﻿----期权交易
--Release version: 1.001.20140505
_WriteAplLog("期权交易初始版 Version:1.001 2014-05-05")
--支持股指期权单笔委托、套利组合交易、委托成交显示、期权及标的行情显示、持仓管理等

--require函数
require("Position")
require("sendLog")
require("DefineEvent_Option")
require("Calculate_Option")
require("SingleOrder_Option")

--启动参数
_DefineStrategyParameters
	_String spStockBAMapID = ""	_Comment "证券账户"	
	_String spFutureBAMapID = ""	_Comment "期权账户"
_End
sendLog("策略初始化中,请稍后……")

--全局变量
gtUnderlyingIssueTable = {}	--已添加的标的合约列表
gtIssuePriceReg = {}		--已注册过行情的合约，避免重复注册
gtIssuePriceInfoTable = {}	--行情表
gUserID = _GetDealerID();	--当前用户ID

DTSDate gNowDate = _GetNowDate();	--获取当前日期
_String gStrDate = gNowDate.asString("%Y%m%d");	--日期格式化成"20100127"
_String gStrDate6 = sys_sub(gStrDate,3,8);	--"100127"
gFutureNo = 0;--已读到几个IF合约的计数变量
gIFIssueCurrent = ""	--当月IF合约
gIFIssueNextMonth = ""	--次月
gIFIssueSeasonMonth = ""--季月
gIFIssueNextSeason = ""	--隔季
gtCalendar = {}	--工作日表，从当前到隔季合约交割日
gtIFIssueInfo = {}	--当前4个股指期货信息表，key为IssueCode,value:到期日、剩余天数等
gtOptionInfo = {}	--期权合约信息
gtFoldExist = {}		--持仓折叠表
gInterestRates = "" --无风险利率
gVolatility	= ""	--波动率
gDividendYield = ""	--股息年化收益率
gUnderlyingIssueCode = "" -- 界面标的
gExpirationDate = "" -- 界面到期日
gGet = "M000300" --选择标的

gCurrentArbType = "" --当前选中套利方式：平价套利、价差套利、凸性套利、箱型套利、日历套利
gtArbitrageRelation = {}	--套利关系表
gtArbitrageRelation["PJ"] = {}	--平价关系
--gtArbitrageRelation["JC"] = {}	--价差关系
gtArbitrageRelation["JD"] = {}	--价差关系（简单）
gtArbitrageRelation["FZ"] = {}	--价差关系（复杂）
gtArbitrageRelation["TX"] = {}	--凸性关系
gtArbitrageRelation["XX"] = {}	--箱型关系
gtArbitrageRelation["RL"] = {}	--日历关系
gOrderNumber = 0	--下单组合编号组成部分，5位数，不足前面补0
gtArbitrageConditions = {}	--套利条件单 第一层key,套利关系ID，第二层key条件单编号(组合编号)
gtStartArbConditios = {}	--执行条件单 key:条件单编号，value:关系ID

gtOrderExist = {}	--委托表折叠功能使用
gtExecExist = {}	--成交表折叠功能使用
gtrefreshIFtable = {} -- 存储当前要刷新的期权合约

gtPosOptionIndex = {}	--保存持仓中Delta,Theta,Vaga,Gamma,Rho的值
IF1LongPos = 0 			--4个期货持仓量
IF2LongPos = 0
IF3LongPos = 0
IF4LongPos = 0
IF1ShortPos = 0
IF2ShortPos = 0
IF3ShortPos = 0
IF4ShortPos = 0

--单笔委托--
_Querylist = {}					--单笔合约维护表
_QueryIssue = ""				--单笔委托中当前显示合约
_DD = 0							--单笔委托资金状况显示标识
_QueryTable = {}				--单笔委托中资金状况显示使用表

--获取当前日期
DTSDate gNowDate = _GetNowDate();	
_String gStrDate = gNowDate.asString("%Y%m%d");	--日期格式化成"20100127"

--position初始化完成
function OnPositionInitialized()
	_WriteAplLog("OnPositionInitialized")
	--发送资金信息
	showFundStatus()
	showPosStatus()
	_StartTimer(_TimerName="ReFreshPosTime",_Interval = 5000);
end
--position初始化报错信息
function OnPositionError(errorInfo)
	_WriteAplLog(errorInfo)
end
--position持仓变化
function OnPositionChanged(position,reason)
	--刷新资金信息
	showFundStatus()
end
--新委托
function OnOrder(positon,order)
end
--新成交
function OnExecution(position,exec)
	showSinglePos(position)
end
--position回测
function OnBackTestDayEnd()
end
--position行情回调
function OnPrice(issueCode,priceInfo)
end

--position初始化
PosInitialize()
PosAddBAMapID(spStockBAMapID)
PosAddBAMapID(spFutureBAMapID)
PosStart()


gStockAccountCode = _PosBAMapAccount[spStockBAMapID]
gFutureAccountCode = _PosBAMapAccount[spFutureBAMapID]

--判断是否设置启动参数
if not gStockAccountCode or not gFutureAccountCode then
	sendLog("请设置有效的启动参数！")
end

----初始化相关数据库信息
--股指期货合约信息
local issueMasterCond = "ExpirationDate >='"..gStrDate.."' and UnderlyingAssetCode = 'IF' and ProductCode = '31' and IssueCode in (select IssueCode from IssueMarketTable where MarketCode = '3' and ListedDate <= '"..gStrDate.."') ORDER BY IssueCode"
_WriteAplLog(issueMasterCond)
_GetCommonData("DBIssueMaster",condition=issueMasterCond,"IssueMaster")
_OnCommonData("DBIssueMaster",DTSIssueMaster record)
	local issueCode = record.getIssueCode()
	local log = sys_format("DBIssueMaster:IssueCode=%s",issueCode)
	_WriteAplLog(log)
	local expirationDate = record.getExpirationDate()
	if gFutureNo == 0 then
		gIFIssueCurrent = issueCode
	elseif gFutureNo == 1 then
		gIFIssueNextMonth = issueCode
	elseif gFutureNo == 2 then
		gIFIssueSeasonMonth = issueCode
	elseif gFutureNo == 3 then
		gIFIssueNextSeason = issueCode
	end
	gFutureNo = gFutureNo + 1
	if not gtIFIssueInfo[issueCode] then
		gtIFIssueInfo[issueCode] = {}
		gtIFIssueInfo[issueCode].ExpirationDate = ""
		gtIFIssueInfo[issueCode].RemainDay = 0
		gtIFIssueInfo[issueCode].RemainTradingDay = 0
	end 
	gtIFIssueInfo[issueCode].ExpirationDate = expirationDate

	local market = record.getPriorMarket();
	_RegisterPrice(_IssueCode = issueCode,_MarketCode = market)
_End

local issueMasterCondition = "ExpirationDate >= '".. _PosGetYMD() .."' and UnderlyingAssetCode = 'IO' and ProductCode = '32' and IssueCode IN (select IssueCode from IssueMarketTable where ListedDate <= '".. _PosGetYMD() .."') ORDER BY IssueCode";
_WriteAplLog(issueMasterCondition)
_GetCommonData(dataName = "OptionIssueMaster", condition = issueMasterCondition, tablename = "IssueMaster");
_OnCommonData(dataName = "OptionIssueMaster", DTSIssueMaster issueMaster)
	local issueCode = issueMaster.getIssueCode();
	local market = issueMaster.getPriorMarket();
	local expirationDate = issueMaster.getExpirationDate();
	local underlying = issueMaster.getUnderlyingIssueCode();
	local putCall = issueMaster.getPutCall();
	local strikePrice = issueMaster.getStrikePrice();
	local optionCode = issueMaster.getIssueLongName();
	local optionName = issueMaster.getIssueLongLocalName();

	local callPut = ""
	--[[	测试期间 getPutCall() 无数据  使用以下逻辑
	if putCall == "3" then
		callPut = "P"
	elseif putCall == "4" then
		callPut = "C"
	end
	]]

	--010
	if gGet == "510300" then
		gtrefreshIFtable["510300"] = gtrefreshIFtable["510300"] or {}
		gtrefreshIFtable["510300"][expirationDate] = gtrefreshIFtable["510300"][expirationDate] or {}
		gtrefreshIFtable["510300"][expirationDate][strikePrice] = gtrefreshIFtable["510300"][expirationDate][strikePrice] or {}
	elseif gGet == "M000300" then
		gtrefreshIFtable["M000300"] = gtrefreshIFtable["M000300"] or {}
		gtrefreshIFtable["M000300"][expirationDate] = gtrefreshIFtable["M000300"][expirationDate] or {}
		gtrefreshIFtable["M000300"][expirationDate][strikePrice] = gtrefreshIFtable["M000300"][expirationDate][strikePrice] or {}
	end

	if sys_sub(issueCode,8,8) == "P" then
		callPut = "P"
		if gGet == "510300" then
			gtrefreshIFtable["510300"][expirationDate][strikePrice].P = issueCode
		elseif gGet == "M000300" then
			gtrefreshIFtable["M000300"][expirationDate][strikePrice].P = issueCode
		end

	elseif sys_sub(issueCode,8,8) == "C" then
		callPut = "C"
		if gGet == "510300" then
			gtrefreshIFtable["510300"][expirationDate][strikePrice].C = issueCode
		elseif gGet == "M000300" then
			gtrefreshIFtable["M000300"][expirationDate][strikePrice].C = issueCode
		end
	end
	gtOptionInfo[issueCode] = {}
	gtOptionInfo[issueCode].IssueName = _PosIssueNameTable[issueCode];
	gtOptionInfo[issueCode].ExpirationDate = expirationDate
	gtOptionInfo[issueCode].CallPut = callPut;
	--gtOptionInfo[issueCode].StrikePrice = sys_format("%.3f",strikePrice);
	gtOptionInfo[issueCode].StrikePrice = strikePrice
	gtOptionInfo[issueCode].Underlying = underlying
	gtOptionInfo[issueCode].RemainDay = 0	--到期剩余自然日
	gtOptionInfo[issueCode].RemainTradingDay = 0	--到期剩余交易日
	-- _RegisterPrice(_IssueCode = issueCode, _MarketCode = market)
	if not gtIssuePriceReg[issueCode] then
		_RegisterPrice(_IssueCode = issueCode,_MarketCode = market)
		gtIssuePriceReg[issueCode] = 1
	end
	 
	 
	local log = sys_format("IssueCode[%s],ExpirationDate[%s],CallPut[%s],StrikePrice[%s]",issueCode,expirationDate,callPut,sys_format("%.3f",strikePrice))
	_WriteAplLog(log)
_End

SendInfo()
function SendInfo()
	local DTSEvent IF = _CreateEventObject("GetIFOut")
	IF._SetFld("IFIssueCurrent",gIFIssueCurrent)
	IF._SetFld("IFIssueNextMonth",gIFIssueNextMonth)
	IF._SetFld("IFIssueSeasonMonth",gIFIssueSeasonMonth)
	IF._SetFld("IFIssueNextSeason",gIFIssueNextSeason)
	_SendToClients(IF);
	_WriteAplLog("发送IF到界面")
	-------------------------------------
	local expirationDateTable = {}
	local DTSEvent Option = _CreateEventObject("GetOptionInfoOut")
	for issue,value in pairs(gtOptionInfo) do
		local expirationDate = value.ExpirationDate
		Option._SetFld("IssueCode",issue)
		Option._SetFld("ExpirationDate",expirationDate)
		_SendToClients(Option);
	
		local log = sys_format("IssueCode[%s],ExpirationDate[%s]",issue,expirationDate)
		_WriteAplLog(log)
	end
end
_OnEventDefined(FindOptionIssue event)
	local xmlDate = event._GetFld("ExpirationDate")
	local callPut = event._GetFld("CallPut")
	local log = sys_format("xmlDate[%s],callPut[%s]",xmlDate,callPut)
	_WriteAplLog(log)
	local issueCode = ""
	for issue,value in pairs(gtOptionInfo) do
		local expirationDate = value.ExpirationDate
		if xmlDate == expirationDate and callPut == sys_sub(issue,8,8) then
			issueCode = issueCode .. issue .. ";"
		end
	end
	local DTSEvent Option = _CreateEventObject("GetOptionIssueOut")
	Option._SetFld("IssueCode",issueCode)
	_SendToClients(Option);
	log = sys_format("OptionIssue[%s]",issueCode)
	_WriteAplLog(log)
_End

local latestDay = gtIFIssueInfo[gIFIssueNextSeason].ExpirationDate;	--有效最后日期是隔季品种的交割日
local openCalendarCondition = "Date >= '"..gStrDate.."' and Date <= '"..latestDay.."'";
_GetCommonData(dataName = "Calendar", condition = openCalendarCondition, tablename = "Calendar");
_OnCommonData(dataName = "Calendar", DTSCalendar calendar)
	local tCalendar = {};
	local theDate = calendar.getDate();
	tCalendar.DayOffFlag = calendar.getDayOffFlag();
	gtCalendar[theDate] = tCalendar;
_End

--计算每个期货、期权的剩余天数和剩余交易天数
for k,v in pairs(gtCalendar) do
	for issueCode,value in pairs(gtIFIssueInfo) do
		local expirationDate = value.ExpirationDate;
		if expirationDate >= k then
			gtIFIssueInfo[issueCode].RemainDay = gtIFIssueInfo[issueCode].RemainDay + 1;
			if v.DayOffFlag == "0" then	--0：工作日
				gtIFIssueInfo[issueCode].RemainTradingDay = gtIFIssueInfo[issueCode].RemainTradingDay + 1;
			end
		end
	end
	for issueCode,value in pairs(gtOptionInfo) do
		local expirationDate = value.ExpirationDate;
		if expirationDate >= k then
			gtOptionInfo[issueCode].RemainDay = gtOptionInfo[issueCode].RemainDay + 1;
			if v.DayOffFlag == "0" then	--0：工作日
				gtOptionInfo[issueCode].RemainTradingDay = gtOptionInfo[issueCode].RemainTradingDay + 1;
			end
		end
	end
end

_OnEventTimer(_TimerName="ReFreshPosTime")
	--_WriteAplLog("定时刷新持仓")
	showPosStatus()

	if _DD == 1 then				--刷新单笔委托资金信息
		if _PosPriceTable[_QueryIssue] then
			_DD = 0
			local CombinCode = _QueryTable["CombinCode"]
			local accountCode = _QueryTable["AccountCode"]
			local BAMapID = 	_QueryTable["BAMapID"]
			sendFundReplyClose(BAMapID,accountCode,CombinCode)
		end
	end

_End

function showSinglePos(pos)
	local DTSEvent posInfo = _CreateEventObject("PositionInfo");
	local baMapID = pos.BAMapID
	local baSubID = pos.BASubID
	local PortID = sys_sub(baSubID,2,-1)
	local PortIDFlag = sys_sub(PortID,1,1)
	local IssueCode = pos.IssueCode
	local Existkey = ""
	if PortID == "" then
		Existkey = _PosIssueProductCodeTable[IssueCode]
		--local log = sys_format("Underlying[%s],IssueCode[%s]",Existkey,IssueCode)
		--_WriteAplLog(log)
	else
		Existkey = PortID
	end
	local IssueName = _PosIssueNameTable[IssueCode]
	local LongShort = ""
	if sys_sub(baSubID,1,1) == "3" then
		LongShort = "多头"
	elseif sys_sub(baSubID,1,1) == "1" then
		LongShort = "空头"
	end
	local Quantity = pos.Quantity
	local ValQuantity = pos.AvlQuantity
	local Cost = ""
	local PriceTable = _PosPriceTable[IssueCode]

	local LastPrice = ""
	if PriceTable then
		LastPrice = PriceTable.LastPrice
	end

	local IFIssue = sys_sub(IssueCode,3,6)
	IFIssue = "IF" .. IFIssue
	local IFPriceTable = _PosPriceTable[IFIssue]
	local IFLastPrice = ""
	if IFPriceTable then
		IFLastPrice = IFPriceTable.LastPrice
	end

	local PL = pos.ValuationPL
	if PL ~= "" and PL then
		PL = sys_format("%.02f",PL)
	end
	local MarketValue = pos.Amount
	if MarketValue ~= "" and MarketValue then
		if Quantity ~= 0 and Quantity then
			Cost = MarketValue / Quantity
			if _PosIssueProductCodeTable[IssueCode] == "31" then
				Cost = Cost / 300
			end
			Cost = sys_format("%.02f",Cost)
		else
			Cost = 0
		end
		MarketValue = sys_format("%.02f",MarketValue)
	end
	local CurMarketValue = "-"
	if LastPrice ~= "" and LastPrice then
		if _PosIssueProductCodeTable[IssueCode] == "31" then
			CurMarketValue = LastPrice * Quantity * 300
			CurMarketValue = sys_format("%.02f",CurMarketValue)
		elseif _PosIssueProductCodeTable[IssueCode] == "32" then
			CurMarketValue = LastPrice * Quantity * 100
			CurMarketValue = sys_format("%.02f",CurMarketValue)
		else
			CurMarketValue = LastPrice * Quantity
			CurMarketValue = sys_format("%.02f",CurMarketValue)
		end
		LastPrice = sys_format("%.02f",LastPrice)
	end
	local OpenFare = pos.Fare
	local ExpirationDate = "-"

	local Delta = "-"
	local Theta = "-"
	local Vaga = "-"
	local Gamma = "-"
	local Rho = "-"
	
	if _PosIssueProductCodeTable[IssueCode] == "32" then
		local log = sys_format("IssueCode[%s],IFIssue[%s],LastPrice[%s],IFLastPrice[%s]",IssueCode,IFIssue,LastPrice,IFLastPrice)
		--_WriteErrorLog(log)
		if LastPrice ~= "" and LastPrice and IFLastPrice ~= "" and IFLastPrice and gDividendYield ~= "" and gDividendYield and gInterestRates ~= "" and gInterestRates then
			local Rounding = 3 							--固定保留3位
			local RemainderDate = dayday(IssueCode) 	--剩余交易日
			local ExercisePrice = 0 					--行权价
			if gtOptionInfo[IssueCode] then
				ExercisePrice = gtOptionInfo[IssueCode].StrikePrice
			end
			local key = baMapID .. baSubID .. IssueCode
			gtPosOptionIndex[key] = {}

			log = sys_format("ExercisePrice[%s],RemainderDate[%s],gDividendYield[%s],gInterestRates[%s],Rounding[%s]",
							ExercisePrice,RemainderDate,gDividendYield,gInterestRates,Rounding)
			--_WriteAplLog(log)
			if sys_sub(IssueCode,8,8) == "P" then 		--看跌
				--_WriteAplLog("看跌")
				local Volatility = calImpliedPutVolatity(IFLastPrice,ExercisePrice,RemainderDate,gDividendYield,LastPrice,gInterestRates,Rounding) -- 跌期权的隐含波动率
				Delta = calPutDelta(IFLastPrice, ExercisePrice, RemainderDate, gDividendYield,Volatility, gInterestRates,Rounding)
				Theta = calPutTheta(IFLastPrice,ExercisePrice,RemainderDate,gDividendYield,Volatility,gInterestRates,Rounding)
				Vaga = calVega(IFLastPrice, ExercisePrice, RemainderDate, gDividendYield,Volatility,gInterestRates,Rounding)
				Gamma = calGamma(IFLastPrice, ExercisePrice, RemainderDate, gDividendYield,Volatility,gInterestRates,Rounding)
				Rho = calPutRho(IFLastPrice, ExercisePrice,RemainderDate,gDividendYield,Volatility,gInterestRates,Rounding)

				gtPosOptionIndex[key].CallPut = "P"

			elseif sys_sub(IssueCode,8,8) == "C" then 	--看涨
				--_WriteAplLog("看涨")
				local Volatility = calImpliedCallVolatity(IFLastPrice,ExercisePrice,RemainderDate,gDividendYield,LastPrice,gInterestRates,Rounding) -- 涨期权的隐含波动率
				Delta = calCallDelta(IFLastPrice, ExercisePrice, RemainderDate, gDividendYield,Volatility, gInterestRates,Rounding)
				Theta = calCallTheta(IFLastPrice,ExercisePrice,RemainderDate,gDividendYield,Volatility,gInterestRates,Rounding)
				Vaga = calVega(IFLastPrice, ExercisePrice, RemainderDate, gDividendYield,Volatility,gInterestRates,Rounding)
				Gamma = calGamma(IFLastPrice, ExercisePrice, RemainderDate, gDividendYield,Volatility,gInterestRates,Rounding)
				Rho = calCallRho(IFLastPrice,ExercisePrice, RemainderDate,gDividendYield,Volatility,gInterestRates,Rounding)

				gtPosOptionIndex[key].CallPut = "C"

			end
			gtPosOptionIndex[key].Delta = Delta
			gtPosOptionIndex[key].Theta = Theta
			gtPosOptionIndex[key].Vaga = Vaga
			gtPosOptionIndex[key].Gamma = Gamma
			gtPosOptionIndex[key].Rho = Rho

			log = sys_format("Delta[%s],Theta[%s],Vaga[%s],Gamma[%s],Rho[%s]",Delta,Theta,Vaga,Gamma,Rho)
			--_WriteErrorLog(log)
		end
	end

	if not gtFoldExist[Existkey] then
		gtFoldExist[Existkey] = {}
		local UniqueKeyCode = "表头" .. Existkey

		if PortIDFlag == "S" then
			posInfo._SetFld("PortName","投机持仓");
			posInfo._SetFld("PortID",PortID);
		elseif PortIDFlag == "H" then
			posInfo._SetFld("PortName","套保持仓");
			posInfo._SetFld("PortID",PortID);
		elseif PortIDFlag == "A" then
			posInfo._SetFld("PortName","套利持仓");
			posInfo._SetFld("PortID",PortID);
		elseif PortIDFlag == "M" then
			posInfo._SetFld("PortName","单笔委托");
			posInfo._SetFld("PortID",PortID);
		elseif PortIDFlag ~= "" then
			posInfo._SetFld("PortName","其他组合");
			posInfo._SetFld("PortID",PortID);
		elseif sys_sub(IssueCode,1,2) == "IF" then
			posInfo._SetFld("PortName","");
			posInfo._SetFld("PortID","期货持仓");
		else
			posInfo._SetFld("PortName","");
			posInfo._SetFld("PortID","other");
		end
		
		posInfo._SetFld("IssueCode","");
		posInfo._SetFld("IssueName","");
		posInfo._SetFld("LongShort","");
		posInfo._SetFld("Quantity","");
		posInfo._SetFld("ValQuantity","");
		posInfo._SetFld("Cost","");
		posInfo._SetFld("LastPrice","");
		posInfo._SetFld("PL","");
		posInfo._SetFld("MarketValue","");
		posInfo._SetFld("CurMarketValue","");
		posInfo._SetFld("OpenFare","");
		posInfo._SetFld("EstCloseFare","");
		posInfo._SetFld("ExpirationDate","");

		posInfo._SetFld("Delta","");
		posInfo._SetFld("Theta","");
		posInfo._SetFld("Vaga","");
		posInfo._SetFld("Gamma","");
		posInfo._SetFld("Rho","");

		posInfo._SetFld("MarginFlag","1");
		posInfo._SetFld("UniqueKeyCode",UniqueKeyCode);
		--_WriteAplLog("合并表头")
		_SendToClients(posInfo)
	end

	local UniqueKeyCode = "表格" .. baSubID .. IssueCode
	if PortIDFlag == "S" then
		posInfo._SetFld("PortName","投机持仓");
		posInfo._SetFld("PortID",PortID);
	elseif PortIDFlag == "H" then
		posInfo._SetFld("PortName","套保持仓");
		posInfo._SetFld("PortID",PortID);
		local WorkingQtyOfOpen = pos.WorkingQtyOfOpen or 0
		if LongShort == "空头" then
			if sys_sub(IssueCode,3,6) == sys_sub(gIFIssueCurrent,3,6) then
				IF1LongPos = IF1LongPos - ValQuantity - WorkingQtyOfOpen
			elseif sys_sub(IssueCode,3,6) == sys_sub(gIFIssueNextMonth,3,6) then
				IF2LongPos = IF2LongPos - ValQuantity - WorkingQtyOfOpen
			elseif sys_sub(IssueCode,3,6) == sys_sub(gIFIssueSeasonMonth,3,6) then
				IF3LongPos = IF3LongPos - ValQuantity - WorkingQtyOfOpen
			elseif sys_sub(IssueCode,3,6) == sys_sub(gIFIssueNextSeason,3,6) then
				IF4LongPos = IF4LongPos - ValQuantity - WorkingQtyOfOpen
			end
		elseif LongShort == "多头" then
			if sys_sub(IssueCode,3,6) == sys_sub(gIFIssueCurrent,3,6) then
				IF1ShortPos = IF1ShortPos - ValQuantity - WorkingQtyOfOpen
			elseif sys_sub(IssueCode,3,6) == sys_sub(gIFIssueNextMonth,3,6) then
				IF2ShortPos = IF2ShortPos - ValQuantity - WorkingQtyOfOpen
			elseif sys_sub(IssueCode,3,6) == sys_sub(gIFIssueSeasonMonth,3,6) then
				IF3ShortPos = IF3ShortPos - ValQuantity - WorkingQtyOfOpen
			elseif sys_sub(IssueCode,3,6) == sys_sub(gIFIssueNextSeason,3,6) then
				IF4ShortPos = IF4ShortPos - ValQuantity - WorkingQtyOfOpen
			end
		end
	elseif PortIDFlag == "A" then
		posInfo._SetFld("PortName","套利持仓");
		posInfo._SetFld("PortID",PortID);
	elseif PortIDFlag == "M" then
		posInfo._SetFld("PortName","单笔委托");
		posInfo._SetFld("PortID",PortID);
	elseif PortIDFlag ~= "" then
		posInfo._SetFld("PortName","其他组合");
		posInfo._SetFld("PortID",PortID);
	elseif sys_sub(IssueCode,1,2) == "IF" then
		posInfo._SetFld("PortName","");
		posInfo._SetFld("PortID","期货持仓");

		if LongShort == "多头" then
			if IssueCode == gIFIssueCurrent then
				IF1LongPos = IF1LongPos + ValQuantity
			elseif IssueCode == gIFIssueNextMonth then
				IF2LongPos = IF2LongPos + ValQuantity
			elseif IssueCode == gIFIssueSeasonMonth then
				IF3LongPos = IF3LongPos + ValQuantity
			elseif IssueCode == gIFIssueNextSeason then
				IF4LongPos = IF4LongPos + ValQuantity
			end
		elseif LongShort == "空头" then
			if IssueCode == gIFIssueCurrent then
				IF1ShortPos = IF1ShortPos + ValQuantity
			elseif IssueCode == gIFIssueNextMonth then
				IF2ShortPos = IF2ShortPos + ValQuantity
			elseif IssueCode == gIFIssueSeasonMonth then
				IF3ShortPos = IF3ShortPos + ValQuantity
			elseif IssueCode == gIFIssueNextSeason then
				IF4ShortPos = IF4ShortPos + ValQuantity
			end
		end
		--[[
		local log = sys_format("IF1LongPos[%s],IF2LongPos[%s],IF3LongPos[%s],IF4LongPos[%s]\nIF1ShortPos[%s],IF2ShortPos[%s],IF3ShortPos[%s],IF4ShortPos[%s]",
								IF1LongPos,IF2LongPos,IF3LongPos,IF4LongPos,IF1ShortPos,IF2ShortPos,IF3ShortPos,IF4ShortPos)
		_WriteAplLog(log)
		]]
	else
		posInfo._SetFld("PortName","");
		posInfo._SetFld("PortID","other");
	end
	if sys_sub(IssueCode,1,2) == "IF" then
		ExpirationDate = gtIFIssueInfo[IssueCode].ExpirationDate
	elseif sys_sub(IssueCode,1,2) == "IO" then
		ExpirationDate = gtOptionInfo[IssueCode].ExpirationDate
	end
	
	posInfo._SetFld("IssueCode",IssueCode);
	posInfo._SetFld("IssueName",IssueName);
	posInfo._SetFld("LongShort",LongShort);
	posInfo._SetFld("Quantity",Quantity);
	posInfo._SetFld("ValQuantity",ValQuantity);
	posInfo._SetFld("Cost",Cost);
	posInfo._SetFld("LastPrice",LastPrice);
	posInfo._SetFld("PL",PL);
	posInfo._SetFld("MarketValue",MarketValue);
	posInfo._SetFld("CurMarketValue",CurMarketValue);
	posInfo._SetFld("OpenFare",OpenFare);
	posInfo._SetFld("EstCloseFare","-");
	posInfo._SetFld("ExpirationDate",ExpirationDate);

	posInfo._SetFld("Delta",Delta);
	posInfo._SetFld("Theta",Theta);
	posInfo._SetFld("Vaga",Vaga);
	posInfo._SetFld("Gamma",Gamma);
	posInfo._SetFld("Rho",Rho);

	posInfo._SetFld("MarginFlag","2");
	posInfo._SetFld("UniqueKeyCode",UniqueKeyCode);
	--_WriteAplLog("表格数据")
	_SendToClients(posInfo)

	--local log = sys_format("baMapID[%s],baSubID[%s],PortID[%s],IssueCode[%s]",baMapID,baSubID,PortID,IssueCode)
	--_WriteAplLog(log)
end
--账户持仓详情
function showPosStatus()
	local tStockPosFundStatus = _PosFundStatus[gStockAccountCode];
	local tFuturePosFundStatus = _PosFundStatus[gFutureAccountCode];
	if tStockPosFundStatus and tFuturePosFundStatus then
		IF1LongPos = 0
		IF2LongPos = 0
		IF3LongPos = 0
		IF4LongPos = 0
		IF1ShortPos = 0
		IF2ShortPos = 0
		IF3ShortPos = 0
		IF4ShortPos = 0
		for key, pos in pairs(_PosPositionTable) do
			local Qty = pos.Quantity
			if Qty > 0 then
				showSinglePos(pos)
			end
		end

		local Delta = 0
		local Theta = 0
		local Vaga = 0
		local Gamma = 0
		local Rho = 0
		for key,OptionIndex in pairs(gtPosOptionIndex) do
			if OptionIndex.CallPut == "P" then
				Delta = Delta - OptionIndex.Delta
				Theta = Theta - OptionIndex.Theta
				Vaga = Vaga - OptionIndex.Vaga
				Gamma = Gamma - OptionIndex.Gamma
				Rho = Rho - OptionIndex.Rho
			elseif OptionIndex.CallPut == "C" then
				Delta = Delta + OptionIndex.Delta
				Theta = Theta + OptionIndex.Theta
				Vaga = Vaga + OptionIndex.Vaga
				Gamma = Gamma + OptionIndex.Gamma
				Rho = Rho + OptionIndex.Rho
			end
		end
		--[[
		local log = sys_format("IF1LongPos[%s],IF2LongPos[%s],IF3LongPos[%s],IF4LongPos[%s]\nIF1ShortPos[%s],IF2ShortPos[%s],IF3ShortPos[%s],IF4ShortPos[%s]",
								IF1LongPos,IF2LongPos,IF3LongPos,IF4LongPos,IF1ShortPos,IF2ShortPos,IF3ShortPos,IF4ShortPos)
		_WriteAplLog(log)
		]]
		local DTSEvent posOption = _CreateEventObject("PosOptionIndex");
		posOption._SetFld("Delta",Delta);
		posOption._SetFld("Theta",Theta);
		posOption._SetFld("Vaga",Vaga);
		posOption._SetFld("Gamma",Gamma);
		posOption._SetFld("Rho",Rho);
	
		if IF1LongPos < 0 then
			IF1LongPos = 0
		end
		if IF2LongPos < 0 then
			IF2LongPos = 0
		end
		if IF3LongPos < 0 then
			IF3LongPos = 0
		end
		if IF4LongPos < 0 then
			IF4LongPos = 0
		end
		if IF1ShortPos < 0 then
			IF1ShortPos = 0
		end
		if IF2ShortPos < 0 then
			IF2ShortPos = 0
		end
		if IF3ShortPos < 0 then
			IF3ShortPos = 0
		end
		if IF4ShortPos < 0 then
			IF4ShortPos = 0
		end

		posOption._SetFld("IF1LongPos",IF1LongPos);
		posOption._SetFld("IF2LongPos",IF2LongPos);
		posOption._SetFld("IF3LongPos",IF3LongPos);
		posOption._SetFld("IF4LongPos",IF4LongPos);

		posOption._SetFld("IF1ShortPos",IF1ShortPos);
		posOption._SetFld("IF2ShortPos",IF2ShortPos);
		posOption._SetFld("IF3ShortPos",IF3ShortPos);
		posOption._SetFld("IF4ShortPos",IF4ShortPos);

		_SendToClients(posOption)
	end
end

--账户资金详情
function showFundStatus()
	--_WriteAplLog("show FundStatus");
	local DTSEvent fundStatusEvent = _CreateEventObject("FundStatus");
	local tStockPosFundStatus = _PosFundStatus[gStockAccountCode];
	local tFuturePosFundStatus = _PosFundStatus[gFutureAccountCode];
	if tStockPosFundStatus and tFuturePosFundStatus then
		local s_AssetValue = tStockPosFundStatus.AssetValue;
		local f_AssetValue = tFuturePosFundStatus.AssetValue;
		local s_AvlFund = tStockPosFundStatus.AvlFund;
		local f_AvlFund = tFuturePosFundStatus.AvlFund;
		local s_Margin = tStockPosFundStatus.Margin;
		local f_Margin = tFuturePosFundStatus.Margin;
		local s_ValuationPL = tStockPosFundStatus.ValuationPL;
		local f_ValuationPL = tFuturePosFundStatus.ValuationPL;
		local s_OrderFund = tStockPosFundStatus.OrderFund;
		local f_OrderFund = tFuturePosFundStatus.OrderFund;

		local value = "";

		fundStatusEvent._SetFld("Item","动态权益");
		value = sys_format("%.02f",s_AssetValue);
		fundStatusEvent._SetFld("StockAccount",value);
		value = sys_format("%.02f",f_AssetValue);
		fundStatusEvent._SetFld("FutureAccount",value);
		fundStatusEvent._SetFld("Row",1);
		_SendToClients(fundStatusEvent);

		fundStatusEvent._SetFld("Item","可用资金");
		value = sys_format("%.02f",s_AvlFund);
		fundStatusEvent._SetFld("StockAccount",value);
		value = sys_format("%.02f",f_AvlFund);
		fundStatusEvent._SetFld("FutureAccount",value);
		fundStatusEvent._SetFld("Row",2);
		_SendToClients(fundStatusEvent);

		fundStatusEvent._SetFld("Item","头寸金额");
		value = sys_format("%.02f",s_Margin);
		fundStatusEvent._SetFld("StockAccount",value);
		value = sys_format("%.02f",f_Margin);
		fundStatusEvent._SetFld("FutureAccount",value);
		fundStatusEvent._SetFld("Row",3);
		_SendToClients(fundStatusEvent);

		fundStatusEvent._SetFld("Item","浮动盈亏");
		value = sys_format("%.02f",s_ValuationPL);
		fundStatusEvent._SetFld("StockAccount",value);
		value = sys_format("%.02f",f_ValuationPL);
		fundStatusEvent._SetFld("FutureAccount",value);
		fundStatusEvent._SetFld("Row",4);
		_SendToClients(fundStatusEvent);

		fundStatusEvent._SetFld("Item","冻结资金");
		value = sys_format("%.02f",s_OrderFund);
		fundStatusEvent._SetFld("StockAccount",value);
		value = sys_format("%.02f",f_OrderFund);
		fundStatusEvent._SetFld("FutureAccount",value);
		fundStatusEvent._SetFld("Row",5);
		--_SendToClients(fundStatusEvent);
	end
end

-----DD数据读取
--合约标的信息
DTSEvent UnderIssuePriceInfoEvent = _CreateEventObject("UnderlyingIssueSave")
DTSDynamicData  UnderIssuePriceInfoStore = _CreateDynamicData(TSInstanceName="AddUnderIssueStore",fileType=_DataOtherType,UnderlyingIssueSave UnderIssuePriceInfoEvent)
UnderIssuePriceInfoStore._GetDynamicData(dataName="AddUnderIssueStore",condition="")
_OnDynamicData(dataName="AddUnderIssueStore",UnderlyingIssueSave event)
	local underlyingIssueCode = event._GetFld("UnderlyingIssueCode")
	local log = sys_format("DD:underlyingIssueCode=%s",underlyingIssueCode)
	_WriteAplLog(log)

	local DTSEvent evt = _CreateEventObject("DDXiaLa") -- 087
	--_WriteAplLog(underlyingIssueCode)
	evt._SetFld("UnderlyingIssueCode",underlyingIssueCode)
	_SendToClients(evt)

	if _PosIssueMarketTable[underlyingIssueCode] then
		local marketCode = _PosIssueMarketTable[underlyingIssueCode]
		if not gtIssuePriceReg[underlyingIssueCode] then
			_RegisterPrice(_IssueCode = underlyingIssueCode,_MarketCode = marketCode)
			gtIssuePriceReg[underlyingIssueCode] = 1
		end
		gtUnderlyingIssueTable[underlyingIssueCode] = marketCode
		sendUnderlyIssuePriceInfo(underlyingIssueCode)
	else
		local log = sys_format("%s marketCode does not exist!",underlyingIssueCode)
		_WriteAplLog(log)
	end
_End
--期权参数
DTSEvent ParameterSetEvent = _CreateEventObject("ParameterSetOut")
DTSDynamicData ParameterStore = _CreateDynamicData(TSInstanceName="ParameterSet",fileType=_DataOtherType,ParameterSetOut ParameterSetEvent)
ParameterStore._GetDynamicData(dataName="ParameterSet",condition="")
_OnDynamicData(dataName="ParameterSet",ParameterSetOut event)
	local interestRates = event._GetFld("InterestRates")
	local volatility = event._GetFld("Volatility")
	local dividendYield = event._GetFld("DividendYield")
	local log = sys_format("DD:ParameterSet InterestRates=%s,Volatility=%s,DividendYield=%s",interestRates,volatility,dividendYield)
	_WriteAplLog(log)
	gInterestRates = interestRates/100
	gVolatility	= volatility/100
	gDividendYield = dividendYield/100
	sendParameters(interestRates,volatility,dividendYield)
_End

--添加标的合约
_OnEventDefined(AddUnderlyingIssue event)
	local underlyingIssueCode = event._GetFld("UnderlyingIssueCode")
	if _PosIssueMarketTable[underlyingIssueCode] then
		local marketCode = _PosIssueMarketTable[underlyingIssueCode]
		local productCode = _PosIssueProductCodeTable[underlyingIssueCode] or ""
		--标的只能添加股指期货和沪深300指数,股票后续版本支持
		if (marketCode == "1" or marketCode =="2") or (marketCode == "3" and productCode == "31") then
			if not gtIssuePriceReg[underlyingIssueCode] then
				_RegisterPrice(_IssueCode = underlyingIssueCode,_MarketCode = marketCode)
				gtIssuePriceReg[underlyingIssueCode] = 1
			end
			gtUnderlyingIssueTable[underlyingIssueCode] = marketCode
			sendUnderlyIssuePriceInfo(underlyingIssueCode)
			local log = sys_format("%s添加完成",underlyingIssueCode)
			_WriteAplLog(log)
			sendLog(log)

			local DTSEvent evt = _CreateEventObject("AddXiaLa")
			evt._SetFld("UnderlyingIssueCode",underlyingIssueCode)
			_SendToClients(evt)
			--saveDDData
			local DTSEvent underlyingIssueSave = _CreateEventObject("UnderlyingIssueSave")
			underlyingIssueSave._SetFld("UnderlyingIssueCode",underlyingIssueCode)
			UnderIssuePriceInfoStore._SaveData("AddUnderIssueStore",underlyingIssueSave)
		else
			local log = sys_format("%s添加失败,标的合约不是股指期货或者个股合约",underlyingIssueCode)
			_WriteAplLog(log)
			sendLog(log)
		end
	else
		local log = sys_format("%s添加失败,合约不存在",underlyingIssueCode)
		_WriteAplLog(log)
		sendLog(log)
	end
_End

--删除标的合约
_OnEventDefined(DeleteUnderlyingIssue event)
	local underlyingIssueCode = event._GetFld("UnderlyingIssueCode")
	if gtUnderlyingIssueTable[underlyingIssueCode] then
		local DTSEvent priceInfo = _CreateEventObject("UnderlyingIssuePriceInfo")
		priceInfo._SetFld("UnderlyingIssueCode",underlyingIssueCode)
		priceInfo._SetFld("UnderlyingIssueName","")
		priceInfo._SetFld("LastPrice","")
		priceInfo._SetFld("Ratio","")
		priceInfo._SetFld("BidPrice1","")
		priceInfo._SetFld("BidQty1","")
		priceInfo._SetFld("AskPrice1","")
		priceInfo._SetFld("AskQty1","")
		priceInfo._SetFld("ExpirationDate","")
		priceInfo._SetFld("RemainDay",0)
		priceInfo._SetFld("Flag","0")
		_SendToClients(priceInfo)
		gtUnderlyingIssueTable[underlyingIssueCode] = nil
		local log = sys_format("%s删除成功",underlyingIssueCode)
		_WriteAplLog(log)
		sendLog(log)

		local DTSEvent evt = _CreateEventObject("DelXiaLa")
		evt._SetFld("UnderlyingIssueCode",underlyingIssueCode)
		_SendToClients(evt)
		--deleteDDData
		UnderIssuePriceInfoEvent._SetFld("UnderlyingIssueCode",underlyingIssueCode)
		UnderIssuePriceInfoStore._Clear()
	else
		local log = sys_format("%s删除失败,合约不存在",underlyingIssueCode)
		_WriteAplLog(log)
		sendLog(log)
	end
_End	
--发送标的合约信息
function sendUnderlyIssuePriceInfo(underlyingIssueCode)
	if gtUnderlyingIssueTable[underlyingIssueCode] then --添加的标的合约
		local expirationDate = ""
		local remainDay = 0
		if gtIFIssueInfo[underlyingIssueCode] then
			expirationDate = gtIFIssueInfo[underlyingIssueCode].ExpirationDate
			remainDay = gtIFIssueInfo[underlyingIssueCode].RemainDay
		end
		if gtIssuePriceInfoTable[underlyingIssueCode] then --行情存在	
			local DTSEvent priceInfo = _CreateEventObject("UnderlyingIssuePriceInfo")
			local lastPrice = gtIssuePriceInfoTable[underlyingIssueCode].LastPrice
			local adjustedLNC = gtIssuePriceInfoTable[underlyingIssueCode].AdjustedLNC
			local ratio = 0
			if adjustedLNC ~= 0 and lastPrice ~= 0 then
				ratio = (lastPrice - adjustedLNC) / adjustedLNC
				ratio = sys_format("%.2f",ratio*100)
			end
			local issueName = _PosIssueNameTable[underlyingIssueCode] or ""
			local bidPrice1 = gtIssuePriceInfoTable[underlyingIssueCode].BidPrice1 or "-"
			local bidQty1 = gtIssuePriceInfoTable[underlyingIssueCode].BidQuantity1 or "-"
			if bidQty1 and bidQty1 ~= "-" then
				bidQty1 = sys_format("%.0f",bidQty1)
			end
			local askPrice1 = gtIssuePriceInfoTable[underlyingIssueCode].AskPrice1 or "-"
			local askQty1 = gtIssuePriceInfoTable[underlyingIssueCode].AskQuantity1 or "-"
			if askQty1 and askQty1 ~= "" then
				askQty1 = sys_format("%.0f",askQty1)
			end
			
			priceInfo._SetFld("UnderlyingIssueCode",underlyingIssueCode)
			priceInfo._SetFld("UnderlyingIssueName",issueName)
			priceInfo._SetFld("LastPrice",lastPrice)
			priceInfo._SetFld("Ratio",ratio)
			priceInfo._SetFld("BidPrice1",bidPrice1)
			priceInfo._SetFld("BidQty1",bidQty1)
			priceInfo._SetFld("AskPrice1",askPrice1)
			priceInfo._SetFld("AskQty1",askQty1)
			priceInfo._SetFld("ExpirationDate",expirationDate)
			priceInfo._SetFld("RemainDay",remainDay)
			priceInfo._SetFld("Flag","1")
			_SendToClients(priceInfo)
		else
			local DTSEvent priceInfo = _CreateEventObject("UnderlyingIssuePriceInfo")
			local issueName = _PosIssueNameTable[underlyingIssueCode] or ""
			priceInfo._SetFld("UnderlyingIssueCode",underlyingIssueCode)
			priceInfo._SetFld("UnderlyingIssueName",issueName)
			priceInfo._SetFld("LastPrice","-")
			priceInfo._SetFld("Ratio","-")
			priceInfo._SetFld("BidPrice1","-")
			priceInfo._SetFld("BidQty1","-")
			priceInfo._SetFld("AskPrice1","-")
			priceInfo._SetFld("AskQty1","-")
			priceInfo._SetFld("ExpirationDate",expirationDate)
			priceInfo._SetFld("RemainDay",remainDay)
			priceInfo._SetFld("Flag","1")
			_SendToClients(priceInfo)
		end
	end
end

--分时图（1分钟K线+实时行情）
_OnEventDefined(OnClickShowChartIn event)
	local underlyingIssueCode = event._GetFld("UnderlyingIssueCode")
	local log =sys_format("get k1mevent:underlyingIssueCode=%s",underlyingIssueCode)
	_WriteAplLog(log)
	
	local DTSTime nowtime = _GetNowTime();
	local time = nowtime.asString("%H%M%S");
	local StartTime = gStrDate .. "000000000000"
	local EndTime = gStrDate .."235900000000"
	local cond = sys_format("IssueCode#%s;_TimeKey#%s:%s",underlyingIssueCode, StartTime, EndTime)
	_WriteAplLog(cond)
	if time > "153000" then
		local DTSEvent k1mevent = _CreateEventObject("k1MEvent")
		local DTSDynamicData k1mdata = _CreateDynamicData(TSInstanceName="_auto_k1mEvent",fileType=_DataDayType,k1MEvent k1mevent,portfolioID="HDS_PID",strategyID="HDS_SID")
		k1mdata._GetDynamicData(dataName="k1m", condition=cond);
	else
		_RegisterEventObject(PortfolioID="HDS_PID",StrageyID="HDS_SID",EventID="k1mEvent", condition=cond)
	end
_End
_OnDynamicData(_dataName="k1m",k1MEvent event)
	local underlyingIssueCode = event._GetFld("IssueCode")
	local lastPrice = event._GetFld("ClosePrice")
	local dataTime = event._GetFld("DateTime")
	local timekey = event._GetTimeKey()
	local log=sys_format("k1mevent:issueCode:%s,price:%s,datatime%s,timekey:%s",underlyingIssueCode,lastPrice,dataTime,timekey)
	_WriteAplLog(log)
	local DTSEvent graphEvent = _CreateEventObject("OnClickShowChartOut")
	graphEvent._SetFld("IssueCode",underlyingIssueCode)
	graphEvent._SetFld("DataTime",dataTime)
	graphEvent._SetFld("_TimeKey",timekey)
	graphEvent._SetFld("LastPrice",lastPrice)
	_SendToClients(graphEvent)
_End

_OnEventDefined(k1mEvent event)
	local underlyingIssueCode = event._GetFld("IssueCode")
	local price = event._GetFld("ClosePrice")
	local dataTime = event._GetFld("DateTime")
	local timekey = event._GetTimeKey()
	local log=sys_format("k1mevent:issueCode:%s,price:%s,datatime%s,timekey:%s",underlyingIssueCode,price,dataTime,timekey)
	_WriteAplLog(log)
	local DTSEvent graphEvent = _CreateEventObject("OnClickShowChartOut")
	graphEvent._SetFld("IssueCode",underlyingIssueCode)
	graphEvent._SetFld("DataTime",dataTime)
	graphEvent._SetFld("_TimeKey",timekey)
	graphEvent._SetFld("LastPrice",price)
	_SendToClients(graphEvent)
_End

--参数设置回调
_OnEventDefined(ParameterSetIn event)
	local interestRates = event._GetFld("InterestRates")
	local volatility = event._GetFld("Volatility")
	local dividendYield = event._GetFld("DividendYield")
	gInterestRates = interestRates/100
	gVolatility	= volatility/100
	gDividendYield = dividendYield/100
	local log = sys_format("ParameterSet:gInterestRates=%s,gVolatility=%s,gDividendYield=%s",gInterestRates,gVolatility,gDividendYield)
	_WriteAplLog(log)
	sendParameters(interestRates,volatility,dividendYield)
	--保存DD
	ParameterStore._Clear()
	local DTSEvent paraSet = _CreateEventObject("ParameterSetOut")
	paraSet._SetFld("InterestRates",interestRates)
	paraSet._SetFld("Volatility",volatility)
	paraSet._SetFld("DividendYield",dividendYield)
	ParameterStore._SaveData("ParameterSet",paraSet)
	local log1 = sys_format("参数设置成功:无风险利率%s,波动率%s,股息年化收益率%s",gInterestRates,gVolatility,gDividendYield)
	sendLog(log1)
	--刷新相关数据
_End

--发送期权参数设置
function sendParameters(interestRates,volatility,dividendYield)
	local DTSEvent evt = _CreateEventObject("ParameterSetOut")
	evt._SetFld("InterestRates",interestRates)
	evt._SetFld("Volatility",volatility)
	evt._SetFld("DividendYield",dividendYield)
	_SendToClients(evt)
end

_RegisterPrice(_IssueCode="M000300", _MarketCode="1");

--行情回调
_OnEventPrice(_PriceName="MyPrice", {} , DTSPrice price);
	local issueCode = price.getIssueCode()
	local priceInfo = gtIssuePriceInfoTable[issueCode]
	if not priceInfo then 
		gtIssuePriceInfoTable[issueCode] = {}
		priceInfo = gtIssuePriceInfoTable[issueCode]
	end
	local tick = _PosIssuePriceTickTable[issueCode]
	if _PosNeedAdjPrice then
		priceInfo.LastPrice = price.getEstLastPrice()
		priceInfo.LastTime = price.getLastVolumeTimeStamp();
		priceInfo.AdjustedLNC = _PosPriceToNumber(price.getAdjustedLNC(),tick);
		priceInfo.AskPrice1 = _PosPriceToNumber(price.getAskPrice_1(), tick)
		priceInfo.AskPrice2 = _PosPriceToNumber(price.getAskPrice_2(), tick)
		priceInfo.AskPrice3 = _PosPriceToNumber(price.getAskPrice_3(), tick)
		priceInfo.AskPrice4 = _PosPriceToNumber(price.getAskPrice_4(), tick)
		priceInfo.AskPrice5 = _PosPriceToNumber(price.getAskPrice_5(), tick)
		priceInfo.BidPrice1 = _PosPriceToNumber(price.getBidPrice_1(), tick)
		priceInfo.BidPrice2 = _PosPriceToNumber(price.getBidPrice_2(), tick)
		priceInfo.BidPrice3 = _PosPriceToNumber(price.getBidPrice_3(), tick)
		priceInfo.BidPrice4 = _PosPriceToNumber(price.getBidPrice_4(), tick)
		priceInfo.BidPrice5 = _PosPriceToNumber(price.getBidPrice_5(), tick)
		priceInfo.AskQuantity1 = _PosQuantityToNumber(price.getAskQty_1())
		priceInfo.AskQuantity2 = _PosQuantityToNumber(price.getAskQty_2())
		priceInfo.AskQuantity3 = _PosQuantityToNumber(price.getAskQty_3())
		priceInfo.AskQuantity4 = _PosQuantityToNumber(price.getAskQty_4())
		priceInfo.AskQuantity5 = _PosQuantityToNumber(price.getAskQty_5())
		priceInfo.BidQuantity1 = _PosQuantityToNumber(price.getBidQty_1())
		priceInfo.BidQuantity2 = _PosQuantityToNumber(price.getBidQty_2())
		priceInfo.BidQuantity3 = _PosQuantityToNumber(price.getBidQty_3())
		priceInfo.BidQuantity4 = _PosQuantityToNumber(price.getBidQty_4())
		priceInfo.BidQuantity5 = _PosQuantityToNumber(price.getBidQty_5())
		
		sendUnderlyIssuePriceInfo(issueCode)
	end
	if issueCode == "M000300" then
		local priceinfo = gtIssuePriceInfoTable[issueCode] or {}
		local lastPrice = priceinfo.LastPrice or priceinfo.AdjustedLNC
		if lastPrice then
			local DTSEvent HS300PriceEvent = _CreateEventObject("GetHS300Price")
			HS300PriceEvent._SetFld("HS300Price",lastPrice)
			_SendToClients(HS300PriceEvent)		
		end
	end

	---------------xh----------------010
	if gUnderlyingIssueCode ~= "" and gExpirationDate ~= "" then
		--if issueCode == "510300" then
			--SendToHandTable(gUnderlyingIssueCode,gExpirationDate,"","1")
		--end

		if issueCode == "M000300" then
			SendToHandTable(gUnderlyingIssueCode,gExpirationDate,"","1")
		end
		SendToHandTable(gUnderlyingIssueCode,gExpirationDate,issueCode,"1")
	end
	--刷新界面显示的套利关系组合
	local marketCode = _PosIssueMarketTable[issueCode] or ""
	if marketCode == "3" then	--股指期货、股指期权
		refreshArbInfo(issueCode,gCurrentArbType)
		ArbConditionMonitorAll()
	end
_End
_OnEventDefined(GetHS300PriceNow event)
	local priceinfo = gtIssuePriceInfoTable["M000300"] or {}
	local lastPrice = priceinfo.LastPrice or priceinfo.AdjustedLNC
	if lastPrice then
		local DTSEvent HS300PriceEvent = _CreateEventObject("GetHS300Price")
		HS300PriceEvent._SetFld("HS300Price",lastPrice)
		_SendToClients(HS300PriceEvent)		
	end
_End

--期权理论价、参数计算
_OnEventDefined(CalcOptionParameterIn event)
	local UnderlyingPrice = event._GetFld("UnderlyingPrice")
	local ExercisePrice = event._GetFld("ExercisePrice")
	local Time = event._GetFld("DaysUntilExpiration")
	local InterestRates = event._GetFld("InterestRates")
	local DividendYield = event._GetFld("DividendYield")
	local Volatility = event._GetFld("Volatility")
	local Rounding = event._GetFld("Rounding")
	local log = sys_format("CalcOptionParameterIn:UnderlyingPrice=%s,ExercisePrice=%s,Time=%s,InterestRates=%s,DividendYield=%s,Volatility=%s,Rounding=%s",UnderlyingPrice,ExercisePrice,Time,InterestRates,DividendYield,Volatility,Rounding)
	_WriteAplLog(log)
	--看涨期权
	local CTheoreticPrice = calCallOption(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	local CDelta = calCallDelta(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	local CTheta = calCallTheta(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	local CRho = calCallRho(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	--看跌期权
	local PTheoreticPrice = calPutOption(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	local PDelta = calPutDelta(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	local PTheta = calPutTheta(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	local PRho = calPutRho(UnderlyingPrice, ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	
	local Gamma = calGamma(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)	
	local Vega = calVega(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	local logs = sys_format("CalcOptionResult:CtheoreticalPrice=%s,PtheoreticalPrice=%s,CDelta=%s,PDelta=%s,CTheta=%s,Gamma=%s,Vega=%s,CRho=%s,PRho=%s",CTheoreticPrice,PTheoreticPrice,CDelta,PDelta,CTheta,Gamma,Vega,CRho,PRho)
	_WriteAplLog(logs)
	
	local format = sys_format("%%.%df",Rounding)
	local Gamma1 = sys_format(format,Gamma/100)
	
	local DTSEvent sendCalcOption = _CreateEventObject("CalcOptionParameterOut")
	sendCalcOption._SetFld("CTheoreticPrice",CTheoreticPrice)
	sendCalcOption._SetFld("PTheoreticPrice",PTheoreticPrice)
	sendCalcOption._SetFld("CDelta",CDelta)
	sendCalcOption._SetFld("PDelta",PDelta)
	sendCalcOption._SetFld("CTheta",CTheta)
	sendCalcOption._SetFld("PTheta",PTheta)
	sendCalcOption._SetFld("CGamma",Gamma)
	sendCalcOption._SetFld("PGamma",Gamma)
	sendCalcOption._SetFld("CGamma1",Gamma1)
	sendCalcOption._SetFld("PGamma1",Gamma1)
	sendCalcOption._SetFld("CVega",Vega)
	sendCalcOption._SetFld("PVega",Vega)
	sendCalcOption._SetFld("CRho",CRho)
	sendCalcOption._SetFld("PRho",PRho)
	_SendToClients(sendCalcOption)
_End

--隐含波动率计算
_OnEventDefined(CalcOptionVolatilityIn event)
	local UnderlyingPrice = event._GetFld("BUnderlyingPrice")
	local ExercisePrice = event._GetFld("BExercisePrice")
	local Time = event._GetFld("BDaysUntilExpiration")
	local InterestRates = event._GetFld("BInterestRates")
	local DividendYield = event._GetFld("BDividendYield")
	local Rounding = event._GetFld("BRounding")
	local CallPut = event._GetFld("CallPut")	--看涨、看跌
	local TheoreticPrice = event._GetFld("BTheoreticPrice")	--市场价
	local log = sys_format("CalcOptionVolatilityIn:UnderlyingPrice=%s,ExercisePrice=%s,Time=%s,InterestRates=%s,DividendYield=%s,Rounding=%s,CallPut=%s,TheoreticPrice=%s",UnderlyingPrice,ExercisePrice,Time,InterestRates,DividendYield,Rounding,CallPut,TheoreticPrice)
	_WriteAplLog(log)
	local volatility = "" --隐含波动率
	if CallPut == "看涨" then
		volatility = calImpliedCallVolatity(UnderlyingPrice,ExercisePrice,Time,DividendYield,TheoreticPrice,InterestRates,Rounding)
	elseif CallPut =="看跌" then
		CallPut = calImpliedPutVolatity(UnderlyingPrice,ExercisePrice,Time,DividendYield,TheoreticPrice,InterestRates,Rounding)
	end
	log = sys_format("SendToClients Volatility=%s",volatility)
	_WriteAplLog(log)
	local DTSEvent sendVolatility = _CreateEventObject("CalcOptionVolatilityOut")
	sendVolatility._SetFld("Volatility",volatility)
	_SendToClients(sendVolatility)
_End

-------------------------------------套利逻辑---------------------------------------------
--初始化套利关系表
initializeArbRelation()
function initializeArbRelation()
	initializePJArb()
	initializeJCArb()
	initializeTXArb()
	initializeXXArb()
	initializeRLArb()
end
--初始化平价套利组合
function initializePJArb()
	_WriteAplLog("initializePJArb")
	for issueCode,value in pairs(gtOptionInfo) do
		local productCode = _PosIssueProductCodeTable[issueCode] or ""
		local callPut = value.CallPut
		if productCode == "32" and callPut == "C" then
			local expirationDate = value.ExpirationDate
			local strikePrice = (value.StrikePrice).toString()
			local date = sys_sub(expirationDate,3,6)
			local putIssueCode = "IO"..date.."-P-"..strikePrice
			--local underlyingIssueCode = value.Underlying
			local underlyingIssueCode = "IF"..date
			if gtOptionInfo[putIssueCode] and gtIFIssueInfo[underlyingIssueCode] then
				local relation1 = "PJ"..date.."CP"..strikePrice
				local relation2 = "PJ"..date.."PC"..strikePrice
				--_WriteAplLog(relation1)
				--_WriteAplLog(relation2)
				if not gtArbitrageRelation["PJ"][relation1] then
					gtArbitrageRelation["PJ"][relation1] = {}
					local temptable = {}
					temptable.IssueCode1 = issueCode
					temptable.Coefficient1 = "3"
					temptable.IssueCode2 =putIssueCode
					temptable.Coefficient2 = "-3"
					temptable.IssueCode3 = underlyingIssueCode
					temptable.Coefficient3 = "-1"
					temptable.IssueCode4 = "-"
					temptable.Coefficient4 = "-"
					temptable.ExpirationDate = expirationDate
					temptable.RemainDay = value.RemainDay
					temptable.Spread = "-"
					temptable.Yield = "-"
					temptable.YearYield = "-"
					temptable.BuySell1 = "卖"
					temptable.BuySell2 = "买"
					temptable.BuySell3 = "买"
					temptable.BuySell4 = "-"
					temptable.ArbitrageType = "PJ"
					temptable.ArbitrageName = "平价关系"
					temptable.ReseverString = "CP"
					gtArbitrageRelation["PJ"][relation1] = temptable
				end
				if not gtArbitrageRelation["PJ"][relation2] then
					gtArbitrageRelation["PJ"][relation2] = {}
					local temptable = {}
					temptable.IssueCode1 = putIssueCode
					temptable.Coefficient1 = "3"
					temptable.IssueCode2 = issueCode
					temptable.Coefficient2 = "-3"
					temptable.IssueCode3 = underlyingIssueCode
					temptable.Coefficient3 = "-1"
					temptable.IssueCode4 = "-"
					temptable.Coefficient4 = "-"
					temptable.ExpirationDate = expirationDate
					temptable.RemainDay = value.RemainDay
					temptable.Spread = "-"
					temptable.Yield = "-"
					temptable.YearYield = "-"
					temptable.BuySell1 = "卖"
					temptable.BuySell2 = "买"
					temptable.BuySell3 = "买"
					temptable.BuySell4 = "-"
					temptable.ArbitrageType = "PJ"
					temptable.ArbitrageName = "平价关系"
					temptable.ReseverString = "PC"
					gtArbitrageRelation["PJ"][relation2] = temptable
				end
			end
		end
	end
end
--初始化价差套利组合,简单价差、复杂价差关系
function initializeJCArb()
	_WriteAplLog("initializeJCArb")
	local tmpOptionInfoTable = {}
	for issueCode,value in pairs(gtOptionInfo) do
		local productCode = _PosIssueProductCodeTable[issueCode] or ""
		if productCode == "32" then	
			local underlyingIssueCode = value.Underlying
			local expirationDate = value.ExpirationDate
			local callPut = value.CallPut
			local tmKey = underlyingIssueCode .. expirationDate .. callPut
			local tmpValueTable = value
			tmpValueTable.IssueCode = issueCode
			if not tmpOptionInfoTable[tmKey]  then
				tmpOptionInfoTable[tmKey] = {}
				sys_insert(tmpOptionInfoTable[tmKey],tmpValueTable)
			else
				sys_insert(tmpOptionInfoTable[tmKey],tmpValueTable)
			end
		end
	end
	for key,valueTable in pairs(tmpOptionInfoTable) do
		for i,value1 in pairs(valueTable)do
			local issueCode1 = value1.IssueCode
			local expirationDate1 = value1.ExpirationDate
			local callPut1 = value1.CallPut
			local strikePrice1 = (value1.StrikePrice).toString()
			for j,value2 in pairs(valueTable)do
				local issueCode2 = value2.IssueCode
				local strikePrice2 = (value2.StrikePrice).toString()
				local callPut2 = value2.CallPut
				if issueCode1 ~= issueCode2 and strikePrice1 < strikePrice2 and callPut1 == callPut2 then
					local expirationDate2 = value2.ExpirationDate
					local underlyingIssueCode = value2.Underlying
					local date = sys_sub(expirationDate1,3,6)
					--简单价差关系
					local relation1 = "JD"..date..callPut1..strikePrice1..callPut2..strikePrice2
					--_WriteAplLog(relation1)
					--复杂价差关系
					local relation2 = "FZ"..date..callPut1..strikePrice1..callPut2..strikePrice2
					--_WriteAplLog(relation2)
					local temptable1 = {}
					local temptable2 = {}
					if callPut1 == "C" then
						--简单价差关系
						temptable1.IssueCode1 = issueCode2
						temptable1.IssueCode2 = issueCode1
						temptable1.IssueCode3 = "-"
						temptable1.IssueCode4 = "-"
						temptable1.Coefficient1 = "1"
						temptable1.Coefficient2 = "-1"
						temptable1.Coefficient3 = "-"
						temptable1.Coefficient4 = "-"
						temptable1.ExpirationDate = expirationDate1
						temptable1.RemainDay = value1.RemainDay
						temptable1.Spread = "-"
						temptable1.Yield = "-"
						temptable1.YearYield = "-"
						temptable1.BuySell1 = "卖"
						temptable1.BuySell2 = "买"
						temptable1.BuySell3 = "-"
						temptable1.BuySell4 = "-"
						temptable1.ReseverString = "CC"
						temptable1.ArbitrageType = "JD"
						temptable1.ArbitrageName = "价差关系(简单)"
						gtArbitrageRelation["JD"][relation1] = temptable1
						--复杂价差关系
						temptable2.IssueCode1 = issueCode1
						temptable2.IssueCode2 = issueCode2
						temptable2.IssueCode3 = "-"
						temptable2.IssueCode4 = "-"
						temptable2.Coefficient1 = "1"
						temptable2.Coefficient2 = "-1"
						temptable2.Coefficient3 = "-"
						temptable2.Coefficient4 = "-"
						temptable2.ExpirationDate = expirationDate1
						temptable2.RemainDay = value1.RemainDay
						temptable2.Spread = "-"
						temptable2.Yield = "-"
						temptable2.YearYield = "-"
						temptable2.BuySell1 = "卖"
						temptable2.BuySell2 = "买"
						temptable2.BuySell3 = "-"
						temptable2.BuySell4 = "-"
						temptable2.ReseverString = "CC"
						temptable2.ArbitrageType = "FZ"
						temptable2.ArbitrageName = "价差关系(复杂)"
						gtArbitrageRelation["FZ"][relation2] = temptable2
					elseif callPut1 == "P" then
						--简单价差关系
						temptable1.IssueCode1 = issueCode1
						temptable1.IssueCode2 = issueCode2
						temptable1.IssueCode3 = "-"
						temptable1.IssueCode4 = "-"
						temptable1.Coefficient1 = "1"
						temptable1.Coefficient2 = "-1"
						temptable1.Coefficient3 = "-"
						temptable1.Coefficient4 = "-"
						temptable1.ExpirationDate = expirationDate1
						temptable1.RemainDay = value1.RemainDay
						temptable1.Spread = "-"
						temptable1.Yield = "-"
						temptable1.YearYield = "-"
						temptable1.BuySell1 = "卖"
						temptable1.BuySell2 = "买"
						temptable1.BuySell3 = "-"
						temptable1.BuySell4 = "-"
						temptable1.ReseverString = "PP"
						temptable1.ArbitrageType = "JD"
						temptable1.ArbitrageName = "价差关系(简单)"
						gtArbitrageRelation["JD"][relation1] = temptable1
						--复杂价差关系
						temptable2.IssueCode1 = issueCode2
						temptable2.IssueCode2 = issueCode1
						temptable2.IssueCode3 = "-"
						temptable2.IssueCode4 = "-"
						temptable2.Coefficient1 = "1"
						temptable2.Coefficient2 = "-1"
						temptable2.Coefficient3 = "-"
						temptable2.Coefficient4 = "-"
						temptable2.ExpirationDate = expirationDate1
						temptable2.RemainDay = value1.RemainDay
						temptable2.Spread = "-"
						temptable2.Yield = "-"
						temptable2.YearYield = "-"
						temptable2.BuySell1 = "卖"
						temptable2.BuySell2 = "买"
						temptable2.BuySell3 = "-"
						temptable2.BuySell4 = "-"
						temptable2.ReseverString = "PP"
						temptable2.ArbitrageType = "FZ"
						temptable2.ArbitrageName = "价差关系(复杂)"
						gtArbitrageRelation["FZ"][relation2] = temptable2
					end		
				end
			end
		end
	end
end
--初始化凸性套利组合
function initializeTXArb()
	_WriteAplLog("initializeTXArb")
	local tmpOptionInfoTable = {};
	for issueCode,value in pairs(gtOptionInfo) do
		local productCode = _PosIssueProductCodeTable[issueCode] or ""
		if productCode == "32" then	
			local underlyingIssueCode = value.Underlying
			local expirationDate = value.ExpirationDate
			local callPut = value.CallPut
			local tmKey = underlyingIssueCode .. expirationDate .. callPut
			local tmpValueTable = value
			tmpValueTable.IssueCode = issueCode
			if not tmpOptionInfoTable[tmKey]  then
				tmpOptionInfoTable[tmKey] = {};
				sys_insert(tmpOptionInfoTable[tmKey],tmpValueTable)
			else
				sys_insert(tmpOptionInfoTable[tmKey],tmpValueTable)
			end
		end
	end

	for i,valueTable in pairs(tmpOptionInfoTable) do
		for key1,value1 in pairs(valueTable) do
			local issueCode1 = value1.IssueCode
			local expirationDate1 = value1.ExpirationDate
			local callPut1 = value1.CallPut
			local strikePrice1 = (value1.StrikePrice)
			for key2,value2 in pairs(valueTable) do
				local issueCode2 = value2.IssueCode
				local expirationDate2 = value2.ExpirationDate;
				local callPut2 = value2.CallPut
				local strikePrice2 = (value2.StrikePrice)
				if issueCode1 ~= issueCode2 then
					for key3,value3 in pairs(valueTable) do
						local issueCode3 = value3.IssueCode
						local expirationDate3 = value3.ExpirationDate
						local callPut3 = value3.CallPut
						local strikePrice3 = (value3.StrikePrice)
						local underlying3 = value3.Underlying
						local minStrikePrice = sys_min(sys_min(strikePrice1,strikePrice2),strikePrice3)
						--minStrikePrice = sys_format("%.3f",minStrikePrice)
						local maxStrikePrice = sys_max(sys_max(strikePrice1,strikePrice2),strikePrice3)
						--maxStrikePrice = sys_format("%.3f",maxStrikePrice)
						--local log = sys_format("issueCode1[%s],issueCode2[%s],issueCode3[%s],strikePrice1[%s],strikePrice2[%s],strikePrice3[%s],minStrikePrice[%s],maxStrikePrice[%s]",
						--issueCode1,issueCode2,issueCode3,strikePrice1,strikePrice2,strikePrice3,minStrikePrice,maxStrikePrice)
						--_WriteAplLog(log)
						if minStrikePrice == strikePrice1 and maxStrikePrice == strikePrice3 and issueCode1 ~= issueCode3 and issueCode2 ~= issueCode3 then
							local relation ="TX" .. sys_sub(expirationDate1, 3,6) .. callPut1 .. strikePrice1.toString() .. callPut2 .. strikePrice2.toString() .. callPut3 .. strikePrice3.toString()
							--_WriteAplLog(relation)
							local K1 = strikePrice2.getNumberValue()
							local K2 = strikePrice1.getNumberValue()
							local K3 = strikePrice3.getNumberValue()
							local commonDivisor = getCommonDivisor(K3 - K1,K3 - K2,K2 - K1)
							--local log = sys_format("CommonDivisor:K3 - K1[%s],K3 - K2[%s],K2 - K1[%s],commonDivisor[%s]",K3 - K1,K3 - K2,K2 - K1,commonDivisor)
							--_WriteAplLog(log)
							gtArbitrageRelation["TX"][relation] = {}
							local temptable = {}
							temptable.IssueCode1 = issueCode1
							temptable.IssueCode2 = issueCode2
							temptable.IssueCode3 = issueCode3
							temptable.IssueCode4 = "-"
							temptable.Coefficient1 = sys_format("%d",1 * (K3 - K1) / commonDivisor)
							temptable.Coefficient2 = sys_format("%d",-1 * (K3 - K2) / commonDivisor)
							temptable.Coefficient3 = sys_format("%d",-1 * (K2 - K1) / commonDivisor)
							temptable.Coefficient4 = "-"
							temptable.ExpirationDate = expirationDate1
							temptable.RemainDay = value1.RemainDay
							temptable.Spread = "-"
							temptable.Yield = "-"
							temptable.YearYield = "-"
							temptable.BuySell1 = "卖"
							temptable.BuySell2 = "买"
							temptable.BuySell3 = "买"
							temptable.BuySell4 = "-"
							temptable.ArbitrageType = "TX"
							temptable.ArbitrageName = "凸性关系"
							temptable.ReseverString = ""
							gtArbitrageRelation["TX"][relation] = temptable
						end
					end
				end
			end
		end
	end
end

--取最大公约数
function getCommonDivisor(a,b,c)
	--股指期权行权价差不会出现小数
	--local tmpa = sys_format("%d",1000*a);
	--local tmpb = sys_format("%d",1000*b);
	--local tmpc = sys_format("%d",1000*c);
	local tmpa = sys_abs(sys_format("%d",a));
	local tmpb = sys_abs(sys_format("%d",b));
	local tmpc = sys_abs(sys_format("%d",c));
	local result = 1;
	local min = sys_min(tmpa,tmpb,tmpc);
	for i = min,1,-1 do
		if (tmpa%i == 0 and tmpb%i == 0 and tmpc%i == 0) then
			result = i;
			break;
		end
	end
	--local log =  sys_format("getCommonDivisor,tmpa[%s],tmpb[%s],tmpc[%s],result[%s],min[%s]",tmpa,tmpb,tmpc,result,min);
	--_WriteAplLog(log);
	--return result/1000;
	return result
end

--初始化箱型套利组合
function initializeXXArb()
	_WriteAplLog("initializeXXArb")
	local tmpOptionInfoTable = {};
	for issueCode,value in pairs(gtOptionInfo) do
		local productcode = _PosIssueProductCodeTable[issueCode] or ""
		if productcode == "32" then
			local underlyingIssueCode = value.Underlying
			local expirationDate = value.ExpirationDate
			local callPut = value.CallPut;
			local tmKey = underlyingIssueCode .. expirationDate;
			local tmpValueTable = value;
			tmpValueTable.IssueCode = issueCode;
			if not tmpOptionInfoTable[tmKey]  then
				tmpOptionInfoTable[tmKey] = {};
				sys_insert(tmpOptionInfoTable[tmKey],tmpValueTable);
			else
				sys_insert(tmpOptionInfoTable[tmKey],tmpValueTable);
			end
		end
	end

	for i,valueTable in pairs(tmpOptionInfoTable) do
		for key1,value1 in pairs(valueTable) do
			local issueCode1 = value1.IssueCode;
			local expirationDate1 = value1.ExpirationDate;
			local callPut1 = value1.CallPut;
			local strikePrice1 = (value1.StrikePrice).toString();
			for key2,value2 in pairs(valueTable) do
				local issueCode2 = value2.IssueCode;
				local expirationDate2 = value2.ExpirationDate;
				local callPut2 = value2.CallPut;
				local strikePrice2 = (value2.StrikePrice).toString();
				for key3,value3 in pairs(valueTable) do
					local issueCode3 = value3.IssueCode;
					local expirationDate3 = value3.ExpirationDate;
					local callPut3 = value3.CallPut;
					local strikePrice3 = (value3.StrikePrice).toString();
					for key4,value4 in pairs(valueTable) do
						local issueCode4 = value4.IssueCode;
						local expirationDate4 = value4.ExpirationDate;
						local callPut4 = value4.CallPut;
						local strikePrice4 = (value4.StrikePrice).toString();
						local underlying4 = value4.Underlying;
						--local log = sys_format("initializeXXArb:IssueCode1=%s,IssueCode2=%s,IssueCode3=%s,IssueCode4=%s,callPut1=%s,callPut2=%s,callPut3=%s,callPut4=%s,strikePrice1=%s,strikePrice2 = %s,strikePrice3=%s,strikePrice4=%s",issueCode1,issueCode2,issueCode3,issueCode4,callPut1,callPut2,callPut3,callPut4,strikePrice1,strikePrice2,strikePrice3,strikePrice4)
						--_WriteAplLog(log)
						if (callPut1 == callPut2 and callPut3 == callPut4 and callPut2 ~= callPut3) then
							if(issueCode1 ~= issueCode2 and issueCode1 ~= issueCode3 and issueCode1 ~= issueCode4 and issueCode2 ~= issueCode3 and issueCode2 ~= issueCode4 and issueCode3 ~= issueCode4) then
								if(strikePrice1.getNumberValue() == strikePrice4.getNumberValue() and strikePrice2.getNumberValue() == strikePrice3.getNumberValue() and strikePrice1.getNumberValue() < strikePrice2.getNumberValue()) then
									local relation = "XX" .. sys_sub(expirationDate1, 3,6) .. callPut1 .. callPut4 .. strikePrice1.toString().. callPut2 .. callPut3 .. strikePrice3.toString();
									--local log = sys_format("relation[%s],underlying4[%s],expirationDate1[%s],issueCode1[%s],callPut1[%s],issueCode2[%s],callPut2[%s],issueCode3[%s],callPut3[%s],issueCode4[%s],callPut4[%s],strikePrice1[%s],strikePrice2[%s],strikePrice3[%s],strikePrice4[%s]",relation,underlying4,expirationDate1,issueCode1,callPut1,issueCode2,callPut2,issueCode3,callPut3,issueCode4,callPut4,strikePrice1,strikePrice2,strikePrice3,strikePrice4);
									--_WriteAplLog(log);
									gtArbitrageRelation["XX"][relation] = {}
									local temptable = {}
									temptable.IssueCode1 = issueCode1
									temptable.IssueCode2 = issueCode2
									temptable.IssueCode3 = issueCode3
									temptable.IssueCode4 = issueCode4
									temptable.Coefficient1 = "1"
									temptable.Coefficient2 = "-1"
									temptable.Coefficient3 = "1"
									temptable.Coefficient4 = "-1"
									temptable.ExpirationDate = expirationDate1
									temptable.RemainDay = value1.RemainDay
									temptable.Spread = "-"
									temptable.Yield = "-"
									temptable.YearYield = "-"
									temptable.BuySell1 = "卖"
									temptable.BuySell2 = "买"
									temptable.BuySell3 = "卖"
									temptable.BuySell4 = "买"
									temptable.ArbitrageType = "XX"
									temptable.ArbitrageName = "箱型套利"
									temptable.ReseverString = callPut1 .. callPut3
									gtArbitrageRelation["XX"][relation] = temptable
								end
							end
						end
					end
				end
			end
		end
	end
end
--初始化日历套利组合
function initializeRLArb()
	_WriteAplLog("initializeRLArb")
	for issueCode1,value1 in pairs(gtOptionInfo) do
		local expirationDate1 = value1.ExpirationDate;
		local callPut1 = value1.CallPut;
		local strikePrice1 = (value1.StrikePrice).toString();
		local underlying1 = value1.Underlying;
		for issueCode2,value2 in pairs(gtOptionInfo) do
			local expirationDate2 = value2.ExpirationDate;
			local callPut2 = value2.CallPut;
			local strikePrice2 = (value2.StrikePrice).toString();
			local underlying2 = value2.Underlying;
			if strikePrice1 == strikePrice2 and callPut1 == callPut2 and underlying1 == underlying2 and issueCode1 ~= issueCode2 and expirationDate1.getNumberValue() < expirationDate2.getNumberValue() then
				local relation = "RL"..sys_sub(expirationDate1, 3,6)..sys_sub(expirationDate2, 3,6)..callPut1..strikePrice1
				--_WriteAplLog(relation)
				gtArbitrageRelation["RL"][relation] = {}
				local temptable = {}
				temptable.IssueCode1 = issueCode1
				temptable.IssueCode2 = issueCode2
				temptable.IssueCode3 = "-"
				temptable.IssueCode4 = "-"
				temptable.Coefficient1 = "1"
				temptable.Coefficient2 = "-1"
				temptable.Coefficient3 = "-"
				temptable.Coefficient4 = "-"
				temptable.ExpirationDate = expirationDate1
				local remaindDay1 = value1.RemainDay
				local remaindDay2 = value2.RemainDay
				temptable.RemainDay = sys_min(remaindDay1,remaindDay2)
				temptable.Spread = "-"
				temptable.Yield = "-"
				temptable.YearYield = "-"
				temptable.BuySell1 = "卖"
				temptable.BuySell2 = "买"
				temptable.BuySell3 = "-"
				temptable.BuySell4 = "-"
				temptable.ArbitrageType = "RL"
				temptable.ArbitrageName = "日历关系"
				temptable.ReseverString = callPut1
				gtArbitrageRelation["RL"][relation] = temptable
			end
		end
	end
end
--选择套利方式
_OnEventDefined(SelectArbitrageType event)
	local type = event._GetFld("ArbitrageType")
	gCurrentArbType = type
	local log = sys_format("SelectArbitrageType:gCurrentArbType=%s",gCurrentArbType)
	_WriteAplLog(log)
	if gCurrentArbType ~="" and gtArbitrageRelation[gCurrentArbType] then 
		refreshArbInfo("",gCurrentArbType)
		for relationID,value in pairs(gtArbitrageRelation[gCurrentArbType])do
			ShowArbRelationInfo(gCurrentArbType,relationID,value)
		end
	end
_End
--发送套利组合详情
function ShowArbRelationInfo(arbitrageType,relationID,value)
	local DTSEvent arbInfo = _CreateEventObject("ArbitrageInfo")
	local issueCode1 = value.IssueCode1
	local issueCode2 = value.IssueCode2
	local issueCode3 = value.IssueCode3
	local issueCode4 = value.IssueCode4
	local coefficient1 = value.Coefficient1
	local coefficient2 = value.Coefficient2
	local coefficient3 = value.Coefficient3
	local coefficient4 = value.Coefficient4
	local buySell1 = value.BuySell1
	local buySell2 = value.BuySell2
	local buySell3 = value.BuySell3
	local buySell4 = value.BuySell4
	local expirationDate = value.ExpirationDate
	local remainDay = value.RemainDay
	local spread = value.Spread
	local yield = value.Yield
	if yield ~= "-" then
		yield = sys_format("%.2f",yield*100)
	end
	local yearYield = value.YearYield
	if yearYield ~= "-" then
		yearYield = sys_format("%.2f",yearYield*100)
	end
	local arbitrageType = value.ArbitrageType
	
	arbInfo._SetFld("ArbitrageID",relationID)
	arbInfo._SetFld("IssueCode1",issueCode1)
	arbInfo._SetFld("IssueCode2",issueCode2)
	arbInfo._SetFld("IssueCode3",issueCode3)
	arbInfo._SetFld("IssueCode4",issueCode4)
	arbInfo._SetFld("Coefficient1",coefficient1)
	arbInfo._SetFld("Coefficient2",coefficient2)
	arbInfo._SetFld("Coefficient3",coefficient3)
	arbInfo._SetFld("Coefficient4",coefficient4)
	arbInfo._SetFld("BuySell1",buySell1)
	arbInfo._SetFld("BuySell2",buySell2)
	arbInfo._SetFld("BuySell3",buySell3)
	arbInfo._SetFld("BuySell4",buySell4)
	arbInfo._SetFld("Spread",spread)
	arbInfo._SetFld("Yield",yield)
	arbInfo._SetFld("YearYield",yearYield)
	arbInfo._SetFld("ArbitrageType",arbitrageType)
	arbInfo._SetFld("RemainDay",remainDay)
	_SendToClients(arbInfo)
end
--套利组合信息刷新
function refreshArbInfo(issueCode,arbitrageType)
	--只实时计算当前界面选中的套利关系组合
	if gtArbitrageRelation[arbitrageType] and arbitrageType ~= "" then	
		for relationID,value in pairs(gtArbitrageRelation[arbitrageType])do
			local issueCode1 = value.IssueCode1
			local issueCode2 = value.IssueCode2
			local issueCode3 = value.IssueCode3
			local issueCode4 = value.IssueCode4
			if issueCode == "" or issueCode == issueCode1 or issueCode == issueCode2 or issueCode == issueCode3 or issueCode == issueCode4 then
				local coefficient1 = value.Coefficient1
				local coefficient2 = value.Coefficient2
				local coefficient3 = value.Coefficient3
				local coefficient4 = value.Coefficient4
				local buySell1 = value.BuySell1
				local buySell2 = value.BuySell2
				local buySell3 = value.BuySell3
				local buySell4 = value.BuySell4
				local expirationDate = value.ExpirationDate
				local remainDay = value.RemainDay
				remainDay = remainDay.getNumberValue()
				local spread = value.Spread
				local yield = value.Yield
				local yearYield = value.YearYield
				--local arbitrageType = value.ArbitrageType
				local reseverString = value.ReseverString
				local bidPrice1_1 = ""
				local askPrice1_1 = ""
				local bidPrice2_1 = ""
				local askPrice2_1 = ""
				local bidPrice3_1 = ""
				local askPrice3_1 = ""
				local bidPrice4_1 = ""
				local askPrice4_1 = ""
				local contractsize1 = 1
				local contractsize2 = 1
				local contractsize3 = 1
				local contractsize4 = 1
				if issueCode1 ~= "-" then
					if  gtIssuePriceInfoTable[issueCode1] then
						bidPrice1_1 = gtIssuePriceInfoTable[issueCode1].BidPrice1 or ""
						askPrice1_1 = gtIssuePriceInfoTable[issueCode1].AskPrice1 or ""
					end
					contractsize2 = _PosIssueContractSizeTable[issueCode1]
				end
				if issueCode2 ~= "-" then
					if gtIssuePriceInfoTable[issueCode2] then
						bidPrice2_1 = gtIssuePriceInfoTable[issueCode2].BidPrice1 or ""
						askPrice2_1 = gtIssuePriceInfoTable[issueCode2].AskPrice1 or ""
					end
					contractsize3 = _PosIssueContractSizeTable[issueCode2]
				end
				if issueCode3 ~= "-" then
					if gtIssuePriceInfoTable[issueCode3] then
						bidPrice3_1 = gtIssuePriceInfoTable[issueCode3].BidPrice1 or ""
						askPrice3_1 = gtIssuePriceInfoTable[issueCode3].AskPrice1 or ""
					end
					contractsize1 = _PosIssueContractSizeTable[issueCode3]
				end
				if issueCode4 ~= "-" then
					if gtIssuePriceInfoTable[issueCode4] then
						bidPrice4_1 = gtIssuePriceInfoTable[issueCode4].BidPrice1 or ""
						askPrice4_1 = gtIssuePriceInfoTable[issueCode4].AskPrice1 or ""
					end
					contractsize4 = _PosIssueContractSizeTable[issueCode4]
				end
			
				if arbitrageType =="PJ" then
					local strikePrice = (gtOptionInfo[issueCode1].StrikePrice).toString()
					if reseverString == "CP" then
						if bidPrice1_1~="" and askPrice2_1~="" and askPrice3_1~="" then
							spread = bidPrice1_1 - askPrice2_1 - askPrice3_1 + strikePrice
							local bail = _PosGetBail(gFutureAccountCode,issueCode3,"1","S")
							local amount = (bidPrice1_1*contractsize1*coefficient1)+(askPrice2_1*contractsize2*coefficient2)+(askPrice3_1*contractsize3*coefficient3*bail)
							if amount and amount ~= 0 then
								yield = spread/amount
								if remainDay ~= 0 then
									yearYield = yield*365/remainDay
								end
							end
						end
					elseif reseverString == "PC" then	--平价关系
						if bidPrice1_1 ~="" and askPrice2_1 ~="" and bidPrice3_1 ~="" then
							spread = bidPrice1_1 - askPrice2_1 + bidPrice3_1 - strikePrice
							local bail = _PosGetBail(gFutureAccountCode,issueCode3,"3","P")
							local amount = (bidPrice1_1*contractsize1*coefficient1)+(askPrice2_1*contractsize2*coefficient2)+(bidPrice3_1*contractsize3*coefficient3*bail)
							if amount and amount ~= 0 then
								yield = spread/amount
								if remainDay ~= 0 then
									yearYield = yield*365/remainDay
								end
							end
						end
					end
				elseif arbitrageType == "JD" then	--简单价差关系
					if bidPrice1_1 ~= "" and askPrice2_1 ~="" then
						spread = bidPrice1_1 - askPrice2_1
						local amount = (bidPrice1_1*contractsize1*coefficient1)+(askPrice2_1*contractsize2*coefficient2)
						if amount and amount ~= 0 then
							yield = spread/amount
							if remainDay ~= 0 then
								yearYield = yield*365/remainDay
							end
						end
					end
				elseif arbitrageType == "FZ" then	--复杂套利关系
					if gInterestRates ~="" then
						local strikePrice1 = (gtOptionInfo[issueCode1].StrikePrice).toString()
						local strikePrice2 = (gtOptionInfo[issueCode2].StrikePrice).toString()
						local y = (-1)*gInterestRates*remainDay/360
						local exercisePriceSpread = (strikePrice2 - strikePrice1)*sys_exp(y)
						if bidPrice1_1 ~="" and askPrice2_1 ~="" then
							spread = bidPrice1_1 - askPrice2_1 - exercisePriceSpread
							local amount = (bidPrice1_1*contractsize1*coefficient1)+(askPrice2_1*contractsize2*coefficient2)
							if amount and amount ~= 0 then
								yield = spread/amount
								if remainDay ~= 0 then
									yearYield = yield*365/remainDay
								end
							end
						end
					else
						_WriteAplLog("FZ复杂套利关系计算，无风险利率不存在")
					end
				elseif arbitrageType == "TX" then	--凸性关系
					local strikePrice1 = (gtOptionInfo[issueCode1].StrikePrice).toString()
					local strikePrice2 = (gtOptionInfo[issueCode2].StrikePrice).toString()
					local strikePrice3 = (gtOptionInfo[issueCode3].StrikePrice).toString()
					local lambda = (strikePrice3 - strikePrice2)/(strikePrice3 - strikePrice1)
					if bidPrice1_1 ~="" and askPrice2_1 ~= "" and askPrice3_1 ~= "" then
						spread = bidPrice1_1 - lambda*askPrice2_1 - (1-lambda)*askPrice3_1
						local amount = (bidPrice1_1*contractsize1*coefficient1)+(askPrice2_1*contractsize2*coefficient2)+(askPrice3_1*contractsize3*coefficient3)
						if amount and amount ~= 0 then
							yield = spread/amount
							if remainDay ~= 0 then
								yearYield = yield*365/remainDay
							end
						end
					end
				elseif arbitrageType == "XX" then
					local strikePrice1 = (gtOptionInfo[issueCode1].StrikePrice).toString()
					local strikePrice2 = (gtOptionInfo[issueCode2].StrikePrice).toString()
					if bidPrice1_1~="" and askPrice2_1~="" and bidPrice3_1~="" and askPrice4_1~="" then
						if reseverString == "CP" then
							spread = bidPrice1_1 - askPrice2_1 + bidPrice3_1 - askPrice4_1 - (strikePrice2 - strikePrice1)
						elseif reseverString == "PC" then
							spread = bidPrice1_1 - askPrice2_1 + bidPrice3_1 - askPrice4_1 + (strikePrice2 - strikePrice1)
						end
						if spread ~= "-" and gInterestRates ~="-" then
							local amount = (bidPrice1_1*contractsize1*coefficient1)+(askPrice2_1*contractsize2*coefficient2)+(bidPrice3_1*contractsize3*coefficient3)+(askPrice4_1*contractsize4*coefficient4)
							if amount and amount ~= 0 then
								local y = (-1)*gInterestRates*remainDay/365
								yield = (spread - (strikePrice2-strikePrice1)*sys_exp(y) - 1)/amount
								if remainDay ~= 0 then
									yearYield = yield*365/remainDay
								end
							end
						end
					end
				elseif arbitrageType == "RL" then
					if bidPrice1_1 ~= "" and askPrice2_1 ~= "" then
						spread = bidPrice1_1 - askPrice2_1
						local amount = (bidPrice1_1*contractsize1*coefficient1)+(askPrice2_1*contractsize2*coefficient2)
						if amount and amount ~= 0 then
							yield = spread/amount
							if remainDay ~= 0 then
								yearYield = yield*365/remainDay
							end
						end
					end
				end
				value.Spread = spread
				value.Yield = yield
				value.YearYield = yearYield
			end
		end
	end
end

--套利下单
_OnEventDefined(QuickArbOrder event)
	local arbitrageID = event._GetFld("ArbitrageID")	--套利关系ID
	local arbitrageType = event._GetFld("ArbitrageType")--套利方式：PJ,JD,FZ,TX,XX,RL
	local unit = event._GetFld("Quantity")	--组合份数
	local log = sys_format("QuickArbOrder:ArbitrageID=%s,ArbitrageType=%s,unit=%s",arbitrageID,arbitrageType,unit)
	_WriteAplLog(log)
	arbOrderReady(arbitrageType,arbitrageID,"",unit,0)
_End
function arbOrderReady(arbitrageType,arbitrageID,portID,unit,openClose)
	if gtArbitrageRelation[arbitrageType] then
		local relationTable = gtArbitrageRelation[arbitrageType][arbitrageID]
		if relationTable then
			local arbitrageName = relationTable.ArbitrageName
			local issueCode1 = relationTable.IssueCode1
			local issueCode2 = relationTable.IssueCode2
			local issueCode3 = relationTable.IssueCode3
			local issueCode4 = relationTable.IssueCode4
			local buySell1 = relationTable.BuySell1
			local buySell2 = relationTable.BuySell2
			local buySell3 = relationTable.BuySell3
			local buySell4 = relationTable.BuySell4
			local coefficient1 = relationTable.Coefficient1
			local coefficient2 = relationTable.Coefficient2
			local coefficient3 = relationTable.Coefficient3
			local coefficient4 = relationTable.Coefficient4
			--合约1
			local portID = createPortID("A",arbitrageType)
			if issueCode1 ~= "-" then
				if openClose ~= 0 then
					if buySell1 =="买" then
						buySell1 = "卖"
					elseif buySell1 == "卖" then
						buySell1 = "买"
					end
				end
				arbitrageOrder(arbitrageType,arbitrageName,portID,issueCode1,buySell1,coefficient1,unit,openClose)
			end
			if issueCode2 ~= "-" then
				if openClose ~= 0 then
					if buySell2 =="买" then
						buySell2 = "卖"
					elseif buySell2 == "卖" then
						buySell2 = "买"
					end
				end
				arbitrageOrder(arbitrageType,arbitrageName,portID,issueCode2,buySell2,coefficient2,unit,openClose)
			end
			if issueCode3 ~= "-" then
				if openClose ~= 0 then
					if buySell3 =="买" then
						buySell3 = "卖"
					elseif buySell3 == "卖" then
						buySell3 = "买"
					end
				end
				arbitrageOrder(arbitrageType,arbitrageName,portID,issueCode3,buySell3,coefficient3,unit,openClose)
			end
			if issueCode4 ~= "-" then
				if openClose ~= 0 then
					if buySell4 =="买" then
						buySell4 = "卖"
					elseif buySell4 == "卖" then
						buySell4 = "买"
					end
				end
				arbitrageOrder(arbitrageType,arbitrageName,portID,issueCode4,buySell4,coefficient4,unit,openClose)
			end
		else
			log = sys_format("下单失败,套利关系%s不存在！",arbitrageID)
			_WriteAplLog(log)
			sendLog(log)
		end
	else
		log = sys_format("下单失败,套利方式%s不存在！",arbitrageType)
		_WriteAplLog(log)
		sendLog(log)
	end
end
--套利下单
function arbitrageOrder(arbitrageType,arbitrageName,portID,issueCode,buySellFld,coefficient,unit,openClose)
	--local portID = ""
	local baSubID = ""
	local buySell = ""
	local price = 0
	local quantity = 0
	--if portID == "" then
		--portID = createPortID("A",arbitrageType)
	--end
	if buySellFld == "买" then
		buySell = "3"
		price = getOrderPrice(issueCode,buySell)
	elseif buySellFld == "卖" then
		buySell = "1"
		price = getOrderPrice(issueCode,buySell)
	end
	baSubID = buySell..portID
	quantity = unit*sys_abs(coefficient.getNumberValue())
	if price ~= 0 and quantity ~= 0 then
		local ret = PosSubmitSingleOrder(spFutureBAMapID,baSubID,issueCode,buySell,openClose,price,quantity,0,nil,"","P")
		if ret.Result then
			local log = sys_format("%s套利下单:%s %s %s手 %s开 ",arbitrageName,issueCode,price,quantity,buySellFld)
			_WriteAplLog(log)
			sendLog(log)
		else
			local log = sys_format("%s套利下单失败%s,原因:%s",arbitrageName,issueCode,ret.Reason)
			_WriteAplLog(log)
			sendLog(log)
		end
	elseif price == 0 then
		local log = sys_format("%s套利下单失败%s,价格%s无效,请检查是否有行情",arbitrageName,issueCode,price)
		_WriteAplLog(log)
		sendLog(log)
	elseif quantity == 0 then
		local log = sys_format("%s套利下单失败%s,数量%s无效",arbitrageName,issueCode,quantity)
		_WriteAplLog(log)
		sendLog(log)
	end
end
--取得委托价格
function getOrderPrice(IssueCode,BuySell)
	local price = 0
	if gtIssuePriceInfoTable[IssueCode] then
		if BuySell =="3" and gtIssuePriceInfoTable[IssueCode].AskPrice1 then
			price = gtIssuePriceInfoTable[IssueCode].AskPrice1
		elseif BuySell =="1" and gtIssuePriceInfoTable[IssueCode].BidPrice1 then
			price = gtIssuePriceInfoTable[IssueCode].BidPrice1
		end
	end
	return price
end



--单笔下单
_OnEventDefined(SingleOrder event)
	local orderType = event._GetFld("OrderType")
	local flag = event._GetFld("Flag")
	local issueCode = event._GetFld("IssueCode")
	local issueCode2 = event._GetFld("IssueCode2")
	local issueCode3 = event._GetFld("IssueCode3")
	local quantity = event._GetFld("Quantity")
	local quote = event._GetFld("Quote")
	local buySell = event._GetFld("BuySell")
	local openClose = event._GetFld("OpenClose")
	local Price = event._GetFld("Price")
	local log = sys_format("单笔下单,orderType[%s],flag[%s],issueCode[%s],issueCode2[%s],issueCode3[%s],quantity[%s],quote[%s],buySell[%s],openClose[%s],Price[%s]",orderType,flag,issueCode,issueCode2,issueCode3,quantity,quote,buySell,openClose,Price)
	_WriteAplLog(log)
	
	if orderType == "S" then			--投机
		if flag == "KD" then		--看多
			local baSubID = createPortID(orderType,flag)
			baSubID = buySell..baSubID
			local price
			if buySell == "1" then
				price = PosGetOrderPrice(issueCode,"BidPrice1",POS_ADJ_BY_BPS, 0)
			else
				price = PosGetOrderPrice(issueCode,"AskPrice1",POS_ADJ_BY_BPS, 0)
			end
			price = PosGetOrderPrice(issueCode,"AskPrice1",POS_ADJ_BY_BPS, 0)
			local ret = PosSubmitSingleOrder(spFutureBAMapID,baSubID,issueCode,buySell,0,price,quantity,0,nil,"","P")
			if not ret.Result then
				local log = sys_format("投机看多[%s]下单失败：原因[%s]",issueCode,ret.Reason)
				sendLog(log)
			else
				local log = sys_format("投机看多[%s]下单完成",issueCode)
				sendLog(log)				
			end
		elseif flag == "KK" then	--看空
			local baSubID = createPortID(orderType,flag)
			baSubID = buySell..baSubID
			local price
			if buySell == "1" then
				price = PosGetOrderPrice(issueCode,"BidPrice1",POS_ADJ_BY_BPS, 0)
			else
				price = PosGetOrderPrice(issueCode,"AskPrice1",POS_ADJ_BY_BPS, 0)
			end
			local ret = PosSubmitSingleOrder(spFutureBAMapID,baSubID,issueCode,buySell,0,price,quantity,0,nil,"","P")
			if not ret.Result then
				local log = sys_format("投机看空[%s]下单失败：原因[%s]",issueCode,ret.Reason)
				sendLog(log)
			else
				local log = sys_format("投机看空[%s]下单完成",issueCode)
				sendLog(log)
			end		
		elseif flag == "PP" then	--平盘
			local baSubID = createPortID(orderType,flag)
			local baSubID1 = "1"..baSubID
			local baSubID2 = "3"..baSubID
			local orderTable = {}
			
			local temp = {}
			local price = PosGetOrderPrice(issueCode,"AskPrice1",POS_ADJ_BY_BPS, 0)
			temp.IssueCode = issueCode
			temp.OpenClose = 0
			temp.BuySell = "3"
			temp.BAMapID = spFutureBAMapID
			temp.BASubID = baSubID2
			temp.Quantity = quantity
			temp.Price = price
			temp.CreRed = 0
			sys_insert(orderTable,temp)
			temp={}
			price = PosGetOrderPrice(issueCode3,"BidPrice1",POS_ADJ_BY_BPS, 0)
			temp.IssueCode = issueCode2
			temp.OpenClose = 0
			temp.BuySell = "1"
			temp.BAMapID = spFutureBAMapID
			temp.BASubID = baSubID1
			temp.Quantity = quantity*2
			temp.Price = price
			temp.CreRed = 0
			sys_insert(orderTable,temp)
			temp={}
			price = PosGetOrderPrice(issueCode2,"AskPrice1",POS_ADJ_BY_BPS, 0)
			temp.IssueCode = issueCode3
			temp.OpenClose = 0
			temp.BuySell = "3"
			temp.BAMapID = spFutureBAMapID
			temp.BASubID = baSubID2
			temp.Quantity = quantity
			temp.Price = price
			temp.CreRed = 0
			sys_insert(orderTable,temp)			
			
			local ret = PosSubmitBasketOrder(orderTable)
			if not ret.Result then
				local log = sys_format("投机平盘[%s] [%s] [%s]下单失败：原因[%s]",issueCode,issueCode2,issueCode3,ret.Reason)
				sendLog(log)
			else
				local log = sys_format("投机平盘[%s] [%s] [%s]下单完成",issueCode,issueCode2,issueCode3)
				sendLog(log)				
			end				
		end
	elseif orderType == "H" then		--套保
		if flag == "DT" then		--看多
			local baSubID = createPortID(orderType,flag)
			baSubID = "3"..baSubID
			local price = PosGetOrderPrice(issueCode,"AskPrice1",POS_ADJ_BY_BPS, 0)
			local ret = PosSubmitSingleOrder(spFutureBAMapID,baSubID,issueCode,"3",0,price,quantity,0,nil,"","P")
			if not ret.Result then
				local log = sys_format("套保看多[%s]下单失败：原因[%s]",issueCode,ret.Reason)
				sendLog(log)
			else
				local log = sys_format("套保看多[%s]下单完成",issueCode)
				sendLog(log)					
			end
		elseif flag == "KT" then	--看空
			local baSubID = createPortID(orderType,flag)
			baSubID = "1"..baSubID
			local price = PosGetOrderPrice(issueCode,"BidPrice1",POS_ADJ_BY_BPS, 0)
			local ret = PosSubmitSingleOrder(spFutureBAMapID,baSubID,issueCode,"1",0,price,quantity,0,nil,"","P")
			if not ret.Result then
				local log = sys_format("套保看空[%s]下单失败：原因[%s]",issueCode,ret.Reason)
				sendLog(log)
			else
				local log = sys_format("套保看空[%s]下单完成",issueCode)
				sendLog(log)				
			end	
		end
	elseif orderType == "M" then		--手动
		local baSubID = createPortID(orderType,flag)
		baSubID = buySell..baSubID
		--local price = PosGetOrderPrice(issueCode,"BidPrice1",POS_ADJ_BY_BPS, 0)
		local ret = PosSubmitSingleOrder(spFutureBAMapID,baSubID,issueCode,buySell,openClose,Price,quantity,0,nil)
		if not ret.Result then
			local log = sys_format("手动交易[%s]下单失败：原因[%s]",issueCode,ret.Reason)
			sendLog(log)
		end			
		
	end
	
	
_End


--生成条件单
_OnEventDefined(CreateArbCondition event)
	local arbitrageID = event._GetFld("ArbitrageID")	--套利关系ID
	local arbitrageType = event._GetFld("ArbitrageType")--套利方式：PJ,JD,FZ,TX,XX,RL
	local issueCode1 = event._GetFld("IssueCode1")
	local issueCode2 = event._GetFld("IssueCode2")
	local issueCode3 = event._GetFld("IssueCode3")
	local issueCode4 = event._GetFld("IssueCode4")
	local unit = event._GetFld("Quantity")	--组合份数
	local openFlag = event._GetFld("OpenFlag")
	local openSpread = event._GetFld("OpenSpread")
	local closeFlag = event._GetFld("CloseFlag")
	local closeSpread = event._GetFld("CloseSpread")
	local log = sys_format("CreateArbCondition:[%s],unit=%s,openFlag=%s,openSpread=%s,closeFlag=%s,closeSpread=%s",arbitrageID,unit,openFlag,openSpread,closeFlag,closeSpread)
	_WriteAplLog(log)
	if gtArbitrageRelation[arbitrageType] then
		local relationTable = gtArbitrageRelation[arbitrageType][arbitrageID]
		if relationTable then
			local arbitrageName = relationTable.ArbitrageName
			local spread = relationTable.Spread
			local arbConditionNo = createPortID("A",arbitrageType)
			if not gtArbitrageConditions[arbitrageID] then
				gtArbitrageConditions[arbitrageID] = {}
			end
			if not gtArbitrageConditions[arbitrageID][arbConditionNo] then
				gtArbitrageConditions[arbitrageID][arbConditionNo] = {}
			end
			local tempTable = {}
			tempTable.Selected = "0"
			tempTable.ArbitrageType = arbitrageType
			tempTable.OpenCompare = openFlag
			tempTable.OpenThreshold = openSpread
			tempTable.ColseCompare = closeFlag
			tempTable.CloseThreshold = closeSpread
			tempTable.OrderUnit = unit
			tempTable.ConditionStatus = "未执行"
			tempTable.OpenFld = "未开" --开仓标志 未开，已开
			tempTable.IssueCode1 = issueCode1
			tempTable.IssueCode2 = issueCode2
			tempTable.IssueCode3 = issueCode3
			tempTable.IssueCode4 = issueCode4
			tempTable.Flag = "1"
			gtArbitrageConditions[arbitrageID][arbConditionNo] = tempTable
			local log =sys_format("套利条件单%s生成成功！",arbConditionNo)
			_WriteAplLog(log)
			sendLog(log)
			--发送界面
			sendArbCondition(arbitrageID,arbConditionNo)
		else
			local log = sys_format("套利关系rbitrageID=%s不存在",arbitrageID)
			_WriteAplLog(log)
		end
	else
		local log = sys_format("套利方式arbitrageType=%s不存在",arbitrageType)
		_WriteAplLog(log)
	end
_End

--发送条件单
function sendArbCondition(arbitrageID,arbConditionNo)
	if gtArbitrageConditions[arbitrageID] then
		if gtArbitrageConditions[arbitrageID][arbConditionNo] then 
			local tempTable = gtArbitrageConditions[arbitrageID][arbConditionNo]
			local selected = tempTable.Selected 
			local openFlag = tempTable.OpenCompare
			local openSpread = tempTable.OpenThreshold 
			local closeFlag = tempTable.ColseCompare 
			local closeSpread = tempTable.CloseThreshold 
			local unit = tempTable.OrderUnit
			local conditionStatus = tempTable.ConditionStatus 
			local openFld =  tempTable.OpenFld
			local issueCode1 = tempTable.IssueCode1 
			local issueCode2 = tempTable.IssueCode2 
			local issueCode3 = tempTable.IssueCode3 
			local issueCode4 = tempTable.IssueCode4
			local arbitrageType = tempTable.ArbitrageType
			local flag = tempTable.Flag
			local spread = "-"
			if gtArbitrageRelation[arbitrageType] then
				if gtArbitrageRelation[arbitrageType][arbitrageID] then
					spread = gtArbitrageRelation[arbitrageType][arbitrageID].Spread
				end
			end
			local DTSEvent conditions = _CreateEventObject("ArbConditionsEvent")
			conditions._SetFld("Selected",selected)
			conditions._SetFld("ArbConditionNo",arbConditionNo)
			conditions._SetFld("ArbitrageID",arbitrageID)
			conditions._SetFld("Spread",spread)
			conditions._SetFld("OpenCompare",openFlag)
			conditions._SetFld("OpenThreshold",openSpread)
			conditions._SetFld("CloseCompare",closeFlag)
			conditions._SetFld("CloseThreshold",closeSpread)
			conditions._SetFld("OrderUnit",unit)
			conditions._SetFld("IssueCode1",issueCode1)
			conditions._SetFld("IssueCode2",issueCode2)
			conditions._SetFld("IssueCode3",issueCode3)
			conditions._SetFld("IssueCode4",issueCode4)
			conditions._SetFld("ConditionStatus",conditionStatus)
			conditions._SetFld("OpenFld",openFld)
			conditions._SetFld("Flag",flag)
			_SendToClients(conditions)
		end
	end
end

--条件单选中
_OnEventDefined(SelectArbConditions event) 
	local selected = event._GetFld("Selected")
	local arbConditionNo = event._GetFld("ArbConditionNo")
	local arbitrageID = event._GetFld("ArbitrageID")
	local log = sys_format("SelectArbConditions:ArbitrageID=%s,ArbConditionNo=%s,Selected=%s",arbitrageID,arbConditionNo,selected)
	_WriteAplLog(log)
	if gtArbitrageConditions[arbitrageID] then
		if gtArbitrageConditions[arbitrageID][arbConditionNo] then 
			gtArbitrageConditions[arbitrageID][arbConditionNo].Selected = selected
		end
	end
_End

--启动条件单
_OnEventDefined(StartArbConditions event)
	_WriteAplLog("StartArbConditions")
	for arbitrageID,valueTable in pairs(gtArbitrageConditions)do
		for arbConditionNo,value in pairs(valueTable)do 
			local selected = value.Selected
			local conditionStatus = value.ConditionStatus
			local log = sys_format("StartArbConditions:arbitrageID=%s,arbConditionNo=%s,selected=%s,conditionStatus=%s",arbitrageID,arbConditionNo,selected,conditionStatus)
			_WriteAplLog(log)
			if selected == "1" and conditionStatus == "未执行" then
				gtStartArbConditios[arbConditionNo] = arbitrageID
				value.ConditionStatus = "执行中"
				local log = sys_format("套利条件单:%s已启动",arbConditionNo)
				_WriteAplLog(log)
				sendLog(log)
				--发送界面
				sendArbCondition(arbitrageID,arbConditionNo)
				ArbConditionMonitor(arbConditionNo,arbitrageID)
			end
		end
	end
_End
--停止条件单
_OnEventDefined(StopArbConditions event)
	_WriteAplLog("StopArbConditions")
	for arbitrageID,valueTable in pairs(gtArbitrageConditions)do
		for arbConditionNo,value in pairs(valueTable)do 
			local selected = value.Selected
			local conditionStatus = value.ConditionStatus
			local log = sys_format("StopArbConditions:arbitrageID=%s,arbConditionNo=%s,selected=%s,conditionStatus=%s",arbitrageID,arbConditionNo,selected,conditionStatus)
			_WriteAplLog(log)
			if selected == "1" and conditionStatus == "执行中" then
				if gtStartArbConditios[arbConditionNo] then
					gtStartArbConditios[arbConditionNo] = nil
				end
				value.ConditionStatus = "未执行"
				local log = sys_format("套利条件单:%s已停止",arbConditionNo)
				_WriteAplLog(log)
				sendLog(log)
				--发送界面
				sendArbCondition(arbitrageID,arbConditionNo)
			end
		end
	end
_End

--删除条件单
_OnEventDefined(DeleteArbConditions event)
	_WriteAplLog("DeleteArbConditions")
	for arbitrageID,valueTable in pairs(gtArbitrageConditions)do
		for arbConditionNo,value in pairs(valueTable)do 
			local selected = value.Selected
			local conditionStatus = value.ConditionStatus
			local log = sys_format("DeleteArbConditions:arbitrageID=%s,arbConditionNo=%s,selected=%s,conditionStatus=%s",arbitrageID,arbConditionNo,selected,conditionStatus)
			_WriteAplLog(log)
			if selected == "1" then
				if gtStartArbConditios[arbConditionNo] then	--在执行中的条件单也删除
					gtStartArbConditios[arbConditionNo] = nil
				end
				value.Flag = "0"
				--刷新界面
				sendArbCondition(arbitrageID,arbConditionNo)
				local log = sys_format("套利条件单:%s已删除",arbConditionNo)
				_WriteAplLog(log)
				sendLog(log)
				gtArbitrageConditions[arbitrageID][arbConditionNo] = nil
			end
		end
	end
_End

--条件单修改
_OnEventDefined(UpdateArbCondition event)
	local arbConditionNo = event._GetFld("ArbConditionNo")
	local arbitrageID = event._GetFld("ArbitrageID")
	local openCompare = event._GetFld("OpenCompare")
	local openThreshold = event._GetFld("OpenThreshold")
	local closeCompare = event._GetFld("CloseCompare")
	local closeThreshold = event._GetFld("CloseThreshold")
	local orderUnit = event._GetFld("OrderUnit")
	local log = sys_format("UpdateArbCondition:%s,%s,openCompare=%s,openThreshold=%s,closeCompare=%s,closeThreshold=%s,orderUnit=%s",arbConditionNo,arbitrageID,openCompare,openThreshold,closeCompare,closeThreshold,orderUnit)
	_WriteAplLog(log)
	if gtArbitrageConditions[arbitrageID] then
		if gtArbitrageConditions[arbitrageID][arbConditionNo] then
			gtArbitrageConditions[arbitrageID][arbConditionNo].OpenCompare = openCompare
			gtArbitrageConditions[arbitrageID][arbConditionNo].OpenThreshold = openThreshold
			gtArbitrageConditions[arbitrageID][arbConditionNo].CloseCompare = closeCompare
			gtArbitrageConditions[arbitrageID][arbConditionNo].CloseThreshold = closeThreshold
			gtArbitrageConditions[arbitrageID][arbConditionNo].OrderUnit = orderUnit
			--刷新界面
			sendArbCondition(arbitrageID,arbConditionNo)
			log = sys_format("套利条件单%s修改成功",arbConditionNo)
			_WriteAplLog(log)
			sendLog(log)
		end
	end
_End

--复制条件单
_OnEventDefined(CopyArbCondition event)
	local arbConditionNo = event._GetFld("ArbConditionNo")
	local arbitrageID = event._GetFld("ArbitrageID")
	local log = sys_format("CopyArbCondition:ArbitrageID=%s,ArbConditionNo=%s",arbitrageID,arbConditionNo)
	_WriteAplLog(log)
	if gtArbitrageConditions[arbitrageID] then
		if gtArbitrageConditions[arbitrageID][arbConditionNo] then
			local tempTable = gtArbitrageConditions[arbitrageID][arbConditionNo]
			local selected = tempTable.Selected 
			local openFlag = tempTable.OpenCompare
			local openSpread = tempTable.OpenThreshold 
			local closeFlag = tempTable.ColseCompare 
			local closeSpread = tempTable.CloseThreshold 
			local unit = tempTable.OrderUnit
			local conditionStatus = tempTable.ConditionStatus 
			local openFld =  tempTable.OpenFld
			local issueCode1 = tempTable.IssueCode1 
			local issueCode2 = tempTable.IssueCode2 
			local issueCode3 = tempTable.IssueCode3 
			local issueCode4 = tempTable.IssueCode4
			local arbitrageType = tempTable.ArbitrageType
			local flag = tempTable.Flag
			local spread = tempTable.Spread
				
			local tempTable1 = {}
			tempTable1.Selected = "0"
			tempTable1.ArbitrageType = arbitrageType
			tempTable1.OpenCompare = openFlag
			tempTable1.OpenThreshold = openSpread
			tempTable1.ColseCompare = closeFlag
			tempTable1.CloseThreshold = closeSpread
			tempTable1.OrderUnit = unit
			tempTable1.ConditionStatus = "未执行"
			tempTable1.OpenFld = "未开" --开仓标志 未开，已开
			tempTable1.IssueCode1 = issueCode1
			tempTable1.IssueCode2 = issueCode2
			tempTable1.IssueCode3 = issueCode3
			tempTable1.IssueCode4 = issueCode4
			tempTable1.Flag = flag
			local newArbConditionNo = createPortID("A",arbitrageType)
			gtArbitrageConditions[arbitrageID][newArbConditionNo] = {}
			gtArbitrageConditions[arbitrageID][newArbConditionNo] = tempTable1
			--发送界面
			sendArbCondition(arbitrageID,newArbConditionNo)
		end
	end
_End

--条件单监控
function ArbConditionMonitorAll()
	for arbConditionNo,arbitrageID in pairs(gtStartArbConditios)do
		ArbConditionMonitor(arbConditionNo,arbitrageID)
	end
end

function ArbConditionMonitor(arbConditionNo,arbitrageID)
	if gtArbitrageConditions[arbitrageID] then
		local conditionTable = gtArbitrageConditions[arbitrageID][arbConditionNo]
		if conditionTable then
			local arbitrageType = conditionTable.ArbitrageType
			local unit = conditionTable.OrderUnit
			if gtArbitrageRelation[arbitrageType] then
				if gtArbitrageRelation[arbitrageType][arbitrageID] then
					local sprade = gtArbitrageRelation[arbitrageType][arbitrageID].Spread
					local openCompare = conditionTable.OpenCompare
					local openThreshold = conditionTable.OpenThreshold
					local colseCompare = conditionTable.ColseCompare
					local closeThreshold = conditionTable.CloseThreshold
					local openFld = conditionTable.OpenFld
					if openFld == "未开" then	--开仓条件单
						if sprade ~="-" and openCompare~="" and openThreshold ~= "" then
							sprade = sprade.getNumberValue()
							openThreshold = openThreshold.getNumberValue()
							if (openCompare ==">=" and sprade >= openThreshold) or (openCompare =="<" and sprade < openThreshold) then
								local log = sys_format("条件单%s开始开仓下单:",arbConditionNo)
								_WriteAplLog(log)
								sendLog(log)
								arbOrderReady(arbitrageType,arbitrageID,arbConditionNo,unit,0)
								conditionTable.OpenFld = "已开"
								sendArbCondition(arbitrageID,arbConditionNo)
							end
						end
					elseif openFld=="已开" then	--平仓条件单
						if sprade ~="-" and openCompare~="" and openThreshold ~= "" then
							sprade = sprade.getNumberValue()
							closeThreshold = closeThreshold.getNumberValue()
							if(colseCompare ==">=" and sprade >= closeThreshold) or (colseCompare =="<" and sprade < closeThreshold) then
								arbOrderReady(arbitrageType,arbitrageID,arbConditionNo,unit,1)
								local log = sys_format("条件单%s开始平仓下单:",arbConditionNo)
								_WriteAplLog(log)
								sendLog(log)
								conditionTable.OpenFld = "已平"
								conditionTable.ConditionStatus = "执行完成"
								sendArbCondition(arbitrageID,arbConditionNo)
							end
						end
					end
				end
			end
		end
	end
end
--生成组合编号
function createPortID(OrderType,Flag)
	--OrderType:"S","H","A"
	--Flag:看多:"KD",看空:"KK",平盘:"PP",套保多:"DT",套保空:"KT",套利："PJ","JD","FZ","TX","XX","RL"
	local DTSTime time = _GetNowTime()
	local nowtime = time.asString("%H%M%S")
	gOrderNumber = gOrderNumber + 1
	local strNo = sys_format("%04d",gOrderNumber)
	local portID = OrderType ..Flag..gStrDate..nowtime..strNo
	_WriteAplLog(portID)
	return portID
end

--我的持仓控件
_OnEventDefined(PosControl event)
	local RefreshPos = event._GetFld("RefreshPos")
	if RefreshPos ~= "" and RefreshPos then				--刷新操作
		if RefreshPos == "0" then						--立即刷新
			--_WriteAplLog("刷新持仓")
			gtFoldExist={}
			showPosStatus()
		else 											--设置自动刷新时间
			--_WriteAplLog("设置自动刷新时间")
			_StopTimer(_TimerName="ReFreshPosTime");
			local log = sys_format("自动刷新间隔为[%sS]",RefreshPos)
			sendLog(log)
			local time = RefreshPos.getNumberValue() * 1000
			_StartTimer(_TimerName="ReFreshPosTime",_Interval = time);
			
		end
	end
_End

--平单笔
_OnEventDefined(SingleCloseEvent fire)
	local issueCode = fire._GetFld("IssueCode")--合约代码
	local baSubID = fire._GetFld("BASubID")--BASubID
	local priceType = fire._GetFld("PriceType")--价格
	local quantity = fire._GetFld("Quantity")--数量
	if quantity > 0 then
		ClosePos(issueCode,baSubID,priceType,quantity)
	end
_End

--平组合
_OnEventDefined(GroupCloseEvent fire)
	local XMLPortID = fire._GetFld("PortID")--合约代码
	local PortName = fire._GetFld("PortName")--合约代码
	local tStockPosFundStatus = _PosFundStatus[gStockAccountCode];
	local tFuturePosFundStatus = _PosFundStatus[gFutureAccountCode];
	if tStockPosFundStatus and tFuturePosFundStatus then
		local DTSEvent posInfo = _CreateEventObject("PositionInfo");
		for key, pos in pairs(_PosPositionTable) do
			local baMapID = pos.BAMapID
			local baSubID = pos.BASubID
			local PortID = sys_sub(baSubID,2,-1)
			local PortIDFlag = sys_sub(PortID,1,1)
			local issueCode = pos.IssueCode
			local priceType = ""
			if sys_sub(baSubID,1,1) == "3" then
				priceType = "BidPrice1"
			elseif sys_sub(baSubID,1,1) == "1" then
				priceType = "AskPrice1"
			end
			local quantity = pos.AvlQuantity
			if quantity > 0 then
				log = sys_format("平组合[%s],当前组合[%s],PortName[%s],issueCode[%s],baSubID[%s],PortID[%s],priceType[%s],quantity[%s]",XMLPortID,PortIDFlag,PortName,issueCode,baSubID,PortID,priceType,quantity)
				_WriteAplLog(log)
				if PortID ~= "" and PortID then
					if XMLPortID == PortID then
						ClosePos(issueCode,baSubID,priceType,quantity)	--平 投机持仓\套保持仓\套利持仓\
					end
				else
					if XMLPortID == "other" and sys_sub(issueCode,1,2) ~= "IF" then
						ClosePos(issueCode,baSubID,priceType,quantity) --平other
					elseif XMLPortID == "期货持仓" and sys_sub(issueCode,1,2) == "IF" then
						ClosePos(issueCode,baSubID,priceType,quantity) --平期货
					end
				end
			end
		end
	end
_End

function ClosePos(issueCode,baSubID,priceType,quantity)
	local marketCode = _PosIssueMarketTable[issueCode]--市场号
	local creRed = 0--快速平仓默认为0
	local log = sys_format("QuickCloseEvent, issue=[%s], baSubID=[%s], priceType=[%s], quantity=[%s]", issueCode, baSubID, priceType, quantity)
	_WriteAplLog(log)

	--子账号
	local baMapID = spFutureBAMapID
	if marketCode == "1" or marketCode == "2" then
		baMapID = spStockBAMapID
	end

	--买卖和开平
	local bs = "3";
	local oc = 3--先平今后平昨
	local posBS = sys_sub(baSubID, 1, 1)
	if posBS == "3" then
		bs = "1"
	else
		bs = "3"
	end
	if (marketCode == "1" or marketCode == "2") then
		oc = 1
	end

	--平仓类型
	local marginType = GetMarginType(bs, oc, creRed)

	if not marketCode then
		local log = sys_format("平仓失败: 合约代码 [ %s] 不合法", issueCode)
		_WriteAplLog(log)
		sendLog(log)
	elseif quantity <= 0 then
		local log = sys_format("平仓失败: 平仓数量 [ %s] 不合法", quantity)
		_WriteAplLog(log)
		sendLog(log)
	elseif marginType == "" then
		local log = sys_format("平仓失败: 无法识别交易类型")
		_WriteAplLog(log)
		sendLog(log)
	else
		local checkAccount = true
		if baMapID == "" then
			if marketCode == "1" or marketCode == "2" then
				checkAccount = false
				local log = sys_format("平仓失败: 未设置证券账号, 禁止证券交易")
				sendLog(log)
				_WriteAplLog(log)
			else
				checkAccount = false
				local log = sys_format("平仓失败: 未设置期货账号, 禁止期货交易")
				sendLog(log)
				_WriteAplLog(log)
			end
		end
		if checkAccount == true then
			--取得快速平仓的平仓价格
			local priceCheck = true
			local price = 0
			local priceTable = _PosPriceTable[issueCode]
			if not priceTable then
				local log = sys_format("平仓失败: 取不到合约 [ %s] 的行情信息", issueCode)
				sendLog(log)
				_WriteAplLog(log)
				priceCheck = false
			else
				local tmpBidPrice_1 = priceTable.BidPrice1
				local tmpAskPrice_1 = priceTable.AskPrice1
				if priceType == "AskPrice1" then
					if (not tmpAskPrice_1) or tmpAskPrice_1 == "" or tmpAskPrice_1 == "-" then
						local log = sys_format("平仓失败: 取不到合约 [ %s] 的卖1价信息", issueCode)
						sendLog(log)
						_WriteAplLog(log)
						priceCheck = false
					else
						price = tmpAskPrice_1
					end
				else
					if (not tmpBidPrice_1)  or tmpBidPrice_1 == "" or tmpBidPrice_1 == "-" then
						local log = sys_format("平仓失败: 取不到合约 [ %s] 的买1价信息", issueCode)
						sendLog(log)
						_WriteAplLog(log)
						priceCheck = false
					else
						price = tmpBidPrice_1
					end
				end
			end

			local log = sys_format("QuickCloseEvent, price=[%s]", price)
			_WriteAplLog(log)

			if priceCheck == true then
				--获取单子的DealerID
				local currentUserID = _GetDealerID()
				local dealerID = GetOrderDealerID(baMapID)
				local dealerlog = sys_format("QuickCloseEvent, dealerID=[%s]", dealerID)
				_WriteAplLog(dealerlog)
				if not dealerID then
					local log = sys_format("平仓失败: 当前用户 [ %s ] 没有用 [ %s ] 进行下单的权限", currentUserID, baMapID)
					sendLog(log)
					_WriteAplLog(log)
				else
					--平仓
					--local ret = SubmitOrder(baMapID, baSubID, issueCode, bs, oc, price, quantity, creRed, dealerID, "", "")
					local poskey = baMapID .. baSubID .. issueCode
					local pos = _PosPositionTable[poskey]
					if pos then
						if quantity > pos.AvlQuantity then
							quantity = pos.AvlQuantity
						end
					end
					local ret = PosSubmitSingleOrder(baMapID, baSubID, issueCode, bs, oc, price, quantity, creRed, dealerID, "", nil, "")
					if ret.Result == true then
						local log = sys_format("[%s]平单笔完成",issueCode)
						sendLog(log)
						_WriteAplLog(log)
					else
						local log = sys_format("平仓失败: %s ", ret.Reason)
						sendLog(log)
						_WriteAplLog(log)
					end
				end
			end
		end
	end
end

function GetMarginType(bs, oc, creRed)
	local log = sys_format("GetMarginType, bs=[%s], oc=[%s], creRed=[%s]", bs, oc, creRed)
	_WriteAplLog(log)
	bs = bs.toString()
	oc = oc.getNumberValue()
	creRed = creRed.getNumberValue()
	local marginType = ""

	if bs == "3" then
		if creRed == 0  then
			if oc == 0 then
				marginType = "买开"
			elseif oc == 1 then
				marginType = "买平"
			elseif oc == 2 then
				marginType = "买平"
			elseif oc == 3 then
				marginType = "买平"
			end
		end
	elseif bs == "1" then
		if creRed == 0  then
			if oc == 0 then
				marginType = "卖开"
			elseif oc == 1 then
				marginType = "卖平"
			elseif oc == 2 then
				marginType = "卖平"
			elseif oc == 3 then
				marginType = "卖平"
			end
		end
	end

	return marginType
end

--取得Order的DealerID
function GetOrderDealerID(baMapID)
	local log = sys_format("GetOrderDealerID, baMapID=%s", baMapID)
	_WriteAplLog(log)

	--如果是本用户的BAMapID,则DealerID就为本用户
	local orderDealerID
	local currentUserID = _GetDealerID()--当前用户
	if _PosUserBAMapTable[currentUserID] then
		if _PosUserBAMapTable[currentUserID][baMapID] then
			orderDealerID = currentUserID
		end
	end

	--如果当前用户对baMapID所属的用户至少存在一个有读写权限的,则当前用户可以用该BAMapID下单
	if not orderDealerID then
		local userIDTable = _PosBAMapUserTable[baMapID]--baMapID在UserBAMapTable中所属的用户
		for baMapUserID, dummy in pairs(userIDTable) do
			if _PosUserAccessUserTable[currentUserID] then
				local right = _PosUserAccessUserTable[currentUserID][baMapUserID]
				local tmplog = sys_format("currentUserID=%s, baMapUserID=%s, right=%s", currentUserID, baMapUserID, right)
				_WriteAplLog(tmplog)
				if right == 11 then--0:没有读写权限, 1:只有读权限, 10:只有写权限, 11:有读写权限
					orderDealerID = baMapUserID;
					break;
				end
			end
		end
	end

	return orderDealerID
end

--委托、成交信息回调
_OnEventExecution("ShowOrder",{},DTSMessageRecordAccess msg)
	local DTSOrderDetailRecordAccess order = msg.getOrderDetailRecord()
	local baMapID = order.getBAMapID()
	local msgType = msg.getMessageType()
	if baMapID == spStockBAMapID or baMapID == spFutureBAMapID then
		local DTSEvent ord = _CreateEventObject("OrderEvent")
		local OrderTime = msg.getPublishTime()
		local CorpCode = order.getCorpCode()
		local IssueCode = order.getIssueCode()
		local IssueName = _PosIssueNameTable[IssueCode] or ""
		local BuySell = order.getBuySell()
		local OpenClose = order.getReserveInt1()
		local Quantity = order.getOriginalQuantity()
		local Price = order.getOrderPrice()
		local ExecutionQuantity = order.getExecutionQuantity()
		local ExecutionValue = order.getExecutionValue()
		local WorkingQuantity = order.getWorkingQuantity()
		local OrderAcceptNo = order.getOrderAcceptNo()
		local CancelQuantity = order.getCancelQuantity()
		local UnAcceptedQuantity = order.getUnacceptedQuantity()
		local RejectedQuantity = order.getRejectedQuantity()
		local GeneralInt1 = order.getGeneralInt1()
		local BASubID = order.getBASubID()
		local PositionCheckID = order.getPositionCheckID()
		--费用
		local BuySellFld = ""
		local feeOrder = {}
		feeOrder.ExecQty = ExecutionQuantity
		feeOrder.ExecValue = ExecutionValue
		feeOrder.OpenClose = OpenClose
		feeOrder.CreRed = 0
		feeOrder.BS = BuySell
		if BuySell == "3" then
			if GeneralInt1 == 1 then
				BuySellFld = "申购"
				feeOrder.CreRed = 1
			elseif GeneralInt1 == 2 then
				BuySellFld = "赎回"
				feeOrder.CreRed = 2
			else
				BuySellFld = "买"
			end
		else
			if GeneralInt1 == 1 then
				BuySellFld = "申购"
				feeOrder.CreRed = 1
			elseif GeneralInt1 == 2 then
				BuySellFld = "赎回"
				feeOrder.CreRed = 2
			else
				BuySellFld = "卖"
			end
		end
		local GeneralInt2 = order.getGeneralInt2()
		local GeneralString2 = order.getGeneralString2()
		if msgType == "L18" and GeneralInt2 == 1 and GeneralString2 ~= "" then
			feeOrder.IsPositionMove = 1
		else	
			feeOrder.IsPositionMove = 0
		end
		local fee = PosFare(_PosBAMapAccount[baMapID],IssueCode,feeOrder)
		--local logs = sys_format("order fare:%s,ExecutionValue:%s,qty:%s,",fee,ExecutionValue,ExecutionQuantity);
		--_WriteAplLog(logs);
		--开平
		local productCode = _PosIssueProductCodeTable[IssueCode]
		local openClose = "-"
		if productCode == "21" or productCode == "31" or productCode == "32" or productCode == "37" then --新增股指期权、国债期货
			if OpenClose == 0 then
				openClose = "开仓"
			elseif OpenClose == 2 then
				openClose = "平今"
			else
				openClose = "平仓"
			end
		end
		--状态
		local  status = "-"
		if Quantity == ExecutionQuantity then
			status = "全部成交"
		elseif Quantity > ExecutionQuantity and ExecutionQuantity > 0 then
			if (ExecutionQuantity + CancelQuantity) == Quantity then
				status = "部成部撤"
			else
				status = "部分成交"
			end
		elseif WorkingQuantity > 0 then
			status = "挂单"
		elseif CancelQuantity > 0 then 
			status = "撤单"
		elseif UnAcceptedQuantity == Quantity then 
			status = "未报"
		elseif RejectedQuantity > 0 then
			status = "拒绝"
		end
		
		local statusFlag = ""
		if WorkingQuantity > 0 then
			statusFlag = "2"
		else
			statusFlag = "1"
		end
		
		--时间格式
		local _String tmpodrtime = OrderTime
		if tmpodrtime ~="" then
			if tmpodrtime.find(":") == -1 then	--有些柜台会直接传回已经格式化好的时间
				local tmpordtimeH = sys_sub(OrderTime,1,2);
				local tmpordtimeM = sys_sub(OrderTime,3,4);
				local tmpordtimeS = sys_sub(OrderTime,5,6);
				local tmpordtimeHM =sys_sub(OrderTime,7,9);
				tmpodrtime = tmpordtimeH..":"..tmpordtimeM..":"..tmpordtimeS.."."..tmpordtimeHM;
			end
		end
		local portID = ""
		if sys_len(BASubID) > 2 then
			portID = sys_sub(BASubID,2,-1)
		else
			portID = "other"
		end
		
		
		if msgType =="L07" or msgType == "L18" then
			local key = msg.getUniqueKeyCode();
			local fare=sys_format("%.2f",0);
			local ExecutionPrice = msg.getExecutionPrice();
			local ExecutionNo = msg.getExecutionNo()
			local _String ExecutionTime = msg.getExecutionTime()
			
			if ExecutionTime then
				if ExecutionTime.find(":") == -1 then
					local hh = sys_sub(ExecutionTime, 1, 2)
					local mm = sys_sub(ExecutionTime, 3, 4)
					local ss = sys_sub(ExecutionTime, 5, 6)
					local hm = sys_sub(ExecutionTime, 7, 9)
					ExecutionTime = hh .. ":" .. mm .. ":" .. ss .. "." .. hm
				end
			else
				ExecutionTime = ""
			end
			
			
			local DTSEvent exec = _CreateEventObject("ExecutEvent")
			if not gtExecExist[portID] then
				gtExecExist[portID] = {};
				local mainRowFlag = "1";
				exec._SetFld("PortID",portID);
				exec._SetFld("UserID","");
				exec._SetFld("BAMapID","");
				exec._SetFld("IssueCode","");
				exec._SetFld("IssueName","");
				exec._SetFld("OrderAcceptNo","");
				exec._SetFld("UniqueKeyCode","");
				exec._SetFld("BuySell","");
				exec._SetFld("Quantity",0);
				exec._SetFld("ExecutionPrice","");
				exec._SetFld("ExecutionTime",0);
				exec._SetFld("ExecutionNo","");
				exec._SetFld("BASubID","");
				exec._SetFld("OpenClose","");
				exec._SetFld("Fee","");
				exec._SetFld("Flag","1");
				exec._SetFld("MainFlag",mainRowFlag);
				exec._SetFld("PortGroupFlag",portID);
				_SendToClients(exec);
				local log = sys_format("exec mainRowFlag1=%s",mainRowFlag)
				_WriteAplLog(log)
			end
			--_WriteAplLog("execution portid1:");
			--_WriteAplLog(portID);
			local mainRowFlag = "2";
			exec._SetFld("PortID",portID);
			exec._SetFld("UserID",gUserID);
			exec._SetFld("BAMapID",baMapID);
			exec._SetFld("IssueCode",IssueCode);
			exec._SetFld("IssueName",IssueName);
			exec._SetFld("OrderAcceptNo",OrderAcceptNo);
			exec._SetFld("UniqueKeyCode",key);
			exec._SetFld("BuySell",BuySellFld);
			exec._SetFld("Quantity",Quantity);
			exec._SetFld("ExecutionPrice",ExecutionPrice);
			exec._SetFld("ExecutionTime",ExecutionTime);
			exec._SetFld("ExecutionNo",ExecutionNo);
			exec._SetFld("BASubID",BASubID);
			exec._SetFld("OpenClose",openClose);
			exec._SetFld("Fee",fare);
			exec._SetFld("Flag","1");
			exec._SetFld("MainFlag",mainRowFlag);
			exec._SetFld("PortGroupFlag",portID);
			_SendToClients(exec);
		end
		if not gtOrderExist[portID] then
			gtOrderExist[portID] = {};
			ord._SetFld("PortID",portID);
			ord._SetFld("BAMapID","");
			ord._SetFld("UserID","");
			ord._SetFld("IssueCode","");
			ord._SetFld("IssueName","");
			ord._SetFld("BuySell","");
			ord._SetFld("OpenClose","");
			ord._SetFld("ExecutionValue",0);
			ord._SetFld("Quantity",0);
			ord._SetFld("Price","");
			ord._SetFld("ExecutionQuantity",0);
			ord._SetFld("WorkingQuantity",0);
			ord._SetFld("CorpCode","");
			ord._SetFld("BASubID","");
			ord._SetFld("Status","");
			ord._SetFld("OrderTime","");
			ord._SetFld("OrderAcceptNo","");
			ord._SetFld("Fee","");
			ord._SetFld("Flag","1");
			ord._SetFld("MainRowFlag","1");
			ord._SetFld("GroupFlag",portID);
			_SendToClients(ord);
			_WriteAplLog("order mainRowFlag1=1")
	
		end
		ord._SetFld("PortID",portID)
		ord._SetFld("BAMapID",baMapID)
		ord._SetFld("UserID",gUserID)
		ord._SetFld("IssueCode",IssueCode)
		ord._SetFld("IssueName",IssueName)
		ord._SetFld("BuySell",BuySellFld)
		ord._SetFld("OpenClose",openClose)
		local strExecutionValue = sys_format("%.2f",ExecutionValue)
		ord._SetFld("ExecutionValue",strExecutionValue)
		ord._SetFld("ExecutionValue",ExecutionValue)
		ord._SetFld("Quantity",Quantity)
		ord._SetFld("Price",Price);
		ord._SetFld("ExecutionQuantity",ExecutionQuantity)
		ord._SetFld("WorkingQuantity",WorkingQuantity)
		ord._SetFld("CorpCode",CorpCode)
		ord._SetFld("BASubID",BASubID)
		ord._SetFld("Status",status)
		ord._SetFld("OrderTime",tmpodrtime)
		ord._SetFld("OrderAcceptNo",OrderAcceptNo)
		local strFee = fee.toString()
		ord._SetFld("Fee",strFee)
		ord._SetFld("StatusFlag",statusFlag)
		ord._SetFld("Flag","1")
		ord._SetFld("MainRowFlag","2")
		ord._SetFld("GroupFlag",portID)
		_SendToClients(ord)
		
		--local temLog = sys_format("OnOrder:BAMapID=%s,IssueCode=%s,BuySell=%s,OpenClose=%s,Quantity=%s,CorpCode=%s",baMapID,IssueCode,BuySell,OpenClose,Quantity,CorpCode)
		--_WriteAplLog(temLog)
	end
_End

_OnEventExecution("RefuseOrder",{},DTSMessageRecordAccess msg)
	_WriteAplLog("_OnEventExecution RefuseOrder")
	local msgType = msg.getMessageType()
	if msgType == "L04" or msgType == "L06" then
		local errorType = msg.getErrorType()
		local acceptCode = msg.getAcceptCode()
		local returnCode = msg.getReturnCode()
		local DTSOrderDetailRecordAccess order = msg.getOrderDetailRecord()
		local corpCode = order.getCorpCode()
		
		if errorType == "1" or errorType == "2" then
			local reserveString2 = order.getReserveString2()
			local issueCode = order.getIssueCode()
			local log = sys_format("RefuseOrder info:msgType=%s,errorType=%s,corpCode=%s,issueCode=%s,returnCode=%s,reserveString2=%s",msgType,errorType,corpCode,issueCode,returnCode,reserveString2)
			_WriteAplLog(log)
			if msgType == "L04" and errorType == "1" then
				local log = sys_format("委托号:%s,合约:%s委托被拒绝,出错代码:%s,原因:%s",corpCode,issueCode,returnCode,reserveString2)
				_WriteAplLog(log)
				sendLog(log)
			elseif msgType == "L04" and errorType == "2" then
				local log = sys_format("委托号:%s,合约:%s委托被拒绝,出错代码:%s,原因:%s",corpCode,issueCode,acceptCode,reserveString2)
				_WriteAplLog(log)
				sendLog(log)
			elseif msgType == "L06" then
				local log = sys_format("委托号:%s,合约:%s撤单被拒绝,出错代码:%s,原因:%s",corpCode,issueCode,returnCode,reserveString2)
				_WriteAplLog(log)
				sendLog(log)
			end
		end
	end
_End

--改价
_OnEventDefined(AmendOrder event)
	local issueCode = event._GetFld("IssueCode")
	local corpCode = event._GetFld("CorpCode")
	local priceType = event._GetFld("PriceType")
	local priceBPS = event._GetFld("PriceBPS")
	local log = sys_format("AmendOrder:issueCode=%s,corpCode=%s,pricetype=%s,priceBPS=%s",issueCode,corpCode,priceType,priceBPS)
	_WriteAplLog(log)
	if issueCode =="" or corpCode == "" or priceType == "" or priceBPS=="" then
	else
		local newprice = PosGetOrderPrice(issueCode,priceType,POS_ADJ_BY_BPS,priceBPS)
		local ret =  PosAmendOrder(corpCode,newprice)
		if ret.Result then
			logs = sys_format("%s,%s改价完成,委托价 %s",corpCode,issueCode,newprice)
			sendLog(logs)
		else
			logs = sys_format("%s,%s改价失败,%s",corpCode,issueCode,ret.Reason)
			sendLog(logs)
		end
	end
_End


--撤单
_OnEventDefined(CancelOrder Event)
	local _String corpCode = Event._GetFld("CorpCode")
	local logs = sys_format("CancelOrder- CorpCode:%s",corpCode);
	_WriteAplLog(logs);
	local ret = PosCancelOrder(corpCode)
	if ret.Result then
		logs = sys_format("%s撤单完成",corpCode)
		sendLog(logs)
	else
		logs = sys_format("%s撤单失败,%s",corpCode,ret.Reason)
		sendLog(logs)
	end
_End


---------------xh----------------010
_OnEventDefined(SetIssueCodeInfo event)
	if gInterestRates == "" or gDividendYield == "" then
		local DTSEvent inf = _CreateEventObject("OptionIssueCodeInfo")
		sendLog("参数未设置，无法计算指标！")

		inf._SetFld("Delta1","-")
		inf._SetFld("Delta2","-")
		inf._SetFld("Theta1","-")
		inf._SetFld("Theta2","-")
		inf._SetFld("Gamma","-")
		inf._SetFld("Vega","-")
		inf._SetFld("Rho","-")

		_SendToClients(inf)
    end

    local Issue = event._GetFld("UnderlyingIssueCode")
	local Month = event._GetFld("UnderlyingMonth")
	
	gUnderlyingIssueCode = Issue
	gExpirationDate = Month

	SendToHandTable("","","","Clear")
	SendToHandTable(gUnderlyingIssueCode,gExpirationDate,"","1")
_End

sendLog("初始化完成！")
--010
function SendToHandTable(UnderlyingIssueCode,ExpirationDate,issueCode,Type) -- 计算并发送手动标签信息
	local DTSEvent info = _CreateEventObject("OptionIssueCodeInfo")
	if Type == "Clear" then
		info._SetFld("ExercisePrice","Clear")
		_SendToClients(info)

	elseif Type == "1" then
		local Rounding = 3
		if _PosPriceTable[UnderlyingIssueCode] then
			local UnderlyingIssLast = _PosPriceTable[UnderlyingIssueCode].LastPrice -- 标的最新价

			--issueCode行情跳动的期权合约，界面选择回调时 该issueCode = "",行情变化里调用是是具体的股指期权行情
			if issueCode == "" then
				--遍历gtrefreshIFtable[gUnderlyingIssueCode][gExpirationDate]
				--按当前行情计算
				--发送全部记录到界面
				for key,value in pairs(gtrefreshIFtable[UnderlyingIssueCode][ExpirationDate]) do
					sendMessagehand(UnderlyingIssLast,Rounding,key,value.C,value.P)
				end


			elseif issueCode~="" then
				--遍历gtrefreshIFtable[gUnderlyingIssueCode][gExpirationDate]
				--计算issueCode变化
				--只发送变化的IssueCode这行记录发送界面
				for key,value in pairs(gtrefreshIFtable[UnderlyingIssueCode][ExpirationDate]) do
					if issueCode == value.C or issueCode == value.P then
						sendMessagehand(UnderlyingIssLast,Rounding,key,value.C,value.P)
					end
				end

			end	
		end
	end
end

function sendMessagehand(UnderlyingIssLast,Rounding,key,C,P)
	local DTSEvent info = _CreateEventObject("OptionIssueCodeInfo")
	local iss1 = C
	local iss2 = P
	info._SetFld("ExercisePrice",key)

	local priceTable1
	local priceTable2

	if iss1 then
		info._SetFld("IssueCode1",iss1)
		priceTable1 = _PosPriceTable[iss1]

	else
		info._SetFld("IssueCode1","-")
	end

	if iss2 then
		info._SetFld("IssueCode2",iss2)
		priceTable2 = _PosPriceTable[iss2]

	else
		info._SetFld("IssueCode2","-")
	end	

	if priceTable1 then 
		--_WriteAplLog("涨行情进来")
		local lastP1 = priceTable1.LastPrice
		local askP1  = priceTable1.AskPrice1
		if not askP1 then
			askP1 = "-"
		end
		local bidP1  = priceTable1.BidPrice1
		if not bidP1 then
			bidP1 = "-"
		end
		local lnc1   = priceTable1.AdjustedLNC
		local ratio1
		if lnc1 then 
			ratio1 = (lastP1 - lnc1)/lnc1*100
			ratio1 = sys_format("%.2f",ratio1)
		else
			ratio1 = "-"
		end

		local log1 = sys_format("lastP1 = %s,lnc1 = %s",lastP1,lnc1)
		--_WriteAplLog(log1)

		local RemainderDate = dayday(iss1) -- 剩余交易日
		--local RemainderDate = dayday(gIF) -- 测试

		info._SetFld("LastPrice1",lastP1)
		info._SetFld("AskPrice1",askP1)
		info._SetFld("BidPrice1",bidP1)
		info._SetFld("Ratio1",ratio1)

		if gInterestRates ~= "" and gDividendYield ~= "" then
			--_WriteAplLog("发送涨计算数据")
			local loggggg = sys_format("iss1[%s],iss2[%s],标的最新价 = %s,行权价 = %s,到期日 = %s,合约最新价 = %s",iss1,iss2,UnderlyingIssLast,key,RemainderDate,lastP1)
			_WriteAplLog(loggggg)

			local volatility = calImpliedCallVolatity(UnderlyingIssLast,key,RemainderDate,gDividendYield,lastP1,gInterestRates,Rounding) -- 涨期权的隐含波动率
			local c_delta = calCallDelta(UnderlyingIssLast, key, RemainderDate, gDividendYield,volatility, gInterestRates,Rounding) -- 看涨期权的delta
			local c_theta = calCallTheta(UnderlyingIssLast, key, RemainderDate, gDividendYield,volatility, gInterestRates,Rounding) -- 计算看涨期权Theta

			local log = sys_format("volatility[%s],c_delta[%s],c_theta[%s]",volatility,c_delta,c_theta)
			_WriteAplLog(log)

			info._SetFld("Delta1",c_delta)
			info._SetFld("Theta1",c_theta)
		else
			info._SetFld("Delta1","-")
			info._SetFld("Theta1","-")
		end
				
	else
		info._SetFld("LastPrice1","-")
		info._SetFld("AskPrice1","-")
		info._SetFld("BidPrice1","-")
		info._SetFld("Ratio1","-")
		info._SetFld("Delta1","-")
		info._SetFld("Theta1","-")
	end

	if priceTable2 then
		--_WriteAplLog("跌行情进来")
		local lastP2 = priceTable2.LastPrice
		local askP2  = priceTable2.AskPrice1
		if not askP2 then
			askP2 = "-"
		end
		local bidP2  = priceTable2.BidPrice1
		if not bidP2 then
			bidP2 = "-"
		end
		local lnc2   = priceTable2.AdjustedLNC
		local ratio2
		if lnc2 then 
			ratio2 = (lastP2 - lnc2)/lnc2*100
			ratio2 = sys_format("%.2f",ratio2)
		else
			ratio2 = "-"
		end

		local log2 = sys_format("lastP2 = %s,lnc2 = %s",lastP2,lnc2)
		--_WriteAplLog(log2)

		local RemainderDate = dayday(iss2) -- 剩余交易日
		--local RemainderDate = dayday(gIF) -- 测试

		info._SetFld("LastPrice2",lastP2)
		info._SetFld("AskPrice2",askP2)
		info._SetFld("BidPrice2",bidP2)
		info._SetFld("Ratio2",ratio2)

		if gInterestRates ~= "" and gDividendYield ~= "" then
			--_WriteAplLog("发送跌计算数据")

			local loggggg = sys_format("标的最新价 = %s,行权价 = %s,到期日 = %s,合约最新价 = %s",UnderlyingIssLast,key,RemainderDate,lastP2)
			--_WriteAplLog(loggggg)
			local volatility = calImpliedPutVolatity(UnderlyingIssLast,key,RemainderDate,gDividendYield,lastP2,gInterestRates,Rounding) -- 跌期权的隐含波动率
			local p_delta = calPutDelta(UnderlyingIssLast, key, RemainderDate, gDividendYield,volatility, gInterestRates,Rounding) -- 看跌期权的delta
			local p_theta = calPutTheta(UnderlyingIssLast, key, RemainderDate, gDividendYield,volatility, gInterestRates,Rounding) -- 计算看跌期权Theta
			local p_gamma = calGamma(UnderlyingIssLast, key, RemainderDate, gDividendYield,volatility,gInterestRates,Rounding) -- 计算Gamma
			local p_vega  = calVega(UnderlyingIssLast, key, RemainderDate, gDividendYield,volatility,gInterestRates,Rounding) -- 计算Vega
			local p_rho   = calPutRho(UnderlyingIssLast, key,RemainderDate,gDividendYield,volatility,gInterestRates,Rounding) -- 计算看跌期权Rho

			local log = sys_format("volatility[%s],p_delta[%s],p_theta[%s],p_gamma[%s],p_vega[%s],p_rho[%s]",volatility,p_delta,p_theta,p_gamma,p_vega,p_rho)
			--_WriteAplLog(log)

			info._SetFld("Delta2",p_delta)
			info._SetFld("Theta2",p_theta)
			info._SetFld("Gamma",p_gamma)
			info._SetFld("Vega",p_vega)
			info._SetFld("Rho",p_rho)
		else
			info._SetFld("Delta2","-")
			info._SetFld("Theta2","-")
			info._SetFld("Gamma","-")
			info._SetFld("Vega","-")
			info._SetFld("Rho","-")
			
		end
	else
		info._SetFld("LastPrice2","-")
		info._SetFld("AskPrice2","-")
		info._SetFld("BidPrice2","-")
		info._SetFld("Ratio2","-")
		info._SetFld("Delta2","-")
		info._SetFld("Theta2","-")
		info._SetFld("Gamma","-")
		info._SetFld("Vega","-")
		info._SetFld("Rho","-")
	end

	_SendToClients(info)
end

function dayday(IssueCode)
	--剩余交易日
	local ExpirationDate = _PosIssueExpirationDateTable[IssueCode]
	local numExpirationDate = ExpirationDate.getNumberValue()
	local RemainderDate = 1
	local TradingDate = 0
	while numExpirationDate > TradingDate do
		TradingDate = _PosComingTradingDate[RemainderDate]
		TradingDate = TradingDate.getNumberValue()
		RemainderDate = RemainderDate + 1
	end

	local log = sys_format("期货[%s]到期日期为[%s],剩余[%s]个交易日",IssueCode,ExpirationDate,RemainderDate)
	--_WriteAplLog(log)

	return RemainderDate
end


_OnEventDefined(OnClickOKSpeculate event)
	local issueCode = event._GetFld("IssueCode")
	local buySell = event._GetFld("BuySell")
	local price = gtOptionInfo[issueCode].StrikePrice		--目标价格
	price = sys_format("%.3f",price)
	local callPut = gtOptionInfo[issueCode].CallPut
	local contract = _PosIssueContractSizeTable[issueCode] 
	local priceInfo = gtIssuePriceInfoTable[issueCode] or {}
	local lastPrice = priceInfo.LastPrice 
	local DTSEvent spEvent = _CreateEventObject("ExpectedProfit")
	--spEvent._SetFld("SettlementPrice","Clear")
	--_SendToClients(spEvent)
	local tempPrice = price.getNumberValue()
	--测试用
	--lastPrice = 100
	local log = sys_format("OnClickOKSpeculate,issueCode:%s,buySell:%s,callPut:%s,price:%s,contract:%s,lastPrice:%s",issueCode,buySell,callPut,price,contract,lastPrice)
	_WriteAplLog(log)
	------
	if lastPrice and contract then
		local amount = lastPrice*contract
		local tempAmount = -amount
		if (callPut == "C" and buySell == "3") then		--买涨
			local str = "K < "..price
			spEvent._SetFld("Index","1")
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","放弃")
			spEvent._SetFld("Profit",tempAmount)
			spEvent._SetFld("ProfitStatus","亏损")
			_SendToClients(spEvent)
			
			spEvent._SetFld("Index","2")
			str = sys_format("%s<=K<=%s",price,lastPrice+tempPrice)
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","行权")
			str = sys_format("(K-%s)*%s-%s",price,contract,amount)
			spEvent._SetFld("Profit",str)
			spEvent._SetFld("ProfitStatus","亏损")
			_SendToClients(spEvent)
			spEvent._SetFld("Index","3")
			spEvent._SetFld("Operation","行权")
			spEvent._SetFld("Profit",str)
			spEvent._SetFld("ProfitStatus","盈利")
			str = sys_format("K > %s",lastPrice+tempPrice)
			spEvent._SetFld("SettlementPrice",str)
			_SendToClients(spEvent)	
		elseif (callPut == "P" and buySell == "1") then			--卖跌
			local str = sys_format("%s",tempPrice-lastPrice)
			str = "K < "..str
			spEvent._SetFld("Index","1")
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","行权")
			str = sys_format("%s+(K-%s)*%s",amount,price,contract)
			spEvent._SetFld("Profit",str)
			spEvent._SetFld("ProfitStatus","亏损")
			_SendToClients(spEvent)

			spEvent._SetFld("Index","2")
			str = sys_format("%s<=K<=%s",tempPrice-lastPrice,lastPrice+tempPrice)
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","行权")
			str = sys_format("%s+(K-%s)*%s",amount,price,contract)
			spEvent._SetFld("Profit",str)
			spEvent._SetFld("ProfitStatus","盈利")
			_SendToClients(spEvent)	

			
			spEvent._SetFld("Index","3")
			str = sys_format("K > %s",lastPrice+tempPrice)
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","行权")
			spEvent._SetFld("Profit",amount)
			spEvent._SetFld("ProfitStatus","盈利")
			_SendToClients(spEvent)	
		elseif (callPut == "P" and buySell == "3") then		--买跌
			local str = sys_format("K > %s",lastPrice+tempPrice)
			spEvent._SetFld("Index","1")
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","放弃")
			spEvent._SetFld("Profit",tempAmount)
			spEvent._SetFld("ProfitStatus","亏损")
			_SendToClients(spEvent)
		
			spEvent._SetFld("Index","2")
			str = sys_format("%s<=K<=%s",tempPrice-lastPrice,lastPrice+tempPrice)
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","行权")
			str = sys_format("(%s-K)*%s-%s",price,contract,amount)
			spEvent._SetFld("Profit",str)
			spEvent._SetFld("ProfitStatus","亏损")
			_SendToClients(spEvent)
			
			spEvent._SetFld("Index","3")
			spEvent._SetFld("Operation","行权")
			spEvent._SetFld("Profit",str)
			spEvent._SetFld("ProfitStatus","盈利")
			str = sys_format("K < %s",tempPrice-lastPrice)
			spEvent._SetFld("SettlementPrice",str)
			_SendToClients(spEvent)		
		elseif (callPut == "C" and buySell == "1") then		--卖涨
			local str = sys_format("K > %s",tempPrice+lastPrice)
			spEvent._SetFld("Index","1")
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","行权")
			str = sys_format("%s-(K-%s)*%s",amount,price,contract)
			spEvent._SetFld("Profit",str)
			spEvent._SetFld("ProfitStatus","亏损")
			_SendToClients(spEvent)

			spEvent._SetFld("Index","2")
			str = sys_format("%s<=K<=%s",tempPrice-lastPrice,lastPrice+tempPrice)
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","行权")
			str = sys_format("%s+(K-%s)*%s",amount,price,contract)
			spEvent._SetFld("Profit",str)
			spEvent._SetFld("ProfitStatus","盈利")
			_SendToClients(spEvent)	

			
			spEvent._SetFld("Index","3")
			str = sys_format("K < %s",tempPrice-lastPrice)
			spEvent._SetFld("SettlementPrice",str)
			spEvent._SetFld("Operation","行权")
			spEvent._SetFld("Profit",amount)
			spEvent._SetFld("ProfitStatus","盈利")
			_SendToClients(spEvent)				
		end
	else
		local log = sys_format("合约:%s没有行情，无法给出预期",issueCode)
		sendLog(log)
	end
_End
sendLog("初始化完成！")
