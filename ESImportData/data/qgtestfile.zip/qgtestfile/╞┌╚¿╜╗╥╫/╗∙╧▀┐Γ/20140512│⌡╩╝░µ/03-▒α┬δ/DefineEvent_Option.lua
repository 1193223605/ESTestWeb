﻿--Release version: 1.001.20140505
--------------------------------------事件定义-----------------------------------------------------

--XH--

_DefineEventObject SetIssueCodeInfo _AS _Input
	_DefFld("UnderlyingIssueCode",_String,10) --标的合约
	_DefFld("UnderlyingMonth",_String,20)
_End

_DefineEventObject DDXiaLa _AS _Output
	_DefFld("UnderlyingIssueCode",_String,10) --标的合约
	_DefKeyField("UnderlyingIssueCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

_DefineEventObject AddXiaLa _AS _Input
	_DefFld("UnderlyingIssueCode",_String,10) --标的合约
_End

_DefineEventObject DelXiaLa _AS _Input
	_DefFld("UnderlyingIssueCode",_String,10) --标的合约
_End	

-----

--添加期权标的
_DefineEventObject AddUnderlyingIssue _AS _Input
	_DefFld("UnderlyingIssueCode",_String,10) --标的合约
_End

--删除期权标的
_DefineEventObject DeleteUnderlyingIssue _AS _Input
	_DefFld("UnderlyingIssueCode",_String,10)
_End
--标的合约行情信息
_DefineEventObject UnderlyingIssuePriceInfo _AS _Output
	_DefFld("UnderlyingIssueCode",_String,10)	--标的合约
	_DefFld("UnderlyingIssueName",_String,32)	--标的名称
	_DefFld("LastPrice",_String,15)				--最新价
	_DefFld("Ratio",_String,15)					--涨跌幅
	_DefFld("BidPrice1",_String,15)
	_DefFld("BidQty1",_String,15)
	_DefFld("AskPrice1",_String,15)
	_DefFld("AskQty1",_String,15)
	_DefFld("ExpirationDate",_String,15)	--到期日
	_DefFld("RemainDay",_Int,4)				--剩余天数
	_DefFld("Flag",_String,1)
	
	_DefKeyField("UnderlyingIssueCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End
--标的合约存储DD
_DefineEventObject UnderlyingIssueSave _AS _Output
	_DefFld("UnderlyingIssueCode",_String,10)	--标的合约
	
	_DefKeyField("UnderlyingIssueCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--分时图显示,单击期权标的合约信息表
_DefineEventObject OnClickShowChartIn _AS _Input
	_DefFld("UnderlyingIssueCode",_String,20)	--标的合约
		
_End

_DefineEventObject OnClickShowChartOut _AS _Output
	_DefFld("IssueCode",_String,20)
	_DefFld("DataTime",_String,20)
	_DefFld("LastPrice",_String,15)
	_DefFld("_TimeKey",_String,20)
	
	_DefKeyField("UnderlyingIssueCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventMinuteType)
	_SetDataInterval(1)
_End

--分钟K线
_DefineEventObject k1mEvent _AS _Input
	_DefFld("Date",_String ,8);
	_DefFld("Time",_String ,6);
	_DefFld("DateTime",_String ,14);
	_DefFld("OpenPrice",_String,8);
	_DefFld("HighPrice",_String,8);
	_DefFld("LowPrice",_String,8);
	_DefFld("ClosePrice",_String,8);
	_DefFld("Volume",_String,15);
	_DefFld("OpenInterest",_String,15);
	_DefFld("ClearingPrice",_String,8);
	_DefFld("IssueCode",_String ,9);
	_DefFld("MarketCode",_String,1);
	_DefFld("Amount",_String,15);
	_DefFld("Zero",_Int,4);
	_DefFld("BidPrice",_String,8);
	_DefFld("AskPrice",_String,8);

	--_DefKeyField("Date");
	--_DefKeyField("IssueCode");
	--_DefKeyField("MarketCode");
	--_SetBufferedFlag(2);
	--_SetDataType(_EventMinuteType);
	--_SetDataInterval(1);
_End

_DefineEventObject k1MEvent _AS _Output
	_DefFld("Date",_String ,8);
	_DefFld("Time",_String ,6);
	_DefFld("DateTime",_String ,14);
	_DefFld("OpenPrice",_String,8);
	_DefFld("HighPrice",_String,8);
	_DefFld("LowPrice",_String,8);
	_DefFld("ClosePrice",_String,8);
	_DefFld("Volume",_String,15);
	_DefFld("OpenInterest",_String,15);
	_DefFld("ClearingPrice",_String,8);
	_DefFld("IssueCode",_String ,9);
	_DefFld("MarketCode",_String,1);
	_DefFld("Amount",_String,15);
	_DefFld("Zero",_Int,4);
	_DefFld("BidPrice",_String,8);
	_DefFld("AskPrice",_String,8);

	_DefKeyField("Date");
	_DefKeyField("IssueCode");
	_DefKeyField("MarketCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventMinuteType);
	_SetDataInterval(1);
_End
------期权计算器
--理论价格计算
_DefineEventObject CalcOptionParameterIn _AS _Input
	_DefFld("UnderlyingPrice",_String,15)	--标的价格
	_DefFld("ExercisePrice",_String,15)		--行权价
	_DefFld("DaysUntilExpiration",_Int,4)	--剩余天数
	_DefFld("InterestRates",_String,15)		--无风险收益率
	_DefFld("DividendYield",_String,15)		--股息年化收益率
	_DefFld("Volatility",_String,15)		--波动率
	_DefFld("Rounding",_String,15)			--保留小数位
_End

_DefineEventObject CalcOptionParameterOut _AS _Output
	--看涨期权
	_DefFld("CTheoreticPrice",_String,15)	--理论价
	_DefFld("CDelta",_String,15)
	_DefFld("CGamma",_String,15)
	_DefFld("CGamma1",_String,15)
	_DefFld("CVega",_String,15)
	_DefFld("CTheta",_String,15)
	_DefFld("CRho",_String,15)
	--看跌期权
	_DefFld("PTheoreticPrice",_String,15)	--理论价
	_DefFld("PDelta",_String,15)
	_DefFld("PGamma",_String,15)
	_DefFld("PGamma1",_String,15)
	_DefFld("PVega",_String,15)
	_DefFld("PTheta",_String,15)
	_DefFld("PRho",_String,15)
	
	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

--隐含波动率计算
_DefineEventObject CalcOptionVolatilityIn _AS _Input
	_DefFld("BUnderlyingPrice",_String,15)	--标的价格
	_DefFld("BExercisePrice",_String,15)		--行权价
	_DefFld("BDaysUntilExpiration",_Int,4)	--剩余天数
	_DefFld("BInterestRates",_String,15)		--无风险收益率
	_DefFld("BDividendYield",_String,15)		--股息年化收益率
	_DefFld("BRounding",_String,15)			--保留小数位
	_DefFld("CallPut",_String,15)			--看涨、看跌
	_DefFld("BTheoreticPrice",_String,15)	--市场价

_End

_DefineEventObject CalcOptionVolatilityOut _AS _Output
	_DefFld("Volatility",_String,15)		--波动率
	
	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End



--参数设置In
_DefineEventObject ParameterSetIn _AS _Input
	_DefFld("InterestRates",_String,15)	--无风险利率
	_DefFld("Volatility",_String,15)	--波动率
	_DefFld("DividendYield",_String,15)	--股息年化收益率
_End

--参数设置Out
_DefineEventObject ParameterSetOut _AS _Output
	_DefFld("InterestRates",_String,15)	--无风险利率
	_DefFld("Volatility",_String,15)	--波动率
	_DefFld("DividendYield",_String,15)	--股息年化收益率
	
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End
--4个期货合约OUT
_DefineEventObject GetIFOut _AS _Output
	_DefFld("IFIssueCurrent",_String,15)		--当月
	_DefFld("IFIssueNextMonth",_String,15)		--次月
	_DefFld("IFIssueSeasonMonth",_String,15)	--季月
	_DefFld("IFIssueNextSeason",_String,15)		--隔季
	
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End
--期权信息
_DefineEventObject GetOptionInfoOut _AS _Output
	_DefFld("IssueCode",_String,20)
	_DefFld("ExpirationDate",_String,15)
	
	_DefKeyField("IssueCode");
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End


--查询沪深300行情
_DefineEventObject GetHS300Price _AS _Output
	_DefFld("HS300Price",_String,15)
_End

--手动查询沪深300行情
_DefineEventObject GetHS300PriceNow _AS _Input
	_DefFld("HS300Price",_String,15)
_End


--回调投机预期盈亏
_DefineEventObject OnClickOKSpeculate _AS _Input
	_DefFld("BuySell",_String,15)
	_DefFld("IssueCode",_String,35)
_End

--发送投机预期盈亏
_DefineEventObject ExpectedProfit _AS _Output
	_DefFld("Index",_String,1)
	_DefFld("SettlementPrice",_String,50)
	_DefFld("Operation",_String,50)
	_DefFld("Profit",_String,50)
	_DefFld("ProfitStatus",_String,50)
	_DefKeyField("Index")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)	
_End


--手动交易 期权合约信息
_DefineEventObject OptionIssueCodeInfo _AS _Output
	_DefFld("Num",_Int,2)	--序号
	
	_DefFld("ExercisePrice",_String,15)	--行权价
	_DefFld("IssueCode1",_String,20)	--看涨期权
	_DefFld("LastPrice1",_String,15)	--最新价
	_DefFld("Ratio1",_String,15)		--涨跌幅
	_DefFld("BidPrice1",_String,15)		--买一价
	_DefFld("AskPrice1",_String,15)		--卖一价
	_DefFld("Delta1",_String,15)		--Delta
	_DefFld("Theta1",_String,15)		--Theta
	
	_DefFld("IssueCode2",_String,20)	--看跌期权
	_DefFld("LastPrice2",_String,15)	--最新价
	_DefFld("Ratio2",_String,15)		--涨跌幅
	_DefFld("BidPrice2",_String,15)		--买一价
	_DefFld("AskPrice2",_String,15)		--卖一价
	_DefFld("Delta2",_String,15)		--Delta
	_DefFld("Theta2",_String,15)		--Theta
	_DefFld("Gamma",_String,15)			--Gamma
	_DefFld("Vega",_String,15)			--Vega
	_DefFld("Rho",_String,15)			--Rho
	
	_DefKeyField("IssueCode1")
	_DefKeyField("IssueCode2")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

-----------------套利向导
--选择套利方式
_DefineEventObject SelectArbitrageType _AS _Input
	_DefFld("ArbitrageType",_String,2)	--套利方式
_End
--套利组合详情
_DefineEventObject ArbitrageInfo _AS _Output
	_DefFld("ArbitrageID",_String,32)	--套利关系ID
	_DefFld("IssueCode1",_String,20)	--第一腿合约
	_DefFld("Coefficient1",_String,10)		--第一腿系数
	_DefFld("IssueCode2",_String,20)	--第二腿合约
	_DefFld("Coefficient2",_String,10)		--第二腿系数
	_DefFld("IssueCode3",_String,20)	--第三腿合约
	_DefFld("Coefficient3",_String,10)		--第三腿系数
	_DefFld("IssueCode4",_String,20)	--第四腿合约
	_DefFld("Coefficient4",_String,10)		--第四腿系数
	_DefFld("Spread",_String,15)		--价差
	_DefFld("Yield",_String,15)			--收益率
	_DefFld("YearYield",_String,15)		--年化收益率
	_DefFld("BuySell1",_String,6)		--第一腿合约买卖
	_DefFld("BuySell2",_String,6)		--第二腿合约买卖
	_DefFld("BuySell3",_String,6)		--第三腿合约买卖
	_DefFld("BuySell4",_String,6)		--第四腿合约买卖
	_DefFld("ArbitrageType",_String,2)	--套利方式
	_DefFld("RemainDay",_String,10)		--到期剩余日
	
	_DefKeyField("ArbitrageID")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End
--立即下单
_DefineEventObject QuickArbOrder _AS _Input
	_DefFld("ArbitrageID",_String,32)	--套利关系ID
	_DefFld("ArbitrageType",_String,2)	--套利方式
	_DefFld("IssueCode1",_String,20)	--第一腿合约
	_DefFld("IssueCode2",_String,20)	--第二腿合约
	_DefFld("IssueCode3",_String,20)	--第三腿合约
	_DefFld("IssueCode4",_String,20)	--第四腿合约
	_DefFld("Quantity",_Int,4)		--组合开仓份数
	_DefFld("Spread",_String,15)		--当前价差
	
_End


--单笔下单
_DefineEventObject SingleOrder _AS _Input
	_DefFld("OrderType",_String,64)			--投机、套利、套保 "S","H","A"
	_DefFld("Flag",_String,2)				--看多:"KD",看空:"KK",平盘:"PP",套保多:"DT",套保空:"KT",套利："PJ","JD","FZ","TX","XX","RL"
	_DefFld("IssueCode",_String,20)			--合约
	_DefFld("IssueCode2",_String,20)		--平盘用到
	_DefFld("IssueCode3",_String,20)		--平盘用到
	_DefFld("Quantity",_Int,4)				--组合开仓份数
	_DefFld("Quote",_String,15)				--盘口类型 如AskPrice1
	_DefFld("BuySell",_String,1)			--买卖 买："3" 卖："1"
	_DefFld("OpenClose",_Int,1)				--开平 开：0 平：1
	_DefFld("Price",_String,10)				--价格
_End


--生成条件单
_DefineEventObject CreateArbCondition _AS _Input
	_DefFld("ArbitrageID",_String,32)	--套利关系ID
	_DefFld("ArbitrageType",_String,2)	--套利方式
	_DefFld("IssueCode1",_String,20)	--第一腿合约
	_DefFld("IssueCode2",_String,20)	--第二腿合约
	_DefFld("IssueCode3",_String,20)	--第三腿合约
	_DefFld("IssueCode4",_String,20)	--第四腿合约
	_DefFld("OpenFlag",_String,10)		--开仓比较符
	_DefFld("OpenSpread",_String,10)	--开仓价差
	_DefFld("CloseFlag",_String,10)		--平仓比较符
	_DefFld("CloseSpread",_String,10)	--平价价差
	_DefFld("Quantity",_Int,4)		--组合开仓份数
	_DefFld("Spread",_String,15)		--当前价差
_End

--条件单
_DefineEventObject ArbConditionsEvent _AS _Output
	_DefFld("Selected",_String,1)	--选中标志
	_DefFld("ArbConditionNo",_String,32)	--条件单编号
	_DefFld("ArbitrageID",_String,32)		--套利关系ID
	_DefFld("Spread",_String,15)			--当前价差
	_DefFld("OpenCompare",_String,6)		--开仓比较符
	_DefFld("OpenThreshold",_String,10)		--开仓阀值
	_DefFld("CloseCompare",_String,6)		--平仓比较符
	_DefFld("CloseThreshold",_String,10)	--平仓阀值
	_DefFld("OrderUnit",_String,10)			--委托份数
	_DefFld("IssueCode1",_String,20)
	_DefFld("IssueCode2",_String,20)
	_DefFld("IssueCode3",_String,20)
	_DefFld("IssueCode4",_String,20)
	_DefFld("ConditionStatus",_String,12)	--状态:未执行,执行中,执行完成
	_DefFld("OpenFld",_String,6)		--开仓与否:已开,未开
	_DefFld("Flag",_String,1)	--显示标志

	
	_DefKeyField("ArbConditionNo")
	_DefKeyField("ArbitrageID")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--选中条件单
_DefineEventObject SelectArbConditions _AS _Input
	_DefFld("Selected",_String,1)	--选中标志 "1"选中 "0"未选中
	_DefFld("ArbConditionNo",_String,32)	--条件单号
	_DefFld("ArbitrageID",_String,32)		--套利关系ID
	
_End
--启动条件单
_DefineEventObject StartArbConditions _AS _Input

_End
--停止条件单
_DefineEventObject StopArbConditions _AS _Input

_End
--删除条件单
_DefineEventObject DeleteArbConditions _AS _Input

_End

--修改条件单
_DefineEventObject UpdateArbCondition _AS _Input
	_DefFld("ArbConditionNo",_String,32)	--条件单号
	_DefFld("ArbitrageID",_String,32)		--套利关系ID
	_DefFld("OpenCompare",_String,6)		--开仓比较符
	_DefFld("OpenThreshold",_String,10)		--开仓阀值
	_DefFld("CloseCompare",_String,6)		--平仓比较符
	_DefFld("CloseThreshold",_String,10)	--平仓阀值
	_DefFld("OrderUnit",_String,10)			--委托份数
_End

--复制条件单
_DefineEventObject CopyArbCondition _AS _Input
	_DefFld("ArbConditionNo",_String,32)	--条件单号
	_DefFld("ArbitrageID",_String,32)		--套利关系ID
_End
-----------------------委托成交信息--------------------------------------
--委托信息
_DefineEventObject OrderEvent _AS _Output
	_DefFld("PortID",_String,48)		--组合编号
	_DefFld("UserID",_String,14)		--帐号
	_DefFld("IssueCode",_String ,20)	--期权合约
	_DefFld("IssueName",_String ,60)	--合约名称
	_DefFld("BuySell",_String ,8)		--买卖
	_DefFld("OpenClose",_String ,8)		--开平
	_DefFld("Quantity",_Int ,4)			--委托数量
	_DefFld("Price",_String ,8)			--委托价格
	_DefFld("ExecutionQuantity",_Int ,4)--成交量
	_DefFld("ExecutionValue",_Number,12)--成交金额
	_DefFld("WorkingQuantity",_Int ,4)	--挂单数量
	_DefFld("Status",_String ,12)		--状态
	_DefFld("OrderAcceptNo",_String,10)	--交易号
	_DefFld("OrderTime",_String,14)		--委托时间
	_DefFld("CorpCode",_String,20)		--委托号
	_DefFld("StatusFlag",_String,1)		--界面过滤
	_DefFld("Fee",_String,14)			--手续费
	_DefFld("Flag",_String,14)			--是否显示
	_DefFld("BAMapID",_String,14);
	_DefFld("BASubID",_String,20);
	_DefFld("MainRowFlag", _String, 1) 	--传1表示是折叠列表中的主行，2表示副行
	_DefFld("GroupFlag", _String, 48) 	--分组标记(填PortID)
	
	_DefKeyField("CorpCode");
	_DefKeyField("PortID");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--成交信息
_DefineEventObject ExecutEvent _AS _Output
	_DefFld("PortID",_String,48)		--组合编号
	_DefFld("UserID",_String,14)		--帐号
	_DefFld("IssueCode",_String ,20)	--期权合约
	_DefFld("IssueName",_String ,60)	--合约名称
	_DefFld("BuySell",_String ,8)		--买卖
	_DefFld("OpenClose",_String ,15)	--开平仓
	_DefFld("Quantity",_Int ,4)			--成交数量
	_DefFld("ExecutionPrice",_String,8)	--成交价格
	_DefFld("ExecutionTime",_String,14)	--成交时间
	_DefFld("ExecutionNo",_String,8)	--成交号
	_DefFld("BAMapID",_String,14)		--交易子账户
	_DefFld("Fee",_String,14)			--交易费用
	_DefFld("Flag",_String,1)		--显示标志
	_DefFld("OrderAcceptNo",_String,10)	--交易号
	_DefFld("UniqueKeyCode",_String,20)	--不会重复key
	_DefFld("BASubID",_String,20)
	_DefFld("MainFlag", _String, 1) --传1表示是折叠列表中的主行，2表示副行
	_DefFld("PortGroupFlag", _String, 48) --分组标记(填PortID)
	
	_DefKeyField("PortID")
	_DefKeyField("UniqueKeyCode")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType)

_End

--改价
_DefineEventObject AmendOrder _AS _Input
	_DefFld("IssueCode",_String,20)
	_DefFld("CorpCode",_String,32)	--内部委托号
	_DefFld("PriceType",_String,10)	--价格盘口，买一价、最新价、卖一价
	_DefFld("PriceBPS",_Int,2)	--价格BPS
_End
--撤单
_DefineEventObject CancelOrder _AS _Input
	_DefFld("CorpCode", _String,32);	--内部委托号
_End

--资金信息
_DefineEventObject FundStatus _AS _Output
	_DefFld("Item",_String,20)			--动态权益、可用资金、头寸金额、浮动盈亏、冻结资金
	_DefFld("StockAccount",_String,20)	--证券账户
	_DefFld("FutureAccount",_String,20)	--期货账户
	_DefFld("Row",_Int,4)				--行号
	
	_DefKeyField("Row")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--提示信息
_DefineEventObject SystemLog _AS _Output
	_DefFld("LogTime",_String,12)
	_DefFld("LogMessage",_Meta,4)
	
	_DefKeyField("LogTime")
	_DefKeyField("LogMessage")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--我的持仓
_DefineEventObject PositionInfo _AS _Output
	_DefFld("PortID",_String,48)		--组合编号
	_DefFld("PortName",_String,48)		--组合类型
	_DefFld("IssueCode",_String ,20)	--合约代码
	_DefFld("IssueName",_String ,60)	--合约名称
	_DefFld("LongShort",_String ,8)		--多空
	_DefFld("Quantity",_String ,6)		--持仓数量
	_DefFld("ValQuantity",_String ,6)	--可用数量
	_DefFld("Cost",_String,12)			--成本价
	_DefFld("LastPrice",_String,12)		--最新价
	_DefFld("PL",_String,18)			--浮动盈亏
	_DefFld("MarketValue",_String,18)	--成本市值
	_DefFld("CurMarketValue",_String,18)--当前市值
	_DefFld("OpenFare",_String,8)		--开仓费用
	_DefFld("EstCloseFare",_String,8)	--预计平仓费用
	_DefFld("ExpirationDate",_String,8)	--到期日

	_DefFld("Delta",_String,8)
	_DefFld("Theta",_String,8)
	_DefFld("Vaga",_String,8)
	_DefFld("Gamma",_String,8)
	_DefFld("Rho",_String,8)

	_DefFld("BAMapID",_String,14)		--交易子账户
	_DefFld("UniqueKeyCode",_String,50)	--不会重复key
	_DefFld("BASubID",_String,20)
	_DefFld("MarginFlag", _String, 1) --传1表示是折叠列表中的主行，2表示副行
	
	_DefKeyField("PortName")
	_DefKeyField("UniqueKeyCode")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType)
_End

--我的持仓控件
_DefineEventObject PosControl _AS _Input
	_DefFld("RefreshPos",_String,2)
_End
--我的持仓指标
_DefineEventObject PosOptionIndex _AS _Output
	_DefFld("Delta",_String,8)
	_DefFld("Theta",_String,8)
	_DefFld("Vaga",_String,8)
	_DefFld("Gamma",_String,8)
	_DefFld("Rho",_String,8)
	
	_DefFld("IF1LongPos",_String,8)
	_DefFld("IF2LongPos",_String,8)
	_DefFld("IF3LongPos",_String,8)
	_DefFld("IF4LongPos",_String,8)
	_DefFld("IF1ShortPos",_String,8)
	_DefFld("IF2ShortPos",_String,8)
	_DefFld("IF3ShortPos",_String,8)
	_DefFld("IF4ShortPos",_String,8)
_End

--单笔平仓
_DefineEventObject SingleCloseEvent _AS _Input
	_DefFld("IssueCode", _String, 20)	--合约代码
	_DefFld("BASubID", _String, 300)	--BASubID
	_DefFld("PriceType", _String, 15)	--下单价格
	_DefFld("Quantity", _Int, 12)		--下单数量
_End
--组合平仓
_DefineEventObject GroupCloseEvent _AS _Input
	_DefFld("PortID", _String, 48)
	_DefFld("PortName", _String, 48)
_End

--单笔委托
_DefineEventObject VQueryCloseFund _AS _Input
	_DefFld("BAMapID",_String,32)		--BAMapID
    _DefFld("IssueCode", _String, 20)
	_DefFld("CombinCode", _String, 100)
_End

_DefineEventObject VBasePriceEvent _AS _Output
	_DefFld("IssueCode",_String ,20);				--合约
	_DefFld("IssueShortName",_String ,30);		--合约名称
	_DefFld("LastPrice",_String,15);       			--最新
	_DefFld("LastVolume",_String,15);      	    	--现量
	_DefFld("BidPrice_1",_String,15);      			--买价
	_DefFld("BidQty_1",_String,15);        	    	--买量
	_DefFld("AskPrice_1",_String,15);  				--卖价
	_DefFld("AskQty_1",_String,15);        			--卖量
	_DefFld("BidPrice_2",_String,15);      			--买价
	_DefFld("BidQty_2",_String,15);        	    	--买量
	_DefFld("AskPrice_2",_String,15);  				--卖价
	_DefFld("AskQty_2",_String,15);        			--卖量
	_DefFld("BidPrice_3",_String,15);      			--买价
	_DefFld("BidQty_3",_String,15);        	    	--买量
	_DefFld("AskPrice_3",_String,15);  				--卖价
	_DefFld("AskQty_3",_String,15);        			--卖量
	_DefFld("BidPrice_4",_String,15);      			--买价
	_DefFld("BidQty_4",_String,15);        	    	--买量
	_DefFld("AskPrice_4",_String,15);  				--卖价
	_DefFld("AskQty_4",_String,15);        			--卖量
	_DefFld("BidPrice_5",_String,15);      			--买价
	_DefFld("BidQty_5",_String,15);        	    	--买量
	_DefFld("AskPrice_5",_String,15);  				--卖价
	_DefFld("AskQty_5",_String,15);        			--卖量
	_DefFld("UpperLimitPrice",_String,20);			--涨停价
	_DefFld("LowerLimitPrice",_String,20);			--跌停价
	_DefFld("TotalAskQty",_String,20);			--总卖量
	_DefFld("TotalBidQty",_String,20);			--总买量

	_DefKeyField("IssueCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

_DefineEventObject VFundReply _AS _Output
    _DefFld("IssueCode", _String, 20)
    _DefFld("AvlibFund", _String, 20)
    _DefFld("AvlibOpenatQty", _String, 20)
    _DefFld("AvlibBuyCloseQty", _String, 20)
    _DefFld("AvlibSellCloseQty", _String, 20)

    _DefKeyField("IssueCode")
    _SetBufferedFlag(2) -- use map mode
_End

_DefineEventObject VFireEvent _AS _Input
	_DefFld("CombinCode",_String,100)
	_DefFld("BAMapID",_String,32)		--BAMapID,平仓应用
    _DefFld("IssueCode", _String, 20)
    _DefFld("BuySell", _String, 1)
    _DefFld("OpenClose", _String, 1)
	_DefFld("Price", _String, 13)
    _DefFld("Quantity", _Int, 8)
_End