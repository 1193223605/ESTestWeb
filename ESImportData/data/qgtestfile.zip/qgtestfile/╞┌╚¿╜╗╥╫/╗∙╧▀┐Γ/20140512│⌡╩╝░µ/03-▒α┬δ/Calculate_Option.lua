﻿--Release version: 1.001.20140505
--计算看涨期权理论价
function calCallOption(UnderlyingPrice, ExercisePrice, tIME, DividendYield,Volatility,InterestRates,Rounding)
	if tIME == 0 then
		return 0
	else
		local done = caldOne(UnderlyingPrice, ExercisePrice, tIME, DividendYield,Volatility,InterestRates)
		local dtwo = caldTwo(UnderlyingPrice, ExercisePrice, tIME, DividendYield,Volatility,InterestRates)
		local p1 = _dsl_cdf_ugaussian_P(done)
		local p2 = _dsl_cdf_ugaussian_P(dtwo)
		local calloption=sys_exp(-InterestRates*tIME)*(UnderlyingPrice*p1-ExercisePrice*p2)
		local format = sys_format("%%.%df",Rounding)
		calloption = sys_format(format,calloption)
		return calloption
	end
end
--计算看跌期权理论价
function calPutOption(UnderlyingPrice, ExercisePrice, tIME, DividendYield,Volatility,InterestRates,Rounding)
	if tIME ==0 then
		return 0
	else
		local done = caldOne(UnderlyingPrice, ExercisePrice, tIME, DividendYield, Volatility,InterestRates);
		local dtwo = caldTwo(UnderlyingPrice, ExercisePrice, tIME, DividendYield, Volatility,InterestRates);
		local p1 = _dsl_cdf_ugaussian_P(-done);
		local p2 = _dsl_cdf_ugaussian_P(-dtwo);
		local putoption=sys_exp(-InterestRates*tIME)*(ExercisePrice*p2-UnderlyingPrice*p1)
		local format = sys_format("%%.%df",Rounding)
		putoption = sys_format(format,putoption)
		return putoption
	end
end

--计算看涨期权的delta
function calCallDelta(UnderlyingPrice, ExercisePrice, tIME, DividendYield,Volatility, InterestRates,Rounding)
	local calldelta=0
	if tIME==0 then
		calldelta=1
	else
		local done=caldOne(UnderlyingPrice, ExercisePrice, tIME, DividendYield,Volatility, InterestRates)
		calldelta=_dsl_cdf_ugaussian_P(done)
	end
	local format = sys_format("%%.%df",Rounding)
	calldelta = sys_format(format,calldelta)
	return calldelta
end

--计算看跌期权的delta
function calPutDelta(UnderlyingPrice, ExercisePrice, tIME, DividendYield,Volatility, InterestRates,Rounding)
	local putdelta=0
	if tIME~=0 then
		local done=caldOne(UnderlyingPrice,ExercisePrice,tIME, DividendYield,Volatility, InterestRates);
		local p1=_dsl_cdf_ugaussian_P(done)
		putdelta=p1-1;
	end
	local format = sys_format("%%.%df",Rounding)
	putdelta = sys_format(format,putdelta)
	return putdelta
end

--计算Gamma
function calGamma(UnderlyingPrice, ExercisePrice, Time, DividendYield,Volatility,InterestRates,Rounding)
	if Time==0 then
		local gamma=0;
		return gamma
	else
		local done=caldOne(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
		local pdens=normDensityFun(done)
		local a=UnderlyingPrice*Volatility*sys_pow(Time,0.5);
		local gamma=pdens/a
		local format = sys_format("%%.%df",Rounding)
		gamma = sys_format(format,gamma)
		return gamma
	end
end

--计算Vega
function calVega(UnderlyingPrice, ExercisePrice, Time, DividendYield,Volatility,InterestRates,Rounding)
	if Time==0 then
		return 0
	end
	local vega=0
	local done=caldOne(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
	local dtwo=caldTwo(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
	local pdens=normDensityFun(done);
	vega=0.01*UnderlyingPrice*sys_pow(Time,0.5)*pdens;
	local format = sys_format("%%.%df",Rounding)
	vega = sys_format(format,vega)
	return vega;
end
--计算看涨期权Theta
function calCallTheta(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	if Time==0 then
		local theta=-InterestRates*ExercisePrice
		local calltheta=theta/360.0
		return calltheta
	end
	local done=caldOne(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
	local dtwo=caldTwo(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
	
	local pdens=normDensityFun(done);
	local p2=_dsl_cdf_ugaussian_P(dtwo)
	local theta=-(UnderlyingPrice * Volatility*pdens)/(2*sys_pow(Time,0.5))-InterestRates*ExercisePrice*p2*sys_exp(-InterestRates * Time)
	local callTheta = theta/360.0
	local format = sys_format("%%.%df",Rounding)
	callTheta = sys_format(format,callTheta)
	return callTheta
end
--计算看跌期权Theta
function calPutTheta(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	if Time==0 then
		return 0
	end
	local done=caldOne(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
	local dtwo=caldTwo(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
	
	local pdens=normDensityFun(done);
	local p2=_dsl_cdf_ugaussian_P(-dtwo)
	local theta=-(UnderlyingPrice * Volatility*pdens)/(2*sys_pow(Time,0.5))+InterestRates*ExercisePrice*p2*sys_exp(-InterestRates * Time)
	local putTheta = theta/360.0
	local format = sys_format("%%.%df",Rounding)
	putTheta = sys_format(format,putTheta)
	return putTheta
end
--计算看涨期权Rho
function calCallRho(UnderlyingPrice,ExercisePrice, Time,DividendYield,Volatility,InterestRates,Rounding)
	local dtwo=caldTwo(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
	local p2=_dsl_cdf_ugaussian_P(dtwo)
	local Rho=ExercisePrice*Time*p2*sys_exp(-InterestRates*Time)
	local callRho=0.01*Rho
	local format = sys_format("%%.%df",Rounding)
	callRho = sys_format(format,callRho)
	return callRho
end
--计算看跌期权Rho
function calPutRho(UnderlyingPrice, ExercisePrice,Time,DividendYield,Volatility,InterestRates,Rounding)
	local dtwo=caldTwo(UnderlyingPrice,ExercisePrice,Time,DividendYield,Volatility,InterestRates)
	local p2=_dsl_cdf_ugaussian_P(-dtwo)
	local Rho=-ExercisePrice*Time*p2*sys_exp(-InterestRates*Time)
	local putRho=0.01*Rho
	local format = sys_format("%%.%df",Rounding)
	putRho = sys_format(format,putRho)
	return putRho
end

--计算正太分布表
function normDensityFun(x)
	local normdensity=1/(sys_pow(2*3.14159265358979,0.5))*sys_exp(-sys_pow(x,2)/2);
	return normdensity;
end

function caldOne(UnderlyingPrice, ExercisePrice, tIME, DividendYield, Volatility,InterestRates)
	local done=0
	if tIME~=0 then
		done = (sys_log(UnderlyingPrice / ExercisePrice) + (InterestRates-DividendYield + 0.5 * sys_pow(Volatility ,2)) * tIME)/(Volatility*(sys_pow(tIME ,0.5)))
	end
	return done
end

function caldTwo(UnderlyingPrice, ExercisePrice, tIME, DividendYield,Volatility,InterestRates)
    local done=caldOne(UnderlyingPrice, ExercisePrice, tIME, DividendYield, Volatility, InterestRates);
    local dtwo=done-Volatility*sys_pow(tIME,0.5);
    return dtwo
end

--计算看涨期权的隐含波动率
function calImpliedCallVolatity(UnderlyingPrice,ExercisePrice,Time,Dividend,CallPrice,Interest,Rounding)
	local high = 50;
	local low = 0;
	while high - low > 0.000001 do
		local cp=calCallOption(UnderlyingPrice,ExercisePrice,Time,Dividend,(high+low)/2,Interest,Rounding);
		local nn=cp-CallPrice;
		--local log=sys_format("价差[%s]",nn);
		--_WriteAplLog(log)
		if nn>0 then
		--_WriteAplLog("启动IF")
			high=(high+low)/2;
		else
			low=(high+low)/2;
		end

	end
	return (high+low)/2
end

--计算看跌期权的隐含波动率
function calImpliedPutVolatity(UnderlyingPrice,ExercisePrice,Time,Dividend,PutPrice,Interest,Rounding)
	local high=50;
	local low=0;
	while high-low>0.000001 do
		local cp=calPutOption(UnderlyingPrice, ExercisePrice, Time,  Dividend,(high+low)/2,Interest,Rounding);
		--local log1=sys_format("迭代计算价格[%s],PutP[%s]",cp,PutPrice)
		--_WriteAplLog(log1)
		local nn=cp-PutPrice
		if nn>0 then
			--_WriteAplLog("启动IF")
			high=(high+low)/2;
		else
			low=(high+low)/2;
		end
	end
	return (high+low)/2
end


