﻿--Release version: 1.001.20140505
--单笔委托处理函数
_OnEventDefined(VQueryCloseFund qfEvent)							--平仓查询资金状况回调
	local issueCode = qfEvent._GetFld("IssueCode")
	local BAMapID = qfEvent._GetFld("BAMapID")
	local CombinCode = qfEvent._GetFld("CombinCode")
	local market = _PosIssueMarketTable[issueCode]
	_DD = 0
	if market then
		_QueryIssue = issueCode
		_PosRegisterPrice(issueCode)

		if market=="1" or  market=="2"  then --股票
			BAMapID = spStockBAMapID
		else      --期货
			BAMapID = spFutureBAMapID
		end
		local accountCode = _PosBAMapAccount[BAMapID]
		if _PosPriceTable[_QueryIssue] then
			sendFundReplyClose(BAMapID,accountCode,CombinCode)
		else
			_DD = 1
			_QueryTable["CombinCode"] = CombinCode
			_QueryTable["AccountCode"] = accountCode
			_QueryTable["BAMapID"] = BAMapID
		end
	end
_End

_OnEventDefined(VFireEvent fire,sessionID)						--单笔委托
	_WriteAplLog("VFireEvent...");

	local CombinCode = fire._GetFld("CombinCode");
	local BAMapID = fire._GetFld("BAMapID");
	local issueCode = fire._GetFld("IssueCode");
	local bs = fire._GetFld("BuySell");
	local oc = fire._GetFld("OpenClose");

	if spFutureBAMapID ~= "" then
		local flag = 1
		local temp = sys_sub(issueCode,1,2);
		if not _PosPriceTable[issueCode] then
		   flag = 0
		end
		local market = _PosIssueMarketTable[issueCode]
		if market and flag==1 then
			if market=="1" or  market=="2" then --股票
				BAMapID = spStockBAMapID
			else
				BAMapID = spFutureBAMapID
			end
		else
			flag = 0
			sendLog("合约不存在或者没有行情")
		end
		if flag ~= 0 then
			--非上期若选择了平今指令，自动发出为平仓
			oc = oc.getNumberValue()	--add
			if _PosIssueMarketTable[issueCode] ~= "4" and oc == 2 then
				oc = 1
			end

			local createPortIDFlag = ""
			if bs == "3" and oc == 0 then
				if sys_sub(issueCode,8,8) == "C" then
					createPortIDFlag = "KD"
				elseif  sys_sub(issueCode,8,8) == "P" then
					createPortIDFlag = "KK"
				end
			elseif bs == "1" and oc == 0 then
				if sys_sub(issueCode,8,8) == "C" then
					createPortIDFlag = "KK"
				elseif  sys_sub(issueCode,8,8) == "P" then
					createPortIDFlag = "KD"
				end
			elseif oc == 1 then
				createPortIDFlag = "PP"
			end
			local basubID = ""
			if CombinCode == "手动交易" then
				basubID = createPortID("S",createPortIDFlag)
			end

			if oc == 0 then
				if CombinCode == "手动交易" then
					basubID = bs..basubID
				else
					basubID = bs..CombinCode
				end
			else
				if bs == "1" then
					basubID = "3" .. CombinCode
				else
					basubID = "1" .. CombinCode
				end
			end

			local Price = fire._GetFld("Price");
			local quantity = fire._GetFld("Quantity");
			local logs = sys_format("VFireEvent:basubID:%s,BAMapID:%s, issue:%s,BuySell:%s,OpenClose:%s,quantity:%d",basubID,BAMapID,issueCode,bs,oc,quantity)
			_WriteAplLog(logs)
			log = sys_format("组合号:[%s],BaMapID:[%s],下单合约:[%s],下单数量:[%s],价格:[%s],方向:[%s]",CombinCode,BAMapID,issueCode,quantity,Price,bs)
			sendLog(log)
			if BAMapID ~= "" then
				local ret = PosSubmitSingleOrder(BAMapID,basubID,issueCode,bs,oc,Price,quantity,0,nil);
				if ret.Result then
					--local log = sys_format("下单完成")
					--sendLog(log)
				else
					local log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
					_WriteAplLog(log)
					log = sys_format("下单错误原因：[%s]",ret.Reason)
					sendLog(log)
				end
			end
		end
	else
		sendLog("单笔委托：请确认资金账号")
	end
_End;
_OnEventPrice(_PriceName="futurePrice", {} , DTSPrice price);
	--单笔委托行情信息显示
	local issueCode = price.getIssueCode();
	local Flag = 0
	if not _Querylist[issueCode] then
		_Querylist[issueCode] = 1
		Flag = 1
	end

	if _QueryIssue == issueCode or Flag == 1 then
		if _PosPriceTable[issueCode] then
			local PriceInfo = _PosPriceTable[issueCode]
			local issueName = _PosIssueNameTable[issueCode]
			local LastPrice = PriceInfo.LastPrice or 0
			local AskPrice1 = PriceInfo.AskPrice1 or 0
			local AskPrice2 = PriceInfo.AskPrice2 or 0
			local AskPrice3 = PriceInfo.AskPrice3 or 0
			local AskPrice4 = PriceInfo.AskPrice4 or 0
			local AskPrice5 = PriceInfo.AskPrice5 or 0
			local BidPrice1 = PriceInfo.BidPrice1 or 0
			local BidPrice2 = PriceInfo.BidPrice2 or 0
			local BidPrice3 = PriceInfo.BidPrice3 or 0
			local BidPrice4 = PriceInfo.BidPrice4 or 0
			local BidPrice5 = PriceInfo.BidPrice5 or 0
			local AskQuantity1 = PriceInfo.AskQuantity1 or 0
			local AskQuantity2 = PriceInfo.AskQuantity2 or 0
			local AskQuantity3 = PriceInfo.AskQuantity3 or 0
			local AskQuantity4 = PriceInfo.AskQuantity4 or 0
			local AskQuantity5 = PriceInfo.AskQuantity5 or 0
			local BidQuantity1 = PriceInfo.BidQuantity1 or 0
			local BidQuantity2 = PriceInfo.BidQuantity2 or 0
			local BidQuantity3 = PriceInfo.BidQuantity3 or 0
			local BidQuantity4 = PriceInfo.BidQuantity4 or 0
			local BidQuantity5 = PriceInfo.BidQuantity5 or 0
			local UpLimitPrice = PriceInfo.UpLimitPrice or 0
			local LowLimitPrice = PriceInfo.LowLimitPrice or 0
			local fttotalAskQty = AskQuantity1 + AskQuantity2 + AskQuantity3 + AskQuantity4 + AskQuantity5
			if fttotalAskQty ~= 0 then
				fttotalAskQty = sys_format("%d",fttotalAskQty);
			else
				fttotalAskQty = "-"
			end
			PriceInfo.totalAskQty = fttotalAskQty
			local fttotalBidQty = BidQuantity1 + BidQuantity2 + BidQuantity3 + BidQuantity4 + BidQuantity5
			if fttotalBidQty ~= 0 then
				fttotalBidQty = sys_format("%d", fttotalBidQty);
			else
				fttotalBidQty = "-"
			end
			--hongwen.kang20120508
			if LastPrice == 0 then
				LastPrice = "-"
			end
			if AskPrice1 == 0 then
				AskPrice1 = "-"
			end
			if AskPrice2 == 0 then
				AskPrice2 = "-"
			end
			if AskPrice3 == 0 then
				AskPrice3 = "-"
			end
			if AskPrice4 == 0 then
				AskPrice4 = "-"
			end
			if AskPrice5 == 0 then
				AskPrice5 = "-"
			end
			if BidPrice1 == 0 then
				BidPrice1 = "-"
			end
			if BidPrice2 == 0 then
				BidPrice2 = "-"
			end
			if BidPrice3 == 0 then
				BidPrice3 = "-"
			end
			if BidPrice4 == 0 then
				BidPrice4 = "-"
			end
			if BidPrice5 == 0 then
				BidPrice5 = "-"
			end
			PriceInfo.totalBidQty = fttotalBidQty
			local totalAskQty = PriceInfo.totalAskQty
			local totalBidQty = PriceInfo.totalBidQty
			AskQuantity1  = sys_format("%.0f",AskQuantity1)
			AskQuantity2  = sys_format("%.0f",AskQuantity2)
			AskQuantity3  = sys_format("%.0f",AskQuantity3)
			AskQuantity4  = sys_format("%.0f",AskQuantity4)
			AskQuantity5  = sys_format("%.0f",AskQuantity5)
			BidQuantity1  = sys_format("%.0f",BidQuantity1)
			BidQuantity2  = sys_format("%.0f",BidQuantity2)
			BidQuantity3  = sys_format("%.0f",BidQuantity3)
			BidQuantity4  = sys_format("%.0f",BidQuantity4)
			BidQuantity5  = sys_format("%.0f",BidQuantity5)
			local DTSEvent BaseEvent=_CreateEventObject("VBasePriceEvent");
			BaseEvent._SetFld("IssueCode",issueCode);
			BaseEvent._SetFld("IssueShortName",issueName);
			BaseEvent._SetFld("LastPrice",LastPrice);
			BaseEvent._SetFld("AskPrice_1",AskPrice1);
			BaseEvent._SetFld("AskPrice_2",AskPrice2);
			BaseEvent._SetFld("AskPrice_3",AskPrice3);
			BaseEvent._SetFld("AskPrice_4",AskPrice4);
			BaseEvent._SetFld("AskPrice_5",AskPrice5);
			BaseEvent._SetFld("BidPrice_1",BidPrice1);
			BaseEvent._SetFld("BidPrice_2",BidPrice2);
			BaseEvent._SetFld("BidPrice_3",BidPrice3);
			BaseEvent._SetFld("BidPrice_4",BidPrice4);
			BaseEvent._SetFld("BidPrice_5",BidPrice5);
			BaseEvent._SetFld("AskQty_1",AskQuantity1);
			BaseEvent._SetFld("AskQty_2",AskQuantity2);
			BaseEvent._SetFld("AskQty_3",AskQuantity3);
			BaseEvent._SetFld("AskQty_4",AskQuantity4);
			BaseEvent._SetFld("AskQty_5",AskQuantity5);
			BaseEvent._SetFld("BidQty_1",BidQuantity1);
			BaseEvent._SetFld("BidQty_2",BidQuantity2);
			BaseEvent._SetFld("BidQty_3",BidQuantity3);
			BaseEvent._SetFld("BidQty_4",BidQuantity4);
			BaseEvent._SetFld("BidQty_5",BidQuantity5);
			BaseEvent._SetFld("UpperLimitPrice",UpLimitPrice);
			BaseEvent._SetFld("LowerLimitPrice",LowLimitPrice);
			BaseEvent._SetFld("TotalAskQty",totalAskQty);
			BaseEvent._SetFld("TotalBidQty",totalBidQty);
			_SendToClients(BaseEvent);
		end
	end
_End

function sendFundReplyClose(BAMapID,AccountCode,CombinCode)		--单笔委托中资金关联信息显示
	_WriteAplLog("sendFundReply")

	local marketCode = _PosIssueMarketTable[_QueryIssue]
	if marketCode then
		local bailRatio = _PosGetBail(AccountCode, _QueryIssue)				--这里返回的是投机或者套保保证金率
		local AvailableFund = _PosFundStatus[AccountCode]["AvlFund"]		--可用资金
		local AvailableOpenQty = 0 														--可开仓数
		local AvailableBuyCloseQuantity = 0											--可平仓数/买
		local AvailableSellCloseQuantity = 0											--可平仓数/卖

		if _PosPriceTable[_QueryIssue] then
			local lastPrice = _PosPriceTable[_QueryIssue].LastPrice
			if lastPrice ~= 0 and lastPrice then
				lastPrice = lastPrice.getNumberValue()
				local contractSize = _PosIssueContractSizeTable[_QueryIssue]
				local availableOpenQuantity = AvailableFund / lastPrice / contractSize / bailRatio
				AvailableOpenQty = sys_floor(availableOpenQuantity)
				local log = sys_format("sendFundReply--IssueCode:%s,availableOpenQuantity:%s AvailableOpenQty:%s,AvlibFund:%s, contractSize:%s, lastPrice:%s, bailRatio:%s",
											_QueryIssue,availableOpenQuantity,AvailableOpenQty, AvailableFund, contractSize, lastPrice, bailRatio)
				--_WriteAplLog(log)
			end
		else
			_RegisterPrice(_IssueCode = _QueryIssue, _MarketCode = marketCode)
		end

		AvailableFund = sys_format("%.2f",_PosFundStatus[AccountCode]["AvlFund"])
		local qrylog = sys_format("sendFundReply--BAMapID:%s, AccountCode:%s, CombinCode:%s",
											BAMapID, AccountCode, CombinCode)
		--_WriteAplLog(qrylog)
		--取得多头可用数量
		local posKey = BAMapID .. ".3" ..CombinCode.. "." .. _QueryIssue
		if _PosPositionTable[posKey] then
			AvailableSellCloseQuantity = _PosPositionTable[posKey].AvlQuantity	--即可卖平数量
		end

		--取得空头可用数量
		posKey = BAMapID .. ".1" ..CombinCode.. "." .. _QueryIssue
		if _PosPositionTable[posKey] then
			AvailableBuyCloseQuantity = _PosPositionTable[posKey].AvlQuantity	--即可买平数量
		end



		DTSEvent fundReply = _CreateEventObject("VFundReply")
		fundReply._SetFld("IssueCode", _QueryIssue)
		fundReply._SetFld("AvlibFund", AvailableFund)
		AvailableOpenQty = sys_format("%.0f",AvailableOpenQty)
		AvailableBuyCloseQuantity = sys_format("%.0f",AvailableBuyCloseQuantity)
		AvailableSellCloseQuantity = sys_format("%.0f",AvailableSellCloseQuantity)
		qrylog = sys_format("sendFundReply--BAMapID:%s,CombinCode:%s,IssueCode:%s, AvlibFund:%s, AvlibOpenatQty:%s, AvlibBuyCloseQty:%s, AvlibSellCloseQty:%s",
											BAMapID,CombinCode,_QueryIssue, AvailableFund, AvailableOpenQty, AvailableBuyCloseQuantity, AvailableSellCloseQuantity)
		_WriteAplLog(qrylog)
		fundReply._SetFld("AvlibOpenatQty", AvailableOpenQty)
		fundReply._SetFld("AvlibBuyCloseQty", AvailableBuyCloseQuantity)
		fundReply._SetFld("AvlibSellCloseQty", AvailableSellCloseQuantity);
		_SendToClients(fundReply);
	end
end
