﻿_WriteAplLog("SecurityTrade L2C_S_Version:1.01.001.20200528")
--Release Version:1.01.001.20200528
--web行情源取LastPrice逻辑修改
--Release Version:1.01.001.20200307
--优化CUP占用高，缓存表的key应包含sessionID，应该是：sessionID_accountCode
--Release Version:1.01.001.20200121
--优化CUP占用高
--Release Version:1.01.001.20200116
--优化风控主管、专员等权限
--Release Version:1.01.001.20200114
--优化出入金划转一键生效逻辑
--Release Version:1.01.001.20200113
--优化访问数据库逻辑,改成新接口DTSDynamicSql
--Release Version:1.01.001.20200107
--优化买卖禁用一键生效逻辑
--Release Version:1.01.001.20190917
--当日资产增加抗跌风险度字段
--Release Version:1.01.001.20190910
--成交记录刷新卡顿优化
--Release Version:1.01.001.20190902
--强平无视禁用数量限制
--Release Version:1.01.001.20190826
--禁用数量相关
--Release Version:1.01.001.20190816
--修改历史成交获取不到印花费的bug
--Release Version:1.01.001.20190802
--科创版合约支持配置项设置
--Release Version:1.01.001.20190723
--支持科创版下单
--Release Version:1.01.001.20190613
--增加配置项 ShowAlert (当日触警/历史触警) 1显示 0隐藏
--ShowAlert + 用户号  单独配置
--立即生效
--Release Version:1.01.001.20190612
--备注显示优化改善科学计数法
--Release Version:1.01.001.20190606_2
--委托时间显示问题改善 -- 风控停掉下拒绝单
--Release Version:1.01.001.20190513_2
--优化触警筛选逻辑
--Release Version:1.01.001.20190510
--接收触警通知Risker 事前：用户|理财账户
--优化当前触警、历史触警 按用户、理财账户 显示
--Release Version:1.01.001.20190430
--初始化理财账户下拉框数据空的问题
--Release Version:1.01.001.20190416
--增加当日预警、历史预警
--Release Version:1.01.001.20190325
--日志版本
--Release Version:1.01.001.20190116
--恢复代码形式的拒绝原因显示
--Release Version:1.01.001.20190115
--恢复代码形式的拒绝原因显示
--Release Version:1.01.001.20181227
--下拉框传入无值时默认全部
--Release Version:1.01.001.20181225
--同步状态改为全部成交
--柜台和风控拒绝原因分开显示
--Release Version:1.01.001.20181129
--历史委托、成交时间格式化
--Release Version:1.01.001.20181109
--单次最大量 默认100万股
--Release Version:1.01.001.20181105
--去掉证券市价
--Release Version:1.01.001.20181029
--历史资产是否显示控制
--Release Version:1.01.001.20181023
--变撤单状态
--Release Version:1.01.001.20181011
--变撤单状态
--柜台拒绝原因是否显示修改
--Release Version:1.01.001.20180927
--合计添加已清仓账户的持仓实现盈亏修改
--Release Version:1.01.001.20180830
--实现盈亏修改
--Release Version:1.01.001.20180724
--下单留痕修改
--货币基金收益内部成交备注
--Release Version:1.01.001.20180629
--上海送股当日不可卖处理委托备注
--Release Version:1.01.001.20180620
--拒绝重下委托显示修改(风控拒绝未隐藏问题修改)
--Release Version:1.01.001.20180615
--是否显示拒绝重下的拒绝委托
--Release Version:1.01.001.20180612
--当日成交，历史成交中费用（总费用，佣金， 过户费，印花税）配置隐藏显示
--Release Version:1.01.001.20180611
--配置生效
--Release Version:1.01.001.20180607
--添加市价选项
--Release Version:1.01.001.20180404
--组合维护增加增删改操作留痕
--Release Version:1.01.001.20180329
--修改组合自动读入问题
--Release Version:1.01.001.20180328
--修改组合维护数量差额不实时更新的问题，组合自动读入会串的问题
--Release Version:1.01.001.20180327
--支持内部成交费用
--Release Version:1.01.001.20180326
--修改组合维护数量差额显示，组合清单与选中组合不同步问题
--Release Version:1.01.001.20180323
--组合维护增加设置项
--算法交易界面组合下单逻辑修改
--Release Version:1.01.001.20180322
--报错处理
--Release Version:1.01.001.20180309
--显示日志和柜台拒绝重下的配置项兼容原设置与按用户号保存的新设置
--Release Version:1.01.001.20180208
--资金刷新修改
--Release Version:1.01.001.20180206
--树结构出不来问题修改
--Release Version:1.01.001.20180202
--配置项兼容原设置与按用户号保存的新设置
--Release Version:1.01.001.20180126
--增加显示下单提示框是否显示的配置项
--Release Version:1.01.001.20180124
--添加算法交易显示配置项
--Release Version:1.01.001.20180118
--修改管理员刷新间隔，默认90秒 可配置
--Release Version:1.01.001.20180108
--持仓盈亏合计加上调整盈亏
--Release Version:1.01.001.20171227
--留痕日志数量修改
--Release Version:1.01.001.20171214_2
--理财账号显示与否勾选项的设置增加除外用户号，如设置为除外，则不受前面设置项的影响依然显示勾选项
--Release Version:1.01.001.20171214
--拒绝重下支持按用户配置
--添加算法交易显示配置项
--Release Version:1.01.001.20171212
--组合号修改
--Release Version:1.01.001.20171211
--委托添加硬件信息
--Release Version:1.01.001.20171208
--组合自动撤单修改
--添加禁止金额
--Release Version:1.01.001.20171207
--组合不显示的问题修改
--Release Version:1.01.001.20171206
--修改组合的行情显示成科学记数法的问题
--Release Version:1.01.001.20171204
--委托留痕
--Release Version:1.01.001.20171204
--加长组合自动撤单的时间长度防止时间被截断
--Release Version:1.01.001.20171201
--全部禁卖，委托数量问题
--Release Version:1.01.001.20171128
--拒绝重下支持配置项
--Release Version:1.01.001.20171127
--成交号截断问题
--加回全部账户委托拒绝后重下
--隐藏算法交易
--Release Version:1.01.001.20171122_2
--管理人员按照绑定产品角色过滤理财账号
--Release Version:1.01.001.20171122
--理财账号显示与否勾选项的设置增加除外用户号，如设置为除外，则不受前面设置项的影响依然显示勾选项
--Release Version:1.01.001.20171120
--管理人员未生效问题
--Release Version:1.01.001.20171117_2
--组合自动下单报错修改
--Release Version:1.01.001.20171107
--全部委托买入失败描述修改
--Release Version:1.01.001.20171106
--市值计算优化
--新增账户未下单bug
--Release Version:1.01.001.20171102
--新增账户未显示bug
--Release Version:1.01.001.20171031
--零股问题
--Release Version:1.01.001.20171030
--交易员登录修改
--Release Version:1.01.001.20171027
--添加xml关闭事件,xml关闭会话停止
--Release Version:1.01.001.20171026
--多点登录及性能优化
--Release Version:1.01.001.20171019
--资金持仓定时刷新
--Release Version:1.01.001.20171018
--未报改为正报
--Release Version:1.01.001.20171017
--去掉条件单功能
--Release Version:1.01.001.20171010
--调整成本价
--Release Version:1.01.001.20171009
--取用户角色的处理移到取账号信息前以便界面账户列表显示
--Release Version:1.01.001.20170929
--资金刷新修改,删除日志
--Release Version:1.01.001.20170928
--改善切换用户号慢的问题
--Release Version:1.01.001.20170922
--立即生效消息不发到界面日志显示
--修改提示信息里数量科学记数法的显示
--Release Version:1.01.001.20170921
--影响界面更新的报错问题修改
--切换到没有理财账号的用户号时资金不更新的问题修改
--Release Version:1.01.001.20170918
--报错问题修改
--Release Version:1.01.001.20170915
--删除全部账户委托拒绝后重下
--交易优先级
--Release Version:1.01.001.20170914
--去掉冗余日志
--Release Version:1.01.001.20170908
--修改非法状态及原因
--立即生效后理财账号禁买禁卖标志不清空直接更新
--盈亏比例保留3位小数
--增加显示理财账号设置项是否显示的配置项
--Release Version:1.01.001.20170907
--防止取到已销户理财账号的修改
--Release Version:1.01.001.20170906
--理财账户归属用户变更刷新
--Release Version:1.01.001.20170905
--全部账户委托拒绝后重下
--收到立即生效消息以后更新风控员组员列表
--Release Version:1.01.001.20170903
--修正不能全部卖
--可买为负数时也弹出提醒
--Release Version:1.01.001.20170902
--限制卖出时，全部限卖仍可以提示
--Release Version:1.01.001.20170901
--限制买入的理财账户可用资产和总资产显示改为可配置
--风控拒绝的备注显示改为可配置
--所有理财账户限制买入的下单提醒
--风控员端的操作不影响交易员端的操作
--选择登录账号时算法交易界面只显示该账号的账户信息
--Release Version:1.01.001.20170831
--修改选中单个组员后界面显示不正确的问题
--Release Version:1.01.001.20170830
--风控拒绝原因显示到委托表格
--Release Version:1.01.001.20170829
--单笔委托零股拆分问题
--配置项控制是否显示理财账户列表
--不显示同步的委托、成交记录
--风控员增加组员列表
--Release Version:1.01.001.20170828
--零股问题
--限制买入的理财账号的可用资金不计入总的可用资金内
--Release Version:1.01.001.20170824
--左边的树节点根据配置项动态显示
--Release Version:1.01.001.20170823
--全部买卖的时候增加检查限制买入卖出的用户权限
--Release Version:1.01.001.20170815
--历史成交，成交金额科学计数法格式化
--Release Version:1.01.001.20170814
--历史成交添加明细和汇总选项
--Release Version:1.01.001.20170811
--成交添加明细和汇总选项
--Release Version:1.01.001.20170802
--去掉策略交易
--Release Version:1.01.001.20170802
--加策略交易
--Release Version:1.01.001.20170731
--算法交易页面增加按资金平均和按数量平均的下单选项
--Release Version:1.01.001.20170728
--修改柜台拒绝原因
--Release Version:1.01.001.20170727
--全部卖带零股的拆分成2笔
--Release Version:1.01.001.20170726
--算法交易增加账户名称宽度
--Release Version:1.01.001.20170721
--持仓汇总增加盈亏总计
--资金输出增加初始资金规模
--Release Version:1.01.001.20170718
--移动条件单至组合维护之后
--Release Version:1.01.001.20170713
--1.修改全部交易过的股票未显示的问题
--2.修改全部资金流水不显示问题
--3.修改理财账号显示样式
--Release Version:1.01.001.20170712
--成本价格小数位数调整(行情价格位数+1位),盈亏比例调整为2位小数
--Release Version:1.01.001.20170707
--成本价格式化字符串放在计算后面
--Release Version:1.01.001.20170614
--持仓字段调整
--Release Version:1.01.001.20170424
--算法交易选择按总资产比例下单时界面少了买入数量字段
--Release Version:1.01.001.20170414
--限制对强平的委托进行撤单
--Release Version:1.01.001.20170410
--修改算法交易卖出时会下0数量的单子
--Release Version:1.01.001.20170331
--组合维护比例超过100%时的提示信息修改
--Release Version:1.01.001.20170329
--算法交易卖出时数量向上取整，有零股时拆分下单
--Release Version:1.01.001.20170328
--只发送注册IssueCode的Price
--Release Version:1.01.001.20170303
--界面打开默认选择全部账户时的显示问题修改称
--Release Version:1.01.001.20170303
--算法交易界面账户信息增加显示账户名称
--Release Version:1.01.001.20170301
--界面打开默认选择全部账户并锁定
--组合下单支持全部账户
--组合下单显示数量差额
--Release Version:1.01.001.20170224
--算法交易界面增加按总资产比例下单
--算法交易界面增加持仓显示
--Release Version:1.01.001.20170222
--修改组合维护的自动卖单的字段设置
--Release Version:1.01.001.20170215
--组合清单增加买卖方向设置
--Release Version:1.01.001.20170214
--组合清单增加对应盘口价格
--组合清单自动读入后自动下单
--组合清单自动下单后定时撤单
--Release Version:1.01.001.20170119
--修改组合维护的创建属性设置和显示问题
--Release Version:1.01.001.20170118
--修改组合维护显示删除，新增自动读入组合文件功能
--Release Version:1.01.001.20170104
--一键清仓批号修改
--Release Version:1.01.001.20161230
--算法交易界面改变买卖方式、算法策略及盘口价格时不改变已勾选账户
--算法交易界面增加显示汇总资金信息及选中账户的资金信息
--Release Version:1.01.001.20161229
--股票树添加条件单节点
--Release Version:1.01.001.20161209
--期货添加一键清仓
--Release Version:1.01.001.20161130
--历史委托加备注字段
--Release Version:1.01.001.20161128
--修改期货持仓和资金字段
--Release Version:1.01.001.20161103
--组合交易添加编辑和指定价格
--Release Version:1.01.001.20161111
--修改bug： 成交均价计算错误
--Release Version:1.01.001.20161103
--合并组合交易
--Release Version:1.01.001.20161019
--统计保证金
--Release Version:1.01.001.20161018
--修改时间格式化
--Release Version:1.01.001.20161017
--修改成交关键字
--Release Version:1.01.001.20161017
--期货： 1. 市值 保证金 格式化 2. 昨仓 和 今仓 分开
--Release Version:1.01.001.20161013
--期货： 1. 开平仓合并 + 界面调整 2. 加快捷键  3. 市价委托 ， 用涨停价或跌停价 4. 加 保证金 字段
--Release Version:1.01.001.20160922
--名称修改，多账户下单-->算法交易
--Release Version:1.01.001.20160831
--历史资产查询添加字段
--Release Version:1.01.001.20160829
--回购修改
--Release Version:1.01.001.20160331
--FundInfo使用缓存BufferFlag(2)
--Release Version:1.01.001.20160218
--委托、成交价格小数位数修改
--Release Version:1.01.001.20160118
--过户费修改
--Release Version:1.01.001.20160105
--柜台拒绝日志主题去前缀
--Release Version:1.01.001.20150806
--委托一览添加强平备注
--Release Version:1.01.001.20150727
--不限制是否为用户分配
--Release Version:1.01.001.20150723
--柜台拒绝日志修改
--Release Version:1.01.001.20150722
--添加摊薄成本
--Release Version:1.01.001.20150702
--添加备注说明送股及股票涨跌停、停牌状态
--Release Version:1.03.004.20150506-
--委托成交回调过滤账户,成交时间修正
--Release Version:1.03.004.20150427-
--再次对接口返回委托时间带有毫秒问题做兼容
--Release Version:1.03.004.20150417-
--委托时间五位六位问题兼容
--交割单流水重复记录及累加问题修正
--Release Version:1.03.004.20150410-
--修正回报来的有5位时间截取问题
--Release Version:1.03.004.20150401-
--过滤非本用户理财账户的立即生效提示
--Release Version:1.03.004.20150316-
--添加是否显示利息管理费操作gShowManagerFee
--Release Version:1.03.004.20150309
--相关字段不读取产品结算表
--Release Version:1.03.004.20150309
--相关字段不读取产品结算表
--Release Version:1.03.004.20150227
--只有一个账户时,删除理财账户立即生效后界面理财账户未删除bug修改
--Release Version:1.03.004.20150213
--增加交割单查询
--解决当日成交中同步后只显示一条同步记录
--解决当日成交、历史成交页面委托成交价格精确度问题(比如ETF应该保留3位小数)
--Release Version:1.03.004.20150128
--解决多账户下单后当日委托界面只显示部分理财账户的风控拒绝委托的问题
--Release Version:1.03.004.20150116
--持仓盈亏比例改为3位小数
--Release Version:1.03.004.20150113
--持仓显示增加合计项(股票数量、可用数量、盈亏、市值)
--盘口增加最新、涨幅字段
--Release Version:1.03.004.20150108
--查询资产界面增加盈利可提字段
--预警值、止损值改为直接读取数据库
--持仓界面增加盈亏比例字段
--Release Version:1.03.004.20150107
--增加市价变动的时候刷新持仓信息
--Release Version:1.03.004.20141226
--委托界面显示风控被拒绝的委托单子
--Release Version:1.03.004.20141224
--手动刷新持仓市价信息和资金信息
--委托成交时间不需要精确到微秒
--当日成交中分笔成交汇总显示为一条记录
--Release Version:1.03.004.20141223
--解决分笔成交时回报中的成交金额累加问题(策略计算)
--Release Version:1.03.004.20141219
--解决亏损警戒值和平仓警戒值计算错误问题
--Release Version:1.03.004.20141217
--查询资产界面警戒值、示警值全部改为值(操盘总资金-劣后资金*比例)
--成交信息增加成本价字段
--Release Version:1.03.004.20141215
--左边买卖树前加ICON显示
--Release Version:1.03.004.20141209
--修改卖出可用余额不对
--Release Version:1.03.004.20141205
--增加借贷资产
--Release Version:1.03.004.20141202
--增加账户名称和快捷键
--Release Version:1.03.004.20141127
--过滤无效信息
--Release Version:1.03.004.20141013
--增加 查询当日资金明细、历史资金明细功能
--Release Version:1.03.003.20140915
--修改撤单委托成交显示等问题
--Release Version:1.03.002.20140905
--增加历史委托、历史成交功能
--Release Version:1.03.002.20140821
--修改日志信息显示位置
--修改多账户下单委托提示信息错误问题
--修改切换账户后下单确认界面,理财账户错误问题
--修改撤单委托返回提示信息
--Release Version:1.03.001.20140715
--初始版本
--============================================
require("PositionRisk")
--require("MySQLQry")
--策略初始化
initialize()
----------------------------------------------
--发送证券树结构输出
_DefineEventObject S_TreeEvent _AS _Output
	_DefFld("Item1",_String,40)
	_DefFld("Item2",_String,40)
	_DefFld("Item3",_String,40)
	_DefFld("Icon", _String,48);  --节点左侧 的图标

	_DefKeyField("Item1")
	_DefKeyField("Item2")
	_DefKeyField("Item3")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--发送期货树结构输出
_DefineEventObject F_TreeEvent _AS _Output
	_DefFld("Item1",_String,40)
	_DefFld("Item2",_String,40)
	_DefFld("Item3",_String,40)
	_DefFld("Icon", _String,48);  --节点左侧 的图标

	_DefKeyField("Item1")
	_DefKeyField("Item2")
	_DefKeyField("Item3")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--证券持仓输出
_DefineEventObject S_PosEvent _AS _Output
	_DefFld("IssueCode", _String, 15)
	_DefFld("IssueName", _String, 20)
	_DefFld("Quantity", _Int, 12)
	_DefFld("AvlQuantity",_Int,12)
	_DefFld("ForbidPosition",_Number,15)
	_DefFld("WorkingQuantity",_String,20)
	_DefFld("Cost", _String, 15)
	_DefFld("AveragePrice", _String, 15)
	_DefFld("PL", _String, 15)		
	_DefFld("ValuationPL", _String, 15)
	_DefFld("CumulationAdjustPL", _String, 15)	
	_DefFld("CumulationPL", _String, 15)
	_DefFld("CumulationFare", _String, 15)
	_DefFld("CumulationDividend", _String, 15)
	_DefFld("LastPrice", _String, 15)
	_DefFld("PLRatio", _String, 15)
	_DefFld("MarketValue", _String, 50)
	_DefFld("MarketName", _String, 15)
	_DefFld("BAMapID", _String, 20)
	_DefFld("BASubID", _String, 15)
	_DefFld("ReserveString", _Meta, 4);
	
	_DefKeyField("BAMapID")
	_DefKeyField("BASubID")
	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--期货持仓输出
_DefineEventObject F_PosEvent _AS _Output
	_DefFld("IssueCode", _String, 15)
	_DefFld("IssueName", _String, 20)
	_DefFld("LongShortStr", _String, 10)
	_DefFld("Quantity", _Int, 12)
	_DefFld("AvlQuantity",_Int,12)
	_DefFld("WorkingQuantity",_String,20)
	_DefFld("Cost", _String, 15)
	_DefFld("ValuationPL", _String, 50)
	_DefFld("PosPrice", _String, 15)
	_DefFld("ValuationPLM2D", _String, 50)	
	_DefFld("LastPrice", _String, 15)
	_DefFld("PrevClearingPrice", _String, 15)
	_DefFld("ClearingPrice", _String, 15)
	_DefFld("PLRatio", _String, 15)
	_DefFld("MarketValue", _String, 50)
	_DefFld("MarketName", _String, 15)
	_DefFld("BAMapID", _String, 15)
	_DefFld("BASubID", _String, 15)
	_DefFld("Margin", _String, 50)
	_DefFld("TodayQuantity",_Int,12)
	_DefFld("PrevQuantity",_Int,12)

	_DefKeyField("BAMapID")
	_DefKeyField("BASubID")
	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--证券委托输出
_DefineEventObject S_OrderEvent _AS _Output
	_DefFld("IssueCode", _String, 15)				--证券代码
	_DefFld("IssueName", _String, 20)				--证券名称
	_DefFld("BuySell", _String, 40)					--买卖
	_DefFld("OrderPrice", _String, 15)     			--委托价格
	_DefFld("Quantity", _String, 10)				--委托数量
	_DefFld("OrderTime", _String, 20)         		--委托时间
	_DefFld("ExecQty",_String,10)					--成交数量
	_DefFld("WorkingQuantity", _String, 10)			--挂单数量
	_DefFld("CancelQty", _String, 10)				--撤单数量
	_DefFld("Status",_String,30)					--状态
	_DefFld("CorpCode", _String, 25)				--委托号
	_DefFld("MarketName", _String, 15)				--交易市场
	_DefFld("BAMapID", _String, 15)
	_DefFld("ShowFlag", _String, 1)
	_DefFld("ReserveString", _String, 200);

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
_End

--期货委托输出
_DefineEventObject F_OrderEvent _AS _Output
	_DefFld("IssueCode", _String, 15)				--合约代码
	_DefFld("IssueName", _String, 20)				--合约名称
	_DefFld("MarginType", _String, 10)				--交易类型
	_DefFld("OrderPrice", _String, 15)     			--委托价格
	_DefFld("Quantity", _String, 10)				--委托数量
	_DefFld("OrderTime", _String, 20)         		--委托时间
	_DefFld("ExecQty",_String,10)					--成交数量
	_DefFld("WorkingQuantity", _String, 10)			--挂单数量
	_DefFld("CancelQty", _String, 10)				--撤单数量
	_DefFld("Status",_String,30)					--状态
	_DefFld("CorpCode", _String, 25)				--委托号
	_DefFld("OrderAcceptNo", _String, 25)				--委托号
	_DefFld("MarketName", _String, 15)				--交易市场
	_DefFld("BAMapID", _String, 15)
	_DefFld("ReserveString", _String, 200);

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
_End

--证券成交输出
_DefineEventObject S_ExecEvent _AS _Output
	_DefFld("IssueCode",_String,20)		--证券代码
	_DefFld("IssueName",_String,20)		--证券名称
	_DefFld("BuySell", _String, 40)		--买卖
	_DefFld("ExecPrice",_String,10)		--成交价格
	_DefFld("CostPrice",_String,10)		--成本价
	_DefFld("ExecQty",_String,10)		--成交数量
	_DefFld("ExecAmount",_String,10)	--成交金额
	_DefFld("ExecTime",_String,10)		--成交时间
	_DefFld("ExecNo",_String,20)		--成交号
	_DefFld("Fare",_String,20)		--费用
	_DefFld("Fare1",_String,20)		--费用
	_DefFld("Fare2",_String,20)		--费用
	_DefFld("Fare3",_String,20)		--费用
	_DefFld("MarketName", _String, 15)	--交易市场
	_DefFld("BAMapID", _String, 10)		--账户
	_DefFld("CorpCode", _String, 30)	--UniqueKey

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--期货成交输出
_DefineEventObject F_ExecEvent _AS _Output
	_DefFld("IssueCode",_String,20)		--合约代码
	_DefFld("IssueName",_String,20)		--合约名称
	_DefFld("MarginType",_String,10)	--交易类型
	_DefFld("ExecPrice",_String,10)		--成交价格
	_DefFld("CostPrice",_String,10)		--成本价
	_DefFld("ExecQty",_String,10)		--成交数量
	_DefFld("ExecAmount",_String,10)	--成交金额
	_DefFld("ExecTime",_String,10)		--成交时间
	_DefFld("ExecNo",_String,20)		--成交号
	_DefFld("Fare",_String,20)		--费用
	_DefFld("Fare1",_String,20)		--费用
	_DefFld("Fare2",_String,20)		--费用
	_DefFld("Fare3",_String,20)		--费用
	_DefFld("MarketName", _String, 15)	--交易市场
	_DefFld("BAMapID", _String, 10)		--账户
	_DefFld("CorpCode", _String, 30)	--UniqueKey

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--证券交割单输出
_DefineEventObject S_DeliveryOrderOutput _AS _Output
	_DefFld("Date",_String,20)			--日期
	_DefFld("Note",_Meta,2)				--备注
	_DefFld("IssueCode",_String,20)		--证券代码
	_DefFld("IssueName",_String,20)		--证券名称
	_DefFld("MarginType",_String,10)	--交易类型
	_DefFld("ExecQty",_String,10)		--成交数量
	_DefFld("ExecPrice",_String,10)		--成交价格
	_DefFld("ExecAmount",_String,10)	--成交金额
	_DefFld("Fare",_String,10)			--佣金
	_DefFld("StampTax",_String,10)		--印花税
	_DefFld("TransferExpense",_String,10)--过户费
	_DefFld("ChangeAmount",_String,10)	--发生金额
	_DefFld("RemainAmount",_String,10)	--剩余金额
	_DefFld("AccountCode", _String, 20)	--理财账户
	_DefFld("UserID", _String, 20)		--用户号
	_DefFld("CorpCode", _String, 20)	--委托编号
	_DefFld("ExecutionNo", _String, 20)	--成交编号
	_DefFld("Quantity", _String, 20)	--证券数量
	_DefFld("OtherFare", _String, 20)	--其他费用
	_DefFld("OrderTime", _String, 20)	--委托时间

	_DefKeyField("Date")
	_DefKeyField("IssueCode")
	_DefKeyField("ExecutionNo")
	_DefKeyField("AccountCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--期货交割单输出
_DefineEventObject F_DeliveryOrderOutput _AS _Output
	_DefFld("Date",_String,20)			--日期
	_DefFld("Note",_Meta,2)				--备注
	_DefFld("IssueCode",_String,20)		--合约代码
	_DefFld("IssueName",_String,20)		--合约名称
	_DefFld("MarginType",_String,10)	--交易类型
	_DefFld("ExecQty",_String,10)		--成交数量
	_DefFld("ExecPrice",_String,10)		--成交价格
	_DefFld("ExecAmount",_String,10)	--成交金额
	_DefFld("Fare",_String,10)			--佣金
	_DefFld("ChangeAmount",_String,10)	--发生金额
	_DefFld("RemainAmount",_String,10)	--剩余金额
	_DefFld("AccountCode", _String, 20)	--理财账户
	_DefFld("UserID", _String, 20)		--用户号
	_DefFld("CorpCode", _String, 20)	--委托编号
	_DefFld("ExecutionNo", _String, 20)	--成交编号
	_DefFld("Quantity", _String, 20)	--期货数量
	_DefFld("OtherFare", _String, 20)	--其他费用
	_DefFld("OrderTime", _String, 20)	--委托时间

	_DefKeyField("Date")
	_DefKeyField("IssueCode")
	_DefKeyField("ExecutionNo")
	_DefKeyField("AccountCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--证券历史资金
_DefineEventObject S_HistoryFundOutput _AS _Output
	_DefFld("Date", _String, 20)
	_DefFld("AccountCode", _String, 20)
	_DefFld("BasePriceLastPL",_String, 20)
	_DefFld("BasePricePL",_String, 20)
	_DefFld("AvlFund",_String, 20)
	_DefFld("ProfitFloat",_String, 20)
	_DefFld("AssetValue",_String, 20)
	_DefFld("BondRepValue",_String, 20)
	_DefFld("StockValue",_String, 20)
	_DefFld("Position",_String, 20)
	_DefFld("Fare", _String, 20)
	_DefFld("Share", _String, 20)
	_DefFld("Nav", _String, 20)

	_DefKeyField("Date")
	_DefKeyField("AccountCode")
	_SetBufferedFlag(2)
_End
--证券历史持仓
_DefineEventObject S_HistoryPosOutput _AS _Output
	_DefFld("Date", _String, 20)
	_DefFld("IssueCode", _String, 15)
	_DefFld("IssueName", _String, 15)
	_DefFld("Quantity", _Int, 12)
	_DefFld("Cost", _String, 15)
	_DefFld("LastPrice", _String, 15)
	_DefFld("ValuationPL", _String, 20)
	_DefFld("Amount", _String, 20)
	_DefFld("MarketValue", _String, 20)
	_DefFld("Ratio1", _String, 15)
	_DefFld("Ratio2", _String, 15)
	_DefFld("MarketName", _String, 15)
	_DefFld("BAMapID", _String, 20)
	_DefFld("BASubID", _String, 15)
	_DefFld("ReserveString", _Meta, 4);

	_DefKeyField("Date")
	_DefKeyField("BAMapID")
	_DefKeyField("BASubID")
	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End


--资金输出
_DefineEventObject FundInfo _AS _Output
	_DefFld("AccountType",_String,1)		--账户类型
	_DefFld("LastFund",_String,20)			--上日资金
	_DefFld("LastAssetValue",_String,20)	--上日权益	
	_DefFld("OrderFund",_String,20)			--开仓冻结资金
	_DefFld("ForbidFund",_String,20)		--冻结资金		
	_DefFld("AvlFund",_String,20)			--可用金额
	_DefFld("TransferIn",_String,20)		--入金
	_DefFld("TransferOut",_String,20)		--出金
	_DefFld("MarketValue",_String,20)		--股票市值
	_DefFld("Margin",_String,20)
	_DefFld("Fare",_String,20)
	_DefFld("RealizedPL",_String,20)	
	_DefFld("RealizedPLM2D",_String,20)		
	_DefFld("ValuationPL",_String,20)	
	_DefFld("ValuationPLM2D",_String,20)	
	
	_DefFld("AssetValue",_String,20)		--总资产	
	_DefFld("EquityFund",_String,20)	    --自有资金,保证金 
	_DefFld("MTBalance",_String,20)	        --借贷金额
	_DefFld("BeginDate",_String,20)	        --借贷日期
	_DefFld("EndDate",_String,20)	        --还款日期
	_DefFld("LossFund4Alert",_String,20)	--预警值
	_DefFld("LossFund4Close",_String,20)	--止损值
	_DefFld("InitialFund",_String,20)		--初始资金
	_DefFld("Resistance2Risk",_String,20)	--抗跌风险度

	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--多账户下单界面资金输出
_DefineEventObject MultiFundInfo _AS _Output
	_DefFld("BaMapID",_String,22)
	_DefFld("AvlFund",_String,20)			--可用金额
	_DefFld("MarketValue",_String,20)		--股票市值	
	_DefFld("AssetValue",_String,20)		--总资产
	_DefFld("AvlFundAll",_String,20)			--可用金额汇总
	_DefFld("MarketValueAll",_String,20)		--股票市值汇总
	_DefFld("AssetValueAll",_String,20)		--总资产汇总

	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End

--PriceServer事件,提供五档行情信息
_DefineEventObject PriceServerEvent _AS _Output
	_DefFld("IssueCode",_String,20)		--合约代码
	_DefFld("MarketCode",_String,2)		--市场号
	_DefFld("IssueName",_String,30)		--合约名称
	_DefFld("LastPrice",_String,8)			--最新价
	_DefFld("LastVolume",_String,10)	--现量
	_DefFld("AdjustedLNC",_String,10)	--昨收
	_DefFld("UpLimitPrice",_String,10)	--涨停价
	_DefFld("LowLimitPrice",_String,10)	--跌停价
	_DefFld("BidPrice1",_String,15);		--买1价
	_DefFld("BidPrice2",_String,15);		--买2价
	_DefFld("BidPrice3",_String,15);		--买3价
	_DefFld("BidPrice4",_String,15);		--买4价
	_DefFld("BidPrice5",_String,15);		--买5价
	_DefFld("BidPrice6",_String,15);		--买6价
	_DefFld("BidPrice7",_String,15);		--买7价
	_DefFld("BidPrice8",_String,15);		--买8价
	_DefFld("BidPrice9",_String,15);		--买9价
	_DefFld("BidPrice10",_String,15);		--买10价
	_DefFld("BidQty1",_String,15);		--买1量
	_DefFld("BidQty2",_String,15);		--买2量
	_DefFld("BidQty3",_String,15);		--买3量
	_DefFld("BidQty4",_String,15);		--买4量
	_DefFld("BidQty5",_String,15);		--买5量
	_DefFld("BidQty6",_String,15);		--买6量
	_DefFld("BidQty7",_String,15);		--买7量
	_DefFld("BidQty8",_String,15);		--买8量
	_DefFld("BidQty9",_String,15);		--买9量
	_DefFld("BidQty10",_String,15);		--买10量
	_DefFld("AskPrice1",_String,15);		--卖1价
	_DefFld("AskPrice2",_String,15);		--卖2价
	_DefFld("AskPrice3",_String,15);		--卖3价
	_DefFld("AskPrice4",_String,15);		--卖4价
	_DefFld("AskPrice5",_String,15);		--卖5价
	_DefFld("AskPrice6",_String,15);		--卖6价
	_DefFld("AskPrice7",_String,15);		--卖7价
	_DefFld("AskPrice8",_String,15);		--卖8价
	_DefFld("AskPrice9",_String,15);		--卖9价
	_DefFld("AskPrice10",_String,15);	--卖10价
	_DefFld("AskQty1",_String,15);		--卖1量
	_DefFld("AskQty2",_String,15);		--卖2量
	_DefFld("AskQty3",_String,15);		--卖3量
	_DefFld("AskQty4",_String,15);		--卖4量
	_DefFld("AskQty5",_String,15);		--卖5量
	_DefFld("AskQty6",_String,15);		--卖6量
	_DefFld("AskQty7",_String,15);		--卖7量
	_DefFld("AskQty8",_String,15);		--卖8量
	_DefFld("AskQty9",_String,15);		--卖9量
	_DefFld("AskQty10",_String,15);		--卖10量

	_DefFld("AvlFund",_String,15);
	_DefFld("ContractSize",_String,15);
	_DefFld("OpenAvailableQty",_String,15);
	_DefFld("CloseAvailableQty",_String,15);
	_DefFld("AvlPrevQuantity",_String,15);
	_DefFld("AvlTodayQuantity",_String,15);
	_DefFld("BailRatio",_String,15);

	_DefKeyField("IssueCode")
	_SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End

--账户下拉框
_DefineEventObject MultiFireDataOut _AS _Output
	_DefFld("IssueCode", _String, 20)	--合约代码
	_DefFld("BuySell", _String, 1)			--买卖
	_DefFld("OpenClose", _Int, 1)			--开平
    _DefFld("DataString", _Meta, 4)

    _SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

--输出委托方式到下单界面委托方式
_DefineEventObject OrderTypeInfoEvent _AS _Output
	_DefFld("OrderType",_String,200)	--报价方式

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--日志信息提示
_DefineEventObject LogInfoOut _AS _Output
    _DefFld("Text", _Meta, 4)

    _SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End

--History submit order OutEvent
_DefineEventObject HistorySubmitOutput _AS _Output
	_DefFld("BAMapID",_String,14);
	_DefFld("IssueCode",_String ,20);
	_DefFld("IssueName",_String ,60);
	_DefFld("BuySell",_String ,40);
	_DefFld("OpenClose",_String ,8);
	_DefFld("Quantity",_Int ,15);
	_DefFld("Price",_String ,15);
	_DefFld("ExecutionQuantity",_Int ,15);
	_DefFld("ExecutionValue",_String,15);	--成交金额
	_DefFld("WorkingQuantity",_Int ,15);
	_DefFld("Status",_String ,12);
	_DefFld("OrderAcceptNo",_String,10);
	_DefFld("Date",_String,8);
	_DefFld("OrderTime",_String,14);
	_DefFld("CorpCode",_String,20);
	_DefFld("Fare",_String,20);
	_DefFld("ReserveString",_Meta, 4)

	_DefKeyField("BAMapID");
	_DefKeyField("CorpCode");
	_DefKeyField("Date");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

--History Execution OutEvent
_DefineEventObject HistoryExecutionOutput _AS _Output
	_DefFld("BAMapID",_String,14);
	_DefFld("AccountCode",_String,14);
	_DefFld("IssueCode",_String ,20);
	_DefFld("IssueName",_String ,60);
	_DefFld("BuySell",_String ,40);
	_DefFld("OpenClose",_String ,15);
	_DefFld("Quantity",_Int ,15);
	_DefFld("ExecutionPrice",_String,15);
	_DefFld("AmountReceivable",_String,12);	--应收金额
	_DefFld("Date",_String,8);
	_DefFld("ExecutionTime",_String,14);
	_DefFld("Fare",_String,20);
	_DefFld("ExecutionKeyCode",_String, 30);
	_DefFld("ExecutionNo",_String,8);
	_DefFld("OrderAcceptNo",_String,10);
	_DefFld("Fare1",_String,20)		--费用
	_DefFld("Fare2",_String,20)		--费用
	_DefFld("Fare3",_String,20)		--费用

	_DefKeyField("AccountCode");
	_DefKeyField("ExecutionKeyCode");
	_DefKeyField("Date");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

--当日资金明细
_DefineEventObject TodayFundJournalOutput _AS _Output
	_DefFld("Date",_String,10);
	_DefFld("Description",_String,256);
	_DefFld("AmountReceived",_String ,20);
	_DefFld("AmountPayed",_String ,20);
	_DefFld("Balance",_String ,20);
	_DefFld("Currency",_String ,20);
	_DefFld("Note",_String ,256);
	_DefFld("AccountTitle",_String ,10);
	_DefFld("AccountName",_String ,20);
	_DefFld("FundJournalID",_String ,20);
	_DefFld("ExecQty",_String ,20);
	_DefFld("ExecPrice",_String ,20);
	_DefFld("Amount",_String ,20);
	_DefFld("Fund",_String ,20);
	_DefFld("StockAccount",_String ,20);
	_DefFld("IssueCode",_String ,20);
	_DefFld("IssueName",_String ,60);
	_DefFld("AccountCode",_String ,20);

	_DefKeyField("Date");
	_DefKeyField("FundJournalID");
	_DefKeyField("AccountCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

--历史资金明细
_DefineEventObject HistoryFundJournalOutput _AS _Output
	_DefFld("Date",_String,8);
	_DefFld("AccountCode",_String ,20);
	_DefFld("Description",_String,256);
	_DefFld("AmountReceived",_String ,20);
	_DefFld("AmountPayed",_String ,20);
	_DefFld("Balance",_String ,20);
	_DefFld("Currency",_String ,20);
	_DefFld("AccountTitle",_String ,10);
	_DefFld("FundJournalID",_String ,20);
	----成交明细字段

	_DefFld("IssueCode",_String,20)		--证券代码
	_DefFld("IssueName",_String,20)		--证券名称
	_DefFld("OpenClose",_String,10)
	_DefFld("BuySell",_String,40)
	_DefFld("OrderQuantity", _String, 20)--证券数量
	_DefFld("ExecQty",_String,10)		--成交数量
	_DefFld("ExecPrice",_String,10)		--成交价格
	_DefFld("ExecAmount",_String,10)	--成交金额
	_DefFld("TotalFare",_String,10)		--总费用
	_DefFld("Fare",_String,10)			--佣金
	_DefFld("StampTax",_String,10)		--印花税
	_DefFld("TransferExpense",_String,10)--过户费
	_DefFld("UserID", _String, 20)		--用户号
	_DefFld("OrderAcceptNo", _String, 20)	--委托编号
	_DefFld("OrderTime", _String, 20)	--委托时间
	_DefFld("ReserveString", _String, 20)


	_DefKeyField("Date");
	_DefKeyField("FundJournalID");
	_DefKeyField("AccountCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

_DefineEventObject ShowBaMapListOutput _AS _Output
	_DefFld("IsShowBaMapList",_String,5); --显示理财账户下拉框标志， "True":显示; 默认不显示
_End

----------------------------------------------
--读取数据库
----------------------------------------------
_OnCommonData(dataName = "GetMarketName", DTSMarketCode evt)
	local marketCode = evt.getMarketCode()
	local marketName = evt.getMarketShortLocalName()
	gtMarketNameTable[marketCode] = marketName
_End

_OnCommonData("GetSPLITData", DTSOvernightData overnightData)
	local baMapID = overnightData.getBAMapID()
	if _PosBAMapTable[baMapID] then
		local baSubID = overnightData.getBASubID()
		local issueCode = overnightData.getIssueCode()
		local overnight = {}
		overnight.BAMapID = baMapID
		overnight.BASubID = baSubID
		overnight.IssueCode = issueCode
		overnight.OvernightQty = overnightData.getOvernightQuantity()

		local posKey = baMapID .. "." .. baSubID .. "." .. issueCode
		gtOvernightSPLITData[posKey]=overnight
		local log=sys_format("GetSPLITData:%s,%s,%s,%s",baMapID,baSubID,issueCode,overnight.OvernightQty)
		_WriteAplLog(log)
	end
_End
_OnCommonData(dataName="StartDateCheck", DTSCalendar cald)
	gDateCheckResult = true;
_End

_OnCommonData(dataName="EndDateCheck", DTSCalendar cald)
	gDateCheckResult = true;
_End

_OnCommonData("readHistoricalOrderDetail",DTSHistoricalOrderDetail record)
	 if not gHisOrderCheckResult then
		gHisOrderCheckResult = true
	 end

	local baMapID = record.getBAMapID()
	local issueCode = record.getIssueCode()
	local issueName = _PosIssueNameTable[issueCode]
	local buySell = record.getBuySell()
	local openClose = record.getReserveInt1()
	local quantity = record.getOriginalQuantity()	--委托数量
	local price = record.getOrderPrice()
	local formatPriceExponent = getPriceFormat(issueCode);
	if price and price ~= "" then
		price = sys_format(formatPriceExponent, price);
	end
	local workingQuantity = record.getWorkingQuantity()	--挂盘数量
	local executionQuantity = record.getExecutionQuantity()	--成交数量
	local executionValue = record.getExecutionValue()
	local cancelQuantity = record.getCancelQuantity()	--撤单数量
	local rejectedQuantity = record.getRejectedQuantity()	--拒绝数量
	local unacceptedQuantity = record.getUnacceptedQuantity()	--未报数量
	local orderAcceptNo = record.getOrderAcceptNo()
	local date = record.getDataDate()
	local orderTime = record.getOrderTime()
	local corpCode = record.getCorpCode()
	local fare = record.getReserveDouble1()

	local creRedFlag = record.getGeneralInt2()
	local creRed = record.getGeneralInt1()
	local targetPrice = record.getTargetPrice()
	-- 备注
	local reserveString=""
	if openClose~=0 then
		if targetPrice then
			if targetPrice~="" then
				if sys_len(targetPrice)>=6 then
					if sys_sub(targetPrice,1,6)=="Index:" then
						local indexName=sys_sub(targetPrice,7,-1) or ""
						reserveString=sys_format("指标[%s]强平",indexName)
					end
					if sys_sub(targetPrice,1,6)=="MClose" then
						reserveString="风控员强平"
					end
				end
			end
		end
	end
	
	
	if creRedFlag == 4 or creRedFlag == 5 or creRedFlag == 6 then
		creRed = creRedFlag - 1
	end

	if buySell == "3" then
		buySell = "买"
	elseif buySell == "1" then
		buySell = "卖"
		if openClose == 0 and creRed == 5 then
			buySell = "融券回购"
			local faceValue = _PosIssueFaceValueTable[issueCode] or 0
			executionValue = executionQuantity * faceValue--债券回购的成交金额=数量*面值
		end
	else
		buySell = "通配"
	end

	if openClose == 0 then
		openClose = "开仓"
	elseif openClose == 1 then
		openClose = "平仓"
	elseif openClose == 2 then
		openClose = "平今"
	end

	if executionValue and executionValue ~= "" and executionValue ~= "nan" then
		executionValue = sys_format("%.2f",executionValue)
	else
		executionValue = "-"
	end

	local status = ""
	if quantity == executionQuantity then
		status = "全部成交";
	elseif executionQuantity >0 and quantity > executionQuantity then
		if executionQuantity + cancelQuantity == quantity then
			status = "部成部撤";
		else
			status = "部分成交";
		end
	elseif workingQuantity > 0 then
		status = "挂单";
	elseif cancelQuantity > 0 then
		status ="已撤";
	elseif unacceptedQuantity == quantity then
		status = "正报";
	elseif rejectedQuantity > 0 then
		status = "拒绝";
	end

	--时间格式化
	if not orderTime or orderTime == "" then
		orderTime = ""
	else
		local tmpordtimeH = sys_sub(orderTime,1,2);
		local tmpordtimeM = sys_sub(orderTime,3,4);
		local tmpordtimeS = sys_sub(orderTime,5,6);
		if tmpordtimeH and tmpordtimeH ~="" and tmpordtimeM and tmpordtimeM ~="" and tmpordtimeS and tmpordtimeS ~="" then
			orderTime = tmpordtimeH..":"..tmpordtimeM..":"..tmpordtimeS
		end
		
	end


	if (POS_LOGIN_CHECK_FUT_ISSUE ~= issueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= issueCode)  then
		local DTSEvent evt = _CreateEventObject("HistorySubmitOutput")
		evt._SetFld("BAMapID",baMapID)
		evt._SetFld("IssueCode",issueCode)
		evt._SetFld("IssueName",issueName)
		evt._SetFld("BuySell",buySell)
		evt._SetFld("OpenClose",openClose)
		evt._SetFld("Quantity",quantity)
		evt._SetFld("Price",price)
		evt._SetFld("ExecutionQuantity",executionQuantity)
		evt._SetFld("ExecutionValue",executionValue)
		evt._SetFld("WorkingQuantity",workingQuantity)
		evt._SetFld("Status",status)
		evt._SetFld("OrderAcceptNo",orderAcceptNo)
		evt._SetFld("Date",date)
		evt._SetFld("OrderTime",orderTime)
		evt._SetFld("CorpCode",corpCode)
		evt._SetFld("Fare",fare)
		evt._SetFld("ReserveString", reserveString)
		local newOrderKeyCode = record.getNewOrderKeyCode()
		if sys_sub(newOrderKeyCode,2,4)~="L18" or gInternalExecShowMode~="1" then
			_SendEventToClient(evt,gCurSession);
		end
	end
_End


_OnCommonData(dataName = "HistoryExecution" , DTSHistoricalExec execEvent);
	 if not gHisExecCheckResult then
		gHisExecCheckResult = true
	 end
	local baMapID = execEvent.getBAMapID()
	local accountCode = _PosBAMapAccount[baMapID]  or baMapID
	local issueCode = execEvent.getIssueCode()
	local issueName = _PosIssueNameTable[issueCode]
	local buySell = execEvent.getBuySell()
	local creRed = execEvent.getCreRed()
	local openClose = execEvent.getOpenClose()
	local buySell_tmp = buySell
	if buySell == "3" then
		buySell = "买"
	else
	    buySell = "卖"
	end

	if openClose == 0 then
		openClose = "开"
	else
		openClose = "平"
	end
	local quantity = execEvent.getQuantity()
	local executionPrice= execEvent.getExecutionPrice()
	local formatPriceExponent = getPriceFormat(issueCode);
	if executionPrice and executionPrice ~= "" then
		executionPrice = sys_format(formatPriceExponent, executionPrice);
	end
	local execTime = execEvent.getExecutionTime()
	--时间格式化
	if not execTime or execTime == "" then
		execTime = ""
	else
		execTime=TimeFormat(execTime)	
	end

	local fare = 0

	local contractSize = 1
	if _PosIssueContractSizeTable[issueCode] then
		contractSize = _PosIssueContractSizeTable[issueCode]
	end
	local executionValue = quantity.getNumberValue() * executionPrice.getNumberValue() * contractSize
	executionValue = sys_format("%.2f", executionValue)
	local date = execEvent.getExecutionDate()
	local executionKeyCode = execEvent.getExecutionKeyCode();
	local executionNo = execEvent.getExecutionNo();
	local orderAcceptNo = execEvent.getOrderAcceptNo();
	local lt = {}
	lt.BAMapID = baMapID
	lt.IssueCode = issueCode
	lt.OpenClose = openClose
	lt.ExecValue = executionValue
	lt.ExecQty = quantity
	lt.Quantity = quantity
	lt.CreRed = creRed
	lt.BS = buySell_tmp
	if sys_sub(executionKeyCode,2,4)=="L18" then
		lt.IsInternal = 1
		if executionNo==_PosInternalWithFareExecNo then
			lt.WithFare = 1
		end
	else
		lt.IsInternal = 0
	end				
	local fareTable =PosFareDetail(accountCode, lt.IssueCode, lt)		
	fare = fareTable.TotalFare or 0
	local fare1 = fareTable.Fare or 0
	local fare2 = fareTable.TransferExpense or 0
	local fare3 = fareTable.StampTax or 0

	local 	showFlag="1"
	if gInternalExecShowMode=="1" and sys_sub(executionKeyCode,2,4)=="L18" then
		showFlag="0"
	end
	if (POS_LOGIN_CHECK_FUT_ISSUE ~= issueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= issueCode  and showFlag=="1")  then
		
		local tempbuySell=buySell
		if openClose == "开" and creRed == 5 and tempbuySell == "卖" then
			tempbuySell = "融券回购"
			local faceValue = _PosIssueFaceValueTable[issueCode] or 0
			executionValue = quantity * faceValue--债券回购的成交金额=数量*面值
		end
		if gHisExecShowMode~=2 then
			local DTSEvent hisExecEvent =_CreateEventObject("HistoryExecutionOutput");
			hisExecEvent._SetFld("BAMapID",baMapID);
			hisExecEvent._SetFld("AccountCode",accountCode);
			hisExecEvent._SetFld("IssueCode",issueCode);
			hisExecEvent._SetFld("IssueName",issueName);
			hisExecEvent._SetFld("BuySell",tempbuySell);
			hisExecEvent._SetFld("OpenClose",openClose);
			hisExecEvent._SetFld("Quantity",quantity);
			hisExecEvent._SetFld("ExecutionPrice",executionPrice);
			hisExecEvent._SetFld("AmountReceivable",executionValue);
			hisExecEvent._SetFld("Date",date);
			hisExecEvent._SetFld("ExecutionTime",execTime);
			hisExecEvent._SetFld("Fare",fare);
			hisExecEvent._SetFld("Fare1",fare1);
			hisExecEvent._SetFld("Fare2",fare2);
			hisExecEvent._SetFld("Fare3",fare3);
			hisExecEvent._SetFld("ExecutionKeyCode",executionKeyCode);
			hisExecEvent._SetFld("ExecutionNo",executionNo);
			hisExecEvent._SetFld("OrderAcceptNo",orderAcceptNo);
			_SendEventToClient(hisExecEvent,gCurSession);
		else
			local key=baMapID.."."..issueCode.."."..buySell
			if not gtHisExecSum[key] then
				gtHisExecSum[key]={}
				gtHisExecSum[key].BAMapID=baMapID
				gtHisExecSum[key].AccountCode=accountCode
				gtHisExecSum[key].IssueCode=issueCode
				gtHisExecSum[key].BuySell=tempbuySell
				gtHisExecSum[key].Quantity=quantity
				gtHisExecSum[key].ExecutionValue=executionValue
				gtHisExecSum[key].Fare=fare
				gtHisExecSum[key].Fare1=fare1
				gtHisExecSum[key].Fare2=fare2
				gtHisExecSum[key].Fare3=fare3
			else
				gtHisExecSum[key].Quantity=gtHisExecSum[key].Quantity+quantity
				gtHisExecSum[key].ExecutionValue=gtHisExecSum[key].ExecutionValue+executionValue
				gtHisExecSum[key].Fare=gtHisExecSum[key].Fare+fare
				gtHisExecSum[key].Fare1=gtHisExecSum[key].Fare1+fare1
				gtHisExecSum[key].Fare2=gtHisExecSum[key].Fare2+fare2
				gtHisExecSum[key].Fare3=gtHisExecSum[key].Fare3+fare3
			end
		end
	end
_End

_OnCommonData("readHisOrderForHistoryFund",DTSHistoricalOrderDetail record)
	local baMapID = record.getBAMapID()
	local accountCode = _PosBAMapAccount[baMapID]
	local issueCode = record.getIssueCode()
	local marketCode = record.getMarketCode()
	local buySell = record.getBuySell()
	local openClose = record.getReserveInt1()
	local originalQuantity = record.getOriginalQuantity()
	local execQty = record.getExecutionQuantity()	--成交数量
	local execAmount = record.getExecutionValue()
	execAmount = sys_format("%.2f",execAmount)
	local execPrice = record.getExecutionPrice()
	local formatPriceExponent = getPriceFormat(issueCode);
	if execPrice and execPrice ~= "" then
		execPrice = sys_format(formatPriceExponent, execPrice);
	end
	local orderAcceptNo = record.getOrderAcceptNo()
	local date = record.getDataDate()
	local userID = record.getDealerID()				--用户号(交易员)
	local corpCode = record.getCorpCode()			--内部委托号
	local executionNo = record.getExecutionSeqNo()	--成交号
	local orderTime = record.getOrderTime()			--委托时间
	local fare = record.getReserveDouble1()
	local creRedFlag = record.getGeneralInt2()
	local creRed = record.getGeneralInt1()
	
	local generalDouble1 = record.getGeneralDouble1()
	local lastLimitType = record.getLastLimitType()
	local crossCorpCode = record.getCrossCorpCode()
	
	if creRedFlag == 4 or creRedFlag == 5 or creRedFlag == 6 then
		creRed = creRedFlag - 1
	end

	local lt = {}
	lt.BAMapID = baMapID
	lt.IssueCode = issueCode
	lt.MarketCode = marketCode
	lt.BuySell = buySell
	lt.OpenClose = openClose
	lt.OrderQuantity=originalQuantity
	lt.ExecQty = execQty
	lt.ExecAmount = execAmount
	lt.ExecPrice = execPrice
	lt.OrderAcceptNo = orderAcceptNo
	lt.UserID = userID
	lt.CorpCode = corpCode
	lt.Fare = fare
	lt.ExecutionNo = executionNo
	lt.OrderTime = orderTime
	lt.CreRed = creRed
	lt.GeneralDouble1 = generalDouble1
	lt.LastLimitType = lastLimitType
	lt.CrossCorpCode = crossCorpCode
	
	gtHistoricalOrderDetail[date]=gtHistoricalOrderDetail[date] or {}
	gtHistoricalOrderDetail[date][corpCode]=lt
_End

_OnCommonData(dataName = "readHisFundJournalDetail", DTSFundJournal fundJournal);
	if not gHisFundJournalCheckResult then
		gHisFundJournalCheckResult = true
	 end
	local fundJournalID = fundJournal.getFundJournalID()
	local accountCode = fundJournal.getAccountCode()
	local date = fundJournal.getDate()
	local description = fundJournal.getDescription()
	local amountReceived = fundJournal.getAmountReceived()
	amountReceived = showFormat(amountReceived,1)
	local amountPayed = fundJournal.getAmountPayed()
	amountPayed = showFormat(amountPayed,1)
	local balance = fundJournal.getBalance()
	balance = showFormat(balance,1)
	local accountTitle = fundJournal.getAccountTitle()
	local currency = "人民币"


	local vReceived=amountReceived.getNumberValue()
	local vPayed=amountPayed.getNumberValue()
	if vReceived>0 or vPayed>0 then
		local filter=false
		if (gShowManagerFee==0 and accountTitle=="10000") then
			filter=true
		end
		if not filter then
			local reserveString=fundJournal.getReserveString()
			local DTSEvent hisFundEvent =_CreateEventObject("HistoryFundJournalOutput");
			hisFundEvent._SetFld("Date",date);
			hisFundEvent._SetFld("Description",description);
			hisFundEvent._SetFld("AccountCode",accountCode);
			hisFundEvent._SetFld("AmountReceived",amountReceived);
			hisFundEvent._SetFld("AmountPayed",amountPayed);
			hisFundEvent._SetFld("Balance",balance);
			hisFundEvent._SetFld("Currency",currency);
			hisFundEvent._SetFld("AccountTitle",accountTitle);
			hisFundEvent._SetFld("FundJournalID",fundJournalID);
			hisFundEvent._SetFld("ReserveString",reserveString);
			local flag=true
			if reserveString and reserveString~="" then
				if gtHistoricalOrderDetail[date] then
					if gtHistoricalOrderDetail[date][reserveString] then
						flag=false
						local lt = gtHistoricalOrderDetail[date][reserveString]
						local issueCode=lt.IssueCode
						hisFundEvent._SetFld("IssueCode",issueCode);
						local issueName=_PosIssueNameTable[issueCode];
						hisFundEvent._SetFld("IssueName",issueName);
						local openClose=lt.OpenClose
						if openClose == 0 then
							openClose = "开"
						else
							openClose = "平"
						end
						hisFundEvent._SetFld("OpenClose",openClose);
						local buySell=lt.BuySell
						local executionNo=lt.ExecutionNo

						local creRed=lt.CreRed or 0
						if buySell == "3" then
							buySell = "买"
						elseif buySell == "1" then
							buySell = "卖"
							if lt.OpenClose == 0 and creRed == 5 then
								buySell = "融券回购"
							end
						else
							buySell = "通配"
						end

						hisFundEvent._SetFld("BuySell",buySell);
						local orderQuantity=lt.OrderQuantity
						hisFundEvent._SetFld("OrderQuantity",orderQuantity);
						local execQty=lt.ExecQty
						hisFundEvent._SetFld("ExecQty",execQty);
						local execPrice=lt.ExecPrice
						hisFundEvent._SetFld("ExecPrice",execPrice);
						local execAmount=lt.ExecAmount
						if buySell == "融券回购" then
							local faceValue = _PosIssueFaceValueTable[issueCode] or 0
							execAmount = execQty * faceValue--债券回购的成交金额=数量*面值
						end
						execAmount = showFormat(execAmount,1)
						hisFundEvent._SetFld("ExecAmount",execAmount);
						local orderAcceptNo=lt.OrderAcceptNo
						local realFare=lt.Fare or 0
						realFare = sys_format("%.2f",realFare)
						hisFundEvent._SetFld("TotalFare",realFare);
						
						local fare_hisOrder = lt.GeneralDouble1 or 0
						fare_hisOrder = sys_format("%.2f",fare_hisOrder)
						hisFundEvent._SetFld("Fare",fare_hisOrder);
						local stampTax_hisOrder = lt.LastLimitType or 0
						stampTax_hisOrder = sys_format("%.2f",stampTax_hisOrder)
						hisFundEvent._SetFld("StampTax",stampTax_hisOrder);
						
						local transferExpense_hisOrder = lt.CrossCorpCode or 0
						transferExpense_hisOrder = sys_format("%.2f",transferExpense_hisOrder)
						hisFundEvent._SetFld("TransferExpense",transferExpense_hisOrder);						
						
						hisFundEvent._SetFld("OrderAcceptNo",orderAcceptNo);
						local orderTime=lt.OrderTime
							--时间格式化
						if not orderTime or orderTime == "" then
							orderTime = ""
						else
							orderTime=TimeFormat(orderTime)
						end
						hisFundEvent._SetFld("OrderTime",orderTime);
					end
				end
			end
			if flag then
				hisFundEvent._SetFld("IssueCode","");
				hisFundEvent._SetFld("IssueName","");
				hisFundEvent._SetFld("OpenClose","");
				hisFundEvent._SetFld("BuySell","");
				hisFundEvent._SetFld("OrderQuantity","");
				hisFundEvent._SetFld("ExecQty","");
				hisFundEvent._SetFld("ExecPrice","");
				hisFundEvent._SetFld("ExecAmount","");
				hisFundEvent._SetFld("Fare","");
				hisFundEvent._SetFld("StampTax","");
				hisFundEvent._SetFld("TransferExpense","");
				hisFundEvent._SetFld("OrderAcceptNo","");
				hisFundEvent._SetFld("OrderTime","");
			end
			_SendEventToClient(hisFundEvent,gCurSession);
		end
	end
_End

_OnCommonData(dataName = "readNetTransfer", DTSNetTransfer netTransfer);
	if not gTodayFundJournalCheckResult then
		gTodayFundJournalCheckResult = true
	end
	if gtSessionTable[gCurSession] then
		local fundJournalID = netTransfer.getUniqueID()
		local inAccountCode = netTransfer.getInAccountCode()
		local outAccountCode = netTransfer.getOutAccountCode()
		local date = _PosGetYMD()
		local description = ""
		local accountCode = gtSessionTable[gCurSession].SelectedBAMapID
		local amountReceived = 0
		local amountPayed = 0
		if gtSessionTable[gCurSession].CurBAMapIDTable[inAccountCode] then
			amountReceived = netTransfer.getAmount()
			description = sys_format("入金理财账户[%s] 出金理财账户[%s]",inAccountCode,outAccountCode)
			accountCode = inAccountCode
		elseif gtSessionTable[gCurSession].CurBAMapIDTable[outAccountCode] then
			amountPayed = netTransfer.getAmount()
			description = sys_format("出金理财账户[%s] 入金理财账户[%s]",outAccountCode,inAccountCode)
			accountCode = outAccountCode
		end

		amountReceived = showFormat(amountReceived,1)
		amountPayed = showFormat(amountPayed,1)

		local balance = 0
		if _PosFundStatus[accountCode] then
			balance = _PosFundStatus[accountCode]["AvlFund"]
		end
		balance = showFormat(balance,1)
		local accountTitle = ""
		local accountName = ""
		local currency = "人民币"
		local note = ""
		local execQty = ""
		local execPrice = ""
		local amount = ""
		local fund = ""
		local stockAccount = ""
		local issueCode = ""
		local issueName = ""

		local DTSEvent todayFundEvent =_CreateEventObject("TodayFundJournalOutput");
		todayFundEvent._SetFld("Date",date);
		todayFundEvent._SetFld("Description",description);
		todayFundEvent._SetFld("AmountReceived",amountReceived);
		todayFundEvent._SetFld("AmountPayed",amountPayed);
		todayFundEvent._SetFld("Balance",balance);
		todayFundEvent._SetFld("Currency",currency);
		todayFundEvent._SetFld("Note",note);
		todayFundEvent._SetFld("AccountTitle",accountTitle);
		todayFundEvent._SetFld("AccountName",accountName);
		todayFundEvent._SetFld("FundJournalID",fundJournalID);
		todayFundEvent._SetFld("ExecQty",execQty);
		todayFundEvent._SetFld("ExecPrice",execPrice);
		todayFundEvent._SetFld("Amount",amount);
		todayFundEvent._SetFld("Fund",fund);
		todayFundEvent._SetFld("StockAccount",stockAccount);
		todayFundEvent._SetFld("IssueCode",issueCode);
		todayFundEvent._SetFld("IssueName",issueName);
		todayFundEvent._SetFld("AccountCode",accountCode);

		_SendEventToClient(todayFundEvent,gCurSession);
	end
_End

----------------------------------------------
--显示理财账户下拉框
----------------------------------------------
_DefineEventObject ShowBaMapListInput _AS _Input
	_DefFld("IsShowBaMapList", _String, 5)

	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

_OnEventDefined(ShowBaMapListInput evt,sessionID)
	gCurSession=sessionID
	
	gIsShowBaMapList = evt._GetFld("IsShowBaMapList");
	local logs = sys_format("gIsShowBaMapList[%s]",gIsShowBaMapList);
	_WriteAplLog(logs)

	local DTSEvent evt = _CreateEventObject("ShowBaMapListOutput");
	evt._SetFld("IsShowBaMapList", gIsShowBaMapList);
	_SendEventToClient(evt, sessionID);
_End


----------------------------------------------
--输入事件定义和回调
----------------------------------------------
_DefineEventObject UserBAMapOut _AS _Output
	_DefFld("StrJson", _Meta, 4);	

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
function sendUserBAMap(sessionID)
    local logs;
	gtUserName = {}
	gtAccountName = {}	
	getNewUserBAMap()
	
	_GetCommonData("ReadUserName", condition="", tablename = "User");
	_GetCommonData("ReadAccountName", condition="", tablename = "Account");
	local ltData={}	
	local userTable={}
	local currentUserID = _GetDealerID()
	if gtPosUserAccessUserTable[currentUserID] then
        --_WriteAplLog("Into gtPosUserAccessUserTable" )
		for accessUserID,v in pairs(gtPosUserAccessUserTable[currentUserID]) do
			sys_insert(userTable,accessUserID)
		end
		sys_sort(userTable,"asc")
	end

	for  i,userID in pairs(userTable) do
		if  gtPosUserBAMapTable[userID] then
            logs = sys_format("Into userTable[%s]",userID)
            --_WriteAplLog(logs)
			ltData[userID]=ltData[userID] or {}
			local userName = GetUserName(userID)
			ltData[userID].UserName=userName
			ltData[userID].BAMapTable={}
			for baMap,v in pairs(gtPosUserBAMapTable[userID]) do
				local accountCode = _PosBAMapAccount[baMap]
				if  not isDefaultAccount(baMap) and accountCode and gtRunAccountTable[baMap] and gtZGProductAccountTable[baMap] then
					if _PosFundStatus[accountCode] then							
						local accountName=GetAccountName(accountCode)
						ltData[userID].BAMapTable[baMap]=accountName
					end
				end
			end
		end
	end
    
    local tmp = {}    
	if  gtPosUserBAMapTable[currentUserID] then
		ltData["self"]=ltData["self"] or {}
		local userName = GetUserName(currentUserID)
		ltData["self"].UserName=userName
		ltData["self"].BAMapTable={}
        
        local num = 0
        
		for baMap,v in pairs(gtPosUserBAMapTable[currentUserID]) do
			local accountCode = _PosBAMapAccount[baMap]
			if  not isDefaultAccount(baMap) and accountCode and gtRunAccountTable[baMap] and gtZGProductAccountTable[baMap] then
				if _PosFundStatus[accountCode] then							
					local accountName=GetAccountName(accountCode)
					ltData["self"].BAMapTable[baMap]=accountName

                    local ProductID = gtZGProductAccountTable[baMap].ProductID
                    if not gtProductTable[ProductID] then
                        gtProductTable[ProductID] = 1
                        local ProductName = gtProduct2NameTable[ProductID]
                        sys_insert(tmp,ProductName)
                    end
                   
				end
			end
		end
	end
    sys_sort(tmp, "desc")
    local str = ""
    for n,ProductName in ipairs (tmp) do
        str = str .. ProductName .. ";"
    end
    if str ~= "" then
        str = str .. ";"
    end
    
    local tmp_old = {}
    for baMap,v in pairs(gtZGProductAccountBackUpTable) do
        --_WriteAplLog(baMap)
        local ProductID = v.ProductID
        if not gtOldProductTable[ProductID] then
            gtOldProductTable[ProductID] = 1
            local ProductName = gtProduct2NameTable[ProductID]
            sys_insert(tmp_old,ProductName)
        end
    end
    sys_sort(tmp_old, "desc")
    local str_old = ""
    for n,ProductName in ipairs (tmp_old) do
        str_old = str_old .. ProductName .. ";"
    end
    if str_old ~= "" then
        str_old = str_old .. ";"
    end
    
    --_WriteAplLog(str)
    --_WriteAplLog(str_old)
    
    local DTSEvent evt1 = _CreateEventObject("SendProductName");
    evt1._SetFld("ProductName", str);
    evt1._SetFld("ProductName_old", str_old);
    _SendEventToClient(evt1,sessionID);

	gtltData = ltData
	
	local DTSSubmitEvent submitEvent1=ltData
	local strJson=submitEvent1.encode()	
    _WriteAplLog(strJson)
	--if gUserBAMapStr~=strJson then 
	if sessionID == "All" or not gtUserBAMapStr[sessionID] or gtUserBAMapStr[sessionID] ~= strJson then
		local DTSEvent evt = _CreateEventObject("UserBAMapOut");
		evt._SetFld("StrJson", strJson);
		if  sessionID=="All" then
			_SendToClients(evt)
		else
			_SendEventToClient(evt,sessionID);
		end	
		--gUserBAMapStr=strJson
		gtUserBAMapStr[sessionID] = strJson
		_WriteAplLog("进来咯@@@@@@@@@@@@@@@@@@@@")
	end
end

_OnCommonData(dataName = "ReadUserName", DTSUser user)
	local userID = user.getUserID()
	local userName = user.getUserName();
	
	if userName and userName~="" then
		gtUserName[userID] = userName
	end
_End

_OnCommonData(dataName = "ReadAccountName", DTSAccount account)
	local accountCode = account.getAccountCode();
	local accountName = account.getAccountName();
	if accountName and accountName~="" then
		gtAccountName[accountCode] = accountName
	end
_End
_DefineEventObject XMLLoad _AS _Input
	_DefFld("UserID", _String, 22)
	_DefFld("BAMapID", _String, 22)
	_DefFld("RouteInfo", _Meta, 4)
	_DefFld("LocalIPV4IP", _Meta, 4)	
	
	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

function getRouteInfoByStr(routeInfo)
	local MacAddress=""
	local LocalIP=""
	local HdID=""
	local len=sys_len(routeInfo)
	for i=1,len,1 do
		for j=i,len,1 do
			if sys_sub(routeInfo,i,j)=="MacAddress=" or sys_sub(routeInfo,i,j)=="MAC=" then
				for k=j+1,len,1 do
					if sys_sub(routeInfo,k,k)==";"  or sys_sub(routeInfo,k,k)=="," then
						MacAddress=sys_sub(routeInfo,j+1,k-1)
						break;
					end
				end
			end
			if sys_sub(routeInfo,i,j)=="LocalIP=" or sys_sub(routeInfo,i,j)=="IP=" then
				for k=j+1,len,1 do
					if sys_sub(routeInfo,k,k)==";" or sys_sub(routeInfo,k,k)=="," then
						LocalIP=sys_sub(routeInfo,j+1,k-1)
						break;
					end
				end
			end
			if sys_sub(routeInfo,i,j)=="HdID=" or sys_sub(routeInfo,i,j)=="HDID=" then
				local flag=false
				for k=j+1,len,1 do
					if sys_sub(routeInfo,k,k)==";" or sys_sub(routeInfo,k,k)=="," then
						HdID=sys_sub(routeInfo,j+1,k-1)
						flag=true
						break;
					end
				end
				if not flag then
					HdID=sys_sub(routeInfo,j+1,len)
				end
			end
		end
	end
	local loginf={}
	loginf.MacAddress=MacAddress
	loginf.LocalIP=LocalIP
	loginf.HdID=HdID
	return loginf
end


_OnEventDefined(XMLLoad evt, sessionID)
	gCurSession=sessionID
	local userID = evt._GetFld("UserID");
	local baMapID = evt._GetFld("BAMapID");
	local routeInfo = evt._GetFld("RouteInfo");
	local localIPV4IP = evt._GetFld("LocalIPV4IP");	
	local logs = sys_format("XMLLoad:SessionID[%s]RouteInfo[%s]LocalIPV4IP[%s]UserID[%s]BAMapID[%s]",sessionID,routeInfo,localIPV4IP,userID,baMapID);
	_WriteAplLog(logs)
	
	--获取科创版信息
	gtKCBSupport["KCBSupport"] = sessionID
	
	local globalCondition = "VariableName='KCBSupport'";
	_GetCommonData("GlobalVariable2KCBSupport",condition=globalCondition,"GlobalVariable");
	
	if not userID or userID=="" then
		userID="全部"
	end
	if not baMapID or baMapID=="" then
		baMapID="全部"
	end	
	local loginf=getRouteInfoByStr(routeInfo)
	
	
	gtRouteInfo[sessionID]={}
	gtRouteInfo[sessionID].MacAddress=loginf.MacAddress or ""
	gtRouteInfo[sessionID].LocalIP=loginf.LocalIP or ""
	gtRouteInfo[sessionID].HdID=loginf.HdID or ""
	gtRouteInfo[sessionID].LocalIPV4IP=localIPV4IP
	
	sendUserBAMap(sessionID)
	currentBaMapID(sessionID,userID,baMapID,"1")
	if gIsInventoryInitialized==false then
		sys_insert(gtSendInventoryInitialized,sessionID)
	else
		SendInventoryInitialized(sessionID)
		local sortInventoryID={}
		for inventoryID,v in pairs(gtInventoryHeaderTable) do
			local key=v.CreateTime.."#"..inventoryID
			sys_insert(sortInventoryID,key)
		end
		sys_sort(sortInventoryID, "asc")
		for i,key in pairs(sortInventoryID) do
			local inventoryID=getTableByString(key,"#")[2]
			FreshComponent(sessionID,inventoryID)
			sendInventory(sessionID,inventoryID)
		end
		if gtSessionTable[sessionID].CurrentInventoryID~="" then
			local currentInventoryID=gtSessionTable[sessionID].CurrentInventoryID
			sendComponent(sessionID,currentInventoryID)
		end
		sendQuantityBalance(sessionID)
	end
    
    LoadCheckDD2Risk()
_End


_DefineEventObject XMLClose _AS _Input
	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

_OnEventDefined(XMLClose evt, sessionID)
	local logs = sys_format("XMLClose:sessionID[%s]",sessionID);
	_WriteAplLog(logs)		
	if gtSessionTable[sessionID] then
		gtSessionTable[sessionID]=nil
	end
_End

_DefineEventObject ExecShowMode _AS _Input
	_DefFld("ShowMode", _Int, 4)
	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

_OnEventDefined(ExecShowMode  evt,sessionID)
	gCurSession=sessionID
	
	local ExecShowMode=evt._GetFld("ShowMode");
	local log=sys_format("ExecShowMode:%d",ExecShowMode)
	_WriteAplLog(log)
	gtSessionTable[sessionID]=gtSessionTable[sessionID] or {}
	gtSessionTable[sessionID].ExecShowMode=ExecShowMode     --1成交明细;2成交汇总		
	local DTSEvent s_ExecEvent = _CreateEventObject("S_ExecEvent")
	s_ExecEvent._SetFld("IssueCode", "clearData")
	_SendEventToClient(s_ExecEvent,sessionID);
	
	if ExecShowMode == 2 then
		gtExecShowAllTable = {}
		for corp,v in pairs(gtShowExecTable) do
			if v.IsInternal~=1 or gInternalExecShowMode~="1" then
				local temp = {}
				temp.BAMapID = v.BAMapID
				temp.IssueCode = v.IssueCode
				temp.OpenClose = v.OpenClose
				temp.ExecValue = v.ExecAmount
				temp.Quantity =v.Quantity
				temp.ExecQty = v.ExecQty
				temp.CreRed = v.CreRed
				temp.BS = v.BuySell
				temp.IsInternal = v.IsInternal
				temp.WithFare = v.WithFare
				
				local accountCode=_PosBAMapAccount[v.BAMapID] or v.BAMapID
				local fareTable =PosFareDetail(accountCode, temp.IssueCode, temp)
				local TotalFare= fareTable.TotalFare or 0
				local Fare= fareTable.Fare or 0
				local TransferExpense= fareTable.TransferExpense or 0
				local StampTax= fareTable.StampTax or 0

				local showKey = sys_format("%s.%s.%s",v.BAMapID,v.IssueCode,v.BuySell)
				_WriteAplLog(showKey)
				if not gtExecShowAllTable[showKey] then
					gtExecShowAllTable[showKey] = {}
					gtExecShowAllTable[showKey].sumFare = TotalFare
					gtExecShowAllTable[showKey].sumFare1 = Fare
					gtExecShowAllTable[showKey].sumFare2 = TransferExpense
					gtExecShowAllTable[showKey].sumFare3 = StampTax
					gtExecShowAllTable[showKey].sumExecQty = v.ExecQty
					gtExecShowAllTable[showKey].sumExecAmount = v.ExecAmount
				else
					gtExecShowAllTable[showKey].sumFare = gtExecShowAllTable[showKey].sumFare + TotalFare
					gtExecShowAllTable[showKey].sumFare1 = gtExecShowAllTable[showKey].sumFare1 + Fare
					gtExecShowAllTable[showKey].sumFare2 = gtExecShowAllTable[showKey].sumFare2 + TransferExpense
					gtExecShowAllTable[showKey].sumFare3 = gtExecShowAllTable[showKey].sumFare3 + StampTax
					gtExecShowAllTable[showKey].sumExecQty = gtExecShowAllTable[showKey].sumExecQty + v.ExecQty
					gtExecShowAllTable[showKey].sumExecAmount = gtExecShowAllTable[showKey].sumExecAmount + v.ExecAmount
				end
			end
		end
	end
	
	for corpCode,value in pairs(gtShowExecTable) do
		RefreshSingleExec(sessionID,corpCode,value)
	end
_End

_DefineEventObject ShowManagerFee _AS _Input
	_DefFld("Show", _Int, 4)

	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

_OnEventDefined(ShowManagerFee evt,sessionID)
	gCurSession=sessionID
	
	local Show = evt._GetFld("Show");

	local logs = sys_format("ShowManagerFee:Show[%s]",Show);
	_WriteAplLog(logs)
	gShowManagerFee=Show
_End

_DefineEventObject BAMapIDIn _AS _Input
	_DefFld("UserID", _String, 22)
	_DefFld("BAMapID", _String, 22)
	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

--客户端界面点击树节点,点击查询节点默认选中查询资产，客户端发消息BAMapIDIn
_OnEventDefined(BAMapIDIn evt, sessionID)
	gCurSession=sessionID
	
	local userID = evt._GetFld("UserID");
	local baMapID = evt._GetFld("BAMapID");
	local logs = sys_format("BAMapIDIn:UserID[%s]BAMapID[%s]",userID,baMapID);
	_WriteAplLog(logs)
	if not userID or userID=="" then
		userID="全部"
	end
	if not baMapID or baMapID=="" then
		baMapID="全部"
	end	
	if userID~="" and baMapID~="" then
		local oldSelectedUserID=""
		local oldSelectedBAMapID=""
		if gtSessionTable[sessionID] then
			oldSelectedUserID=gtSessionTable[sessionID].SelectedUserID
			oldSelectedBAMapID=gtSessionTable[sessionID].SelectedBAMapID
		end
		if userID~=oldSelectedUserID or baMapID~=oldSelectedBAMapID then 	
			currentBaMapID(sessionID,userID,baMapID,"1")
		else
			_WriteAplLog("the same param")
		end
	else
		_WriteAplLog("not valid")
	end
_End
function currentBaMapID(sessionID,userID,baMapID,sendFlag)
	local log = sys_format("currentBaMapID:userID[%s]baMapID[%s]sendFlag[%s]",userID,baMapID,sendFlag);
	_WriteAplLog(log)
	gtSessionTable[sessionID]=gtSessionTable[sessionID] or {}
	gtSessionTable[sessionID].SelectedUserID = userID
	gtSessionTable[sessionID].SelectedBAMapID = baMapID	
	gtSessionTable[sessionID].CurBAMapIDTable = {}
	gtSessionTable[sessionID].SortBaMapIDTable = {}
	if not gtSessionTable[sessionID].CurIssueCode then
		gtSessionTable[sessionID].CurIssueCode=""
	end
	if not gtSessionTable[sessionID].CurMultiFireBaMapID then
		gtSessionTable[sessionID].CurMultiFireBaMapID=""
	end
	if not gtSessionTable[sessionID].CurrentInventoryID then
		gtSessionTable[sessionID].CurrentInventoryID=""
	end	
	
	if not gtSessionTable[sessionID].ExecShowMode then
		gtSessionTable[sessionID].ExecShowMode=1     --1成交明细;2成交汇总
	end	
	local CurIssueCode=gtSessionTable[sessionID].CurIssueCode
	local SelectedUserID=gtSessionTable[sessionID].SelectedUserID
	local SelectedBAMapID=gtSessionTable[sessionID].SelectedBAMapID
	if SelectedUserID=="全部" then
		if SelectedBAMapID == "全部" then
			for k, clientId in pairs(gOrderSortClient) do
				for bAMap,value in pairs(_PosBAMapTable) do
					if _PosBAMapAccount[bAMap] and gtRunAccountTable[bAMap] and gtZGProductAccountTable[bAMap] then
						local accountCode = _PosBAMapAccount[bAMap]
						if _PosFundStatus[accountCode] then
							local accountCodeType = _PosFundStatus[accountCode].Type
							local tmpClientID = _PosFundStatus[accountCode].ClientID
							if accountCodeType == "S" and (not isDefaultAccount(bAMap)) and tmpClientID == clientId then
								sys_insert(gtSessionTable[sessionID].SortBaMapIDTable,bAMap)
								gtSessionTable[sessionID].CurBAMapIDTable[bAMap] = 1
							end
						end
					end
				end
			end
			for bAMap,value in pairs(_PosBAMapTable) do
				if _PosBAMapAccount[bAMap] and gtZGProductAccountTable[bAMap] then
					local accountCode = _PosBAMapAccount[bAMap]
					if _PosFundStatus[accountCode] then
						local accountCodeType = _PosFundStatus[accountCode].Type
						local tmpClientID = _PosFundStatus[accountCode].ClientID
						if IsInTable(tmpClientID, gOrderSortClient) == false then
							if accountCodeType == "S" and (not isDefaultAccount(bAMap)) then
								sys_insert(gtSessionTable[sessionID].SortBaMapIDTable, bAMap)
								gtSessionTable[sessionID].CurBAMapIDTable[bAMap] = 1
							end
						end
					end
				end
			end
		else
			if _PosBAMapAccount[SelectedBAMapID] and gtRunAccountTable[SelectedBAMapID] and gtZGProductAccountTable[SelectedBAMapID] then	
				gtSessionTable[sessionID].CurBAMapIDTable[SelectedBAMapID] = 1
			end
		end
	else
		if SelectedBAMapID == "全部" then
			for k, clientId in pairs(gOrderSortClient) do
				for bAMap,value in pairs(_PosBAMapTable) do
					if _PosBAMapAccount[bAMap] and gtRunAccountTable[bAMap] and gtZGProductAccountTable[bAMap] then
						local accountCode = _PosBAMapAccount[bAMap]
						if _PosFundStatus[accountCode] then
							local accountCodeType = _PosFundStatus[accountCode].Type
							local tmpClientID = _PosFundStatus[accountCode].ClientID
							if accountCodeType == "S" and (not isDefaultAccount(bAMap)) and tmpClientID == clientId then
								if gtPosUserBAMapTable[SelectedUserID] then
									if gtPosUserBAMapTable[SelectedUserID][bAMap] then
										sys_insert(gtSessionTable[sessionID].SortBaMapIDTable, bAMap)
										gtSessionTable[sessionID].CurBAMapIDTable[bAMap] = 1
									end
								end
							end
						end
					end
				end
			end
			for bAMap,value in pairs(_PosBAMapTable) do
				if _PosBAMapAccount[bAMap] and gtRunAccountTable[bAMap] and gtZGProductAccountTable[bAMap]  then
					local accountCode = _PosBAMapAccount[bAMap]
					if _PosFundStatus[accountCode] then
						local accountCodeType = _PosFundStatus[accountCode].Type
						local tmpClientID = _PosFundStatus[accountCode].ClientID
						if IsInTable(tmpClientID, gOrderSortClient) == false then
							if accountCodeType == "S" and (not isDefaultAccount(bAMap)) then
								if gtPosUserBAMapTable[SelectedUserID] then
									if gtPosUserBAMapTable[SelectedUserID][bAMap] then
										sys_insert(gtSessionTable[sessionID].SortBaMapIDTable, bAMap)
										gtSessionTable[sessionID].CurBAMapIDTable[bAMap] = 1
									end
								end
							end
						end
					end
				end
			end
		else
			if _PosBAMapAccount[SelectedBAMapID] and gtRunAccountTable[SelectedBAMapID] and gtZGProductAccountTable[SelectedBAMapID]  then	
				gtSessionTable[sessionID].CurBAMapIDTable[SelectedBAMapID] = 1
			end
		end
	end
	
	if sendFlag=="1" and _PosStatus == POS_STATUS_NORMAL then
		gtSessionTable[sessionID].InitXMLData=true
		--清空证券持仓
		local DTSEvent s_PosEvent = _CreateEventObject("S_PosEvent")
		s_PosEvent._SetFld("IssueCode", "clearData")
		_SendEventToClient(s_PosEvent,sessionID);

		--清空期货持仓
		local DTSEvent f_PosEvent = _CreateEventObject("F_PosEvent")
		f_PosEvent._SetFld("IssueCode", "clearData")
		_SendEventToClient(f_PosEvent,sessionID);

		local DTSEvent s_OrderEvent = _CreateEventObject("S_OrderEvent")
		s_OrderEvent._SetFld("IssueCode", "clearData")
		_SendEventToClient(s_OrderEvent,sessionID);
		--清空期货委托
		local DTSEvent f_OrderEvent = _CreateEventObject("F_OrderEvent")
		f_OrderEvent._SetFld("IssueCode", "clearData")
		_SendEventToClient(f_OrderEvent,sessionID);			
		
		--清空证券成交
		local DTSEvent s_ExecEvent = _CreateEventObject("S_ExecEvent")
		s_ExecEvent._SetFld("IssueCode", "clearData")
		_SendEventToClient(s_ExecEvent,sessionID);		
		--清空期货成交
		local DTSEvent f_ExecEvent = _CreateEventObject("F_ExecEvent")
		f_ExecEvent._SetFld("IssueCode", "clearData")
		_SendEventToClient(f_ExecEvent,sessionID);		
		for posKey, pos in pairs(_PosPositionTable) do
			PosCalcValuationPL(pos)
		end
		RefreshPosFund(sessionID)			
		for corpCode,value in pairs(gtShowOrderTable) do
			RefreshSingleOrder(sessionID,corpCode,value)
		end
		
		local ExecShowMode = gtSessionTable[sessionID].ExecShowMode
		if ExecShowMode == 2 then
			gtExecShowAllTable = {}
			for corp,v in pairs(gtShowExecTable) do
				if v.IsInternal~=1 or gInternalExecShowMode~="1" then
					local temp = {}
					temp.BAMapID = v.BAMapID
					temp.IssueCode = v.IssueCode
					temp.OpenClose = v.OpenClose
					temp.ExecValue = v.ExecAmount
					temp.Quantity =v.Quantity
					temp.ExecQty = v.ExecQty
					temp.CreRed = v.CreRed
					temp.BS = v.BuySell
					temp.IsInternal = v.IsInternal
					temp.WithFare = v.WithFare
					
					local accountCode=_PosBAMapAccount[v.BAMapID] or v.BAMapID
					local fareTable =PosFareDetail(accountCode, temp.IssueCode, temp)
					local TotalFare= fareTable.TotalFare or 0
					local Fare= fareTable.Fare or 0
					local TransferExpense= fareTable.TransferExpense or 0
					local StampTax= fareTable.StampTax or 0

					local showKey = sys_format("%s.%s.%s",v.BAMapID,v.IssueCode,v.BuySell)
					if not gtExecShowAllTable[showKey] then
						gtExecShowAllTable[showKey] = {}
						gtExecShowAllTable[showKey].sumFare = TotalFare
						gtExecShowAllTable[showKey].sumFare1 = Fare
						gtExecShowAllTable[showKey].sumFare2 = TransferExpense
						gtExecShowAllTable[showKey].sumFare3 = StampTax
						gtExecShowAllTable[showKey].sumExecQty = v.ExecQty
						gtExecShowAllTable[showKey].sumExecAmount = v.ExecAmount
					else
						gtExecShowAllTable[showKey].sumFare = gtExecShowAllTable[showKey].sumFare + TotalFare
						gtExecShowAllTable[showKey].sumFare1 = gtExecShowAllTable[showKey].sumFare1 + Fare
						gtExecShowAllTable[showKey].sumFare2 = gtExecShowAllTable[showKey].sumFare2 + TransferExpense
						gtExecShowAllTable[showKey].sumFare3 = gtExecShowAllTable[showKey].sumFare3 + StampTax
						gtExecShowAllTable[showKey].sumExecQty = gtExecShowAllTable[showKey].sumExecQty + v.ExecQty
						gtExecShowAllTable[showKey].sumExecAmount = gtExecShowAllTable[showKey].sumExecAmount + v.ExecAmount
					end
				end
			end
		end
		
		for corpCode,value in pairs(gtShowExecTable) do
			RefreshSingleExec(sessionID,corpCode,value)
		end
		--清空历史委托信息表
		clearHistorySubmitInfo(sessionID)
		--清空历史成交信息表
		clearHistoryExecutionInfo(sessionID)
		--清空历史资金明细表
		clearHistoryFundJournalInfo(sessionID)
		--清空交割单表
		clearQueryS_DeliveryOrder(sessionID)
		clearQueryF_DeliveryOrder(sessionID)

		--查询当日资金流水
		QueryTodayFundJournal(sessionID,SelectedBAMapID)
		PriceServer(sessionID,CurIssueCode)
	end
end
--下单界面切换合约
_DefineEventObject ChangeFireIssue _AS _Input
	_DefFld("IssueCode",_String,20)	--合约代码
	_DefFld("Mode", _String, 1) -- 是否同时收数据，0表示主界面，1表示盘口，或者条件单需要多个股票同时收行情
_End

--下单界面切换合约
_OnEventDefined(ChangeFireIssue fireIssue,sessionID)
	gCurSession=sessionID
	if gInitialized then
		local issueCode = fireIssue._GetFld("IssueCode")--获取下单界面切换的合约代码
		local mode = fireIssue._GetFld("Mode")
		local marketCode = _PosIssueMarketTable[issueCode]
		local temptable = {}
		if not marketCode or marketCode == "" or marketCode == "0" then
			temptable = BigSmall(issueCode)
			if temptable ~= "error" then
				marketCode = temptable.MarketCode
				issueCode = temptable.IssueCode
			end
		end
		if marketCode then--合约代码合法才做下一步处理
			local log = sys_format("ChangeFireIssue, mode=[%s],issueCode=[%s]", mode,issueCode)
			_WriteAplLog(log)
			if mode == "1" then
				gCurIssueCodeTable[issueCode] = 0
			else
				gtSessionTable[sessionID]=gtSessionTable[sessionID] or {}
				gtSessionTable[sessionID].CurIssueCode=issueCode
				--根据合约所在的市场为下单界面设置相应的委托方式
				local orderTypeStr = ""
				if marketCode == "1" then
					orderTypeStr = ":限价委托;H:五档即成剩撤;I:五档即成转限价;"
				elseif marketCode == "2" then
					orderTypeStr = ":限价委托;U:对方最优价;V:本方最优价;W:即时成交剩撤;X:五档即成剩撤;Y:全额成交或撤销;"
				elseif marketCode == "3" then
					orderTypeStr = ":限价委托;F:市价;"
				elseif marketCode == "4" or marketCode == "5" or marketCode == "6" then
					orderTypeStr = ":限价委托;F:市价;"
				else
					orderTypeStr = ":限价委托;"
				end
				local orderTypelog = sys_format("*OrderTypeList, issue=[%s], orderTypeStr=[%s]", issueCode, orderTypeStr)
				_WriteAplLog(orderTypelog)

				--发送委托方式到下单界面的委托方式控件
				local DTSEvent orderInfoEvt = _CreateEventObject("OrderTypeInfoEvent")
				orderInfoEvt._SetFld("OrderType", orderTypeStr)
				_SendEventToClient(orderInfoEvt,sessionID)
			end

			_RegisterPrice(_IssueCode = issueCode, _MarketCode = marketCode)
			PriceServer(sessionID,issueCode)
		elseif gtInventoryHeaderTable[issueCode] and gtInventoryComponentTable[issueCode] then
			gtSessionTable[sessionID]=gtSessionTable[sessionID] or {}
			gtSessionTable[sessionID].CurIssueCode=issueCode
			local log = sys_format("ChangeFireIssue, issueCode=[%s]", issueCode)
			_WriteAplLog(log)
			local orderTypeStr = ":限价委托;"
			local DTSEvent orderInfoEvt = _CreateEventObject("OrderTypeInfoEvent")
			orderInfoEvt._SetFld("OrderType", orderTypeStr)
			_SendEventToClient(orderInfoEvt,sessionID)
			FreshComponent(sessionID,issueCode)
			PriceServer(sessionID,issueCode)
		else
			local err_log = sys_format("ChangeFireIssue, error issueCode=[%s]", issueCode)
			_WriteAplLog(err_log)
		end
	else
		local log = sys_format("ChangeFireIssue, gInitialized = false")
		_WriteAplLog(log)
	end
_End

--触发下单
_DefineEventObject FireEvent _AS _Input
	_DefFld("IssueCode", _String, 20)	--合约代码
	_DefFld("OrderType", _String, 2)	--委托类型
	_DefFld("Price", _String, 15)		--下单价格
	_DefFld("Quantity", _Int, 12)		--下单数量
	_DefFld("BuySell", _String, 1)		--买卖
	_DefFld("OpenClose", _Int, 1)		--开平
	_DefFld("BAMapID", _String, 15)		--账户
	_DefFld("PriceType", _String, 15)   --价格类型（买一价，卖一价等）
	_DefFld("OverPrice", _String, 15)   --超价
_End

function newPCID(baMapID)
	local pcid=""
	local nowHMS=GetHMS()
	if POS_ISUTFLAG == 0 then
		pcid = sys_format("%-10s%6s%04d",baMapID, nowHMS, _PosCheckIDSeq)
	else
		pcid = sys_format("%-10s%04d",baMapID, _PosCheckIDSeq)
	end
	_PosCheckIDSeq = _PosCheckIDSeq + 1
	if _PosCheckIDSeq >= 10000 then
		_PosCheckIDSeq = _PosCheckIDSeq - 10000
	end
	return pcid	
end
function setOrderRouteInfo(sessionID,pcid)
	if gtRouteInfo[sessionID] and pcid then
		local MacAddress=gtRouteInfo[sessionID].MacAddress or ""
		local LocalIP=gtRouteInfo[sessionID].LocalIP or ""
		local HdID=gtRouteInfo[sessionID].HdID or ""
		local LocalIPV4IP=gtRouteInfo[sessionID].LocalIPV4IP or ""
		local routeInfo=sys_format("LocalIP=%s;LocalIPV4IP=%s;MacAddress=%s;HdID=%s",LocalIP,LocalIPV4IP,MacAddress,HdID)
		_PosSenderRouteInfoTable[pcid]=routeInfo
		local log=sys_format("setOrderRouteInfo:%s,%s",pcid,routeInfo)
		_WriteAplLog(log)
	end	
end
--下单界面触发下单
_OnEventDefined(FireEvent fire,sessionID)
	gCurSession=sessionID
	if not gInitialized then
		local log = sys_format("下单失败:策略没有初始化完毕, 不允许下单")
		_WriteAplLog(log)
		showLog(sessionID,log)
	else
		local issueCode = fire._GetFld("IssueCode")			--合约代码
		local orderType = fire._GetFld("OrderType")			--委托方式
		local price = fire._GetFld("Price")					--价格
		local quantity = fire._GetFld("Quantity")			--数量
		local bs = fire._GetFld("BuySell")					--买卖
		local oc = fire._GetFld("OpenClose")				--开平
		local baMapID = fire._GetFld("BAMapID")				--账户
		local creRed = 0
		local marketCode = _PosIssueMarketTable[issueCode]	--市场号
		local priceType = fire._GetFld("PriceType")         --价格类型（买一价，卖一价等）
		local overPrice = fire._GetFld("OverPrice")         --超价
		local issueName = _PosIssueNameTable[issueCode]
		local productCode = _PosIssueProductCodeTable[issueCode]
		if productCode == "12" then
			if (sys_sub(issueName,1,2) == "R-" or sys_sub(issueName,1,2) == "GC") and bs=="1" then
				oc=0
				creRed=5
			end
		end
							
		local log = sys_format("FireEvent, issue=[%s], orderType=[%s],bs=[%s], oc=[%s],price=[%s], quantity=[%s],baMapID=[%s],priceType=[%s], overPrice=[%s]", issueCode, orderType, bs, oc, price, quantity,baMapID, priceType, overPrice)
		_WriteAplLog(log)

		--价格类型和超价逻辑
		if priceType ~= nil and priceType ~= "" then
			local newPrice = GetPrice(issueCode, priceType)
			if newPrice ~= 0 then
				local tick = _PosIssuePriceTickTable[issueCode]
				local diff = 0
				if overPrice - 0 > 0 then
					diff = tick * overPrice
				end
				if bs == "1" then
					price = newPrice - diff;
				elseif  bs == "3" then
					price = newPrice + diff;
				end
			end
		end

		--多空
		local baSubID = bs
		if oc == 0 then
			baSubID = bs
		else
			if bs == "3" then
				baSubID = "1"
			else
				baSubID = "3"
			end
		end

		--委托类型
		local tmpOrderType  = GetOrderTypeName(orderType)

		--交易类型
		local marginType = GetMarginType(marketCode, bs, oc, creRed)

		local accountName=GetAccountName(baMapID)
		
		local orderFlag = true
		
		local ForbidPosition = 0
		if oc == 1 and baMapID ~= "全部" and marketCode then
			local posKey = sys_format("%s.%s.%s",baMapID,baSubID,issueCode)
			if gtBAMapID2ForbidPositionTable[posKey] then
				ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition		
			end
			
			if _PosPositionTable[posKey] then
				local avlQty = _PosPositionTable[posKey].AvlQuantity
				if quantity > avlQty - ForbidPosition then
					--提示:可用不足,拒绝下单
					local OrderMsg=sys_format("【普通委托】操作:[下单],内容：理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]价格[%s].结果【失败,可用数量[%s]不足,禁用数量[%s]】",baMapID,accountName,issueCode,marginType,quantity,price,avlQty - ForbidPosition,ForbidPosition)
					showLog(sessionID,OrderMsg)
					sendOprationLog(sessionID,OrderMsg)
					orderFlag = false
				end
			end
		end
		
		if orderFlag then
			local selectedUserID=""
			if gtSessionTable[sessionID] then 
				if gtSessionTable[sessionID].SelectedUserID then
					selectedUserID=gtSessionTable[sessionID].SelectedUserID
				end
			end
			local currentUserID = _GetDealerID()
			
			
			local msg=sys_format("【普通委托】操作:[下单],内容：理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]价格[%s].",baMapID,accountName,issueCode,marginType,quantity,price)
			if gtUserRole[currentUserID] then 
				if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
					local roleName=gtUserRole[currentUserID].RoleName or ""
					msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]价格[%s].",roleName,selectedUserID,baMapID,accountName,issueCode,marginType,quantity,price)
				end
			end
		
			if not marketCode then
				if gtInventoryHeaderTable[issueCode] and gtInventoryComponentTable[issueCode] then
					if gtSessionTable[sessionID].CurBAMapIDTable then
						for bMID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
							fireInventory(sessionID,bMID,baSubID,issueCode,oc,bs,price,quantity,creRed)
						end
					end
				else
					local log = sys_format("下单失败: 代码[%s]不合法", issueCode)
					_WriteAplLog(log)
					showLog(sessionID,log)
					msg=msg.."结果【失败,代码不合法】"
					sendOprationLog(sessionID,msg)
				end
			elseif quantity <= 0 then
				local log = sys_format("下单失败: 下单数量[%d]不合法", quantity)
				_WriteAplLog(log)
				showLog(sessionID,log)
				msg=msg.."结果【失败,数量不合法】"
				sendOprationLog(sessionID,msg)
			elseif marginType == "" then
				local log = sys_format("下单失败: 无法识别交易类型")
				_WriteAplLog(log)
				showLog(sessionID,log)
				msg=msg.."结果【失败,无法识别交易类型】"
				sendOprationLog(sessionID,msg)
			elseif tmpOrderType == "无法识别" then
				local log = sys_format("下单失败: 无法识别委托类型")
				_WriteAplLog(log)
				showLog(sessionID,log)
				msg=msg.."结果【失败,无法识别委托类型】"
				sendOprationLog(sessionID,msg)
			else
				local checkAccount = true
				if baMapID == "" then
					if marketCode == "1" or marketCode == "2" then
						checkAccount = false
						local log = sys_format("下单失败: 未设置证券账户, 禁止证券交易")
						_WriteAplLog(log)
						showLog(sessionID,log)
						msg=msg.."结果【失败,未设置证券账户】"
						sendOprationLog(sessionID,msg)
					else
						checkAccount = false
						local log = sys_format("下单失败: 未设置期货账户, 禁止期货交易")
						_WriteAplLog(log)
						showLog(sessionID,log)
					end
				end
				if checkAccount == true then
					local ret = CheckOrder(issueCode, bs, oc, creRed)--检查Order
					if ret.Result == false then
						local log = sys_format("下单失败: %s", ret.Reason)
						_WriteAplLog(log)
						showLog(sessionID,log)
						msg=sys_format("%s结果【失败,%s】",msg,ret.Reason)
						sendOprationLog(sessionID,msg)
					else
						if baMapID == "全部" then
							if gtSessionTable[sessionID] then 
							
								local batchID=sys_format("All%s%d",currentUserID,gIndexAllBAMapOrder)
								gIndexAllBAMapOrder=gIndexAllBAMapOrder+1
								SendOrder_All(sessionID,issueCode, bs, oc, price, quantity, orderType, baSubID, creRed,batchID)
							else
								local log = sys_format("下单失败: 获取全部账户失败")
								_WriteAplLog(log)
								showLog(sessionID,log)
								msg=sys_format("%s结果【失败,获取全部账户失败】",msg)
								sendOprationLog(sessionID,msg)
							end
						else
							--获取单子的DealerID
							local dealerID = GetOrderDealerID(baMapID)
							local dealerlog = sys_format("FireEvent: dealerID=[%s]", dealerID)
							_WriteAplLog(dealerlog)
							--下单价格
							local priceInfo = _PosPriceTable[issueCode]
							local orderPrice = price
							if orderType == "" then--如果没有OrderType,则下单价格为所传的价格
								orderPrice = price
							else
								if bs == "3" then
									orderPrice = priceInfo.UpLimitPrice --模拟市价， 卖用涨停价
								end
							end
							price = orderPrice
							local firePriceLog = sys_format("FireEvent:price=%s", price)
							_WriteAplLog(firePriceLog)

							--下单
							if CheckSubmitIssue(sessionID,issueCode,baMapID) then
								local issueCode_123 = sys_sub(issueCode,1,3)
								--if issueCode_123 ~= "688" then
								if not sys_find(gKCBList,issueCode_123,1) then
									--先下整股
									local qtyTmp = 100*sys_floor(quantity/100)
									if qtyTmp > 0  then
										local remainQty=qtyTmp
										while remainQty>0 do 
											local orderQty=remainQty
											if orderQty>gS_SingleOrderQuantity and gS_SingleOrderQuantity>0 then
												orderQty=gS_SingleOrderQuantity
											end
											remainQty=remainQty-orderQty;
											local pcid=newPCID(baMapID)
											setOrderRouteInfo(sessionID,pcid)
											local ret = PosSubmitSingleOrder(baMapID, baSubID, issueCode, bs, oc, price, orderQty, creRed, dealerID, nil, nil, orderType, pcid)
											if ret.Result then
												local log = sys_format("单笔委托:理财账户[%s]代码[%s]数量[%d] 已发送至风控系统,委托号为[%s],等待回应！",baMapID,issueCode,orderQty,ret.PositionCheckID)
												_WriteAplLog(log)
												showLog(sessionID,log)
												gtOrderSessionTable[ret.PositionCheckID]=sessionID
												
												msg=sys_format("【普通委托】操作:[下单],内容：理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]委托数量[%d]价格[%s].结果【已发送至风控系统】",baMapID,accountName,issueCode,marginType,quantity,orderQty,price)
												if gtUserRole[currentUserID] then 
													if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
														local roleName=gtUserRole[currentUserID].RoleName or ""
														msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]委托数量[%d]价格[%s].结果【已发送至风控系统】",roleName,selectedUserID,baMapID,accountName,issueCode,marginType,quantity,orderQty,price)
													end
												end
												
												sendOprationLog(sessionID,msg)
											else
												if ret.Reason then
													local log = sys_format("单笔委托:理财账户[%s]代码[%s]数量[%d] 发送至风控系统失败！原因:%s",baMapID,issueCode,orderQty,ret.Reason)
													_WriteAplLog(log)
													showLog(sessionID,log)
													msg=sys_format("【普通委托】操作:[下单],内容：理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]委托数量[%d]价格[%s].结果【失败,%s】",baMapID,accountName,issueCode,marginType,quantity,orderQty,price,ret.Reason)
													if gtUserRole[currentUserID] then 
														if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
															local roleName=gtUserRole[currentUserID].RoleName or ""
															msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]委托数量[%d]价格[%s].结果【失败,%s】",roleName,selectedUserID,baMapID,accountName,issueCode,marginType,quantity,orderQty,price,ret.Reason)
														end
													end
													sendOprationLog(sessionID,msg)
												end 
											end
										end
									end
									quantity = quantity - qtyTmp
								end
								if quantity > 0 then
									--再下零股
									local pcid=newPCID(baMapID)
									setOrderRouteInfo(sessionID,pcid)
									ret = PosSubmitSingleOrder(baMapID, baSubID, issueCode, bs, oc, price, quantity, 0, dealerID, "", nil, orderType,pcid)
									if ret.Result then
										local log = sys_format("单笔委托:理财账户[%s]代码[%s]数量[%d] 已发送至风控系统，委托号[%s],等待回应！",baMapID,issueCode,quantity,ret.PositionCheckID)
										_WriteAplLog(log)
										showLog(sessionID,log)
										gtOrderSessionTable[ret.PositionCheckID]=sessionID
										msg=sys_format("【普通委托】操作:[下单],内容：理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]价格[%s].结果【已发送至风控系统】",baMapID,accountName,issueCode,marginType,quantity,price)
										if gtUserRole[currentUserID] then 
											if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
												local roleName=gtUserRole[currentUserID].RoleName or ""
												msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]价格[%s].结果【已发送至风控系统】",roleName,selectedUserID,baMapID,accountName,issueCode,marginType,quantity,price)
											end
										end
										sendOprationLog(sessionID,msg)
									else
										if ret.Reason then
											local log = sys_format("单笔委托:理财账户[%s]代码[%s]数量[%d] 发送至风控系统失败！原因:%s",baMapID,issueCode,quantity,ret.Reason)
											_WriteAplLog(log)
											showLog(sessionID,log)
											msg=sys_format("【普通委托】操作:[下单],内容：理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]价格[%s].结果【失败,%s】",baMapID,accountName,issueCode,marginType,quantity,price,ret.Reason)
											if gtUserRole[currentUserID] then 
												if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
													local roleName=gtUserRole[currentUserID].RoleName or ""
													msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[%s]理财账户名[%s]代码[%s]买卖[%s]数量[%d]价格[%s].结果【失败,%s】",roleName,selectedUserID,baMapID,accountName,issueCode,marginType,quantity,price,ret.Reason)
												end
											end
											sendOprationLog(sessionID,msg)
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
_End

function GetPrice(issueCode, priceType)
	local price = gtPriceTable[issueCode]

	if priceType == "涨停" then
		return price.upperLimitPrice;
	elseif priceType == "跌停" then
		return price.lowerLimitPrice;
	elseif priceType == "卖十价" then
		return price.askPrice_10;
	elseif priceType == "卖九价" then
		return price.askPrice_9;
	elseif priceType == "卖八价" then
		return price.askPrice_8;
	elseif priceType == "卖七价" then
		return price.askPrice_7;
	elseif priceType == "卖六价" then
		return price.askPrice_6;
	elseif priceType == "卖五价" then
		return price.askPrice_5;
	elseif priceType == "卖四价" then
		return price.askPrice_4;
	elseif priceType == "卖三价" then
		return price.askPrice_3;
	elseif priceType == "卖二价" then
		return price.askPrice_2;
	elseif priceType == "卖一价" then
		return price.askPrice_1;
	elseif priceType == "买一价" then
		return price.bidPrice_1;
	elseif priceType == "买二价" then
		return price.bidPrice_2;
	elseif priceType == "买三价" then
		return price.bidPrice_3;
	elseif priceType == "买四价" then
		return price.bidPrice_4;
	elseif priceType == "买五价" then
		return price.bidPrice_5;
	elseif priceType == "买六价" then
		return price.bidPrice_6;
	elseif priceType == "买七价" then
		return price.bidPrice_7;
	elseif priceType == "买八价" then
		return price.bidPrice_8;
	elseif priceType == "买九价" then
		return price.bidPrice_9;
	elseif priceType == "买十价" then
		return price.bidPrice_10;
	elseif priceType == "最新价" then
		return price.lastPrice;
	else
		return "0";
	end
end

--一键清仓
_DefineEventObject ClosePosition _AS _Input
	_DefFld("PriceType", _String, 20)
	_DefFld("RatioType", _String, 20)
	_DefFld("Ratio", _String, 10)
	_DefFld("BAMapID", _String, 20)
	_SetDataType(_EventOtherType)
_End
_OnEventDefined(ClosePosition evt, sessionID)
	gCurSession=sessionID
	local PriceType = evt._GetFld("PriceType")
	local RatioType = evt._GetFld("RatioType")
	local Ratio = evt._GetFld("Ratio")
	local BAMapID = evt._GetFld("BAMapID")
	if (not PriceType) or PriceType=="" or (PriceType~="最新价" and PriceType~="对手价" and PriceType~="涨跌停") then
		PriceType="对手价"
	end
	if RatioType=="输入比例"  then
		local inLog=sys_format("一键清仓,理财帐户%s,价格类型%s,比例类型%s,比例%f",BAMapID,PriceType,RatioType,Ratio)
		sendLog(sessionID,inLog)
	elseif RatioType=="全平"  then
		local inLog=sys_format("一键清仓,理财帐户%s,价格类型%s,比例类型%s",BAMapID,PriceType,RatioType)
		sendLog(sessionID,inLog)
	end
	local AccountType=""
	local accountCode=BAMapID
	if _PosBAMapAccount[BAMapID] then
		accountCode=_PosBAMapAccount[BAMapID]
	end
	if _PosFundStatus[accountCode] then
		AccountType=_PosFundStatus[accountCode].Type	
	end

	local closNum=0
	for posKey, pos in pairs(_PosPositionTable) do
		if pos then
			if pos.BAMapID==BAMapID then
				local avlQuantity = pos.AvlQuantity;

				local ForbidPosition = 0
				if gtBAMapID2ForbidPositionTable[posKey] then
					ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition		
				end 
				avlQuantity = avlQuantity - ForbidPosition
				
				local issueCode = pos.IssueCode
				local bs=sys_sub(pos.BASubID,1,1)
				local buSell="1"
				if bs=="3" then
					buSell="1"
				elseif bs=="1" then
					buSell="3"
				end
				local openClose=1
				local marketCode = _PosIssueMarketTable[issueCode]
				if marketCode=="4"  then
					openClose=3
				end
				if avlQuantity>0 and pos.Quantity>0 then
					local priceInfo = _PosPriceTable[issueCode]
					if priceInfo then
						local orderPrice=0
						local orderPriceType="LastPrice"
						if buSell=="1" then
							if PriceType=="最新价" then
								orderPriceType="LastPrice"
							elseif  PriceType=="对手价" then
								orderPriceType="BidPrice1"
							elseif   PriceType=="涨跌停" then
								orderPriceType="LowLimitPrice"
							end
						elseif buSell=="3" then
							if PriceType=="最新价" then
								orderPriceType="LastPrice"
							elseif  PriceType=="对手价" then
								orderPriceType="AskPrice1"
							elseif   PriceType=="涨跌停" then
								orderPriceType="UpLimitPrice"
							end
						end
						if priceInfo[orderPriceType] and priceInfo[orderPriceType]~="" then
							orderPrice=priceInfo[orderPriceType]
						else
							if buSell=="1" then
								orderPrice=priceInfo.BidPrice1
							elseif buSell=="3" then
								orderPrice=priceInfo.AskPrice1
							end
							if not orderPrice or orderPrice=="" then
								orderPrice = priceInfo.LastPrice
							end
						end
						if (not orderPrice) or orderPrice==0 or orderPrice=="" then
							local log=sys_format("代码[%s]无行情清仓失败",issueCode)
							sendLog(sessionID,log)
						else
							local baMapID=pos.BAMapID
							local baSubID=pos.BASubID
							local dealerID = _GetDealerID()--当前用户
							local creRed = 0
							local batchID=""
							local orderQuantity=avlQuantity
							if RatioType=="输入比例"  then
								orderQuantity=sys_floor(avlQuantity*Ratio+0.5)
								if AccountType=="S" then
									orderQuantity=100*sys_floor(avlQuantity*Ratio/100+0.5)
								end 
								if orderQuantity>avlQuantity then
									orderQuantity=avlQuantity
								end
							end
							local pcid=newPCID(baMapID)
							setOrderRouteInfo(sessionID,pcid)
							local ret = PosSubmitSingleOrder(baMapID, baSubID, issueCode, buSell, openClose, orderPrice, orderQuantity, creRed, dealerID,batchID, POS_SPECULATE, "",pcid)
							if ret.Result then
								local log = sys_format("平仓:子帐号[%s]代码[%s]数量[%d]价格[%s]pcid[%s]已发出",baMapID,issueCode,orderQuantity,orderPrice,ret.PositionCheckID)
								sendLog(sessionID,log)
								closNum=closNum+1
								gtOrderSessionTable[ret.PositionCheckID]=sessionID
							else
								local reason=""
								if ret.Reason then
									reason=ret.Reason
								end
								local log = sys_format("平仓:子帐号[%s]代码[%s]数量[%d]价格[%s]平仓失败,原因:%s",baMapID,issueCode,orderQuantity,orderPrice,reason)
								sendLog(sessionID,log)
							end
						end
					else
						local log=sys_format("代码[%s]无行情平仓失败",issueCode)
						sendLog(sessionID,log)
					end
				end
			end 
		end
	end
	local log=sys_format("此次一键清仓发出[%s]个委托",closNum)
	sendLog(sessionID,log)
_End
--发送撤单广播给快捷下单
function BroadcastCancelOrder(corpCode,status)
	local DTSUnifieldMessage message;
	local subject = "CancelOrder1"
	message.setClientNo(subject);
	message.addField("CorpCode");
	message.addValue(corpCode);
	message.addField("Status");
	message.addValue(status);

	local log = sys_format("BroadcastCancelOrder:subject=[%s],corpCode=[%s],status[%s]",subject,corpCode,status)
	_WriteAplLog(log)

	local ret = _PublishUnifieldMessage(subject, message)
	if ret then
		_WriteAplLog("广播撤单消息成功............")
	end
end

--接收从快捷下单发来的撤单消息
_OnReceiveUnifieldMessage("S02", "CancelOrder2", DTSUnifieldMessage message)
	_WriteAplLog("Begin CancelOrder2")

	message.first()
    while not message.eof() do
		--_WriteAplLog("接收到委托工具发来的撤单消息")

		local corpCode = message.getValueByName("CorpCode")
		local status = message.getValueByName("Status")
		--维护已报待撤，并刷新委托表状态
		if gtShowOrderTable[corpCode] then
			gtShowOrderTable[corpCode].Status = status
			--发送委托
			RefreshSingleOrder("All",corpCode,gtShowOrderTable[corpCode])
		end
        message.next()
    end
	message.clear()
_End

--撤单
_DefineEventObject CancelOrderEvent _AS _Input
	_DefFld("CorpCode", _String, 25)	--内部委托号
_End

--撤单
_OnEventDefined(CancelOrderEvent order,sessionID)
	gCurSession=sessionID
	local corpCode = order._GetFld("CorpCode")--内部委托号
	
	if not gInitialized then
		local log = sys_format("撤单失败: 策略没有初始化完毕, 不允许撤单")
		_WriteAplLog(log)
		showLog(sessionID,log)
		local msg=sys_format("【普通委托】操作:[撤单],内容：内部委托号[%s].结果【失败,未初始化完毕不允许撤单】",corpCode)
		sendOprationLog(sessionID,msg)
	else
		local log = sys_format("CancelOrderEvent: corpCode=%s", corpCode)
		_WriteAplLog(log)				
		local flag=false --是否为强平单		
		if gtShowOrderTable[corpCode] then
			local batchID =gtShowOrderTable[corpCode].BatchID
			if batchID and batchID~="" then
				if sys_len(batchID)>=6 then
					if sys_sub(batchID,1,6)=="Index:" then
						flag=true 
					end
					if sys_sub(batchID,1,6)=="MClose" then
						flag=true 
					end
				end
			end
		end
		if not flag then 
			local pcid=gtShowOrderTable[corpCode].PositionCheckID
			setOrderRouteInfo(sessionID,pcid)
			local ret = PosCancelOrder(corpCode)--撤单
			if ret.Result then
				local msg=sys_format("【普通委托】操作:[撤单],内容：内部委托号[%s].结果【已发送】",corpCode)
				sendOprationLog(sessionID,msg)
			else
				if ret.Reason then
					local log = sys_format("内部委托号[%s]撤单委托发送至风控系统失败!;原因:%s",corpCode,ret.Reason)
					_WriteAplLog(log)
					showLog(sessionID,log)
					local msg=sys_format("【普通委托】操作:[撤单],内容：内部委托号[%s].结果【失败,%s】",corpCode,ret.Reason)
					sendOprationLog(sessionID,msg)
				end
			end
		else
			local log = sys_format("内部委托号[%s]强平委托无权撤单!",corpCode)
			_WriteAplLog(log)
			showLog(sessionID,log)
			local msg=sys_format("【普通委托】操作:[撤单],内容：内部委托号[%s].结果【失败,强平委托无权撤单】",corpCode)
			sendOprationLog(sessionID,msg)
		end 
	end
_End

--证券代码全部撤单
_DefineEventObject CancelIssueOrderEvent _AS _Input
	_DefFld("IssueCode", _String, 25)	--证券代码
_End

--证券代码全部撤单
_OnEventDefined(CancelIssueOrderEvent order,sessionID)
	gCurSession=sessionID
	local issueCode = order._GetFld("IssueCode")--证券代码
	if not gInitialized then
		local log = sys_format("issueCode=%s证券代码全部撤单失败: 策略没有初始化完毕, 不允许撤单", issueCode)
		_WriteAplLog(log)
		showLog(sessionID,log)
	else
		local log = sys_format("issueCode=%s证券代码全部撤单开始...", issueCode)
		_WriteAplLog(log)
		showLog(sessionID,log)

		local workOrderCnt = 0
		for corpCode, value in pairs(gtWorkingOrderTable) do
			if gtSessionTable[sessionID].CurBAMapIDTable then
				if gtSessionTable[sessionID].CurBAMapIDTable[value.BAMapID] and value.IssueCode == issueCode then
				
				
					local flag=false --是否为强平单
					
					if gtShowOrderTable[corpCode] then
						local batchID =gtShowOrderTable[corpCode].BatchID
						if batchID and batchID~="" then
							if sys_len(batchID)>=6 then
								if sys_sub(batchID,1,6)=="Index:" then
									flag=true 
								end
								if sys_sub(batchID,1,6)=="MClose" then
									flag=true 
								end
							end
						end
					end
					if not flag then
						workOrderCnt = workOrderCnt + 1

						local log = sys_format("CancelAllOrderEvent: issueCode=%s, corpCode=%s, workingQty=%.0f", issueCode, corpCode, value.WorkingQty)
						_WriteAplLog(log)
						local pcid=gtShowOrderTable[corpCode].PositionCheckID
						setOrderRouteInfo(sessionID,pcid)
						local ret = PosCancelOrder(corpCode)--撤单
						if ret.Result then
						else
							if ret.Reason then
								local log = sys_format("内部委托号[%s]撤单委托发送至风控系统失败!;原因:%s",corpCode,ret.Reason)
								_WriteAplLog(log)
							end
						end
					end
				end
			end
		end

		if workOrderCnt == 0 then
			local log = sys_format("issueCode=%s证券代码全部撤单结束: 当前无可撤委托!", issueCode)

			_WriteAplLog(log)
			showLog(sessionID,log)
		else
			local log = sys_format("issueCode=%s证券代码全部撤单结束!", issueCode)

			_WriteAplLog(log)
			showLog(sessionID,log)
		end
	end
_End

--全部撤单
_DefineEventObject CancelAllOrderEvent _AS _Input

_End

--全部撤单
_OnEventDefined(CancelAllOrderEvent order,sessionID)
	gCurSession=sessionID
	if not gInitialized then
		local log = sys_format("全部撤单失败: 策略没有初始化完毕, 不允许撤单")
		_WriteAplLog(log)
		showLog(sessionID,log)
		local msg="【普通委托】操作:[全部撤单].结果【失败,未初始化完毕不允许撤单】"
		sendOprationLog(sessionID,msg)
	else
		local log = "全部撤单开始..."
		_WriteAplLog(log)
		showLog(sessionID,log)

		local workOrderCnt = 0
		for corpCode, value in pairs(gtWorkingOrderTable) do
			if gtSessionTable[sessionID].CurBAMapIDTable then
				if gtSessionTable[sessionID].CurBAMapIDTable[value.BAMapID] then
				
					local flag=false --是否为强平单
					
					if gtShowOrderTable[corpCode] then
						local batchID =gtShowOrderTable[corpCode].BatchID
						if batchID and batchID~="" then
							if sys_len(batchID)>=6 then
								if sys_sub(batchID,1,6)=="Index:" then
									flag=true 
								end
								if sys_sub(batchID,1,6)=="MClose" then
									flag=true 
								end
							end
						end
					end
				
				
					if not flag then 
						workOrderCnt = workOrderCnt + 1

						local log = sys_format("CancelAllOrderEvent: corpCode=%s, workingQty=%.0f", corpCode, value.WorkingQty)
						_WriteAplLog(log)
						local pcid=gtShowOrderTable[corpCode].PositionCheckID
						setOrderRouteInfo(sessionID,pcid)
						local ret = PosCancelOrder(corpCode)--撤单
						if ret.Result then
							local msg=sys_format("【普通委托】操作:[全部撤单],内容：内部委托号[%s].结果【已发送】",corpCode)
							sendOprationLog(sessionID,msg)
						else
							if ret.Reason then
								local log = sys_format("内部委托号[%s]撤单委托发送至风控系统失败!;原因:%s",corpCode,ret.Reason)
								_WriteAplLog(log)
								local msg=sys_format("【普通委托】操作:[全部撤单],内容：内部委托号[%s].结果【失败,%s】",corpCode,ret.Reason)
								sendOprationLog(sessionID,msg)
							end
						end
					end
				end
			end
		end

		if workOrderCnt == 0 then
			local log = "全部撤单结束: 当前无可撤委托!"

			_WriteAplLog(log)
			showLog(sessionID,log)
		else
			local log = "全部撤单结束!"

			_WriteAplLog(log)
			showLog(sessionID,log)
		end
	end
_End

--撤买
_DefineEventObject CancelBuyOrderEvent _AS _Input

_End

--撤买
_OnEventDefined(CancelBuyOrderEvent order,sessionID)
	gCurSession=sessionID
	if not gInitialized then
		local log = sys_format("撤买失败: 策略没有初始化完毕,不允许撤单")
		_WriteAplLog(log)
		showLog(sessionID,log)
		local msg="【普通委托】操作:[撤买].结果【失败,未初始化完毕不允许撤单】"
		sendOprationLog(sessionID,msg)
	else
		local log = "撤买开始..."
		_WriteAplLog(log)
		showLog(sessionID,log)

		local workOrderCnt = 0
		for corpCode, value in pairs(gtWorkingOrderTable) do
			if gtSessionTable[sessionID].CurBAMapIDTable[value.BAMapID] and value.BuySell == "3" then
			
				local flag=false --是否为强平单
				if gtShowOrderTable[corpCode] then
					local batchID =gtShowOrderTable[corpCode].BatchID
					if batchID and batchID~="" then
						if sys_len(batchID)>=6 then
							if sys_sub(batchID,1,6)=="Index:" then
								flag=true 
							end
							if sys_sub(batchID,1,6)=="MClose" then
								flag=true 
							end
						end
					end
				end
				if not flag then 
			
			
			
					workOrderCnt = workOrderCnt + 1

					local log = sys_format("CancelBuyOrderEvent: corpCode=%s, workingQty=%.0f", corpCode, value.WorkingQty)
					_WriteAplLog(log)
					local pcid=gtShowOrderTable[corpCode].PositionCheckID
					setOrderRouteInfo(sessionID,pcid)
					local ret = PosCancelOrder(corpCode)--撤单
					if ret.Result then
						local msg=sys_format("【普通委托】操作:[撤买],内容：内部委托号[%s].结果【已发送】",corpCode)
						sendOprationLog(sessionID,msg)
					else
						if ret.Reason then
							local log = sys_format("内部委托号[%s]撤单委托发送至风控系统失败!;原因:%s",corpCode,ret.Reason)
							_WriteAplLog(log)
							local msg=sys_format("【普通委托】操作:[撤买],内容：内部委托号[%s].结果【失败,%s】",corpCode,ret.Reason)
							sendOprationLog(sessionID,msg)
						end
					end
				end
			else

			end
		end

		if workOrderCnt == 0 then
			local log = "撤买结束: 当前无可撤委托!"

			_WriteAplLog(log)
			showLog(sessionID,log)
		else
			local log = "撤买结束!"

			_WriteAplLog(log)
			showLog(sessionID,log)
		end
	end
_End

--撤卖
_DefineEventObject CancelSellOrderEvent _AS _Input

_End

--撤卖
_OnEventDefined(CancelSellOrderEvent order,sessionID)
	gCurSession=sessionID
	if not gInitialized then
		local log = sys_format("撤卖失败: 策略没有初始化完毕, 不允许撤单")
		_WriteAplLog(log)
		showLog(sessionID,log)
		local msg="【普通委托】操作:[撤卖].结果【失败,未初始化完毕不允许撤单】"
		sendOprationLog(sessionID,msg)		
	else
		local log = "撤卖开始..."
		_WriteAplLog(log)
		showLog(sessionID,log)

		local workOrderCnt = 0
		for corpCode, value in pairs(gtWorkingOrderTable) do
			if gtSessionTable[sessionID].CurBAMapIDTable[value.BAMapID] and value.BuySell == "1" then
				local flag=false --是否为强平单
				if gtShowOrderTable[corpCode] then
					local batchID =gtShowOrderTable[corpCode].BatchID
					if batchID and batchID~="" then
						if sys_len(batchID)>=6 then
							if sys_sub(batchID,1,6)=="Index:" then
								flag=true 
							end
							if sys_sub(batchID,1,6)=="MClose" then
								flag=true 
							end
						end
					end
				end
				if not flag then 
			
					workOrderCnt = workOrderCnt + 1

					local log = sys_format("CancelSellOrderEvent: corpCode=%s, workingQty=%.0f", corpCode, value.WorkingQty)
					_WriteAplLog(log)
					local pcid=gtShowOrderTable[corpCode].PositionCheckID
					setOrderRouteInfo(sessionID,pcid)
					local ret = PosCancelOrder(corpCode)--撤单
					if ret.Result then
						local msg=sys_format("【普通委托】操作:[撤卖],内容：内部委托号[%s].结果【已发送】",corpCode)
						sendOprationLog(sessionID,msg)
					else
						if ret.Reason then
							local log = sys_format("内部委托号[%s]撤单委托已发送至风控系统,等待回应!",corpCode,ret.Reason)

							_WriteAplLog(log)
							local msg=sys_format("【普通委托】操作:[撤卖],内容：内部委托号[%s].结果【失败,%s】",corpCode,ret.Reason)
							sendOprationLog(sessionID,msg)
						end
					end
				end
			else

			end
		end

		if workOrderCnt == 0 then
			local log = "撤卖结束: 当前无可撤委托!"

			_WriteAplLog(log)
			showLog(sessionID,log)
		else
			local log = "撤卖结束!"

			_WriteAplLog(log)
			showLog(sessionID,log)
		end
	end
_End

--手动刷新最新的资金行情信息
_DefineEventObject RefreshPosFundInfo _AS _Input

_End

_OnEventDefined(RefreshPosFundInfo evt, sessionID)
	_WriteAplLog("RefreshPosFundInfo")
	gCurSession=sessionID
	for posKey, pos in pairs(_PosPositionTable) do
		PosCalcValuationPL(pos)
	end	
	RefreshPosFund(sessionID)
_End

function CalPos_IssueCode(sessionID,pos)
	local issueCode = pos.IssueCode
	gtSessionTable[sessionID].PositionTable[issueCode] = nil
	for posKey, subPos in pairs(_PosPositionTable) do
		if subPos.IssueCode == pos.IssueCode then
			Sub_CalPos(sessionID,subPos)
		end
	end
end

function CalPosV(sessionID)
	gtSessionTable[sessionID].PositionTable = {}
	for posKey, pos in pairs(_PosPositionTable) do
		Sub_CalPos(sessionID,pos)
	end
end

function Sub_CalPos(sessionID,subPos)
	local baMapId = subPos.BAMapID
	if baMapId then
		if gtSessionTable[sessionID].CurBAMapIDTable then
			if gtSessionTable[sessionID].CurBAMapIDTable[baMapId] then
				local issueCode = subPos.IssueCode
				local issueName = _PosIssueNameTable[issueCode];
				local marketCode = _PosIssueMarketTable[issueCode]
				local marketName = gtMarketNameTable[marketCode]


				local formatPriceExponent = getPriceFormat(issueCode);
				local contractSize = 1
				if _PosIssueContractSizeTable[issueCode] then
					contractSize = _PosIssueContractSizeTable[issueCode]
				end

				if not gtSessionTable[sessionID].PositionTable[issueCode] then
					gtSessionTable[sessionID].PositionTable[issueCode] = {}
					gtSessionTable[sessionID].PositionTable[issueCode]["IssueCode"] = issueCode;
					gtSessionTable[sessionID].PositionTable[issueCode]["IssueName"] = issueName;
					gtSessionTable[sessionID].PositionTable[issueCode]["Quantity"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["AvlQuantity"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["WorkingQtyOfClose"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["RealizedPL"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["CumulationPL"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["CumulationAdjustPL"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["CumulationFare"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["Fare"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["CumulationDividend"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["ValuationPL"] = 0
					gtSessionTable[sessionID].PositionTable[issueCode]["MarketName"] = marketName
					gtSessionTable[sessionID].PositionTable[issueCode]["BAMapID"] = "全部"
					gtSessionTable[sessionID].PositionTable[issueCode]["BASubID"] = "3"
					gtSessionTable[sessionID].PositionTable[issueCode]["Amount"] = 0
					local cumulationPL=0
					local SelectedUserID=gtSessionTable[sessionID].SelectedUserID
					local allUser={}
					if  SelectedUserID=="全部" then
						local currentUserID = _GetDealerID()
						allUser[currentUserID]=1
						if gtPosUserAccessUserTable[currentUserID] then
							for accessUserID,v in pairs(gtPosUserAccessUserTable[currentUserID]) do
								allUser[accessUserID]=1
							end
						end
					else
						allUser[SelectedUserID]=1
						if gtPosUserAccessUserTable[SelectedUserID] then
							for accessUserID,v in pairs(gtPosUserAccessUserTable[SelectedUserID]) do
								allUser[accessUserID]=1
							end
						end
					end
					
					for user,v in pairs(allUser) do
						if not gtPosUserAccessUserTable[user] then 
							if gtUserCumulationPLTable[user] then
								if gtUserCumulationPLTable[user][issueCode] then
									for baSubID,v in pairs(gtUserCumulationPLTable[user][issueCode]) do 
										cumulationPL=cumulationPL+v
									end
								end
							end
						end
					end
					gtSessionTable[sessionID].PositionTable[issueCode]["CumulationPL"] = cumulationPL
				end

				gtSessionTable[sessionID].PositionTable[issueCode]["Quantity"] = gtSessionTable[sessionID].PositionTable[issueCode]["Quantity"] + subPos.Quantity
				gtSessionTable[sessionID].PositionTable[issueCode]["AvlQuantity"] = gtSessionTable[sessionID].PositionTable[issueCode]["AvlQuantity"] + subPos.AvlQuantity
				gtSessionTable[sessionID].PositionTable[issueCode]["WorkingQtyOfClose"] = gtSessionTable[sessionID].PositionTable[issueCode]["WorkingQtyOfClose"] + subPos.WorkingQtyOfClose
				gtSessionTable[sessionID].PositionTable[issueCode]["RealizedPL"] = gtSessionTable[sessionID].PositionTable[issueCode]["RealizedPL"] + subPos.RealizedPL
				gtSessionTable[sessionID].PositionTable[issueCode]["CumulationPL"] = gtSessionTable[sessionID].PositionTable[issueCode]["CumulationPL"] + subPos.CumulationPL
				local subCumulationAdjustPL=subPos.CumulationAdjustPL or 0
				gtSessionTable[sessionID].PositionTable[issueCode]["CumulationAdjustPL"] = gtSessionTable[sessionID].PositionTable[issueCode]["CumulationAdjustPL"] + subCumulationAdjustPL
				gtSessionTable[sessionID].PositionTable[issueCode]["CumulationFare"] = gtSessionTable[sessionID].PositionTable[issueCode]["CumulationFare"] + subPos.CumulationFare
				gtSessionTable[sessionID].PositionTable[issueCode]["Fare"] = gtSessionTable[sessionID].PositionTable[issueCode]["Fare"] + subPos.Fare
				gtSessionTable[sessionID].PositionTable[issueCode]["CumulationDividend"] = gtSessionTable[sessionID].PositionTable[issueCode]["CumulationDividend"] + subPos.CumulationDividend
				gtSessionTable[sessionID].PositionTable[issueCode]["Amount"] = gtSessionTable[sessionID].PositionTable[issueCode]["Amount"] + subPos.Amount
				gtSessionTable[sessionID].PositionTable[issueCode]["ValuationPL"] = gtSessionTable[sessionID].PositionTable[issueCode]["ValuationPL"] + subPos.ValuationPL
			end
		end
	end
end

function RefreshPosFund(sessionID)
	if gtSessionTable[sessionID] then
		if gtSessionTable[sessionID].SelectedBAMapID == "全部" then
			CalPosV(sessionID)
			for issueCode, pos in pairs(gtSessionTable[sessionID].PositionTable) do
				RefreshPosition(sessionID,pos)
			end
		else
			for posKey, pos in pairs(_PosPositionTable) do
				if gtSessionTable[sessionID].SelectedBAMapID==pos.BAMapID then
					--刷新持仓
					RefreshPosition(sessionID,pos)
					--刷新账户资金信息
				end
			end
		end
		for posKey, bondRepPosition in pairs(_PosBondRepPosTable) do
			if gtSessionTable[sessionID].CurBAMapIDTable then
				if gtSessionTable[sessionID].CurBAMapIDTable[bondRepPosition.BAMapID] then
					RefreshBondRepPosition(sessionID,bondRepPosition)
					--刷新账户资金信息
				end
			end
		end	
		--发送持仓汇总记录
		SendPos_SumData(sessionID)
		--刷新账户资金信息
		--RefreshFundInfo(sessionID,"other")
		UpdateFundInfo(sessionID,"All","send")
		RefreshMultiFireFundInfo(sessionID,"other")
	end
end

function InOutRefreshFund(sessionID)
	--刷新账户资金信息
	--RefreshFundInfo(sessionID,"other")
	UpdateFundInfo(sessionID,"All","send")
	RefreshMultiFireFundInfo(sessionID,"other")
end

----------------------------------------------
--自定义函数部分
----------------------------------------------

--界面日志
_DefineEventObject SystemLog _AS _Output
	_DefFld("LogTime", _String, 20);
	_DefFld("LogMessage", _Meta, 4);
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

function sendLog(sessionID,logMessage)
	local DTSEvent systemLog=_CreateEventObject("SystemLog")
	local DTSTime nowtime = _GetNowTime();
    local smtime = nowtime.asString("%H%M%S");
	local tmplogtimeH = sys_sub(smtime,1,2);
	local tmplogtimeM = sys_sub(smtime,3,4);
	local tmplogtimeS = sys_sub(smtime,5,6);
	local tmplogtime = tmplogtimeH..":"..tmplogtimeM..":"..tmplogtimeS
	systemLog._SetFld("LogTime",tmplogtime)
	systemLog._SetFld("LogMessage",logMessage)
	if sessionID=="All" then
		_SendToClients(systemLog)
	else
		_SendEventToClient(systemLog,sessionID);
	end
	_WriteAplLog(logMessage)
end
--日志信息显示
function showLog(sessionID,log)
    local nowTime = GetHMS();
	smtime = showFormat(nowTime,3)
	sendLog(sessionID,log)

	log = smtime .. "  " .. log
	local DTSEvent logEvent = _CreateEventObject("LogInfoOut");
	logEvent._SetFld("Text", log);
	if sessionID=="All" then
		_SendToClients(logEvent)
	else
		_SendEventToClient(logEvent,sessionID);
	end
end
_DefineEventObject OprationLog _AS _Output
	_DefFld("LogMessage", _Meta, 4);
	_SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End
function sendOprationLog(sessionID,msg)
	local DTSEvent systemLog=_CreateEventObject("OprationLog")
	systemLog._SetFld("LogMessage",msg)
	if sessionID=="All" then
		_SendToClients(systemLog)
	else
		_SendEventToClient(systemLog,sessionID);
	end
	_WriteAplLog(msg)
end
--持仓初始化结束
function OnPositionInitialized()
	gInitialized = true

	local log = "初始化结束..."
	_WriteAplLog(log)
	sendLog("All",log)	
	for sessionID,v in pairs(gtSessionTable) do
		if not v.InitXMLData then 
			local userID=v.SelectedUserID
			local baMapID=v.SelectedBAMapID
			currentBaMapID(sessionID,userID,baMapID,"1")
		end
	end
	
	sendInitialOrderTypeList()

	local currentUserID = _GetDealerID()
	local currentRoleID=""
	if gtUserRole[currentUserID] then
		currentRoleID=gtUserRole[currentUserID].RoleID;	
	end

	if currentRoleID==gRole_Riskor or currentRoleID==gRole_AdminRiskor or currentRoleID==gRole_Assistant_Riskor then 
		--管理员刷新间隔
		gPTWTFreshTimer = 90
		GetPTWTFreshTimer()
		if gPTWTFreshTimer<30 then
			gPTWTFreshTimer=30
		end
		local log=sys_format("管理员设置刷新间隔%d",gPTWTFreshTimer)
		_WriteAplLog(log)
		local interval=gPTWTFreshTimer*1000
		_StartTimer(_TimerName="FreshTimer",_Interval=interval) 
	else
		_StartTimer(_TimerName="FreshTimer",_Interval=30000) --30秒定时刷新
	end
	
	_StartTimer(_TimerName="AutoCancelTimer",_Interval=1000)
	--InitMySQLQuery()	
 	GetOrderSort()
	initInventory()
end

_OnEventTimer(_TimerName="FreshTimer")
	_WriteAplLog("FreshTimer")
	local plChange=false
	for issueCode, dummy in pairs(_PosPLChangedIssue) do 
		local issuePositionList = _PosKeyByIssueCode[issueCode]
		if issuePositionList then
			for i, posKey in ipairs(issuePositionList) do
				plChange=true
				break
			end
		end
		if plChange then
			break
		end
	end
	_PosPLChangedIssue = {}
	if plChange then 
		for posKey, pos in pairs(_PosPositionTable) do
			PosCalcValuationPL(pos)
		end	
		for sessionID,v in pairs(gtSessionTable) do 	
			RefreshPosFund(sessionID)
		end
	end
_End

function queryProductAccount()	
	gtZGProductFlowTable={}
	gtZGProductAccountTable={}
	local oldRoleID=""
	local currentUserID = _GetDealerID()
	if gtUserRole[currentUserID] then
		oldRoleID=gtUserRole[currentUserID].RoleID;	
	end	
	local con=sys_format("select UserID,RoleID,RoleName from dtszgrisk.DTSZGUserExtTable where UserID='%s'",currentUserID)		
	_WriteAplLog(con)
	_GetCommonData(dataName="DTSZGUserExtTable", condition=con, tablename="DynamicSql")	
	local currentRoleID=""
	if gtUserRole[currentUserID] then
		currentRoleID=gtUserRole[currentUserID].RoleID;	
	end
	if oldRoleID~=currentRoleID then
		sendRole()
	end
	con =  sys_format("select * from dtszgrisk.DTSZGProductFlowTable where UserID='%s' and RoleID='%s'",currentUserID,currentRoleID)
	_WriteAplLog(con)
	gProductIDs_str = ""
	_GetCommonData(dataName="DTSZGProductFlowTable", condition=con, tablename="DynamicSql")		
    _WriteAplLog(gProductIDs_str)
	con =  sys_format("select * from dtszgrisk.DTSZGProductAccountTable where DelFlag='0' and ProductID in (%s)",gProductIDs_str)
	_WriteAplLog(con)
	_GetCommonData(dataName="DTSZGProductAccountTable", condition=con, tablename="DynamicSql")
	con =  sys_format("select * from dtszgrisk.DTSZGProductTable where DelFlag='0' and ProductID in (%s)",gProductIDs_str)
	_WriteAplLog(con)
	_GetCommonData(dataName="DTSZGProductTable", condition=con, tablename="DynamicSql")
    
    con = sys_format("select GroupID,LeaderUserID from GroupTable where GroupID in (select groupid from GroupUserTable where UserID = '%s') or LeaderUserID = '%s'", gCurrentUserID, gCurrentUserID);
	_WriteAplLog(con)
	_GetCommonData(dataName= "GetGroupID",condition = con, tablename="DynamicSql"); -- 获取风控员 LeaderUserID 和分组号 GroupID
    
    --_GetCommonData(dataName="GetGroupData", condition="", tablename="Group")
    --_GetCommonData(dataName="GetGroupUserData", condition="", tablename="GroupUser")
    
    local cond="1=1 Order by ClientID"
	_GetCommonData("ReadUserClientTable", condition=cond, tablename = "Client");

    con = sys_format("select * from dtszgrisk.DTSZGProductAccountBackupTable where LeaderUserID = '%s' and OpFlag = 'delete'",gLeaderUserID)
    _WriteAplLog(con)
	_GetCommonData(dataName="DTSZGProductAccountBackupTable", condition=con, tablename="DynamicSql")

	if currentRoleID==gRole_Riskor or currentRoleID==gRole_AdminRiskor or currentRoleID==gRole_Assistant_Riskor then 
		_WriteAplLog("Admin")
		for baMapID,v in pairs(gtZGProductAccountTable) do 
			local productID=v.ProductID or ""
			if not gtZGProductFlowTable[productID] then
				gtZGProductAccountTable[baMapID]=nil 
			end
		end
	else
		_WriteAplLog("not Admin")
	end
	for sessionID,v in pairs(gtSessionTable) do 
		--刷新账户资金信息
		--RefreshFundInfo(sessionID,"other")
		UpdateFundInfo(sessionID,"All","send")
	end
end

function splitSting(line,splitChar)
	local lin = line
	local rtn = {}
	local len = sys_len(line)
	local begin=1
	for i = 1, len do
		local chr = sys_sub(line, i, i)
		if i<len then
			if chr == splitChar then
				if begin<=i-1 then 
					sys_insert(rtn, sys_sub(line, begin, i-1))
				end
				begin=i+1
			end
		else
			if begin<=i then 
				sys_insert(rtn, sys_sub(line, begin, i))
			end
		end
	end
	return rtn
end

_OnCommonData(dataName="getUserCumulationPL", DTSDynamicSql dynamicSql)
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		if luat["ID"] and luat["Value"] then 
			local  posKey=luat["ID"];
			local  chr=".";
			local lt=splitSting(posKey,chr);
			if lt[1] and lt[2] and lt[3] then
				local UserCumulationPL=luat["Value"];
				local UserID=lt[1]
				local BASubID=lt[2]
				local IssueCode=lt[3]
				gtUserCumulationPLTable[UserID]=gtUserCumulationPLTable[UserID] or {}
				gtUserCumulationPLTable[UserID][IssueCode]=gtUserCumulationPLTable[UserID][IssueCode] or {}
				gtUserCumulationPLTable[UserID][IssueCode][BASubID]=UserCumulationPL
			end
		end				
	end
_End

_OnCommonData(dataName="DTSZGUserExtTable", DTSDynamicSql dynamicSql)
	_WriteAplLog("on DTSZGUserExtTable")
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		if luat["UserID"] and luat["RoleID"] and luat["RoleName"] then 
			local UserID=luat["UserID"]
			local RoleID=luat["RoleID"]
			local RoleName=luat["RoleName"]
			gtUserRole[UserID]={};
			gtUserRole[UserID].RoleID=RoleID;
			gtUserRole[UserID].RoleName=RoleName
		end				
	end
_End

_OnCommonData(dataName="DTSZGProductFlowTable", DTSDynamicSql dynamicSql)
	_WriteAplLog("on DTSZGProductFlowTable")
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		if luat["ProductID"] and luat["RoleID"] and luat["UserID"] then 
			local ProductID=luat["ProductID"]
			local RoleID=luat["RoleID"]
			local UserID=luat["UserID"]
			if gProductIDs_str == "" then
				gProductIDs_str = sys_format("'%s'",ProductID)
			else
				gProductIDs_str = sys_format("%s,'%s'",gProductIDs_str,ProductID)
			end

			gtZGProductFlowTable[ProductID]=gtZGProductFlowTable[ProductID] or {}
			gtZGProductFlowTable[ProductID][RoleID]=gtZGProductFlowTable[ProductID][RoleID] or {}
			gtZGProductFlowTable[ProductID][RoleID][UserID]=1
		end				
	end
_End

_OnCommonData(dataName="DTSZGProductAccountTable", DTSDynamicSql dynamicSql)
	_WriteAplLog("on DTSZGProductAccountTable")
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		if luat["ProductID"] and luat["AssetsCellID"] and luat["BAMapID"] then  
			local ProductID=luat["ProductID"]
			local AssetsCellID=luat["AssetsCellID"]
			local BAMapID=luat["BAMapID"]
			if gtRunAccountTable[BAMapID] then
				gtZGProductAccountTable[BAMapID]={}	
				gtZGProductAccountTable[BAMapID]=luat
                
                gtAssetsCellBAMapTable[AssetsCellID]=gtAssetsCellBAMapTable[AssetsCellID] or {}
                gtAssetsCellBAMapTable[AssetsCellID][BAMapID]=1
                
                --gtSendProductBAMap[ProductID][BAMapID] = 1
                
				local SeniorFund=luat["SeniorFund"]
				local MezzFund=luat["MezzFund"]
				if SeniorFund and SeniorFund ~= "" and MezzFund and MezzFund ~= "" then
					gtZGProductAccountTable[BAMapID].MTBalance = SeniorFund.getNumberValue() + MezzFund.getNumberValue()
				end	
			end
		end
	end
_End

--[[
function OnMySQLQuery(ret)
	_WriteAplLog("===============OnMySQLQuery======================")
	local log = sys_format("reqid=%s, result=%s, reason=%s, get %d rows", ret.ReqID,ret.Result,ret.Reason,sys_getSize(ret.Data)+1)
	_WriteAplLog(log)
	if gtReqIDtoQueryName[ret.ReqID] then
		local queryName=gtReqIDtoQueryName[ret.ReqID]
		_WriteAplLog(queryName)
		if queryName=="ReadInventoryHeaderTable" then
			if ret.Result==0 or  ret.Result=="0" then
				if ret.Data then
					for row,v in pairs(ret.Data) do
						local InventoryID=ret.Data[row][1]
						local InventoryName=ret.Data[row][2]
						local IsPublic=ret.Data[row][3]
						local WeightType=ret.Data[row][4]
						local PerAmount=ret.Data[row][5]
						local Owner=ret.Data[row][6]
						local AddType = ret.Data[row][7]
						local DeleteFlg = ret.Data[row][8]
						local BuySell = ret.Data[row][9]
						local CreateTime = ret.Data[row][10]
						local ReserveString = ret.Data[row][11] or "按固定金额"
						local ComponentCount = ret.Data[row][12]
						if BuySell ~= "卖" then
							BuySell = "买"
						end
						gtInventoryHeaderTable[InventoryID]=gtInventoryHeaderTable[InventoryID] or {}
						gtInventoryHeaderTable[InventoryID].InventoryName=InventoryName
						gtInventoryHeaderTable[InventoryID].IsPublic=IsPublic
						gtInventoryHeaderTable[InventoryID].WeightType=WeightType
						gtInventoryHeaderTable[InventoryID].PerAmount=PerAmount
						gtInventoryHeaderTable[InventoryID].Owner=Owner
						gtInventoryHeaderTable[InventoryID].AddType=AddType
						gtInventoryHeaderTable[InventoryID].DeleteFlg=DeleteFlg
						gtInventoryHeaderTable[InventoryID].BuySell=BuySell
						gtInventoryHeaderTable[InventoryID].CreateTime = CreateTime
						gtInventoryHeaderTable[InventoryID].ReserveString = ReserveString
						gtInventoryHeaderTable[InventoryID].ComponentCount = ComponentCount
					end
					_WriteAplLog("end ReadInventoryHeaderTable")
					if gIsInventoryInitialized==false then
						gIsInventoryInitialized=true
						for i,sessionID in pairs(gtSendInventoryInitialized) do
							SendInventoryInitialized(sessionID)
							gtSendInventoryInitialized[i]=nil
						end
					end
					local sortInventoryID={}
					for inventoryID,v in pairs(gtInventoryHeaderTable) do
						local key=v.CreateTime.."#"..inventoryID
						sys_insert(sortInventoryID,key)
					end
					sys_sort(sortInventoryID, "asc")
					for sessionID,v in pairs(gtSessionTable) do 
						for i,key in pairs(sortInventoryID) do
							local inventoryID=getTableByString(key,"#")[2]
							FreshComponent(sessionID,inventoryID)
							sendInventory(sessionID,inventoryID)
						end
						if gtSessionTable[sessionID].CurrentInventoryID~="" then
							local currentInventoryID=gtSessionTable[sessionID].CurrentInventoryID
							sendComponent(sessionID,currentInventoryID)
							SendCurrentInventoryID(sessionID)
						end
						sendQuantityBalance(sessionID)
					end
					for sessionID, inventoryID in pairs(gInventoryIDNeedAutoOrder) do
						if gtInventoryHeaderTable[inventoryID] then
							local bs = gtInventoryHeaderTable[inventoryID].BuySell
							local oc = 0
							if bs == "卖" then
								bs = "1"
								oc = 1
							else
								bs = "3"
							end
							local baSubID = bs
							if oc == 0 then
								baSubID = bs
							else
								if bs == "3" then
									baSubID = "1"
								else
									baSubID = "3"
								end
							end
							if gtSessionTable[sessionID] then
								if gtSessionTable[sessionID].CurBAMapIDTable then
									for baMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
										fireInventory(sessionID,baMapID,baSubID,inventoryID,oc,bs,"",1,0)
									end
								end
							end
						end
						gInventoryIDNeedAutoOrder[sessionID] = ""
					end
				end
			end
		elseif queryName=="ReadInventoryComponentTable" then
			if ret.Result==0 or  ret.Result=="0" then
				if ret.Data then
					for row,v in pairs(ret.Data) do
						local InventoryID=ret.Data[row][1]
						local IssueCode=ret.Data[row][2]
						local Ratio=ret.Data[row][3]
						local Quantity=ret.Data[row][4]
						local BuyPrice=ret.Data[row][5] or ""
						local IsSelected = ret.Data[row][6]
						if isNumBer(BuyPrice) then
							if BuyPrice-0.00001<0 then
								BuyPrice=""
							end
						--else
						--	BuyPrice=""
						end
						gtInventoryComponentTable[InventoryID]=gtInventoryComponentTable[InventoryID] or {}
						gtInventoryComponentTable[InventoryID][IssueCode]={}
						gtInventoryComponentTable[InventoryID][IssueCode].Ratio=Ratio
						gtInventoryComponentTable[InventoryID][IssueCode].Quantity=Quantity
						gtInventoryComponentTable[InventoryID][IssueCode].BuyPrice=BuyPrice
						gtInventoryComponentTable[InventoryID][IssueCode].IsSelected=IsSelected
						if not gtPriceTable[IssueCode] then
							local issueCode=IssueCode
							local marketCode = _PosIssueMarketTable[issueCode]
							_RegisterPrice(_IssueCode = issueCode, _MarketCode = marketCode)
						end
					end
				end
			end
			_WriteAplLog("end ReadInventoryComponentTable")
		elseif queryName=="DTSZGInvestorOrderSortTable" then 
			if ret.Result==0 or  ret.Result=="0" then
				if ret.Data then
					local lt={}
					local sortIndex={}
					for row,v in pairs(ret.Data) do
						local clientID=ret.Data[row][1]
						local investorID=ret.Data[row][2]
						local orderIndex=ret.Data[row][3]
						lt[orderIndex]=clientID
						sys_insert(sortIndex,orderIndex)
					end
					sys_sort(sortIndex, "asc")
					gOrderSortClient={}
					for i,index in pairs(sortIndex) do
						local clientID=lt[index]
						sys_insert(gOrderSortClient,clientID)
					end
					--只更新优先级不改变界面数据					
					for sessionID,v in pairs(gtSessionTable) do
						local userID=gtSessionTable[sessionID].SelectedUserID
						local baMapID=gtSessionTable[sessionID].SelectedBAMapID
						currentBaMapID(sessionID,userID,baMapID,"0")
					end
				end
			end
		end
	end
end]]

--持仓回调,刷新DTS相关数据
function OnPositionChanged(pos, reason)
	if _PosStatus == POS_STATUS_NORMAL then 
		local poskey=pos.BAMapID.."."..pos.BASubID.."."..pos.IssueCode
		if  reason == POS_REASON_ORDER_CHANGE then
			for sessionID,v in pairs(gtSessionTable) do 
				if gtSessionTable[sessionID].CurBAMapIDTable then
					if gtSessionTable[sessionID].SelectedBAMapID == "全部" and gtSessionTable[sessionID].CurBAMapIDTable[pos.BAMapID] then					
						CalPos_IssueCode(sessionID,pos)
						RefreshPosition(sessionID,gtSessionTable[sessionID].PositionTable[pos.IssueCode])
						--发送持仓汇总记录
						SendPos_SumData(sessionID)
						--刷新账户资金信息
						--RefreshFundInfo(sessionID,"order")
						if gFirstCalculation then
							UpdateFundInfo(sessionID,"All","send")
						else
							UpdateFundInfo(sessionID,pos.BAMapID,"send")
						end
						RefreshMultiFireFundInfo(sessionID,"order")
						
						local curIssueCode=gtSessionTable[sessionID].CurIssueCode
						if curIssueCode==pos.IssueCode then 
							PriceServer(sessionID,curIssueCode)
						end
					elseif pos.BAMapID == gtSessionTable[sessionID].SelectedBAMapID then
						--刷新持仓
						RefreshPosition(sessionID,pos)
						--发送持仓汇总记录
						SendPos_SumData(sessionID)
						--刷新账户资金信息
						--RefreshFundInfo(sessionID,"order")
						if gFirstCalculation then
							UpdateFundInfo(sessionID,"All","send")
						else
							UpdateFundInfo(sessionID,pos.BAMapID,"send")
						end
						RefreshMultiFireFundInfo(sessionID,"order")
						local curIssueCode=gtSessionTable[sessionID].CurIssueCode
						if curIssueCode==pos.IssueCode then 
							PriceServer(sessionID,curIssueCode)
						end
					end
				end
			end		
			gFirstCalculation = false
		elseif reason == POS_REASON_PRICE_CHANGE then
			if not sys_find(pos.BAMapID,"-000",1) and not sys_find(pos.BAMapID,"-999",1) then
				local log = sys_format("POS_REASON_PRICE_CHANGE:BAMapID[%s]",pos.BAMapID)
				_WriteAplLog(log)
				
				for sessionID,v in pairs(gtSessionTable) do 
					if gFirstCalculation then
						UpdateFundInfo(sessionID,"All","")
					else
						UpdateFundInfo(sessionID,pos.BAMapID,"")
					end
				end
				gFirstCalculation = false
			end
		end
	end
end
function OnOrder(pos, order)
end
function OnExecution(pos, exec)
end
function OnBondRepPositionChanged(pos, reason)
	if _PosStatus == POS_STATUS_NORMAL then 
		if  reason == POS_REASON_ORDER_CHANGE then
			for sessionID,v in pairs(gtSessionTable) do 
				if  gtSessionTable[sessionID].CurBAMapIDTable then	
					if  gtSessionTable[sessionID].CurBAMapIDTable[pos.BAMapID] then					
						RefreshBondRepPosition(sessionID,pos)
					end
				end
			end
		end
	end
end
function OnStdSecPositionChanged(stdSecPosition, reason)
end
function OnBondExecution(position, exec)

end
function OnBondOrder(position, order)

end
function TimeFormat(strtime)
	local newTime="";
	if strtime and strtime ~= "" then
		local len=sys_len(strtime)
		for i=1,len,1 do
			local ch=sys_sub(strtime,i,i)
			if ch=="0" or ch=="1" or ch=="2" or ch=="3" or ch=="4" or ch=="5" or ch=="6" or ch=="7" or ch=="8" or ch=="9" then
				newTime=newTime..ch
			end
		end
		if sys_len(newTime) >= 6 then
			if sys_len(newTime) >= 8 then
				newTime = sys_sub(newTime,1,-4)
			end
		end
	else
		newTime="000000"
	end
	newTime= sys_format("%06d",newTime)
	local timeH = sys_sub(newTime,1,2)
	local timeM = sys_sub(newTime,3,4)
	local timeS = sys_sub(newTime,5,6)
	newTime = timeH..":"..timeM..":"..timeS
	return newTime
end

--委托成交回调
_OnEventExecution("OrderExecReply", {} , DTSMessageRecordAccess msg)
	local DTSOrderDetailRecordAccess order = msg.getOrderDetailRecord();
	local issueCode = order.getIssueCode();
	if ("11111111111111111111" ~= issueCode and "00000000000000000000" ~= issueCode) then
		local _String baMapID = order.getBAMapID();
		if _PosBAMapTable[baMapID] then
			local issueCode = order.getIssueCode();					--合约号
			local buySell = order.getBuySell();						--买卖
			local openClose = order.getReserveInt1();				--开仓、平仓、平今
			local creRed = order.getGeneralInt1()					--0普通委托, 1:申购. 2:赎回, 3:质押, 4:融资回购, 5:融券回购
			local orderQuantity = order.getOriginalQuantity();		--委托数量
			local orderPrice = order.getOrderPrice();				--委托价
			local orderTime = order.getOrderTime();					--委托时间
			local corpCode = order.getCorpCode();						--内部委托号
			local workingQuantity = order.getWorkingQuantity();			--挂盘数量
			local cancelQuantity = order.getCancelQuantity();			--撤单数量
			local unAcceptedQuantity = order.getUnacceptedQuantity();	--未报数量
			local rejectedQuantity = order.getRejectedQuantity();		--拒绝数量
			local executionQuantity = order.getExecutionQuantity();		--成交数量
			--local executionValue = order.getExecutionValue();			--成交金额
			local marketCode = order.getMarketCode();					--市场号
			local pcid = order.getPositionCheckID()
			local batchID = order.getTargetPrice()
			local baSubID = order.getBASubID();
			--交易类型
			local marginType = GetMarginType(marketCode,buySell, openClose, creRed)
			local pbTime = msg.getPublishTime()
			--local logg = sys_format("orderTime[%s],pbTime[%s]",orderTime,pbTime)
			--_WriteAplLog(logg)
			if orderTime and orderTime ~= "" then
				orderTime = TimeFormat(orderTime)
			else
				orderTime = msg.getPublishTime()
				local timeH = sys_sub(orderTime,1,2)
				local timeM = sys_sub(orderTime,3,4)
				local timeS = sys_sub(orderTime,5,6)
				orderTime = timeH..":"..timeM..":"..timeS
			end
			
			_WriteAplLog(orderTime)
			--设置委托状态
			local status = "-"
			if orderQuantity == executionQuantity then
				status = "全部成交"
			elseif executionQuantity >0 and orderQuantity > executionQuantity then
				if executionQuantity + cancelQuantity == orderQuantity then
					status = "部成部撤"
				else
					status = "部分成交"
				end
			elseif workingQuantity > 0 then
				status = "挂单"
			elseif cancelQuantity > 0 then
				status = "已撤"
			elseif unAcceptedQuantity == orderQuantity then
				status = "正报"
			elseif rejectedQuantity > 0 then
				status = "拒绝"
			end
			if msg.getMessageType () == "L18" then
				status = "同步"
			end

			--委托入表
			local lt = {}
			lt.IssueCode = issueCode
			lt.MarketCode = marketCode
			lt.Status = status
			lt.MarginType = marginType
			lt.BuySell = buySell
			lt.OrderPrice = orderPrice
			lt.Quantity = orderQuantity
			lt.ExecQty = executionQuantity
			lt.WorkingQuantity = workingQuantity
			lt.CancelQty = cancelQuantity
			lt.OrderTime = orderTime
			lt.BAMapID = baMapID
			lt.Fare = 0
			lt.CorpCode = corpCode
			lt.PositionCheckID = pcid
			lt.CreRed = creRed
			lt.OpenClose = openClose
			if batchID then
				if batchID~="" then
					lt.BatchID = batchID
				end
			end
			gtShowOrderTable[corpCode] = lt
			if msg.getMessageType() == "L18" then
				local originExecKey = msg.getGeneralString2()
				local posKey = baMapID .. "." .. baSubID .. "." .. issueCode
				if gtOvernightSPLITData[posKey] then
					if buySell=="3" then 
						if originExecKey=="SPLIT_ADJUST" then
							gtSPLIT_ADJUST[corpCode]=1
						end
					elseif  buySell=="1" then 
						if sys_sub(originExecKey,1,5)=="SPLIT" then
							gtSPLIT_ADJUST[corpCode]=1
						end
					end
				end
				if originExecKey=="Fund_Profit" and buySell=="3" then
					gtFund_ProfitSettle[corpCode]=1
				end
			end
			if _PosStatus == POS_STATUS_NORMAL then 
				RefreshSingleOrder("All",corpCode,lt)
			end
			--成交回调，并发送成交
			if msg.getMessageType () == "L07" or msg.getMessageType () == "L18"  then
				local executionValue = 0
				local execPrice = msg.getExecutionPrice()				--成交价格
				local execQuantity = msg.getExecutionQuantity()			--成交数量
				local contractSize = 1
				if _PosIssueContractSizeTable[issueCode] then
					contractSize = _PosIssueContractSizeTable[issueCode]
				end
				if execPrice and execPrice ~= "" and execQuantity and execQuantity ~= "" and contractSize and contractSize ~= "" then
					execPrice = execPrice.getNumberValue()
					execQuantity = execQuantity.getNumberValue()
					contractSize = contractSize.getNumberValue()
					executionValue = execPrice * execQuantity * contractSize
				end
				local execTime = msg.getExecutionTime()					--成交时间
				local execNo = msg.getExecutionNo()						--成交号
				local uniqueKey = msg.getUniqueKeyCode()

				if msg.getMessageType () ~= "L18" then
					local temReservestring2 = msg.getReserveString2()
					if temReservestring2 and temReservestring2~="" and temReservestring2~=execNo then
						execNo=temReservestring2
					end
				end
				if execTime ~= "" then
					--防止接口程序返回的格式不统一造成附带的毫秒影响格式化
					execTime=TimeFormat(execTime)
				end

				--设置成交额
				if executionValue ~= "" then
					executionValue = showFormat(executionValue,1)
					executionValue = executionValue.getNumberValue()
				end


				--成交入表
				lt = lt or {}
				lt.IssueCode = issueCode
				lt.MarketCode = marketCode
				lt.MarginType = marginType
				lt.BuySell = buySell
				--lt.ExecQty = execQuantity
				lt.ExecPrice = execPrice
				lt.ExecTime = execTime
				--lt.ExecAmount = executionValue
				lt.BAMapID = baMapID
				lt.ExecNo = execNo
				lt.Fare = 0
				lt.CorpCode = corpCode
				lt.CreRed = creRed
				lt.OpenClose = openClose
				lt.Quantity = orderQuantity
				lt.UniqueKey = uniqueKey
				if msg.getMessageType() == "L18" and (creRed == 0 or creRed == 3 or creRed == 4 or creRed == 5) then
					lt.IsInternal = 1 --判断是否为内部成交单子
					lt.WithFare = 0
					local _String executionNo=msg.getExecutionNo()
					if executionNo==_PosInternalWithFareExecNo then
						lt.WithFare = 1
					end
				else
					lt.IsInternal = 0
				end
				--分笔成交汇总显示为一条记录
				if not gtShowExecTable[corpCode] then
					gtShowExecTable[corpCode] = lt
					gtShowExecTable[corpCode].ExecQty = 0
					gtShowExecTable[corpCode].ExecAmount = 0
				end
				gtShowExecTable[corpCode].ExecPrice = execPrice
				gtShowExecTable[corpCode].ExecQty = gtShowExecTable[corpCode].ExecQty + execQuantity
				gtShowExecTable[corpCode].ExecAmount = gtShowExecTable[corpCode].ExecAmount + executionValue

				if gtShowExecTable[corpCode].ExecAmount and gtShowExecTable[corpCode].ExecQty and gtShowExecTable[corpCode].ExecQty ~= 0 then
					local price = gtShowExecTable[corpCode].ExecAmount / gtShowExecTable[corpCode].ExecQty/ contractSize
					gtShowExecTable[corpCode].ExecPrice = price
				end
				if _PosStatus == POS_STATUS_NORMAL then 
					local temp = {}
					temp.BAMapID = baMapID
					temp.IssueCode = issueCode
					temp.OpenClose = openClose
					temp.ExecValue = executionValue
					temp.Quantity =orderQuantity
					temp.ExecQty = execQuantity
					temp.CreRed = creRed
					temp.BS = buySell
					temp.IsInternal = lt.IsInternal
					temp.WithFare = lt.WithFare
					
					local accountCode=_PosBAMapAccount[baMapID] or baMapID
					local fareTable =PosFareDetail(accountCode, temp.IssueCode, temp)
					local TotalFare= fareTable.TotalFare or 0
					local Fare= fareTable.Fare or 0
					local TransferExpense= fareTable.TransferExpense or 0
					local StampTax= fareTable.StampTax or 0

					local showKey = sys_format("%s.%s.%s",baMapID,issueCode,buySell)
					_WriteAplLog(showKey)
					if not gtExecShowAllTable[showKey] then
						gtExecShowAllTable[showKey] = {}
						gtExecShowAllTable[showKey].sumFare = TotalFare
						gtExecShowAllTable[showKey].sumFare1 = Fare
						gtExecShowAllTable[showKey].sumFare2 = TransferExpense
						gtExecShowAllTable[showKey].sumFare3 = StampTax
						gtExecShowAllTable[showKey].sumExecQty = execQuantity
						gtExecShowAllTable[showKey].sumExecAmount = executionValue
					else
						gtExecShowAllTable[showKey].sumFare = gtExecShowAllTable[showKey].sumFare + TotalFare
						gtExecShowAllTable[showKey].sumFare1 = gtExecShowAllTable[showKey].sumFare1 + Fare
						gtExecShowAllTable[showKey].sumFare2 = gtExecShowAllTable[showKey].sumFare2 + TransferExpense
						gtExecShowAllTable[showKey].sumFare3 = gtExecShowAllTable[showKey].sumFare3 + StampTax
						gtExecShowAllTable[showKey].sumExecQty = gtExecShowAllTable[showKey].sumExecQty + execQuantity
						gtExecShowAllTable[showKey].sumExecAmount = gtExecShowAllTable[showKey].sumExecAmount + executionValue
					end
					
					for sessionID,v in pairs(gtSessionTable) do
						RefreshSingleExec(sessionID,corpCode,gtShowExecTable[corpCode])
					end

					--RefreshSingleExec("All",corpCode,gtShowExecTable[corpCode])
				end
				
				local poskey=baMapID.."."..baSubID.."."..issueCode
				gtTtradeExec[poskey]=1
				local allPosKey="全部."..baSubID.."."..issueCode
				gtTtradeExec[allPosKey]=1
			end
			--维护挂单委托表
			if unAcceptedQuantity > 0 or workingQuantity > 0 then
				gtWorkingOrderTable[corpCode] = gtWorkingOrderTable[corpCode] or {}
				gtWorkingOrderTable[corpCode].WorkingQty = workingQuantity
				gtWorkingOrderTable[corpCode].BuySell = buySell
				gtWorkingOrderTable[corpCode].BAMapID = baMapID
				gtWorkingOrderTable[corpCode].IssueCode = issueCode
			else
				gtWorkingOrderTable[corpCode] = nil
			end

			--如果发生拒绝,发送拒绝消息,提示用户
			if msg.getMessageType() == "L04" or msg.getMessageType() == "L06" then
				local errorInfo = "";
				local errorType =  msg.getErrorType();
				if errorType ~= "0" then
					errorInfo = order.getReserveString2();
					local tmperrorInfo = "";
					if msg.getMessageType() == "L04" then
						if gChangeErrorInfo then 
							if errorInfo=="dts manual reject order" then
								errorInfo="[3001]更新交易状态"
							else
								errorInfo="[10061]交易代码异常"
							end	
						end
						if not gtErrorInfo[corpCode] then
							gtErrorInfo[corpCode]=errorInfo
						end
						if errorInfo~="ManualCancel" then
							--变撤单
							tmperrorInfo = sys_format("委托号[%s]，理财账户[%s],[%s]下单拒绝:[%s]",pcid,baMapID,issueCode,errorInfo);
						end
						if _PosStatus == POS_STATUS_NORMAL then
							local log = sys_format("下单及回报:%s",tmperrorInfo)
							if gtOrderSessionTable[pcid] then
								local sessionID=gtOrderSessionTable[pcid]
								if errorInfo~="ManualCancel" and errorInfo~="" then
									showLog(sessionID,log)
								end 
								if gReSubMitRefuseOrder then
									if batchID and batchID~="" then 
										if gtAllRefuseBAMap[batchID] then
											gtAllRefuseBAMap[batchID][baMapID]=1
											if rejectedQuantity>0 and errorInfo~="ManualCancel" then
												local baSubID = order.getBASubID();
												SendOrder_All(sessionID,issueCode,buySell,openClose,orderPrice,rejectedQuantity,"",baSubID,creRed,batchID)
											end 	
										end
									end
								end
							end
						end
						RefreshSingleOrder("All",corpCode,gtShowOrderTable[corpCode])
					else
						errorInfo = msg.getReserveString2();
						tmperrorInfo = sys_format("[%s][%s]撤单拒绝[%s]",issueCode,corpCode,errorInfo);
						if _PosStatus == POS_STATUS_NORMAL then
							local log = sys_format("撤单及回报:%s",tmperrorInfo)
							if gtOrderSessionTable[pcid] then
								local sessionID=gtOrderSessionTable[pcid]
								showLog(sessionID,log)
							end
						end
					end
				end
			end
		end
	end
_End
_OnReceiveUnifieldMessage("errorTRADEMsg", "TRADE_ERROR", DTSUnifieldMessage srcMsg)
    srcMsg.first()
	while not srcMsg.eof() do
		local corpCode = srcMsg.getValueByName("CorpCode")
		local errorType= srcMsg.getValueByName("ErrorType")
		local errorInfo= srcMsg.getValueByName("ReserveString2")
		local baMapID = _PosCorpCode2BAMapID[corpCode]
		if baMapID then
			if _PosBAMapTable[baMapID] then
				--柜台拒绝原因				
				if errorInfo=="ManualCancel" then
					--变撤单
					errorInfo=""
				end
				gtErrorInfo[corpCode]=errorInfo
				if errorInfo~="" then
					if gChangeErrorInfo then 
						if errorInfo=="dts manual reject order" then
							errorInfo="[3001]更新交易状态"
						else
							errorInfo="[10061]交易代码异常"
						end
						gtErrorInfo[corpCode]=errorInfo	
					end	

					local log = sys_format("委托号[%s],柜台拒绝原因:[%s]",corpCode,errorInfo);
					local pcid=gtShowOrderTable[corpCode].PositionCheckID
					if pcid then 
						if gtOrderSessionTable[pcid] then
							local sessionID=gtOrderSessionTable[pcid]
							showLog(sessionID,log)
						end
					end
					RefreshSingleOrder("All",corpCode,gtShowOrderTable[corpCode])
				end
			end
		else
			local log = sys_format("baMapID[nil],委托号[%s],柜台拒绝原因:[%s]",corpCode,errorInfo);
			_WriteAplLog(log)
		end
		srcMsg.next()
	end
	srcMsg.clear()
_End
--刷新单条委托
function RefreshSingleOrder(sessionID,corpCode,table)
	local baMapID = table.BAMapID
	local fare = table.Fare
	local orderTime = table.OrderTime
	local issueCode = table.IssueCode
	local marketCode = table.MarketCode
	local issueName = _PosIssueNameTable[issueCode]
	local buySell = table.BuySell
	if buySell == "3" then
		buySell = "买"
	else
		buySell = "卖"
		if table.OpenClose == 0 and table.CreRed == 5 and table.BuySell=="1" then
			buySell = "融券回购"
		end
	end
	local marginType = table.MarginType
	local formatPriceExponent = getPriceFormat(issueCode);
	local orderPrice = table.OrderPrice
	if orderPrice and orderPrice ~= "" then
		orderPrice = sys_format(formatPriceExponent, orderPrice);
	end
	local orderQty = table.Quantity
	if orderQty and orderQty ~= "" then
		orderQty = showFormat(orderQty,2)
	end
	local execQty = table.ExecQty
	if execQty and execQty ~= "" then
		execQty = showFormat(execQty,2)
	end
	local workingQty = table.WorkingQuantity
	if workingQty and workingQty ~= "" then
		workingQty = showFormat(workingQty,2)
	end
	local cancelQty = table.CancelQty
	if cancelQty and cancelQty ~= "" then
		cancelQty = showFormat(cancelQty,2)
	end
	local status = table.Status
	local marketName = gtMarketNameTable[marketCode]
	local reserveString=""
	if table.OpenClose~=0 then
		if table.BatchID then
			if table.BatchID~="" then
				if sys_len(table.BatchID)>=6 then
					if sys_sub(table.BatchID,1,6)=="Index:" then
						local indexName=sys_sub(table.BatchID,7,-1) or ""
						reserveString=sys_format("指标[%s]强平",indexName)
					end
					if sys_sub(table.BatchID,1,6)=="MClose" then
						reserveString="风控员强平"
					end
				end
			end
		end
	end
	if gtRiskRefuseReason[corpCode] then
		if gShowRiskRefuseReason~="1" then 
			local reason=gtRiskRefuseReason[corpCode]
			if reserveString=="" then
				reserveString=reason
			else
				reserveString=reserveString..","..reason
			end
		end 
	end
	local errorInfo=""
	if gtErrorInfo[corpCode] then
		errorInfo=gtErrorInfo[corpCode]
		if gReserveStringShowMode~="1" then 
			if reserveString=="" then
				reserveString=errorInfo
			else
				reserveString=reserveString..","..errorInfo
			end
		end 
	end
	
	if gtSPLIT_ADJUST[corpCode] then
		local log="上海送股当日不可卖处理"
		if reserveString=="" then
			reserveString=log
		else
			reserveString=reserveString..","..log
		end
	end
	if gtFund_ProfitSettle[corpCode] then
		local log="货币基金收益"
		if reserveString=="" then
			reserveString=log
		else
			reserveString=reserveString..","..log
		end
	end

	if errorInfo=="ManualCancel" and status=="拒绝" then
			status="已撤"
			reserveString=""
	end

	if marketCode == "1" or marketCode == "2" then
		local DTSEvent orderEvent = _CreateEventObject("S_OrderEvent")
		orderEvent._SetFld("OrderTime",orderTime)
		orderEvent._SetFld("IssueCode",issueCode)
		orderEvent._SetFld("IssueName",issueName)
		orderEvent._SetFld("BuySell",buySell)
		orderEvent._SetFld("OrderPrice",orderPrice)
		orderEvent._SetFld("Quantity",orderQty)
		orderEvent._SetFld("ExecQty",execQty)
		orderEvent._SetFld("WorkingQuantity",workingQty)
		orderEvent._SetFld("CancelQty",cancelQty)
	
		orderEvent._SetFld("Status",status)
		if status == "同步" then
			orderEvent._SetFld("Status","全部成交")
		end 
		orderEvent._SetFld("CorpCode",corpCode)
		orderEvent._SetFld("MarketName",marketName)
		orderEvent._SetFld("BAMapID",baMapID)
		orderEvent._SetFld("ReserveString",reserveString)
		local showFlag="1"
		if (status=="拒绝" or status=="风控拒绝") and gShowReSubMitRefuseOrder=="0" then
			if table.BatchID then
				if table.BatchID~="" then
					if sys_sub(table.BatchID,1,3)=="All" then
						showFlag="0"  
					end
				end
			end
		end
		orderEvent._SetFld("ShowFlag",showFlag)
		
		if status~="同步" or gInternalExecShowMode~="1" then
			for tempSessionID,v in pairs(gtSessionTable) do 
				if tempSessionID==sessionID or sessionID=="All" then
					if  gtSessionTable[tempSessionID].CurBAMapIDTable then
						if  gtSessionTable[tempSessionID].CurBAMapIDTable[baMapID] then		
							_SendEventToClient(orderEvent,tempSessionID);
						end
					end
				end
			end
		end
	elseif marketCode == "3" or marketCode == "4" or marketCode == "5" or marketCode == "6" then
		local DTSEvent orderEvent = _CreateEventObject("F_OrderEvent")
		orderEvent._SetFld("OrderTime",orderTime)
		orderEvent._SetFld("IssueCode",issueCode)
		orderEvent._SetFld("IssueName",issueName)
		orderEvent._SetFld("MarginType",marginType)
		orderEvent._SetFld("OrderPrice",orderPrice)
		orderEvent._SetFld("Quantity",orderQty)
		orderEvent._SetFld("ExecQty",execQty)
		orderEvent._SetFld("WorkingQuantity",workingQty)
		orderEvent._SetFld("CancelQty",cancelQty)
		orderEvent._SetFld("Status",status)
		orderEvent._SetFld("CorpCode",corpCode)
		orderEvent._SetFld("MarketName",marketName)
		orderEvent._SetFld("BAMapID",baMapID)
		orderEvent._SetFld("ReserveString",reserveString)
		for tempSessionID,v in pairs(gtSessionTable) do 
			if tempSessionID==sessionID or sessionID=="All" then 
				if  gtSessionTable[tempSessionID].CurBAMapIDTable then
					if  gtSessionTable[tempSessionID].CurBAMapIDTable[baMapID] then		
						_SendEventToClient(orderEvent,tempSessionID);
					end
				end
			end
		end
	end
end

--刷新单条成交
function RefreshSingleExec(sessionID,corpCode,table)
	local baMapID = table.BAMapID
	local fare = table.Fare
	local fare1 = 0
	local fare2 = 0
	local fare3 = 0
	if gInitialized then
		local baMapID= table.BAMapID
		local temp = {}
		temp.BAMapID = baMapID
		temp.IssueCode = table.IssueCode
		temp.OpenClose = table.OpenClose
		temp.ExecValue = table.ExecAmount
		temp.Quantity =table.Quantity
		temp.ExecQty = table.ExecQty
		temp.CreRed = table.CreRed
		temp.BS = table.BuySell
		temp.IsInternal = table.IsInternal
		temp.WithFare = table.WithFare
		
		local accountCode=_PosBAMapAccount[baMapID] or baMapID
		local fareTable =PosFareDetail(accountCode, temp.IssueCode, temp)
		fare = fareTable.TotalFare or 0
		fare1 = fareTable.Fare or 0
		fare1 = showFormat(fare1,1)
		fare2 = fareTable.TransferExpense or 0
		fare2 = showFormat(fare2,1)
		fare3 = fareTable.StampTax or 0
		fare3 = showFormat(fare3,1)
	end
	local execTime = table.ExecTime
	local issueCode = table.IssueCode
	local marketCode = table.MarketCode
	local issueName = _PosIssueNameTable[issueCode]
	local buySell = table.BuySell
	if buySell == "3" then
		buySell = "买"
	else
		buySell = "卖"
	end
	local marginType = table.MarginType
	local execPrice = table.ExecPrice
	local execQty = table.ExecQty
	local execAmount = table.ExecAmount
	if fare and fare ~= "" then
		fare = fare.getNumberValue()
	end

	local contractSize = 1
	if _PosIssueContractSizeTable[issueCode] then
		contractSize = _PosIssueContractSizeTable[issueCode]
	end
	contractSize = contractSize.getNumberValue()
	local costPrice = execPrice
	if fare and fare ~= "" and execAmount and execAmount ~= "" and execQty ~= 0 and contractSize and contractSize ~= 0 then
		if  buySell=="买" then
			costPrice = (fare + execAmount.getNumberValue()) / (execQty.getNumberValue() * contractSize)
		else
			costPrice = (execAmount.getNumberValue()-fare) / (execQty.getNumberValue() * contractSize)
		end
		local formatPriceExponent = getPriceFormat(issueCode);
		costPrice = sys_format(formatPriceExponent, costPrice);
	end
	local execNo = table.ExecNo
	local marketName = gtMarketNameTable[marketCode]
	if execAmount and execAmount ~= "" then
		execAmount = showFormat(execAmount,1)
	end
	if fare and fare ~= "" then
		fare = showFormat(fare,1)
	end
	if execQty and execQty ~= "" then
		execQty = showFormat(execQty,2)
	end
	local formatPriceExponent = getPriceFormat(issueCode);
	if execPrice and execPrice ~= "" then
		execPrice = sys_format(formatPriceExponent, execPrice);
	end
	local uniqueKey = table.UniqueKey
	local ExecShowMode=1
	if gtSessionTable[sessionID] then 
		ExecShowMode=gtSessionTable[sessionID].ExecShowMode or 1
	end
	if marketCode == "1" or marketCode == "2" then		
		if ExecShowMode==1 then
			local DTSEvent execEvent = _CreateEventObject("S_ExecEvent")
			execEvent._SetFld("ExecTime",execTime)
			execEvent._SetFld("IssueCode",issueCode)
			execEvent._SetFld("IssueName",issueName)
			execEvent._SetFld("BuySell",buySell)
			if table.OpenClose == 0 and table.CreRed == 5 and table.BuySell=="1" then
				local temp = "融券回购"
				execEvent._SetFld("BuySell",temp)
				local faceValue = _PosIssueFaceValueTable[issueCode] or 0
				execAmount = execQty * faceValue--债券回购的成交金额=数量*面值
				costPrice=faceValue
				execAmount = showFormat(execAmount,1)
			end
			execEvent._SetFld("ExecPrice",execPrice)
			execEvent._SetFld("CostPrice",costPrice)
			execEvent._SetFld("ExecQty",execQty)
			execEvent._SetFld("ExecAmount",execAmount)
			execEvent._SetFld("ExecNo",execNo)
			execEvent._SetFld("MarketName",marketName)
			execEvent._SetFld("BAMapID",baMapID)
			execEvent._SetFld("Fare",fare)
			execEvent._SetFld("Fare1",fare1)
			execEvent._SetFld("Fare2",fare2)
			execEvent._SetFld("Fare3",fare3)
			execEvent._SetFld("CorpCode",corpCode)
			if table.IsInternal~=1 or gInternalExecShowMode~="1" then				
				for tempSessionID,v in pairs(gtSessionTable) do 
					if tempSessionID==sessionID or sessionID=="All" then 
						if  gtSessionTable[tempSessionID].CurBAMapIDTable then	
							if  gtSessionTable[tempSessionID].CurBAMapIDTable[baMapID] then		
								_SendEventToClient(execEvent,tempSessionID);
							end
						end
					end
				end				
			end
		elseif ExecShowMode==2 then
			local showKey = sys_format("%s.%s.%s",table.BAMapID,table.IssueCode,table.BuySell)
			_WriteAplLog(showKey)
			if gtExecShowAllTable[showKey] then
				local sumFare = gtExecShowAllTable[showKey].sumFare
				local sumFare1 = gtExecShowAllTable[showKey].sumFare1 
				local sumFare2 = gtExecShowAllTable[showKey].sumFare2 
				local sumFare3 = gtExecShowAllTable[showKey].sumFare3 
				local sumExecQty = gtExecShowAllTable[showKey].sumExecQty
				local sumExecAmount = gtExecShowAllTable[showKey].sumExecAmount
				local sumexecPrice = sumExecAmount / (sumExecQty * contractSize)
				
				local DTSEvent execEvent = _CreateEventObject("S_ExecEvent")
				execEvent._SetFld("ExecTime","")
				execEvent._SetFld("IssueCode",issueCode)
				execEvent._SetFld("IssueName",issueName)
				execEvent._SetFld("BuySell",buySell)
				if table.OpenClose == 0 and table.CreRed == 5 and table.BuySell=="1" then
					local temp = "融券回购"
					execEvent._SetFld("BuySell",temp)
					local faceValue = _PosIssueFaceValueTable[issueCode] or 0
					sumExecAmount = sumExecQty * faceValue--债券回购的成交金额=数量*面值
					sumexecPrice=faceValue
				end
				if sumexecPrice and sumexecPrice ~= "" then
					local formatPriceExponent=getPriceFormat2(issueCode,1);
					sumexecPrice = sys_format(formatPriceExponent, sumexecPrice);
				end
				execEvent._SetFld("ExecPrice",sumexecPrice)
				execEvent._SetFld("CostPrice","")
				sumExecQty = sys_format("%d",sumExecQty);
				execEvent._SetFld("ExecQty",sumExecQty)
				sumExecAmount = sys_format("%.2f", sumExecAmount);
				execEvent._SetFld("ExecAmount",sumExecAmount)
				execEvent._SetFld("ExecNo","")
				execEvent._SetFld("MarketName",marketName)
				execEvent._SetFld("BAMapID",baMapID)
				sumFare = sys_format("%.2f", sumFare);
				execEvent._SetFld("Fare",sumFare)
				sumFare1 = sys_format("%.2f", sumFare1);
				execEvent._SetFld("Fare1",sumFare1)
				sumFare2 = sys_format("%.2f", sumFare2);
				execEvent._SetFld("Fare2",sumFare2)
				sumFare3 = sys_format("%.2f", sumFare3);
				execEvent._SetFld("Fare3",sumFare3)
				execEvent._SetFld("CorpCode","")
				if sumExecQty-0>0 then				
					for tempSessionID,v in pairs(gtSessionTable) do 
						if tempSessionID==sessionID or sessionID=="All" then 
							if gtSessionTable[tempSessionID].CurBAMapIDTable then
								if  gtSessionTable[tempSessionID].CurBAMapIDTable[baMapID] then		
									_SendEventToClient(execEvent,tempSessionID);
								end
							end
						end
					end	
				end 
			end
		end 
	elseif marketCode == "3" or marketCode == "4" or marketCode == "5" or marketCode == "6" then
		local DTSEvent execEvent = _CreateEventObject("F_ExecEvent")
		execEvent._SetFld("ExecTime",execTime)
		execEvent._SetFld("IssueCode",issueCode)
		execEvent._SetFld("IssueName",issueName)
		execEvent._SetFld("MarginType",marginType)
		execEvent._SetFld("ExecPrice",execPrice)
		execEvent._SetFld("CostPrice",costPrice)
		execEvent._SetFld("ExecQty",execQty)
		execEvent._SetFld("ExecAmount",execAmount)
		execEvent._SetFld("ExecNo",execNo)
		execEvent._SetFld("MarketName",marketName)
		execEvent._SetFld("BAMapID",baMapID)
		execEvent._SetFld("Fare",fare)
		execEvent._SetFld("Fare1",fare1)
		execEvent._SetFld("Fare2",fare2)
		execEvent._SetFld("Fare3",fare3)
		execEvent._SetFld("CorpCode",corpCode)
		for tempSessionID,v in pairs(gtSessionTable) do 
			if tempSessionID==sessionID or sessionID=="All" then
				if gtSessionTable[tempSessionID].CurBAMapIDTable then
					if  gtSessionTable[tempSessionID].CurBAMapIDTable[baMapID] then		
						_SendEventToClient(execEvent,tempSessionID);
					end
				end
			end
		end
	end
	for tempSessionID,v in pairs(gtSessionTable) do 
		if tempSessionID==sessionID or sessionID=="All" then
			sendQuantityBalance(tempSessionID)
		end
	end
end
--价格回调
function OnPrice(issueCode, priceInfo)

end

--使用持仓库必须定义函数之一，可以只为空函数。
function OnPositionError(errorInfo)
    local tmp = errorInfo;
	local logs = sys_format("OnPositionError:[%s]",tmp);
	_WriteAplLog(logs);
end

--使用持仓库必须定义函数之一，可以只为空函数。
function OnPositionDebugInfo(debugInfo)
	local tmp = debugInfo
	local logs = sys_format("OnPositionDebugInfo:[%s]",tmp);
	_WriteAplLog(logs);
end

--使用持仓库必须定义函数之一，可以只为空函数。
function OnBackTestDayEnd()
	local log = sys_format("OnBackTestDayEnd() start, %s",_PosBackTestDate)
	_WriteAplLog(log)
end

--输出格式显示函数 formatType 1:保留两位小数 2:不显示科学计数法 3:时间格式为09:15:20
function showFormat(data,formatType)
	if data ~= nil and data ~= "" then
		if formatType == 1 then
			data = sys_format("%.2f",data)
		elseif formatType == 2 then
			data = sys_format("%.0f",data)
		elseif formatType == 3 then
			local timeH = sys_sub(data,1,2)
			local timeM = sys_sub(data,3,4)
			local timeS = sys_sub(data,5,6)
			data = timeH..":"..timeM..":"..timeS
		end
	end
	return data
end

--检查单子
function CheckOrder(issueCode, bs, oc, creRed)
	local log = sys_format("CheckOrder, issue=[%s], bs=[%s], oc=[%s], creRed=[%s]", issueCode, bs, oc, creRed)
	_WriteAplLog(log)

	local ret = {}
	ret.Result = true
	ret.Reason = ""

	local marketCode = _PosIssueMarketTable[issueCode]
	local productCode = _PosIssueProductCodeTable[issueCode]

	--上证深证不支持空头
	if marketCode == "1" or marketCode == "2" then
		if creRed == 0 then
			if bs == "1" and oc == 0 then
				ret.Result = false
				ret.Reason = sys_format("合约 [ %s ] 不支持空头开仓", issueCode)
				return ret
			elseif bs == "3" and (oc == 1 or oc == 2 or oc == 3) then
				ret.Result = false
				ret.Reason = sys_format("合约 [ %s ] 不支持空头平仓", issueCode)
				return ret
			end
		end
	end

	--回购合约不支持普通买卖
	if productCode == "12" and creRed == 0 then
		if bs == "3" and oc == 0 then
			ret.Result = false
			ret.Reason = sys_format("合约 [ %s ] 不支持买操作, 只支持融资回购和融券回购", issueCode)
		elseif bs == "1" and oc == 1 then
			ret.Result = false
			ret.Reason = sys_format("合约 [ %s ] 不支持卖操作, 只支持融资回购和融券回购", issueCode)
		end
	end

	--只有上期支持平今指令
	if marketCode ~= "4" and oc == 2 and creRed == 0 then
		ret.Result = false
		ret.Reason = sys_format("合约 [ %s ] 不支持平今指令, 只有上期交易所支持", issueCode)
		return ret
	end
	return ret
end

--取得Order的DealerID
function GetOrderDealerID(baMapID)
	local log = sys_format("GetOrderDealerID, baMapID=%s", baMapID)
	_WriteAplLog(log)

	--如果是本用户的BAMapID,则DealerID就为本用户
	local orderDealerID
	local currentUserID = _GetDealerID()--当前用户
	if _PosUserBAMapTable[currentUserID] then
		if _PosUserBAMapTable[currentUserID][baMapID] then
			orderDealerID = currentUserID
		end
	end

	--如果当前用户对baMapID所属的用户至少存在一个有读写权限的,则当前用户可以用该BAMapID下单
	if not orderDealerID then
		local userIDTable = _PosBAMapUserTable[baMapID]--baMapID在UserBAMapTable中所属的用户
		for baMapUserID, dummy in pairs(userIDTable) do
			if _PosUserAccessUserTable[currentUserID] then
				local right = _PosUserAccessUserTable[currentUserID][baMapUserID]
				local tmplog = sys_format("currentUserID=%s, baMapUserID=%s, right=%s", currentUserID, baMapUserID, right)
				_WriteAplLog(tmplog)
				if right == 11 then--0:没有读写权限, 1:只有读权限, 10:只有写权限, 11:有读写权限
					orderDealerID = baMapUserID;
					break;
				end
			end
		end
	end

	return orderDealerID
end

--期货、证券下单处理
function CheckSubmitIssue(sessionID,IssueCode,baMapID)
	local accountCode = _PosBAMapAccount[baMapID]
	if _PosIssueMarketTable[IssueCode] == "3" or _PosIssueMarketTable[IssueCode] == "4" or _PosIssueMarketTable[IssueCode] == "5" or _PosIssueMarketTable[IssueCode] == "6" then
		if _PosFundStatus[accountCode].Type == "S" then
			local log  = "下单失败：请设置期货账户下期货单"
			showLog(sessionID,log)
			return false
		end
	else
		if _PosFundStatus[accountCode].Type == "F" then
			local log  = "下单失败：请设置证券账户下证券单"
			_WriteAplLog(log)
			showLog(sessionID,log)

			return false
		end
	end
	if _PosFundStatus[accountCode].Type == "M" then
			local log  = "下单失败：不支持信用账户下单"
			_WriteAplLog(log)
			showLog(sessionID,log)

			return false
		end
	return true
end


function GetAccountName(accountCode)
	local accountName = accountCode
	if accountCode ~= nil then
		if gtAccountName[accountCode] then
			accountName = gtAccountName[accountCode]
		end
	end
	return accountName
end

function GetUserName(userID)
	local userName = userID
	if userID ~= nil then
		if gtUserName[userID] then
			userName = gtUserName[userID]
		end
	end
	return userName
end

--发送持仓汇总记录
function SendPos_SumData(sessionID)
	if not gtSessionTable[sessionID] then
		return
	end
	if not gtSessionTable[sessionID].CurBAMapIDTable then
		return 
	end
	local sumQty = 0		--持仓数量合计
	local sumTodayQty = 0   --今日持仓数量合计
	local sumPrevQty = 0    --昨日持仓数量合计
	local sumAvlQty = 0		--可用数量合计
	local sumValuationPL = 0--盈亏合计
	local sumMarketValue = 0--市值合计
	local sumMagin = 0 --统计保证金
	local sumPL = 0
	local sumForbidPosition = 0 -- 禁用数量合计
	
	local flagCumulationPL=false
	local allUser={}
	local ltPos={}
	if gtSessionTable[sessionID].SelectedBAMapID == "全部" then
		flagCumulationPL=true
		local SelectedUserID=gtSessionTable[sessionID].SelectedUserID

		if  SelectedUserID=="全部" then
			local currentUserID = _GetDealerID()
			allUser[currentUserID]=1
			if gtPosUserAccessUserTable[currentUserID] then
				for accessUserID,v in pairs(gtPosUserAccessUserTable[currentUserID]) do
					allUser[accessUserID]=1
				end
			end
		else
			allUser[SelectedUserID]=1
			if gtPosUserAccessUserTable[SelectedUserID] then
				for accessUserID,v in pairs(gtPosUserAccessUserTable[SelectedUserID]) do
					allUser[accessUserID]=1
				end
			end
		end
	end 

	for posKey, pos in pairs(_PosPositionTable) do
		if gtSessionTable[sessionID].CurBAMapIDTable[pos.BAMapID] then
			local lastPrice
			local marketValue = 0
			local priceInfo = _PosPriceTable[pos.IssueCode]
			if priceInfo then
				lastPrice = priceInfo.LastPrice
			end
			local contractSize = 1
			if _PosIssueContractSizeTable[pos.IssueCode] then
				contractSize = _PosIssueContractSizeTable[pos.IssueCode]
			end
			local formatPriceExponent = getPriceFormat(pos.IssueCode);
			if lastPrice then
				marketValue = lastPrice * pos.Quantity * contractSize
				marketValue = sys_format(formatPriceExponent, marketValue)
			end

			sumQty = sumQty + (pos.Quantity).getNumberValue()
			sumQty = showFormat(sumQty,2)
			
			
			sumTodayQty = sumTodayQty + (pos.TodayQuantity).getNumberValue()
			sumTodayQty = showFormat(sumTodayQty,2)

			sumPrevQty = sumPrevQty + (pos.PrevQuantity).getNumberValue()
			sumPrevQty = showFormat(sumPrevQty,2)
			
			local ForbidPosition = 0
			if gtBAMapID2ForbidPositionTable[posKey] then
				ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition
				local avlQuantity = (pos.AvlQuantity).getNumberValue()
				if avlQuantity < ForbidPosition and avlQuantity >= 0 then
					gtBAMapID2ForbidPositionTable[posKey].ForbidPosition = avlQuantity
					--gtIssueCode2ForbidPosition[pos.IssueCode] = gtIssueCode2ForbidPosition[pos.IssueCode] - (ForbidPosition - avlQuantity)
					ForbidPosition = avlQuantity
				end
			end
			--_WriteAplLog(ForbidPosition)
			sumForbidPosition = sumForbidPosition + ForbidPosition
			--sumForbidPosition = showFormat(sumForbidPosition,2)
			sumAvlQty = sumAvlQty + (pos.AvlQuantity).getNumberValue() - ForbidPosition
			sumAvlQty = showFormat(sumAvlQty,2)

			sumValuationPL = sumValuationPL + (showFormat(pos.ValuationPL,1)).getNumberValue()
			sumValuationPL = showFormat(sumValuationPL,1)

			sumMarketValue = sumMarketValue + marketValue.getNumberValue()
			sumMarketValue = showFormat(sumMarketValue,1)
			
			sumMagin = sumMagin + (pos.Margin).getNumberValue()
			sumMagin = showFormat(sumMagin, 1)
			local cumulationAdjustPL=pos.CumulationAdjustPL or 0  --调整累计平仓盈亏,用来调整成本价
			sumPL = sumPL + (pos.CumulationPL).getNumberValue() + (pos.RealizedPL).getNumberValue() + (pos.ValuationPL).getNumberValue()+cumulationAdjustPL - ((pos.CumulationFare).getNumberValue() + (pos.Fare).getNumberValue())
			
			ltPos[pos.IssueCode]=ltPos[pos.IssueCode] or {}
			ltPos[pos.IssueCode][pos.BASubID]=1
		end
	end
	if flagCumulationPL then
		for issueCode,v in pairs(ltPos) do
			for baSubID,v in pairs(ltPos[issueCode]) do
				for user,v in pairs(allUser) do
					if not gtPosUserAccessUserTable[user] then 
						if gtUserCumulationPLTable[user] then
							if gtUserCumulationPLTable[user][issueCode] then
								if gtUserCumulationPLTable[user][issueCode][baSubID] then
									sumPL=sumPL+gtUserCumulationPLTable[user][issueCode][baSubID]
								end
							end
						end
					end
				end
			end
		end
	end
	sumPL = showFormat(sumPL, 1)

	sumValuationPL = "￥" .. sumValuationPL.toString()
	sumMarketValue = "￥" .. sumMarketValue.toString()
	sumMagin = "￥" .. sumMagin.toString()

	local firstBAMapID = ""
	for baMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
		local accountCode = _PosBAMapAccount[baMapID]
		if accountCode then
			firstBAMapID = baMapID
			break
		end
	end
	
	local qtyLog = sys_format("合计:sumAvlQty[%s],sumForbidPosition[%s]",sumAvlQty,sumForbidPosition)
	--_WriteAplLog(qtyLog)

	local accountCode = _PosBAMapAccount[firstBAMapID]
	if accountCode then
		if _PosFundStatus[accountCode] then
			local accountCodeType = _PosFundStatus[accountCode].Type
			if accountCodeType == "S" then
				local DTSEvent s_PosEvent = _CreateEventObject("S_PosEvent")
				s_PosEvent._SetFld("IssueCode", "合计")
				s_PosEvent._SetFld("IssueName", "")
				s_PosEvent._SetFld("Quantity", sumQty)
				s_PosEvent._SetFld("AvlQuantity", sumAvlQty)
				s_PosEvent._SetFld("ForbidPosition", sumForbidPosition)
				s_PosEvent._SetFld("WorkingQuantity", "")
				s_PosEvent._SetFld("Cost", "")
				s_PosEvent._SetFld("LastPrice","")
				s_PosEvent._SetFld("CumulationAdjustPL","")
				s_PosEvent._SetFld("PL",sumPL)
				s_PosEvent._SetFld("ValuationPL", sumValuationPL)
				s_PosEvent._SetFld("PLRatio", "")
				s_PosEvent._SetFld("MarketValue", sumMarketValue)
				s_PosEvent._SetFld("MarketName","" )
				s_PosEvent._SetFld("BAMapID", "")
				s_PosEvent._SetFld("BASubID", "")
				_SendEventToClient(s_PosEvent,sessionID);
			else
				local DTSEvent f_PosEvent = _CreateEventObject("F_PosEvent")
				f_PosEvent._SetFld("IssueCode", "合计")
				f_PosEvent._SetFld("IssueName", "")
				f_PosEvent._SetFld("LongShortStr", "")
				f_PosEvent._SetFld("Quantity", sumQty)
				f_PosEvent._SetFld("AvlQuantity", sumAvlQty)
				f_PosEvent._SetFld("WorkingQuantity", "")
				f_PosEvent._SetFld("Cost", "")
				f_PosEvent._SetFld("LastPrice", "")
				f_PosEvent._SetFld("ValuationPL", sumValuationPL)
				f_PosEvent._SetFld("PLRatio", "")
				f_PosEvent._SetFld("MarketValue", sumMarketValue)
				f_PosEvent._SetFld("MarketName","" )
				f_PosEvent._SetFld("BAMapID", "")
				f_PosEvent._SetFld("BASubID", "")
				f_PosEvent._SetFld("Margin", sumMagin)
				f_PosEvent._SetFld("TodayQuantity", sumTodayQty)
				f_PosEvent._SetFld("PrevQuantity", sumPrevQty)
				_SendEventToClient(f_PosEvent,sessionID);
			end
		end
	end
end

-- 股票状态判断
function stateJudge(issueCode)
	local tIssuePriceInfo = _PosPriceTable[issueCode];
	if not _PosPriceTable[issueCode] then
		return ""
	else
		local askQty1 = tIssuePriceInfo.AskQuantity1;
		local askQty2 = tIssuePriceInfo.AskQuantity2;
		local askQty3 = tIssuePriceInfo.AskQuantity3;
		local askQty4 = tIssuePriceInfo.AskQuantity4;
		local askQty5 = tIssuePriceInfo.AskQuantity5;
		local bidQty1 = tIssuePriceInfo.BidQuantity1;
		local bidQty2 = tIssuePriceInfo.BidQuantity2;
		local bidQty3 = tIssuePriceInfo.BidQuantity3;
		local bidQty4 = tIssuePriceInfo.BidQuantity4;
		local bidQty5 = tIssuePriceInfo.BidQuantity5;
		if (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
			local DTSTime nowtime = _GetNowTime();
			local smtime = nowtime.asString("%H%M%S");
			local marketCode = _PosIssueMarketTable[issueCode]
			if marketCode=="1" or marketCode=="2" then
				if smtime>"0925"  then
					return "停牌";	--SusPend 停牌
				else
					return "";
				end
			else
				return "停牌";
			end
		elseif (askQty1 > 0 or askQty2 > 0 or askQty3 > 0 or askQty4 > 0 or askQty5 > 0) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
			return "跌停";	--Decline Limit 跌停
		elseif (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 > 0 or bidQty2 > 0 or bidQty3 > 0 or bidQty4 > 0 or bidQty5 > 0) then
			return "涨停";	--Surged Limit 涨停
		else--if (askQty1>0 and askQty2>0 and askQty3>0 and askQty4>0 and askQty5>0) and (bidQty1>0 and bidQty2>0 and bidQty3>0 and bidQty4>0 and bidQty5>0) then
			return "";	--NorMal 正常
		end
	end
end
function RefreshPosition(sessionID,pos)
	if not pos then
		return
	end
	if not gtSessionTable[sessionID] then
		return
	end 
	if not gtSessionTable[sessionID].CurBAMapIDTable then
		return
	end 
	if pos.BAMapID~="全部" then 
		if not gtSessionTable[sessionID].CurBAMapIDTable[pos.BAMapID] then
			return
		end 
	else
		if pos.BAMapID~=gtSessionTable[sessionID].SelectedBAMapID then
			return
		end
	end
	
	local issueCode=pos.IssueCode;
	local issueName=_PosIssueNameTable[issueCode];
	local formatPriceExponent = getPriceFormat(issueCode);
	local quantity=pos.Quantity;
	local todayqty = pos.TodayQuantity
	local prevqty = pos.PrevQuantity
	local avlQuantity = pos.AvlQuantity;
	
	local ForbidPosition = 0
	if pos.BAMapID~="全部" then
		local posKey = sys_format("%s.%s.%s",pos.BAMapID,pos.BASubID,issueCode)
		if gtBAMapID2ForbidPositionTable[posKey] then
			ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition
			if avlQuantity < ForbidPosition and avlQuantity >= 0 then
				gtBAMapID2ForbidPositionTable[posKey].ForbidPosition = avlQuantity
				--gtIssueCode2ForbidPosition[pos.IssueCode] = gtIssueCode2ForbidPosition[pos.IssueCode] - (ForbidPosition - avlQuantity)
				ForbidPosition = avlQuantity
			end
		end
	else
		if gtIssueCode2ForbidPosition[issueCode] then
			ForbidPosition = gtIssueCode2ForbidPosition[issueCode]	
			local logg = sys_format("XXX avlQuantity[%s],ForbidPosition[%s]",avlQuantity,ForbidPosition)
			_WriteAplLog(logg)
			if avlQuantity < ForbidPosition and avlQuantity >= 0 then
				gtIssueCode2ForbidPosition[pos.IssueCode] = avlQuantity
				ForbidPosition = avlQuantity
			end
		end
	end
	
	avlQuantity = avlQuantity - ForbidPosition
							
	local workingQuantity = pos.WorkingQtyOfClose;
	local amount=pos.Amount;
	local margin=pos.Margin
	margin = sys_format(formatPriceExponent, margin)
	local contractSize = 1
	if _PosIssueContractSizeTable[issueCode] then
		contractSize = _PosIssueContractSizeTable[issueCode]
	end
	local isSend=false
	if quantity>0 then
		isSend=true
	else
		local poskey=pos.BAMapID.."."..pos.BASubID.."."..pos.IssueCode
		if gtTtradeExec[poskey] then
			isSend=true
		end
	end
	if not isSend then
		return
	end
	local averagePrice = 0
	if quantity > 0 then
	    averagePrice=amount/quantity/ contractSize
	end

	local valuationPL=pos.ValuationPL
	valuationPL = showFormat(valuationPL,1)
	local valuationPLM2D=pos.ValuationPLM2D
	valuationPLM2D = showFormat(valuationPLM2D,1)
	
	local cost = 0
	local cumulationPL=pos.CumulationPL --截止上一交易日为止的累计平仓盈亏
	local cumulationAdjustPL=pos.CumulationAdjustPL or 0  --调整累计平仓盈亏,用来调整成本价
	local realizedPL=pos.RealizedPL --逐笔平仓盈亏
	cumulationPL=cumulationPL+realizedPL
	
	local cumulationFare=pos.CumulationFare
	cumulationFare=cumulationFare+pos.Fare
	
	if (cumulationPL == nil) then
		cumulationPL=0
	end
	
	if (valuationPL == nil) then
		valuationPL=0
	end
	
	if (cumulationFare == nil) then
		cumulationFare=0
	end
	
	local pl=cumulationPL+valuationPL+cumulationAdjustPL-cumulationFare
	pl = showFormat(pl,1)

	
	local cumulationDividend=pos.CumulationDividend or 0 --截止上一交易日为止的累计分红
	if quantity > 0 then
		cost=(cumulationFare+amount-cumulationPL-cumulationAdjustPL)/quantity/ contractSize
	end
	cumulationPL = showFormat(cumulationPL,1)
	cumulationAdjustPL = showFormat(cumulationAdjustPL,1)
	cumulationFare = showFormat(cumulationFare,1)
	cumulationDividend = showFormat(cumulationDividend,1)
	local lastPrice
	local marketValue
	local priceInfo = _PosPriceTable[issueCode]
	if priceInfo then
		lastPrice = priceInfo.LastPrice
	end
	if lastPrice then
		marketValue = lastPrice * quantity * contractSize
		marketValue = sys_format(formatPriceExponent, marketValue)
		lastPrice = sys_format(formatPriceExponent, lastPrice)
	else
		lastPrice = "-"
		marketValue = "-"
	end


	local marketCode = _PosIssueMarketTable[issueCode]
	local marketName = gtMarketNameTable[marketCode]
	local bAMapID = pos.BAMapID
	local bASubID = pos.BASubID


	local firstBAMapID = ""
	for baMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
		firstBAMapID = baMapID
		break
	end

	local accountCode = _PosBAMapAccount[firstBAMapID]
	if accountCode then
		if _PosFundStatus[accountCode] then
			local accountCodeType = _PosFundStatus[accountCode].Type
			if accountCodeType == "S"  or accountCodeType == "M" then
				local PLRatio = 0.000		--盈亏比例
				if cost and cost ~= "" and lastPrice and lastPrice ~= "-" and lastPrice ~= "" and lastPrice ~= 0 then
					if cost-0.0001>0 then
						PLRatio = (lastPrice-cost) / cost* 100
						PLRatio =  sys_format("%.3f",PLRatio)
					end
				end
			
				local DTSEvent s_PosEvent = _CreateEventObject("S_PosEvent")
				
				local qtyLog = sys_format("S_PosEvent:issueCode[%s],avlQuantity[%s],ForbidPosition[%s]",issueCode,avlQuantity,ForbidPosition)
				--_WriteAplLog(qtyLog)
				
				s_PosEvent._SetFld("IssueCode", issueCode)
				s_PosEvent._SetFld("IssueName", issueName)
				s_PosEvent._SetFld("Quantity", showFormat(quantity, 2))
				s_PosEvent._SetFld("AvlQuantity", showFormat(avlQuantity, 2))
				--s_PosEvent._SetFld("ForbidPosition", showFormat(ForbidPosition, 2))
				s_PosEvent._SetFld("ForbidPosition", ForbidPosition)
				s_PosEvent._SetFld("WorkingQuantity", showFormat(workingQuantity, 2))
				local formatPriceExponent2=getPriceFormat2(issueCode,1);
				averagePrice=sys_format(formatPriceExponent2, averagePrice);
				cost=sys_format(formatPriceExponent2, cost);
				s_PosEvent._SetFld("AveragePrice", averagePrice)
				s_PosEvent._SetFld("Cost", cost)
				s_PosEvent._SetFld("PL", pl)
				s_PosEvent._SetFld("CumulationFare", cumulationFare)
				s_PosEvent._SetFld("CumulationPL", cumulationPL)
				s_PosEvent._SetFld("CumulationAdjustPL", cumulationAdjustPL)
				s_PosEvent._SetFld("CumulationDividend", cumulationDividend)

				s_PosEvent._SetFld("LastPrice", lastPrice)
				s_PosEvent._SetFld("ValuationPL", valuationPL)
				s_PosEvent._SetFld("PLRatio", PLRatio)
				s_PosEvent._SetFld("MarketValue", marketValue)
				s_PosEvent._SetFld("MarketName",marketName )
				s_PosEvent._SetFld("BAMapID", bAMapID)
				s_PosEvent._SetFld("BASubID", bASubID)

				local reserveString=""
				if pos.BAMapID == "全部" then
					local sumOvernightQty = 0
					for posKey, overnightQty in pairs(gtOvernightSPLITData) do
						if gtOvernightSPLITData[posKey].IssueCode == issueCode then
							sumOvernightQty = gtOvernightSPLITData[posKey].OvernightQty + sumOvernightQty
						end
					end
					if sumOvernightQty>0 then
						reserveString=sys_format("送股%d",sumOvernightQty)
					end
				else
					local posKey = bAMapID .. "." .. bASubID .. "." .. issueCode
					if gtOvernightSPLITData[posKey] then
						reserveString=sys_format("送股%d",gtOvernightSPLITData[posKey].OvernightQty)
					end
				end
				local priceStatues=stateJudge(issueCode)
				if priceStatues~="" then
					if reserveString=="" then
						reserveString=priceStatues
					else
						reserveString=reserveString..","..priceStatues
					end
				end
				s_PosEvent._SetFld("ReserveString", reserveString)
				_SendEventToClient(s_PosEvent,sessionID);
			else
				local PLRatio = 0.00		--盈亏比例
				if valuationPL and valuationPL ~= "" and amount and amount ~= "" and amount ~= 0 then
					PLRatio = valuationPL.getNumberValue() / amount.getNumberValue() * 100
					PLRatio =  sys_format("%.3f",PLRatio)
				end
			
			
				local longShort = sys_sub(bASubID,1,1)
				local longShortStr = ""
				if longShort == "1" then
					longShortStr = "空"
				elseif longShort == "3" then
					longShortStr = "多"
				end
				local prevClearingPrice
				local clearingPrice
				if _PosPriceTable[issueCode] then
					prevClearingPrice=_PosPriceTable[issueCode].LastClear
					clearingPrice=_PosPriceTable[issueCode].ClearingPrice
				end 
				if not prevClearingPrice or prevClearingPrice=="" then
					if _PosPrevClearingPriceTable[issueCode] then 
						prevClearingPrice =_PosPrevClearingPriceTable[issueCode]
					end 
				end 			
				local posPrice=averagePrice
				local todayAmount=pos.TodayAmount
				if prevqty>0 then
					if prevClearingPrice and prevClearingPrice~="" then 
						local contractSize = _PosIssueContractSizeTable[issueCode]
						posPrice=(prevqty*prevClearingPrice+todayAmount/contractSize)/quantity
						posPrice = sys_format(formatPriceExponent, posPrice)
					end 
				end 
				if clearingPrice and clearingPrice~="" then 
					clearingPrice = sys_format(formatPriceExponent, clearingPrice)
				else
					clearingPrice = ""
				end 
				if prevClearingPrice and prevClearingPrice~="" then 
					prevClearingPrice = sys_format(formatPriceExponent, prevClearingPrice)
				else 
					prevClearingPrice = ""
				end	
				
				PLRatio = 0.00		--盈亏比例
				PLRatio =valuationPL/margin * 100
				PLRatio =  sys_format("%.3f",PLRatio)
				local DTSEvent f_PosEvent = _CreateEventObject("F_PosEvent")
				f_PosEvent._SetFld("IssueCode", issueCode)
				f_PosEvent._SetFld("IssueName", issueName)
				f_PosEvent._SetFld("LongShortStr", longShortStr)
				f_PosEvent._SetFld("Quantity", showFormat(quantity,2))
				f_PosEvent._SetFld("AvlQuantity", showFormat(avlQuantity,2))
				f_PosEvent._SetFld("WorkingQuantity", showFormat(workingQuantity,2))
				averagePrice=sys_format(formatPriceExponent, averagePrice);
				f_PosEvent._SetFld("Cost", averagePrice)
				f_PosEvent._SetFld("PosPrice", posPrice)
				f_PosEvent._SetFld("LastPrice", lastPrice)
				f_PosEvent._SetFld("PrevClearingPrice", prevClearingPrice)
				f_PosEvent._SetFld("ClearingPrice", clearingPrice)
				f_PosEvent._SetFld("ValuationPL", valuationPL)
				f_PosEvent._SetFld("ValuationPLM2D",valuationPLM2D)			
				f_PosEvent._SetFld("PLRatio", PLRatio)
				f_PosEvent._SetFld("MarketValue", marketValue)
				f_PosEvent._SetFld("MarketName",marketName )
				f_PosEvent._SetFld("BAMapID", bAMapID)
				f_PosEvent._SetFld("BASubID", bASubID)
				f_PosEvent._SetFld("Margin", margin)
				f_PosEvent._SetFld("TodayQuantity", showFormat(todayqty, 2))
				f_PosEvent._SetFld("PrevQuantity", showFormat(prevqty, 2))
				_SendEventToClient(f_PosEvent,sessionID);
			end
		end
	end
end

function RefreshBondRepPosition(sessionID,bondRepPosition)
	local issueCode=bondRepPosition.IssueCode
	local issueName=_PosIssueNameTable[issueCode]
	local bAMapID=bondRepPosition.BAMapID
	local bASubID=bondRepPosition.BASubID
	local quantity=bondRepPosition.Quantity
	local avlQuantity=bondRepPosition.AvlQuantity
	
	local posKey = sys_format("%s.%s.%s",bAMapID,bASubID,issueCode)
	local ForbidPosition = 0
	if gtBAMapID2ForbidPositionTable[posKey] then
		ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition
	end
	avlQuantity = avlQuantity - ForbidPosition
	
	local sumInterest=0
	local avgPrice=0
	local sumQuantity=0
	local sumAmount=0
	for seqNo, exec in ipairs(bondRepPosition.OpenExecList) do
		local estInterest = exec.EstInterest--回购预估利息
		local price = exec.Price--回购利率
		local quantity = exec.Quantity--回购数量
		sumAmount=exec.Price*exec.Quantity
		sumQuantity=sumQuantity+quantity
		sumInterest=sumInterest+estInterest
	end
	if sumQuantity>0 then
		avgPrice=sumAmount/sumQuantity
	end
	local DTSEvent s_PosEvent = _CreateEventObject("S_PosEvent")
	s_PosEvent._SetFld("IssueCode", issueCode)
	s_PosEvent._SetFld("IssueName", issueName)
	s_PosEvent._SetFld("Quantity", showFormat(quantity,2))
	s_PosEvent._SetFld("AvlQuantity", showFormat(avlQuantity,2))
	--s_PosEvent._SetFld("ForbidPosition", showFormat(ForbidPosition,2))
	s_PosEvent._SetFld("ForbidPosition", ForbidPosition)
	s_PosEvent._SetFld("WorkingQuantity", 0)
	s_PosEvent._SetFld("Cost", 0)
	s_PosEvent._SetFld("PL", 0)
	s_PosEvent._SetFld("CumulationPL", 0)
	s_PosEvent._SetFld("CumulationAdjustPL", 0)
	s_PosEvent._SetFld("CumulationDividend", 0)
	s_PosEvent._SetFld("AveragePrice", 0)
	s_PosEvent._SetFld("LastPrice", 0)
	s_PosEvent._SetFld("ValuationPL", 0)
	s_PosEvent._SetFld("PLRatio", 0)
	s_PosEvent._SetFld("MarketValue", 0)
	s_PosEvent._SetFld("MarketName","" )
	s_PosEvent._SetFld("BAMapID", bAMapID)
	s_PosEvent._SetFld("BASubID", bASubID)
	local reserveString=sys_format("融券回购:利率[%.2f%%]预估利息[%.2f]",avgPrice,sumInterest)
	s_PosEvent._SetFld("ReserveString", reserveString)
	_SendEventToClient(s_PosEvent,sessionID);
end
function GetS_SingleOrderQuantity()
	gS_SingleOrderQuantity=1000000	
	gSingleOrderQuantity=0
	gSingleOrderQuantityCurUser=0
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'S_SingleOrderQuantity%s' or VariableName='S_SingleOrderQuantity'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetS_SingleOrderQuantity", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	if gSingleOrderQuantityCurUser and gSingleOrderQuantityCurUser~=0 then
		if gSingleOrderQuantityCurUser<1000000 then
			gS_SingleOrderQuantity=gSingleOrderQuantityCurUser
		end 
	else
		if gSingleOrderQuantity and gSingleOrderQuantity~=0 then
			if gSingleOrderQuantity<1000000 then
				gS_SingleOrderQuantity=gSingleOrderQuantity
			end 
		end
	end
	gS_SingleOrderQuantity = 100*sys_floor(gS_SingleOrderQuantity/100)
end
_OnCommonData(dataName = "GetS_SingleOrderQuantity", DTSGlobalVariable evt)
	_WriteAplLog("GetS_SingleOrderQuantity")
	local currentUserID = _GetDealerID()
	local variableName = evt.getVariableName()
	if sys_find(variableName,currentUserID,1)~=nil then
		gSingleOrderQuantityCurUser = evt.getVariableValue()
		gSingleOrderQuantityCurUser=gSingleOrderQuantityCurUser.getNumberValue()
	else
		gSingleOrderQuantity = evt.getVariableValue()
		gSingleOrderQuantity=gSingleOrderQuantity.getNumberValue()
	end
	local log = sys_format("GetS_SingleOrderQuantity : %s ,CurUser : %s" ,gSingleOrderQuantity,gSingleOrderQuantityCurUser)
	_WriteAplLog(log)
_End
function GetFundJournalShowMode()
	gFundJournalShowMode = ""
	gFundJournalShowModeCurUser=""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'FundJournalShowMode%s' or VariableName='FundJournalShowMode'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetFundJournalShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end
_OnCommonData(dataName = "GetFundJournalShowMode", DTSGlobalVariable evt)
	_WriteAplLog("GetFundJournalShowMode")
	local currentUserID = _GetDealerID()
	local variableName = evt.getVariableName()
	if sys_find(variableName,currentUserID,1)~=nil then
		gFundJournalShowModeCurUser = evt.getVariableValue()
	else
		gFundJournalShowMode = evt.getVariableValue()
	end
	local log = sys_format("FundJournalShowMode : %s ,CurUser : %s" ,gFundJournalShowMode,gFundJournalShowModeCurUser)
	_WriteAplLog(log)
_End

function GetHisFundShowMode()
	gHisFundShowMode = ""
	gHisFundShowModeCurUser=""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'HisFundShowMode%s' or VariableName='HisFundShowMode'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetHisFundShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end

_OnCommonData(dataName = "GetHisFundShowMode", DTSGlobalVariable evt)
	_WriteAplLog("GetHisFundShowMode")
	local currentUserID = _GetDealerID()
	local variableName = evt.getVariableName()
	if sys_find(variableName,currentUserID,1)~=nil then
		gHisFundShowModeCurUser = evt.getVariableValue()
	else
		gHisFundShowMode = evt.getVariableValue()
	end
	local log = sys_format("HisFundShowMode : %s ,CurUser : %s" ,gHisFundShowMode,gHisFundShowModeCurUser)
	_WriteAplLog(log)
_End

--发送证券树结构到界面
function sendS_Tree(sessionID)
	GetFundJournalShowMode()
	GetLogsShowMode()
	GetHisFundShowMode()
	GetAlertShowMode()
	local RoleID = "other"
	local currentUserID= _GetDealerID()
	if gtUserRole[currentUserID] then
		RoleID=gtUserRole[currentUserID].RoleID;	
	end

	local log = sys_format("RoleID :%s",RoleID)
	_WriteAplLog(log)
	local DTSEvent evt = _CreateEventObject("S_TreeEvent")
	evt._SetFld("Item1", "买入(F1)")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/buy.png")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	evt._SetFld("Item1", "卖出(F2)")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/sell.png")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	evt._SetFld("Item1", "撤单(F4)")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/cancelOrder.ico")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	if ((not gHideSFJY or RoleID~=gRole_Trader) and gHideSFJYCurUser=="") or gHideSFJYCurUser=="1" then
		evt._SetFld("Item1", "算法交易")
		evt._SetFld("Item2", "")
		evt._SetFld("Item3", "")
		evt._SetFld("Icon", "Images/multiOrder.ico")
		if sessionID=="All" then
			_SendToClients(evt)
		else
			_SendEventToClient(evt,sessionID);
		end 
	end
	evt._SetFld("Item1", "组合维护")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/multiOrder.ico")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "查询资产")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/queryAssets.png")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "当日委托")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "当日成交")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	if ((gFundJournalShowMode~="1" or RoleID ~= gRole_Trader) and gFundJournalShowModeCurUser=="") or gFundJournalShowModeCurUser=="1" then	--gFundJournalShowMode为1时交易员不显示资金流水
		_WriteAplLog("send FundJournal")
		evt._SetFld("Item1", "查询")
		evt._SetFld("Item2", "资金流水")
		evt._SetFld("Item3", "")
		evt._SetFld("Icon", "Images/fundJournal.ico")
		if sessionID=="All" then
			_SendToClients(evt)
		else
			_SendEventToClient(evt,sessionID);
		end 
	end

	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "历史委托")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "历史成交")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
	
	if ((gHisFundShowMode~="1" or RoleID ~= gRole_Trader) and gHisFundShowModeCurUser=="") or gHisFundShowModeCurUser=="1" then
		evt._SetFld("Item1", "查询")
		evt._SetFld("Item2", "历史资产")
		evt._SetFld("Item3", "")
		evt._SetFld("Icon", "Images/queryAssets.png")
		if sessionID=="All" then
			_SendToClients(evt)
		else
			_SendEventToClient(evt,sessionID);
		end 
	end 
	
	if ((gFundJournalShowMode~="1" or RoleID ~= gRole_Trader) and gFundJournalShowModeCurUser=="") or gFundJournalShowModeCurUser=="1" then
		_WriteAplLog("send HisFundJournal")
		evt._SetFld("Item1", "查询")
		evt._SetFld("Item2", "历史资金流水")
		evt._SetFld("Item3", "")
		evt._SetFld("Icon", "Images/hisFundJournal.ico")
		if sessionID=="All" then
			_SendToClients(evt)
		else
			_SendEventToClient(evt,sessionID);
		end 
	end
	
	if (gShowAlert == "1" and gShowAlertCurUser=="") or gShowAlertCurUser =="1" then
		evt._SetFld("Item1", "查询")
		evt._SetFld("Item2", "当日触警")
		evt._SetFld("Item3", "")
		evt._SetFld("Icon", "Images/query.png")
		if sessionID=="All" then
			_SendToClients(evt)
		else
			_SendEventToClient(evt,sessionID);
		end 
		
		evt._SetFld("Item1", "查询")
		evt._SetFld("Item2", "历史触警")
		evt._SetFld("Item3", "")
		evt._SetFld("Icon", "Images/query.png")
		if sessionID=="All" then
			_SendToClients(evt)
		else
			_SendEventToClient(evt,sessionID);
		end 
	end
    
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "交割单")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
--	_SendToClients(evt)
	if ((gLogsShowMode~="1" or RoleID ~= gRole_Trader) and gLogsShowModeCurUser=="") or gLogsShowModeCurUser=="1" then	--gLogsShowMode为1时交易员不显示日志,gLogsShowModeCurUser为0时不显示
		_WriteAplLog("send Logs")
		evt._SetFld("Item1", "查询")
		evt._SetFld("Item2", "日志")
		evt._SetFld("Item3", "")
		evt._SetFld("Icon", "Images/log.ico")
		if sessionID=="All" then
			_SendToClients(evt)
		else
			_SendEventToClient(evt,sessionID);
		end 
	end
	evt._SetFld("Item1", "快捷键设置")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/otheroptions.ico")
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end 
end
_DefineEventObject ReQuestTree _AS _Input
	_SetDataType(_EventOtherType)
_End
_OnEventDefined(ReQuestTree evt, sessionID)
	local log=sys_format("ReQuestTree:%s",sessionID)
	_WriteAplLog(log)
	sendS_Tree(sessionID)
_End
--发送期货树结构到界面
function sendF_Tree()
	local DTSEvent evt = _CreateEventObject("F_TreeEvent")
	evt._SetFld("Item1", "交易(F1)")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/buy.png")
	_SendToClients(evt)
	evt._SetFld("Item1", "撤单(F4)")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/cancelOrder.ico")
	_SendToClients(evt)
	evt._SetFld("Item1", "算法交易")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/multiOrder.ico")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "查询资产")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/queryAssets.png")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "当日委托")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "当日成交")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "历史委托")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "历史成交")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "资金流水")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/fundJournal.ico")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "历史资金流水")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/hisFundJournal.ico")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "交割单")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/query.png")
	_SendToClients(evt)
	evt._SetFld("Item1", "查询")
	evt._SetFld("Item2", "日志")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/log.ico")
	_SendToClients(evt)
	evt._SetFld("Item1", "快捷键设置")
	evt._SetFld("Item2", "")
	evt._SetFld("Item3", "")
	evt._SetFld("Icon", "Images/otheroptions.ico")
	_SendToClients(evt)
end

--发送初始化orderType列表，只有限价委托选项
function sendInitialOrderTypeList()
	local DTSEvent orderInfoEvt = _CreateEventObject("OrderTypeInfoEvent")
	orderInfoEvt._SetFld("OrderType", ":限价委托;")
	_SendToClients(orderInfoEvt)
end

--忽略大小写
function BigSmall(IssueCode)
	local temptable = {}
	IssueCode = sys_upper(IssueCode)
	local IssueMarket  = _PosIssueMarketTable[IssueCode]
	if not IssueMarket or IssueMarket == "" or IssueMarket == "0" then
		IssueCode = sys_lower(IssueCode)
		IssueMarket  = _PosIssueMarketTable[IssueCode]
		if not IssueMarket or IssueMarket == "" or IssueMarket == "0" then
			return "error"
		end
	end
	temptable["IssueCode"] = IssueCode
	temptable["MarketCode"] = IssueMarket
	return temptable
end

--监听实时行情数据
_OnEventPrice(_PriceName = "addIssuePrice", {} , DTSPrice price)
	local issueCode = price.getIssueCode()
	local formatStr = getPriceFormat(issueCode)
	local dpPrice = {}
	--合约代码
	dpPrice.issueCode = issueCode

	--合约名称
	local issueName = _PosIssueNameTable[issueCode]
	dpPrice.issueName = issueName

	--市场号
	local marketCode = _PosIssueMarketTable[issueCode]
	dpPrice.marketCode = marketCode

	--市场名
	local marketName = gtMarketNameTable[marketCode]
	dpPrice.marketName = marketName

	--最新价
	local ftLastPrice = ""
	local lastPrice = price.getEstLastPrice();
	if lastPrice ~= "" then
		ftLastPrice = sys_format(formatStr, lastPrice)
	else
		lastPrice = price.getLastPrice();
		if lastPrice ~= "" then
			ftLastPrice = sys_format(formatStr, lastPrice)
		else
			ftLastPrice = "-"
                end
	end
	dpPrice.lastPrice = ftLastPrice

	--除权昨收
	local ftAdjustedLNC = ""
	local adjustedLNC = price.getAdjustedLNC();
	if adjustedLNC ~= "" then
		ftAdjustedLNC = sys_format(formatStr, adjustedLNC)
	else
		ftAdjustedLNC = "-"
	end
	dpPrice.adjLNC = ftAdjustedLNC

	 --买1价
	local ftBidPrice_1 = ""
	local bidPrice_1 = price.getBidPrice_1();
	if bidPrice_1 ~= "" then
		ftBidPrice_1 = sys_format(formatStr, bidPrice_1);
	else
		ftBidPrice_1 = "-"
	end
	dpPrice.bidPrice_1 = ftBidPrice_1

	--买2价
	local ftBidPrice_2 = ""
	local bidPrice_2 = price.getBidPrice_2();
	if bidPrice_2 ~= "" then
		ftBidPrice_2 = sys_format(formatStr, bidPrice_2);
	else
		ftBidPrice_2 = "-"
	end
	dpPrice.bidPrice_2 = ftBidPrice_2

	--买3价
	local ftBidPrice_3 = ""
	local bidPrice_3 = price.getBidPrice_3();
	if bidPrice_3 ~= "" then
		ftBidPrice_3 = sys_format(formatStr, bidPrice_3);
	else
		ftBidPrice_3 = "-"
	end
	dpPrice.bidPrice_3 = ftBidPrice_3

	--买4价
	local ftBidPrice_4 = ""
	local bidPrice_4 = price.getBidPrice_4();
	if bidPrice_4 ~= "" then
		ftBidPrice_4 = sys_format(formatStr, bidPrice_4);
	else
		ftBidPrice_4 = "-"
	end
	dpPrice.bidPrice_4 = ftBidPrice_4

	--买5价
	local ftBidPrice_5 = ""
	local bidPrice_5 = price.getBidPrice_5();
	if bidPrice_5 ~= "" then
		ftBidPrice_5 = sys_format(formatStr, bidPrice_5);
	else
		ftBidPrice_5 = "-"
	end
	dpPrice.bidPrice_5 = ftBidPrice_5

	--买1量
	local ftBidQty_1 = ""
	local bidQty_1 = price.getBidQty_1();
	if bidQty_1 ~= "" then
		ftBidQty_1 = sys_format("%d", bidQty_1)
	else
		ftBidQty_1 = "-"
	end
	dpPrice.bidQty_1 = ftBidQty_1

	--买2量
	local ftBidQty_2 = ""
	local bidQty_2 = price.getBidQty_2();
	if bidQty_2 ~= "" then
		ftBidQty_2 = sys_format("%d", bidQty_2)
	else
		ftBidQty_2 = "-"
	end
	dpPrice.bidQty_2 = ftBidQty_2

	--买3量
	local ftBidQty_3 = ""
	local bidQty_3 = price.getBidQty_3();
	if bidQty_3 ~= "" then
		ftBidQty_3 = sys_format("%d", bidQty_3)
	else
		ftBidQty_3 = "-"
	end
	dpPrice.bidQty_3 = ftBidQty_3

	--买4量
	local ftBidQty_4 = ""
	local bidQty_4 = price.getBidQty_4();
	if bidQty_4 ~= "" then
		ftBidQty_4 = sys_format("%d", bidQty_4)
	else
		ftBidQty_4 = "-"
	end
	dpPrice.bidQty_4 = ftBidQty_4

	--买5量
	local ftBidQty_5 = ""
	local bidQty_5 = price.getBidQty_5();
	if bidQty_5 ~= "" then
		ftBidQty_5 = sys_format("%d", bidQty_5)
	else
		ftBidQty_5 = "-"
	end
	dpPrice.bidQty_5 = ftBidQty_5

	--卖1价
	local ftAskPrice_1 = ""
	local askPrice_1  = price.getAskPrice_1();
	if askPrice_1 ~= "" then
		ftAskPrice_1 = sys_format(formatStr, askPrice_1);
	else
		ftAskPrice_1 = "-"
	end
	dpPrice.askPrice_1 = ftAskPrice_1

	--卖2价
	local ftAskPrice_2 = ""
	local askPrice_2  = price.getAskPrice_2();
	if askPrice_2 ~= "" then
		ftAskPrice_2 = sys_format(formatStr, askPrice_2);
	else
		ftAskPrice_2 = "-"
	end
	dpPrice.askPrice_2 = ftAskPrice_2

	--卖3价
	local ftAskPrice_3 = ""
	local askPrice_3  = price.getAskPrice_3();
	if askPrice_3 ~= "" then
		ftAskPrice_3 = sys_format(formatStr, askPrice_3);
	else
		ftAskPrice_3 = "-"
	end
	dpPrice.askPrice_3 = ftAskPrice_3

	--卖4价
	local ftAskPrice_4 = ""
	local askPrice_4  = price.getAskPrice_4();
	if askPrice_4 ~= "" then
		ftAskPrice_4 = sys_format(formatStr, askPrice_4);
	else
		ftAskPrice_4 = "-"
	end
	dpPrice.askPrice_4 = ftAskPrice_4

	--卖5价
	local ftAskPrice_5 = ""
	local askPrice_5  = price.getAskPrice_5();
	if askPrice_5 ~= "" then
		ftAskPrice_5 = sys_format(formatStr, askPrice_5);
	else
		ftAskPrice_5 = "-"
	end
	dpPrice.askPrice_5 = ftAskPrice_5

	--卖1量
	local ftAskQty_1 = ""
	local askQty_1 = price.getAskQty_1();
	if askQty_1 ~= "" then
		ftAskQty_1 = sys_format("%d", askQty_1)
	else
		ftAskQty_1 = "-"
	end
	dpPrice.askQty_1 = ftAskQty_1

	--卖2量
	local ftAskQty_2 = ""
	local askQty_2 = price.getAskQty_2();
	if askQty_2 ~= "" then
		ftAskQty_2 = sys_format("%d", askQty_2)
	else
		ftAskQty_2 = "-"
	end
	dpPrice.askQty_2 = ftAskQty_2

	--卖3量
	local ftAskQty_3 = ""
	local askQty_3 = price.getAskQty_3();
	if askQty_3 ~= "" then
		ftAskQty_3 = sys_format("%d", askQty_3)
	else
		ftAskQty_3 = "-"
	end
	dpPrice.askQty_3 = ftAskQty_3

	--卖4量
	local ftAskQty_4 = ""
	local askQty_4 = price.getAskQty_4();
	if askQty_4 ~= "" then
		ftAskQty_4 = sys_format("%d", askQty_4)
	else
		ftAskQty_4 = "-"
	end
	dpPrice.askQty_4 = ftAskQty_4

	--卖5量
	local ftAskQty_5 = ""
	local askQty_5 = price.getAskQty_5();
	if askQty_5 ~= "" then
		ftAskQty_5 = sys_format("%d", askQty_5)
	else
		ftAskQty_5 = "-"
	end
	dpPrice.askQty_5 = ftAskQty_5

	--成交量
	local ftVolume = ""
	local volume = price.getVolume();
	if volume ~= "" then
		ftVolume = sys_format("%d", volume)
	else
		ftVolume = "-"
	end
	dpPrice.volume = ftVolume

	--现量
	local ftLastVolume = ""
	local lastVolume = price.getLastVolume();
	if lastVolume ~= "" then
		ftLastVolume = sys_format("%d", lastVolume)
	else
		ftLastVolume = "-"
	end
	dpPrice.lastVolume = ftLastVolume

	--最高
	local ftHighAMPrice = ""
	local highAMPrice = price.getHighAMPrice();
	if highAMPrice ~= "" then
		ftHighAMPrice = sys_format(formatStr, highAMPrice)
	else
		ftHighAMPrice = "-"
	end
	dpPrice.highAMPrice = ftHighAMPrice

	--最低
	local ftLowAMPrice = ""
	local lowAMPrice = price.getLowAMPrice();
	if lowAMPrice ~="" then
		ftLowAMPrice = sys_format(formatStr, lowAMPrice)
	else
		ftLowAMPrice = "-"
	end
	dpPrice.lowAMPrice = ftLowAMPrice

	--涨停价
	local ftUpperLimitPrice = ""
	local upperLimitPrice = price.getUpperLimitPrice()
	if upperLimitPrice ~= "" then
		ftUpperLimitPrice =  sys_format(formatStr, upperLimitPrice)
	else
		ftUpperLimitPrice = "-"
	end
	dpPrice.upperLimitPrice  = ftUpperLimitPrice

	--跌停价
	local ftLowerLimitPrice = ""
	local lowerLimitPrice = price.getLowerLimitPrice()
	if lowerLimitPrice ~= "" then
		ftLowerLimitPrice =  sys_format(formatStr, lowerLimitPrice)
	else
		ftLowerLimitPrice = "-"
	end
	dpPrice.lowerLimitPrice  = ftLowerLimitPrice
	gtPriceTable[issueCode] = dpPrice;
	
	for sessionID,v in pairs(gtSessionTable) do
		if v.CurIssueCode==issueCode then 
			PriceServer(sessionID,issueCode)
		end
	end
_End

--提供行情服务
--下单界面的五档行情从该服务接收
--提供行情服务
--下单界面的五档行情从该服务接收
function PriceServer(sessionID,issueCode)
	if not gtSessionTable[sessionID] then
		return false
	end
	if issueCode~=gtSessionTable[sessionID].CurIssueCode and not gCurIssueCodeTable[issueCode] then
		return false
	end
	local price = gtPriceTable[issueCode]
	if price then
		local issueCode = price.issueCode
		local issueName = price.issueName
		local lastPrice = price.lastPrice
		local lastVolume = price.lastVolume
		local adjLNC = price.adjLNC
		local upperLimitPrice = price.upperLimitPrice
		local lowerLimitPrice = price.lowerLimitPrice
		local bidPrice_1 = price.bidPrice_1
		local bidPrice_2 = price.bidPrice_2
		local bidPrice_3 = price.bidPrice_3
		local bidPrice_4 = price.bidPrice_4
		local bidPrice_5 = price.bidPrice_5
		local bidPrice_6 = price.bidPrice_6
		local bidPrice_7 = price.bidPrice_7
		local bidPrice_8 = price.bidPrice_8
		local bidPrice_9 = price.bidPrice_9
		local bidPrice_10 = price.bidPrice_10
		local bidQty_1 = price.bidQty_1
		local bidQty_2 = price.bidQty_2
		local bidQty_3 = price.bidQty_3
		local bidQty_4 = price.bidQty_4
		local bidQty_5 = price.bidQty_5
		local bidQty_6 = price.bidQty_6
		local bidQty_7 = price.bidQty_7
		local bidQty_8 = price.bidQty_8
		local bidQty_9 = price.bidQty_9
		local bidQty_10 = price.bidQty_10
		local askPrice_1 = price.askPrice_1
		local askPrice_2 = price.askPrice_2
		local askPrice_3 = price.askPrice_3
		local askPrice_4 = price.askPrice_4
		local askPrice_5 = price.askPrice_5
		local askPrice_6 = price.askPrice_6
		local askPrice_7 = price.askPrice_7
		local askPrice_8 = price.askPrice_8
		local askPrice_9 = price.askPrice_9
		local askPrice_10 = price.askPrice_10
		local askQty_1 = price.askQty_1
		local askQty_2 = price.askQty_2
		local askQty_3 = price.askQty_3
		local askQty_4 = price.askQty_4
		local askQty_5 = price.askQty_5
		local askQty_6 = price.askQty_6
		local askQty_7 = price.askQty_7
		local askQty_8 = price.askQty_8
		local askQty_9 = price.askQty_9
		local askQty_10 = price.askQty_10

		local DTSEvent priceEvent = _CreateEventObject("PriceServerEvent")
		priceEvent._SetFld("IssueCode", issueCode)
		priceEvent._SetFld("IssueName", issueName)
		priceEvent._SetFld("LastPrice", lastPrice)
		priceEvent._SetFld("LastVolume", lastVolume)
		priceEvent._SetFld("AdjustedLNC", adjLNC)
		priceEvent._SetFld("UpLimitPrice", upperLimitPrice)
		priceEvent._SetFld("LowLimitPrice", lowerLimitPrice)
		priceEvent._SetFld("BidPrice1", bidPrice_1)
		priceEvent._SetFld("BidPrice2", bidPrice_2)
		priceEvent._SetFld("BidPrice3", bidPrice_3)
		priceEvent._SetFld("BidPrice4", bidPrice_4)
		priceEvent._SetFld("BidPrice5", bidPrice_5)
		priceEvent._SetFld("BidPrice6", bidPrice_6)
		priceEvent._SetFld("BidPrice7", bidPrice_7)
		priceEvent._SetFld("BidPrice8", bidPrice_8)
		priceEvent._SetFld("BidPrice9", bidPrice_9)
		priceEvent._SetFld("BidPrice10", bidPrice_10)
		priceEvent._SetFld("AskPrice1", askPrice_1)
		priceEvent._SetFld("AskPrice2", askPrice_2)
		priceEvent._SetFld("AskPrice3", askPrice_3)
		priceEvent._SetFld("AskPrice4", askPrice_4)
		priceEvent._SetFld("AskPrice5", askPrice_5)
		priceEvent._SetFld("AskPrice6", askPrice_6)
		priceEvent._SetFld("AskPrice7", askPrice_7)
		priceEvent._SetFld("AskPrice8", askPrice_8)
		priceEvent._SetFld("AskPrice9", askPrice_9)
		priceEvent._SetFld("AskPrice10", askPrice_10)
		priceEvent._SetFld("BidQty1", bidQty_1)
		priceEvent._SetFld("BidQty2", bidQty_2)
		priceEvent._SetFld("BidQty3", bidQty_3)
		priceEvent._SetFld("BidQty4", bidQty_4)
		priceEvent._SetFld("BidQty5", bidQty_5)
		priceEvent._SetFld("BidQty6", bidQty_6)
		priceEvent._SetFld("BidQty7", bidQty_7)
		priceEvent._SetFld("BidQty8", bidQty_8)
		priceEvent._SetFld("BidQty9", bidQty_9)
		priceEvent._SetFld("BidQty10", bidQty_10)
		priceEvent._SetFld("AskQty1", askQty_1)
		priceEvent._SetFld("AskQty2", askQty_2)
		priceEvent._SetFld("AskQty3", askQty_3)
		priceEvent._SetFld("AskQty4", askQty_4)
		priceEvent._SetFld("AskQty5", askQty_5)
		priceEvent._SetFld("AskQty6", askQty_6)
		priceEvent._SetFld("AskQty7", askQty_7)
		priceEvent._SetFld("AskQty8", askQty_8)
		priceEvent._SetFld("AskQty9", askQty_9)
		priceEvent._SetFld("AskQty10", askQty_10)

		local marketCode = _PosIssueMarketTable[issueCode]
		priceEvent._SetFld("MarketCode", marketCode)
		local ContractSize = _PosIssueContractSizeTable[issueCode]
		priceEvent._SetFld("ContractSize", ContractSize)

		local underlyingIssueCode = _PosIssueUnderlyingTable[issueCode]
		local strBailRatio = "-"
		local temAvailableFund = 0
		local temOpenAvailableQty = 0;
		local temCloseAvailableQty = 0;
			
		if gtSessionTable[sessionID].SelectedBAMapID == "全部" then
			if gtSessionTable[sessionID].PositionTable then 
				if gtSessionTable[sessionID].PositionTable[issueCode] then 
					temOpenAvailableQty = sys_format("%d",gtSessionTable[sessionID].PositionTable[issueCode].AvlQuantity);
				end
			end
		elseif gtSessionTable[sessionID].SelectedBAMapID then
			local baMapID=gtSessionTable[sessionID].SelectedBAMapID
			local posKey=baMapID..".".."3".."."..issueCode
			if _PosPositionTable[posKey] then 
				temOpenAvailableQty = sys_format("%d",_PosPositionTable[posKey].AvlQuantity);
			end 
		end
		if gtSessionTable[sessionID].AvailableFund then
			temAvailableFund=gtSessionTable[sessionID].AvailableFund
		end
		temAvailableFund = sys_format("%.2f",temAvailableFund);
		temOpenAvailableQty = sys_format("%d",temOpenAvailableQty);
		temCloseAvailableQty = sys_format("%d", temCloseAvailableQty)
		if (sys_sub(issueName,1,2) == "R-" or sys_sub(issueName,1,2) == "GC") then
			local faceValue = _PosIssueFaceValueTable[issueCode]
			if faceValue then
				temCloseAvailableQty=sys_floor(temAvailableFund/faceValue)
				temCloseAvailableQty = sys_format("%d", temCloseAvailableQty)
			end
		end
		priceEvent._SetFld("AvlFund", temAvailableFund)
		priceEvent._SetFld("OpenAvailableQty", temOpenAvailableQty)
		priceEvent._SetFld("CloseAvailableQty", temCloseAvailableQty)
		priceEvent._SetFld("BailRatio", strBailRatio)
		_SendEventToClient(priceEvent,sessionID)
	elseif gtInventoryHeaderTable[issueCode] and gtInventoryComponentTable[issueCode] then
		onInventoryprice(sessionID,issueCode)
	else
		local issueName = _PosIssueNameTable[issueCode]
		local DTSEvent priceEvent = _CreateEventObject("PriceServerEvent")
		priceEvent._SetFld("IssueCode", issueCode)
		priceEvent._SetFld("IssueName", issueName)
		priceEvent._SetFld("LastPrice", "-")
		priceEvent._SetFld("LastVolume", "-")
		priceEvent._SetFld("AdjustedLNC", "-")
		priceEvent._SetFld("UpLimitPrice", "-")
		priceEvent._SetFld("LowLimitPrice", "-")
		priceEvent._SetFld("BidPrice1", "-")
		priceEvent._SetFld("BidPrice2", "-")
		priceEvent._SetFld("BidPrice3", "-")
		priceEvent._SetFld("BidPrice4", "-")
		priceEvent._SetFld("BidPrice5", "-")
		priceEvent._SetFld("BidPrice6", "-")
		priceEvent._SetFld("BidPrice7", "-")
		priceEvent._SetFld("BidPrice8", "-")
		priceEvent._SetFld("BidPrice9", "-")
		priceEvent._SetFld("BidPrice10", "-")
		priceEvent._SetFld("AskPrice1", "-")
		priceEvent._SetFld("AskPrice2", "-")
		priceEvent._SetFld("AskPrice3", "-")
		priceEvent._SetFld("AskPrice4", "-")
		priceEvent._SetFld("AskPrice5", "-")
		priceEvent._SetFld("AskPrice6", "-")
		priceEvent._SetFld("AskPrice7", "-")
		priceEvent._SetFld("AskPrice8", "-")
		priceEvent._SetFld("AskPrice9", "-")
		priceEvent._SetFld("AskPrice10", "-")
		priceEvent._SetFld("BidQty1", "-")
		priceEvent._SetFld("BidQty2", "-")
		priceEvent._SetFld("BidQty3", "-")
		priceEvent._SetFld("BidQty4", "-")
		priceEvent._SetFld("BidQty5", "-")
		priceEvent._SetFld("BidQty6", "-")
		priceEvent._SetFld("BidQty7", "-")
		priceEvent._SetFld("BidQty8", "-")
		priceEvent._SetFld("BidQty9", "-")
		priceEvent._SetFld("BidQty10", "-")
		priceEvent._SetFld("AskQty1", "-")
		priceEvent._SetFld("AskQty2", "-")
		priceEvent._SetFld("AskQty3", "-")
		priceEvent._SetFld("AskQty4", "-")
		priceEvent._SetFld("AskQty5", "-")
		priceEvent._SetFld("AskQty6", "-")
		priceEvent._SetFld("AskQty7", "-")
		priceEvent._SetFld("AskQty8", "-")
		priceEvent._SetFld("AskQty9", "-")
		priceEvent._SetFld("AskQty10", "-")
		priceEvent._SetFld("BailRatio", "-")
		priceEvent._SetFld("OpenAvailableQty", 0)
		priceEvent._SetFld("CloseAvailableQty", 0)
		_SendEventToClient(priceEvent,sessionID)
	end
end
--得到价格格式字符串
function getPriceFormat(issueCode)
	local priceExponent = _PosIssueExponentTable[issueCode]
	if not priceExponent then
		priceExponent = -3
	end
	local priceExponentabs = sys_abs(priceExponent)
	local formatStr = sys_format("%%.%df", priceExponentabs)
	return formatStr
end

function getPriceFormat2(issueCode,i)
	local priceExponent = _PosIssueExponentTable[issueCode]
	if not priceExponent then
		priceExponent = -3
	else
		priceExponent=priceExponent-i
	end
	local priceExponentabs = sys_abs(priceExponent)
	local formatStr = sys_format("%%.%df", priceExponentabs)
	return formatStr
end

--刷新账户资金信息
function RefreshFundInfo(sessionID,reason)
	if not gtSessionTable[sessionID] then
		return 
	end
	if not gtSessionTable[sessionID].CurBAMapIDTable then
		return 
	end
	local sumAccountType = "S" --账户类型
	local sumLastFund = 0     --昨日资金
	local sumLastAssetValue=0 --昨日权益

	local sumAvlFund = 0 -- 可用资金
	local sumMarketValue = 0 --市值
	local sumAssetValue = 0  --权益	
	
	local sumFund = 0; --资金余额
	local sumOrderFund = 0; --开仓冻结资金
	local sumForbidFund = 0; --冻结资金
	local sumMargin=0
	local sumTransferIn=0
	local sumTransferOut=0
	local sumFare=0
	local sumRealizedPL=0
	local sumRealizedPLM2D=0
	local sumValuationPL=0
	local sumValuationPLM2D=0
		
	local sumMTBalance = 0
	local sumEquityFund = 0
	local beginDate="-"
	local endDate="-"
	local sumLossFund4Alert = 0
	local sumLossFund4Close = 0
	local sumInitialFund = 0
	
	local sumResistance2Risk = 0
	local sumAssetValue4Customer = 0
	local sumStockValue = 0
	
	for baMapID, value in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
		local accountCode = _PosBAMapAccount[baMapID]
		if accountCode then 
			local forbidBuy = "0"
			if gtZGProductAccountTable[baMapID] then
				forbidBuy = gtZGProductAccountTable[baMapID].ForbidBuy
			end
			--市值
			local marketValue = 0
			--[[
			if reason=="order" then
				marketValue =_PosFundStatus[accountCode].Margin+_PosFundStatus[accountCode].ValuationPL
			else
				marketValue = GetMarketValue(baMapID,1)
			end
			]]--
			marketValue =_PosFundStatus[accountCode].Margin+_PosFundStatus[accountCode].ValuationPL
			sumMarketValue = sumMarketValue + marketValue
			if _PosFundStatus[accountCode] then
				local accountType = _PosFundStatus[accountCode].Type
				sumAccountType = accountType
				--资金余额(上一个交易日的可用资金)
				local lastFund = _PosFundStatus[accountCode]["LastFund"]
				sumLastFund = sumLastFund + lastFund
				
				local lastAssetValue = _PosFundStatus[accountCode]["LastAssetValue"] 
				sumLastAssetValue=sumLastAssetValue+lastAssetValue
			
				--可用资金
				if forbidBuy~="1" or gFund4ForbidBuyBAMapIDShowMode~="1" then	--没有设置限制买入的计算到可用资金，限制买入账号的可用资金不计算在内
					local avlFund = _PosFundStatus[accountCode]["AvlFund"]
					sumAvlFund = sumAvlFund + avlFund		
					local assetValue = _PosFundStatus[accountCode]["AssetValue"]
					sumAssetValue = sumAssetValue + assetValue
				end

				--当日转入资金
				local transferIn = _PosFundStatus[accountCode]["TransferIn"]
				sumTransferIn=sumTransferIn+transferIn
				--当日转出资金
				local transferOut = _PosFundStatus[accountCode]["TransferOut"]		
				sumTransferOut=sumTransferOut+transferOut
				
				--开仓冻结资金
				local orderFund = _PosFundStatus[accountCode]["OrderFund"]
				sumOrderFund = sumOrderFund + orderFund
				
				local ForbidFund = 0
				if gtZGProductAccountTable[baMapID] then
					ForbidFund = gtZGProductAccountTable[baMapID].ForbidFund or 0
				end
				sumForbidFund = sumForbidFund + ForbidFund
				local margin = _PosFundStatus[accountCode]["Margin"]
				sumMargin=sumMargin+margin
				--费用
				local fare = _PosFundStatus[accountCode]["Fare"]
				fare = fare.getNumberValue()
				sumFare=sumFare+fare
				
				local realizedPL = _PosFundStatus[accountCode]["RealizedPL"]
				sumRealizedPL=sumRealizedPL+realizedPL
				local realizedPLM2D = _PosFundStatus[accountCode]["RealizedPLM2D"]			
				sumRealizedPLM2D=sumRealizedPLM2D+realizedPLM2D
				local valuationPL = _PosFundStatus[accountCode]["ValuationPL"]
				sumValuationPL=sumValuationPL+valuationPL
				local valuationPLM2D = _PosFundStatus[accountCode]["ValuationPLM2D"]
				sumValuationPLM2D=sumValuationPLM2D+valuationPLM2D
					
				local mTBalance="-"
				local lossRatio4Alert = 0
				local lossRatio4Close = 0
				local lossFund4Alert = "-"
				local lossFund4Close = "-"
				local totalFund = 0
				if gtZGProductAccountTable[baMapID] then
					mTBalance=gtZGProductAccountTable[baMapID].MTBalance
					if mTBalance and mTBalance ~= "" and mTBalance ~= "-" then
						mTBalance = sys_format("%.2f",mTBalance);
					else
						mTBalance = "-"
					end
					if mTBalance == "-" then
						sumMTBalance = sumMTBalance + 0
					else
						sumMTBalance = sumMTBalance + mTBalance
					end
					beginDate=gtZGProductAccountTable[baMapID].BeginDate
					endDate=gtZGProductAccountTable[baMapID].EndDate
					if not beginDate or beginDate == "" or beginDate == " " then
						beginDate = "-"
					end
					if not endDate or endDate == "" or endDate == " " then
						endDate = "-"
					end
					lossRatio4Alert = gtZGProductAccountTable[baMapID].LossRatio4Alert or 0
					lossRatio4Alert = lossRatio4Alert.getNumberValue()
					lossRatio4Close = gtZGProductAccountTable[baMapID].LossRatio4Close or 0
					lossRatio4Close = lossRatio4Close.getNumberValue()

					local seniorFund = gtZGProductAccountTable[baMapID].SeniorFund or 0 --优先资金
					seniorFund = seniorFund.getNumberValue()
					local mezzFund = gtZGProductAccountTable[baMapID].MezzFund or 0	--分层资金
					mezzFund = mezzFund.getNumberValue()
					local equityFund = gtZGProductAccountTable[baMapID].EquityFund or 0	--劣后资金
					equityFund = equityFund.getNumberValue()

					--理财账户初始权益=优先+夹层+劣后
					if seniorFund and mezzFund and equityFund then
						totalFund = seniorFund + mezzFund + equityFund
					end
					sumInitialFund = sumInitialFund + totalFund

					if equityFund and equityFund ~= "" and equityFund ~= "-" then
						sumEquityFund = sumEquityFund + equityFund
					end
					
					lossFund4Alert = gtZGProductAccountTable[baMapID].LossFund4Alert
					if lossFund4Alert and lossFund4Alert ~= "" and lossFund4Alert ~= "-" then
						lossFund4Alert = sys_format("%.2f",lossFund4Alert);
					else
						lossFund4Alert = "-"
					end
					if lossFund4Alert == "-" then
						sumLossFund4Alert = sumLossFund4Alert + 0
					else
						sumLossFund4Alert = sumLossFund4Alert + lossFund4Alert
					end
					lossFund4Close = gtZGProductAccountTable[baMapID].LossFund4Close
					if lossFund4Close and lossFund4Close ~= "" and lossFund4Close ~= "-" then
						lossFund4Close = sys_format("%.2f",lossFund4Close);
					else
						lossFund4Close = "-"
					end
					if lossFund4Close == "-" then
						sumLossFund4Close = sumLossFund4Close  + 0
					else
						sumLossFund4Close = sumLossFund4Close  + lossFund4Close
					end
					--增加抗跌风险度
					local v=gtZGProductAccountTable[baMapID]
					local MTFund = 0
					if v.SeniorFund and v.SeniorFund~="" then
						MTFund=MTFund+v.SeniorFund
					end
					if v.MezzFund and v.MezzFund~="" then
						MTFund=MTFund+v.MezzFund
					end
					if MTFund~=0 then
						MTFund=sys_format("%.2f",MTFund)
					end
					local AssetValue = _PosFundStatus[accountCode].AssetValue
					AssetValue=sys_format("%.2f",AssetValue)
					local AssetValue4Customer=AssetValue-MTFund
					AssetValue4Customer=sys_format("%.2f",AssetValue4Customer)
					sumAssetValue4Customer = sumAssetValue4Customer + AssetValue4Customer
					local StockValue = 0
					local fund=_PosFundStatus[accountCode]
					for posKey, pos in pairs(_PosPositionTable) do
						if baMapID==pos.BAMapID then
							local quantity=pos.Quantity
							local issueCode=pos.IssueCode
							local marketValue=0
							if fund.Type== "S" then
								local contractSize = 1
								if _PosIssueContractSizeTable[issueCode] then
									contractSize = _PosIssueContractSizeTable[issueCode]
								end
								if _PosPriceTable[issueCode] then
									local lastPrice = _PosPriceTable[issueCode].LastPrice --最新价
									if lastPrice then
										marketValue=lastPrice*quantity*contractSize
									end
								end
							end
							StockValue=StockValue+marketValue
						end
					end
					
					local log = sys_format("市值计算：baMapID[%s],AssetValue4Customer[%s],StockValue[%s]",baMapID,AssetValue4Customer,StockValue)
					--_WriteAplLog(log)
					if StockValue ~= 0 then
						StockValue=sys_format("%.2f",StockValue)
						sumStockValue = sumStockValue + StockValue
					end
					
				end
			end
		end
	end
	
	if sumStockValue ~= 0 then--0
		sumResistance2Risk = 100*sumAssetValue4Customer/sumStockValue
		sumResistance2Risk=sys_format("%.2f",sumResistance2Risk)
	end
	
	gtSessionTable[sessionID].AvailableFund=sumAvlFund
	
	sumLastFund = sys_format("%.2f",sumLastFund);
	sumLastAssetValue = sys_format("%.2f",sumLastAssetValue);	
	sumOrderFund = sys_format("%.2f",sumOrderFund)
	sumForbidFund = sys_format("%.2f",sumForbidFund)
	sumAvlFund = sys_format("%.2f",sumAvlFund)
	sumMarketValue = sys_format("%.2f", sumMarketValue)
	sumAssetValue = sys_format("%.2f",sumAssetValue);	
	sumTransferIn = sys_format("%.2f", sumTransferIn)
	sumTransferOut = sys_format("%.2f",sumTransferOut);		
	sumMargin = sys_format("%.2f", sumMargin)
	sumFare = sys_format("%.2f",sumFare);
	sumRealizedPL = sys_format("%.2f", sumRealizedPL)
	sumRealizedPLM2D= sys_format("%.2f", sumRealizedPLM2D)
	sumValuationPL = sys_format("%.2f", sumValuationPL)
	sumValuationPLM2D = sys_format("%.2f", sumValuationPLM2D)	
	sumMTBalance = sys_format("%.2f", sumMTBalance)
	sumEquityFund = sys_format("%.2f", sumEquityFund) 
	sumLossFund4Alert = sys_format("%.2f", sumLossFund4Alert)
	sumLossFund4Close = sys_format("%.2f", sumLossFund4Close)
	sumInitialFund = sys_format("%.2f", sumInitialFund)
		
	local DTSEvent fundStatus = _CreateEventObject("FundInfo")
	fundStatus._SetFld("AccountType",sumAccountType)
	fundStatus._SetFld("LastFund",sumLastFund)
	fundStatus._SetFld("LastAssetValue",sumLastAssetValue)	
	fundStatus._SetFld("OrderFund",sumOrderFund)
	fundStatus._SetFld("ForbidFund",sumForbidFund)	
	fundStatus._SetFld("AvlFund",sumAvlFund)
	fundStatus._SetFld("MarketValue",sumMarketValue)
	fundStatus._SetFld("AssetValue",sumAssetValue)
	fundStatus._SetFld("Margin",sumMargin)
	fundStatus._SetFld("Fare",sumFare)	

	fundStatus._SetFld("RealizedPL",sumRealizedPL)
	fundStatus._SetFld("RealizedPLM2D",sumRealizedPLM2D)
	fundStatus._SetFld("ValuationPL",sumValuationPL)
	fundStatus._SetFld("ValuationPLM2D",sumValuationPLM2D)	
	
	fundStatus._SetFld("TransferIn",sumTransferIn)
	fundStatus._SetFld("TransferOut",sumTransferOut)				
	fundStatus._SetFld("MTBalance",sumMTBalance)
	fundStatus._SetFld("EquityFund",sumEquityFund)
	if gtSessionTable[sessionID].SelectedBAMapID == "全部" then
		fundStatus._SetFld("BeginDate","-")
		fundStatus._SetFld("EndDate","-")
	else
		fundStatus._SetFld("BeginDate",beginDate)
		fundStatus._SetFld("EndDate",endDate)
	end
	fundStatus._SetFld("LossFund4Alert",sumLossFund4Alert)
	fundStatus._SetFld("LossFund4Close",sumLossFund4Close)
	fundStatus._SetFld("InitialFund",sumInitialFund)
	fundStatus._SetFld("Resistance2Risk",sumResistance2Risk)
	_SendEventToClient(fundStatus,sessionID);
	
	--local fundlog = sys_format("sumAvlFund[%s],sumForbidFund[%s]",sumAvlFund,sumForbidFund)
	--_WriteAplLog(fundlog)
end

--刷新多账户下单单账户资金信息
function RefreshMultiFireFundInfo(sessionID,reason)
	local curMultiFireBaMapID="" 
	local curSelectedUserID=""
	if gtSessionTable[sessionID] then 
		curMultiFireBaMapID=gtSessionTable[sessionID].CurMultiFireBaMapID
		curSelectedUserID=gtSessionTable[sessionID].SelectedUserID
	end
	if curMultiFireBaMapID=="" or (not curMultiFireBaMapID) then
		return
	end
	local sumAvlFund = 0 -- 可用资金
	local sumMarketValue = 0 --市值
	local sumAssetValue = 0  --权益
	local sumAvlFundAll = 0 -- 可用资金汇总
	local sumMarketValueAll = 0 --市值汇总
	local sumAssetValueAll = 0  --权益汇总
	local allBaMapIDTable = {}
	
	--取得全部bamapid
	for bAMap,value in pairs(gtRunAccountTable) do
		if gtZGProductAccountTable[bAMap] then 
			local flag = true				
			if curSelectedUserID~="全部" then
				if gtPosUserBAMapTable[curSelectedUserID] then
					if not gtPosUserBAMapTable[curSelectedUserID][bAMap] then
						flag = false
					end
				else
					flag = false
				end
			end
			if flag then
				if _PosBAMapAccount[bAMap] then
					local accountCode = _PosBAMapAccount[bAMap]
					if _PosFundStatus[accountCode] then
						local accountCodeType = _PosFundStatus[accountCode].Type
						local tmpClientID = _PosFundStatus[accountCode].ClientID
						if accountCodeType == "S" and (not isDefaultAccount(bAMap)) then
							allBaMapIDTable[bAMap] = 1
						end
					end
				end
			end
		end
	end	
	for baMapID, value in pairs(allBaMapIDTable) do
		local forbidBuy = "0"
		if gtZGProductAccountTable[baMapID] then
			forbidBuy = gtZGProductAccountTable[baMapID].ForbidBuy
		end
		local accountCode = _PosBAMapAccount[baMapID]
		--市值
		local marketValue =0
		--[[
		if reason=="order" then
			if accountCode then
				if _PosFundStatus[accountCode] then
					marketValue =_PosFundStatus[accountCode].Margin+_PosFundStatus[accountCode].ValuationPL
				end
			end
		else
			marketValue = GetMarketValue(baMapID,1)
		end
		]]--
		marketValue =_PosFundStatus[accountCode].Margin+_PosFundStatus[accountCode].ValuationPL
		sumMarketValueAll = sumMarketValueAll + marketValue
		if baMapID == curMultiFireBaMapID then
			sumMarketValue = marketValue
		end
		if _PosFundStatus[accountCode] then
			--可用资金
			local avlFund = _PosFundStatus[accountCode]["AvlFund"]
			local assetValue = _PosFundStatus[accountCode]["AssetValue"]
			if forbidBuy~="1" or gFund4ForbidBuyBAMapIDShowMode~="1" then
				sumAvlFundAll = sumAvlFundAll + avlFund
				sumAssetValueAll = sumAssetValueAll + assetValue
			end
			if baMapID == curMultiFireBaMapID then
				if forbidBuy~="1" or gFund4ForbidBuyBAMapIDShowMode~="1" then
					sumAvlFund = avlFund
					sumAssetValue = assetValue
				end
			end
		end
	end
	
	sumAvlFund = sys_format("%.2f",sumAvlFund)
	sumMarketValue = sys_format("%.2f", sumMarketValue)
	sumAssetValue = sys_format("%.2f",sumAssetValue)
	sumAvlFundAll = sys_format("%.2f",sumAvlFundAll)
	sumMarketValueAll = sys_format("%.2f", sumMarketValueAll)
	sumAssetValueAll = sys_format("%.2f",sumAssetValueAll)
	
	local DTSEvent fundStatus = _CreateEventObject("MultiFundInfo")
	fundStatus._SetFld("BaMapID",curMultiFireBaMapID)
	fundStatus._SetFld("AvlFund",sumAvlFund)
	fundStatus._SetFld("MarketValue",sumMarketValue)
	fundStatus._SetFld("AssetValue",sumAssetValue)
	fundStatus._SetFld("AvlFundAll",sumAvlFundAll)
	fundStatus._SetFld("MarketValueAll",sumMarketValueAll)
	fundStatus._SetFld("AssetValueAll",sumAssetValueAll)
	_SendEventToClient(fundStatus,sessionID);
end

--计算市值
function GetMarketValue(baMapID,type)
	local marketValue = 0
	for posKey, pos in pairs(_PosPositionTable) do
		if pos.BAMapID == baMapID then
			local lastPrice--现价
			local issueCode = pos.IssueCode
			local quantity = pos.Quantity
			local priceInfo = _PosPriceTable[issueCode]
			if priceInfo then
				lastPrice = priceInfo.LastPrice
			end
			if lastPrice then
				local contractSize = 1
				if _PosIssueContractSizeTable[issueCode] then
					contractSize = _PosIssueContractSizeTable[issueCode]
				end
				if type == 1 then
					marketValue = marketValue + lastPrice * quantity * contractSize --市值=最新价*持仓量*合约乘数
				elseif type == 2 then	--主板市值
					if (sys_sub(issueCode,1,1) == "0" or sys_sub(issueCode,1,1) == "6") and sys_sub(issueCode,1,3) ~= "002" then
						marketValue = marketValue + lastPrice * quantity * contractSize --市值=最新价*持仓量*合约乘数
					end
				elseif type == 3 then
					if sys_sub(issueCode,1,1) == "3" then	--创业板市值
						marketValue = marketValue + lastPrice * quantity * contractSize --市值=最新价*持仓量*合约乘数
					end
				end
			end
		end
	end
	marketValue = sys_format("%.2f", marketValue)

	return marketValue
end

--获取交易类型
function GetMarginType(marketCode,bs, oc, creRed)
	local log = sys_format("GetMarginType, marketCode=[%s],bs=[%s], oc=[%s], creRed=[%s]",marketCode, bs, oc, creRed)
	_WriteAplLog(log)
	bs = bs.toString()
	oc = oc.getNumberValue()
	creRed = creRed.getNumberValue()

	local marginType = ""
	if bs == "1" and oc == 1 and creRed == 3 then
		marginType = "质押入库"
	elseif bs == "3" and oc == 0 and creRed == 3 then
		marginType = "质押出库"
	elseif bs == "3" and oc == 0 and creRed == 4 then
		marginType = "融资回购"
	elseif bs == "1" and oc == 0 and creRed == 5 then
		marginType = "融券回购"
	else
		if bs == "3" then
			if creRed == 0  then
				if oc == 0 then
					if marketCode == "1" or marketCode == "2" then
						marginType = "买入"
					elseif  marketCode == "3" or marketCode == "4" or marketCode == "5" or marketCode == "6" then
						marginType = "买开"
					end
				elseif oc == 1 then
					marginType = "买平"
				elseif oc == 2 then
					marginType = "买平"
				elseif oc == 3 then
					marginType = "买平"
				end
			end
		elseif bs == "1" then
			if creRed == 0  then
				if oc == 0 then
					marginType = "卖开"
				elseif oc == 1 then
					if marketCode == "1" or marketCode == "2" then
						marginType = "卖出"
					elseif  marketCode == "3" or marketCode == "4" or marketCode == "5" or marketCode == "6" then
						marginType = "卖平"
					end
				elseif oc == 2 then
					marginType = "卖平"
				elseif oc == 3 then
					marginType = "卖平"
				end
			end
		end
	end
	return marginType
end

--获取当前时间
function GetHMS()
	local DTSTime nowtime = _GetNowTime();
	local smtime = nowtime.asString("%H%M%S");
	return smtime
end

-----------------多账户下单-----------------
--多账户下单数据查询
_DefineEventObject MultiFireQueryData _AS _Input
	_DefFld("IssueCode", _String, 20)	--合约代码
	_DefFld("BuySell", _String, 1)			--买卖
	_DefFld("OpenClose", _Int, 1)			--开平
	_DefFld("PortID", _String, 48)
	_DefFld("Price", _String, 15)
	_DefFld("QuantityType", _String, 15)
	_DefFld("Quantity", _Number, 12)
	_DefFld("SelectedBAMapID", _String, 300)

_End
_OnEventDefined(MultiFireQueryData evt,sessionID)
	gCurSession=sessionID
	local curSelectedUserID=gtSessionTable[sessionID].SelectedUserID
	_WriteAplLog("================MultiFireQueryData=================")
	if gInitialized then
		local IssueCode = evt._GetFld("IssueCode")
		local OpenClose = evt._GetFld("OpenClose")
		local PortID = evt._GetFld("PortID")
		local BuySell = evt._GetFld("BuySell")
		local Price = evt._GetFld("Price")
		local QuantityType = evt._GetFld("QuantityType")
		local Quantity = evt._GetFld("Quantity")
		local SelectedBAMapID = evt._GetFld("SelectedBAMapID")
		local inParam=sys_format("IssueCode[%s],OpenClose[%s],BuySell[%s],Price[%s],PortID[%s],QuantityType[%s],Quantity[%s],SelectedBAMapID[%s]",IssueCode,OpenClose,BuySell,Price,PortID,QuantityType,Quantity,SelectedBAMapID)
		_WriteAplLog(inParam)
		local isZH=false
		local PriceType=Price

		local weightType=""
		local reserveString=""
		if not _PosIssueMarketTable[IssueCode] then
			if gtInventoryHeaderTable[IssueCode] and gtInventoryComponentTable[IssueCode] then
				isZH=true
				weightType=gtInventoryHeaderTable[IssueCode].WeightType
				reserveString=gtInventoryHeaderTable[IssueCode].ReserveString
				FreshComponent(sessionID,IssueCode)
				onInventoryprice(sessionID,IssueCode)
				if QuantityType=="InventorySet" then
					if gtInvestoryPriceTable[IssueCode] then
						Price=gtInvestoryPriceTable[IssueCode].BuyPrice
						if not isNumBer(Price) then
							Price=gtInvestoryPriceTable[IssueCode].LastPrice
						end
						local log=sys_format("InvestoryPrice[%s,%s]",IssueCode,Price)
						_WriteAplLog(log)
					end
				else
					local orderPriceType=""
					if  PriceType=="涨停" then
						orderPriceType="UpLimitPrice"
					elseif  PriceType=="卖5" then
						orderPriceType="AskPrice5"
					elseif  PriceType=="卖4" then
						orderPriceType="AskPrice4"
					elseif  PriceType=="卖3" then
						orderPriceType="AskPrice3"
					elseif  PriceType=="卖2" then
						orderPriceType="AskPrice2"
					elseif  PriceType=="卖1" then
						orderPriceType="AskPrice1"
					elseif  PriceType=="买1" then
						orderPriceType="BidPrice1"
					elseif  PriceType=="买2" then
						orderPriceType="BidPrice2"
					elseif  PriceType=="买3" then
						orderPriceType="BidPrice3"
					elseif  PriceType=="买4" then
						orderPriceType="BidPrice4"
					elseif  PriceType=="买5" then
						orderPriceType="BidPrice5"
					elseif  PriceType=="跌停" then
						orderPriceType="LowLimitPrice"
					end
					if gtInvestoryPriceTable[IssueCode] then
						if gtInvestoryPriceTable[IssueCode][orderPriceType] then
							Price=gtInvestoryPriceTable[IssueCode][orderPriceType]
							if not isNumBer(Price) then
								Price=gtInvestoryPriceTable[IssueCode].LastPrice
							end
						end
						local log=sys_format("InvestoryPrice[%s,%s,%s,%s]",IssueCode,PriceType,orderPriceType,Price)
						_WriteAplLog(log)
					end
				end
			end
		end
		if OpenClose==0 then
			local marketCode = _PosIssueMarketTable[IssueCode]
			local type=""
			local orderQtyField=""
			local avlQtyField=""
			local priceField=""
			if marketCode=="1" or marketCode=="2" then
				type="S"
				if BuySell=="3" then
					avlQtyField="可买数量"
					orderQtyField="买入数量"
					priceField="买入价格"
				end
			elseif marketCode=="3" or marketCode=="4" or marketCode=="5" or marketCode=="6" then
				type="F"
				if BuySell=="3" then
					avlQtyField="可买开数量"
					orderQtyField="买开数量"
					priceField="买开价格"
				elseif BuySell=="1" then
					avlQtyField="可卖开数量"
					orderQtyField="卖开数量"
					priceField="卖开价格"
				end
			elseif isZH then
				type="S"
				if BuySell=="3" then
					avlQtyField="可买数量(份)"
					orderQtyField="买入数量(份)"
					priceField="买入价格"
				end
			end
			local columnsString="";
			local field1=sys_format("{FieldName=\"勾选\",Field=\"Select\",Width=%s}",60)
			local field2=sys_format("{FieldName=\"理财账户\",Field=\"BaMapID\",Width=%s}",80)
			local field8=sys_format("{FieldName=\"账户名称\",Field=\"AccountName\",Width=%s}",300)
			local field3=sys_format("{FieldName=\"可用资金\",Field=\"AvlFund\",Width=%s}",140)
			local field4=sys_format("{FieldName=\"%s\",Field=\"Price\",Width=%s}",priceField,80)
			local field5=sys_format("{FieldName=\"%s\",Field=\"AvlOpenQty\"}",avlQtyField)
			local field6=sys_format("{FieldName=\"%s\",Field=\"OrderQty\",ReadOnly=\"False\"}",orderQtyField)
			if isZH then
				field6=sys_format("{FieldName=\"%s\",Field=\"OrderQty\"}",orderQtyField)
			end
			if QuantityType=="Ratio4AllFund" then
				local field7=sys_format("{FieldName=\"目标资金\",Field=\"NeededFund\",Width=%s}",140)
				local field9=sys_format("{FieldName=\"总资产\",Field=\"AllFund\",Width=%s}",140)
				columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field3,field9,field7,field4,field5,field6)
			elseif QuantityType=="FundAvg" then
				local field10=sys_format("{FieldName=\"使用金额\",Field=\"AvgFund\",Width=%s}",140)
				columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field3,field4,field5,field10,field6)
			elseif QuantityType=="InventorySet" then
				local field7=sys_format("{FieldName=\"目标资金\",Field=\"NeededFund\",Width=%s}",140)
				local field9=sys_format("{FieldName=\"总资产\",Field=\"AllFund\",Width=%s}",140)
				local fieldOrderFund=sys_format("{FieldName=\"预计下单金额\",Field=\"OrderFund\",Width=%s}",140)
				local fieldShow=sys_format("{FieldName=\"查看清单\",Field=\"Show\",Width=%s,IsButton=\"True\"}",60)
				local fieldDetail="{FieldName=\"清单\",Field=\"Detail\",Width=0,Visible=\"False\"}"
				if weightType=="比例" then
					if reserveString=="按固定金额" then
						columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field3,field7,fieldOrderFund,field6,fieldShow,fieldDetail)
					elseif reserveString=="按总资产" then
						columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field3,field9,field7,fieldOrderFund,field6,fieldShow,fieldDetail)
					elseif reserveString=="按可用资金" then
						columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field3,field7,fieldOrderFund,field6,fieldShow,fieldDetail)
					end
				elseif weightType=="数量" then
					columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field3,fieldOrderFund,field6,fieldShow,fieldDetail)
				end
			else
				columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field3,field4,field5,field6)
			end
			local rowsString="";
			for bAMap,value in pairs(gtRunAccountTable) do
				if gtZGProductAccountTable[bAMap] then
					local needShow = true						
					if curSelectedUserID~="全部" then
						if gtPosUserBAMapTable[curSelectedUserID] then
							if not gtPosUserBAMapTable[curSelectedUserID][bAMap] then
								needShow = false
							end
						else
							needShow = false
						end
					end
					if needShow then
						local accCode = _PosBAMapAccount[bAMap]
						if _PosFundStatus[accCode] then
							local accCodeType = _PosFundStatus[accCode].Type
							if accCodeType==type then
								local avlFund=_PosFundStatus[accCode].AvlFund
								local detail=""
								
								local contractSize = 1
								local bail = 1
								if _PosIssueContractSizeTable[IssueCode] then
									contractSize=_PosIssueContractSizeTable[IssueCode]
								end
								if  _PosIssueMarketTable[IssueCode] then
									bail=_PosGetBail(accCode, IssueCode, BuySell, POS_SPECULATE)
								end
								if isZH then
									contractSize = 1
									bail = 1
								end
								local avlOpenQty=avlFund / (Price * bail * contractSize)
								if type=="S" then
									if not isZH then
										avlOpenQty=sys_floor(avlOpenQty/100)*100
									else
										avlOpenQty=sys_floor(avlOpenQty)
									end
								elseif type=="F" then
									avlOpenQty=sys_floor(avlOpenQty)
								end
								local orderQty=0
								local neededFund=0
								local allFund=0
								local avgFund = 0
								local orderFund=0
								if QuantityType=="All" then
									orderQty=avlOpenQty
								elseif QuantityType=="Ratio" then
									orderQty=avlFund*Quantity / (Price * bail * contractSize)
									if type=="S" then
										if not isZH then
											orderQty=sys_floor(orderQty/100)*100
										else
											orderQty=sys_floor(orderQty)
										end
									elseif type=="F" then
										orderQty=sys_floor(orderQty)
									end
								elseif QuantityType=="Fund" then
									orderQty=Quantity / (Price * bail * contractSize)
									if type=="S" then
										if not isZH then
											orderQty=sys_floor(orderQty/100)*100
										else
											orderQty=sys_floor(orderQty)
										end
									elseif type=="F" then
										orderQty=sys_floor(orderQty)
									end
								elseif QuantityType=="Quantity" then
									orderQty=Quantity
								elseif QuantityType=="Ratio4AllFund" then
									allFund=_PosFundStatus[accCode].AssetValue
									neededFund=allFund*Quantity
									orderQty=neededFund / (Price * bail * contractSize)
									if type=="S" then
										if not isZH then
											orderQty=sys_floor(orderQty/100)*100
										else
											orderQty=sys_floor(orderQty)
										end
									elseif type=="F" then
										orderQty=sys_floor(orderQty)
									end
								elseif QuantityType=="FundAvg" then
									local len = sys_len(SelectedBAMapID)
									if len > 0 then
										local lt = getTableByString(SelectedBAMapID, ",")
										local accoutCount = sys_getSize(lt)
										avgFund = Quantity / accoutCount
										orderQty= avgFund / (Price * bail * contractSize)
										if not isZH then
											orderQty=sys_floor(orderQty/100)*100
										else
											orderQty=sys_floor(orderQty)
										end
									else
										orderQty=0
									end
								elseif QuantityType=="QtyAvg" then
									local len = sys_len(SelectedBAMapID)
									if len > 0 then
										local lt = getTableByString(SelectedBAMapID, ",")
										local accoutCount = sys_getSize(lt)
										orderQty = Quantity / accoutCount
										if not isZH then
											orderQty=sys_floor(orderQty/100)*100
										else
											orderQty=sys_floor(orderQty)
										end
									else
										orderQty=0
									end
								elseif QuantityType=="InventorySet" then
									orderQty=1
									if weightType=="比例" then
										if reserveString=="按固定金额" then
											neededFund=gtInventoryHeaderTable[IssueCode].PerAmount*1
										elseif reserveString=="按总资产" then
											allFund=_PosFundStatus[accCode].AssetValue
											neededFund=allFund*gtInventoryHeaderTable[IssueCode].PerAmount/100
										elseif reserveString=="按可用资金" then
											neededFund=avlFund*gtInventoryHeaderTable[IssueCode].PerAmount/100
										end
										if gtInventoryComponentTable[IssueCode] then
											for issueCode,v in pairs(gtInventoryComponentTable[IssueCode])do
												if v.IsSelected=="1" then
													if detail~="" then
														detail=detail..";"
													end
													local price = v.BuyPrice
													if price=="" then
														price="卖1"
													end
													local orderPrice=0
													if gtPriceTable[issueCode] then
														tprice=gtPriceTable[issueCode]
														if  price=="涨停" then
															orderPrice=tprice.upperLimitPrice
														elseif  price=="卖5" then
															orderPrice=tprice.askPrice_5
														elseif  price=="卖4" then
															orderPrice=tprice.askPrice_4
														elseif  price=="卖3" then
															orderPrice=tprice.askPrice_3
														elseif  price=="卖2" then
															orderPrice=tprice.askPrice_2
														elseif  price=="卖1" then
															orderPrice=tprice.askPrice_1
														elseif  price=="买1" then
															orderPrice=tprice.bidPrice_1
														elseif  price=="买2" then
															orderPrice=tprice.bidPrice_2
														elseif  price=="买3" then
															orderPrice=tprice.bidPrice_3
														elseif  price=="买4" then
															orderPrice=tprice.bidPrice_4
														elseif  price=="买5" then
															orderPrice=tprice.bidPrice_5
														elseif  price=="跌停" then
															orderPrice=tprice.lowerLimitPrice
														end
													end
													local avlOpenQty=0
													local contractSize = _PosIssueContractSizeTable[issueCode]
													local bail = _PosGetBail(accCode, issueCode, BuySell, POS_SPECULATE)
													if not isNumBer(orderPrice) then
														orderPrice=0
													else
														avlOpenQty=neededFund * v.Ratio / 100 / (orderPrice * bail * contractSize * (1 + gMaxFare))
														avlOpenQty=sys_floor(avlOpenQty/100)*100
													end
													orderFund=orderFund+avlOpenQty*(orderPrice * bail * contractSize * (1 + gMaxFare))
													detail = detail.."代码:"..issueCode.."，预计数量:"..avlOpenQty.toString().."，价格:"..price.toString()
												end
											end
										end
									elseif weightType=="数量" then
										if gtInventoryComponentTable[IssueCode] then
											for issueCode,v in pairs(gtInventoryComponentTable[IssueCode])do
												if v.IsSelected=="1" then
													if detail~="" then
														detail=detail..";"
													end
													local price = v.BuyPrice
													if price=="" then
														price="卖1"
													end
													local orderPrice=0
													if gtPriceTable[issueCode] then
														tprice=gtPriceTable[issueCode]
														if  price=="涨停" then
															orderPrice=tprice.upperLimitPrice
														elseif  price=="卖5" then
															orderPrice=tprice.askPrice_5
														elseif  price=="卖4" then
															orderPrice=tprice.askPrice_4
														elseif  price=="卖3" then
															orderPrice=tprice.askPrice_3
														elseif  price=="卖2" then
															orderPrice=tprice.askPrice_2
														elseif  price=="卖1" then
															orderPrice=tprice.askPrice_1
														elseif  price=="买1" then
															orderPrice=tprice.bidPrice_1
														elseif  price=="买2" then
															orderPrice=tprice.bidPrice_2
														elseif  price=="买3" then
															orderPrice=tprice.bidPrice_3
														elseif  price=="买4" then
															orderPrice=tprice.bidPrice_4
														elseif  price=="买5" then
															orderPrice=tprice.bidPrice_5
														elseif  price=="跌停" then
															orderPrice=tprice.lowerLimitPrice
														end
													end
													if not isNumBer(orderPrice) then
														orderPrice=0
													end
													local contractSize = _PosIssueContractSizeTable[issueCode]
													local bail = _PosGetBail(accCode, issueCode, BuySell, POS_SPECULATE)
													orderFund=orderFund+v.Quantity*(orderPrice * bail * contractSize * (1 + gMaxFare))
													detail = detail.."代码:"..issueCode.."，数量:"..v.Quantity.toString().."，价格:"..price.toString()
												end
											end
										end
									end
								end
								if orderQty>avlOpenQty then
									orderQty=avlOpenQty
								end
								local isSelected = false
								if sys_find(SelectedBAMapID, bAMap,1) ~= nil then
									isSelected = true
								end
								if avlOpenQty>0 or orderQty>0 then
									local accountName = GetAccountName(accCode)
									local row=""
									if QuantityType=="Ratio4AllFund" then
										if neededFund > avlFund then
											avlOpenQty=0
											orderQty=0
										end
										if isZH then
											row=sys_format("{%s,\"%s\",\"%s\",%.2f,%.2f,%.2f,\"%s\",%s,%s}",isSelected,bAMap,accountName,avlFund,allFund,neededFund,PriceType,avlOpenQty,orderQty)
										else
											row=sys_format("{%s,\"%s\",\"%s\",%.2f,%.2f,%.2f,\"%s\",%s,%s}",isSelected,bAMap,accountName,avlFund,allFund,neededFund,Price,avlOpenQty,orderQty)
										end
									elseif QuantityType=="FundAvg" then
										if isSelected==true then
											if isZH then
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s,%s}",isSelected,bAMap,accountName,avlFund,PriceType,avlOpenQty,avgFund,orderQty)
											else
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s,%s}",isSelected,bAMap,accountName,avlFund,Price,avlOpenQty,avgFund,orderQty)
											end
										else
											if isZH then
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s,%s}",isSelected,bAMap,accountName,avlFund,PriceType,avlOpenQty,0,0)
											else
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s,%s}",isSelected,bAMap,accountName,avlFund,Price,avlOpenQty,0,0)
											end
										end
									elseif QuantityType=="QtyAvg" then
										if isSelected==true then
											if isZH then
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s}",isSelected,bAMap,accountName,avlFund,PriceType,avlOpenQty,orderQty)
											else
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s}",isSelected,bAMap,accountName,avlFund,Price,avlOpenQty,orderQty)
											end
										else
											if isZH then
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s}",isSelected,bAMap,accountName,avlFund,PriceType,avlOpenQty,0)
											else
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s}",isSelected,bAMap,accountName,avlFund,Price,avlOpenQty,0)
											end
										end
									elseif QuantityType=="InventorySet" then
										if weightType=="比例" then
											if neededFund>avlFund or orderFund==0 then
												orderQty=0
											end
											if reserveString=="按固定金额" then
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,%.2f,%.2f,%s,\"%s\",\"%s\"}",isSelected,bAMap,accountName,avlFund,neededFund,orderFund,orderQty,"查看",detail)
											elseif reserveString=="按总资产" then
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,%.2f,%.2f,%.2f,%s,\"%s\",\"%s\"}",isSelected,bAMap,accountName,avlFund,allFund,neededFund,orderFund,orderQty,"查看",detail)
											elseif reserveString=="按可用资金" then
												row=sys_format("{%s,\"%s\",\"%s\",%.2f,%.2f,%.2f,%s,\"%s\",\"%s\"}",isSelected,bAMap,accountName,avlFund,neededFund,orderFund,orderQty,"查看",detail)
											end
										elseif weightType=="数量" then
											if orderFund>avlFund then
												orderQty=0
											end
											row=sys_format("{%s,\"%s\",\"%s\",%.2f,%.2f,%s,\"%s\",\"%s\"}",isSelected,bAMap,accountName,avlFund,orderFund,orderQty,"查看",detail)
										end
									else
										if isZH then
											row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s}",isSelected,bAMap,accountName,avlFund,PriceType,avlOpenQty,orderQty)
										else
											row=sys_format("{%s,\"%s\",\"%s\",%.2f,\"%s\",%s,%s}",isSelected,bAMap,accountName,avlFund,Price,avlOpenQty,orderQty)
										end
									end
									if rowsString=="" then
										rowsString=row
									else
										rowsString=rowsString..","..row
									end
								end
							end
						end
					end
				end
			end
			local DataString=sys_format("{Columns=%s,Rows={%s}}",columnsString,rowsString)
			_WriteAplLog("=============MultiFireDataOut DataString==============")
			_WriteAplLog(DataString)
			local DTSEvent outEvt = _CreateEventObject("MultiFireDataOut")
			outEvt._SetFld("IssueCode",IssueCode)
			outEvt._SetFld("OpenClose",OpenClose)
			outEvt._SetFld("BuySell",BuySell)
			outEvt._SetFld("DataString",DataString)
			_SendEventToClient(outEvt,sessionID);
		elseif OpenClose==1 then
			local marketCode = _PosIssueMarketTable[IssueCode]
			local orderBS=""
			local type=""
			local avlOpenQtyField=""
			local OrderQtyField=""
			local priceField=""
			local issueCodeField=""
			if marketCode=="1" or marketCode=="2" then
				type="S"
				issueCodeField="证券代码"
				if BuySell=="1" then
					avlOpenQtyField="可卖数量"
					OrderQtyField="卖出数量"
					priceField="卖出价格"
					orderBS="3"
				end
			elseif isZH then
				type="S"
				issueCodeField="证券代码"
				if BuySell=="1" then
					avlOpenQtyField="可卖数量"
					OrderQtyField="卖出数量"
					priceField="卖出价格"
					orderBS="3"
				end
			elseif marketCode=="3" or marketCode=="4" or marketCode=="5" or marketCode=="6" then
				type="F"
				issueCodeField="合约代码"
				if BuySell=="3" then
					avlOpenQtyField="可买平数量"
					OrderQtyField="买平数量"
					priceField="买平价格"
					orderBS="1"
				elseif BuySell=="1" then
					avlOpenQtyField="可卖平数量"
					OrderQtyField="卖平数量"
					priceField="卖平价格"
					orderBS="3"
				end
			end
			local columnsString="";
			local field1=sys_format("{FieldName=\"勾选\",Field=\"Select\",Width=%s}",60)
			local field2=sys_format("{FieldName=\"理财账户\",Field=\"BaMapID\",Width=%s}",80)
			local field8=sys_format("{FieldName=\"账户名称\",Field=\"AccountName\",Width=%s}",300)
			--local field3=sys_format("{FieldName=\"持仓组合号\",Field=\"PortID\",Width=%s}",80)--隐藏
			local field4=sys_format("{FieldName=\"%s\",Field=\"IssueCode\",Width=%s}",issueCodeField,80)
			local field5=sys_format("{FieldName=\"%s\",Field=\"Price\",Width=%s}",priceField,80)
			local field6=sys_format("{FieldName=\"%s\",Field=\"AvlOpenQty\"}",avlOpenQtyField)
			local field7=sys_format("{FieldName=\"%s\",Field=\"OrderQty\",ReadOnly=\"False\"}",OrderQtyField)
			--columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s}",field1,field2,field3,field4,field5,field6,field7)
			columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field4,field5,field6,field7)
			local rowsString="";
			for bAMap,value in pairs(gtRunAccountTable) do
				if gtZGProductAccountTable[bAMap] then
					local needShow = true						
					if curSelectedUserID~="全部" then
						if gtPosUserBAMapTable[curSelectedUserID] then
							if not gtPosUserBAMapTable[curSelectedUserID][bAMap] then
								needShow = false
							end
						else
							needShow = false
						end
					end
					if needShow then
						local accCode = _PosBAMapAccount[bAMap]
						if _PosFundStatus[accCode] then
							local accCodeType = _PosFundStatus[accCode].Type
							if accCodeType==type then
								for posKey, pos in pairs(_PosPositionTable) do
									local posBS = sys_sub(pos.BASubID, 1, 1)
									local posPortID = sys_sub(pos.BASubID, 2, -1)
									if not isZH then
										if pos.BAMapID==bAMap and posPortID==PortID and pos.IssueCode==IssueCode and posBS==orderBS and pos.AvlQuantity>0 then
											local accountName = GetAccountName(accCode)
											local orderQty=0
											if QuantityType=="All" then
												orderQty=pos.AvlQuantity
											elseif QuantityType=="Ratio" then
												orderQty=pos.AvlQuantity*Quantity
												if type=="S" then
													orderQty=sys_ceil(orderQty/100)*100
												elseif type=="F" then
													orderQty=sys_floor(orderQty)
												end
											elseif QuantityType=="Quantity" then
												orderQty=Quantity
											elseif QuantityType=="QtyAvg" then
												local len = sys_len(SelectedBAMapID)
												if len > 0 then
													local lt = getTableByString(SelectedBAMapID, ",")
													local accoutCount = sys_getSize(lt)
													orderQty = Quantity / accoutCount
													orderQty=sys_ceil(orderQty/100)*100
												else
													orderQty=0
												end
											end
											if orderQty>pos.AvlQuantity then
												orderQty=pos.AvlQuantity
											end
											local isSelected = false
											if sys_find(SelectedBAMapID, bAMap,1) ~= nil then
												isSelected = true
											end
											local row=""
											if QuantityType=="QtyAvg" then
												if isSelected==true then
													row=sys_format("{%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",isSelected,bAMap,accountName,IssueCode,Price,pos.AvlQuantity,orderQty)
												else
													row=sys_format("{%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",isSelected,bAMap,accountName,IssueCode,Price,pos.AvlQuantity,0)
												end
											else
												row=sys_format("{%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",isSelected,bAMap,accountName,IssueCode,Price,pos.AvlQuantity,orderQty)
											end
											if rowsString=="" then
												rowsString=row
											else
												rowsString=rowsString..","..row
											end
										end
									elseif pos.BAMapID==bAMap and posPortID==PortID and gtInventoryComponentTable[IssueCode][pos.IssueCode] and posBS==orderBS and pos.AvlQuantity>0 then
										if gtInventoryComponentTable[IssueCode][pos.IssueCode].IsSelected=="1" then
											local accountName = GetAccountName(accCode)
											local orderQty=0
											local orderPrice=""
											if QuantityType=="All" then
												orderQty=pos.AvlQuantity
											elseif QuantityType=="Ratio" then
												orderQty=pos.AvlQuantity*Quantity
												orderQty=sys_ceil(orderQty/100)*100
											elseif QuantityType=="Quantity" then
												orderQty=Quantity
											elseif QuantityType=="QtyAvg" then
												local len = sys_len(SelectedBAMapID)
												if len > 0 then
													local lt = getTableByString(SelectedBAMapID, ",")
													local accoutCount = sys_getSize(lt)
													orderQty = Quantity / accoutCount
													orderQty=sys_ceil(orderQty/100)*100
												else
													orderQty=0
												end
											elseif QuantityType=="InventorySet" then
												orderQty=gtInventoryComponentTable[IssueCode][pos.IssueCode].Quantity
												if orderQty>pos.AvlQuantity then
													orderQty=0
												end
												orderPrice=gtInventoryComponentTable[IssueCode][pos.IssueCode].BuyPrice
												if orderPrice=="" then
													orderPrice="买1"
												end
											end
											if orderQty>pos.AvlQuantity then
												orderQty=pos.AvlQuantity
											end
											local isSelected = false
											if sys_find(SelectedBAMapID, bAMap,1) ~= nil then
												isSelected = true
											end
											local row=""
											if QuantityType=="QtyAvg" then
												if isSelected==true then
													row=sys_format("{%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",isSelected,bAMap,accountName,pos.IssueCode,PriceType,pos.AvlQuantity,orderQty)
												else
													row=sys_format("{%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",isSelected,bAMap,accountName,pos.IssueCode,PriceType,pos.AvlQuantity,orderQty)
												end
											elseif QuantityType=="InventorySet" then
												if isNumBer(orderPrice) then
													row=sys_format("{%s,\"%s\",\"%s\",\"%s\",%s,%s,%s}",isSelected,bAMap,accountName,pos.IssueCode,orderPrice,pos.AvlQuantity,orderQty)
												else
													row=sys_format("{%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",isSelected,bAMap,accountName,pos.IssueCode,orderPrice,pos.AvlQuantity,orderQty)
												end
											else
												row=sys_format("{%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",isSelected,bAMap,accountName,pos.IssueCode,PriceType,pos.AvlQuantity,orderQty)
											end
											if rowsString=="" then
												rowsString=row
											else
												rowsString=rowsString..","..row
											end
										end
									end
								end
							end
						end
					end
				end
			end
			local DataString=sys_format("{Columns=%s,Rows={%s}}",columnsString,rowsString)
			_WriteAplLog("=============MultiFireDataOut DataString==============")
			_WriteAplLog(DataString)
			local DTSEvent outEvt = _CreateEventObject("MultiFireDataOut")
			outEvt._SetFld("IssueCode",IssueCode)
			outEvt._SetFld("OpenClose",OpenClose)
			outEvt._SetFld("BuySell",BuySell)
			outEvt._SetFld("DataString",DataString)
			_SendEventToClient(outEvt,sessionID);
		elseif OpenClose==2 then
			local marketCode = _PosIssueMarketTable[IssueCode]
			local orderBS=""
			local type=""
			local avlOpenQtyField=""
			local OrderQtyField=""
			local priceField=""
			local issueCodeField=""
			if marketCode=="3" or marketCode=="4" or marketCode=="5" or marketCode=="6" then
				type="F"
				issueCodeField="合约代码"
				if BuySell=="3" then
					avlOpenQtyField="可买平今数量"
					OrderQtyField="买平今数量"
					priceField="买平今价格"
					orderBS="1"
				elseif BuySell=="1" then
					avlOpenQtyField="可卖平今数量"
					OrderQtyField="卖平今数量"
					priceField="卖平今价格"
					orderBS="3"
				end
			end
			local columnsString="";
			local field1=sys_format("{FieldName=\"勾选\",Field=\"Select\",Width=%s}",60)
			local field2=sys_format("{FieldName=\"理财账户\",Field=\"BaMapID\",Width=%s}",80)
			local field8=sys_format("{FieldName=\"账户名称\",Field=\"AccountName\",Width=%s}",300)
			--local field3=sys_format("{FieldName=\"持仓组合号\",Field=\"PortID\",Width=%s}",80)--隐藏
			local field4=sys_format("{FieldName=\"%s\",Field=\"IssueCode\",Width=%s}",issueCodeField,80)
			local field5=sys_format("{FieldName=\"%s\",Field=\"Price\",Width=%s}",priceField,80)
			local field6=sys_format("{FieldName=\"%s\",Field=\"AvlOpenQty\"}",avlOpenQtyField)
			local field7=sys_format("{FieldName=\"%s\",Field=\"OrderQty\",ReadOnly=\"False\"}",OrderQtyField)
			--columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s}",field1,field2,field3,field4,field5,field6,field7)
			columnsString=sys_format("{%s,%s,%s,%s,%s,%s,%s}",field1,field2,field8,field4,field5,field6,field7)
			local rowsString="";
			for bAMap,value in pairs(gtRunAccountTable) do
				if gtZGProductAccountTable[bAMap] then
					local needShow = true						
					if curSelectedUserID~="全部" then
						if gtPosUserBAMapTable[curSelectedUserID] then
							if not gtPosUserBAMapTable[curSelectedUserID][bAMap] then
								needShow = false
							end
						else
							needShow = false
						end
					end
					if needShow then
						local accCode = _PosBAMapAccount[bAMap]
						if _PosFundStatus[accCode] then
							local accCodeType = _PosFundStatus[accCode].Type
							if accCodeType==type then
								for posKey, pos in pairs(_PosPositionTable) do
									local posBS = sys_sub(pos.BASubID, 1, 1)
									local posPortID = sys_sub(pos.BASubID, 2, -1)
									if pos.BAMapID==bAMap and posPortID==PortID and pos.IssueCode==IssueCode and posBS==orderBS and pos.AvlTodayQuantity>0 then
										local accountName = GetAccountName(accCode)
										local orderQty=0
										if QuantityType=="All" then
											orderQty=pos.AvlTodayQuantity
										elseif QuantityType=="Ratio" then
											orderQty=pos.AvlTodayQuantity*Quantity
											if type=="S" then
												orderQty=sys_floor(orderQty)
											elseif type=="F" then
												orderQty=sys_floor(orderQty)
											end
										elseif QuantityType=="Quantity" then
											orderQty=Quantity
										end
										if orderQty>pos.AvlTodayQuantity then
											orderQty=pos.AvlTodayQuantity
										end
										local isSelected = false
										if sys_find(SelectedBAMapID, bAMap,1) ~= nil then
											isSelected = true
										end
										--local row=sys_format("{false,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",bAMap,sys_sub(pos.BASubID, 2, -1),IssueCode,Price,pos.AvlTodayQuantity,orderQty)
										local row=sys_format("{%s,\"%s\",\"%s\",\"%s\",\"%s\",%s,%s}",isSelected,bAMap,accountName,IssueCode,Price,pos.AvlTodayQuantity,orderQty)
										if rowsString=="" then
											rowsString=row
										else
											rowsString=rowsString..","..row
										end
									end
								end
							end
						end
					end
				end
			end
			local DataString=sys_format("{Columns=%s,Rows={%s}}",columnsString,rowsString)
			_WriteAplLog("=============MultiFireDataOut DataString==============")
			_WriteAplLog(DataString)
			local DTSEvent outEvt = _CreateEventObject("MultiFireDataOut")
			outEvt._SetFld("IssueCode",IssueCode)
			outEvt._SetFld("OpenClose",OpenClose)
			outEvt._SetFld("BuySell",BuySell)
			outEvt._SetFld("DataString",DataString)
			_SendEventToClient(outEvt,sessionID);
		end
	else
		local log = sys_format("策略没有初始化完毕, 请稍后再试")
		_WriteAplLog(log)

		showLog(sessionID,log)
	end
_End

--多账户下单
_DefineEventObject MultiFireEvent _AS _Input
	_DefFld("IssueCode", _String, 20)	--代码
	_DefFld("OpenClose", _Int, 1)			--开平
	_DefFld("BuySell", _String, 1)			--买卖
	_DefFld("Price", _String, 15)
	_DefFld("PortID", _String, 48)
	_DefFld("OrderType", _String, 2)	  --委托类型
	_DefFld("OrderInf",  _Meta, 4)
_End

_OnEventDefined(MultiFireEvent evt,sessionID) -- 算法交易
	gCurSession=sessionID
	_WriteAplLog("================MultiFireEvent=================")
	if gInitialized then
		local IssueCode = evt._GetFld("IssueCode")
		local OpenClose = evt._GetFld("OpenClose")
		local BuySell = evt._GetFld("BuySell")
		local Price = evt._GetFld("Price")
		local PortID = evt._GetFld("PortID")
		local OrderType = evt._GetFld("OrderType")
		local OrderInf = evt._GetFld("OrderInf")

		local inParam=sys_format("IssueCode[%s],OpenClose[%s],BuySell[%s],Price[%s],PortID[%s],OrderType[%s],OrderInf[%s]",IssueCode,OpenClose,BuySell,Price,PortID,OrderType,OrderInf)
		_WriteAplLog(inParam)
		local marketCode = _PosIssueMarketTable[IssueCode]
		local isZH=false
		if not _PosIssueMarketTable[IssueCode] then
			if gtInventoryHeaderTable[IssueCode] and gtInventoryComponentTable[IssueCode] then
				isZH=true
			end
		end
		local orders={}
		local len = sys_len(OrderInf)
		local lineBegin=1
		local lineEnd=1
		for i = 1, len do
			local chr = sys_sub(OrderInf, i, i)
			if chr == "(" then
				lineBegin=i+1;
			end
			if chr == ")" then
				lineEnd=i-1;
				local line=sys_sub(OrderInf, lineBegin, lineEnd)
				line=innerTrimAll(line," ");
				line=innerTrimAll(line,"\r");
				line=innerTrimAll(line,"\n");
				local rtn = getNameAndValue(line);
				sys_insert(orders,rtn)
			end
		end

		local BaSubID = BuySell .. PortID
		if OpenClose == 0 then
			BaSubID = BuySell .. PortID
		else
			if BuySell == "3" then
				BaSubID = "1" .. PortID
			else
				BaSubID = "3" .. PortID
			end
		end
		--委托类型
		local tmpOrderType  = GetOrderTypeName(OrderType)
		if tmpOrderType == "无法识别" then
			local log = sys_format("多账户下单失败: 无法识别委托类型")
			showLog(sessionID,log)
		else
			local priceInfo = _PosPriceTable[IssueCode]
			local orderPrice = Price
			if OrderType == "" then--如果没有OrderType,则下单价格为所传的价格
				orderPrice = Price
			elseif priceInfo then
				orderPrice = priceInfo.UpLimitPrice--市价委托的委托价都按涨停价
				if OrderType == "F" then
					if marketCode == "4" or marketCode == "5" or marketCode == "6" then
						if BuySell == "1" then
							OrderType = ""
							orderPrice = priceInfo.LowLimitPrice --模拟市价， 卖用跌停价
						elseif BuySell == "3" then
							OrderType = ""
							orderPrice = priceInfo.UpLimitPrice --模拟市价， 卖用涨停价
						end
					end
				end
			end
			for i,order in pairs(orders) do
				if not isZH then
					local baMapID=order[1]
					local dealerID = GetOrderDealerID(baMapID)
					local qty=order[2]
					qty = sys_format("%s",qty)
					qty = qty.getNumberValue()
					if OpenClose == 1 then
						local ForbidPosition = 0
						local avlQty = 0
						local baSubID_tmp = sys_sub(BaSubID,1,1)
						local posKey = sys_format("%s.%s.%s",baMapID,baSubID_tmp,IssueCode)
						_WriteAplLog(posKey)
						
						if _PosPositionTable[posKey] then
							avlQty = _PosPositionTable[posKey].AvlQuantity
							if gtBAMapID2ForbidPositionTable[posKey] then
								ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition		
							end
							
							local log = sys_format("qty[%s],avlQty[%s],ForbidPosition[%s]",qty,avlQty,ForbidPosition)
							_WriteAplLog(log)

							if qty > avlQty - ForbidPosition then
								qty = avlQty - ForbidPosition
							end
						end
					end

					local qtyTmp = 100*sys_floor(qty/100)
					if BuySell=="3" or (BuySell=="1" and qtyTmp.toInt() == qty) then
						if (marketCode=="1" or marketCode=="2") and BuySell=="3" then
							qty=qtyTmp
						end
						--qty=qty.toInt();
						
						local log=sys_format("PosSubmitSingleOrder:BaMapID[%s],BaSubID[%s],IssueCode[%s],OpenClose[%s],BuySell[%s],Price[%s],Quantity[%s],OrderType[%s],",baMapID,BaSubID,IssueCode,OpenClose,BuySell,Price,qty,OrderType)
						_WriteAplLog(log)
						local pcid=newPCID(baMapID)
						setOrderRouteInfo(sessionID,pcid)
						local ret = PosSubmitSingleOrder(baMapID, BaSubID, IssueCode, BuySell, OpenClose, orderPrice, qty, 0, dealerID, "", nil, OrderType,pcid)
						if ret.Result then
							local log = sys_format("算法交易委托:理财账户[%s]合约[%s]数量[%d] 已发送至风控系统，委托号[%s],等待回应！",baMapID,IssueCode,qty,ret.PositionCheckID)
							showLog(sessionID,log)
							gtOrderSessionTable[ret.PositionCheckID]=sessionID
						else
							if ret.Reason then
								local log = sys_format("算法交易委托:理财账户[%s]代码[%s]数量[%d] 发送至风控系统失败！原因:%s",baMapID,IssueCode,qty,ret.Reason)
								showLog(sessionID,log)
							end
						end
					else
						--先下整股
						if qtyTmp > 0 or qty == 0 then
							local log=sys_format("PosSubmitSingleOrder:BaMapID[%s],BaSubID[%s],IssueCode[%s],OpenClose[%s],BuySell[%s],Price[%s],Quantity[%s],OrderType[%s],",baMapID,BaSubID,IssueCode,OpenClose,BuySell,Price,qtyTmp,OrderType)
							_WriteAplLog(log)
							local pcid=newPCID(baMapID)
							setOrderRouteInfo(sessionID,pcid)
							local ret = PosSubmitSingleOrder(baMapID, BaSubID, IssueCode, BuySell, OpenClose, orderPrice, qtyTmp, 0, dealerID, "", nil, OrderType,pcid)
							if ret.Result then
								local log = sys_format("算法交易委托:理财账户[%s]合约[%s]数量[%d] 已发送至风控系统，委托号[%s],等待回应！",baMapID,IssueCode,qtyTmp,ret.PositionCheckID)
								showLog(sessionID,log)
								gtOrderSessionTable[ret.PositionCheckID]=sessionID
							else
								if ret.Reason then
									local log = sys_format("算法交易委托:理财账户[%s]代码[%s]数量[%d] 发送至风控系统失败！原因:%s",baMapID,IssueCode,qtyTmp,ret.Reason)
									showLog(sessionID,log)
								end
							end
						end
						qty = qty - qtyTmp
						--再下零股
						if qty > 0 then
							log=sys_format("PosSubmitSingleOrder:BaMapID[%s],BaSubID[%s],IssueCode[%s],OpenClose[%s],BuySell[%s],Price[%s],Quantity[%s],OrderType[%s],",baMapID,BaSubID,IssueCode,OpenClose,BuySell,Price,qty,OrderType)
							_WriteAplLog(log)
							local pcid=newPCID(baMapID)
							setOrderRouteInfo(sessionID,pcid)
							ret = PosSubmitSingleOrder(baMapID, BaSubID, IssueCode, BuySell, OpenClose, orderPrice, qty, 0, dealerID, "", nil, OrderType,pcid)
							if ret.Result then
								local log = sys_format("算法交易委托:理财账户[%s]合约[%s]数量[%d] 已发送至风控系统，委托号[%s],等待回应！",baMapID,IssueCode,qty,ret.PositionCheckID)
								showLog(sessionID,log)
								gtOrderSessionTable[ret.PositionCheckID]=sessionID
							else
								if ret.Reason then
									local log = sys_format("算法交易委托:理财账户[%s]代码[%s]数量[%d] 发送至风控系统失败！原因:%s",baMapID,IssueCode,qty,ret.Reason)
									showLog(sessionID,log)
								end
							end
						end
					end
				else
					if BuySell=="3"  then
						local baMapID=order[1];
						local qty=order[2];
						qty = sys_format("%s",qty)
						qty = qty.getNumberValue()
						
						qty=sys_floor(qty);
						fireInventory(sessionID,baMapID,BaSubID,IssueCode,OpenClose,BuySell,Price,qty,0)
					else
						local baMapID=order[1];
						local issue=order[2];
						local price=order[3];
						local qty=order[4].toInt();
						
						if OpenClose == 1 then
							local ForbidPosition = 0
							local avlQty = 0
							local baSubID_tmp = sys_sub(BaSubID,1,1)
							local posKey = sys_format("%s.%s.%s",baMapID,baSubID_tmp,issue)
							_WriteAplLog(posKey)
							
							if _PosPositionTable[posKey] then
								avlQty = _PosPositionTable[posKey].AvlQuantity
								if gtBAMapID2ForbidPositionTable[posKey] then
									ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition		
								end
								
								if qty > avlQty - ForbidPosition then
									qty = avlQty - ForbidPosition
								end
							end
						end
						
						local qtyTmp = 100*sys_floor(qty/100)
						local dealerID = GetOrderDealerID(baMapID);
						if isNumBer(price) then
							if price-0.00001>=0 then
								orderPrice=price
							end
						else
							orderPrice=getInventoryIssueOrderPrice(issue,price,BuySell)
						end
						if isNumBer(orderPrice) then
							if qtyTmp > 0 or qty == 0 then
								local log=sys_format("PosSubmitSingleOrder:BaMapID[%s],BaSubID[%s],IssueCode[%s],OpenClose[%s],BuySell[%s],Price[%s],Quantity[%s],OrderType[%s],",baMapID,BaSubID,issue,OpenClose,BuySell,price,qtyTmp,OrderType)
								_WriteAplLog(log)
								local pcid=newPCID(baMapID)
								setOrderRouteInfo(sessionID,pcid)
								local ret = PosSubmitSingleOrder(baMapID, BaSubID, issue, BuySell, OpenClose, orderPrice, qtyTmp, 0, dealerID, "", nil, OrderType,pcid)
								if ret.Result then
									local log = sys_format("算法交易委托:理财帐号[%s]代码[%s]数量[%d] 已发送至风控系统，委托号[%s],等待回应！",baMapID,issue,qtyTmp,ret.PositionCheckID)
									_WriteAplLog(log)
									showLog(sessionID,log)
									gtOrderSessionTable[ret.PositionCheckID]=sessionID
								else
									if ret.Reason then
										local log = sys_format("算法交易委托:理财账户[%s]代码[%s]数量[%d] 发送至风控系统失败！原因:%s",baMapID,issue,qtyTmp,ret.Reason)
										_WriteAplLog(log)
										showLog(sessionID,log)
									end
								end
							end
							qty = qty - qtyTmp
							--再下零股
							if qty > 0 then
								local log=sys_format("PosSubmitSingleOrder:BaMapID[%s],BaSubID[%s],IssueCode[%s],OpenClose[%s],BuySell[%s],Price[%s],Quantity[%s],OrderType[%s],",baMapID,BaSubID,issue,OpenClose,BuySell,price,qty,OrderType)
								_WriteAplLog(log)
								local pcid=newPCID(baMapID)
								setOrderRouteInfo(sessionID,pcid)
								local ret = PosSubmitSingleOrder(baMapID, BaSubID, issue, BuySell, OpenClose, orderPrice, qty, 0, dealerID, "", nil, OrderType,pcid)
								if ret.Result then
									local log = sys_format("算法交易委托:理财帐号[%s]代码[%s]数量[%d] 已发送至风控系统，委托号[%s],等待回应！",baMapID,issue,qty,ret.PositionCheckID)
									_WriteAplLog(log)
									showLog(sessionID,log)
									gtOrderSessionTable[ret.PositionCheckID]=sessionID
								else
									if ret.Reason then
										local log = sys_format("算法交易委托:理财账户[%s]代码[%s]数量[%d] 发送至风控系统失败！原因:%s",baMapID,issue,qty,ret.Reason)
										_WriteAplLog(log)
										showLog(sessionID,log)
									end
								end
							end
						else
							local log = sys_format("算法交易委托:理财账户[%s]代码[%s]数量[%d]获取行情失败,下单失败！",baMapID,issue,qty)
							_WriteAplLog(log)
							showLog(sessionID,log)
						end
					end
				end
			end
		end
	else
		local log = sys_format("下单失败: 策略没有初始化完毕, 不允许下单")
		_WriteAplLog(log)
		showLog(sessionID,log)
	end
_End

--多账户界面查询资产信息
_DefineEventObject MultiFireQueryFundInfo _AS _Input
	_DefFld("BaMapID", _String, 22);

	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)

_End
_OnEventDefined(MultiFireQueryFundInfo evt,sessionID)
	gCurSession=sessionID
	_WriteAplLog("================MultiFireQueryFundInfo=================")
	if gInitialized then
		local baMapID = evt._GetFld("BaMapID");
		gtSessionTable[sessionID]=gtSessionTable[sessionID] or {} 
		gtSessionTable[sessionID].CurMultiFireBaMapID = baMapID
		local log = sys_format("MultiFireQueryFundInfo:BAMapID[%s]",baMapID);
		_WriteAplLog(log)		
		RefreshMultiFireFundInfo(sessionID,"other")
	else
		local log = sys_format("策略没有初始化完毕, 请稍后再试")
		_WriteAplLog(log)
		showLog(sessionID,log)
	end
_End

--理财账户历史委托查询
_DefineEventObject HistorySubmitInput _AS _Input
	_DefFld("AccountCode", _String, 20);
	_DefFld("StartDate", _String, 8);
	_DefFld("EndDate", _String, 8);
_End

--查询历史委托回调
_OnEventDefined(HistorySubmitInput historySubmitInEvent,sessionID)
	gCurSession=sessionID
	local accountCode = historySubmitInEvent._GetFld("AccountCode");
	local startDate = historySubmitInEvent._GetFld("StartDate");
	local endDate = historySubmitInEvent._GetFld("EndDate");

	local log = sys_format("HistorySubmitInput:accountCode[%s],startDate[%s],endDate[%s]",accountCode,startDate,endDate)
	_WriteAplLog(log);

	local baMapID = _PosAccountBAMap[accountCode]
	local logs = "";

	local allBaMapID = ""
	if accountCode == "全部" then
		for baMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
			if sys_len(allBaMapID) > 0 then
				allBaMapID = allBaMapID .. ","
			end
			allBaMapID = allBaMapID .. "\'" .. baMapID .. "\'"
		end
	end

	gDateCheckResult = false;
	gHisOrderCheckResult = false
	local calCondition = "Date = \""..startDate.."\"";
	_GetCommonData(dataName = "StartDateCheck",condition = calCondition,tablename = "Calendar");
	calCondition = "Date = \""..endDate.."\"";
	_GetCommonData(dataName = "EndDateCheck",condition = calCondition,tablename = "Calendar");

	if endDate >= startDate and gDateCheckResult then
		if accountCode == "全部" or (baMapID and (not isDefaultAccount(accountCode))) then
			--查询前先清空
			clearHistorySubmitInfo(sessionID)

			local cond = ""
			if accountCode == "全部" and sys_len(allBaMapID) > 0 then
				cond = "DataDate >= \'"..startDate.."' and DataDate <= \'"..endDate.."\' and BAMapID in (".. allBaMapID ..")  ORDER BY DataDate,OrderTime ASC"

			else
				cond = "DataDate >= \'"..startDate.."' and DataDate <= \'"..endDate.."\' and BAMapID = \'"..baMapID.."\'   ORDER BY DataDate,OrderTime ASC"
			end


			_GetCommonData("readHistoricalOrderDetail",condition = cond,"HistoricalOrderDetail")

			if not gHisOrderCheckResult then
				logs = sys_format("理财账户[%s]在该时间范围内无历史委托,请确认！",accountCode);
				showLog(sessionID,logs);
			end
		elseif isDefaultAccount(accountCode) then
			logs = sys_format("%s不是理财账户",accountCode);
			showLog(sessionID,logs);
		else
			logs = sys_format("您无权查看%s的信息",accountCode);
			showLog(sessionID,logs);
		end
	else
		--Invalid searching condition
		showLog(sessionID,"查询历史委托失败:输入日期错误！");
	end
_End

--理财账户历史成交查询
_DefineEventObject HistoryExecutionInput _AS _Input
	_DefFld("AccountCode", _String, 20);
	_DefFld("StartDate", _String, 8);
	_DefFld("EndDate", _String, 8);
	_DefFld("ShowMode", _Int, 4)
_End

_OnEventDefined(HistoryExecutionInput historyExecInEvent,sessionID)
	gCurSession=sessionID
	local accountCode = historyExecInEvent._GetFld("AccountCode");
	local startDate = historyExecInEvent._GetFld("StartDate");
	local endDate = historyExecInEvent._GetFld("EndDate");
	local showMode = historyExecInEvent._GetFld("ShowMode");
	gHisExecShowMode=showMode
	gtHisExecSum={}
	local log = sys_format("HistoryExecutionInput:accountCode[%s],startDate[%s],endDate[%s],showMode[%s]",accountCode,startDate,endDate,showMode)
	_WriteAplLog(log);

	local baMapID = _PosAccountBAMap[accountCode]
	local logs = "";

	local allBaMapID = ""
	if accountCode == "全部" then
		for baMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
			if sys_len(allBaMapID) > 0 then
				allBaMapID = allBaMapID .. ","
			end
			allBaMapID = allBaMapID .. "\'" .. baMapID .. "\'"
		end
	end

	local DTSDate d2 = endDate.toString()
	local DTSDate d1 = startDate.toString()
	local during = d2 - d1
	if during < 90 then
		gDateCheckResult = false;
		gHisExecCheckResult = false
		local calCondition = "Date = \""..startDate.."\"";
		_GetCommonData(dataName = "StartDateCheck",condition = calCondition,tablename = "Calendar");
		calCondition = "Date = \""..endDate.."\"";
		_GetCommonData(dataName = "EndDateCheck",condition = calCondition,tablename = "Calendar");

		if endDate >= startDate and gDateCheckResult then
			if accountCode == "全部" or (baMapID and (not isDefaultAccount(accountCode))) then
				--清空历史成交信息表
				clearHistoryExecutionInfo(sessionID)

				local cond = ""
				if accountCode == "全部" and sys_len(allBaMapID) > 0 then
					calCondition = "ExecutionDate <= \""..endDate.."\" and ExecutionDate >= \""..startDate.."\" and BAMapID in (".. allBaMapID ..") ORDER BY ExecutionDate,ExecutionTime ASC"
				else
					calCondition = "ExecutionDate <= \""..endDate.."\" and ExecutionDate >= \""..startDate.."\" and BAMapID = \""..baMapID.."\" ORDER BY ExecutionDate,ExecutionTime ASC"
				end
				_WriteAplLog(calCondition)
				_GetCommonData(dataName = "HistoryExecution",condition = calCondition,tablename = "HistoricalExec")

				if not gHisExecCheckResult then
					logs = sys_format("理财账户[%s]在该时间范围内无历史成交,请确认！",accountCode);
					showLog(sessionID,logs);
				else
					
					if gHisExecShowMode==2 then
						local DTSEvent hisExecEvent =_CreateEventObject("HistoryExecutionOutput");
						for key,v in pairs(gtHisExecSum) do 
							local baMapID=v.BAMapID
							local accountCode=v.AccountCode
							local issueCode=v.IssueCode
							local buySell=v.BuySell
							local quantity=v.Quantity
							local executionValue=v.ExecutionValue
							local fare=v.Fare
							local fare1=v.Fare1
							local fare2=v.Fare2
							local fare3=v.Fare3
															
							hisExecEvent._SetFld("BAMapID",baMapID);
							hisExecEvent._SetFld("AccountCode",accountCode);
							hisExecEvent._SetFld("IssueCode",issueCode);
							local issueName=_PosIssueNameTable[issueCode]
							hisExecEvent._SetFld("IssueName",issueName);
							hisExecEvent._SetFld("BuySell",buySell);
							hisExecEvent._SetFld("OpenClose","");
							hisExecEvent._SetFld("Quantity",quantity);
							local contractSize = 1
							if _PosIssueContractSizeTable[issueCode] then
								contractSize = _PosIssueContractSizeTable[issueCode]
							end
							local avgPrice=executionValue / (quantity * contractSize)
							local formatPriceExponent=getPriceFormat2(issueCode,1);
							local executionPrice= sys_format(formatPriceExponent,avgPrice);
							hisExecEvent._SetFld("ExecutionPrice",executionPrice);
							executionValue=sys_format("%.2f",executionValue)
							hisExecEvent._SetFld("AmountReceivable",executionValue);
							hisExecEvent._SetFld("Date","");
							hisExecEvent._SetFld("ExecutionTime","");
							fare=sys_format("%.2f",fare)
							hisExecEvent._SetFld("Fare",fare);
							fare1=sys_format("%.2f",fare1)
							hisExecEvent._SetFld("Fare1",fare1);
							fare2=sys_format("%.2f",fare2)
							hisExecEvent._SetFld("Fare2",fare2);
							fare3=sys_format("%.2f",fare3)
							hisExecEvent._SetFld("Fare3",fare3);
							hisExecEvent._SetFld("ExecutionKeyCode","");
							hisExecEvent._SetFld("ExecutionNo","");
							hisExecEvent._SetFld("OrderAcceptNo","");
							_SendEventToClient(hisExecEvent,sessionID);
							local log=sys_format("HistoryExecutionOutput2:%s,%s,%s",baMapID,issueCode,buySell,quantity,executionValue)
							_WriteAplLog(log)
						end
						gtHisExecSum={}
				   end
				
				end
				
				
				
				
			elseif isDefaultAccount(accountCode) then
				logs = sys_format("%s不是理财账户",accountCode);
				showLog(sessionID,logs);
			else
				logs = sys_format("您无权查看%s的信息",accountCode);
				showLog(sessionID,logs);
			end
		else
			--Invalid searching condition
			showLog(sessionID,"查询历史委托失败:输入日期错误！");
		end
	else
	    showLog(sessionID,"查询时间范围不能超过三个月!")
	end
_End

--理财账户当日资金明细查询
_DefineEventObject TodayFundJournal _AS _Input

_End
_OnEventDefined(TodayFundJournal todayFundJournal,sessionID)
	gCurSession=sessionID
	_WriteAplLog("Enter TodayFundJournal")
	if gtSessionTable[sessionID] then 
		local accountCode = gtSessionTable[sessionID].SelectedBAMapID 
		local log = sys_format("TodayFundJournal:accountCode[%s]",accountCode)
		_WriteAplLog(log);
		--查询当日资金流水
		QueryTodayFundJournal(sessionID,accountCode)
	end
_End

--查询当日资金流水
function QueryTodayFundJournal(sessionID,accountCode)
	--清空当日资金明细表
	clearTodayFundJournalInfo(sessionID)
	if accountCode == "全部" then
		for baMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
			local tempAccCode = _PosBAMapAccount[baMapID]
			Sub_QueryTodayFundJournal(sessionID,tempAccCode)
		end
	else
		Sub_QueryTodayFundJournal(sessionID,accountCode)
	end
end
 
function Sub_QueryTodayFundJournal(sessionID,accountCode)
	local logs = "";

	gTodayFundJournalCheckResult = false
	if not isDefaultAccount(accountCode) then

		--查询当日出入金变化
		local today = _PosGetYMDSlash()
		local cond = "NetTransferTime >= \"" .. today .. "\" and (OutAccountCode = \"" .. accountCode .. "\" or InAccountCode =  \"" .. accountCode .. "\" )"
		--_WriteAplLog(cond)
		_GetCommonData("readNetTransfer",condition = cond,tablename = "NetTransfer")
		--查询当日成交资金明细
		QueryTodayExecInfo(accountCode)
	elseif isDefaultAccount(accountCode) then
		logs = sys_format("%s不是理财账户",accountCode);
		showLog(sessionID,logs);
	else
		logs = sys_format("您无权查看%s的信息",accountCode);
		showLog(sessionID,logs);
	end
end

--理财账户历史资金明细查询
_DefineEventObject HistoryFundJournal _AS _Input
	_DefFld("AccountCode", _String, 20);
	_DefFld("StartDate", _String, 8);
	_DefFld("EndDate", _String, 8);
_End

_OnEventDefined(HistoryFundJournal historyFundJournal,sessionID)
	gCurSession=sessionID
	local accountCode = historyFundJournal._GetFld("AccountCode");
	local startDate = historyFundJournal._GetFld("StartDate");
	local endDate = historyFundJournal._GetFld("EndDate");

	local allAccountCode = ""
	if accountCode == "全部" then
		for baMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
			if sys_len(allAccountCode) > 0 then
				allAccountCode = allAccountCode .. ","
			end
			local tempAccCode = _PosBAMapAccount[baMapID]
			allAccountCode = allAccountCode .. "\'" .. tempAccCode .. "\'"
		end
	end

	local log = sys_format("HistoryFundJournal:accountCode[%s],startDate[%s],endDate[%s]",accountCode,startDate,endDate)
	_WriteAplLog(log);
	local logs = "";
	gDateCheckResult = false;
	gHisFundJournalCheckResult = false
	local calCondition = "Date = \""..startDate.."\"";
	_GetCommonData(dataName = "StartDateCheck",condition = calCondition,tablename = "Calendar");
	calCondition = "Date = \""..endDate.."\"";
	_GetCommonData(dataName = "EndDateCheck",condition = calCondition,tablename = "Calendar");

	if endDate >= startDate and gDateCheckResult then
		if accountCode == "全部" or (not isDefaultAccount(accountCode)) then
			--查询前先清空
			clearHistoryFundJournalInfo(sessionID)

			local cond = "Date <= \"" .. endDate.."\" and Date >= \"" .. startDate.."\" and AccountCode = \""..accountCode.."\"".." ORDER BY Date,FundJournalID ASC"
			local cond2 = "ExecutionDate <= \""..endDate.."\" and ExecutionDate >= \""..startDate.."\" and BAMapID = \""..accountCode.."\""
			local cond3 = "DataDate >= \'" .. startDate .. "' and DataDate <= \'" .. endDate .. "\' and BAMapID = \'" .. accountCode .. "\' ORDER BY DataDate,OrderTime ASC"
			if accountCode == "全部" and sys_len(allAccountCode) then
				cond = "Date <= \"" .. endDate.."\" and Date >= \"" .. startDate.."\" and AccountCode in (".. allAccountCode ..")".." ORDER BY Date,FundJournalID ASC"
				cond2 = "ExecutionDate <= \""..endDate.."\" and ExecutionDate >= \""..startDate.."\" and BAMapID in (".. allAccountCode ..")"
				cond3 = "DataDate >= \'" .. startDate .. "' and DataDate <= \'" .. endDate .. "\' and BAMapID in (".. allAccountCode ..") ORDER BY DataDate,OrderTime ASC"
			end
			_WriteAplLog(cond3)
			gtHistoricalOrderDetail={}
			_GetCommonData("readHisOrderForHistoryFund",condition = cond3,"HistoricalOrderDetail")
			_GetCommonData("readHisFundJournalDetail",condition = cond,tablename = "FundJournal")

			if not gHisFundJournalCheckResult then
				logs = sys_format("理财账户[%s]在该时间范围内无历史资金流水,请确认！",accountCode);
				showLog(sessionID,logs);
			end
		elseif isDefaultAccount(accountCode) then
			logs = sys_format("%s不是理财账户",accountCode);
			showLog(sessionID,logs);
		else
			logs = sys_format("您无权查看%s的信息",accountCode);
			showLog(sessionID,logs);
		end
	else
		--Invalid searching condition
		showLog(sessionID,"查询历史资金流水失败:输入日期错误！");
	end
_End

--查询当日成交资金明细
function QueryTodayExecInfo(accountCode)
	for corpCode,value	in pairs(gtShowExecTable) do
		local baMapID = _PosAccountBAMap[accountCode]
		if baMapID == value.BAMapID then
			if not gTodayFundJournalCheckResult then
				gTodayFundJournalCheckResult = true
			end
			--发送当日资金明细
			sendTodayFundInfo(corpCode,accountCode,value)
		end
	end
end

--发送当日资金明细
function sendTodayFundInfo(corpCode,accountCode,value)
	local fundJournalID = corpCode
	local date = _PosGetYMD()
	local description = ""
	local issueName = _PosIssueNameTable[value.IssueCode]
	if value.MarketCode == "1" or value.MarketCode == "2" then
		if value.OpenClose == 0 then
			description = sys_format("买入[%s,%s]成交数量[%s]委托号[%s]",value.IssueCode,issueName,value.ExecQty,value.CorpCode)
			local productCode = _PosIssueProductCodeTable[value.IssueCode]
			if value.BuySell=="1" and productCode=="12" then
				description = sys_format("融券回购%s,%s]成交数量[%s]委托号[%s]",value.IssueCode,issueName,value.ExecQty,value.CorpCode)
			end
		elseif value.OpenClose == 1 then
			description = sys_format("卖出[%s,%s]成交数量[%s]委托号[%s]",value.IssueCode,issueName,value.ExecQty,value.CorpCode)
		end
	elseif value.MarketCode == "3" or value.MarketCode == "4" or value.MarketCode == "5" or value.MarketCode == "6" then
		if value.OpenClose == 0 then
			if value.BuySell == "3" then
				description = sys_format("买开[%s,%s]成交数量[%s]委托号[%s]",value.IssueCode,issueName,value.ExecQty,value.CorpCode)
			elseif value.BuySell == "1" then
				description = sys_format("卖开[%s,%s]成交数量[%s]委托号[%s]",value.IssueCode,issueName,value.ExecQty,value.CorpCode)
			end
		elseif value.OpenClose == 1 or value.OpenClose == 2 then
			if value.BuySell == "3" then
				description = sys_format("买平[%s,%s]成交数量[%s]委托号[%s]",value.IssueCode,issueName,value.ExecQty,value.CorpCode)
			elseif value.BuySell == "1" then
				description = sys_format("卖平[%s,%s]成交数量[%s]委托号[%s]",value.IssueCode,issueName,value.ExecQty,value.CorpCode)
			end
		end
	end
	local amountReceived = 0
	if value.OpenClose == 1 or value.OpenClose == 2 then
		amountReceived = value.ExecAmount
	end
	amountReceived = showFormat(amountReceived,1)
	local amountPayed = 0
	if value.OpenClose == 0 then
		amountPayed = value.ExecAmount
		if value.BuySell=="1" then
			local productCode = _PosIssueProductCodeTable[value.IssueCode]
			if productCode=="12" then
				local faceValue = _PosIssueFaceValueTable[value.IssueCode] or 0
				amountPayed = value.ExecQty * faceValue
			end
		end
	end
	amountPayed = showFormat(amountPayed,1)
	local balance = 0
	if _PosFundStatus[accountCode] then
		balance = _PosFundStatus[accountCode]["AvlFund"]
	end
	balance = showFormat(balance,1)
	local accountTitle = ""
	local accountName = ""
	local currency = "人民币"
	local note = ""
	local execQty = ""
	local execPrice = ""
	local amount = ""
	local fund = ""
	local stockAccount = ""
	local issueCode = value.IssueCode


	local DTSEvent todayFundEvent =_CreateEventObject("TodayFundJournalOutput");
	todayFundEvent._SetFld("Date",date);
	todayFundEvent._SetFld("Description",description);
	todayFundEvent._SetFld("AmountReceived",amountReceived);
	todayFundEvent._SetFld("AmountPayed",amountPayed);
	todayFundEvent._SetFld("Balance",balance);
	todayFundEvent._SetFld("Currency",currency);
	todayFundEvent._SetFld("Note",note);
	todayFundEvent._SetFld("AccountTitle",accountTitle);
	todayFundEvent._SetFld("AccountName",accountName);
	todayFundEvent._SetFld("FundJournalID",fundJournalID);
	todayFundEvent._SetFld("ExecQty",execQty);
	todayFundEvent._SetFld("ExecPrice",execPrice);
	todayFundEvent._SetFld("Amount",amount);
	todayFundEvent._SetFld("Fund",fund);
	todayFundEvent._SetFld("StockAccount",stockAccount);
	todayFundEvent._SetFld("IssueCode",issueCode);
	todayFundEvent._SetFld("IssueName",issueName);
	todayFundEvent._SetFld("AccountCode",accountCode);
	_SendEventToClient(todayFundEvent,gCurSession);
end

_OnCommonData(dataName = "GetPreTradingDate", DTSCalendar cald)
	gPreTradingDate = cald.getDate()
_End

function GetPreTradingDate(date)
	--获取前一个交易日期
	calCondition = "DayOffFlag = '0' and Date < \'" .. date .. "\' ORDER BY Date DESC LIMIT 1"
	_GetCommonData(dataName = "GetPreTradingDate",condition = calCondition,tablename = "Calendar");

	return gPreTradingDate
end

_OnCommonData("readHistoricalOrderDetail1",DTSHistoricalOrderDetail record)
	_WriteAplLog("readHistoricalOrderDetail1...")

	 if not gDeliveryOrderResult1 then
		gDeliveryOrderResult1 = true
	 end

	local baMapID = record.getBAMapID()
	local accountCode = _PosBAMapAccount[baMapID]
	local issueCode = record.getIssueCode()
	local marketCode = record.getMarketCode()
	local buySell = record.getBuySell()
	local openClose = record.getReserveInt1()
	local execQty = record.getExecutionQuantity()	--成交数量
	local execAmount = record.getExecutionValue()
	execAmount = sys_format("%.2f",execAmount)
	local execPrice = record.getExecutionPrice()
	local formatPriceExponent = getPriceFormat(issueCode);
	if execPrice and execPrice ~= "" then
		execPrice = sys_format(formatPriceExponent, execPrice);
	end
	local orderAcceptNo = record.getOrderAcceptNo()
	local date = record.getDataDate()
	local userID = record.getDealerID()				--用户号(交易员)
	local corpCode = record.getCorpCode()			--内部委托号
	local executionNo = record.getExecutionSeqNo()	--成交号
	local orderTime = record.getOrderTime()			--委托时间
	local creRedFlag = record.getGeneralInt2()
	local creRed = record.getGeneralInt1()
	if creRedFlag == 4 or creRedFlag == 5 or creRedFlag == 6 then
		creRed = creRedFlag - 1
	end
	local lt = {}
	lt.BAMapID = baMapID
	lt.IssueCode = issueCode
	lt.MarketCode = marketCode
	lt.BuySell = buySell
	lt.OpenClose = openClose
	lt.ExecQty = execQty
	lt.ExecAmount = execAmount
	lt.ExecPrice = execPrice
	lt.OrderAcceptNo = orderAcceptNo
	lt.UserID = userID
	lt.CorpCode = corpCode
	lt.ExecutionNo = executionNo
	lt.OrderTime = orderTime
	lt.CreRed = creRed

	local log = sys_format("readHistoricalOrderDetail1:IssueCode[%s],Date[%s],OrderTime[%s]",issueCode,date,orderTime)
	_WriteAplLog(log)

	gtDeliveryOrderInfoTable[accountCode] = gtDeliveryOrderInfoTable[accountCode] or {}
	gtDeliveryOrderInfoTable[accountCode][date] = gtDeliveryOrderInfoTable[accountCode][date] or {}
	sys_insert(gtDeliveryOrderInfoTable[accountCode][date],lt)
_End

--发送交割单信息到界面
function sendDeliveryOrderInfo(sessionID,accountCode_input)
	for tmpBaMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
		local accountCode = _PosBAMapAccount[tmpBaMapID]
		if accountCode_input == "全部" or accountCode_input == accountCode then
			if gtDeliveryOrderInfoTable[accountCode] then
				for date,value1 in pairs(gtDeliveryOrderInfoTable[accountCode]) do
					for seq,value in pairs(value1) do

						_WriteAplLog("Enter sendDeliveryOrderInfo1:")
						_WriteAplLog(seq)

						local baMapID = value.BAMapID
						local issueCode = value.IssueCode
						local issueName = _PosIssueNameTable[issueCode]
						local marketCode = value.MarketCode
						local buySell = value.BuySell
						local openClose = value.OpenClose
						local execQty = value.ExecQty
						local execAmount = value.ExecAmount
						local execPrice = value.ExecPrice
						local formatPriceExponent = getPriceFormat(issueCode);
						if execPrice and execPrice ~= "" then
							execPrice = sys_format(formatPriceExponent, execPrice);
						end
						local orderAcceptNo = value.OrderAcceptNo
						local userID = value.UserID
						local corpCode = value.CorpCode
						local executionNo = value.ExecutionNo
						local orderTime = value.OrderTime

						local log = sys_format("sendDeliveryOrderInfo1:date[%s] seq[%s] orderTime[%s] baMapID[%s] issueCode[%s] execQty[%s]",date,seq,orderTime,baMapID,issueCode,execQty)
						_WriteAplLog(log)

						local otherFare = 0
						local marginType = GetMarginType(marketCode,buySell, openClose, 0)
						local note = ""
						if marketCode == "1" or marketCode == "2" then
							note = "证券" .. marginType
						elseif marketCode == "3" or marketCode == "4" or marketCode == "5" or marketCode == "6" then
							note = "期货" .. marginType
						end

						local temp = {}
						temp.BAMapID = baMapID
						temp.IssueCode = issueCode
						temp.OpenClose = openClose
						temp.ExecValue = execAmount
						temp.Quantity =execQty
						temp.ExecQty = execQty
						temp.CreRed = 0
						temp.BS = buySell
						temp.IsInternal = 0
						temp.WithFare = 0
						if orderAcceptNo=="" and executionNo==_PosInternalWithFareExecNo then
							temp.WithFare = 1
						end
						
						local accountCode=_PosBAMapAccount[baMapID] or baMapID
						local fareTable =PosFareDetail(accountCode, temp.IssueCode, temp)
						
												
						local fare = fareTable.Fare	 or 0			--佣金
						local transferExpense = fareTable.TransferExpense	 or 0		--过户费
						local stampTax = fareTable.StampTax		 or 0		--印花税
						local totalFare = fareTable.TotalFare	 or 0		--总费用
						fare = sys_format("%.2f",fare)
						transferExpense = sys_format("%.2f",transferExpense)
						stampTax = sys_format("%.2f",stampTax)

						local changeAmount = execAmount.getNumberValue() + totalFare.getNumberValue()
						changeAmount = sys_format("%.2f",changeAmount)

						local avlFund = 0
						local remainAmount = 0
						local preTradingDate = GetPreTradingDate(date)--前一个交易日
						if gtFundInfoTable[accountCode] then
							if gtFundInfoTable[accountCode][preTradingDate] then
								avlFund = gtFundInfoTable[accountCode][preTradingDate].AvlFund
							end

							if openClose == 0 then
								remainAmount = avlFund - execAmount
							else
								remainAmount = avlFund + execAmount
							end
							if gtFundInfoTable[accountCode][preTradingDate] then
								gtFundInfoTable[accountCode][preTradingDate].AvlFund = remainAmount
							end
						end
						if remainAmount and totalFare then
							remainAmount = remainAmount - totalFare.getNumberValue()
							if remainAmount < 0 then
								remainAmount = avlFund
							end
						end
						remainAmount = sys_format("%.2f",remainAmount)

						local quantity = 0
						local overnightQuantity = 0
						if gtOvernightDataTable[accountCode] then
							if gtOvernightDataTable[accountCode][issueCode] then
								if gtOvernightDataTable[accountCode][issueCode][preTradingDate] then
									overnightQuantity = gtOvernightDataTable[accountCode][issueCode][preTradingDate].OvernightQuantity
									if openClose == 0 then
										quantity = overnightQuantity + execQty
									else
										quantity = overnightQuantity - execQty
									end
									gtOvernightDataTable[accountCode][issueCode][preTradingDate].OvernightQuantity = quantity
								else
									quantity = execQty
								end
							else
								quantity = execQty
							end
						else
							quantity = execQty
						end
						if quantity < 0 then
							quantity = 0
						end
						quantity = showFormat(quantity,2)

						log = sys_format("sendDeliveryOrderInfo1:issueCode[%s] remainAmount[%s] quantity[%s] totalFare[%s]",issueCode,remainAmount,quantity,totalFare)
						_WriteAplLog(log)

						if _PosFundStatus[accountCode] then
							local accountCodeType = _PosFundStatus[accountCode].Type
							if (issueCode ~= POS_LOGIN_CHECK_FUT_ISSUE and issueCode ~= POS_LOGIN_CHECK_STOCK_ISSUE) then
								if accountCodeType == "S" then
									local DTSEvent s_Delivery = _CreateEventObject("S_DeliveryOrderOutput")
									s_Delivery._SetFld("Date", date)
									s_Delivery._SetFld("Note", note)
									s_Delivery._SetFld("IssueCode", issueCode)
									s_Delivery._SetFld("IssueName", issueName)
									s_Delivery._SetFld("MarginType", marginType)
									s_Delivery._SetFld("ExecQty", execQty)
									s_Delivery._SetFld("ExecPrice", execPrice)
									s_Delivery._SetFld("ExecAmount", execAmount)
									s_Delivery._SetFld("Fare", fare)
									s_Delivery._SetFld("StampTax", stampTax)
									s_Delivery._SetFld("TransferExpense", transferExpense)
									s_Delivery._SetFld("ChangeAmount", changeAmount)
									s_Delivery._SetFld("RemainAmount", remainAmount)
									s_Delivery._SetFld("AccountCode", accountCode)
									s_Delivery._SetFld("UserID", userID)
									s_Delivery._SetFld("CorpCode", corpCode)
									s_Delivery._SetFld("ExecutionNo", executionNo)
									s_Delivery._SetFld("Quantity", quantity)
									s_Delivery._SetFld("OtherFare", otherFare)
									s_Delivery._SetFld("OrderTime", orderTime)
									_SendEventToClient(s_Delivery,sessionID);
								elseif accountCodeType == "F" then
									local DTSEvent f_Delivery = _CreateEventObject("F_DeliveryOrderOutput")
									f_Delivery._SetFld("Date", date)
									f_Delivery._SetFld("Note", note)
									f_Delivery._SetFld("IssueCode", issueCode)
									f_Delivery._SetFld("IssueName", issueName)
									f_Delivery._SetFld("MarginType", marginType)
									f_Delivery._SetFld("ExecQty", execQty)
									f_Delivery._SetFld("ExecPrice", execPrice)
									f_Delivery._SetFld("ExecAmount", execAmount)
									f_Delivery._SetFld("Fare", fare)
									f_Delivery._SetFld("ChangeAmount", changeAmount)
									f_Delivery._SetFld("RemainAmount", remainAmount)
									f_Delivery._SetFld("AccountCode", accountCode)
									f_Delivery._SetFld("UserID", userID)
									f_Delivery._SetFld("CorpCode", corpCode)
									f_Delivery._SetFld("ExecutionNo", executionNo)
									f_Delivery._SetFld("Quantity", quantity)
									f_Delivery._SetFld("OtherFare", otherFare)
									f_Delivery._SetFld("OrderTime", orderTime)
				
									_SendEventToClient(f_Delivery,sessionID);
								end
							end
						end
					end
				end
			end
		end
	end
end

--查询交割单
_DefineEventObject QueryDeliveryOrder _AS _Input
	_DefFld("AccountCode", _String, 20);
	_DefFld("StartDate", _String, 8);
	_DefFld("EndDate", _String, 8);
_End

_OnEventDefined(QueryDeliveryOrder deliveryOrder,sessionID)
	gCurSession=sessionID
	local accountCode = deliveryOrder._GetFld("AccountCode");
	local startDate = deliveryOrder._GetFld("StartDate");
	local endDate = deliveryOrder._GetFld("EndDate");

	local log = sys_format("QueryDeliveryOrder:accountCode[%s],startDate[%s],endDate[%s]",accountCode,startDate,endDate)
	_WriteAplLog(log)

	local baMapID = _PosAccountBAMap[accountCode]
	local logs = "";

	gDateCheckResult = false;
	gDeliveryOrderResult1 = false
	gDeliveryOrderResult2 = false
	--发送的记录重新初始化，避免不断累加
	gtDeliveryOrderInfoTable = {}
	local calCondition = "Date = \'" .. startDate .. "\'";
	_GetCommonData(dataName = "StartDateCheck",condition = calCondition,tablename = "Calendar");
	calCondition = "Date = \'" .. endDate .. "\'";
	_GetCommonData(dataName = "EndDateCheck",condition = calCondition,tablename = "Calendar");

	if endDate >= startDate and gDateCheckResult then
		if accountCode == "全部" or (baMapID and (not isDefaultAccount(accountCode))) then
			--查询前先清空
			clearQueryS_DeliveryOrder(sessionID)

			_WriteAplLog("gtRunAccountTable:" )
			if accountCode == "全部" then
				local allBaMapID = ""
				local allAccountCode = ""
				for tmpBaMapID,value in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
					if sys_len(allBaMapID) > 0 then
						allBaMapID = allBaMapID .. ","
					end
					allBaMapID = allBaMapID .. "\'" .. tmpBaMapID .. "\'"

					if sys_len(allAccountCode) > 0 then
						allAccountCode = allAccountCode .. ","
					end
					local tempAccCode = _PosBAMapAccount[tmpBaMapID]
					allAccountCode = allAccountCode .. "\'" .. tempAccCode .. "\'"
				end

				--业务科目代码 10113入金 10213出金
				if sys_len(allAccountCode) > 0 then
					cond = "(AccountTitle = '10113' or AccountTitle = '10213') and (AmountReceived > 0 or AmountPayed > 0) and Date <= \'" .. endDate .. "\' and Date >= \'" .. startDate .. "\' and AccountCode in (" .. allAccountCode..") ORDER BY DTSDate,Time"
					_WriteAplLog(cond)
					_GetCommonData("readHisFundJournalDetail1",condition = cond,tablename = "FundJournal")

					cond = "AccountCode in (" .. allAccountCode .. ")"
					_WriteAplLog(cond)
					_GetCommonData("FundStatus", condition = cond, "FundStatus");
				end

				if sys_len(allBaMapID) > 0 then
					cond = "BAMapID in (" .. allBaMapID .. ")"
					_WriteAplLog(cond)
					_GetCommonData("OvernightData", sqlCondition=cond, "OvernightData");

					cond = "ExecutionQuantity > 0 and DataDate >= \'" .. startDate .. "' and DataDate <= \'" .. endDate .. "\' and BAMapID in (" .. allBaMapID .. ") ORDER BY DataDate,OrderTime ASC"
					_WriteAplLog(cond)
					_GetCommonData("readHistoricalOrderDetail1",condition = cond,"HistoricalOrderDetail")
				end

				--发送交割单信息到界面
				sendDeliveryOrderInfo(sessionID,accountCode)
			else
				local accountCode = _PosBAMapAccount[baMapID]

				--业务科目代码 10113入金 10213出金
				cond = "(AccountTitle = '10113' or AccountTitle = '10213') and (AmountReceived > 0 or AmountPayed > 0) and Date <= \'" .. endDate .. "\' and Date >= \'" .. startDate .. "\' and AccountCode = \'" .. accountCode.."\' ORDER BY DTSDate,Time"
				_WriteAplLog(cond)
				_GetCommonData("readHisFundJournalDetail1",condition = cond,tablename = "FundJournal")

				cond = "AccountCode = \'" .. accountCode .. "\'"
				_WriteAplLog(cond)
				_GetCommonData("FundStatus", condition = cond, "FundStatus");

				cond = "BAMapID = \'" .. baMapID .. "\'"
				_WriteAplLog(cond)
				_GetCommonData("OvernightData", sqlCondition=cond, "OvernightData");

				cond = "ExecutionQuantity > 0 and DataDate >= \'" .. startDate .. "' and DataDate <= \'" .. endDate .. "\' and BAMapID = \'" .. baMapID .. "\' ORDER BY DataDate,OrderTime ASC"
				_WriteAplLog(cond)
				_GetCommonData("readHistoricalOrderDetail1",condition = cond,"HistoricalOrderDetail")

				--发送交割单信息到界面
				sendDeliveryOrderInfo(sessionID,accountCode)
			end

			if (not gDeliveryOrderResult1) and (not gDeliveryOrderResult2) then
				logs = sys_format("理财账户[%s]在该时间范围内无交割单信息,请确认！",accountCode);
				showLog(sessionID,logs);
			end
		elseif isDefaultAccount(accountCode) then
			logs = sys_format("%s不是理财账户",accountCode);
			showLog(sessionID,logs);
		else
			logs = sys_format("您无权查看%s的信息",accountCode);
			showLog(sessionID,logs);
		end
	else
		--Invalid searching condition
		showLog(sessionID,"查询历史委托失败:输入日期错误！");
	end
_End

--读取资金表
_OnCommonData("FundStatus", DTSFundStatus fs)

	local accountCode = fs.getAccountCode()
	local overnightDate = fs.getOvernightDate()
	local avlFund = fs.getAvailableFund()

	gtFundInfoTable[accountCode] = gtFundInfoTable[accountCode] or {}
	gtFundInfoTable[accountCode][overnightDate] = gtFundInfoTable[accountCode][overnightDate] or {}
	gtFundInfoTable[accountCode][overnightDate].AvlFund = avlFund
_End


--读取昨仓表
_OnCommonData("OvernightData", DTSOvernightData overnight)

	local baMapID = overnight.getBAMapID()
	local accountCode = _PosAccountBAMap[baMapID]
	local issueCode = overnight.getIssueCode()
	local overnightDate = overnight.getOvernightDate()
	local overnightQuantity = overnight.getOvernightQuantity()

	if not gtOvernightDataTable[accountCode] then
		gtOvernightDataTable[accountCode] = {}
	end
	if not gtOvernightDataTable[accountCode][issueCode] then
		gtOvernightDataTable[accountCode][issueCode] = {}
	end
	if not gtOvernightDataTable[accountCode][issueCode][overnightDate] then
		gtOvernightDataTable[accountCode][issueCode][overnightDate] = {}
		gtOvernightDataTable[accountCode][issueCode][overnightDate].OvernightQuantity = 0
	end
	gtOvernightDataTable[accountCode][issueCode][overnightDate].OvernightQuantity = gtOvernightDataTable[accountCode][issueCode][overnightDate].OvernightQuantity  + overnightQuantity
_End


_OnCommonData(dataName = "readHisFundJournalDetail1", DTSFundJournal fundJournal)

	local fundJournalID = fundJournal.getFundJournalID()
	local accountCode = fundJournal.getAccountCode()
	local date = fundJournal.getDate()
	local amountReceived = fundJournal.getAmountReceived()	--收入金额
	amountReceived = showFormat(amountReceived,1)

	local amountPayed = fundJournal.getAmountPayed()		--付出金额
	amountPayed = showFormat(amountPayed,1)

	local balance = fundJournal.getBalance()
	balance = showFormat(balance,1)

	local accountTitle = fundJournal.getAccountTitle()
	local orderTime = fundJournal.getTime()

	local note = ""
	local issueCode = "-"
	local issueName = "-"
	local marginType = ""
	local changeAmount = ""
	if accountTitle == "10113" then
		marginType = "入金"
		changeAmount = amountReceived

		note = sys_format("入金[%s]",amountReceived)
	elseif accountTitle == "10213" then
		marginType = "出金"
		changeAmount = amountPayed

		note = sys_format("出金[%s]",amountPayed)
	end

	local execQty = "-"
	local execPrice = "-"
	local execAmount = "-"
	local fare = "-"
	local stampTax = "-"
	local transferExpense = "-"
	local userID = "-"
	local executionNo = "-"
	local quantity = "-"
	local otherFare = "-"

	local log = sys_format("readHisFundJournalDetail1:date[%s],note[%s],amountReceived[%s],amountPayed[%s],balance[%s],accountTitle[%s],fundJournalID[%s],issueCode[%s],issueName[%s]",
							date,note,amountReceived,amountPayed,balance,accountTitle,fundJournalID,issueCode,issueName)
	_WriteAplLog(log)


	if _PosFundStatus[accountCode] then
		local accountCodeType = _PosFundStatus[accountCode].Type
		if accountCodeType == "S" then
			local DTSEvent s_Delivery = _CreateEventObject("S_DeliveryOrderOutput")
			s_Delivery._SetFld("Date", date)
			s_Delivery._SetFld("Note", note)
			s_Delivery._SetFld("IssueCode", issueCode)
			s_Delivery._SetFld("IssueName", issueName)
			s_Delivery._SetFld("MarginType", marginType)
			s_Delivery._SetFld("ExecQty", execQty)
			s_Delivery._SetFld("ExecPrice", execPrice)
			s_Delivery._SetFld("ExecAmount", execAmount)
			s_Delivery._SetFld("Fare", fare)
			s_Delivery._SetFld("StampTax", stampTax)
			s_Delivery._SetFld("TransferExpense", transferExpense)
			s_Delivery._SetFld("ChangeAmount", changeAmount)
			s_Delivery._SetFld("RemainAmount", balance)
			s_Delivery._SetFld("AccountCode", accountCode)
			s_Delivery._SetFld("UserID", userID)
			s_Delivery._SetFld("CorpCode", fundJournalID)
			s_Delivery._SetFld("ExecutionNo", executionNo)
			s_Delivery._SetFld("Quantity", quantity)
			s_Delivery._SetFld("OtherFare", otherFare)
			s_Delivery._SetFld("OrderTime", orderTime)
			_SendEventToClient(s_Delivery,gCurSession);
		elseif accountCodeType == "F" then
			local DTSEvent f_Delivery = _CreateEventObject("F_DeliveryOrderOutput")
			f_Delivery._SetFld("Date", date)
			f_Delivery._SetFld("Note", note)
			f_Delivery._SetFld("IssueCode", issueCode)
			f_Delivery._SetFld("IssueName", issueName)
			f_Delivery._SetFld("MarginType", marginType)
			f_Delivery._SetFld("ExecQty", execQty)
			f_Delivery._SetFld("ExecPrice", execPrice)
			f_Delivery._SetFld("ExecAmount", execAmount)
			f_Delivery._SetFld("Fare", fare)
			f_Delivery._SetFld("ChangeAmount", changeAmount)
			f_Delivery._SetFld("RemainAmount", balance)
			f_Delivery._SetFld("AccountCode", accountCode)
			f_Delivery._SetFld("UserID", userID)
			f_Delivery._SetFld("CorpCode", fundJournalID)
			f_Delivery._SetFld("ExecutionNo", executionNo)
			f_Delivery._SetFld("Quantity", quantity)
			f_Delivery._SetFld("OtherFare", otherFare)
			f_Delivery._SetFld("OrderTime", orderTime)
			_SendEventToClient(f_Delivery,gCurSession);
		end
	end
_End


--查询历史资产
_DefineEventObject QueryHistoryFund _AS _Input
	_DefFld("AccountCode", _String, 20);
	_DefFld("StartDate", _String, 8);
	_DefFld("EndDate", _String, 8);
_End

_OnEventDefined(QueryHistoryFund deliveryOrder,sessionID)
	gCurSession=sessionID
	local accountCode = deliveryOrder._GetFld("AccountCode");
	local startDate = deliveryOrder._GetFld("StartDate");
	local endDate = deliveryOrder._GetFld("EndDate");

	local log = sys_format("QueryHistoryFund:accountCode[%s],startDate[%s],endDate[%s]",accountCode,startDate,endDate)
	_WriteAplLog(log)

	local baMapID = _PosAccountBAMap[accountCode]
	local logs = "";


	if endDate >= startDate then
		if accountCode == "全部" or (baMapID and (not isDefaultAccount(accountCode))) then
			--查询前先清空
			clearQueryS_HistoryFund(sessionID)
			clearQueryS_HistoryPos(sessionID)
			gtHistoryOvernightData={}
			gtHistoryFundStatus={}
			_WriteAplLog("gtRunAccountTable:" )
			if accountCode == "全部" then
				local allBaMapID = ""
				local allAccountCode = ""
				for tmpBaMapID,value in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
					local isS=true
					local tmpAccountCode=tmpBaMapID
					if _PosBAMapAccount[tmpBaMapID] then
						tmpAccountCode=_PosBAMapAccount[tmpBaMapID]
					end
					if _PosFundStatus[tmpAccountCode] then
						if _PosFundStatus[tmpAccountCode].Type=="F" then
							isS=false
						end
					end
					if 	isS	 then
						if sys_len(allBaMapID) > 0 then
							allBaMapID = allBaMapID .. ","
						end
						allBaMapID = allBaMapID .. "\'" .. tmpBaMapID .. "\'"

						if sys_len(allAccountCode) > 0 then
							allAccountCode = allAccountCode .. ","
						end
						local tempAccCode = _PosBAMapAccount[tmpBaMapID]
						allAccountCode = allAccountCode .. "\'" .. tempAccCode .. "\'"
					end
				end


				if sys_len(allAccountCode) > 0 then
					local cond =sys_format("AccountCode in (%s) and  OvernightDate>='%s' and  OvernightDate<='%s'",allAccountCode,startDate,endDate)
					_WriteAplLog(cond)
					_GetCommonData("HistoryFundStatus", condition = cond, "FundStatus");
				end

				if sys_len(allBaMapID) > 0 then
					local cond = sys_format("BAMapID in (%s) and  OvernightDate>='%s' and  OvernightDate<='%s'",allBaMapID,startDate,endDate)
					_WriteAplLog(cond)
					_GetCommonData("HistoryOvernightData", sqlCondition=cond, "OvernightData");
				end
			else
				local accountCode = _PosBAMapAccount[baMapID]
				local cond = sys_format("AccountCode ='%s' and  OvernightDate>='%s' and  OvernightDate<='%s'",accountCode,startDate,endDate)
				_WriteAplLog(cond)
				_GetCommonData("HistoryFundStatus", condition = cond, "FundStatus");

				cond = sys_format("BAMapID ='%s' and  OvernightDate>='%s' and  OvernightDate<='%s'",baMapID,startDate,endDate)
				_WriteAplLog(cond)
				_GetCommonData("HistoryOvernightData", sqlCondition=cond, "OvernightData");
			end
			for date,v1 in pairs(gtHistoryOvernightData) do
				for poskey,v2 in pairs(gtHistoryOvernightData[date]) do
					local reserveString=""
					local DTSEvent evt =_CreateEventObject("S_HistoryPosOutput");
					local baMapID=v2.BAMapID
					evt._SetFld("BAMapID",baMapID);
					local date=v2.Date
					evt._SetFld("Date",date);
					local issueCode=v2.IssueCode
					evt._SetFld("IssueCode",issueCode);
					local issueName=""
					if _PosIssueNameTable[issueCode] then
						issueName=_PosIssueNameTable[issueCode]
					end
					evt._SetFld("IssueName",issueName);
					local quantity=v2.Quantity
					local strQuantity=sys_format("%d",quantity)
					evt._SetFld("Quantity",strQuantity);

					local sPLITQuantity=v2.SPLITQuantity
					if sPLITQuantity>0 then
						reserveString=sys_format("送股%d",sPLITQuantity)
					end
					local amount=v2.Amount
					local strAmount=sys_format("%.2f",amount)
					evt._SetFld("Amount",strAmount);
					local ratio1=""
					if gtHistoryFundStatus[date] then
						local accountCode=baMapID
						if _PosBAMapAccount[baMapID] then
							accountCode=_PosBAMapAccount[baMapID]
						end
						if gtHistoryFundStatus[date][accountCode] then
							local assetValue=gtHistoryFundStatus[date][accountCode].AssetValue
							ratio1= 100*amount/assetValue;
							ratio1=sys_format("%.2f",ratio1)
						end
					end
					evt._SetFld("Ratio1",ratio1);
					local contractSize = 1
					if _PosIssueContractSizeTable[issueCode] then
						contractSize = _PosIssueContractSizeTable[issueCode]
					end
					local cost=amount/contractSize/quantity
					local formatPriceExponent = getPriceFormat(issueCode);
					local costPrice = sys_format(formatPriceExponent, cost);
					evt._SetFld("Cost",costPrice);
					local buySell=v2.BuySell
					local baSubID=v2.BASubID
					evt._SetFld("BASubID",baSubID);
					gHistoricalPrice=""
					local con=sys_format("IssueCode='%s' and DataDate='%s'",issueCode,date)
					_GetCommonData("GetHistoricalPriceTable", sqlCondition=con, "HistoricalPrice");
					if gHistoricalPrice~="" then
						evt._SetFld("LastPrice",gHistoricalPrice);
						local valuationPL=(gHistoricalPrice-cost)*contractSize*quantity
						if buySell=="1" then
							valuationPL=0-valuationPL
						end
						valuationPL = sys_format(formatPriceExponent, valuationPL);
						evt._SetFld("ValuationPL",valuationPL);
						local marketValue=gHistoricalPrice*contractSize*quantity
						local strmarketValue = sys_format(formatPriceExponent, marketValue);
						evt._SetFld("MarketValue",strmarketValue);
						local ratio2=""
						if gtHistoryFundStatus[date] then
							local accountCode=baMapID
							if _PosBAMapAccount[baMapID] then
								accountCode=_PosBAMapAccount[baMapID]
							end
							if gtHistoryFundStatus[date][accountCode] then
								local assetValue=gtHistoryFundStatus[date][accountCode].AssetValue
								ratio2= 100*marketValue/assetValue;
								ratio2=sys_format("%.2f",ratio2)
							end
						end
						evt._SetFld("Ratio2",ratio2);
					else
						evt._SetFld("LastPrice","");
						evt._SetFld("ValuationPL","");
						evt._SetFld("MarketValue","");
						evt._SetFld("Ratio2","");
					end
					local marketCode = _PosIssueMarketTable[issueCode] or ""
					--市场名
					local marketName = gtMarketNameTable[marketCode] or ""
					evt._SetFld("MarketName",marketName);
					local productCode = _PosIssueProductCodeTable[issueCode]
					if buySell=="1" and productCode=="12" then
						local faceValue = _PosIssueFaceValueTable[issueCode]
						evt._SetFld("Cost",faceValue);
						evt._SetFld("LastPrice","");
						evt._SetFld("ValuationPL","");
						local marketValue=faceValue*quantity
						if gtHistoryFundStatus[date] then
							local accountCode=baMapID
							if _PosBAMapAccount[baMapID] then
								accountCode=_PosBAMapAccount[baMapID]
							end
							if gtHistoryFundStatus[date][accountCode] then
								gtHistoryFundStatus[date][accountCode].BondRepValue=gtHistoryFundStatus[date][accountCode].BondRepValue+marketValue
							end
						end
						marketValue = sys_format(formatPriceExponent, marketValue);
						evt._SetFld("Amount",marketValue);
						evt._SetFld("MarketValue",marketValue);
						evt._SetFld("Ratio1","");
						evt._SetFld("Ratio2","");
						local estInterest=_PosGetBondRepEstInterest(issueCode, cost, quantity)
						reserveString=sys_format("融券回购:利率[%.2f%%]预估利息[%.2f]",cost,estInterest)
					end
					evt._SetFld("ReserveString",reserveString);
					_SendEventToClient(evt,sessionID);
				end
			end
			for date,v1 in pairs(gtHistoryFundStatus) do
				for accountCode,v2 in pairs(gtHistoryFundStatus[date]) do
					local accountCode=v2.AccountCode
					local overnightDate=v2.Date
					local basePriceLastPL=v2.BasePriceLastPL
					local basePricePL=v2.BasePricePL
					local avlFund=v2.AvlFund
					local bailBalance=v2.BailBalance
					local profitFloat=v2.ProfitFloat
					local assetValue=v2.AssetValue
					local fare=v2.Fare
					local bondRepValue=v2.BondRepValue
					local stockValue=bailBalance+profitFloat-bondRepValue
					local position=0
					if assetValue>0.001 or assetValue<-0.001 then
						position=100*stockValue/assetValue
					end
					local baMapID=accountCode
					if _PosAccountBAMap[accountCode] then
						baMapID=_PosAccountBAMap[accountCode]
					end
					local share=0
					local Nav=""
					if gtZGProductAccountTable[baMapID] then
						if gtZGProductAccountTable[baMapID].Share and gtZGProductAccountTable[baMapID].Share~="" then
							share=gtZGProductAccountTable[baMapID].Share
							if share>0 then
								Nav=assetValue/share
								Nav=sys_format("%.4f",Nav)
							end
						end
					end
					basePriceLastPL=sys_format("%.2f",basePriceLastPL)
					basePricePL=sys_format("%.2f",basePricePL)
					avlFund=sys_format("%.2f",avlFund)
					profitFloat=sys_format("%.2f",profitFloat)
					assetValue=sys_format("%.2f",assetValue)
					bondRepValue=sys_format("%.2f",bondRepValue)
					stockValue=sys_format("%.2f",stockValue)
					fare=sys_format("%.2f",fare)
					position=sys_format("%.2f",position)
					local DTSEvent evt =_CreateEventObject("S_HistoryFundOutput");
					evt._SetFld("AccountCode",accountCode);
					evt._SetFld("Date",overnightDate);
					evt._SetFld("BasePriceLastPL",basePriceLastPL);
					evt._SetFld("BasePricePL",basePricePL);
					evt._SetFld("AvlFund",avlFund);
					evt._SetFld("ProfitFloat",profitFloat);
					evt._SetFld("AssetValue",assetValue);
					evt._SetFld("Position",position);
					evt._SetFld("BondRepValue",bondRepValue);
					evt._SetFld("StockValue",stockValue);
					evt._SetFld("Nav",Nav);
					evt._SetFld("Share",share);
					evt._SetFld("Fare",fare);
					_SendEventToClient(evt,sessionID);
				end
			end
		elseif isDefaultAccount(accountCode) then
			logs = sys_format("%s不是理财账户",accountCode);
			showLog(sessionID,logs);
		else
			logs = sys_format("您无权查看%s的信息",accountCode);
			showLog(sessionID,logs);
		end
	else
		showLog(sessionID,"查询历史资产失败:输入日期错误！");
	end
_End

_OnCommonData("HistoryFundStatus", DTSFundStatus fs)

	local accountCode = fs.getAccountCode()
	local overnightDate = fs.getOvernightDate()
	local basePriceLastPL = fs.getBasePriceLastPL()
	local basePricePL = fs.getBasePricePL()
	local avlFund = fs.getAvailableFund()
	local fare = fs.getFareTotal()
	local bailBalance = fs.getBailBalance()
	local profitFloat = fs.getProfitFloat()
	local assetValue=basePricePL+profitFloat
	gtHistoryFundStatus[overnightDate]=gtHistoryFundStatus[overnightDate] or {}
	local lt={}
	lt.AccountCode=accountCode
	lt.Date=overnightDate
	lt.BasePriceLastPL=basePriceLastPL
	lt.BasePricePL=basePricePL
	lt.AvlFund=avlFund
	lt.Fare=fare
	lt.BailBalance=bailBalance
	lt.ProfitFloat=profitFloat
	lt.AssetValue=assetValue
	lt.BondRepValue=0
	gtHistoryFundStatus[overnightDate][accountCode]=lt
_End

_OnCommonData("HistoryOvernightData", DTSOvernightData overnight)
	local baMapID = overnight.getBAMapID()
	local baSubID = overnight.getBASubID()
	local issueCode = overnight.getIssueCode()
	local overnightDate = overnight.getOvernightDate()
	local overnightQuantity = overnight.getOvernightQuantity()
	local overnightPrice = overnight.getOvernightPrice()
	local buySell = overnight.getBuySell()
	local executionDate = overnight.getExecutionDate()
	local executionKeyCode = overnight.getExecutionKeyCode()
	local isSPLIT=false
	if executionDate==overnightDate and executionKeyCode~="" then
		if sys_sub(executionKeyCode,1,5)=="SPLIT" then
			isSPLIT=true
		end
	end
	local poskey=baMapID.."."..baSubID.."."..issueCode
	gtHistoryOvernightData[overnightDate]=gtHistoryOvernightData[overnightDate] or {}


	if not gtHistoryOvernightData[overnightDate][poskey] then
		gtHistoryOvernightData[overnightDate][poskey]={}
		gtHistoryOvernightData[overnightDate][poskey].BAMapID=baMapID
		gtHistoryOvernightData[overnightDate][poskey].Date=overnightDate
		gtHistoryOvernightData[overnightDate][poskey].IssueCode=issueCode
		gtHistoryOvernightData[overnightDate][poskey].Quantity=overnightQuantity
		gtHistoryOvernightData[overnightDate][poskey].BuySell=buySell
		gtHistoryOvernightData[overnightDate][poskey].SPLITQuantity=0
		if isSPLIT then
			gtHistoryOvernightData[overnightDate][poskey].SPLITQuantity=overnightQuantity
		end
		local contractSize = 1
		if _PosIssueContractSizeTable[issueCode] then
			contractSize = _PosIssueContractSizeTable[issueCode]
		end
		local amount=overnightQuantity*overnightPrice*contractSize
		gtHistoryOvernightData[overnightDate][poskey].Amount=amount
		gtHistoryOvernightData[overnightDate][poskey].BASubID=baSubID
	else
		local quantity=gtHistoryOvernightData[overnightDate][poskey].Quantity
		quantity=quantity+overnightQuantity
		gtHistoryOvernightData[overnightDate][poskey].Quantity=quantity
		local contractSize = 1
		if _PosIssueContractSizeTable[issueCode] then
			contractSize = _PosIssueContractSizeTable[issueCode]
		end
		local amount=gtHistoryOvernightData[overnightDate][poskey].Amount
		amount=amount+overnightQuantity*overnightPrice*contractSize
		gtHistoryOvernightData[overnightDate][poskey].Amount=amount
		if isSPLIT then
			gtHistoryOvernightData[overnightDate][poskey].SPLITQuantity=gtHistoryOvernightData[overnightDate][poskey].SPLITQuantity+overnightQuantity
		end
	end
_End
_OnCommonData("GetHistoricalPriceTable", DTSHistoricalPrice evt)
	gHistoricalPrice = evt.getAdjustedClosePrice()
_End
--清空历史委托信息表
function clearHistorySubmitInfo(sessionID)
	local DTSEvent clear = _CreateEventObject("HistorySubmitOutput")
	clear._SetFld("IssueCode","clearData")
	_SendEventToClient(clear,sessionID);
end

--清空历史成交信息表
function clearHistoryExecutionInfo(sessionID)
	local DTSEvent hisExecEvent =_CreateEventObject("HistoryExecutionOutput");
	hisExecEvent._SetFld("IssueCode","clearData");
	_SendEventToClient(hisExecEvent,sessionID);
end

--清空当日资金明细表
function clearTodayFundJournalInfo(sessionID)
	local DTSEvent todayFundEvent =_CreateEventObject("TodayFundJournalOutput");
	todayFundEvent._SetFld("IssueCode","clearData");
	_SendEventToClient(todayFundEvent,sessionID);
end

--清空历史资金明细表
function clearHistoryFundJournalInfo(sessionID)
	local DTSEvent hisFundEvent =_CreateEventObject("HistoryFundJournalOutput");
	hisFundEvent._SetFld("IssueCode","clearData");
	_SendEventToClient(hisFundEvent,sessionID);
end

--清空交割单表
function clearQueryS_DeliveryOrder(sessionID)
	local DTSEvent s_DeliveryEvent =_CreateEventObject("S_DeliveryOrderOutput");
	s_DeliveryEvent._SetFld("IssueCode","clearData");
	_SendEventToClient(s_DeliveryEvent,sessionID);
end

--清空交割单表
function clearQueryF_DeliveryOrder(sessionID)
	local DTSEvent f_DeliveryEvent =_CreateEventObject("F_DeliveryOrderOutput");
	f_DeliveryEvent._SetFld("IssueCode","clearData");
	_SendEventToClient(f_DeliveryEvent,sessionID);
end

function clearQueryS_HistoryFund(sessionID)
	local DTSEvent evt =_CreateEventObject("S_HistoryFundOutput");
	evt._SetFld("AccountCode","clearData");
	_SendEventToClient(evt,sessionID);
end
function clearQueryS_HistoryPos(sessionID)
	local DTSEvent evt =_CreateEventObject("S_HistoryPosOutput");
	evt._SetFld("IssueCode","clearData");
	_SendEventToClient(evt,sessionID);
end
--解析费用
function calReserveString(reservestring)
	local fare = 0
	local length = sys_len(reservestring);
	for i = 2 , length do
		if sys_sub(reservestring,i,i)=="|" then
			fare = sys_sub(reservestring,1,i-1);
			break
		end
	end
	return fare
end

--判断帐号代码是否为投资者帐号
function isDefaultAccount(accountCode)
	local size = sys_len(accountCode);
	local flag = sys_sub(accountCode,size-2,-1)	--get the last 3 character of the account code
	if flag == "000" or flag == "999" or flag == "ZZZ" then
		--this account is an Investor account
		return true;
	else
		return false;
	end
end

--获取委托类型名称
function GetOrderTypeName(orderType)
	local log = sys_format("GetOrderTypeName, orderType=[%s]", orderType)
	_WriteAplLog(log)

	local tmpOrderType = ""
	if orderType == "" then
		tmpOrderType = "限价委托"
	elseif orderType == "U" then
		tmpOrderType = "对方最优价"
	elseif orderType == "V" then
		tmpOrderType = "本方最优价"
	elseif orderType == "H" then
		tmpOrderType = "五档即成剩撤"
	elseif orderType == "I" then
		tmpOrderType = "五档即成转限价"
	elseif orderType == "W" then
		tmpOrderType = "即时成交剩撤"
	elseif orderType == "X" then
		tmpOrderType = "五档即成剩撤"
	elseif orderType == "Y" then
		tmpOrderType = "全额成交或撤销"
	elseif orderType == "F" then
		tmpOrderType = "市价"
	else
		tmpOrderType = "无法识别"
	end
	_WriteAplLog(tmpOrderType)
	return tmpOrderType
end

--==========================================
--资管风控状态返回
--==========================================
function OnOrderStatusFromRisk(lt)
	local strbuysell=lt.BuySell;
	if strbuysell=="3" then
		strbuysell="买"
	elseif strbuysell=="1" then
		strbuysell="卖"
	end
	local ordermessageid=lt.OrderMessageID
	local Strbamapid = sys_sub(ordermessageid,2,10)
	local pcid = lt.PositionCheckID
	if lt.Status =="风控拒绝" or lt.Status =="非法" or lt.Status =="审批拒绝" or lt.Status =="下单失败" or lt.Status =="用户锁定" then
		if lt.MsgType == "3" then	--撤单
			--已报待撤变成挂单，并刷新委托表状态
			local corpCode = _PosPCIDCorpCodeTable[pcid]
			if gtShowOrderTable[corpCode] then
				local log = sys_format("内部委托号[%s]撤单指令风控拒绝：原因:%s",corpCode,lt.ReserveString)
				if gtOrderSessionTable[pcid] then
					local sessionID=gtOrderSessionTable[pcid]
					showLog(sessionID,log)
				end
			end
		else--非撤单
			local log = sys_format("指令未报出,委托号[%s]：状态[%s],理财账户[%s],合约[%s],买卖[%s],数量[%d],原因：%s",lt.PositionCheckID,lt.Status,Strbamapid,lt.IssueCode,strbuysell,lt.Quantity,lt.ReserveString)
			if gtOrderSessionTable[pcid] then
				local sessionID=gtOrderSessionTable[pcid]
				showLog(sessionID,log)
			end
			--风控拒绝的单子也显示在当日委托中
			local baMapID = lt.BAMapID
			local orderTime = lt.OrderTime
			--设置委托时间
			--local lggg = sys_format("function OnOrderStatusFromRisk:orderTime[%s]",orderTime)
			--_WriteAplLog(lggg)
			if orderTime and orderTime ~= "" then
				orderTime = changeOrderTime(orderTime)
				orderTime = sys_sub(orderTime,9,-1)
			else
				orderTime = GetHMS()
			end
			orderTime = showFormat(orderTime,3)
			_WriteAplLog(orderTime)
			local issueCode = lt.IssueCode
			local marketCode = _PosIssueMarketTable[issueCode]
			local marketName = gtMarketNameTable[marketCode]
			local issueName = _PosIssueNameTable[issueCode]
			--交易类型
			local marginType = GetMarginType(marketCode,lt.BuySell, lt.OpenClose, lt.CreRed)
			local orderPrice = lt.Price
			local orderQty = lt.Quantity
			if orderQty and orderQty ~= "" then
				orderQty = showFormat(orderQty,2)
			end
			local status = lt.Status
			local corpCode = lt.CorpCode
			if not corpCode or corpCode == "" then
				corpCode = lt.PositionCheckID
			end

			local ret = {}
			ret.IssueCode = issueCode
			ret.MarketCode = marketCode
			ret.Status = status
			ret.MarginType = marginType
			ret.BuySell = lt.BuySell
			ret.OrderPrice = orderPrice
			ret.Quantity = orderQty
			ret.ExecQty = 0
			ret.WorkingQuantity = 0
			ret.CancelQty = 0
			ret.OrderTime = orderTime
			ret.BAMapID = baMapID
			ret.Fare = 0
			ret.CorpCode = corpCode
			ret.CreRed = lt.CreRed
			ret.OpenClose = lt.OpenClose
			ret.PositionCheckID= lt.PositionCheckID
			ret.BatchID=lt.BatchID
			gtShowOrderTable[corpCode] = ret		
			gtRiskRefuseReason[corpCode]=lt.ReserveString or ""
			if status=="非法" then	
				ret.Status="风控拒绝"
				if gChangeErrorInfo then
					gtRiskRefuseReason[corpCode]="10062"
				end
			end
			RefreshSingleOrder("All",corpCode,ret)
			if gReSubMitRefuseOrder then
				if gtOrderSessionTable[pcid] then
					local sessionID=gtOrderSessionTable[pcid]
					if status =="风控拒绝" or status =="非法" then 
						if lt.BatchID then
							if gtAllRefuseBAMap[lt.BatchID] then
								gtAllRefuseBAMap[lt.BatchID][baMapID]=1
								local log = sys_format("%s重下 bAMapID=%s,issueCode=%s,buySell=%s,openClose=%s,orderPrice=%s,orderQty=%s,baSubID=%s,creRed=%s,batchID=%s",
									status,baMapID,lt.IssueCode, lt.BuySell, lt.OpenClose, lt.Price, lt.Quantity,lt.BASubID, lt.CreRed,lt.BatchID)
								_WriteAplLog(log)
								local oc= lt.OpenClose
								local quantity= lt.Quantity
								local creRed=lt.CreRed or 0
								oc=oc.getNumberValue();
								quantity=quantity.getNumberValue()
								creRed=creRed.getNumberValue()
								SendOrder_All(sessionID,lt.IssueCode, lt.BuySell,oc, lt.Price,quantity,"", lt.BASubID,creRed,lt.BatchID)
							end
						end
					end 
				end
			end
		end
	elseif lt.Status =="下单"  then
		--撤单
		if lt.MsgType == "3" then
			local log = sys_format("风控通过，撤单指令已报出：内部委托号[%s]",lt.CorpCode)
			if gtOrderSessionTable[pcid] then
				local sessionID=gtOrderSessionTable[pcid]
				showLog(sessionID,log)
			end
		else--非撤单
			local log = sys_format("风控通过，下单指令已报出：委托号[%s],状态[%s],理财账户[%s],合约[%s],买卖[%s],数量[%d]",lt.PositionCheckID,lt.Status,Strbamapid,lt.IssueCode,strbuysell,lt.Quantity)
			if gtOrderSessionTable[pcid] then
				local sessionID=gtOrderSessionTable[pcid]
				showLog(sessionID,log)
			end
		end
	end
end

_OnReceiveUnifieldMessage("BROADCASTMSG", "Broadcast_Investor", DTSUnifieldMessage srcMsg)
    _WriteAplLog("Receive message Broadcast_Investor")
	local investorID = ""
	local baMapID = ""
	local clientID = ""
	local investorType = ""
	local userID = ""

	srcMsg. first()
    while not srcMsg.eof() do --实际只会进来一次
		investorID = srcMsg.getValueByName("InvestorID")
		baMapID = srcMsg.getValueByName("BAMapID")
		clientID = srcMsg.getValueByName("ClientID")
		investorType = srcMsg.getValueByName("InvestorType")
		userID = srcMsg.getValueByName("UserID")
		local log1 = sys_format("BROADCASTMSG Info: %s, %s, %s, %s, %s", investorID, baMapID, clientID, investorType, userID)
        _WriteAplLog(log1)

		if not _PosBAMapUserTable[baMapID] then
			local log = sys_format("Receive Info: %s, %s, %s, %s, %s", investorID, baMapID, clientID, investorType, userID)
			_WriteAplLog(log)
			PosSyncReceiveInvestor(investorID,baMapID,clientID)
			PosRefreshTransferFund()
	   end
        srcMsg.next()
    end
    srcMsg.clear()

_End
_OnReceiveUnifieldMessage("onAdjust_PL", "Adjust_PL", DTSUnifieldMessage srcMsg)
	srcMsg.first()
	while not srcMsg.eof() do 
         local baMapID = srcMsg.getValueByName("BAMapID") 
		 local bASubID = srcMsg.getValueByName("BASubID") 
		 local issueCode = srcMsg.getValueByName("IssueCode") 		 
		 local posKey=baMapID.."."..bASubID.."."..issueCode
		local pos=_PosPositionTable[posKey]
		if pos then
			local log=sys_format("onAdjust_PL posKey:%s",posKey)
			_WriteAplLog(log) 	
			PosRefreshCumulationAdjustPL(baMapID,bASubID,issueCode)
			
			
			for sessionID,v in pairs(gtSessionTable) do 
				if gtSessionTable[sessionID].CurBAMapIDTable then
					if gtSessionTable[sessionID].SelectedBAMapID == "全部" and gtSessionTable[sessionID].CurBAMapIDTable[pos.BAMapID] then					
						CalPos_IssueCode(sessionID,pos)
						RefreshPosition(sessionID,gtSessionTable[sessionID].PositionTable[pos.IssueCode])
						--发送持仓汇总记录
						SendPos_SumData(sessionID)
						--刷新账户资金信息
						RefreshFundInfo(sessionID,"other")
						RefreshMultiFireFundInfo(sessionID,"other")
					elseif pos.BAMapID == gtSessionTable[sessionID].SelectedBAMapID then
						--刷新持仓
						RefreshPosition(sessionID,pos)
						--发送持仓汇总记录
						SendPos_SumData(sessionID)
						--刷新账户资金信息
						RefreshFundInfo(sessionID,"other")
						RefreshMultiFireFundInfo(sessionID,"other")
					end
				end
			end			
		end
        srcMsg.next()
    end
	srcMsg.clear()
_End
---收到资金变更信息后刷新资金账户信息
_OnReceiveUnifieldMessage("POSTRANSFERMSG", "POS_BROADCAST_TRANSFERFUND", DTSUnifieldMessage srcMsg)

    _WriteAplLog("Begin POS_BROADCAST_TRANSFERFUND")
    --完成出入金操作后刷新出入金记录
    local strBAMapIDs = ""
    srcMsg.first()
    while not srcMsg.eof() do --实际只会进来一次
         strBAMapIDs = srcMsg.getValueByName("BAMapIDs") --获取要刷新的理财账户列表
         srcMsg.next()
    end
    srcMsg.clear()

    --解析理财账户列表，刷新各自策略资金表界面数据
    --strBAMapIDs就是accountCode
    local returnTable = PosGetTransferBAMapsTable(strBAMapIDs)
	local isvalid=false
    for seq, baMapID in pairs(returnTable) do
		if _PosBAMapTable[baMapID] then
			isvalid=true
		end
	end
	if isvalid then
		PosRefreshTransferFund()
		--刷新账户资金信息
		for sessionID,v in pairs(gtSessionTable) do 
			 for seq, baMapID in pairs(returnTable) do
				if gtSessionTable[sessionID].CurBAMapIDTable then
					if gtSessionTable[sessionID].CurBAMapIDTable[baMapID] then
						RefreshFundInfo(sessionID,"other")
						RefreshMultiFireFundInfo(sessionID,"other")
					end
				end
				break 
			 end
		end	
		
    end
_End

function GetPTWTFreshTimer()
	gPTWTFreshTimer = 90
	local GlobalVariableTableSql = "VariableName = 'PTWTFreshTimer'"
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "PTWTFreshTimer", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end

_OnCommonData(dataName = "PTWTFreshTimer", DTSGlobalVariable evt)
	_WriteAplLog("PTWTFreshTimer")
	local i = evt.getVariableValue()
	local log = sys_format("PTWTFreshTimer : %s" ,i)
	_WriteAplLog(log)
	if isNumBer(i) then
		gPTWTFreshTimer=i.getNumberValue()
	end
_End

function GetInternalExecShowMode()
	gInternalExecShowMode = ""
	local currentUserID= _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'InternalExecShowMode%s'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "InternalExecShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	if gInternalExecShowMode=="" then
		GlobalVariableTableSql = "VariableName = 'InternalExecShowMode'"
		_WriteAplLog(GlobalVariableTableSql)
		_GetCommonData(dataName = "InternalExecShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	else
		if gInternalExecShowMode=="0" then
			gInternalExecShowMode="1"
		else
			gInternalExecShowMode="0"
		end
	end
end

_OnCommonData(dataName = "InternalExecShowMode", DTSGlobalVariable evt)
	_WriteAplLog("InternalExecShowMode")
	gInternalExecShowMode = evt.getVariableValue()
	local log = sys_format("InternalExecShowMode : %s" ,gInternalExecShowMode)
	_WriteAplLog(log)
_End

function GetReSubMitRefuseOrderMode1()
	local GlobalVariableTableSql = "VariableName = 'ReSubMitRefuseOrderMode'"
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetReSubMitRefuseOrderMode1", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end
_OnCommonData(dataName = "GetReSubMitRefuseOrderMode1", DTSGlobalVariable evt)
	_WriteAplLog("GetReSubMitRefuseOrderMode1")
	local variableValue = evt.getVariableValue()
	local log = sys_format("GetReSubMitRefuseOrderMode1 : %s" ,variableValue)
	_WriteAplLog(log)
	if variableValue=="1" then
		gReSubMitRefuseOrder=true
	else
		gReSubMitRefuseOrder=false
	end
_End
function GetReSubMitRefuseOrderMode2()
	local currentUser= _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'ReSubMitRefuseOrderMode%s'",currentUser)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetReSubMitRefuseOrderMode2", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end
_OnCommonData(dataName = "GetReSubMitRefuseOrderMode2", DTSGlobalVariable evt)
	_WriteAplLog("GetReSubMitRefuseOrderMode2")
	local variableValue = evt.getVariableValue()
	local log = sys_format("GetReSubMitRefuseOrderMode2 : %s" ,variableValue)
	_WriteAplLog(log)
	-- 如果没设置个人项就不处理按环境项执行
	if variableValue~="" then
		if variableValue=="1" then
			gReSubMitRefuseOrder=true
		else
			gReSubMitRefuseOrder=false
		end
	end
_End

function GetShowReSubMitRefuseOrder()
	gShowReSubMitRefuseOrder="" --是否显示拒绝重下的委托,0不显示,1显示
	local currentUserID= _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'ShowReSubMitRefuseOrder%s'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "ShowReSubMitRefuseOrder", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	if gShowReSubMitRefuseOrder=="" then
		GlobalVariableTableSql = "VariableName = 'ShowReSubMitRefuseOrder'"
		_WriteAplLog(GlobalVariableTableSql)
		_GetCommonData(dataName = "ShowReSubMitRefuseOrder", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	end
	if gShowReSubMitRefuseOrder~="0" then
		gShowReSubMitRefuseOrder="1"
	end
end
_OnCommonData(dataName = "ShowReSubMitRefuseOrder", DTSGlobalVariable evt)
	_WriteAplLog("ShowReSubMitRefuseOrder")
	gShowReSubMitRefuseOrder = evt.getVariableValue()
	local log = sys_format("ShowReSubMitRefuseOrder : %s" ,gShowReSubMitRefuseOrder)
	_WriteAplLog(log)
_End

function GetSFJYMode()
	gHideSFJYCurUser=""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'HideSFJY%s' or VariableName='HideSFJY'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetSFJYMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end
_OnCommonData(dataName = "GetSFJYMode", DTSGlobalVariable evt)
	_WriteAplLog("GetSFJYMode")
	local variableName = evt.getVariableName()
	local variableValue = evt.getVariableValue()
	local currentUserID = _GetDealerID()
	local log = sys_format("GetSFJYMode %s : %s" ,variableName,variableValue)
	_WriteAplLog(log)
	if sys_find(variableName,currentUserID,1) ~= nil then
		gHideSFJYCurUser=variableValue
	else
		if variableValue=="1" then
			gHideSFJY=true
		end
	end
_End
function GetFund4ForbidBuyBAMapIDShowMode()
	gFund4ForbidBuyBAMapIDShowMode = ""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'Fund4ForbidBuyBAMapIDShowMode%s'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetFund4ForbidBuyBAMapIDShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	if gFund4ForbidBuyBAMapIDShowMode=="" then
		GlobalVariableTableSql = "VariableName = 'Fund4ForbidBuyBAMapIDShowMode'"
		_WriteAplLog(GlobalVariableTableSql)
		_GetCommonData(dataName = "GetFund4ForbidBuyBAMapIDShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	else
		if gFund4ForbidBuyBAMapIDShowMode=="0" then
			gFund4ForbidBuyBAMapIDShowMode="1"
		else
			gFund4ForbidBuyBAMapIDShowMode="0"
		end
	end
end

_OnCommonData(dataName = "GetFund4ForbidBuyBAMapIDShowMode", DTSGlobalVariable evt)
	_WriteAplLog("GetFund4ForbidBuyBAMapIDShowMode")
	gFund4ForbidBuyBAMapIDShowMode = evt.getVariableValue()
	local log = sys_format("Fund4ForbidBuyBAMapIDShowMode : %s" ,gFund4ForbidBuyBAMapIDShowMode)
	_WriteAplLog(log)
_End

function GetReserveStringShowMode()
	gReserveStringShowMode = ""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'ReserveStringShowMode%s'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetReserveStringShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	if gReserveStringShowMode=="" then
		GlobalVariableTableSql = "VariableName = 'ReserveStringShowMode'"
		_WriteAplLog(GlobalVariableTableSql)
		_GetCommonData(dataName = "GetReserveStringShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	else
		if gReserveStringShowMode=="0" then
			gReserveStringShowMode="1"
		else
			gReserveStringShowMode="0"
		end
	end
end

_OnCommonData(dataName = "GetReserveStringShowMode", DTSGlobalVariable evt)
	_WriteAplLog("GetReserveStringShowMode")
	gReserveStringShowMode = evt.getVariableValue()
	local log = sys_format("ReserveStringShowMode : %s" ,gReserveStringShowMode)
	_WriteAplLog(log)
_End


function GetShowRiskRefuseReason()
	gShowRiskRefuseReason = ""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'ShowRiskRefuseReason%s'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetShowRiskRefuseReason", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	if gShowRiskRefuseReason=="" then
		GlobalVariableTableSql = "VariableName = 'ShowRiskRefuseReason'"
		_WriteAplLog(GlobalVariableTableSql)
		_GetCommonData(dataName = "GetShowRiskRefuseReason", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	else
		if gShowRiskRefuseReason=="0" then
			gShowRiskRefuseReason="1"
		else
			gShowRiskRefuseReason="0"
		end
	end
end

_OnCommonData(dataName = "GetShowRiskRefuseReason", DTSGlobalVariable evt)
	_WriteAplLog("GetShowRiskRefuseReason")
	gShowRiskRefuseReason = evt.getVariableValue()
	local log = sys_format("ShowRiskRefuseReason : %s" ,gShowRiskRefuseReason)
	_WriteAplLog(log)
_End



function GetShowBAMapListSettingShowMode()
	gShowBAMapListSettingShowMode = ""
	gShowBAMapListSettingShowModeCurUser=""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'ShowBAMapListSettingShowMode%s' or VariableName='ShowBAMapListSettingShowMode'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetShowBAMapListSettingShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end
_OnCommonData(dataName = "GetShowBAMapListSettingShowMode", DTSGlobalVariable evt)
	local settingName = evt.getVariableName()
	local settingValue = evt.getVariableValue()
	local currentUserID = _GetDealerID()
	if sys_find(settingName,currentUserID,1) ~= nil then
		gShowBAMapListSettingShowModeCurUser = settingValue
	else
		if sys_len(settingValue) == 1 then
			gShowBAMapListSettingShowMode = settingValue;
		else
			local lt = getTableByString(settingValue, ":")
			gShowBAMapListSettingShowMode = lt[1]
			gShowBAMapListSettingShowModeExceptUsers = lt[2]
		end
	end
	local log = sys_format("ShowBAMapListSettingShowMode : %s , ExceptUsers : %s , CurUser : %s" ,gShowBAMapListSettingShowMode,gShowBAMapListSettingShowModeExceptUsers,gShowBAMapListSettingShowModeCurUser)
	_WriteAplLog(log)
_End

_DefineEventObject IsShowShowBAMapListSetting _AS _Output
	_DefFld("IsShow",_String,5); --是否允许设置理财账户列表显示与否，1：交易员不显示，0：全部显示
	_SetBufferedFlag(2);
_End

function SendIsShowShowBAMapListSetting()
	local DTSEvent evt = _CreateEventObject("IsShowShowBAMapListSetting");
	local isShow = "True"
	local currentUserID= _GetDealerID()

	if gShowBAMapListSettingShowModeCurUser~="" then
		if gShowBAMapListSettingShowModeCurUser == "0" then
			isShow = "False"
		end
	else
		if not gtPosUserAccessUserTable[currentUserID] then	--交易员
			--设置为1：交易员不显示的情况下且不在除外交易员里面则不显示勾选项
			if gShowBAMapListSettingShowMode=="1" and sys_find(gShowBAMapListSettingShowModeExceptUsers, currentUserID,1) == nil then
				isShow = "False"
			--设置为0：交易员显示的情况下且在除外交易员里面则不显示勾选项
			elseif gShowBAMapListSettingShowMode=="0" and sys_find(gShowBAMapListSettingShowModeExceptUsers, currentUserID,1) ~= nil then
				isShow = "False"
			end
		end
	end
	evt._SetFld("IsShow", isShow);
	_SendToClients(evt);
end

function GetShowPromptSettingShowMode()
	gShowPromptSettingShowMode = ""
	gShowPromptSettingShowModeCurUser=""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'ShowPromptSettingShowMode%s' or VariableName='ShowPromptSettingShowMode'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetShowPromptSettingShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end
_OnCommonData(dataName = "GetShowPromptSettingShowMode", DTSGlobalVariable evt)
	local settingName = evt.getVariableName()
	local settingValue = evt.getVariableValue()
	local currentUserID = _GetDealerID()
	if sys_find(settingName,currentUserID,1) ~= nil then
		gShowPromptSettingShowModeCurUser = settingValue
	else
		if sys_len(settingValue) == 1 then
			gShowPromptSettingShowMode = settingValue;
		else
			local lt = getTableByString(settingValue, ":")
			gShowPromptSettingShowMode = lt[1]
			gShowPromptSettingShowModeExceptUsers = lt[2]
		end
	end
	local log = sys_format("ShowPromptSettingShowMode : %s , ExceptUsers : %s , CurUser : %s" ,gShowPromptSettingShowMode,gShowPromptSettingShowModeExceptUsers,gShowPromptSettingShowModeCurUser)
	_WriteAplLog(log)
_End

_DefineEventObject IsShowShowPromptSetting _AS _Output
	_DefFld("IsShow",_String,5); --是否允许设置下单提示框是否显示，1：交易员不显示，0：全部显示
	_SetBufferedFlag(2);
_End

function SendIsShowShowPromptSetting()
	local DTSEvent evt = _CreateEventObject("IsShowShowPromptSetting");
	local isShow = "True"
	local currentUserID= _GetDealerID()

	if gShowPromptSettingShowModeCurUser~="" then
		if gShowPromptSettingShowModeCurUser == "0" then
			isShow = "False"
		end
	else
		if not gtPosUserAccessUserTable[currentUserID] then	--交易员
			--设置为1：交易员不显示的情况下且不在除外交易员里面则不显示勾选项
			if gShowPromptSettingShowMode=="1" and sys_find(gShowPromptSettingShowModeExceptUsers, currentUserID,1) == nil then
				isShow = "False"
			--设置为0：交易员显示的情况下且在除外交易员里面则不显示勾选项
			elseif gShowPromptSettingShowMode=="0" and sys_find(gShowPromptSettingShowModeExceptUsers, currentUserID,1) ~= nil then
				isShow = "False"
			end
		end
	end
	evt._SetFld("IsShow", isShow);
	_SendToClients(evt);
end

--初始化部分
function initialize()
	local log = "初始化开始,请稍候..."
	_WriteAplLog(log)
	sendLog("All",log)

	local currentUserID = _GetDealerID()	
	initialVariation()
	_GetCommonData("ReadUserName", condition="", tablename = "User");
	_GetCommonData("ReadAccountName", condition="", tablename = "Account");
	_GetCommonData(dataName = "GetMarketName", condition="",  tablename = "MarketCode")		
	goneflag = 1
	gShowManagerFee=0
	getNewUserBAMap()
    
    local con="select IndexCode,IndexName from dtszgrisk.DTSZGRiskIndexTable"	
	_WriteAplLog(con)
	_GetCommonData(dataName="RradIndexName", condition=con,tablename="DynamicSql")	
	
	con=sys_format("select UserID,RoleID,RoleName from dtszgrisk.DTSZGUserExtTable where UserID='%s'",currentUserID)		
	_GetCommonData(dataName="DTSZGUserExtTable", condition=con, tablename="DynamicSql")
	GetSFJYMode()	
	GetS_SingleOrderQuantity()
	GetReSubMitRefuseOrderMode1()
	GetReSubMitRefuseOrderMode2()	
	GetShowReSubMitRefuseOrder()
	GetInternalExecShowMode()
	GetFund4ForbidBuyBAMapIDShowMode()
	GetShowRiskRefuseReason()
	GetReserveStringShowMode()
	GetShowBAMapListSettingShowMode()
	GetShowPromptSettingShowMode()
	GetShowCostOfExcution()
	
	sendS_Tree("All")
	SendIsShowShowBAMapListSetting()
	SendIsShowShowPromptSetting()
	PosInitialize()
	_PosPLCalcFreq=-1	
	PosAddBAMapIDForCurrentUser()
	PosAddBAMapIDForAccessUser()
	--订阅对此账户有使用权限的用户的回报
	for baMapID, dummy1 in pairs(_PosBAMapTable) do
		if _PosBAMapUserTable[baMapID] then 
			for userID, dummy2 in pairs(_PosBAMapUserTable[baMapID]) do
				_PosUserTable[userID] = 1
				--订阅对此账户有使用权限的上级用户的回报
				if _PosAccessUserUserTable[userID] then
					for highUserID, dummy in pairs(_PosAccessUserUserTable[userID]) do
						_PosUserTable[highUserID] = 1
					end
				end
			end
		end
	end
	
	
	for baMapID,v in pairs(_PosBAMapTable) do
		if not isDefaultAccount(baMapID) then
			gtRunAccountTable[baMapID] = 1
		end
	end
	
	local baMapIDList = ""
	for baMapID,v in pairs (gtRunAccountTable) do
		if baMapIDList == "" then
			baMapIDList = sys_format("'%s'",baMapID)
		else
			baMapIDList = sys_format("%s,'%s'",baMapIDList,baMapID)
		end
	end
	con=sys_format("select BAMapID,BASubID,IssueCode,ForbidPosition,ReserveString from DTSBAMapID2ForbidPositionTable where BAMapID in (%s)",baMapIDList)
	_WriteAplLog(con)
	gtBAMapID2ForbidPositionTable = {}
	gtIssueCode2ForbidPosition = {}
	_GetCommonData(dataName="GetForbidPositionData", condition=con, tablename="DynamicSql")
	
	queryProductAccount()
	PosStart();
	---------读取送股信息--------
	local prevTradingDay = _PosTradingDate[1]
	local  cond = "OvernightDate = '" .. prevTradingDay .. "' and ExecutionDate = '" .. prevTradingDay .."' and ExecutionKeyCode like 'SPLIT%'"
	_WriteAplLog(cond)
	_GetCommonData("GetSPLITData", condition=cond, "OvernightData");
	
	cond=sys_format("select * from dtszgrisk.DTSZGStatisticsTable where OvernightDate='%s' and IDType='Poskey' and Field='UserCumulationPL'",prevTradingDay)		
	_WriteAplLog(cond)
	_GetCommonData(dataName="getUserCumulationPL", condition=cond,tablename="DynamicSql")	
    
	sendRole()

end

--全局变量定义部分
function initialVariation()
	gCurSession=""
	gtSessionTable={}
	gtRouteInfo={}
	gtPosUserBAMapTable={}
	gtPosBAMapUserTable={}
	gtPosUserAccessUserTable={}
	gtPosBAMapTable={}
	gtUserName = {}
	gtAccountName = {}
	gUserBAMapStr=""	
	gIsShowBaMapList = "False" --是否显示理财账户下拉框， "True"：显示； 默认：不显示		
	gCurIssueCodeTable = {}
	gInitialized = false
	gDateCheckResult = false;
	gDeliveryOrderResult1 = false
	gDeliveryOrderResult2 = false
	gHisExecCheckResult = true
	gHisOrderCheckResult = false
	gHisFundJournalCheckResult = false
	gTodayFundJournalCheckResult = false

	gHisExecShowMode=1
	gtHisExecSum={}
	gChangeErrorInfo=true --是否修改报错信息
	
	gOrderSortClient = {}   --ClientID顺序集合
	gtMarketNameTable = {}	--交易市场名称
	gtPriceTable = {}		--价格信息表
	
	gtOrderSessionTable = {}--本策略发出的委托才弹出提示框
	gtWorkingOrderTable = {}--挂单委托维护
	gtShowOrderTable = {}   --委托表
	gtShowExecTable = {}	--成交表
	gtRunAccountTable = {}  --用户分配的账户
	gtTodayOpenAmountTable = {} --当日已用资金
	gtDeliveryOrderInfoTable = {}
	gtFundInfoTable = {}
	gtOvernightDataTable = {}
	gtUserCumulationPLTable = {}
	gtOvernightSPLITData={}--送股信息

	gtFund_ProfitSettle={}
	gtSPLIT_ADJUST={}
	gtErrorInfo={}
	gtRiskRefuseReason={}
	gtTtradeExec={}

	gRole_Trader = 5000 --交易员
	gRole_Riskor = 5001 --风控员
	gRole_Assistant_Riskor = 5011 --风控专员
	gRole_AdminRiskor = 5003 --风控主管
	
	gtUserRole={}	
	gtZGProductFlowTable={}
	gtZGProductAccountTable={}
    gtProductAssetsCellTable = {}
    gtProductTable = {}
    gtOldProductTable = {}
    gtProduct2NameTable = {}
    gtGroupID2LeaderUserID = {}
    gtUserID2GroupID = {}
    gtZGProductAccountBackUpTable = {}
    gtLeaderUserID = {}
    gtIndexCode2IndexName = {}
    gtZGProductTable = {}
    gtAssetsCellBAMapTable = {}
    gtSendProductBAMap = {}
    gtClientTable = {}
    gtChecked = {}
    gtltData = {}
	gtUserBAMapStr = {}
	gtExecShowAllTable = {}
	
	gtKCBSupport = {}
	gKCBList = ""
    
    gLeaderUserID = ""
    gGroupID = ""
    gCurrentUserID = _GetDealerID()

	gtInventoryHeaderTable={}
	gtInventoryComponentTable={}
	gtInvestoryPriceTable={}
	gInventoryIDNeedAutoOrder = {}
	gAutoCancelInterval = 5 --默认撤单间隔
	gtAutoCancelInterval={}
	gtAutoCancelTime={}  --自动撤单时间
	gInternalExecShowMode = ""
	gFundJournalShowMode = ""
	gFundJournalShowModeCurUser=""
	gLogsShowMode = ""
	gLogsShowModeCurUser=""
	gFund4ForbidBuyBAMapIDShowMode = ""
	gReserveStringShowMode = ""
	gShowBAMapListSettingShowMode = ""
	gShowBAMapListSettingShowModeExceptUsers=""
	gShowBAMapListSettingShowModeCurUser=""
	gMaxFare = 0.003
	gtReqIDtoQueryName={}
	gHideSFJY=false
	gHideSFJYCurUser=""
	gReSubMitRefuseOrder=false
	gIndexAllBAMapOrder=1  --全部账户委托序号
	gtAllRefuseBAMap={}
	gShowPromptSettingShowMode = ""
	gShowPromptSettingShowModeExceptUsers=""
	gShowPromptSettingShowModeCurUser=""
	gIsInventoryInitialized=false
	gtSendInventoryInitialized={}
	
	gShowAlert = ""
	gShowAlertCurUser=""
	
	gtfundStatusAccountCode_Cache = {}
	gtfundStatusAllSessionID_Cache = {}
	gFirstCalculation = true
	gProductIDs_str = ""
	
    
end
function getNewUserBAMap()
	gtPosUserBAMapTable={}
	gtPosBAMapUserTable={}
	gtPosUserAccessUserTable={}
	gtPosBAMapTable={}		
	_GetCommonData("GetNewUserBAMapID", sqlCondition="", "UserBAMap");
	_GetCommonData("GetNewUserAccess", sqlCondition="", "UserAccess");
end

_OnCommonData("GetNewUserBAMapID", DTSUserBAMap userba)
	local userID = userba.getUserID()
	local baMapID = userba.getBAMapID()
	gtPosUserBAMapTable[userID] = gtPosUserBAMapTable[userID] or {}
	gtPosUserBAMapTable[userID][baMapID] = 1
	gtPosBAMapUserTable[baMapID] = gtPosBAMapUserTable[baMapID] or {}
	gtPosBAMapUserTable[baMapID][userID] = 1
	
_End
_OnCommonData("GetNewUserAccess", DTSUserAccess userAccess)
	local userID = userAccess.getUserID()
	local accessUserID = userAccess.getAccessUserID()
	local readRight = userAccess.getReadRight()
	local writeRight = userAccess.getWriteRight()
	local right = 0
	if readRight == "1" then
		right = right + 1
	end
	if writeRight == "1" then
		right = right + 10
	end
	gtPosUserAccessUserTable[userID] = gtPosUserAccessUserTable[userID] or {}
	gtPosUserAccessUserTable[userID][accessUserID] = right
_End

--优先级消息
_OnReceiveUnifieldMessage("onUpDateOrderSort", "UpDateOrderSort", DTSUnifieldMessage srcMsg)
    srcMsg.first()
    while not srcMsg.eof() do
		local groupID = srcMsg.getValueByName("GroupID")
		groupID=groupID.getNumberValue()
		local log=sys_format("UpDateOrderSort :GroupID:%s,CurrentGroupID:%s",groupID,gGroupID)
		_WriteAplLog(log)
		if gGroupID==groupID then
			local strJson = srcMsg.getValueByName("StrJson")
			_WriteAplLog(strJson)			
			local DTSSubmitEvent decoder
			decoder.decode(strJson)
			local lt = decoder.asCommon()
			if lt then
				local ltClientID={}
				local sortIndex={}
				for clientID,index in pairs(lt) do
					sys_insert(sortIndex,index)
					ltClientID[index]=clientID
				end				
				sys_sort(sortIndex, "asc")
				
				gOrderSortClient={}
				for i,index in pairs(sortIndex) do
					local log=sys_format("InvestorOrderSort:%s,%s",index,ltClientID[index])
					_WriteAplLog(log)
					local clientID=ltClientID[index]
					sys_insert(gOrderSortClient,clientID)
				end
				--只更新优先级不改变界面数据
				for sessionID,v in pairs(gtSessionTable) do
					local userID=gtSessionTable[sessionID].SelectedUserID
					local baMapID=gtSessionTable[sessionID].SelectedBAMapID
					currentBaMapID(sessionID,userID,baMapID,"0")
				end
			end
		end
		srcMsg.next()
    end
    srcMsg.clear()
_End

_OnReceiveUnifieldMessage("onGlobalVariable", "ReLoadGlobalVariable", DTSUnifieldMessage srcMsg)
	local VariableName=""
	srcMsg.first()
	while not srcMsg.eof() do 
		VariableName = srcMsg.getValueByName("VariableName")
        srcMsg.next()
    end
    srcMsg.clear()
	local log=sys_format("ReLoadGlobalVariable:%s",VariableName)
	_WriteAplLog(log)	
	local currentUserID = _GetDealerID()
	local userVariableName=sys_format("ReSubMitRefuseOrderMode%s",currentUserID)
	if VariableName=="ReSubMitRefuseOrderMode" or VariableName==userVariableName then
		GetReSubMitRefuseOrderMode1()
		GetReSubMitRefuseOrderMode2()	 
	end

	userVariableName=sys_format("ShowBAMapListSettingShowMode%s",currentUserID)
	if VariableName=="ShowBAMapListSettingShowMode" or VariableName==userVariableName then
		GetShowBAMapListSettingShowMode()
		SendIsShowShowBAMapListSetting()
	end		
	userVariableName=sys_format("ShowPromptSettingShowMode%s",currentUserID)
	if VariableName=="ShowPromptSettingShowMode" or VariableName==userVariableName then
		GetShowPromptSettingShowMode()
		SendIsShowShowPromptSetting()
	end	
	
	
	userVariableName=sys_format("Fund4ForbidBuyBAMapIDShowMode%s",currentUserID)
	if VariableName=="Fund4ForbidBuyBAMapIDShowMode" or VariableName==userVariableName then
		GetFund4ForbidBuyBAMapIDShowMode()
	end	
	
	userVariableName=sys_format("S_SingleOrderQuantity%s",currentUserID)
	if VariableName=="S_SingleOrderQuantity" or VariableName==userVariableName then
		GetS_SingleOrderQuantity()
	end					
	if VariableName=="PTWTFreshTimer" then
		GetPTWTFreshTimer()
	end
	userVariableName=sys_format("InternalExecShowMode%s",currentUserID)
	if VariableName=="InternalExecShowMode" or VariableName==userVariableName then
		GetInternalExecShowMode()
	end
	userVariableName=sys_format("ShowReSubMitRefuseOrder%s",currentUserID)
	if VariableName=="ShowReSubMitRefuseOrder" or VariableName==userVariableName then
		GetShowReSubMitRefuseOrder()
	end
	
	userVariableName=sys_format("ReserveStringShowMode%s",currentUserID)
	if VariableName=="ReserveStringShowMode" or VariableName==userVariableName then
		GetReserveStringShowMode()
	end
	
	userVariableName=sys_format("ShowRiskRefuseReason%s",currentUserID)
	if VariableName=="ShowRiskRefuseReason" or VariableName==userVariableName then
		GetShowRiskRefuseReason()
	end		
	local sendTree=false
	
	userVariableName=sys_format("LogsShowMode%s",currentUserID)
	if VariableName=="LogsShowMode" or VariableName==userVariableName then
		GetLogsShowMode()
		sendTree=true 
	end	
	
	userVariableName=sys_format("FundJournalShowMode%s",currentUserID)
	if VariableName=="FundJournalShowMode" or VariableName==userVariableName then
		GetFundJournalShowMode()
		sendTree=true 
	end	
	
	userVariableName=sys_format("HisFundShowMode%s",currentUserID)
	if VariableName=="HisFundShowMode" or VariableName==userVariableName then
		GetHisFundShowMode()
		sendTree=true 
	end
	
	
	
	userVariableName=sys_format("HideSFJY%s",currentUserID)
	if VariableName=="HideSFJY" or VariableName==userVariableName then
		GetSFJYMode()
		sendTree=true 
	end	
	
	userVariableName=sys_format("ShowAlert%s",currentUserID)
	if VariableName=="ShowAlert" or VariableName==userVariableName then
		sendTree=true 
	end	
	
	
	if sendTree then
		local DTSEvent evt = _CreateEventObject("S_TreeEvent")
		evt._SetFld("Item1", "clearData")
		_SendToClients(evt)
		sendS_Tree("All")
	end
	
	userVariableName=sys_format("ShowCostOfExcution%s",currentUserID)
	if VariableName=="ShowCostOfExcution" or VariableName==userVariableName then
		GetShowCostOfExcution()
	end	
_End


--产品、账户更新刷新持仓
_OnReceiveUnifieldMessage("ProductRefresh", "ProductRefreshBaMapID", DTSUnifieldMessage srcMsg)
    _WriteAplLog("Receive message ProductRefreshBaMapID")
	local productID = ""
	local risker = ""
	local baMapIDs = ""
	srcMsg. first()
    while not srcMsg.eof() do --实际只会进来一次
		productID = srcMsg.getValueByName("ProductID")
		baMapIDs = srcMsg.getValueByName("BAMapID")
		risker = srcMsg.getValueByName("Risker")
        srcMsg.next()
    end
    srcMsg.clear()

	 local baMapIDTable={}
	 local len = sys_len(baMapIDs)
	 local begin = 1
	 local curi = 1
	 while curi<=len do
		local chr = sys_sub(baMapIDs, curi, curi)
		if chr == "," then
			local baMapID=sys_sub(baMapIDs, begin, curi-1)
			baMapIDTable[baMapID]=1
			begin = curi + 1
		elseif curi==len then
			local baMapID=sys_sub(baMapIDs, begin, len)
			baMapIDTable[baMapID]=1
			begin = curi + 1
		end
		curi=curi+1
	 end
	 PosReInitialize()
	 local currentUserID = _GetDealerID()
	 local newBaMapIDTable = {} --新增的账户
	 local haveNew=false
	 local istoMe=false
	for baMapID,v in pairs(baMapIDTable) do
		if _PosUserBAMapTable[currentUserID] then
		   if _PosUserBAMapTable[currentUserID][baMapID] then
				istoMe=true
				if not _PosBAMapTable[baMapID] then
					newBaMapIDTable[baMapID]=1
					haveNew=true
				end
		   end
		end
		if _PosUserAccessUserTable[currentUserID] then
			for accessUser,v in pairs(_PosUserAccessUserTable[currentUserID]) do
				if _PosUserBAMapTable[accessUser] then
				   if _PosUserBAMapTable[accessUser][baMapID] then
						istoMe=true
						if not _PosBAMapTable[baMapID] then
							newBaMapIDTable[baMapID]=1
							haveNew=true
						end
				   end
				end
			end
		end
	end
	for baMapID,v in pairs(gtZGProductAccountTable) do
		if v.ProductID==productID then
			istoMe=true
		end
	end

	if istoMe then
		local log = sys_format("产品[%s]立即生效,风控员[%s],产品账户[%s]",productID,risker,baMapIDs)
		_WriteAplLog(log)
        --当前交易员的可用理财账户
		if haveNew then
			PosAddBAMapIDForCurrentUser()
			PosAddBAMapIDForAccessUser()
			--订阅对此账户有使用权限的用户的回报
			for baMapID, dummy1 in pairs(_PosBAMapTable) do
				if _PosBAMapUserTable[baMapID] then 
					for userID, dummy2 in pairs(_PosBAMapUserTable[baMapID]) do
						_PosUserTable[userID] = 1
						--订阅对此账户有使用权限的上级用户的回报
						if _PosAccessUserUserTable[userID] then
							for highUserID, dummy in pairs(_PosAccessUserUserTable[userID]) do
								_PosUserTable[highUserID] = 1
							end
						end
					end
				end
			end
			PosStart();
		end
		local baMapIDlog = ""
		for baMapID, v in pairs(baMapIDTable) do
			if _PosBAMapTable[baMapID] then
				gtRunAccountTable[baMapID] = 1
				baMapIDlog=baMapIDlog.." "..baMapID
			end
		end
		if haveNew then
			local newbaMapID=""
			for baMapID, v in pairs(newBaMapIDTable) do
				if _PosBAMapTable[baMapID] then
					newbaMapID=newbaMapID.." "..baMapID
				end
			end
			log = sys_format("新增账户[%s]",newbaMapID)
			_WriteAplLog(log)
		end
		--------------------------最新有使用权限的用户-------------------------------
		getNewUserBAMap()
		newPosBAMapTable={}		
		if gtPosUserBAMapTable[currentUserID] then
		   for baMapID,v in pairs(gtPosUserBAMapTable[currentUserID]) do
				newPosBAMapTable[baMapID]=1
		   end
		 end
		if gtPosUserAccessUserTable[currentUserID] then
			for accessUser, dummy in pairs(gtPosUserAccessUserTable[currentUserID]) do
				if gtPosUserBAMapTable[accessUser] then
					for baMapID,v in pairs(gtPosUserBAMapTable[accessUser]) do
						newPosBAMapTable[baMapID]=1
					end
				end
			end
		end	
		------------------------------------------------------------------------
		local baMapIDReduced = false
		for baMapID, v in pairs(gtRunAccountTable) do
			if not newPosBAMapTable[baMapID] then
				gtRunAccountTable[baMapID] = nil
				baMapIDReduced = true
				local log=sys_format("用户对账户%s已无使用权限",baMapID)
				_WriteAplLog(log)
			end
		end	
		RefreshFundSuspend()
		queryProductAccount()
		sendUserBAMap("All")
		for sessionID,v in pairs(gtSessionTable) do
			local userID=gtSessionTable[sessionID].SelectedUserID
			local baMapID=gtSessionTable[sessionID].SelectedBAMapID
			currentBaMapID(sessionID,userID,baMapID,"0")
		end	
	end
_End	

function RefreshFundSuspend()
	for accountCode,v in pairs(_PosFundStatus) do
		_PosFundStatus[accountCode].AvlFund = _PosFundStatus[accountCode].AvlFund + _PosFundStatus[accountCode].FrozenFund_R
		--清0
		_PosFundStatus[accountCode].FrozenFund = 0.00
		_PosFundStatus[accountCode].UnFrozenFund = 0.00
		_PosFundStatus[accountCode].FrozenFund_T = 0.00
		_PosFundStatus[accountCode].UnFrozenFund_T = 0.00
		_PosFundStatus[accountCode].FrozenFund_R = 0.00
	end
	_PosShowTodayFundSuspend()
	_PosCalFrozenFund()
end

function SendOrder_All(sessionID,issueCode, bs, oc, price, quantity, orderType, baSubID, creRed,batchID)
	local effectedIDCount = 0	--下单成功的有效理财账号
	local lastForbidBAMapID=""	--最后一个禁买禁卖的理财账号
	local lastBAMapIDFund=0
	gtAllRefuseBAMap[batchID]=gtAllRefuseBAMap[batchID] or {}
	
	local currentUser= _GetDealerID()
	--交易类型
	local marketCode = _PosIssueMarketTable[issueCode]
	local marginType = GetMarginType(marketCode, bs, oc, creRed)
	
	local selectedUserID=""
	if gtSessionTable[sessionID] then 
		if gtSessionTable[sessionID].SelectedUserID then
			selectedUserID=gtSessionTable[sessionID].SelectedUserID
		end
	end
	local currentUserID = _GetDealerID()

	local msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s].",currentUser,issueCode,marginType,quantity,price)
	if gtUserRole[currentUserID] then 
		if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
			local roleName=gtUserRole[currentUserID].RoleName or ""
			msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s].",roleName,selectedUserID,issueCode,marginType,quantity,price)
		end
	end	

	
	local originalQuantity=quantity
	if oc == 0 then --买
		--下单价格
		local priceInfo = _PosPriceTable[issueCode]
		local orderPrice = price
		if orderType == "" then--如果没有OrderType,则下单价格为所传的价格
			orderPrice = price
		elseif priceInfo then
			orderPrice = priceInfo.UpLimitPrice--市价委托的委托价都按涨停价
		end
		price = orderPrice
		local firePriceLog = sys_format("FireEvent:price=%s", price)
		_WriteAplLog(firePriceLog)
		--总可用资金
		local temAvailableFund = 0
		if gtSessionTable[sessionID].CurBAMapIDTable then
			for tmpBaMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
				local accountCode = ""
				if tmpBaMapID then
					accountCode = _PosBAMapAccount[tmpBaMapID]
				end

				if accountCode and accountCode ~= ""  then
					local availableFund = _PosFundStatus[accountCode]["AvlFund"]
					temAvailableFund = temAvailableFund + availableFund
				end
			end
		end
		local requiredFund = price * quantity

		if requiredFund > temAvailableFund then
			local log = sys_format("资金不足，需要%.02f元，现有%.02f元", requiredFund, temAvailableFund)
			_WriteAplLog(log)
		end

		-- 可买数量
		local totalAvlOpenQty = 0
		if gtSessionTable[sessionID].CurBAMapIDTable then
			for bAMap, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
				local accCode = _PosBAMapAccount[bAMap]
				if _PosFundStatus[accCode] then
					if not gtAllRefuseBAMap[batchID][bAMap] then 
						local avlFund=_PosFundStatus[accCode].AvlFund
						local contractSize = _PosIssueContractSizeTable[issueCode]
						local bail = _PosGetBail(accCode, issueCode, bs, POS_SPECULATE)
						local avlOpenQty=avlFund / (price * bail * contractSize * (1 + gMaxFare))
						avlOpenQty=sys_floor(avlOpenQty/100)*100
						totalAvlOpenQty = totalAvlOpenQty + avlOpenQty
					end
				end
			end 
		end
		if totalAvlOpenQty<=0 then
			local log = sys_format("单位总可买数量不足，下单数量%d，单位总可买数量%d",originalQuantity, totalAvlOpenQty)
			_WriteAplLog(log)
			showLog(sessionID,log)
			return;
		elseif quantity > totalAvlOpenQty then
			local log = sys_format("单位总可买数量不足，下单数量%d，单位总可买数量%d",originalQuantity, totalAvlOpenQty)
			_WriteAplLog(log)
			--showLog(sessionID,log)
			--return;
		end

		for i,bAMap in pairs(gtSessionTable[sessionID].SortBaMapIDTable ) do
			if quantity <= 0 then
				return
			end
			if not gtAllRefuseBAMap[batchID][bAMap] then
				if gtZGProductAccountTable[bAMap] then
					local log = sys_format("理财账户[%s]禁买标志[%s]",bAMap,gtZGProductAccountTable[bAMap].ForbidBuy)
					_WriteAplLog(log)
					if gtZGProductAccountTable[bAMap].ForbidBuy=="0" then
						local accCode = _PosBAMapAccount[bAMap]
						if _PosFundStatus[accCode] then
							local avlFund=_PosFundStatus[accCode].AvlFund
							local contractSize = _PosIssueContractSizeTable[issueCode]
							local bail = _PosGetBail(accCode, issueCode, bs, POS_SPECULATE)
							local avlOpenQty=avlFund / (price * bail * contractSize * (1 + gMaxFare))
							avlOpenQty=sys_floor(avlOpenQty/100)*100

							local tmpQty = 0
							if avlOpenQty > 0 then
								if quantity > avlOpenQty then
									tmpQty = avlOpenQty
								else
									tmpQty = quantity
								end
							end

							if tmpQty > 0 then
								--获取单子的DealerID
								local dealerID = GetOrderDealerID(bAMap)
								local dealerlog = sys_format("FireEvent: dealerID=[%s]", dealerID)
								_WriteAplLog(dealerlog)
								effectedIDCount = effectedIDCount + 1
								--下单
								
								local remainQty=tmpQty
								while remainQty>0 do 
									local orderQty=remainQty
									if orderQty>gS_SingleOrderQuantity and gS_SingleOrderQuantity>0 then
										orderQty=gS_SingleOrderQuantity
									end
									remainQty=remainQty-orderQty;
									if CheckSubmitIssue(sessionID,issueCode,bAMap) then
										local pcid=newPCID(bAMap)
										setOrderRouteInfo(sessionID,pcid)
										local ret = PosSubmitSingleOrder(bAMap, baSubID, issueCode, bs, oc, price, orderQty, creRed, dealerID, batchID, nil, orderType,pcid)
										if ret.Result then
											local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 已发送至风控系统,委托号为[%s],等待回应！",bAMap,issueCode,orderQty,ret.PositionCheckID)
											_WriteAplLog(log)
											showLog(sessionID,log)
											quantity = quantity - orderQty							
											gtOrderSessionTable[ret.PositionCheckID]=sessionID	
											msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",currentUser,issueCode,marginType,originalQuantity,price,bAMap,orderQty)
											if gtUserRole[currentUserID] then 
												if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
													local roleName=gtUserRole[currentUserID].RoleName or ""
													msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,bAMap,orderQty)
												end
											end
											
											sendOprationLog(sessionID,msg)
										else
											if ret.Reason then
												local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 发送至风控系统失败！原因:%s",bAMap,issueCode,orderQty,ret.Reason)
												_WriteAplLog(log)
												showLog(sessionID,log)
												msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",currentUser,issueCode,marginType,originalQuantity,price,bAMap,orderQty,ret.Reason)
												if gtUserRole[currentUserID] then 
													if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
														local roleName=gtUserRole[currentUserID].RoleName or ""
														msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,bAMap,orderQty,ret.Reason)
													end
												end
												
												sendOprationLog(sessionID,msg)
											end
										end
									end
								end
							end
						end
					else
						local accCode = _PosBAMapAccount[bAMap]
						if _PosFundStatus[accCode] then
							local avlFund=_PosFundStatus[accCode].AvlFund
							if lastForbidBAMapID=="" or avlFund>=lastBAMapIDFund then
								lastForbidBAMapID = bAMap
								lastBAMapIDFund=avlFund
							end
						end
					end
				end
			end
		end
		--如果一个理财账号都没下单，那就用最后一个禁买理财账号下单
		if effectedIDCount==0 then
			local accCode = _PosBAMapAccount[lastForbidBAMapID]
			if _PosFundStatus[accCode] then
				--获取单子的DealerID
				local dealerID = GetOrderDealerID(lastForbidBAMapID)
				local dealerlog = sys_format("FireEvent: dealerID=[%s] lastForbidBAMapID=[%s]", dealerID, lastForbidBAMapID)
				_WriteAplLog(dealerlog)

				
				local avlFund=_PosFundStatus[accCode].AvlFund
				local contractSize = _PosIssueContractSizeTable[issueCode]
				local bail = _PosGetBail(accCode, issueCode, bs, POS_SPECULATE)
				local avlOpenQty=avlFund / (price * bail * contractSize * (1 + gMaxFare))
				avlOpenQty=sys_floor(avlOpenQty/100)*100

				local tmpQty = 0
				if avlOpenQty > 0 then
					if quantity > avlOpenQty then
						tmpQty = avlOpenQty
					else
						tmpQty = quantity
					end
				end
				if tmpQty>0 then 
					--下单
					if CheckSubmitIssue(sessionID,issueCode,lastForbidBAMapID) then
						local pcid=newPCID(lastForbidBAMapID)
						setOrderRouteInfo(sessionID,pcid)
						local ret = PosSubmitSingleOrder(lastForbidBAMapID, baSubID, issueCode, bs, oc, price, tmpQty, creRed, dealerID, nil, nil, orderType,pcid)
						if ret.Result then
							local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 已发送至风控系统,委托号为[%s],等待回应！",lastForbidBAMapID,issueCode,tmpQty,ret.PositionCheckID)
							_WriteAplLog(log)
							showLog(sessionID,log)
							gtOrderSessionTable[ret.PositionCheckID]=sessionID
							
							msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",currentUser,issueCode,marginType,originalQuantity,price,lastForbidBAMapID,tmpQty)
							if gtUserRole[currentUserID] then 
								if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
									local roleName=gtUserRole[currentUserID].RoleName or ""
									msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,lastForbidBAMapID,tmpQty)
								end
							end
							
							sendOprationLog(sessionID,msg)
							
						else
							if ret.Reason then
								local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 发送至风控系统失败！原因:%s",lastForbidBAMapID,issueCode,tmpQty,ret.Reason)
								_WriteAplLog(log)
								showLog(sessionID,log)
								msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",currentUser,issueCode,marginType,originalQuantity,price,lastForbidBAMapID,tmpQty,ret.Reason)
								if gtUserRole[currentUserID] then 
									if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
										local roleName=gtUserRole[currentUserID].RoleName or ""
										msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,lastForbidBAMapID,tmpQty,ret.Reason)
									end
								end
								sendOprationLog(sessionID,msg)
							end
						end
					end
				else
					local log = sys_format("全部委托:合约[%s]数量[%d] 发送至风控系统失败！原因:4006 error operation",issueCode,originalQuantity)
					_WriteAplLog(log)
					showLog(sessionID,log)
					msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s].结果【失败,4006 error operation】",currentUser,issueCode,marginType,originalQuantity,price)
					if gtUserRole[currentUserID] then 
						if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
							local roleName=gtUserRole[currentUserID].RoleName or ""
							msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s].结果【失败,4006 error operation】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price)
						end
					end
					sendOprationLog(sessionID,msg)
				end
			end
		end
	elseif oc == 1 then --卖
		local lastAvlQty = 0
		local oddLotData = {}
		for i,bAMap in pairs(gtSessionTable[sessionID].SortBaMapIDTable) do
			if quantity <= 0 then
				return
			end
			if not gtAllRefuseBAMap[batchID][bAMap] then
				local accCode = _PosBAMapAccount[bAMap]
				if _PosFundStatus[accCode] then
					for posKey, pos in pairs(_PosPositionTable) do
						local posBS = sys_sub(pos.BASubID, 1, 1)
						local posPortID = sys_sub(pos.BASubID, 2, -1)
						
						local ForbidPosition = 0
						if gtBAMapID2ForbidPositionTable[posKey] then
							ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition		
						end 	
						
						local AvlQuantity_tmp = pos.AvlQuantity - ForbidPosition
						--pos.AvlQuantity = pos.AvlQuantity - ForbidPosition
						
						if pos.BAMapID==bAMap and pos.IssueCode==issueCode and posBS=="3" and AvlQuantity_tmp>0 then
							if gtZGProductAccountTable[bAMap] then
								local log = sys_format("理财账户[%s]禁卖标志[%s]",bAMap,gtZGProductAccountTable[bAMap].ForbidSell)
								_WriteAplLog(log)
								if gtZGProductAccountTable[bAMap].ForbidSell=="0" then
									local tmpQty = 0
									if quantity > AvlQuantity_tmp then
										tmpQty = AvlQuantity_tmp
									else
										tmpQty = quantity
									end

									if tmpQty > 0 then
										local modQty = 0
										
										if bs=="1" and (marketCode == "1" or marketCode == "2") then
											modQty = tmpQty
											tmpQty=sys_floor(tmpQty/100) *100 
											modQty = modQty - tmpQty
										end
										if modQty > 0 then
											oddLotData[bAMap] = modQty
										end
										--获取单子的DealerID
										local dealerID = GetOrderDealerID(bAMap)
										local dealerlog = sys_format("FireEvent: dealerID=[%s]", dealerID)
										_WriteAplLog(dealerlog)
										effectedIDCount = effectedIDCount + 1
										--下单
										
										local remainQty=tmpQty
										while remainQty>0 do 
											local orderQty=remainQty
											if orderQty>gS_SingleOrderQuantity and gS_SingleOrderQuantity>0 then
												orderQty=gS_SingleOrderQuantity
											end
											remainQty=remainQty-orderQty;
										
											if CheckSubmitIssue(sessionID,issueCode,bAMap) then
												local pcid=newPCID(bAMap)
												setOrderRouteInfo(sessionID,pcid)
												local ret = PosSubmitSingleOrder(bAMap, baSubID, issueCode, bs, oc, price, orderQty, creRed, dealerID, batchID, nil, orderType,pcid)
												if ret.Result then
													local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 已发送至风控系统,委托号为[%s],等待回应！",bAMap,issueCode,orderQty,ret.PositionCheckID)
													_WriteAplLog(log)
													showLog(sessionID,log)
													quantity = quantity - orderQty
													gtOrderSessionTable[ret.PositionCheckID]=sessionID
													msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",currentUser,issueCode,marginType,originalQuantity,price,bAMap,orderQty)
													if gtUserRole[currentUserID] then 
														if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
															local roleName=gtUserRole[currentUserID].RoleName or ""
															msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,bAMap,orderQty)
														end
													end
													
													sendOprationLog(sessionID,msg)
												else
													if ret.Reason then
														local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 发送至风控系统失败！原因:%s",bAMap,issueCode,orderQty,ret.Reason)
														_WriteAplLog(log)
														showLog(sessionID,log)
														msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",currentUser,issueCode,marginType,originalQuantity,price,bAMap,orderQty,ret.Reason)
														if gtUserRole[currentUserID] then 
															if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
																local roleName=gtUserRole[currentUserID].RoleName or ""
																msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,bAMap,orderQty,ret.Reason)
															end
														end
														sendOprationLog(sessionID,msg)
													end
												end
											end
										end
									end
								else
									if lastForbidBAMapID=="" or AvlQuantity_tmp>=lastAvlQty then
										lastForbidBAMapID = bAMap
										lastAvlQty = AvlQuantity_tmp
									end
								end
							end
							break
						end
					end
				end
			end
		end
		-- 处理零股
		for bAMap, modQty in pairs(oddLotData) do
			if quantity >= modQty then
				--获取单子的DealerID
				local dealerID = GetOrderDealerID(bAMap)
				local pcid=newPCID(bAMap)
				setOrderRouteInfo(sessionID,pcid)
				local ret = PosSubmitSingleOrder(bAMap, "3", issueCode, bs, oc, price, modQty, creRed, dealerID, nil, nil, orderType,pcid)
				if ret.Result then
					local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 已发送至风控系统,委托号为[%s],等待回应！",bAMap,issueCode,modQty,ret.PositionCheckID)
					_WriteAplLog(log)
					showLog(sessionID,log)
					quantity = quantity - modQty
					gtOrderSessionTable[ret.PositionCheckID]=sessionID
					
					msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",currentUser,issueCode,marginType,originalQuantity,price,bAMap,modQty)
					if gtUserRole[currentUserID] then 
						if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
							local roleName=gtUserRole[currentUserID].RoleName or ""
							msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,bAMap,modQty)
						end
					end
					
					sendOprationLog(sessionID,msg)
				else
					local reason=""
					if ret.Reason then
						reason=ret.Reason
						msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",currentUser,issueCode,marginType,originalQuantity,price,bAMap,modQty,ret.Reason)
						if gtUserRole[currentUserID] then 
							if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
								local roleName=gtUserRole[currentUserID].RoleName or ""
								msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,bAMap,modQty,ret.Reason)
							end
						end
						sendOprationLog(sessionID,msg)
					end
					local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 发送至风控系统失败！原因:%s",bAMap,issueCode,modQty,reason)
					_WriteAplLog(log)

					showLog(sessionID,log)
				end
			end
		end
		if effectedIDCount==0 then
			local modQty = 0
			if bs=="1" and (marketCode == "1" or marketCode == "2") then
				modQty = lastAvlQty
				lastAvlQty=sys_floor(lastAvlQty/100) *100 
				modQty = modQty - lastAvlQty
			end
			if lastAvlQty == 0 then
				lastAvlQty = modQty
			end
			if lastForbidBAMapID~="" then 
				--获取单子的DealerID
				local dealerID = GetOrderDealerID(lastForbidBAMapID)
				local dealerlog = sys_format("FireEvent: dealerID=[%s]lastForbidBAMapID=[%s]lastAvlQty=[%d]", dealerID,lastForbidBAMapID,lastAvlQty)
				_WriteAplLog(dealerlog)
				
				--下单
				if CheckSubmitIssue(sessionID,issueCode,lastForbidBAMapID) then
					
					local orderQty=0
					if lastAvlQty>quantity then
						orderQty=quantity
					else
						orderQty=lastAvlQty
					end
					local pcid=newPCID(lastForbidBAMapID)
					setOrderRouteInfo(sessionID,pcid)
					local ret = PosSubmitSingleOrder(lastForbidBAMapID, baSubID, issueCode, bs, oc, price, orderQty, creRed, dealerID, nil, nil, orderType,pcid)
					if ret.Result then
						local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 已发送至风控系统,委托号为[%s],等待回应！",lastForbidBAMapID,issueCode,orderQty,ret.PositionCheckID)
						_WriteAplLog(log)
						showLog(sessionID,log)
						gtOrderSessionTable[ret.PositionCheckID]=sessionID
						msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",currentUser,issueCode,marginType,originalQuantity,price,lastForbidBAMapID,orderQty)
						if gtUserRole[currentUserID] then 
							if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
								local roleName=gtUserRole[currentUserID].RoleName or ""
								msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【已发送至风控系统】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,lastForbidBAMapID,orderQty)
							end
						end
						sendOprationLog(sessionID,msg)
					else
						if ret.Reason then
							local log = sys_format("全部委托:理财账户[%s]合约[%s]数量[%d] 发送至风控系统失败！原因:%s",lastForbidBAMapID,issueCode,orderQty,ret.Reason)
							_WriteAplLog(log)
							showLog(sessionID,log)
							msg=sys_format("【普通委托】操作:[下单],内容：用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",currentUser,issueCode,marginType,originalQuantity,price,lastForbidBAMapID,orderQty,ret.Reason)
							if gtUserRole[currentUserID] then 
								if gtUserRole[currentUserID].RoleID and gtUserRole[currentUserID].RoleID~="" and gtUserRole[currentUserID].RoleID~=gRole_Trader then 
									local roleName=gtUserRole[currentUserID].RoleName or ""
									msg=sys_format("【普通委托】操作:[下单],内容：角色[%s]选择用户[%s]理财账户[全部]代码[%s]买卖[%s]数量[%d]价格[%s]下单账户[%s]下单数量[%d].结果【失败,%s】",roleName,selectedUserID,issueCode,marginType,originalQuantity,price,lastForbidBAMapID,orderQty,ret.Reason)
								end
							end
							sendOprationLog(sessionID,msg)
						end
					end
				end
			end
		end
	elseif oc == 2 then
		-- 平仓暂不实现
	else
		_WriteAplLog(oc)
		_WriteAplLog("oc not support")
	end
end

function GetOrderSort()
	_WriteAplLog("GetOrderSort")
	--gGroupID = ""
	local userID = _GetDealerID()
	local log = "GetOrderSort userID:" .. userID
	_WriteAplLog(log)
	local groupUserTableSql =  " UserID = '" .. userID .. "'"
	_WriteAplLog(groupUserTableSql)
    
    if gGroupID == "" then
        _GetCommonData(dataName= "GetGroupID_1",condition = groupUserTableSql, tablename = "GroupUser");
    end
	if gGroupID == "" then
		local groupTableSql = " LeaderUserID = '" .. userID .. "'"
		_WriteAplLog(groupTableSql)
		_GetCommonData(dataName="GetGroupID_2", condition=groupTableSql, tablename="Group")
	end
    
	if gGroupID ~= nil and gGroupID ~= "" then
		local sql=sys_format("select ClientID,InvestorID,OrderIndex from dtszgrisk.DTSZGInvestorOrderSortTable where GroupID=%d ORDER BY OrderIndex", gGroupID)
		_WriteAplLog(sql)
		_GetCommonData(dataName="ReadInvestorOrderSort", condition=sql,tablename="DynamicSql")	
		--只更新优先级不改变界面数据					
		for sessionID,v in pairs(gtSessionTable) do
			local userID=gtSessionTable[sessionID].SelectedUserID
			local baMapID=gtSessionTable[sessionID].SelectedBAMapID
			currentBaMapID(sessionID,userID,baMapID,"0")
		end
	end
end

_OnCommonData(dataName = "GetGroupID_1", DTSGroupUser evt)
	gGroupID = evt.getGroupID()
	local log = sys_format("GetGroupID_1 groupID : %s" ,gGroupID)
	_WriteAplLog(log)
_End

_OnCommonData(dataName = "GetGroupID_2", DTSGroup evt)
	gGroupID = evt.getGroupID()
	local log = gGroupID sys_format("GetGroupID_2 groupID : %s" ,gGroupID)
	_WriteAplLog(log)
_End



function getTableByString(line, split)
	local lin = line
	local logs = sys_format("variableValue line = [%s]",lin);
	--_WriteAplLog(logs);
	local rtn = {}
	local len = sys_len(line)
	if len > 0 then
		local chrbegin = 1
		for i = 1, len do
			local chr = sys_sub(line, i, i)
			if chr == split then
				sys_insert(rtn, sys_sub(line, chrbegin, i-1))
				chrbegin = i + 1
			end
		end

		local lastChr = sys_sub(line, len -1, len)
		if lastChr ~= split then
			sys_insert(rtn, sys_sub(line, chrbegin, len))
		end
	end
	return rtn
end
function IsInTable(value, tbl)
	--_WriteAplLog("IsInTable")
	--_WriteAplLog(value)
	for k,v in pairs(tbl) do
	  --local logs = sys_format("IsInTable %s:%s",k,v)
	  --_WriteAplLog(logs)
	  if v == value then
		return true;
	  end
	end
	return false;
end

----------------------------------------组合维护组合交易-----------------------------------------------
_DefineEventObject UserRoleOut _AS _Output
	_DefFld("UserID",_String,20)
	_DefFld("RoleID", _Int, 10);
	_DefFld("RoleName", _String, 40);


	_DefKeyField("UserID")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
function sendRole()
	local currentUser= _GetDealerID()
	if gtUserRole[currentUser] then
		local RoleID=gtUserRole[currentUser].RoleID;
		local RoleName=gtUserRole[currentUser].RoleName
		local DTSEvent evt = _CreateEventObject("UserRoleOut");
		evt._SetFld("UserID", currentUser);
		evt._SetFld("RoleID", RoleID);
		evt._SetFld("RoleName", RoleName);
		_SendToClients(evt);
	end
end
function initInventory()
	local DTSEvent evt1 = _CreateEventObject("InventoryComponentInfo");
	evt1._SetFld("IssueCode", "clearData");
	_SendToClients(evt1);
	local DTSEvent evt2 = _CreateEventObject("InventoryInfOutput");
	evt2._SetFld("InventoryID", "clearData");
	_SendToClients(evt2);
	local DTSEvent evt3 = _CreateEventObject("InventoryComponentInfoSum");
	evt3._SetFld("InventoryID", "clearData");
	_SendToClients(evt3);

	--gtInventoryHeaderTable={}--不清空只更新
	gtInventoryComponentTable={}
	local currentUser= _GetDealerID()
	local sql=sys_format("select InventoryID,IssueCode,Ratio,Quantity,BuyPrice,IsSelected From dtszgrisk.DTSZGInventoryComponentTable where InventoryID in (select InventoryID From dtszgrisk.DTSZGInventoryHeaderTable where (Owner='%s' or IsPublic='1') and DeleteFlg='0')",currentUser)
	_WriteAplLog(sql)
	_GetCommonData(dataName="ReadInventoryComponent", condition=sql,tablename="DynamicSql")
	
	sql=sys_format("select InventoryID,InventoryName,IsPublic,WeightType,PerAmount,Owner,AddType,DeleteFlg,BuySell,CreateTime,ReserveString,(select count(*) FROM dtszgrisk.DTSZGInventoryComponentTable where InventoryID=ih.InventoryID) as ComponentCount From dtszgrisk.DTSZGInventoryHeaderTable ih where Owner='%s' or IsPublic='1'",currentUser)
	_WriteAplLog(sql)
	_GetCommonData(dataName="ReadInventoryHeader", condition=sql,tablename="DynamicSql")
	
	if gIsInventoryInitialized==false then
		gIsInventoryInitialized=true
		for i,sessionID in pairs(gtSendInventoryInitialized) do
			SendInventoryInitialized(sessionID)
			gtSendInventoryInitialized[i]=nil
		end
	end
	local sortInventoryID={}
	for inventoryID,v in pairs(gtInventoryHeaderTable) do
		local key=v.CreateTime.."#"..inventoryID
		sys_insert(sortInventoryID,key)
	end
	sys_sort(sortInventoryID, "asc")
	for sessionID,v in pairs(gtSessionTable) do 
		for i,key in pairs(sortInventoryID) do
			local inventoryID=getTableByString(key,"#")[2]
			FreshComponent(sessionID,inventoryID)
			sendInventory(sessionID,inventoryID)
		end
		if gtSessionTable[sessionID].CurrentInventoryID~="" then
			local currentInventoryID=gtSessionTable[sessionID].CurrentInventoryID
			sendComponent(sessionID,currentInventoryID)
			SendCurrentInventoryID(sessionID)
		end
		sendQuantityBalance(sessionID)
	end
	for sessionID, inventoryID in pairs(gInventoryIDNeedAutoOrder) do
		if gtInventoryHeaderTable[inventoryID] then
			local bs = gtInventoryHeaderTable[inventoryID].BuySell
			local oc = 0
			if bs == "卖" then
				bs = "1"
				oc = 1
			else
				bs = "3"
			end
			local baSubID = bs
			if oc == 0 then
				baSubID = bs
			else
				if bs == "3" then
					baSubID = "1"
				else
					baSubID = "3"
				end
			end
			if gtSessionTable[sessionID] then
				if gtSessionTable[sessionID].CurBAMapIDTable then
					for baMapID, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
						fireInventory(sessionID,baMapID,baSubID,inventoryID,oc,bs,"",1,0)
					end
				end
			end
		end
		gInventoryIDNeedAutoOrder[sessionID] = ""
	end
end

_DefineEventObject InventoryInfOutput _AS _Output
	_DefFld("InventoryID",_String,20)
	_DefFld("InventoryName", _String, 40);
	_DefFld("IsPublic", _String, 10);
	_DefFld("WeightType", _String, 10)
	_DefFld("PerAmount", _String, 20);
	_DefFld("Owner", _String, 10);
	_DefFld("AdjLNC", _String, 10)
	_DefFld("LastPrice", _String, 20);
	_DefFld("UpDownPercent", _String, 20);
	_DefFld("AddType", _String, 10);
	_DefFld("BuySell", _String, 4);
	_DefFld("ReserveString", _String, 64);
	_DefFld("ComponentCount", _Int, 6);
	_DefFld("Opration", _String, 6);

	_DefKeyField("InventoryID")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
function sendInventory(sessionID,inventoryID)
	if gtInventoryHeaderTable[inventoryID] then
		if gtInventoryHeaderTable[inventoryID].DeleteFlg == "0" then
			onInventoryprice(sessionID,inventoryID)
			local InventoryName=gtInventoryHeaderTable[inventoryID].InventoryName
			local IsPublic=gtInventoryHeaderTable[inventoryID].IsPublic
			local WeightType=gtInventoryHeaderTable[inventoryID].WeightType
			local ReserveString=gtInventoryHeaderTable[inventoryID].ReserveString
			local PerAmount=gtInventoryHeaderTable[inventoryID].PerAmount
			local Owner=gtInventoryHeaderTable[inventoryID].Owner
			local AddType=gtInventoryHeaderTable[inventoryID].AddType
			local BuySell=gtInventoryHeaderTable[inventoryID].BuySell
			local ComponentCount=gtInventoryHeaderTable[inventoryID].ComponentCount
			local Opration=""
			if IsPublic=="1" then
				IsPublic="公有"
			else
				IsPublic="私有"
			end
			if WeightType~="比例" then
				ReserveString="按清单数量与价格"
				PerAmount="-"
			else
				if ReserveString=="" then
					ReserveString="按固定金额"
				elseif ReserveString=="按总资产" or ReserveString=="按可用资金" then
					PerAmount=PerAmount.toString().."%"
				end
			end
			if AddType=="2" then
				AddType="自动"
			else
				AddType="手动"
			end
			local AdjLNC=""
			local LastPrice=""
			local UpDownPercent=""
			if gtInvestoryPriceTable[inventoryID] then
				LastPrice=gtInvestoryPriceTable[inventoryID].LastPrice
				AdjLNC=gtInvestoryPriceTable[inventoryID].AdjustedLNC
				if isNumBer(LastPrice) and isNumBer(AdjLNC) then
					UpDownPercent=100*(LastPrice-AdjLNC)/AdjLNC
					UpDownPercent=sys_format("%.2f",UpDownPercent)
				end
			end
			if BuySell=="买" then
				Opration="速买"
			else
				Opration="速卖"
			end
			local DTSEvent evt = _CreateEventObject("InventoryInfOutput");
			evt._SetFld("InventoryID", inventoryID);
			evt._SetFld("InventoryName", InventoryName);
			evt._SetFld("IsPublic", IsPublic);
			evt._SetFld("WeightType", WeightType);
			evt._SetFld("ReserveString", ReserveString);
			evt._SetFld("PerAmount", PerAmount);
			evt._SetFld("Owner", Owner);
			evt._SetFld("AdjLNC", AdjLNC);
			evt._SetFld("LastPrice", LastPrice);
			evt._SetFld("UpDownPercent", UpDownPercent);
			evt._SetFld("AddType", AddType);
			evt._SetFld("BuySell", BuySell);
			evt._SetFld("ComponentCount", ComponentCount);
			evt._SetFld("Opration", Opration);
			_SendEventToClient(evt,sessionID);
			
			-- 合计
			if inventoryID==gtSessionTable[sessionID].CurrentInventoryID then
				local DTSEvent evt1 = _CreateEventObject("InventoryComponentInfoSum");
				evt1._SetFld("InventoryID", "clearData");
				_SendEventToClient(evt1,sessionID);
				
				evt1._SetFld("InventoryID", inventoryID);
				evt1._SetFld("InventoryName", "合计");
				if gtInvestoryPriceTable[inventoryID] then
					local buyPrice = gtInvestoryPriceTable[inventoryID].BuyPrice
					local lastPrice = gtInvestoryPriceTable[inventoryID].LastPrice
					evt1._SetFld("BuyPrice", buyPrice);
					evt1._SetFld("LastPrice", lastPrice);
				else
					evt1._SetFld("BuyPrice", "");
					evt1._SetFld("LastPrice", "");
				end
				_SendEventToClient(evt1,sessionID);
			end
		end
	end
end
_DefineEventObject NewInventory _AS _Input
	_DefFld("InventoryName", _String, 40);
	_DefFld("WeightType", _String, 20);
	_DefFld("BuySell", _String, 4);
	_DefFld("ReserveString", _String, 64);
	_DefFld("PerAmount", _String, 20);
	_DefFld("AssetValuePercent", _String, 3);
	_DefFld("AvaFundPercent", _String, 3);
	_DefFld("IsPublic", _String, 1);
_End
_OnEventDefined(NewInventory evt,sessionID)
	gCurSession=sessionID
	local InventoryName = evt._GetFld("InventoryName");
	local WeightType = evt._GetFld("WeightType");
	local BuySell = evt._GetFld("BuySell");
	local ReserveString = evt._GetFld("ReserveString");
	local PerAmount = evt._GetFld("PerAmount");
	local AssetValuePercent = evt._GetFld("AssetValuePercent");
	local AvaFundPercent = evt._GetFld("AvaFundPercent");
	local IsPublic = evt._GetFld("IsPublic");
	local log=sys_format("NewInventory[%s,%s,%s,%s,%s,%s,%s,%s]",InventoryName,WeightType,BuySell,ReserveString,PerAmount,AssetValuePercent,AvaFundPercent,IsPublic)
	_WriteAplLog(log)

	if CheckInventoryNameIsExisted(InventoryName) == true then
		local reason=sys_format("组合名称[%s]已被占用，请另外命名",InventoryName);
		_WriteAplLog(reason)
		showLog(sessionID,reason)
		sendOprationLog4Inventory(sessionID,"新建组合","",InventoryName,WeightType,ReserveString,PerAmount,BuySell,"1","失败")
	else
		if ReserveString=="按总资产" then
			PerAmount=AssetValuePercent
		elseif ReserveString=="按可用资金" then
			PerAmount=AvaFundPercent
		end
		local ret=NewInventory(InventoryName,WeightType,ReserveString,PerAmount,IsPublic,"1",BuySell,sessionID)
		if not ret.Result then
			local reason=ret.Reason;
			_WriteAplLog(reason)
			showLog(sessionID,reason)
			sendOprationLog4Inventory(sessionID,"新建组合",ret.InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,"1","失败")
		else
			sendOprationLog4Inventory(sessionID,"新建组合",ret.InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,"1","成功")
		end
	end
_End

_DefineEventObject UpdateInventory _AS _Input
	_DefFld("InventoryID",_String,20)
	_DefFld("InventoryName", _String, 40);
	_DefFld("WeightType", _String, 20);
	_DefFld("BuySell", _String, 4);
	_DefFld("ReserveString", _String, 64);
	_DefFld("PerAmount", _String, 20);
	_DefFld("AssetValuePercent", _String, 3);
	_DefFld("AvaFundPercent", _String, 3);
	_DefFld("IsPublic", _String, 1);
_End
_OnEventDefined(UpdateInventory evt,sessionID)
	gCurSession=sessionID
	local InventoryID = evt._GetFld("InventoryID");
	local InventoryName = evt._GetFld("InventoryName");
	local WeightType = evt._GetFld("WeightType");
	local BuySell = evt._GetFld("BuySell");
	local ReserveString = evt._GetFld("ReserveString");
	local PerAmount = evt._GetFld("PerAmount");
	local AssetValuePercent = evt._GetFld("AssetValuePercent");
	local AvaFundPercent = evt._GetFld("AvaFundPercent");
	local IsPublic = evt._GetFld("IsPublic");
	local log=sys_format("UpdateInventory[%s,%s,%s,%s,%s,%s,%s,%s,%s]",InventoryID,InventoryName,WeightType,BuySell,ReserveString,PerAmount,AssetValuePercent,AvaFundPercent,IsPublic)
	_WriteAplLog(log)
	local check = true
	if gtInventoryHeaderTable[InventoryID] then
		if ReserveString=="按总资产" then
			PerAmount=AssetValuePercent
		elseif ReserveString=="按可用资金" then
			PerAmount=AvaFundPercent
		end
		local oldInventoryName = gtInventoryHeaderTable[InventoryID].InventoryName
		if oldInventoryName ~= InventoryName then
			if CheckInventoryNameIsExisted(InventoryName) == true then
				check = false
				local reason=sys_format("组合名称[%s]已被占用，请另外命名",InventoryName);
				_WriteAplLog(reason)
				showLog(sessionID,reason)
				sendOprationLog4Inventory(sessionID,"修改组合",InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,"","失败")
			end
		end
		if check == true then
			local currentUserID= _GetDealerID()
			local Owner=gtInventoryHeaderTable[InventoryID].Owner
			if currentUserID==Owner then
				local _String sql = sys_format("Update dtszgrisk.DTSZGInventoryHeaderTable Set InventoryName='%s',WeightType='%s',PerAmount='%f' ,IsPublic='%s',BuySell='%s',ReserveString='%s' where InventoryID='%s'",InventoryName,WeightType,PerAmount,IsPublic,BuySell,ReserveString,InventoryID)
				_WriteAplLog(sql)
				--local UpdateInventory = _UpdateCommonData(type=_Modify,condition="",DTSDynamicSql object=(Data = sql));
				local UpdateInventory = _UpdateCommonData(type=_Insert,condition="",DTSDynamicSql object=(Data = sql));
				if UpdateInventory then
					_WriteAplLog("-----------UpdateInventory success-----------")
				else
					_WriteAplLog("-----------UpdateInventory failure------------")
				end
				gtInventoryHeaderTable[InventoryID].InventoryName=InventoryName
				sendOprationLog4Inventory(sessionID,"修改组合",InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,"","成功")
				initInventory()
			else
				local reason=sys_format("组合[%s]属于用户[%s],无权修改",InventoryID,Owner);
				showLog(sessionID,reason)
				sendOprationLog4Inventory(sessionID,"修改组合",InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,"","失败")
			end
		end
	end
_End
_DefineEventObject DeleteInventory _AS _Input
	_DefFld("InventoryID",_String,20)
_End
_OnEventDefined(DeleteInventory evt,sessionID)
	gCurSession=sessionID
	local inventoryID = evt._GetFld("InventoryID");
	local currentUserID= _GetDealerID()
	local curIssueCode=gtSessionTable[sessionID].CurIssueCode
	if gtInventoryHeaderTable[inventoryID] then
		local Owner=gtInventoryHeaderTable[inventoryID].Owner
		if currentUserID==Owner then
			if gtSessionTable[sessionID].CurrentInventoryID==inventoryID then
				gtSessionTable[sessionID].CurrentInventoryID=""
			end
			if curIssueCode==inventoryID then
				curIssueCode=""
				gtSessionTable[sessionID].CurIssueCode=""
			end

			local _String delSql = sys_format("Update dtszgrisk.DTSZGInventoryHeaderTable Set DeleteFlg='1' where InventoryID='%s'",inventoryID)
			_WriteAplLog(delSql)
			--local DeleteInventory = _UpdateCommonData(type=_Modify,condition="",DTSDynamicSql object=(Data = delSql));
			local DeleteInventory = _UpdateCommonData(type=_Insert,condition="",DTSDynamicSql object=(Data = delSql));
			if DeleteInventory then
				_WriteAplLog("-----------DeleteInventory success-----------")
			else
				_WriteAplLog("-----------DeleteInventory failure------------")
			end
			gtInventoryHeaderTable[inventoryID].DeleteFlg="1"
			sendOprationLog4Inventory(sessionID,"删除组合",inventoryID,gtInventoryHeaderTable[inventoryID].InventoryName,gtInventoryHeaderTable[inventoryID].WeightType,gtInventoryHeaderTable[inventoryID].ReserveString,gtInventoryHeaderTable[inventoryID].PerAmount,gtInventoryHeaderTable[inventoryID].BuySell,"","成功")
			initInventory()
		else
			local reason=sys_format("组合[%s]属于用户[%s],无权删除",inventoryID,Owner);
			showLog(sessionID,reason)
			sendOprationLog4Inventory(sessionID,"删除组合",inventoryID,gtInventoryHeaderTable[inventoryID].InventoryName,gtInventoryHeaderTable[inventoryID].WeightType,gtInventoryHeaderTable[inventoryID].ReserveString,gtInventoryHeaderTable[inventoryID].PerAmount,gtInventoryHeaderTable[inventoryID].BuySell,"","失败")
		end
	end
_End

_DefineEventObject ReloadInventory _AS _Input
_End
_OnEventDefined(ReloadInventory evt,sessionID)
	gCurSession=sessionID
	gtSessionTable[sessionID].CurrentInventoryID=""
	initInventory()
_End
function getLines(text)
    text = text.."\n"
	local lines = {}
	local len = sys_len(text)
	local lineBegin = 1
	for i = 1, len do
		local chr = sys_sub(text, i, i)
		if chr == "\n" then
			if lineBegin <= i-1 then
				local line = sys_sub(text, lineBegin, i-1)
				sys_insert(lines, line)
			end
			lineBegin = i + 1;
		end
	end
	return lines
end
function getNameAndValue(line)
	local lin = line
	local rtn = {}
	local len = sys_len(line)
	local begin=1
	for i = 1, len do
		local chr = sys_sub(line, i, i)
		if i<len then
			if chr == "," then
				if begin<=i-1 then 
					sys_insert(rtn, sys_sub(line, begin, i-1))
				end
				begin=i+1
			end
		else
			if begin<=i then 
				sys_insert(rtn, sys_sub(line, begin, i))
			end
		end
	end
	return rtn
end

function innerTrimAll(line, trimChar)
	local len1 = sys_len(line);
	local rt = "";
	for i = 1, len1 do
		local chr = sys_sub(line,i,i);
		if trimChar ~= chr then
			rt = rt .. chr;
		end
	end
	return rt;
end

function isNumBer(s)
	local _String v=s or ""
	local ret=true
	local flag=false
	if not v then
		ret=false
	elseif v=="" then
		ret=false
	else
		local len = sys_len(v);
		for i = 1, len do
			local chr = sys_sub(v,i,i);
			if chr=="0" or chr=="1" or chr=="2" or chr=="3"or chr=="4"or chr=="5"or chr=="6"or chr=="7"or chr=="8"or chr=="9" then
			elseif i==1 and chr=="-" and len>1 then
			elseif i>1 and chr=="." and len>i and (not flag) then
				flag=true
			else
				ret=false
			end
		end
	end
	return ret;
end
_DefineEventObject ComponentTextOut _AS _Output
	_DefFld("InventoryID",_String,20)
	_DefFld("Text", _Meta, 4);

	_DefKeyField("InventoryID")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

_DefineEventObject RquireComponentText _AS _Input
	_DefFld("InventoryID", _String, 20)
_End
_OnEventDefined(RquireComponentText evt,sessionID)
	gCurSession=sessionID
	local inventoryID = evt._GetFld("InventoryID")
	local text=""
	if gtInventoryHeaderTable[inventoryID] then
		local weightType=gtInventoryHeaderTable[inventoryID].WeightType
		if gtInventoryComponentTable[inventoryID] then
			for issueCode,v in pairs(gtInventoryComponentTable[inventoryID])do
				local quantity = v.Quantity
				local ratio = v.Ratio
				local buyPrice=v.BuyPrice
				
				local line=""
				if weightType=="比例" then
					if buyPrice=="" then 
						line=sys_format("%s,%s",issueCode,ratio)
					else
						line=sys_format("%s,%s,%s",issueCode,ratio,buyPrice)
					end 
				elseif weightType=="数量" then
					if buyPrice=="" then 
						line=sys_format("%s,%d",issueCode,quantity)
					else
						line=sys_format("%s,%d,%s",issueCode,quantity,buyPrice)
					end 
				end
				if line~="" then
					if text=="" then
						text=line
					else
						text=text.."\r\n"..line
					end
				end
			end
		end
	end
	local DTSEvent evt = _CreateEventObject("ComponentTextOut");
	evt._SetFld("InventoryID", inventoryID);
	evt._SetFld("Text", text);
	_SendEventToClient(evt,sessionID);	
_End
_DefineEventObject ComponentSet _AS _Input
	_DefFld("InventoryID", _String, 20)
	_DefFld("Text",  _Meta, 4)
_End

_OnEventDefined(ComponentSet evt,sessionID)
	gCurSession=sessionID
	local inventoryID = evt._GetFld("InventoryID")
	local text = evt._GetFld("Text")
	local testLog=sys_format("ComponentSet:%s\n%s",inventoryID,text)
	_WriteAplLog(testLog)
	
	SetComponent(sessionID,inventoryID,text,"",false)
_End
_DefineEventObject InventoryComponentInfoSum _AS _Output
	_DefFld("InventoryID",_String,20);
	_DefFld("InventoryName",_String,40);
	_DefFld("BuyPrice", _String, 20);	
	_DefFld("LastPrice", _String, 20);

	_DefKeyField("InventoryID")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
_DefineEventObject InventoryComponentInfo _AS _Output
	_DefFld("IsSelected",_String,1)
	_DefFld("InventoryID",_String,20)
	_DefFld("InventoryName", _String, 40);
	_DefFld("IssueCode",_String,20)
	_DefFld("IssueName", _String, 40);
	_DefFld("WeightType", _String, 10)
	_DefFld("Quantity", _String, 20);
	_DefFld("Ratio", _String, 20);
	_DefFld("BuyPrice", _String, 20);	
	_DefFld("AdjLNC", _String, 10)
	_DefFld("LastPrice", _String, 20);
	_DefFld("UpDownPercent", _String, 20);

	_DefKeyField("InventoryID")
	_DefKeyField("IssueCode")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
function FreshComponent(sessionID,inventoryID)
	if gtInventoryHeaderTable[inventoryID] then
		local weightType=gtInventoryHeaderTable[inventoryID].WeightType
		if gtInventoryComponentTable[inventoryID] then
			for issueCode,v in pairs(gtInventoryComponentTable[inventoryID])do
				if weightType=="比例" then
					local bs = gtInventoryHeaderTable[inventoryID].BuySell
					if bs=="买" then
						bs="3"
					elseif bs=="卖" then
						bs="1"
					end
					local ratio = v.Ratio
					local quantity=0
					local buyPrice = v.BuyPrice
					if not isNumBer(buyPrice) then
						buyPrice=getInventoryIssueOrderPrice(issueCode,buyPrice,bs)
					end
					if isNumBer(buyPrice) then
						local reserveString = gtInventoryHeaderTable[inventoryID].ReserveString;
						local perAmount = gtInventoryHeaderTable[inventoryID].PerAmount;
						if reserveString=="按固定金额" then
							if bs=="3" then
								quantity =perAmount*ratio / 100 / (buyPrice * (1 + gMaxFare))
								quantity=sys_floor(quantity/100)*100
							else
								quantity=perAmount*ratio/buyPrice/100;
								quantity=sys_floor(quantity/100+0.5)*100
							end
						elseif reserveString=="按总资产" then
							if gtSessionTable[sessionID].CurBAMapIDTable then
								for bAMap, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
									local accCode = _PosBAMapAccount[bAMap]
									if _PosFundStatus[accCode] then
										local assetValue=_PosFundStatus[accCode].AssetValue
										local neededFund = assetValue*perAmount/100*ratio/100
										local qty = 0
										if bs=="3" then
											local contractSize = _PosIssueContractSizeTable[issueCode]
											local bail = _PosGetBail(accCode, issueCode, bs, POS_SPECULATE)
											qty=neededFund / (buyPrice * bail * contractSize * (1 + gMaxFare))
											qty=sys_floor(qty/100)*100
										else
											qty = neededFund / buyPrice
											qty=sys_floor(qty/100+0.5)*100
										end
										quantity=quantity+qty
									end
								end
							end
						elseif reserveString=="按可用资金" then
							if gtSessionTable[sessionID].CurBAMapIDTable then
								for bAMap, v in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
									local accCode = _PosBAMapAccount[bAMap]
									if _PosFundStatus[accCode] then
										local avlFund=_PosFundStatus[accCode].AvlFund
										local neededFund = avlFund*perAmount/100*ratio/100
										local qty = 0
										if bs=="3" then
											local contractSize = _PosIssueContractSizeTable[issueCode]
											local bail = _PosGetBail(accCode, issueCode, bs, POS_SPECULATE)
											qty=neededFund / (buyPrice * bail * contractSize * (1 + gMaxFare))
											qty=sys_floor(qty/100)*100
										else
											qty = neededFund / buyPrice
											qty=sys_floor(qty/100+0.5)*100
										end
										quantity=quantity+qty
									end
								end
							end
						end
					end
					v.Quantity = quantity
				end
			end
		end
	end
end
function sendComponent(sessionID,inventoryID)
	if inventoryID==gtSessionTable[sessionID].CurrentInventoryID then
		local DTSEvent evt = _CreateEventObject("InventoryComponentInfo");
		evt._SetFld("IssueCode", "clearData");
		_SendEventToClient(evt,sessionID);
		if gtInventoryHeaderTable[inventoryID] then
			local inventoryName=gtInventoryHeaderTable[inventoryID].InventoryName
			local weightType=gtInventoryHeaderTable[inventoryID].WeightType
			evt._SetFld("InventoryID", inventoryID);
			evt._SetFld("InventoryName", inventoryName);
			evt._SetFld("WeightType", weightType);
			if gtInventoryComponentTable[inventoryID] then
				for issueCode,v in pairs(gtInventoryComponentTable[inventoryID])do
					local issueName = _PosIssueNameTable[issueCode] or ""
					local quantity = v.Quantity
					local ratio = v.Ratio
					local buyPrice = v.BuyPrice
					local isSelected=v.IsSelected
					quantity=sys_floor(quantity)
					quantity=showFormat(quantity,2)
					evt._SetFld("IsSelected",isSelected)
					evt._SetFld("IssueCode", issueCode);
					evt._SetFld("IssueName", issueName);
					evt._SetFld("Quantity", quantity);
					if weightType=="比例" then
						evt._SetFld("Ratio", ratio);
					elseif weightType=="数量" then
						evt._SetFld("Ratio", "");
					end
					evt._SetFld("BuyPrice", buyPrice);
					
					if 	gtPriceTable[issueCode] then
						local adjLNC = gtPriceTable[issueCode].adjLNC;
						local lastPrice = gtPriceTable[issueCode].lastPrice;

						local upDownPercent=100*(lastPrice-adjLNC)/adjLNC;
						upDownPercent=sys_format("%.2f",upDownPercent)
						evt._SetFld("AdjLNC", adjLNC);
						evt._SetFld("LastPrice", lastPrice);
						evt._SetFld("UpDownPercent", upDownPercent);
					else
						evt._SetFld("AdjLNC", "");
						evt._SetFld("LastPrice", "");
						evt._SetFld("UpDownPercent", "");
					end
					_SendEventToClient(evt,sessionID);
				end
			end
		end
	end
end

function onInventoryprice(sessionID,inventoryID)
	if gtInventoryHeaderTable[inventoryID] and gtInventoryComponentTable[inventoryID] then
		local issueName = gtInventoryHeaderTable[inventoryID].InventoryName
		local lastPrice =0
		local lastVolume = 0
		local adjLNC = 0
		local upperLimitPrice = 0
		local lowerLimitPrice = 0
		local bidPrice_1 =0
		local bidPrice_2 = 0
		local bidPrice_3 = 0
		local bidPrice_4 = 0
		local bidPrice_5 =0
		local bidPrice_6 = "-"
		local bidPrice_7 = "-"
		local bidPrice_8 = "-"
		local bidPrice_9 = "-"
		local bidPrice_10 = "-"
		local bidQty_1 = 0
		local bidQty_2 = 0
		local bidQty_3 =0
		local bidQty_4 = 0
		local bidQty_5 = 0
		local bidQty_6 = "-"
		local bidQty_7 = "-"
		local bidQty_8 = "-"
		local bidQty_9 = "-"
		local bidQty_10 = "-"
		local askPrice_1 = 0
		local askPrice_2 = 0
		local askPrice_3 = 0
		local askPrice_4 = 0
		local askPrice_5 = 0
		local askPrice_6 = "-"
		local askPrice_7 = "-"
		local askPrice_8 = "-"
		local askPrice_9 = "-"
		local askPrice_10 = "-"
		local askQty_1 = 0
		local askQty_2 = 0
		local askQty_3 = 0
		local askQty_4 =0
		local askQty_5 =0
		local askQty_6 = "-"
		local askQty_7 = "-"
		local askQty_8 = "-"
		local askQty_9 = "-"
		local askQty_10 = "-"
		local buyPrice = 0
		for issue,v in pairs(gtInventoryComponentTable[inventoryID]) do
			local isSelected = v.IsSelected
			if  gtPriceTable[issue] and isSelected == "1" then
				local price=gtPriceTable[issue]
				local sublastPrice=price.lastPrice
				local sublastVolume = price.lastVolume
				local subadjLNC = price.adjLNC
				local subupperLimitPrice = price.upperLimitPrice
				local sublowerLimitPrice = price.lowerLimitPrice
				local subbidPrice_1 = price.bidPrice_1
				local subbidPrice_2 = price.bidPrice_2
				local subbidPrice_3 = price.bidPrice_3
				local subbidPrice_4 = price.bidPrice_4
				local subbidPrice_5 = price.bidPrice_5
				local subbidQty_1 = price.bidQty_1
				local subbidQty_2 = price.bidQty_2
				local subbidQty_3 = price.bidQty_3
				local subbidQty_4 = price.bidQty_4
				local subbidQty_5 = price.bidQty_5

				local subaskPrice_1 = price.askPrice_1
				local subaskPrice_2 = price.askPrice_2
				local subaskPrice_3 = price.askPrice_3
				local subaskPrice_4 = price.askPrice_4
				local subaskPrice_5 = price.askPrice_5
				local subaskQty_1 = price.askQty_1
				local subaskQty_2 = price.askQty_2
				local subaskQty_3 = price.askQty_3
				local subaskQty_4 = price.askQty_4
				local subaskQty_5 = price.askQty_5
				local subBuyPrice = v.BuyPrice
				if not isNumBer(sublastPrice) then
					sublastPrice= 0
				end
				if not isNumBer(sublastVolume) then
					sublastVolume= 0
				end

				if not isNumBer(subadjLNC) then
					subadjLNC= 0
				end
				if not isNumBer(subupperLimitPrice) then
					subupperLimitPrice= 0
				end
				if not isNumBer(sublowerLimitPrice) then
					sublowerLimitPrice= 0
				end
				if not isNumBer(subbidPrice_1) then
					subbidPrice_1= 0
				end
				if not isNumBer(subbidPrice_2) then
					subbidPrice_2= 0
				end
				if not isNumBer(subbidPrice_3) then
					subbidPrice_3= 0
				end
				if not isNumBer(subbidPrice_4) then
					subbidPrice_4= 0
				end
				if not isNumBer(subbidPrice_5) then
					subbidPrice_5= 0
				end
				if not isNumBer(subaskPrice_1) then
					subaskPrice_1= 0
				end
				if not isNumBer(subaskPrice_2) then
					subaskPrice_2= 0
				end
				if not isNumBer(subaskPrice_3) then
					subaskPrice_3= 0
				end
				if not isNumBer(subaskPrice_4) then
					subaskPrice_4= 0
				end
				if not isNumBer(subaskPrice_5) then
					subaskPrice_5= 0
				end


				if not isNumBer(subbidQty_1) then
					subbidQty_1= 0
				end
				if not isNumBer(subbidQty_2) then
					subbidQty_2= 0
				end
				if not isNumBer(subbidQty_3) then
					subbidQty_3= 0
				end
				if not isNumBer(subbidQty_4) then
					subbidQty_4= 0
				end
				if not isNumBer(subbidQty_5) then
					subbidQty_5= 0
				end


				if not isNumBer(subaskQty_1) then
					subaskQty_1= 0
				end
				if not isNumBer(subaskQty_2) then
					subaskQty_2= 0
				end
				if not isNumBer(subaskQty_3) then
					subaskQty_3= 0
				end
				if not isNumBer(subaskQty_4) then
					subaskQty_4= 0
				end
				if not isNumBer(subaskQty_5) then
					subaskQty_5= 0
				end

				local quantity=v.Quantity
				lastPrice = lastPrice + sublastPrice*quantity
				adjLNC = adjLNC +subadjLNC*quantity
				upperLimitPrice = upperLimitPrice +subupperLimitPrice*quantity
				lowerLimitPrice = lowerLimitPrice + sublowerLimitPrice*quantity
				bidPrice_1 =bidPrice_1 + subbidPrice_1*quantity
				bidPrice_2 =bidPrice_2 + subbidPrice_2*quantity
				bidPrice_3 =bidPrice_3 + subbidPrice_3*quantity
				bidPrice_4 =bidPrice_4 + subbidPrice_4*quantity
				bidPrice_5 =bidPrice_5 + subbidPrice_5*quantity

				askPrice_1=askPrice_1 + subaskPrice_1*quantity
				askPrice_2=askPrice_2 + subaskPrice_2*quantity
				askPrice_3=askPrice_3 + subaskPrice_3*quantity
				askPrice_4=askPrice_4 + subaskPrice_4*quantity
				askPrice_5=askPrice_5 + subaskPrice_5*quantity

				lastVolume=lastVolume+sublastVolume*sublastPrice
				bidQty_1=bidQty_1+subbidPrice_1*subbidQty_1
				bidQty_2=bidQty_2+subbidPrice_2*subbidQty_2
				bidQty_3=bidQty_3+subbidPrice_3*subbidQty_3
				bidQty_4=subbidQty_4+subbidPrice_4*subbidQty_4
				bidQty_5=bidQty_5+subbidPrice_5*subbidQty_5

				askQty_1=askQty_1+subaskPrice_1*subaskQty_1
				askQty_2=askQty_2+subaskPrice_2*subaskQty_2
				askQty_3=askQty_3+subaskPrice_3*subaskQty_3
				askQty_4=askQty_4+subaskPrice_4*subaskQty_4
				askQty_5=askQty_5+subaskPrice_5*subaskQty_5
				
				if  subBuyPrice=="涨停" then
					subBuyPrice=subupperLimitPrice
				elseif  subBuyPrice=="卖5" then
					subBuyPrice=subaskPrice_5
				elseif  subBuyPrice=="卖4" then
					subBuyPrice=subaskPrice_4
				elseif  subBuyPrice=="卖3" then
					subBuyPrice=subaskPrice_3
				elseif  subBuyPrice=="卖2" then
					subBuyPrice=subaskPrice_2
				elseif  subBuyPrice=="卖1" then
					subBuyPrice=subaskPrice_1
				elseif  subBuyPrice=="买1" then
					subBuyPrice=subbidPrice_1
				elseif  subBuyPrice=="买2" then
					subBuyPrice=subbidPrice_2
				elseif  subBuyPrice=="买3" then
					subBuyPrice=subbidPrice_3
				elseif  subBuyPrice=="买4" then
					subBuyPrice=subbidPrice_4
				elseif  subBuyPrice=="买5" then
					subBuyPrice=subbidPrice_5
				elseif  subBuyPrice=="跌停" then
					subBuyPrice=sublowerLimitPrice
				elseif  subBuyPrice=="" then  --没有设置价格的取对手价
					if gtInventoryHeaderTable[inventoryID].BuySell=="买" then
						subBuyPrice=subaskPrice_1
					else
						subBuyPrice=subbidPrice_1
					end
				end
				if isNumBer(subBuyPrice) then
					if subBuyPrice-0.00001>=0 then
						buyPrice = buyPrice + subBuyPrice*quantity
					else
						buyPrice = buyPrice + sublastPrice*quantity
					end
				else
					buyPrice = buyPrice + sublastPrice*quantity
				end
			end
		end
		if buyPrice==0 then
			buyPrice = "-"
		else
			buyPrice=sys_format("%.2f",buyPrice)
		end
		if lastPrice==0 then
			lastPrice = "-"
			bidQty_1="-";
			bidQty_2="-";
			bidQty_3="-";
			bidQty_4="-";
			bidQty_5="-";

			askQty_1="-";
			askQty_2="-";
			askQty_3="-";
			askQty_4="-";
			askQty_5="-";
		else
			bidQty_1=bidQty_1/lastPrice
			bidQty_2=bidQty_2/lastPrice
			bidQty_3=bidQty_3/lastPrice
			bidQty_4=bidQty_4/lastPrice
			bidQty_5=bidQty_5/lastPrice

			askQty_1=askQty_1/lastPrice
			askQty_2=askQty_2/lastPrice
			askQty_3=askQty_3/lastPrice
			askQty_4=askQty_4/lastPrice
			askQty_5=askQty_5/lastPrice

			bidQty_1=bidQty_1.toInt();
			bidQty_2=bidQty_2.toInt();
			bidQty_3=bidQty_3.toInt();
			bidQty_4=bidQty_4.toInt();
			bidQty_5=bidQty_5.toInt();

			askQty_1=askQty_1.toInt();
			askQty_2=askQty_2.toInt();
			askQty_3=askQty_3.toInt();
			askQty_4=askQty_4.toInt();
			askQty_5=askQty_5.toInt();
			lastPrice=sys_format("%.2f",lastPrice)
		end
		if lastVolume==0 then
			lastVolume = "-"
		end
		if adjLNC==0 then
			adjLNC = "-"
		else
			adjLNC=sys_format("%.2f",adjLNC)
		end
		if upperLimitPrice==0 then
			upperLimitPrice = "-"
		else
			upperLimitPrice=sys_format("%.2f",upperLimitPrice)
		end
		if lowerLimitPrice==0 then
			lowerLimitPrice = "-"
		else
			lowerLimitPrice=sys_format("%.2f",lowerLimitPrice)
		end
		if bidPrice_1==0 then
			bidPrice_1="-"
		else
			bidPrice_1=sys_format("%.2f",bidPrice_1)
		end
		if bidPrice_2==0 then
			bidPrice_2="-"
		else
			bidPrice_2=sys_format("%.2f",bidPrice_2)
		end
		if bidPrice_3==0 then
			bidPrice_3="-"
		else
			bidPrice_3=sys_format("%.2f",bidPrice_3)
		end
		if bidPrice_4==0 then
			bidPrice_4="-"
		else
			bidPrice_4=sys_format("%.2f",bidPrice_4)
		end
		if bidPrice_5==0 then
			bidPrice_5="-"
		else
			bidPrice_5=sys_format("%.2f",bidPrice_5)
		end
		if bidQty_1==0 then
			bidQty_1="-"
		end
		if bidQty_2==0 then
			bidQty_2="-"
		end
		if bidQty_3==0 then
			bidQty_3="-"
		end
		if bidQty_4==0 then
			bidQty_4="-"
		end
		if bidQty_5==0 then
			bidQty_5="-"
		end
		if askPrice_1==0 then
			askPrice_1="-"
		else
			askPrice_1=sys_format("%.2f",askPrice_1)
		end
		if askPrice_2==0 then
			askPrice_2="-"
		else
			askPrice_2=sys_format("%.2f",askPrice_2)
		end
		if askPrice_3==0 then
			askPrice_3="-"
		else
			askPrice_3=sys_format("%.2f",askPrice_3)
		end
		if askPrice_4==0 then
			askPrice_4="-"
		else
			askPrice_4=sys_format("%.2f",askPrice_4)
		end
		if askPrice_5==0 then
			askPrice_5="-"
		else
			askPrice_5=sys_format("%.2f",askPrice_5)
		end
		if askQty_1==0 then
			askQty_1="-"
		end
		if askQty_2==0 then
			askQty_2="-"
		end
		if askQty_3==0 then
			askQty_3="-"
		end
		if askQty_4==0 then
			askQty_4="-"
		end
		if askQty_5==0 then
			askQty_5="-"
		end
		gtInvestoryPriceTable[inventoryID]={}
		gtInvestoryPriceTable[inventoryID].LastPrice=lastPrice
		gtInvestoryPriceTable[inventoryID].AdjustedLNC=adjLNC
		gtInvestoryPriceTable[inventoryID].UpLimitPrice=upperLimitPrice
		gtInvestoryPriceTable[inventoryID].LowLimitPrice=lowerLimitPrice
		gtInvestoryPriceTable[inventoryID].BidPrice1=bidPrice_1
		gtInvestoryPriceTable[inventoryID].BidPrice2=bidPrice_2
		gtInvestoryPriceTable[inventoryID].BidPrice3=bidPrice_3
		gtInvestoryPriceTable[inventoryID].BidPrice4=bidPrice_4
		gtInvestoryPriceTable[inventoryID].BidPrice5=bidPrice_5
		gtInvestoryPriceTable[inventoryID].AskPrice1=askPrice_1
		gtInvestoryPriceTable[inventoryID].AskPrice2=askPrice_2
		gtInvestoryPriceTable[inventoryID].AskPrice3=askPrice_3
		gtInvestoryPriceTable[inventoryID].AskPrice4=askPrice_4
		gtInvestoryPriceTable[inventoryID].AskPrice5=askPrice_5
		gtInvestoryPriceTable[inventoryID].BuyPrice=buyPrice
		if inventoryID==gtSessionTable[sessionID].CurIssueCode then
			local DTSEvent priceEvent = _CreateEventObject("PriceServerEvent")
			priceEvent._SetFld("IssueCode", inventoryID)
			priceEvent._SetFld("IssueName", issueName)
			priceEvent._SetFld("LastPrice", lastPrice)
			priceEvent._SetFld("LastVolume", lastVolume)
			priceEvent._SetFld("AdjustedLNC", adjLNC)
			priceEvent._SetFld("UpLimitPrice", upperLimitPrice)
			priceEvent._SetFld("LowLimitPrice", lowerLimitPrice)
			priceEvent._SetFld("BidPrice1", bidPrice_1)
			priceEvent._SetFld("BidPrice2", bidPrice_2)
			priceEvent._SetFld("BidPrice3", bidPrice_3)
			priceEvent._SetFld("BidPrice4", bidPrice_4)
			priceEvent._SetFld("BidPrice5", bidPrice_5)
			priceEvent._SetFld("BidPrice6", bidPrice_6)
			priceEvent._SetFld("BidPrice7", bidPrice_7)
			priceEvent._SetFld("BidPrice8", bidPrice_8)
			priceEvent._SetFld("BidPrice9", bidPrice_9)
			priceEvent._SetFld("BidPrice10", bidPrice_10)
			priceEvent._SetFld("AskPrice1", askPrice_1)
			priceEvent._SetFld("AskPrice2", askPrice_2)
			priceEvent._SetFld("AskPrice3", askPrice_3)
			priceEvent._SetFld("AskPrice4", askPrice_4)
			priceEvent._SetFld("AskPrice5", askPrice_5)
			priceEvent._SetFld("AskPrice6", askPrice_6)
			priceEvent._SetFld("AskPrice7", askPrice_7)
			priceEvent._SetFld("AskPrice8", askPrice_8)
			priceEvent._SetFld("AskPrice9", askPrice_9)
			priceEvent._SetFld("AskPrice10", askPrice_10)
			priceEvent._SetFld("BidQty1", bidQty_1)
			priceEvent._SetFld("BidQty2", bidQty_2)
			priceEvent._SetFld("BidQty3", bidQty_3)
			priceEvent._SetFld("BidQty4", bidQty_4)
			priceEvent._SetFld("BidQty5", bidQty_5)
			priceEvent._SetFld("BidQty6", bidQty_6)
			priceEvent._SetFld("BidQty7", bidQty_7)
			priceEvent._SetFld("BidQty8", bidQty_8)
			priceEvent._SetFld("BidQty9", bidQty_9)
			priceEvent._SetFld("BidQty10", bidQty_10)
			priceEvent._SetFld("AskQty1", askQty_1)
			priceEvent._SetFld("AskQty2", askQty_2)
			priceEvent._SetFld("AskQty3", askQty_3)
			priceEvent._SetFld("AskQty4", askQty_4)
			priceEvent._SetFld("AskQty5", askQty_5)
			priceEvent._SetFld("AskQty6", askQty_6)
			priceEvent._SetFld("AskQty7", askQty_7)
			priceEvent._SetFld("AskQty8", askQty_8)
			priceEvent._SetFld("AskQty9", askQty_9)
			priceEvent._SetFld("AskQty10", askQty_10)

			local accountCode = ""
			if gtSessionTable[sessionID] then
				local baMapID=gtSessionTable[sessionID].SelectedBAMapID
				accountCode = _PosBAMapAccount[baMapID]
			end

			local marketCode = "ZH"
			local strBailRatio = 1
			priceEvent._SetFld("MarketCode", marketCode)

			local testlog = ""
			if accountCode and accountCode ~= ""  then
				local availableFund = _PosFundStatus[accountCode]["AvlFund"]
				local temAvailableFund = sys_format("%.2f",availableFund);
				priceEvent._SetFld("AvlFund", temAvailableFund)

				local ContractSize =1
				priceEvent._SetFld("ContractSize", ContractSize)

				local OpenAvailableQty = 0
				local CloseAvailableQty = 0
				local AvlTodayQuantity = 0
				local AvlPrevQuantity = 0

				priceEvent._SetFld("OpenAvailableQty", OpenAvailableQty)
				priceEvent._SetFld("CloseAvailableQty", CloseAvailableQty)
				priceEvent._SetFld("BailRatio", strBailRatio)
				_SendEventToClient(priceEvent,sessionID);
			else
				priceEvent._SetFld("AvlFund", 0)
				priceEvent._SetFld("OpenAvailableQty", 0)
				priceEvent._SetFld("CloseAvailableQty", 0)
				priceEvent._SetFld("BailRatio", 0)
				_SendEventToClient(priceEvent,sessionID);
			end
		end
	end
end

function getInventoryIssueOrderPrice(issueCode,priceTye,bs)
	local orderPrice=""
	if gtPriceTable[issueCode] then
		tprice=gtPriceTable[issueCode]
		if  priceTye=="涨停" then
			orderPrice=tprice.upperLimitPrice
		elseif  priceTye=="卖5" then
			orderPrice=tprice.askPrice_5
		elseif  priceTye=="卖4" then
			orderPrice=tprice.askPrice_4
		elseif  priceTye=="卖3" then
			orderPrice=tprice.askPrice_3
		elseif  priceTye=="卖2" then
			orderPrice=tprice.askPrice_2
		elseif  priceTye=="卖1" then
			orderPrice=tprice.askPrice_1
		elseif  priceTye=="买1" then
			orderPrice=tprice.bidPrice_1
		elseif  priceTye=="买2" then
			orderPrice=tprice.bidPrice_2
		elseif  priceTye=="买3" then
			orderPrice=tprice.bidPrice_3
		elseif  priceTye=="买4" then
			orderPrice=tprice.bidPrice_4
		elseif  priceTye=="买5" then
			orderPrice=tprice.bidPrice_5
		elseif  priceTye=="跌停" then
			orderPrice=tprice.lowerLimitPrice
		elseif  priceTye=="" then --没有设置价格的取对手价
			if bs=="3" then
				orderPrice=tprice.askPrice_1
			else
				orderPrice=tprice.bidPrice_1
			end
		end
	end
	return orderPrice
end

function fireInventory(sessionID,baMapID,baSubID,inventoryID,oc,bs,price,unit,creRed)
	if gtInventoryHeaderTable[inventoryID] and gtInventoryComponentTable[inventoryID] then
		local orderTable={}
		local num=0
		local dealerID = GetOrderDealerID(baMapID)
		local accCode = _PosBAMapAccount[baMapID]
		if bs=="3" then
			if gtInventoryHeaderTable[inventoryID].WeightType=="数量" then
				for issue,v in pairs(gtInventoryComponentTable[inventoryID]) do
					local isSelected = v.IsSelected
					local buyPrice=v.BuyPrice
					local log = sys_format("组合[%s]成分股[%s]是否选中[%s]",inventoryID,issue,isSelected)
					_WriteAplLog(log)
					if v.Quantity and isSelected == "1" then
						local issueQty =v.Quantity*unit
						issueQty=sys_floor(issueQty/100)*100
						if  issueQty>=100 then
							local order={}
							order.IssueCode=issue
							order.OpenClose=oc
							order.BuySell=bs
							order.BAMapID=baMapID
							order.BASubID=baSubID
							order.Quantity=issueQty
							order.CreRed=creRed
							order.OwnerID=dealerID
							local orderPrice=""
							if isNumBer(buyPrice) then
								if buyPrice-0.00001>=0 then
									orderPrice=buyPrice
								end
							else
								orderPrice=getInventoryIssueOrderPrice(issue,buyPrice,bs)
							end
							if isNumBer(orderPrice) then
								order.Price=orderPrice
								sys_insert(orderTable,order)
								num=num+1
							else
								local log = sys_format("篮子:帐号[%s]组合[%s]份数[%s],获取[%s]的盘口价格失败！",baMapID,inventoryID,unit,issue)
								_WriteAplLog(log)
								showLog(sessionID,log)					
							end
						else
							local log = sys_format("篮子:帐号[%s]组合[%s]份数[%s],[%s]的可买数量低于100！",baMapID,inventoryID,unit,issue)
							_WriteAplLog(log)
							showLog(sessionID,log)
						end
					end
				end
			elseif gtInventoryHeaderTable[inventoryID].WeightType=="比例" then
				local neededFund=0
				if gtInventoryHeaderTable[inventoryID].ReserveString=="按固定金额" then
					neededFund=gtInventoryHeaderTable[inventoryID].PerAmount*1
				elseif gtInventoryHeaderTable[inventoryID].ReserveString=="按总资产" then
					if _PosFundStatus[accCode] then
						local assetValue=_PosFundStatus[accCode].AssetValue
						neededFund=assetValue*gtInventoryHeaderTable[inventoryID].PerAmount/100
					end
				elseif gtInventoryHeaderTable[inventoryID].ReserveString=="按可用资金" then
					if _PosFundStatus[accCode] then
						local avlFund=_PosFundStatus[accCode].AvlFund
						neededFund=avlFund*gtInventoryHeaderTable[inventoryID].PerAmount/100
					end
				end
				for issue,v in pairs(gtInventoryComponentTable[inventoryID]) do
					local isSelected = v.IsSelected
					local buyPrice=v.BuyPrice
					local log = sys_format("组合[%s]成分股[%s]是否选中[%s]",inventoryID,issue,isSelected)
					_WriteAplLog(log)
					if isSelected == "1" then
						local orderPrice=""
						if isNumBer(buyPrice) then
							if buyPrice-0.00001>=0 then
								orderPrice=buyPrice
							end
						else
							orderPrice=getInventoryIssueOrderPrice(issue,buyPrice,bs)
						end
						if isNumBer(orderPrice) then
							local contractSize = _PosIssueContractSizeTable[issue]
							local bail = _PosGetBail(accCode, issue, bs, POS_SPECULATE)
							local issueQty =neededFund * v.Ratio / 100 / (orderPrice * bail * contractSize * (1 + gMaxFare))
							issueQty=sys_floor(issueQty/100)*100
							if  issueQty>=100 then
								local order={}
								order.IssueCode=issue
								order.OpenClose=oc
								order.BuySell=bs
								order.BAMapID=baMapID
								order.BASubID=baSubID
								order.Quantity=issueQty
								order.CreRed=creRed
								order.OwnerID=dealerID
								order.Price=orderPrice
								sys_insert(orderTable,order)
								num=num+1
							else
								local log = sys_format("篮子:帐号[%s]组合[%s]份数[%s],[%s]的可买数量低于100！",baMapID,inventoryID,unit,issue)
								_WriteAplLog(log)
								showLog(sessionID,log)
							end
						else
							local log = sys_format("篮子:帐号[%s]组合[%s]份数[%s],获取[%s]的盘口价格失败！",baMapID,inventoryID,unit,issue)
							_WriteAplLog(log)
							showLog(sessionID,log)	
						end
					end
				end
			end
		else
			FreshComponent(sessionID,inventoryID)
			for issue,v in pairs(gtInventoryComponentTable[inventoryID]) do
				local isSelected = v.IsSelected
				local buyPrice=v.BuyPrice
				local log = sys_format("组合[%s]成分股[%s]是否选中[%s]",inventoryID,issue,isSelected)
				_WriteAplLog(log)
				if v.Quantity and isSelected == "1" then
					local issueQty =v.Quantity*unit
					if oc == 1 then
						local posKey = sys_format("%s.%s.%s",baMapID,baSubID,issue)
						if _PosPositionTable[posKey] then
							local avlQty = _PosPositionTable[posKey].AvlQuantity
							local ForbidPosition = 0
							if gtBAMapID2ForbidPositionTable[posKey] then
								ForbidPosition = gtBAMapID2ForbidPositionTable[posKey].ForbidPosition		
							end 
							if issueQty > avlQty - ForbidPosition then
								issueQty = avlQty - ForbidPosition
							end
						end
					end

					if issueQty>0 then
						local qtyTmp = 100*sys_floor(issueQty/100)
						local orderPrice=""
						if isNumBer(buyPrice) then
							if buyPrice-0.00001>=0 then
								orderPrice=buyPrice
							end
						else
							orderPrice=getInventoryIssueOrderPrice(issue,buyPrice,bs)
						end
						if isNumBer(orderPrice) then
							if qtyTmp > 0 then
								local order={}
								order.IssueCode=issue
								order.OpenClose=oc
								order.BuySell=bs
								order.BAMapID=baMapID
								order.BASubID=baSubID
								order.Quantity=qtyTmp
								order.CreRed=creRed
								order.OwnerID=dealerID
								order.Price=orderPrice
								sys_insert(orderTable,order)
								num=num+1
							end
							issueQty = issueQty - qtyTmp
							--再下零股
							if issueQty > 0 then
								local order={}
								order.IssueCode=issue
								order.OpenClose=oc
								order.BuySell=bs
								order.BAMapID=baMapID
								order.BASubID=baSubID
								order.Quantity=issueQty
								order.CreRed=creRed
								order.OwnerID=dealerID
								order.Price=orderPrice
								sys_insert(orderTable,order)
								num=num+1
							end
						else
							local log = sys_format("篮子:帐号[%s]组合[%s]份数[%s],获取[%s]的盘口价格失败！",baMapID,inventoryID,unit,issue)
							_WriteAplLog(log)
							showLog(sessionID,log)
						end
					end
				end
			end
		end
		if num>0 then
			--暂不用篮子，循环单个委托
			--[[
			local ret=PosSubmitBasketOrder(orderTable)						
			if ret.Result then
				local log = sys_format("篮子委托:子帐号[%s]组合[%s]份数[%s],篮子成分股数[%s] 已发送至风控系统等待回应！",baMapID,inventoryID,unit,num)
				_WriteAplLog(log)
				showLog(sessionID,log)
			else
				if ret.Reason then
					local log = sys_format("篮子委托:子帐号[%s]组合[%s]份数[%s],篮子成分股数[%s] 发送至风控系统失败！原因:%s",baMapID,inventoryID,unit,num,ret.Reason)
					_WriteAplLog(log)
					showLog(sessionID,log)
				end
			end
			]]--
			local sucessNum=0
			for i,order in pairs(orderTable) do
				local pcid=newPCID(order.BAMapID)
				setOrderRouteInfo(sessionID,pcid)
				local ret=PosSubmitSingleOrder(order.BAMapID, order.BASubID, order.IssueCode, order.BuySell, order.OpenClose, order.Price, order.Quantity, 0, order.OwnerID, "", nil, "",pcid)
				if ret.Result then
					sucessNum=sucessNum+1
					if price=="" then
						local nowTime=GetHMS()
						local interval=gAutoCancelInterval
						if gtAutoCancelInterval[sessionID] then
							interval=gtAutoCancelInterval[sessionID]
						end
						gtAutoCancelTime[ret.PositionCheckID] = _PosTimeAddInterval(nowTime, "s",interval)
					end
					gtOrderSessionTable[ret.PositionCheckID]=sessionID
				else
					if ret.Reason then
						local log = sys_format("组合买入:理财帐号[%s]组合[%s]份数[%s]成分股[%s] 发送至风控系统失败！原因:%s",baMapID,inventoryID,unit,order.IssueCode,ret.Reason)
						_WriteAplLog(log)
						showLog(sessionID,log)
					end
				end
			end
			if sucessNum==num then
				local log = sys_format("组合买入:理财帐号[%s]组合[%s]份数[%d],篮子成分个股数[%d] 已发送至风控系统等待回应！",baMapID,inventoryID,unit,num)
				_WriteAplLog(log)
				showLog(sessionID,log)
			else 
				local log = sys_format("组合买入:理财帐号[%s]组合[%s]份数[%d],篮子成分个股数[%d],委托成功个股数[%d],失败个股数[%d],已发送至风控系统等待回应！",baMapID,inventoryID,unit,num,sucessNum,num-sucessNum)
				_WriteAplLog(log)
				showLog(sessionID,log)
			end 
		else
			local log = sys_format("下单失败:理财帐号[%s]组合[%s]份数[%d],无可委托成分股",baMapID,inventoryID,unit)
			_WriteAplLog(log)
			showLog(sessionID,log)
		end
	else
		local log = sys_format("下单失败:组合代码[%s]不合法",inventoryID)
		showLog(sessionID,log)
	end

end
_DefineEventObject FreshComponent _AS _Input
	_DefFld("InventoryID", _String, 20)	--代码
_End
_OnEventDefined(FreshComponent evt,sessionID)
	gCurSession=sessionID
	local inventoryID = evt._GetFld("InventoryID");
	gtSessionTable[sessionID].CurrentInventoryID=inventoryID;
	FreshComponent(sessionID,inventoryID)
	sendInventory(sessionID,inventoryID)
	sendComponent(sessionID,inventoryID)
_End

function CheckInventoryNameIsExisted(inventoryName)
	local currentUser = _GetDealerID()
	for key,inventoryInfo in pairs(gtInventoryHeaderTable) do
		if inventoryInfo.InventoryName == inventoryName and inventoryInfo.DeleteFlg == "0" and inventoryInfo.Owner == currentUser then
			return true
		end
	end
	return false
end
function GetInventoryIDByName(inventoryName)
	local currentUser = _GetDealerID()
	for inventoryID,inventoryInfo in pairs(gtInventoryHeaderTable) do
		if inventoryInfo.InventoryName == inventoryName and inventoryInfo.DeleteFlg == "0" and inventoryInfo.Owner == currentUser then
			return inventoryID
		end
	end
	return ""
end

_DefineEventObject AutoNewInventoryAndComponent _AS _Input
	_DefFld("InventoryName", _String, 40);
	_DefFld("WeightType", _String, 20);
	_DefFld("ReserveString", _String, 64);
	_DefFld("PerAmount", _String, 20);
	_DefFld("IsPublic", _String, 1);
	_DefFld("BuySell", _String, 4);
	_DefFld("Text",  _Meta, 4)
	_DefFld("IsWatching", _String, 5);
_End
_OnEventDefined(AutoNewInventoryAndComponent evt,sessionID)
	gCurSession=sessionID
	local InventoryName = evt._GetFld("InventoryName");
	local WeightType = evt._GetFld("WeightType");
	local ReserveString = evt._GetFld("ReserveString");
	local PerAmount = evt._GetFld("PerAmount");
	local IsPublic = evt._GetFld("IsPublic");
	local BuySell = evt._GetFld("BuySell");
	local text = evt._GetFld("Text")
	local isWatching = evt._GetFld("IsWatching")
	local log=sys_format("AutoNewInventoryAndComponent[%s,%s,%s,%s,%s,%s,%s,%s]",InventoryName,WeightType,ReserveString,PerAmount,IsPublic,BuySell,text,isWatching)
	_WriteAplLog(log)

	if CheckInventoryNameIsExisted(InventoryName) == true then
		if isWatching == true then
			local reason=sys_format("(自动读入)组合名称[%s]已被占用，请另外命名",InventoryName);
			_WriteAplLog(reason)
			showLog(sessionID,reason)
			sendOprationLog4Inventory(sessionID,"新建组合","",InventoryName,WeightType,ReserveString,PerAmount,BuySell,"2","失败")
		else
			log=sys_format("(自动读入)组合名称[%s]已读入，跳过",InventoryName);
			_WriteAplLog(log)
		end
	else		
		--保存组合信息
		local ret = NewInventory(InventoryName,WeightType,ReserveString,PerAmount,IsPublic,"2",BuySell,sessionID)
		if ret.Result then
			local inventoryID=ret.InventoryID
			if inventoryID ~= "" then
				--保存组合成分
				local result=SetComponent(sessionID,inventoryID,text,WeightType,true)
				if not result then
					sendOprationLog4Inventory(sessionID,"新建组合",ret.InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,"2","失败")
				else
					if gtSessionTable[sessionID] then
						if gtSessionTable[sessionID].NeedAutoOrder=="True" then
							gInventoryIDNeedAutoOrder[sessionID] = inventoryID
							local log=sys_format("NeedAutoOrder is %s,AutoOrderInventoryID is %s",gtSessionTable[sessionID].NeedAutoOrder,inventoryID)
							_WriteAplLog(log)
						end
					end
					sendOprationLog4Inventory(sessionID,"新建组合",ret.InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,"2","成功")
				end
			end
		else
			local log=sys_format("保存(自动读入)组合名称[%s]失败%s",InventoryName,ret.Reason);
			_WriteAplLog(log)
			sendOprationLog4Inventory(sessionID,"新建组合",ret.InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,"2","失败")
		end
	end
_End

_DefineEventObject AutoComponentSet _AS _Input
	_DefFld("InventoryName", _String, 40);
	_DefFld("Text",  _Meta, 4)
_End
_OnEventDefined(AutoComponentSet evt,sessionID)
	gCurSession=sessionID
	local InventoryName = evt._GetFld("InventoryName");
	local text = evt._GetFld("Text")
	local log=sys_format("AutoComponentSet[%s,%s]",InventoryName,text)
	_WriteAplLog(log)

	local inventoryID = GetInventoryIDByName(InventoryName)
	if inventoryID == "" then
		log=sys_format("(自动读入)组合[%s]不存在,成分设置失败",InventoryName)
		showLog(sessionID,log)
	else
		--保存组合成分
		SetComponent(sessionID,inventoryID,text,"",true)
	end
_End

function NewInventory(inventoryName,weightType,reserveString,perAmount,isPublic,addType,buySell,sessionID)
	local ret={}
	ret.Result=true
	ret.InventoryID=""
	ret.Reason=""
	
	local Owner= _GetDealerID()
	local today = _PosGetYMD()
	local head="ZH"..Owner..today
	local index=1
	local InventoryID=""
	for i=1,1000000000 do
		local newInventoryID=sys_format("%s%03d",head,i)
		if not gtInventoryHeaderTable[newInventoryID] then
			InventoryID=newInventoryID
			break
		end
	end
	if InventoryID=="" then
		ret.Result=false
		ret.Reason="组合号使用已超出上限,请删除不使用的数据"
	else
		ret.InventoryID=InventoryID;
		gtSessionTable[sessionID].CurrentInventoryID=InventoryID;
		local CreateTime=today..GetHMS()
		local TimeStamp=CreateTime

		local _String sql=sys_format("INSERT INTO dtszgrisk.DTSZGInventoryHeaderTable(InventoryID,InventoryName,IsPublic,WeightType,PerAmount,Owner,CreateTime,TimeStamp,DeleteFlg,AddType,BuySell,ReserveString)VALUES('%s','%s','%s','%s',%.2f,'%s','%s','%s','%s','%s','%s','%s')",InventoryID,inventoryName,isPublic,weightType,perAmount,Owner,CreateTime,TimeStamp,"0",addType,buySell,reserveString)
		_WriteAplLog(sql)
		local NewInventory = _UpdateCommonData(type=_Insert,condition="",DTSDynamicSql object=(Data = sql));
		if NewInventory then
			_WriteAplLog("-----------NewInventory success-----------")
		else
			_WriteAplLog("-----------NewInventory failure------------")
		end
			
		gtInventoryHeaderTable[InventoryID]={}
		gtInventoryHeaderTable[InventoryID].InventoryName=inventoryName
		gtInventoryHeaderTable[InventoryID].IsPublic=isPublic
		gtInventoryHeaderTable[InventoryID].WeightType=weightType
		gtInventoryHeaderTable[InventoryID].PerAmount=perAmount
		gtInventoryHeaderTable[InventoryID].Owner=Owner
		gtInventoryHeaderTable[InventoryID].AddType=addType
		gtInventoryHeaderTable[InventoryID].DeleteFlg="0"
		gtInventoryHeaderTable[InventoryID].BuySell=buySell
		gtInventoryHeaderTable[InventoryID].CreateTime = CreateTime
		gtInventoryHeaderTable[InventoryID].ReserveString = reserveString
		gtInventoryHeaderTable[InventoryID].ComponentCount = 0
		if addType~="2" then
			initInventory()
		end
	end
	return ret
end
function SetComponent(sessionID,inventoryID,text,weightTypeIn,isAuto)
	local check=true
	local reason=""
	local autoStr = ""
	if isAuto == true then
		autoStr = "(自动读入)"
	end
	if weightTypeIn == "" then	--有值的情况下不用检查
		if gtInventoryHeaderTable[inventoryID] then
			local Owner=gtInventoryHeaderTable[inventoryID].Owner
			local currentUser= _GetDealerID()
			if Owner~=currentUser then
				check=false
				reason=sys_format("%s组合[%s]属于用户[%s],无权成分设置操作",autoStr,inventoryID,Owner);
				showLog(sessionID,reason)
			end

		else
			check=false
			reason=sys_format("%s组合%s不存在,成分设置失败",autoStr,inventoryID)
			showLog(sessionID,reason)
		end
	end
	local totalRows = 0
	local checkRows = 0
	local weightType=weightTypeIn
	if weightType == "" then
		weightType = gtInventoryHeaderTable[inventoryID].WeightType
	end
	local lines = getLines(text)
	if check then
		local totalRatio=0
		for i, line in ipairs(lines) do
			totalRows=totalRows+1
		end
		for i, line in ipairs(lines) do
			line=innerTrimAll(line," ");
			line=innerTrimAll(line,"\r");
			line=innerTrimAll(line,"\n");
			local rtn = getNameAndValue(line);
			local issueCode = rtn[1];
			local quantity = rtn[2];
			local buyPrice = rtn[3] or "";
			local rowCheck=false
			if issueCode and quantity then
				local marketCode = _PosIssueMarketTable[issueCode]
				if (marketCode=="1" or marketCode=="2")  and isNumBer(quantity) then
					if weightType =="数量" then
						local qty = quantity.toInt();
						if (qty > 0) then
							rowCheck=true
						end
					elseif weightType =="比例" then
						local _Double dQty = quantity.getNumberValue();
						if dQty>0  then
							rowCheck=true
							totalRatio=totalRatio+quantity
						end
					end
				end
			end
			if rowCheck then
				checkRows=checkRows+1
			else
				local log=sys_format("%s组合%s成分设置行%s数据[%s]有误",autoStr,inventoryID,i,line)
				sendLog(sessionID,log)
			end
		end
		if checkRows== totalRows then
			if weightType =="比例" then
				if totalRatio>100.5 then
					check=false
					local log=sys_format("%s组合%s成分设置总比例%.0f%%，大于100%%",autoStr,inventoryID,totalRatio)
					showLog(sessionID,log)
				end
			end
		else
			check=false
			local log=sys_format("%s组合%s成分设置失败:设置行数[%s]检查通过行[%s]",autoStr,inventoryID,totalRows,checkRows)
			showLog(sessionID,log)
		end
		if check then
			local today = _PosGetYMD()
			local nowTime=today..GetHMS()
			local sql = sys_format("Delete From dtszgrisk.DTSZGInventoryComponentTable Where InventoryID='%s'",inventoryID)
			_WriteAplLog(sql)
			local DeleteComponent = _UpdateCommonData(type=_Delete,condition=sql,DTSDynamicSql object);
			if DeleteComponent then
				_WriteAplLog("-----------DeleteComponent success-----------")
			else
				_WriteAplLog("-----------DeleteComponent failure------------")
			end

			for i, line in ipairs(lines) do
				line=innerTrimAll(line," ");
				line=innerTrimAll(line,"\r");
				line=innerTrimAll(line,"\n");
				local rtn = getNameAndValue(line);
				local issueCode = rtn[1];
				local quantity=0
				local ratio=0
				local buyPrice = rtn[3] or "";
				if not isNumBer(buyPrice) then
					if buyPrice~="涨停" and buyPrice~="卖5" and buyPrice~="卖4" and buyPrice~="卖3" and buyPrice~="卖2" and buyPrice~="卖1" and buyPrice~="买1" and buyPrice~="买2" and buyPrice~="买3" and buyPrice~="买4" and buyPrice~="买5" and buyPrice~="跌停" then
						buyPrice=""
					end
				end 
				if weightType =="数量" then
					quantity = rtn[2];
					quantity = quantity.toInt();
				elseif weightType =="比例" then
					ratio = rtn[2];
					ratio = ratio.getNumberValue();
				end

				local _String sqll = sys_format("INSERT INTO dtszgrisk.DTSZGInventoryComponentTable(InventoryID,IssueCode,Quantity,Ratio,BuyPrice,CreateTime,TimeStamp)VALUES('%s','%s',%d,%.2f,'%s','%s','%s')",inventoryID,issueCode,quantity,ratio,buyPrice,nowTime,nowTime)
				_WriteAplLog(sqll)
				local ComponentSet = _UpdateCommonData(type=_Insert,condition="",DTSDynamicSql object=(Data = sqll));
				if ComponentSet then
					_WriteAplLog("-----------ComponentSet success-----------")
				else
					_WriteAplLog("-----------ComponentSet failure------------")
				end
				
				if not gtPriceTable[issueCode] then
					local marketCode = _PosIssueMarketTable[issueCode]
					_RegisterPrice(_IssueCode = issueCode, _MarketCode = marketCode)
				end
			end

		end
	end
	initInventory()
	return check
end

_DefineEventObject InventoryList _AS _Input
	_DefFld("BuySell",_String,4)
_End

_DefineEventObject InvestoryListOut _AS _Output
	_DefFld("InventoryID",_String,20)
	_DefFld("InventoryName", _String, 40);
	_DefFld("Owner", _String, 10);
	_DefFld("BuySell", _String, 4);
	_DefFld("WeightType", _String, 10)

	_DefKeyField("InventoryID")
	_SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End
_OnEventDefined(InventoryList evt,sessionID)
	gCurSession=sessionID
	local buySell = evt._GetFld("BuySell");
	local log=sys_format("InventoryList,BuySell[%s]",buySell)
	_WriteAplLog(log)
	
	local sortInventoryID={}
	for inventoryID,v in pairs(gtInventoryHeaderTable) do
		local key=v.CreateTime.."#"..inventoryID
		sys_insert(sortInventoryID,key)
	end
	sys_sort(sortInventoryID, "desc")
	for i,key in pairs(sortInventoryID) do
		local inventoryID=getTableByString(key,"#")[2]
		if gtInventoryHeaderTable[inventoryID] then
			inventoryInfo=gtInventoryHeaderTable[inventoryID]
			if inventoryInfo.DeleteFlg == "0" then
				local inventoryName = inventoryInfo.InventoryName
				local owner = inventoryInfo.Owner
				local lBuySell = inventoryInfo.BuySell
				local weightType = inventoryInfo.WeightType
				if (buySell=="" or (buySell~="" and buySell == lBuySell)) then
					local DTSEvent evt = _CreateEventObject("InvestoryListOut");
					evt._SetFld("InventoryID", inventoryID);
					evt._SetFld("InventoryName", inventoryName);
					evt._SetFld("Owner", owner);
					evt._SetFld("BuySell", lBuySell);
					evt._SetFld("WeightType", weightType);
					_SendEventToClient(evt,sessionID);
				end
			end
		end
	end
_End

_DefineEventObject ChangeComponentSelectedStatus _AS _Input
	_DefFld("InventoryID",_String,20)
	_DefFld("IssueCode", _String, 20)
	_DefFld("IsSelected", _String, 1)
_End

_OnEventDefined(ChangeComponentSelectedStatus evt,sessionID)
	gCurSession=sessionID
	local InventoryID = evt._GetFld("InventoryID");
	local IssueCode = evt._GetFld("IssueCode")
	local IsSelected = evt._GetFld("IsSelected")
	local log=sys_format("ChangeComponentSelectedStatus[%s,%s,%s]",InventoryID,IssueCode,IsSelected)
	_WriteAplLog(log)
	
	if gtInventoryComponentTable[InventoryID] and gtInventoryComponentTable[InventoryID][IssueCode] then
		local _String updateSql = sys_format("Update dtszgrisk.DTSZGInventoryComponentTable Set IsSelected='%s' where InventoryID='%s' and IssueCode='%s'",IsSelected,InventoryID,IssueCode)
		_WriteAplLog(updateSql)
		--local ChangeComponent = _UpdateCommonData(type=_Modify,condition="",DTSDynamicSql object=(Data = updateSql));
		local ChangeComponent = _UpdateCommonData(type=_Insert,condition="",DTSDynamicSql object=(Data = updateSql));
		if ChangeComponent then
			_WriteAplLog("-----------ChangeComponent success-----------")
		else
			_WriteAplLog("-----------ChangeComponent failure------------")
		end
		
		gtInventoryComponentTable[InventoryID][IssueCode].IsSelected = IsSelected
		FreshComponent(sessionID,InventoryID)
		sendInventory(sessionID,InventoryID)
		sendComponent(sessionID,InventoryID)
	end
_End

_DefineEventObject SetAutoCancelInterval _AS _Input
	_DefFld("Interval", _String, 7)	--代码
_End
_OnEventDefined(SetAutoCancelInterval evt,sessionID)
	gCurSession=sessionID
	local interval = evt._GetFld("Interval");
	gtAutoCancelInterval[sessionID]=interval
_End

_OnEventTimer(_TimerName="AutoCancelTimer")
		local nowHMS=GetHMS()
		for pcid,cancelTime in pairs(gtAutoCancelTime) do
			if nowHMS >= cancelTime then
				for corpCode, value in pairs(gtShowOrderTable) do
					if value.PositionCheckID == pcid and value.WorkingQuantity > 0 then
						local log = sys_format("AutoCancel: corpCode=%s", corpCode)
						_WriteAplLog(log)
						local ret = PosCancelOrder(corpCode)--撤单
						if ret.Result then
							gtAutoCancelTime[pcid]=nil
						else
							if ret.Reason then
								local log = sys_format("内部委托号[%s]撤单委托发送至风控系统失败!;原因:%s",corpCode,ret.Reason)
								_WriteAplLog(log)
								showLog("All",log)
							end
						end
					end
				end
			end
		end 
_End

_DefineEventObject InventoryComponentQtyBalanceInfo _AS _Output
	_DefFld("IssueCode",_String,20)
	_DefFld("IssueName", _String, 40);
	_DefFld("BuySell", _String, 4);
	_DefFld("Quantity", _Number, 20);
	_DefFld("ExcutedQuantity", _Number, 20);
	_DefFld("QuantityBalance", _Number, 20);

	_DefKeyField("IssueCode")
	_DefKeyField("BuySell")
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

function sendQuantityBalance(sessionID)
	local DTSEvent evt = _CreateEventObject("InventoryComponentQtyBalanceInfo");
	evt._SetFld("IssueCode", "clearData");
	_SendEventToClient(evt,sessionID);
	
	local quantityBalanceTable = {}
	local DTSDate today = _GetNowDate()
	local strToday = sys_format("%s-%02d-%02d",today.year(),today.month(),today.day())
	for inventoryID, component in pairs(gtInventoryComponentTable) do
		if gtInventoryHeaderTable[inventoryID].DeleteFlg=="0" then
			local date = sys_sub(gtInventoryHeaderTable[inventoryID].CreateTime.toString(),1,10)
			if date == strToday then	----只统计今天的组合内容
				for issueCode,v in pairs(component) do
					if not quantityBalanceTable[issueCode] then
						quantityBalanceTable[issueCode] = {}
					end
					local bs = "3"
					if gtInventoryHeaderTable[inventoryID].BuySell == "卖" then
						bs = "1"
					end
					if not quantityBalanceTable[issueCode][bs] then
						quantityBalanceTable[issueCode][bs] = {}
						quantityBalanceTable[issueCode][bs].Quantity = 0
						quantityBalanceTable[issueCode][bs].ExcutedQuantity = 0
						quantityBalanceTable[issueCode][bs].QuantityBalance = 0
					end
					local quantity = v.Quantity
					quantity=sys_floor(quantity)
					quantityBalanceTable[issueCode][bs].Quantity = quantityBalanceTable[issueCode][bs].Quantity + quantity
				end
			end
		end
	end
	
	for corpCode,value in pairs(gtShowExecTable) do
		if value.IsInternal~=1 then  --内部成交除外
			if gtSessionTable[sessionID] then
				if gtSessionTable[sessionID].CurBAMapIDTable then
					if gtSessionTable[sessionID].CurBAMapIDTable[value.BAMapID] and quantityBalanceTable[value.IssueCode] then
						if quantityBalanceTable[value.IssueCode][value.BuySell] then
							local execQty = quantityBalanceTable[value.IssueCode][value.BuySell].ExcutedQuantity + value.ExecQty
							quantityBalanceTable[value.IssueCode][value.BuySell].ExcutedQuantity = execQty
						end
					end
				end
			end
		end
	end
	
	for code,bsTable in pairs(quantityBalanceTable) do
		local innerCount = sys_getSize(bsTable)
		for bs, diff in pairs(bsTable) do
			local issueName = _PosIssueNameTable[code] or ""
			local quantity = diff.Quantity
			local executedQty = diff.ExcutedQuantity
			diff.QuantityBalance=quantity-executedQty
			local balance = diff.QuantityBalance
			evt._SetFld("IssueCode", code);
			evt._SetFld("IssueName", issueName);
			if bs == "3" then
				evt._SetFld("BuySell", "买");
			else
				evt._SetFld("BuySell", "卖");
			end
			evt._SetFld("Quantity", quantity);
			evt._SetFld("ExcutedQuantity", executedQty);
			evt._SetFld("QuantityBalance", balance);
			_SendEventToClient(evt,sessionID);
		end
	end
end

_DefineEventObject CurrentInventoryID _AS _Output
	_DefFld("InventoryID",_String,20)

	_SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End

function SendCurrentInventoryID(sessionID)
	if gtSessionTable[sessionID] then
		if gtSessionTable[sessionID].CurrentInventoryID~="" then
			local inventoryID=gtSessionTable[sessionID].CurrentInventoryID
			local DTSEvent evt = _CreateEventObject("CurrentInventoryID");
			evt._SetFld("InventoryID", inventoryID);
			_SendEventToClient(evt,sessionID);
		end
	end
end

function GetLogsShowMode()
	gLogsShowMode = ""
	gLogsShowModeCurUser=""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'LogsShowMode%s' or VariableName='LogsShowMode'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetLogsShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end

_OnCommonData(dataName = "GetLogsShowMode", DTSGlobalVariable evt)
	_WriteAplLog("GetLogsShowMode")
	local currentUserID = _GetDealerID()
	local variableName = evt.getVariableName()
	if sys_find(variableName,currentUserID,1)~=nil then
		gLogsShowModeCurUser = evt.getVariableValue()
	else
		gLogsShowMode = evt.getVariableValue()
	end
	local log = sys_format("LogsShowMode : %s ,CurUser : %s" ,gLogsShowMode,gLogsShowModeCurUser)
	_WriteAplLog(log)
_End

function GetShowCostOfExcution()
	gShowCostOfExcution = ""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'ShowCostOfExcution%s'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetShowCostOfExcution", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	if gShowCostOfExcution=="" then
		GlobalVariableTableSql = "VariableName = 'ShowCostOfExcution'"
		_WriteAplLog(GlobalVariableTableSql)
		_GetCommonData(dataName = "GetShowCostOfExcution", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
	end
	
end

_OnCommonData(dataName = "GetShowCostOfExcution", DTSGlobalVariable evt)
	_WriteAplLog("GetShowCostOfExcution")
	local variableName = evt.getVariableName()
	gShowCostOfExcution = evt.getVariableValue()
	local log = sys_format("GetShowCostOfExcution : %s" ,gShowCostOfExcution)
	_WriteAplLog(log)
	
	local DTSEvent evt = _CreateEventObject("ReloadGlobalVariableTable");
	evt._SetFld("VariableName", variableName);
	evt._SetFld("VariableValue", gShowCostOfExcution);
	_SendToClients(evt)
_End

_DefineEventObject AutoOrderSetting _AS _Input
	_DefFld("NeedAutoOrder", _String, 7)
_End

_OnEventDefined(AutoOrderSetting evt,sessionID)
	gCurSession=sessionID
	local needAutoOrder = evt._GetFld("NeedAutoOrder");
	local log = sys_format("NeedAutoOrder : %s" ,needAutoOrder)
	_WriteAplLog(log)
	gtSessionTable[sessionID]=gtSessionTable[sessionID] or {}
	gtSessionTable[sessionID].NeedAutoOrder=needAutoOrder
_End

_DefineEventObject InventoryInitializedOut _AS _Output
	_DefFld("Param",_String,1)

	_SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End

function SendInventoryInitialized(sessionID)
	local log = sys_format("SendInventoryInitialized,sessionID is %s" ,sessionID)
	_WriteAplLog(log)
	if gtSessionTable[sessionID] then
		local DTSEvent evt = _CreateEventObject("InventoryInitializedOut");
		evt._SetFld("Param", "1");
		_SendEventToClient(evt,sessionID);
	end
end

function sendOprationLog4Inventory(sessionID,opType,InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,AddType,Status)
	if WeightType~="比例" then
		PerAmount="-"
	else
		if ReserveString=="按总资产" or ReserveString=="按可用资金" then
			PerAmount=PerAmount.toString().."%"
		end
	end
	if AddType=="2" then
		AddType=",方式:自动"
	elseif AddType=="1" then
		AddType=",方式:手工"
	end
	local msg=sys_format("【组合维护】操作:%s,组合代码【%s】,组合名称【%s】,类型:%s(%s%s),买卖方向:%s%s,状态[操作%s]",opType,InventoryID,InventoryName,WeightType,ReserveString,PerAmount,BuySell,AddType,Status)
	sendOprationLog(sessionID,msg)
end

_DefineEventObject ReloadGlobalVariableTable _AS _Output
	_DefFld("VariableName",_String, 64)
	_DefFld("VariableValue",_String, 128)

	_SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End


------------------------------------------------------
--启动风控提示框 勾选DD
_DefineEventObject checkDD2Risk _AS _Input     
    _DefFld("CHK",_String,20)    
    _DefFld("UserID",_String,20)    
_End

--发送启动风控提示框 勾选DD
_DefineEventObject checkDD2RiskOut _AS _Output     
    _DefFld("CHK",_String,20)    
_End


_DefineEventObject CheckShowPrompt _AS _Input
	_DefFld("CHK", _String, 64)
	_DefFld("UserID", _String, 64)

	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

_DefineEventObject QueryRiskAlarmsCond _AS _Input
	_DefFld("NodeText", _String, 64)
	_DefFld("StartDate", _String, 64)
	_DefFld("EndDate", _String, 64)
	_DefFld("UserID", _String, 64)
	_DefFld("BAMapID", _String, 64)

	_SetBufferedFlag(0)
	_SetDataType(_EventOtherType)
_End

_DefineEventObject TodayRiskAlarmsOut _AS _Output
	_DefFld("AlarmsIndex",_String,20);
	_DefFld("AlarmsTime",_String,20);
	_DefFld("RiskSetCode",_String,20);
	_DefFld("IndexCode",_String,20);
	_DefFld("IndexName",_String,60);
	_DefFld("AlarmsType", _String, 20);
	_DefFld("ConObj",_String ,20);
	_DefFld("ClientMessageInfo", _Meta, 4)

	_DefKeyField("AlarmsIndex");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

_DefineEventObject HistoryRiskAlarmsOut _AS _Output
	_DefFld("AlarmsIndex",_String,20);
	_DefFld("AlarmsTime",_String,20);
	_DefFld("RiskSetCode",_String,20);
	_DefFld("IndexCode",_String,20);
	_DefFld("IndexName",_String,60);
	_DefFld("AlarmsType", _String, 20);
	_DefFld("ConObj",_String ,20);
	_DefFld("ClientMessageInfo", _Meta, 4)

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

_DefineEventObject LogDialog _AS _Output
	_DefFld("MessageType", _String,20);
	_DefFld("LogMessage", _Meta, 4);
	_SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End

_DefineEventObject SendProductName _AS _Output 
	_DefFld("ProductName", _Meta, 4);
	_DefFld("ProductName_old", _Meta, 4);

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

_OnEventDefined(CheckShowPrompt evt,sessionID)
    local logs;
    local chk = evt._GetFld("CHK");
    local userID = evt._GetFld("UserID");
    logs = sys_format("是否提示风控触警提示框: UserID[%s],CHK[%s]",chk,userID)
    _WriteAplLog(logs)
    gtChecked[userID] = chk
    
    --保存风控提示框DD
    SaveCheckDD2Risk(chk,userID)

_End

_OnEventDefined(QueryRiskAlarmsCond evt,sessionID)
    gCurSession=sessionID
	local NodeText = evt._GetFld("NodeText");
	local StartDate = evt._GetFld("StartDate");
	local EndDate = evt._GetFld("EndDate");
	local UserID = evt._GetFld("UserID");
	local BAMapID = evt._GetFld("BAMapID");
	
	local userID_tmp = _GetDealerID()
	_WriteAplLog(userID_tmp)
	
	local baMapIDTbale2Cond = {}
	if UserID == "全部" then
		if BAMapID == "全部" then
			if userID_tmp == gLeaderUserID then -- 风控员
				for userID,v in pairs(gtltData) do
					for bamapID,v1 in pairs(v.BAMapTable) do
						baMapIDTbale2Cond[bamapID] = 1
					end
				end
			else
				for bamapID,v1 in pairs(gtltData["self"].BAMapTable) do
                    baMapIDTbale2Cond[bamapID] = 1
                end
			end
		else
			baMapIDTbale2Cond[BAMapID] = 1
		end
	else
		if BAMapID == "全部" then
			for bamapID,v1 in pairs(gtltData[UserID].BAMapTable) do
				baMapIDTbale2Cond[bamapID] = 1
			end
		else
			baMapIDTbale2Cond[BAMapID] = 1
		end
		
	end
	
	local cond = ""
	for bamap,v in pairs(baMapIDTbale2Cond) do
		if cond == "" then
			cond = bamap
		else
			cond = cond .. "|" .. bamap
		end
	end
	
	local sql = ""
	if  NodeText=="当日触警" then
		local DTSEvent evt = _CreateEventObject("TodayRiskAlarmsOut")
		evt._SetFld("AlarmsIndex","clearData")
		_SendEventToClient(evt,sessionID);
		
		sql=sys_format("SELECT DTSZGRiskAlarmsTable.ProductID,DTSZGRiskAlarmsTable.AlarmsIndex,DTSZGRiskAlarmsTable.AlarmsTime,DTSZGRiskAlarmsTable.AlarmsType,DTSZGRiskAlarmsTable.ClientMessageInfo,DTSZGRiskAlarmsTable.RiskSetCode,DTSZGRiskMainTable.ControlLevel,DTSZGRiskMainTable.ControlEntity,DTSZGRiskMainTable.IndexCode,DTSZGRiskIndexTable.IndexName   FROM dtszgrisk.DTSZGRiskAlarmsTable Left Join dtszgrisk.DTSZGRiskMainTable on DTSZGRiskAlarmsTable.RiskSetCode=DTSZGRiskMainTable.RiskSetCode Left Join dtszgrisk.DTSZGRiskIndexTable on DTSZGRiskMainTable.IndexCode=DTSZGRiskIndexTable.IndexCode where DTSZGRiskAlarmsTable.CreateUser REGEXP '%s' order by DTSZGRiskAlarmsTable.AlarmsTime desc",cond);
		_GetCommonData(dataName="DTSZGRiskAlarmsTable", condition=sql, tablename="DynamicSql")
	elseif NodeText=="历史触警" then
		
		local DTSEvent evt = _CreateEventObject("HistoryRiskAlarmsOut")
		evt._SetFld("AlarmsIndex","clearData")
		_SendEventToClient(evt,sessionID);

		local startDateTime=StartDate.."000000"
		local endDateTime=EndDate.."235959"
		local condTime = sys_format(" AlarmsTime>='%s' and AlarmsTime<='%s' order by AlarmsTime desc",startDateTime,endDateTime)

		sql=sys_format("SELECT DTSZGHistoryAlarmsTable.ProductID,DTSZGHistoryAlarmsTable.AlarmsIndex,DTSZGHistoryAlarmsTable.AlarmsTime,DTSZGHistoryAlarmsTable.AlarmsType,DTSZGHistoryAlarmsTable.ClientMessageInfo,DTSZGHistoryAlarmsTable.RiskSetCode,DTSZGRiskMainTable.ControlLevel,DTSZGRiskMainTable.ControlEntity,DTSZGHistoryAlarmsTable.IndexCode,DTSZGRiskIndexTable.IndexName   FROM dtszgrisk.DTSZGHistoryAlarmsTable Left Join dtszgrisk.DTSZGRiskMainTable on DTSZGHistoryAlarmsTable.RiskSetCode=DTSZGRiskMainTable.RiskSetCode Left Join dtszgrisk.DTSZGRiskIndexTable on DTSZGHistoryAlarmsTable.IndexCode=DTSZGRiskIndexTable.IndexCode where DTSZGHistoryAlarmsTable.CreateUser REGEXP '%s' and %s",cond,condTime);
		_GetCommonData(dataName="DTSZGHistoryAlarmsTable", condition=sql, tablename="DynamicSql")
	end
	_WriteAplLog(sql)
	--[[
    local ProductID_cond = ""
    if UserID == "全部" then
        if BAMapID == "全部" then
            ProductID_cond = "ALL"
        else
            for userID,v in pairs(gtltData) do
                for bamapID,v1 in pairs(v.BAMapTable) do
                    if bamapID == BAMapID then
                        local ProductID = gtZGProductAccountTable[bamapID].ProductID
                        ProductID_cond = sys_format("'%s'",ProductID)
                    end
                end
            end
            
        end
    else
        if BAMapID == "全部" then
            for bamapID,v in pairs(gtltData[UserID].BAMapTable) do
                local ProductID = gtZGProductAccountTable[bamapID].ProductID
                if ProductID_cond == "" then
                    ProductID_cond = sys_format("'%s'",ProductID)
                else
                    ProductID_cond = sys_format("%s,'%s'",ProductID_cond,ProductID)
                end
            end
        else
            for bamapID,v in pairs(gtltData[UserID].BAMapTable) do
                if bamapID == BAMapID then 
                    local ProductID = gtZGProductAccountTable[bamapID].ProductID
                    ProductID_cond = sys_format("'%s'",ProductID)
                end
            end
        end
    end
    
    _WriteAplLog(ProductID_cond)
    
    if ProductID_cond ~= "" then
        local sql=""
        if  NodeText=="当日触警" then
            local DTSEvent evt = _CreateEventObject("TodayRiskAlarmsOut")
            evt._SetFld("AlarmsIndex","clearData")
            _SendEventToClient(evt,sessionID);

            if ProductID_cond ~= "ALL" then
                sql=sys_format("SELECT DTSZGRiskAlarmsTable.ProductID,DTSZGRiskAlarmsTable.AlarmsIndex,DTSZGRiskAlarmsTable.AlarmsTime,DTSZGRiskAlarmsTable.AlarmsType,DTSZGRiskAlarmsTable.ClientMessageInfo,DTSZGRiskAlarmsTable.RiskSetCode,DTSZGRiskMainTable.ControlLevel,DTSZGRiskMainTable.ControlEntity,DTSZGRiskMainTable.IndexCode,DTSZGRiskIndexTable.IndexName   FROM dtszgrisk.DTSZGRiskAlarmsTable Left Join dtszgrisk.DTSZGRiskMainTable on DTSZGRiskAlarmsTable.RiskSetCode=DTSZGRiskMainTable.RiskSetCode Left Join dtszgrisk.DTSZGRiskIndexTable on DTSZGRiskMainTable.IndexCode=DTSZGRiskIndexTable.IndexCode where DTSZGRiskAlarmsTable.ProductID in(%s) order by DTSZGRiskAlarmsTable.AlarmsTime desc",ProductID_cond);
            else
                sql="SELECT DTSZGRiskAlarmsTable.ProductID,DTSZGRiskAlarmsTable.AlarmsIndex,DTSZGRiskAlarmsTable.AlarmsTime,DTSZGRiskAlarmsTable.AlarmsType,DTSZGRiskAlarmsTable.ClientMessageInfo,DTSZGRiskAlarmsTable.RiskSetCode,DTSZGRiskMainTable.ControlLevel,DTSZGRiskMainTable.ControlEntity,DTSZGRiskMainTable.IndexCode,DTSZGRiskIndexTable.IndexName   FROM dtszgrisk.DTSZGRiskAlarmsTable Left Join dtszgrisk.DTSZGRiskMainTable on DTSZGRiskAlarmsTable.RiskSetCode=DTSZGRiskMainTable.RiskSetCode Left Join dtszgrisk.DTSZGRiskIndexTable on DTSZGRiskMainTable.IndexCode=DTSZGRiskIndexTable.IndexCode order by DTSZGRiskAlarmsTable.AlarmsTime desc";
            end

            --sql=sys_format("ProductID in(gProductID) order by AlarmsTime desc"
            _WriteAplLog(sql)
            _GetCommonData(dataName="DTSZGRiskAlarmsTable", condition=sql, tablename="DynamicSql")
            
        elseif  NodeText=="历史触警" then
            local DTSEvent evt = _CreateEventObject("HistoryRiskAlarmsOut")
            evt._SetFld("AlarmsIndex","clearData")
            _SendEventToClient(evt,sessionID);
            
            local cond = ""
            local startDateTime=StartDate.."000000"
            local endDateTime=EndDate.."235959"
            if ProductID_cond ~= "ALL" then
                cond = sys_format("DTSZGHistoryAlarmsTable.ProductID in(%s) and AlarmsTime>='%s' and AlarmsTime<='%s' ",ProductID_cond,startDateTime,endDateTime)
            else
                cond = sys_format(" AlarmsTime>='%s' and AlarmsTime<='%s' order by AlarmsTime desc",startDateTime,endDateTime)
            end
            sql=sys_format("SELECT DTSZGHistoryAlarmsTable.ProductID,DTSZGHistoryAlarmsTable.AlarmsIndex,DTSZGHistoryAlarmsTable.AlarmsTime,DTSZGHistoryAlarmsTable.AlarmsType,DTSZGHistoryAlarmsTable.ClientMessageInfo,DTSZGHistoryAlarmsTable.RiskSetCode,DTSZGRiskMainTable.ControlLevel,DTSZGRiskMainTable.ControlEntity,DTSZGHistoryAlarmsTable.IndexCode,DTSZGRiskIndexTable.IndexName   FROM dtszgrisk.DTSZGHistoryAlarmsTable Left Join dtszgrisk.DTSZGRiskMainTable on DTSZGHistoryAlarmsTable.RiskSetCode=DTSZGRiskMainTable.RiskSetCode Left Join dtszgrisk.DTSZGRiskIndexTable on DTSZGHistoryAlarmsTable.IndexCode=DTSZGRiskIndexTable.IndexCode where %s order by AlarmsTime desc",cond);
            _WriteAplLog(sql)
            _GetCommonData(dataName="DTSZGHistoryAlarmsTable", condition=sql, tablename="DynamicSql")
        end
    else
        if  NodeText=="当日触警" then
            local DTSEvent evt = _CreateEventObject("TodayRiskAlarmsOut")
            evt._SetFld("AlarmsIndex","clearData")
            _SendEventToClient(evt,sessionID);
        elseif NodeText=="历史触警" then
            local DTSEvent evt = _CreateEventObject("HistoryRiskAlarmsOut")
            evt._SetFld("AlarmsIndex","clearData")
            _SendEventToClient(evt,sessionID);
        end
    end]]
_End

_OnCommonData(dataName = "GetGroupData", DTSGroup evt)
    _WriteAplLog("_OnCommonData GetGroupData")
	local GroupID = evt.getGroupID()
	local LeaderUserID = evt.getLeaderUserID()
    gtGroupID2LeaderUserID[GroupID] = LeaderUserID
    gtLeaderUserID[LeaderUserID] = 1

	local log = gGroupID sys_format("GetGroupData GroupID[%s],LeaderUserID[%s]" ,GroupID,LeaderUserID)
	_WriteAplLog(log)
_End

_OnCommonData(dataName = "GetGroupUserData", DTSGroupUser evt)
    _WriteAplLog("_OnCommonData GetGroupUserData")
	local UserID = evt.getUserID()
	local GroupID = evt.getGroupID()
    
    gtUserID2GroupID[UserID] = GroupID
	local log = gGroupID sys_format("GetGroupUserData UserID[%s],GroupID[%s]" ,UserID,GroupID)
	_WriteAplLog(log)
_End

_OnCommonData(dataName = "DTSZGProductAccountBackupTable", DTSDynamicSql dynamicSql)
    _WriteAplLog("_OnCommonData DTSZGProductAccountBackupTable")
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		if luat["ProductID"] and luat["AssetsCellID"] and luat["BAMapID"] then  
			local ProductID=luat["ProductID"]
			local AssetsCellID=luat["AssetsCellID"]
			local BAMapID=luat["BAMapID"]
			if gtRunAccountTable[BAMapID] then
				gtZGProductAccountBackUpTable[BAMapID]={}	
				gtZGProductAccountBackUpTable[BAMapID]=luat
			end
		end
	end
_End

_OnCommonData(dataName="DTSZGAssetsCellTable", DTSDynamicSql dynamicSql)
	_WriteAplLog("on DTSZGAssetsCellTable")
    local logs;
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then
		if luat["ProductID"] and luat["AssetsCellID"] then
			local ProductID=luat["ProductID"]
			local AssetsCellID=luat["AssetsCellID"]
            local AssetsCellName = luat["AssetsCellName"]
			gtProductAssetsCellTable[ProductID] = gtProductAssetsCellTable[ProductID] or {}
			gtProductAssetsCellTable[ProductID][AssetsCellID]=AssetsCellName
            
            logs = sys_format("ProductID[%s],AssetsCellID[%s],AssetsCellName[%s]",ProductID,AssetsCellID,AssetsCellName)
            _WriteAplLog(logs)
		end
	end
_End

_OnCommonData(dataName="DTSZGProductTable", DTSDynamicSql dynamicSql)
	_WriteAplLog("on DTSZGProductTable")
    local logs;
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then
		if luat["ProductID"] and luat["ProductShortName"] then
			local ProductID=luat["ProductID"]
			local ProductShortName=luat["ProductShortName"]
            gtZGProductTable[ProductID] = {}
            gtZGProductTable[ProductID]=luat
            gtProduct2NameTable[ProductID] = ProductShortName
            logs = sys_format("ProductID[%s],ProductShortName[%s]",ProductID,ProductShortName)
            _WriteAplLog(logs)
		end
	end
    
_End

_OnCommonData(dataName="DTSZGRiskAlarmsTable", DTSDynamicSql dynamicSql)
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then
		--[[
		local sendFlag=false
		local ControlLevel=luat.ControlLevel or "-"
		local ControlEntity=luat.ControlEntity or "-"
		if ControlLevel==1 or  ControlLevel==2 or  ControlLevel==3 then
			local productID=luat.ProductID or "-"
			if gtProductTable[productID] then
				sendFlag=true
			end
		elseif  ControlLevel==5 then
			local investorID=ControlEntity
			for clientID,v in pairs(gtClientTable) do
				if v.InvestorID== investorID then
                    local CurrentUserID = _GetDealerID()
					if gLeaderUserID==CurrentUserID then
						sendFlag=true
						break
					end 
				end
			end
			
		elseif  ControlLevel==6 then
			local userID=	ControlEntity
			local currentUser = _GetDealerID()
			if currentUser==userID then
				sendFlag=true
			else
				if gtPosUserAccessUserTable then
					if gtPosUserAccessUserTable[currentUser] then
						if gtPosUserAccessUserTable[currentUser][userID] then
                            sendFlag=true
                            
							--if gtUserBAMapTable then 
								--if gtUserBAMapTable[userID] then 
									--if gtUserBAMapTable[userID].NumBAMapID>0 then
										--sendFlag=true
									--end
								--end 
							--end
						end
					end
				end
			end	
		end
		]]
		--if sendFlag then
			local DTSEvent evt = _CreateEventObject("TodayRiskAlarmsOut")
			local AlarmsIndex=luat.AlarmsIndex or "-"
			evt._SetFld("AlarmsIndex",AlarmsIndex)
			local AlarmsTime=luat.AlarmsTime or "-"
			evt._SetFld("AlarmsTime",AlarmsTime)
			local AlarmsType=luat.AlarmsType or "-"
			if AlarmsType == "0" then
				AlarmsType = "事前"
			elseif AlarmsType == "1" then
				AlarmsType = "事中"
			elseif AlarmsType == "2" then
				AlarmsType = "事后"
			end
			evt._SetFld("AlarmsType",AlarmsType)
			local RiskSetCode=luat.RiskSetCode or "-"
			evt._SetFld("RiskSetCode",RiskSetCode)
			local IndexCode=luat.IndexCode or "-"
			evt._SetFld("IndexCode",IndexCode)
			local IndexName=luat.IndexName or "-"
			evt._SetFld("IndexName",IndexName)
			local ControlLevel=luat.ControlLevel or "-"
			local ControlEntity=luat.ControlEntity or "-"
			local ConObj=ControlEntity

			evt._SetFld("ConObj",ConObj)
			local ClientMessageInfo=luat.ClientMessageInfo or "-"
			evt._SetFld("ClientMessageInfo",ClientMessageInfo)
			_SendEventToClient(evt,gCurSession);
		--end
	end
_End

_OnCommonData(dataName="DTSZGHistoryAlarmsTable", DTSDynamicSql dynamicSql)
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then
		
		--local sendFlag=false
		local DTSEvent evt = _CreateEventObject("HistoryRiskAlarmsOut")
		--[[
		local ControlLevel=luat.ControlLevel or "-"
		local ControlEntity=luat.ControlEntity or "-"
		if ControlLevel==1 or  ControlLevel==2 or  ControlLevel==3 then
			local productID=luat.ProductID or "-"
			if gtOldProductTable[productID] then
				sendFlag=true
			end
		elseif  ControlLevel==5 then
			local investorID=ControlEntity
			for clientID,v in pairs(gtClientTable) do
				if v.InvestorID== investorID then
					if gLeaderUserID==gCurrentUserID then
						sendFlag=true
						break
					end 
				end
			end			
		elseif  ControlLevel==6 then
			local userID=	ControlEntity
			local currentUser = _GetDealerID()
			if currentUser==userID then
				sendFlag=true
			else
				if gtPosUserAccessUserTable then
					if gtPosUserAccessUserTable[currentUser] then
						if gtPosUserAccessUserTable[currentUser][userID] then
                            sendFlag=true
							--if gtUserBAMapTable then 
								--if gtUserBAMapTable[userID] then 
									--if gtUserBAMapTable[userID].NumBAMapID>0 then
										--sendFlag=true
									--end
								--end 
							--end
						end
					end
				end
			end
		end]]
		--if sendFlag then
			local ControlEntity=luat.ControlEntity or "-"
			local ConObj=ControlEntity
			local AlarmsIndex=luat.AlarmsIndex or "-"
			evt._SetFld("AlarmsIndex",AlarmsIndex)
			local AlarmsTime=luat.AlarmsTime or "-"
			evt._SetFld("AlarmsTime",AlarmsTime)
			local AlarmsType=luat.AlarmsType or "-"
			if AlarmsType == "0" then
				AlarmsType = "事前"
			elseif AlarmsType == "1" then
				AlarmsType = "事中"
			elseif AlarmsType == "2" then
				AlarmsType = "事后"
			end
			evt._SetFld("AlarmsType",AlarmsType)
			local RiskSetCode=luat.RiskSetCode or "-"
			evt._SetFld("RiskSetCode",RiskSetCode)
			local IndexCode=luat.IndexCode or "-"
			evt._SetFld("IndexCode",IndexCode)
			local IndexName=luat.IndexName or "-"
			evt._SetFld("IndexName",IndexName)


			evt._SetFld("ConObj",ConObj)
			local ClientMessageInfo=luat.ClientMessageInfo or "-"
			evt._SetFld("ClientMessageInfo",ClientMessageInfo)
			_SendEventToClient(evt,gCurSession);
		--end
	end
_End

_OnCommonData(dataName="RradIndexName", DTSDynamicSql dynamicSql)
    local logs;
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		if luat["IndexCode"] and luat["IndexName"] then
            local IndexCode = luat["IndexCode"]
            local IndexName = luat["IndexName"]
            logs = sys_format("RradIndexName:IndexCode[%s],IndexName[%s]",IndexCode,IndexName)
            _WriteAplLog(logs)
            
            gtIndexCode2IndexName[IndexCode] = IndexName
        end				
	end
_End

_OnCommonData(dataName = "ReadUserClientTable", DTSClient client)
	local flag=false
	local userID= client.getDefaultUserID();
    local currentUserID = _GetDealerID()
	if userID==currentUserID then
		flag=true
	else
		if gtPosUserAccessUserTable[currentUserID] then
			if gtPosUserAccessUserTable[currentUserID][userID] then
				flag=true
			end
		end
	end
	if flag then
		local clientID=client.getClientID();
		gtClientTable[clientID]={}
		gtClientTable[clientID].ClientID = clientID
		gtClientTable[clientID].ClientName = client.getClientName();
		gtClientTable[clientID].ClientType = client.getReserveString();
		gtClientTable[clientID].InvestorID = client.getInvestorID();
		gtClientTable[clientID].DefaultUserID = client.getDefaultUserID();
		gtClientTable[clientID].LocationID = client.getLocationID();
		gtClientTable[clientID].Password = client.getPassword()
	end
_End

_OnCommonData(dataName = "GetGroupID", DTSDynamicSql dynamicSql)
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then
		gGroupID= luat["GroupID"]
		gLeaderUserID= luat["LeaderUserID"]
		local log = sys_format("GroupID:%d,LeaderUserID:%s",gGroupID,gLeaderUserID)
		_WriteAplLog(log)
	end

_End

_OnDynamicData(_dataName="LoadCHKDD" ,checkDD2Risk checkDD2RiskEvent);
    local UserID = checkDD2RiskEvent._GetFld("UserID")
    local CHK = checkDD2RiskEvent._GetFld("CHK")
    local log = sys_format("Load checkDD2Risk UserID:%s,CHK:%s",UserID,CHK)
    _WriteAplLog(log)
    
    local UserID_tmp = _GetDealerID()
    if UserID == UserID_tmp then
    
        gtChecked[UserID_tmp] = CHK
        local DTSEvent evt1 = _CreateEventObject("checkDD2RiskOut");
        evt1._SetFld("CHK", CHK);
        _SendEventToClient(evt1,gCurSession);
        
    end
    
    
_End

function LoadCheckDD2Risk()
    local DTSEvent checkDD2RiskEvent = _CreateEventObject("checkDD2Risk")
    local DTSDynamicData checkDD2RiskStore = _CreateDynamicData(TSInstanceName="checkDD2Risk", fileType=_DataOtherType, checkDD2Risk checkDD2RiskEvent);
    checkDD2RiskStore._GetDynamicData(dataName="LoadCHKDD", condition="");
end

function SaveCheckDD2Risk(Checked,userID)
    local DTSEvent checkDD2RiskEvent = _CreateEventObject("checkDD2Risk")
    local DTSDynamicData checkDD2RiskStore = _CreateDynamicData(TSInstanceName="checkDD2Risk", fileType=_DataOtherType, checkDD2Risk checkDD2RiskEvent);
    checkDD2RiskEvent._SetFld("UserID", userID)
    checkDD2RiskStore._Clear()

    checkDD2RiskEvent._SetFld("UserID", userID)
    checkDD2RiskEvent._SetFld("CHK", Checked)
    checkDD2RiskStore._SaveData("checkDD2Risk", checkDD2RiskEvent)
    
    local log = sys_format("save checkDD2Risk userID:%s,gChecked:%s",userID,Checked)
    _WriteAplLog(log)
end

function showDialog(sessionID,logMessage,messageType)
	local DTSEvent evt=_CreateEventObject("LogDialog")
	evt._SetFld("LogMessage",logMessage)
	evt._SetFld("MessageType",messageType)
	if sessionID=="All" then
		_SendToClients(evt)
	else
		_SendEventToClient(evt,sessionID);
	end
	sendLog(sessionID,logMessage)
end

_OnReceiveUnifieldMessage("onCJTZ1", "OnRiskAlarms", DTSUnifieldMessage message)
	message.first()
   	 while not message.eof() do
		
		local Risker = message.getValueByName("Risker")
		local StrJson = message.getValueByName("StrJson")
		local baMapID = ""
		if sys_find(Risker,"|",1) then
			baMapID = sys_sub(Risker,5,-1)
		end
		local log=sys_format("OnRiskAlarms:Risker[%s],baMapID[%s],StrJson[%s]",Risker,baMapID,StrJson)
		_WriteAplLog(log)
		
		Risker = sys_sub(Risker,1,3)
        local currentUser = _GetDealerID()
        local Checked = gtChecked[currentUser]
        if Checked == "True" then
			local flag=false
            if currentUser==Risker then
                flag=true
            else
                if gtPosUserAccessUserTable then
                    if gtPosUserAccessUserTable[currentUser] then
                        if gtPosUserAccessUserTable[currentUser][Risker] then
                            local ControlLevel = message.getValueByName("ControlLevel")
                            local ControlEntity = message.getValueByName("ControlEntity")
                            if ControlLevel==1 then
                            elseif  ControlLevel==2 then
                            end
                            flag=true
                        end
                    end
                end
				
				if not flag then
					_WriteAplLog(baMapID)
					if baMapID ~= "" and _PosBAMapUserTable[baMapID] then
						for userID, v in pairs(_PosBAMapUserTable[baMapID]) do
							_WriteAplLog(userID)
							if userID == currentUser then
								flag=true
							end
						end
					end
				end
            end			
            if flag then
                if StrJson and StrJson~="" then 
                    local DTSSubmitEvent decoder
                    decoder.decode(StrJson)
                    local luat = decoder.asCommon()
                    if luat then
                        local ClientMessageInfo=luat.ClientMessageInfo
                        if ClientMessageInfo and ClientMessageInfo~="" then
                            showDialog("All",ClientMessageInfo,"RiskAlarms")
                        end
                    end
                end
            end
        end
        message.next()
    end
	message.clear()
_End

function changeOrderTime(orderTime)
	local len_str = sys_len(orderTime)
	local ordertime_2 = ""
	for i=1,len_str,1 do
		local str = sys_sub(orderTime,i,i)
		if str == "0" or str == "1" or str == "2" or str == "3" or str == "4" or str == "5" or str == "6" or str == "7" or str == "8" or str == "9" then
			ordertime_2 = ordertime_2 .. str
		end
	end
	
	return ordertime_2
end

function GetAlertShowMode()
	_WriteAplLog("Into GetAlertShowMode")
	gShowAlert = ""
	gShowAlertCurUser=""
	local currentUserID = _GetDealerID()
	local GlobalVariableTableSql = sys_format("VariableName = 'ShowAlert%s' or VariableName='ShowAlert'",currentUserID)
	_WriteAplLog(GlobalVariableTableSql)
	_GetCommonData(dataName = "GetAlertShowMode", condition = GlobalVariableTableSql, tablename = "GlobalVariable");
end

_OnCommonData(dataName = "GetAlertShowMode", DTSGlobalVariable evt)
	_WriteAplLog("_OnCommonData GetAlertShowMode")
	local currentUserID = _GetDealerID()
	local variableName = evt.getVariableName()
	if sys_find(variableName,currentUserID,1)~=nil then
		gShowAlertCurUser = evt.getVariableValue()
	else
		gShowAlert = evt.getVariableValue()
	end
	local log = sys_format("GetAlertShowMode : %s ,CurUser : %s" ,gShowAlert,gShowAlertCurUser)
	_WriteAplLog(log)
_End

_OnCommonData("GlobalVariable2KCBSupport",DTSGlobalVariable gv)
	local KCBSupport2IssueList = gv.getVariableValue()
	gKCBList = KCBSupport2IssueList
	local log = sys_format("GlobalVariable2KCBSupport:科创版合约支持[%s]",KCBSupport2IssueList)
	_WriteAplLog(log)
	
	--if KCBSupport2IssueList ~= "" and KCBSupport2IssueList ~= " " then
		local sessionID = gtKCBSupport["KCBSupport"]
		local DTSEvent KCBSupportEvent = _CreateEventObject("SnedKCBSupport");
		KCBSupportEvent._SetFld("KCBSupport2IssueList", KCBSupport2IssueList);
		if sessionID=="All" then
			_SendToClients(KCBSupportEvent)
		else
			_SendEventToClient(KCBSupportEvent,sessionID);
		end
	--end
_End

_DefineEventObject SnedKCBSupport _AS _Output
	_DefFld("KCBSupport2IssueList", _String, 1000)	--合约代码
	
    _SetBufferedFlag(0);
	_SetDataType(_EventOtherType);
_End;

_OnCommonData(dataName="GetForbidPositionData", DTSDynamicSql dynamicSql)
	_WriteAplLog("---------------- GetForbidPositionData CommonData test --------------")
	local data = dynamicSql.getData();
	_WriteAplLog(data)
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		--for field,value in pairs(luat) do 
			local BAMapID=luat["BAMapID"]
			local BASubID=luat["BASubID"]
			local IssueCode=luat["IssueCode"]
			local ForbidPosition=luat["ForbidPosition"]
			local ReserveString=luat["ReserveString"]
			
			local log = sys_format("Into SQL:DTSBAMapID2ForbidPositionTable -> BAMapID[%s],BASubID[%s],IssueCode[%s],ForbidPosition[%s],ReserveString[%s]",
			BAMapID,BASubID,IssueCode,ForbidPosition,ReserveString)
			_WriteAplLog(log)
			
			local _String posKey = sys_format("%s.%s.%s",BAMapID,BASubID,IssueCode)
			gtBAMapID2ForbidPositionTable[posKey] = {}
			gtBAMapID2ForbidPositionTable[posKey].BAMapID = BAMapID
			gtBAMapID2ForbidPositionTable[posKey].BASubID = BASubID
			gtBAMapID2ForbidPositionTable[posKey].IssueCode = IssueCode
			gtBAMapID2ForbidPositionTable[posKey].ForbidPosition = ForbidPosition
			--gtBAMapID2ForbidPositionTable[posKey].ReserveString = ReserveString
			
			if not gtIssueCode2ForbidPosition[IssueCode] then
				gtIssueCode2ForbidPosition[IssueCode] = ForbidPosition
			else
				gtIssueCode2ForbidPosition[IssueCode] = gtIssueCode2ForbidPosition[IssueCode] + ForbidPosition
			end
		--end
	end
_End

_OnReceiveUnifieldMessage("ForbidPosition", "UpdateForbidPosition", DTSUnifieldMessage srcMsg)
	_WriteAplLog("_OnReceiveUnifieldMessage UpdateForbidPosition")
	local log;
	local Row = srcMsg.getRowCount()    
    local Col = srcMsg.getColCount()    
    local clientno = srcMsg.getClientNo()    
    log = sys_format("列数:%d行数:%d主题:%s",Row,Col,clientno)    
    _WriteAplLog(log)
	srcMsg.first()--移动到第一条消息
	
	local LeaderUserID = ""
	local BAMapID = ""
	local BASubID = ""
	local IssueCode = ""
	local Qty = ""
	
	while not srcMsg.eof() do
		for i=1,Col do
            local field = srcMsg.getField()
            local value = srcMsg.getValue()
            local log = sys_format("字段名:[%s],字段值:[%s]",field,value)
            _WriteAplLog(log)
			
			--if clientno == "SecuritiesID" then
				if field == "LeaderUserID" then
					LeaderUserID = value
				elseif field == "BAMapID" then
					BAMapID = value
				elseif field == "BASubID" then
					BASubID = value
				elseif field == "IssueCode" then
					IssueCode = value
				elseif field == "Qty" then
					Qty = value
				end
			--end
		end
		srcMsg.next()
		
		loglog = sys_format(" ->-> LeaderUserID[%s]:BAMapID:[%s],BASubID:[%s],IssueCode:[%s],Qty[%s]",
		LeaderUserID,BAMapID,BASubID,IssueCode,Qty)
		_WriteAplLog(loglog)
		Qty = sys_format("%s",Qty)
		Qty = Qty.getNumberValue()
		if LeaderUserID == gLeaderUserID and gtRunAccountTable[BAMapID] then
			-- 更新禁用数量
			local _String posKey = sys_format("%s.%s.%s",BAMapID,BASubID,IssueCode)
			
			local oldForbidPosition = 0
			if not gtBAMapID2ForbidPositionTable[posKey] then
				gtBAMapID2ForbidPositionTable[posKey] = {}
				gtBAMapID2ForbidPositionTable[posKey].BAMapID = BAMapID
				gtBAMapID2ForbidPositionTable[posKey].BASubID = BASubID
				gtBAMapID2ForbidPositionTable[posKey].IssueCode = IssueCode
				gtBAMapID2ForbidPositionTable[posKey].ForbidPosition = 0
			end
			
			if not gtIssueCode2ForbidPosition[IssueCode] then
				gtIssueCode2ForbidPosition[IssueCode] = Qty
			else
				gtIssueCode2ForbidPosition[IssueCode] = gtIssueCode2ForbidPosition[IssueCode] - gtBAMapID2ForbidPositionTable[posKey].ForbidPosition + Qty
			end
			
			gtBAMapID2ForbidPositionTable[posKey].ForbidPosition = Qty
			
			--刷新
			for sessionID,v in pairs(gtSessionTable) do 	
				RefreshPosFund(sessionID)
			end
		end
	end
	srcMsg.clear()
_End

-- 新增跨库查询回调
_OnCommonData(dataName="ReadInvestorOrderSort", DTSDynamicSql dynamicSql)
    local logs;
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		if luat["ClientID"] and luat["InvestorID"] and luat["OrderIndex"] then
            local ClientID = luat["ClientID"]
            local InvestorID = luat["InvestorID"]
            local OrderIndex = luat["OrderIndex"]
            logs = sys_format("InvestorOrderSort:ClientID[%s],InvestorID[%s],OrderIndex[%s]",ClientID,InvestorID,OrderIndex)
            _WriteAplLog(logs)
            
			sys_insert(gOrderSortClient,ClientID)
        end				
	end
_End

_OnCommonData(dataName="ReadInventoryComponent", DTSDynamicSql dynamicSql)
    local logs;
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		local InventoryID = luat["InventoryID"]
		local IssueCode = luat["IssueCode"]
		local Ratio = luat["Ratio"]
		local Quantity = luat["Quantity"]
		local BuyPrice = luat["BuyPrice"]
		local IsSelected = luat["IsSelected"]
		logs = sys_format("ReadInventoryComponent:InventoryID[%s],IssueCode[%s],Ratio[%s],Quantity[%s],BuyPrice[%s],IsSelected[%s]",InventoryID,IssueCode,Ratio,Quantity,BuyPrice,IsSelected)
		_WriteAplLog(logs)
		
		if isNumBer(BuyPrice) then
			if BuyPrice-0.00001<0 then
				BuyPrice=""
			end
		--else
		--	BuyPrice=""
		end
		gtInventoryComponentTable[InventoryID]=gtInventoryComponentTable[InventoryID] or {}
		gtInventoryComponentTable[InventoryID][IssueCode]={}
		gtInventoryComponentTable[InventoryID][IssueCode].Ratio=Ratio
		gtInventoryComponentTable[InventoryID][IssueCode].Quantity=Quantity
		gtInventoryComponentTable[InventoryID][IssueCode].BuyPrice=BuyPrice
		gtInventoryComponentTable[InventoryID][IssueCode].IsSelected=IsSelected
		if not gtPriceTable[IssueCode] then
			local issueCode=IssueCode
			local marketCode = _PosIssueMarketTable[issueCode]
			_RegisterPrice(_IssueCode = issueCode, _MarketCode = marketCode)
		end
	end
_End

_OnCommonData(dataName="ReadInventoryHeader", DTSDynamicSql dynamicSql)
    local logs;
	local data = dynamicSql.getData();
	local DTSSubmitEvent decoder
	decoder.decode(data)
	local luat = decoder.asCommon()
	if luat then 
		local InventoryID = luat["InventoryID"]
		local InventoryName = luat["InventoryName"]
		local IsPublic = luat["IsPublic"]
		local WeightType = luat["WeightType"]
		local PerAmount = luat["PerAmount"]
		local Owner = luat["Owner"]
		local AddType = luat["AddType"]
		local DeleteFlg = luat["DeleteFlg"]
		local BuySell = luat["BuySell"]
		local CreateTime = luat["CreateTime"]
		local ReserveString = luat["ReserveString"] or "按固定金额"
		local ComponentCount = luat["ComponentCount"]

		logs = sys_format("ReadInventoryHeaderTable:InventoryID[%s],InventoryName[%s],IsPublic[%s],WeightType[%s],PerAmount[%s],Owner[%s],AddType[%s],DeleteFlg[%s],BuySell[%s],CreateTime[%s],ReserveString[%s],ComponentCount[%s]",
		InventoryID,InventoryName,IsPublic,WeightType,PerAmount,Owner,AddType,DeleteFlg,BuySell,CreateTime,ReserveString,ComponentCount)
		_WriteAplLog(logs)
		
		if BuySell ~= "卖" then
			BuySell = "买"
		end
		gtInventoryHeaderTable[InventoryID]=gtInventoryHeaderTable[InventoryID] or {}
		gtInventoryHeaderTable[InventoryID].InventoryName=InventoryName
		gtInventoryHeaderTable[InventoryID].IsPublic=IsPublic
		gtInventoryHeaderTable[InventoryID].WeightType=WeightType
		gtInventoryHeaderTable[InventoryID].PerAmount=PerAmount
		gtInventoryHeaderTable[InventoryID].Owner=Owner
		gtInventoryHeaderTable[InventoryID].AddType=AddType
		gtInventoryHeaderTable[InventoryID].DeleteFlg=DeleteFlg
		gtInventoryHeaderTable[InventoryID].BuySell=BuySell
		gtInventoryHeaderTable[InventoryID].CreateTime = CreateTime
		gtInventoryHeaderTable[InventoryID].ReserveString = ReserveString
		gtInventoryHeaderTable[InventoryID].ComponentCount = ComponentCount
	end
_End

--刷新账户资金信息
function UpdateFundInfo(sessionID,baMapID,ifSend)
	if not gtSessionTable[sessionID] then
		return 
	end
	if not gtSessionTable[sessionID].CurBAMapIDTable then
		return 
	end
	local sumAccountType = "S" --账户类型
	local sumLastFund = 0     --昨日资金
	local sumLastAssetValue=0 --昨日权益

	local sumAvlFund = 0 -- 可用资金
	local sumMarketValue = 0 --市值
	local sumAssetValue = 0  --权益	
	
	--local sumFund = 0; --资金余额
	local sumOrderFund = 0; --开仓冻结资金
	local sumForbidFund = 0; --冻结资金
	local sumMargin=0
	local sumTransferIn=0
	local sumTransferOut=0
	local sumFare=0
	local sumRealizedPL=0
	local sumRealizedPLM2D=0
	local sumValuationPL=0
	local sumValuationPLM2D=0
		
	local sumMTBalance = 0
	local sumEquityFund = 0
	local beginDate="-"
	local endDate="-"
	local sumLossFund4Alert = 0
	local sumLossFund4Close = 0
	local sumInitialFund = 0
	
	local sumResistance2Risk = 0
	local sumAssetValue4Customer = 0
	local sumStockValue = 0
	
	if baMapID == "All" then
		for baMapID, value in pairs(gtSessionTable[sessionID].CurBAMapIDTable) do
			local accountCode = _PosBAMapAccount[baMapID]
			if accountCode then 
				if _PosFundStatus[accountCode] and gtZGProductAccountTable[baMapID] then
					local accountType = _PosFundStatus[accountCode].Type
					--市值
					local marketValue = 0
					marketValue =_PosFundStatus[accountCode].Margin+_PosFundStatus[accountCode].ValuationPL
					sumMarketValue = sumMarketValue + marketValue
					sumAccountType = accountType
					
					--资金余额(上一个交易日的可用资金)
					local lastFund = _PosFundStatus[accountCode]["LastFund"]
					sumLastFund = sumLastFund + lastFund
					
					local lastAssetValue = _PosFundStatus[accountCode]["LastAssetValue"] 
					sumLastAssetValue=sumLastAssetValue+lastAssetValue

					--当日转入资金
					local transferIn = _PosFundStatus[accountCode]["TransferIn"]
					sumTransferIn=sumTransferIn+transferIn
					--当日转出资金
					local transferOut = _PosFundStatus[accountCode]["TransferOut"]		
					sumTransferOut=sumTransferOut+transferOut
					
					--开仓冻结资金
					local orderFund = _PosFundStatus[accountCode]["OrderFund"]
					sumOrderFund = sumOrderFund + orderFund

					local margin = _PosFundStatus[accountCode]["Margin"]
					sumMargin=sumMargin+margin
					--费用
					local fare = _PosFundStatus[accountCode]["Fare"]
					fare = fare.getNumberValue()
					sumFare=sumFare+fare
					
					local realizedPL = _PosFundStatus[accountCode]["RealizedPL"]
					sumRealizedPL=sumRealizedPL+realizedPL
					local realizedPLM2D = _PosFundStatus[accountCode]["RealizedPLM2D"]			
					sumRealizedPLM2D=sumRealizedPLM2D+realizedPLM2D
					local valuationPL = _PosFundStatus[accountCode]["ValuationPL"]
					sumValuationPL=sumValuationPL+valuationPL
					local valuationPLM2D = _PosFundStatus[accountCode]["ValuationPLM2D"]
					sumValuationPLM2D=sumValuationPLM2D+valuationPLM2D
						
					local mTBalance="-"
					local lossRatio4Alert = 0
					local lossRatio4Close = 0
					local lossFund4Alert = "-"
					local lossFund4Close = "-"
					local totalFund = 0
					
					--可用资金
					local forbidBuy = "0"
					if gtZGProductAccountTable[baMapID] then
						forbidBuy = gtZGProductAccountTable[baMapID].ForbidBuy
					end
					
					local avlFund = _PosFundStatus[accountCode]["AvlFund"]
					local assetValue = _PosFundStatus[accountCode]["AssetValue"]
					if forbidBuy~="1" or gFund4ForbidBuyBAMapIDShowMode~="1" then	--没有设置限制买入的计算到可用资金，限制买入账号的可用资金不计算在内
						sumAvlFund = sumAvlFund + avlFund		
						sumAssetValue = sumAssetValue + assetValue
					end
					
					local ForbidFund = 0
					if gtZGProductAccountTable[baMapID] then
						ForbidFund = gtZGProductAccountTable[baMapID].ForbidFund or 0
					end
					sumForbidFund = sumForbidFund + ForbidFund
					
					local mtBalance = 0
					mTBalance=gtZGProductAccountTable[baMapID].MTBalance
					if mTBalance and mTBalance ~= "" and mTBalance ~= "-" then
						mTBalance = sys_format("%.2f",mTBalance);
						sumMTBalance = sumMTBalance + mTBalance
						mtBalance = mTBalance
					else
						mTBalance = "-"
						sumMTBalance = sumMTBalance + 0
					end

					beginDate=gtZGProductAccountTable[baMapID].BeginDate
					endDate=gtZGProductAccountTable[baMapID].EndDate
					if not beginDate or beginDate == "" or beginDate == " " then
						beginDate = "-"
					end
					if not endDate or endDate == "" or endDate == " " then
						endDate = "-"
					end
					lossRatio4Alert = gtZGProductAccountTable[baMapID].LossRatio4Alert or 0
					lossRatio4Alert = lossRatio4Alert.getNumberValue()
					lossRatio4Close = gtZGProductAccountTable[baMapID].LossRatio4Close or 0
					lossRatio4Close = lossRatio4Close.getNumberValue()

					local seniorFund = gtZGProductAccountTable[baMapID].SeniorFund or 0 --优先资金
					seniorFund = seniorFund.getNumberValue()
					local mezzFund = gtZGProductAccountTable[baMapID].MezzFund or 0	--分层资金
					mezzFund = mezzFund.getNumberValue()
					local equityFund = gtZGProductAccountTable[baMapID].EquityFund or 0	--劣后资金
					equityFund = equityFund.getNumberValue()

					--理财账户初始权益=优先+夹层+劣后
					if seniorFund and mezzFund and equityFund then
						totalFund = seniorFund + mezzFund + equityFund
					end
					sumInitialFund = sumInitialFund + totalFund

					if equityFund and equityFund ~= "" and equityFund ~= "-" then
						sumEquityFund = sumEquityFund + equityFund
					end
					
					local lossFund4A = 0
					lossFund4Alert = gtZGProductAccountTable[baMapID].LossFund4Alert
					if lossFund4Alert and lossFund4Alert ~= "" and lossFund4Alert ~= "-" then
						lossFund4Alert = sys_format("%.2f",lossFund4Alert);
						sumLossFund4Alert = sumLossFund4Alert + lossFund4Alert
						lossFund4A = lossFund4Alert
					end
					
					local lossFund4C = 0
					lossFund4Close = gtZGProductAccountTable[baMapID].LossFund4Close
					if lossFund4Close and lossFund4Close ~= "" and lossFund4Close ~= "-" then
						lossFund4Close = sys_format("%.2f",lossFund4Close);
						sumLossFund4Close = sumLossFund4Close  + lossFund4Close
						lossFund4C = lossFund4Close
					end
					
					--增加抗跌风险度
					local v=gtZGProductAccountTable[baMapID]
					local MTFund = 0
					if v.SeniorFund and v.SeniorFund~="" then
						MTFund=MTFund+v.SeniorFund
					end
					if v.MezzFund and v.MezzFund~="" then
						MTFund=MTFund+v.MezzFund
					end
					if MTFund~=0 then
						MTFund=sys_format("%.2f",MTFund)
					end

					assetValue=sys_format("%.2f",assetValue)
					local AssetValue4Customer=assetValue-MTFund
					AssetValue4Customer=sys_format("%.2f",AssetValue4Customer)
					sumAssetValue4Customer = sumAssetValue4Customer + AssetValue4Customer
					local StockValue = 0
					local fund=_PosFundStatus[accountCode]
					for posKey, pos in pairs(_PosPositionTable) do
						if baMapID==pos.BAMapID then
							local quantity=pos.Quantity
							local issueCode=pos.IssueCode
							local marketValue=0
							if fund.Type== "S" then
								local contractSize = 1
								if _PosIssueContractSizeTable[issueCode] then
									contractSize = _PosIssueContractSizeTable[issueCode]
								end
								if _PosPriceTable[issueCode] then
									local lastPrice = _PosPriceTable[issueCode].LastPrice --最新价
									if lastPrice then
										marketValue=lastPrice*quantity*contractSize
									end
								end
							end
							StockValue=StockValue+marketValue
						end
					end
					
					local resistance2Risk = 0
					if StockValue ~= 0 then
						StockValue=sys_format("%.2f",StockValue)
						sumStockValue = sumStockValue + StockValue
						
						resistance2Risk = 100*AssetValue4Customer/StockValue
						resistance2Risk=sys_format("%.2f",resistance2Risk)
					end	
					
					--存储缓存明细表，--缓存表的key应包含sessionID，by frank.shi
					local accountCode_sessionID = sys_format("%s_%s",accountCode,sessionID)
					local log2_2 = sys_format("accountCode_sessionID: %s",accountCode_sessionID)
					_WriteAplLog(log2_2)
					
					if not gtfundStatusAccountCode_Cache[accountCode_sessionID] then
						 gtfundStatusAccountCode_Cache[accountCode_sessionID] = {}
					end
					
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["accountType"] = accountType
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["lastFund"] = lastFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["lastAssetValue"] = lastAssetValue
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["avlFund"] = avlFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["marketValue"] = marketValue
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["assetValue"] = assetValue
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["orderFund"] = orderFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["ForbidFund"] = ForbidFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["margin"] = margin
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["transferIn"] = transferIn
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["transferOut"] = transferOut
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["fare"] = fare
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["realizedPL"] = realizedPL
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["realizedPLM2D"] = realizedPLM2D
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["valuationPL"] = valuationPL
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["valuationPLM2D"] = valuationPLM2D
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["mtBalance"] = mtBalance
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["equityFund"] = equityFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["beginDate"] = beginDate
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["endDate"] = endDate
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["lossFund4A"] = lossFund4A
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["lossFund4C"] = lossFund4C
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["totalFund"] = totalFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["resistance2Risk"] = resistance2Risk
					
					local log = sys_format("BaMapALL-UpdateFundInfoOne ======> accountCode_sessionID[%s],accountType[%s],lastFund[%s],lastAssetValue[%s],avlFund[%s],marketValue[%s],assetValue[%s],orderFund[%s],ForbidFund[%s],margin[%s],transferIn[%s],transferOut[%s],fare[%s],realizedPL[%s],realizedPLM2D[%s],valuationPL[%s],valuationPLM2D[%s],mtBalance[%s],equityFund[%s],beginDate[%s],endDate[%s],lossFund4A[%s],lossFund4C[%s],totalFund[%s],resistance2Risk[%s]",
					accountCode_sessionID,accountType,lastFund,lastAssetValue,avlFund,marketValue,assetValue,orderFund,ForbidFund,margin,transferIn,transferOut,fare,realizedPL,realizedPLM2D,valuationPL,valuationPLM2D,mtBalance,equityFund,beginDate,endDate,lossFund4A,lossFund4C,totalFund,resistance2Risk)
					_WriteAplLog(log)
				end
			end
		end
		
		if sumStockValue ~= 0 then--0
			sumResistance2Risk = 100*sumAssetValue4Customer/sumStockValue
			sumResistance2Risk=sys_format("%.2f",sumResistance2Risk)
		end
		
		gtSessionTable[sessionID].AvailableFund=sumAvlFund
		
		sumLastFund = sys_format("%.2f",sumLastFund);
		sumLastAssetValue = sys_format("%.2f",sumLastAssetValue);	
		sumOrderFund = sys_format("%.2f",sumOrderFund)
		sumForbidFund = sys_format("%.2f",sumForbidFund)
		sumAvlFund = sys_format("%.2f",sumAvlFund)
		sumMarketValue = sys_format("%.2f", sumMarketValue)
		sumAssetValue = sys_format("%.2f",sumAssetValue);	
		sumTransferIn = sys_format("%.2f", sumTransferIn)
		sumTransferOut = sys_format("%.2f",sumTransferOut);		
		sumMargin = sys_format("%.2f", sumMargin)
		sumFare = sys_format("%.2f",sumFare);
		sumRealizedPL = sys_format("%.2f", sumRealizedPL)
		sumRealizedPLM2D= sys_format("%.2f", sumRealizedPLM2D)
		sumValuationPL = sys_format("%.2f", sumValuationPL)
		sumValuationPLM2D = sys_format("%.2f", sumValuationPLM2D)	
		sumMTBalance = sys_format("%.2f", sumMTBalance)
		sumEquityFund = sys_format("%.2f", sumEquityFund) 
		sumLossFund4Alert = sys_format("%.2f", sumLossFund4Alert)
		sumLossFund4Close = sys_format("%.2f", sumLossFund4Close)
		sumInitialFund = sys_format("%.2f", sumInitialFund)
		
		--存储缓存总表
		if not gtfundStatusAllSessionID_Cache[sessionID] then
			 gtfundStatusAllSessionID_Cache[sessionID] = {}
		end
		
		gtfundStatusAllSessionID_Cache[sessionID]["sumAccountType"] = sumAccountType
		gtfundStatusAllSessionID_Cache[sessionID]["sumLastFund"] = sumLastFund
		gtfundStatusAllSessionID_Cache[sessionID]["sumLastAssetValue"] = sumLastAssetValue
		gtfundStatusAllSessionID_Cache[sessionID]["sumAvlFund"] = sumAvlFund
		gtfundStatusAllSessionID_Cache[sessionID]["sumMarketValue"] = sumMarketValue
		gtfundStatusAllSessionID_Cache[sessionID]["sumAssetValue"] = sumAssetValue
		gtfundStatusAllSessionID_Cache[sessionID]["sumOrderFund"] = sumOrderFund
		gtfundStatusAllSessionID_Cache[sessionID]["sumForbidFund"] = sumForbidFund
		gtfundStatusAllSessionID_Cache[sessionID]["sumMargin"] = sumMargin
		gtfundStatusAllSessionID_Cache[sessionID]["sumTransferIn"] = sumTransferIn
		gtfundStatusAllSessionID_Cache[sessionID]["sumTransferOut"] = sumTransferOut
		gtfundStatusAllSessionID_Cache[sessionID]["sumFare"] = sumFare
		gtfundStatusAllSessionID_Cache[sessionID]["sumRealizedPL"] = sumRealizedPL
		gtfundStatusAllSessionID_Cache[sessionID]["sumRealizedPLM2D"] = sumRealizedPLM2D
		gtfundStatusAllSessionID_Cache[sessionID]["sumValuationPL"] = sumValuationPL
		gtfundStatusAllSessionID_Cache[sessionID]["sumValuationPLM2D"] = sumValuationPLM2D
		gtfundStatusAllSessionID_Cache[sessionID]["sumMTBalance"] = sumMTBalance
		gtfundStatusAllSessionID_Cache[sessionID]["sumEquityFund"] = sumEquityFund
		gtfundStatusAllSessionID_Cache[sessionID]["beginDate"] = beginDate
		gtfundStatusAllSessionID_Cache[sessionID]["endDate"] = endDate
		gtfundStatusAllSessionID_Cache[sessionID]["sumLossFund4Alert"] = sumLossFund4Alert
		gtfundStatusAllSessionID_Cache[sessionID]["sumLossFund4Close"] = sumLossFund4Close
		gtfundStatusAllSessionID_Cache[sessionID]["sumInitialFund"] = sumInitialFund
		gtfundStatusAllSessionID_Cache[sessionID]["sumResistance2Risk"] = sumResistance2Risk
		
		local log = sys_format("BaMapALL-UpdateFundInfoAll ======> sessionID[%s],sumAccountType[%s],sumLastFund[%s],sumLastAssetValue[%s],sumAvlFund[%s],sumMarketValue[%s],sumAssetValue[%s],sumOrderFund[%s],sumForbidFund[%s],sumMargin[%s],sumTransferIn[%s],sumTransferOut[%s],sumFare[%s],sumRealizedPL[%s],sumRealizedPLM2D[%s],sumValuationPL[%s],sumValuationPLM2D[%s],sumMTBalance[%s],sumEquityFund[%s],beginDate[%s],endDate[%s],sumLossFund4Alert[%s],sumLossFund4Close[%s],sumInitialFund[%s],sumResistance2Risk[%s]",
		sessionID,sumAccountType,sumLastFund,sumLastAssetValue,sumAvlFund,sumMarketValue,sumAssetValue,sumOrderFund,sumForbidFund,sumMargin,sumTransferIn,sumTransferOut,sumFare,sumRealizedPL,sumRealizedPLM2D,sumValuationPL,sumValuationPLM2D,sumMTBalance,sumEquityFund,beginDate,endDate,sumLossFund4Alert,sumLossFund4Close,sumInitialFund,sumResistance2Risk)
		_WriteAplLog(log)
	else
		local accountCode = _PosBAMapAccount[baMapID]
		if accountCode then 
			if _PosFundStatus[accountCode] and gtZGProductAccountTable[baMapID] then
			
				local accountCode_sessionID = sys_format("%s_%s",accountCode,sessionID)
				local log2_2 = sys_format("accountCode_sessionID: %s",accountCode_sessionID)
				_WriteAplLog(log2_2)
			
				if gtfundStatusAllSessionID_Cache[sessionID] and gtfundStatusAccountCode_Cache[accountCode_sessionID] then
					local sumAccountType_old =  gtfundStatusAllSessionID_Cache[sessionID]["sumAccountType"]
					local sumLastFund_old = gtfundStatusAllSessionID_Cache[sessionID]["sumLastFund"]
					local sumLastAssetValue_old = gtfundStatusAllSessionID_Cache[sessionID]["sumLastAssetValue"]
					local sumAvlFund_old = gtfundStatusAllSessionID_Cache[sessionID]["sumAvlFund"]
					local sumMarketValue_old = gtfundStatusAllSessionID_Cache[sessionID]["sumMarketValue"]
					local sumAssetValue_old = gtfundStatusAllSessionID_Cache[sessionID]["sumAssetValue"]
					local sumOrderFund_old = gtfundStatusAllSessionID_Cache[sessionID]["sumOrderFund"]
					local sumForbidFund_old = gtfundStatusAllSessionID_Cache[sessionID]["sumForbidFund"]
					local sumMargin_old = gtfundStatusAllSessionID_Cache[sessionID]["sumMargin"]
					local sumTransferIn_old = gtfundStatusAllSessionID_Cache[sessionID]["sumTransferIn"]
					local sumTransferOut_old = gtfundStatusAllSessionID_Cache[sessionID]["sumTransferOut"]
					local sumFare_old = gtfundStatusAllSessionID_Cache[sessionID]["sumFare"]
					local sumRealizedPL_old = gtfundStatusAllSessionID_Cache[sessionID]["sumRealizedPL"]
					local sumRealizedPLM2D_old = gtfundStatusAllSessionID_Cache[sessionID]["sumRealizedPLM2D"]
					local sumValuationPL_old = gtfundStatusAllSessionID_Cache[sessionID]["sumValuationPL"]
					local sumValuationPLM2D_old = gtfundStatusAllSessionID_Cache[sessionID]["sumValuationPLM2D"]
					local sumMTBalance_old = gtfundStatusAllSessionID_Cache[sessionID]["sumMTBalance"]
					local sumEquityFund_old = gtfundStatusAllSessionID_Cache[sessionID]["sumEquityFund"]
					local AbeginDate_old = gtfundStatusAllSessionID_Cache[sessionID]["beginDate"]
					local AendDate_old = gtfundStatusAllSessionID_Cache[sessionID]["endDate"]
					local sumLossFund4Alert_old = gtfundStatusAllSessionID_Cache[sessionID]["sumLossFund4Alert"]
					local sumLossFund4Close_old = gtfundStatusAllSessionID_Cache[sessionID]["sumLossFund4Close"]
					local sumInitialFund_old = gtfundStatusAllSessionID_Cache[sessionID]["sumInitialFund"]
					local sumResistance2Risk_old = gtfundStatusAllSessionID_Cache[sessionID]["sumResistance2Risk"]

					local accountType_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["accountType"]
					local lastFund_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["lastFund"]
					local lastAssetValue_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["lastAssetValue"]
					local avlFund_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["avlFund"]
					local marketValue_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["marketValue"]
					local assetValue_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["assetValue"]
					local orderFund_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["orderFund"]
					local ForbidFund_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["ForbidFund"]
					local margin_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["margin"]
					local transferIn_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["transferIn"]
					local transferOut_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["transferOut"]
					local fare_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["fare"]
					local realizedPL_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["realizedPL"]
					local realizedPLM2D_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["realizedPLM2D"]
					local valuationPL_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["valuationPL"]
					local valuationPLM2D_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["valuationPLM2D"]
					local mtBalance_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["mtBalance"]
					local equityFund_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["equityFund"]
					local beginDate_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["beginDate"]
					local endDate_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["endDate"]
					local lossFund4A_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["lossFund4A"]
					local lossFund4C_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["lossFund4C"]
					local totalFund_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["totalFund"]
					local resistance2Risk_old = gtfundStatusAccountCode_Cache[accountCode_sessionID]["resistance2Risk"]
					
					--开始新的计算
					local accountType = _PosFundStatus[accountCode].Type
					--市值
					local marketValue = 0
					marketValue =_PosFundStatus[accountCode].Margin+_PosFundStatus[accountCode].ValuationPL
					sumMarketValue = sumMarketValue_old - marketValue_old + marketValue
					sumAccountType = accountType
					
					--资金余额(上一个交易日的可用资金)
					local lastFund = _PosFundStatus[accountCode]["LastFund"]
					sumLastFund = sumLastFund_old - lastFund_old + lastFund
					
					local lastAssetValue = _PosFundStatus[accountCode]["LastAssetValue"] 
					sumLastAssetValue=sumLastAssetValue_old - lastAssetValue_old + lastAssetValue

					--当日转入资金
					local transferIn = _PosFundStatus[accountCode]["TransferIn"]
					sumTransferIn = sumTransferIn_old - transferIn_old + transferIn
					--当日转出资金
					local transferOut = _PosFundStatus[accountCode]["TransferOut"]		
					sumTransferOut = sumTransferOut_old - transferOut_old + transferOut
					
					--开仓冻结资金
					local orderFund = _PosFundStatus[accountCode]["OrderFund"]
					sumOrderFund = sumOrderFund_old - orderFund_old + orderFund

					local margin = _PosFundStatus[accountCode]["Margin"]
					sumMargin = sumMargin_old - margin_old + margin
					--费用
					local fare = _PosFundStatus[accountCode]["Fare"]
					fare = fare.getNumberValue()
					sumFare = sumFare_old- fare_old + fare
					
					local realizedPL = _PosFundStatus[accountCode]["RealizedPL"]
					sumRealizedPL = sumRealizedPL_old - realizedPL_old + realizedPL
					local realizedPLM2D = _PosFundStatus[accountCode]["RealizedPLM2D"]			
					sumRealizedPLM2D = sumRealizedPLM2D_old - realizedPLM2D_old + realizedPLM2D
					local valuationPL = _PosFundStatus[accountCode]["ValuationPL"]
					sumValuationPL= sumValuationPL_old - valuationPL_old + valuationPL
					local valuationPLM2D = _PosFundStatus[accountCode]["ValuationPLM2D"]
					sumValuationPLM2D = valuationPLM2D_old - valuationPLM2D_old + valuationPLM2D
						
					local mTBalance="-"
					local lossRatio4Alert = 0
					local lossRatio4Close = 0
					local lossFund4Alert = "-"
					local lossFund4Close = "-"
					local totalFund = 0
					
					--可用资金
					local forbidBuy = "0"
					if gtZGProductAccountTable[baMapID] then
						forbidBuy = gtZGProductAccountTable[baMapID].ForbidBuy
					end
					
					local avlFund = _PosFundStatus[accountCode]["AvlFund"]
					local assetValue = _PosFundStatus[accountCode]["AssetValue"]
					if forbidBuy~="1" or gFund4ForbidBuyBAMapIDShowMode~="1" then	--没有设置限制买入的计算到可用资金，限制买入账号的可用资金不计算在内
						sumAvlFund = sumAvlFund_old - avlFund_old + avlFund		
						sumAssetValue = sumAssetValue_old - assetValue_old + assetValue
					end
					
					local ForbidFund = 0
					if gtZGProductAccountTable[baMapID] then
						ForbidFund = gtZGProductAccountTable[baMapID].ForbidFund or 0
					end
					sumForbidFund = sumForbidFund_old - ForbidFund_old + ForbidFund
					
					local mtBalance = 0
					mTBalance=gtZGProductAccountTable[baMapID].MTBalance
					if mTBalance and mTBalance ~= "" and mTBalance ~= "-" then
						mTBalance = sys_format("%.2f",mTBalance);
						sumMTBalance = sumMTBalance_old - mtBalance_old + mTBalance
						mtBalance = mTBalance
					else
						sumMTBalance = sumMTBalance_old - mtBalance_old
					end

					beginDate=gtZGProductAccountTable[baMapID].BeginDate
					endDate=gtZGProductAccountTable[baMapID].EndDate
					if not beginDate or beginDate == "" or beginDate == " " then
						beginDate = "-"
					end
					if not endDate or endDate == "" or endDate == " " then
						endDate = "-"
					end
					lossRatio4Alert = gtZGProductAccountTable[baMapID].LossRatio4Alert or 0
					lossRatio4Alert = lossRatio4Alert.getNumberValue()
					lossRatio4Close = gtZGProductAccountTable[baMapID].LossRatio4Close or 0
					lossRatio4Close = lossRatio4Close.getNumberValue()

					local seniorFund = gtZGProductAccountTable[baMapID].SeniorFund or 0 --优先资金
					seniorFund = seniorFund.getNumberValue()
					local mezzFund = gtZGProductAccountTable[baMapID].MezzFund or 0	--分层资金
					mezzFund = mezzFund.getNumberValue()
					local equityFund = gtZGProductAccountTable[baMapID].EquityFund or 0	--劣后资金
					equityFund = equityFund.getNumberValue()

					--理财账户初始权益=优先+夹层+劣后
					if seniorFund and mezzFund and equityFund then
						totalFund = seniorFund + mezzFund + equityFund
					end
					sumInitialFund = sumInitialFund_old - totalFund_old + totalFund

					if equityFund and equityFund ~= "" and equityFund ~= "-" then
						sumEquityFund = sumEquityFund_old - equityFund_old + equityFund
					end
					
					local lossFund4A = 0
					lossFund4Alert = gtZGProductAccountTable[baMapID].LossFund4Alert
					if lossFund4Alert and lossFund4Alert ~= "" and lossFund4Alert ~= "-" then
						lossFund4Alert = sys_format("%.2f",lossFund4Alert);
						sumLossFund4Alert = sumLossFund4Alert_old - lossFund4A_old + lossFund4Alert
						lossFund4A = lossFund4Alert
					else
						sumLossFund4Alert = sumLossFund4Alert_old - lossFund4A_old
					end
					
					local lossFund4C = 0
					lossFund4Close = gtZGProductAccountTable[baMapID].LossFund4Close
					if lossFund4Close and lossFund4Close ~= "" and lossFund4Close ~= "-" then
						lossFund4Close = sys_format("%.2f",lossFund4Close);
						sumLossFund4Close = sumLossFund4Close_old - lossFund4C_old + lossFund4Close
						lossFund4C = lossFund4Close
					else
						sumLossFund4Close = sumLossFund4Close_old - lossFund4C_old
					end
					
					--增加抗跌风险度
					local v=gtZGProductAccountTable[baMapID]
					local MTFund = 0
					if v.SeniorFund and v.SeniorFund~="" then
						MTFund=MTFund+v.SeniorFund
					end
					if v.MezzFund and v.MezzFund~="" then
						MTFund=MTFund+v.MezzFund
					end
					if MTFund~=0 then
						MTFund=sys_format("%.2f",MTFund)
					end

					assetValue=sys_format("%.2f",assetValue)
					local AssetValue4Customer=assetValue-MTFund
					AssetValue4Customer=sys_format("%.2f",AssetValue4Customer)
					local StockValue = 0
					local fund=_PosFundStatus[accountCode]
					for posKey, pos in pairs(_PosPositionTable) do
						if baMapID==pos.BAMapID then
							local quantity=pos.Quantity
							local issueCode=pos.IssueCode
							local marketValue=0
							if fund.Type== "S" then
								local contractSize = 1
								if _PosIssueContractSizeTable[issueCode] then
									contractSize = _PosIssueContractSizeTable[issueCode]
								end
								if _PosPriceTable[issueCode] then
									local lastPrice = _PosPriceTable[issueCode].LastPrice --最新价
									if lastPrice then
										marketValue=lastPrice*quantity*contractSize
									end
								end
							end
							StockValue=StockValue+marketValue
						end
					end
					
					local resistance2Risk = 0
					if StockValue ~= 0 then
						StockValue=sys_format("%.2f",StockValue)
						resistance2Risk = 100*AssetValue4Customer/StockValue
						resistance2Risk=sys_format("%.2f",resistance2Risk)
						sumResistance2Risk = sumResistance2Risk_old - resistance2Risk_old + resistance2Risk
					else
						sumResistance2Risk = sumResistance2Risk_old - resistance2Risk_old
					end	
					
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["accountType"] = accountType
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["lastFund"] = lastFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["lastAssetValue"] = lastAssetValue
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["avlFund"] = avlFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["marketValue"] = marketValue
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["assetValue"] = assetValue
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["orderFund"] = orderFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["ForbidFund"] = ForbidFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["margin"] = margin
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["transferIn"] = transferIn
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["transferOut"] = transferOut
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["fare"] = fare
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["realizedPL"] = realizedPL
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["realizedPLM2D"] = realizedPLM2D
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["valuationPL"] = valuationPL
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["valuationPLM2D"] = valuationPLM2D
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["mtBalance"] = mtBalance
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["equityFund"] = equityFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["beginDate"] = beginDate
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["endDate"] = endDate
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["lossFund4A"] = lossFund4A
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["lossFund4C"] = lossFund4C
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["totalFund"] = totalFund
					gtfundStatusAccountCode_Cache[accountCode_sessionID]["resistance2Risk"] = resistance2Risk
					
					gtfundStatusAllSessionID_Cache[sessionID]["sumAccountType"] = sumAccountType
					gtfundStatusAllSessionID_Cache[sessionID]["sumLastFund"] = sumLastFund
					gtfundStatusAllSessionID_Cache[sessionID]["sumLastAssetValue"] = sumLastAssetValue
					gtfundStatusAllSessionID_Cache[sessionID]["sumAvlFund"] = sumAvlFund
					gtfundStatusAllSessionID_Cache[sessionID]["sumMarketValue"] = sumMarketValue
					gtfundStatusAllSessionID_Cache[sessionID]["sumAssetValue"] = sumAssetValue
					gtfundStatusAllSessionID_Cache[sessionID]["sumOrderFund"] = sumOrderFund
					gtfundStatusAllSessionID_Cache[sessionID]["sumForbidFund"] = sumForbidFund
					gtfundStatusAllSessionID_Cache[sessionID]["sumMargin"] = sumMargin
					gtfundStatusAllSessionID_Cache[sessionID]["sumTransferIn"] = sumTransferIn
					gtfundStatusAllSessionID_Cache[sessionID]["sumTransferOut"] = sumTransferOut
					gtfundStatusAllSessionID_Cache[sessionID]["sumFare"] = sumFare
					gtfundStatusAllSessionID_Cache[sessionID]["sumRealizedPL"] = sumRealizedPL
					gtfundStatusAllSessionID_Cache[sessionID]["sumRealizedPLM2D"] = sumRealizedPLM2D
					gtfundStatusAllSessionID_Cache[sessionID]["sumValuationPL"] = sumValuationPL
					gtfundStatusAllSessionID_Cache[sessionID]["sumValuationPLM2D"] = sumValuationPLM2D
					gtfundStatusAllSessionID_Cache[sessionID]["sumMTBalance"] = sumMTBalance
					gtfundStatusAllSessionID_Cache[sessionID]["sumEquityFund"] = sumEquityFund
					gtfundStatusAllSessionID_Cache[sessionID]["beginDate"] = beginDate
					gtfundStatusAllSessionID_Cache[sessionID]["endDate"] = endDate
					gtfundStatusAllSessionID_Cache[sessionID]["sumLossFund4Alert"] = sumLossFund4Alert
					gtfundStatusAllSessionID_Cache[sessionID]["sumLossFund4Close"] = sumLossFund4Close
					gtfundStatusAllSessionID_Cache[sessionID]["sumInitialFund"] = sumInitialFund
					gtfundStatusAllSessionID_Cache[sessionID]["sumResistance2Risk"] = sumResistance2Risk
					
					local log = sys_format("BaMapOne-UpdateFundInfoAll ======> sessionID[%s],sumAccountType[%s],sumLastFund[%s],sumLastAssetValue[%s],sumAvlFund[%s],sumMarketValue[%s],sumAssetValue[%s],sumOrderFund[%s],sumForbidFund[%s],sumMargin[%s],sumTransferIn[%s],sumTransferOut[%s],sumFare[%s],sumRealizedPL[%s],sumRealizedPLM2D[%s],sumValuationPL[%s],sumValuationPLM2D[%s],sumMTBalance[%s],sumEquityFund[%s],beginDate[%s],endDate[%s],sumLossFund4Alert[%s],sumLossFund4Close[%s],sumInitialFund[%s],sumResistance2Risk[%s]",
					sessionID,sumAccountType,sumLastFund,sumLastAssetValue,sumAvlFund,sumMarketValue,sumAssetValue,sumOrderFund,sumForbidFund,sumMargin,sumTransferIn,sumTransferOut,sumFare,sumRealizedPL,sumRealizedPLM2D,sumValuationPL,sumValuationPLM2D,sumMTBalance,sumEquityFund,beginDate,endDate,sumLossFund4Alert,sumLossFund4Close,sumInitialFund,sumResistance2Risk)
					_WriteAplLog(log)
				end
			end
		end
	end
	if ifSend == "send" then
		local DTSEvent fundStatus = _CreateEventObject("FundInfo")
		fundStatus._SetFld("AccountType",sumAccountType)
		fundStatus._SetFld("LastFund",sumLastFund)
		fundStatus._SetFld("LastAssetValue",sumLastAssetValue)	
		fundStatus._SetFld("OrderFund",sumOrderFund)
		fundStatus._SetFld("ForbidFund",sumForbidFund)	
		fundStatus._SetFld("AvlFund",sumAvlFund)
		fundStatus._SetFld("MarketValue",sumMarketValue)
		fundStatus._SetFld("AssetValue",sumAssetValue)
		fundStatus._SetFld("Margin",sumMargin)
		fundStatus._SetFld("Fare",sumFare)	

		fundStatus._SetFld("RealizedPL",sumRealizedPL)
		fundStatus._SetFld("RealizedPLM2D",sumRealizedPLM2D)
		fundStatus._SetFld("ValuationPL",sumValuationPL)
		fundStatus._SetFld("ValuationPLM2D",sumValuationPLM2D)	
		
		fundStatus._SetFld("TransferIn",sumTransferIn)
		fundStatus._SetFld("TransferOut",sumTransferOut)				
		fundStatus._SetFld("MTBalance",sumMTBalance)
		fundStatus._SetFld("EquityFund",sumEquityFund)
		if gtSessionTable[sessionID].SelectedBAMapID == "全部" then
			fundStatus._SetFld("BeginDate","-")
			fundStatus._SetFld("EndDate","-")
		else
			fundStatus._SetFld("BeginDate",beginDate)
			fundStatus._SetFld("EndDate",endDate)
		end
		if sumLossFund4Alert == 0 then
			sumLossFund4Alert = "-"
		end
		if sumLossFund4Close == 0 then
			sumLossFund4Close = "-"
		end
		fundStatus._SetFld("LossFund4Alert",sumLossFund4Alert)
		fundStatus._SetFld("LossFund4Close",sumLossFund4Close)
		fundStatus._SetFld("InitialFund",sumInitialFund)
		fundStatus._SetFld("Resistance2Risk",sumResistance2Risk)
		_SendEventToClient(fundStatus,sessionID);
	end
end

--禁用买卖权限生效
_OnReceiveUnifieldMessage("BaMapIDRefresh", "BaMapIDRefreshForbid", DTSUnifieldMessage srcMsg)
    _WriteAplLog("Receive message BaMapIDRefreshForbid")
	local baMapIDs = ""
	srcMsg. first()
    while not srcMsg.eof() do --实际只会进来一次
		baMapIDs = srcMsg.getValueByName("BAMapID")
        srcMsg.next()
    end
    srcMsg.clear()
	
	local gtBaMapIDs = {}
	--local currentUser = _GetDealerID()
	_WriteAplLog(baMapIDs)
	local baMapStr = ""
	if baMapIDs ~= "" then
		--[[baMapIDs = sys_format("%s;",baMapIDs)
		while sys_find(baMapIDs,";",1) do
			local n = sys_find(baMapIDs,";",1)
			local baMap = sys_sub(baMapIDs,1,n-1)
			baMapIDs = sys_sub(baMapIDs,n+1,-1)
			if gtPosUserBAMapTable[currentUser] then
				if gtPosUserBAMapTable[currentUser][baMap] then 
					_WriteAplLog(baMap)
					gtBaMapIDs[baMap] = 1
					gtZGProductAccountTable[baMap] = nil
					if baMapStr == "" then
						baMapStr = sys_format("'%s'",baMap)
					else
						baMapStr = sys_format("%s,'%s'",baMapStr,baMap)
					end
				end
			end
		end
		]]
		baMapStr = baMapIDs
		if gtPosUserBAMapTable[gLeaderUserID] then
			if gtPosUserBAMapTable[gLeaderUserID][baMapStr] then 
				local sqlcon = sys_format("select * from dtszgrisk.DTSZGProductAccountTable where DelFlag='0' and BAMapID = '%s';",baMapStr)
				_WriteAplLog(sqlcon)
				_GetCommonData(dataName="DTSZGProductAccountTable", condition=sqlcon, tablename="DynamicSql")
			end
		end
	end
	
_End

--出入金划转生效
_OnReceiveUnifieldMessage("ModityAccount", "BaMapIDRefreshModityAccount", DTSUnifieldMessage srcMsg)
    _WriteAplLog("Receive message BaMapIDRefreshModityAccount")
	local baMapIDs = ""
	srcMsg. first()
    while not srcMsg.eof() do --实际只会进来一次
		baMapIDs = srcMsg.getValueByName("BAMapID")
        srcMsg.next()
    end
    srcMsg.clear()
	
	local gtBaMapIDs = {}
	--local currentUser = _GetDealerID()
	_WriteAplLog(baMapIDs)
	if baMapIDs ~= "" then
		_WriteAplLog(baMapIDs)
		if gtPosUserBAMapTable[gLeaderUserID] then
			if gtPosUserBAMapTable[gLeaderUserID][baMapIDs] then 
				local sqlcon = sys_format("select * from dtszgrisk.DTSZGProductAccountTable where DelFlag='0' and BAMapID = '%s';",baMapIDs)
				_WriteAplLog(sqlcon)
				_GetCommonData(dataName="DTSZGProductAccountTable", condition=sqlcon, tablename="DynamicSql")
			
				for sessionID,v in pairs(gtSessionTable) do 	
					InOutRefreshFund(sessionID)
				end
			end
		end
	end
_End
