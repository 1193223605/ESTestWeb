--@@����������Ϲ���
--@@Version:20131105
_WriteAplLog("����������Ϲ��� Version:2.003 2013-12-05")
date = require('date')
local luasql = require("luasql.mysql");
require "serialize"

------------------
--���ݿ�����߼�--
------------------
local env = assert(luasql.mysql());

local function Close(dataEx)
    dataEx.con:close();
    dataEx.con = nil;
end

local function Commit(dataEx)
    dataEx.con:commit();
end

local function Rollback(dataEx)
    dataEx.con:rollback();
end

local function Insert(dataEx, tablename, tableobject)
    local insertKeys = {};
    local insertValues = {};
    for k, v in pairs(tableobject) do
        insertKeys[#insertKeys + 1] = k;
        insertValues[#insertValues + 1] = "'" .. v .. "'";
    end
    local strSql = string.format("insert into %sTable (%s) values (%s)",
        tablename, table.concat(insertKeys, ","), table.concat(insertValues, ","));
	_WriteAplLog(strSql)
    local res = dataEx.con:execute(strSql);
    Commit(dataEx);
end

local function Modify(dataEx ,condition, tablename, tableobject)
    local updateValues = {}
    for k, v in pairs(tableobject) do
        updateValues[#updateValues + 1] = k .. "= '" .. v .. "'"
    end
    local where = (type(condition) == "string" and #condition > 0 and "where") or "";
    local strSql = string.format("update %sTable set %s %s %s", tablename, table.concat(updateValues, ","), where, condition);
	_WriteAplLog(strSql)
    local res = dataEx.con:execute(strSql);
    Commit(dataEx);
end

local function Delete(dataEx, condition, tablename)
    local where = (type(condition) == "string" and #condition > 0 and "where") or "";
    local strSql = string.format("delete from %sTable %s %s", tablename, where, condition);
	_WriteAplLog(strSql)
    local res = dataEx.con:execute(strSql);
    Commit(dataEx);
end

local function Get(dataEx, condition, tablename)
	local where = (type(condition) == "string" and #condition > 0 and "where") or "";
	local strSql = string.format("select * from %sTable %s %s", tablename, where, condition);
	_WriteAplLog(strSql)
	local cur = dataEx.con:execute(strSql);
	local columns = cur:getcolnames();
	local colTypes = cur:getcoltypes();

    local totype = {};
    local default = {};
    for i,v in ipairs(colTypes) do
        if (string.match(v,"number")) then
            totype[i] = tonumber;
            default[i] = 0;
        else
            totype[i] = function(data)
            	return data
        	end;
            default[i] = "-";
        end
    end

--~ 	row = cur:fetch({}, "n");
--~ 	local result = {}
--~ 	while row do
--~ 		for i,v in pairs (row) do
--~ 			if not result[columns[i]] then result[columns[i]] = {} end
--~ 			table.insert(result[columns[i]],v)
--~ 		end
--~ 		row = cur:fetch(row,"n")
--~ 	end

	row = cur:fetch({}, "a");
	local result = {}
	while row do
		for i,v in pairs (columns) do
			if not result[v] then result[v] = {} end
			table.insert(result[v],row[v] or default[i])
		end
		row = cur:fetch(row,"a")
	end

	return result
end

function Connect(params)
    params = params or {};
    local connectHost = params.IP
    local connectIP = tonumber(params.PORT)
    local connectDB = params.DB
    local connectUser = params.USER
    local connectPwd = params.PWD
    local dataEx = {};
    dataEx.con = assert(env:connect(connectDB, connectUser, connectPwd, connectHost, connectIP));
    dataEx.Close = Close;
    dataEx.Insert = Insert;
    dataEx.Modify = Modify;
    dataEx.Delete = Delete;
    dataEx.Get = Get;
    return dataEx;
end
--------------------
--��Ϲ��������߼�--
--------------------
_glogFlag = "0"		--��־��ʾ��Ϣ��ʾ
_AnalDays = 201		--��ʼ����ǰ��ȡ��������
_CurrentCombin = ""	--��ǰ��ϱ��
gIssueNameList = {}	--��Լ���Ʊ�
gCombinList = {}  --�����Ϣ�б�
gCombinIssueList = {}  --�����ϸ��
gCombinIndustryList = {} --�����ҵ��
gPriceTable = {}  --��Լ�����
gIndustryTable = {} --��ҵ����
gSharesTable = {} --��ͨ����Ϣ��
gCapitalTable = {}  --�ܹɱ���Ϣ��
gIndustrySum = 0	--��ҵ����(������ҵ����)
gIndexWeight = 1	--����300ȫȨ��ֵ(����Ȩ�ظ���)
gKlineindexTable = {time={},close={},Rate={}}		--ָ���۸��
gKlineTable = {}		--��Լ�۸��
gConnect={IP="10.15.118.27",PORT = "3306",DB ="dtsdb",USER = "dtsweb",PWD="dtsweb"} --���ݿ����Ӵ�
function init(arg)  --��ʼ��
	--��ʼ��
	Writelog("init")
	progressBar(0)
	--��ȡ����300���̼�
	local KlineTable = GetKLine("SH000300.index", "1d", nil, nil, -_AnalDays, _AnalDays)

	for i,v in pairs(KlineTable.time) do
		table.insert(gKlineindexTable.time,string.sub(v,1,8))
		table.insert(gKlineindexTable.close,KlineTable.close[i])
		if KlineTable.close[i] and KlineTable.close[i-1] then
			if tonumber(KlineTable.close[i-1]) > 0 then
				gKlineindexTable.Rate[i] = tonumber(KlineTable.close[i])/tonumber(KlineTable.close[i-1]) -1
			else
				gKlineindexTable.Rate[i] = 0
			end
		end
	end
	Writelog(serialize(gKlineindexTable))
	SetPriceHandler("OnPrice")
	StartPrice("SH000300.index","No5Market")
	progressBar(5)
	--��ȡ�û���
	gUSERID = GetDTSUserID()
	Writelog(gUSERID)
	--�������ݿ�
	DB = Connect(gConnect)
	--��ȡ���ݿ��Լ����
	GetIssueName()
	progressBar(8)
	--��ȡ���ݿ��Լ��ͨ������
	--GetShares()
	--��ȡ���ݿ���ҵ����
	GetIndustry()
	progressBar(10)
	Writelog("GetInventory")
	--��ȡ���ݿ��������
	GetInventory()
	Writelog("GetInventory end")
	progressBar(92)
	--���㻦��300��Ȩ����ֵ
	if gCombinIssueList["300ȫ����"] then
		gIndexWeight = 0
		for issue,info in pairs(gCombinIssueList["300ȫ����"])do
			gIndexWeight = gIndexWeight + tonumber(info.Weight)
		end
	end
	--������ϵ�Ȩ�ظ��ǣ���ҵ����
	for combin,v in pairs (gCombinList) do
		CoverEvent(gCombinList[combin],gCombinIssueList[combin])
	end
	progressBar(95)
	--����������ݵ�����ǰ̨
	SendCombinList()		--��������б���Ϣ
	progressBar(98)
	SendIDtoUI()		--����������ϴ������뵽����
	progressBar(100)
end
function progressBar(arg)			--������
	local lt={}
	lt.Bar=arg
	SendToUIScript("SendprogressBar",lt);
end
function Writelog(arg)			--��ʾ��־���
	if _glogFlag == "1" then
		Writelog(arg)
	end
end
function GetCapital(issueCode)	--��ȡ�ܹɱ���Ϣ
	Writelog("GetCapital")
	Writelog(issueCode)
	local Capital = 0
	local obj = toObjID(issueCode)
	local place = string.find(obj, "%.")
	if place then
		local inditype = string.sub(obj,place)
		if inditype == ".stk" then
			if gCapitalTable[issueCode] then
				Capital = gCapitalTable[issueCode]
			else
				Writelog(obj)
				local nowtime = GetDate() .. "000000"
				local temp1 = GetData("dhd",{"TOT_SHR","TOT_FLOAT_SHR"},{obj},{},nil,nil,19900101000000,tonumber(nowtime))
				Writelog(serialize(temp1))
				local temp = temp1.data
				if temp and temp["indi"] and temp["indi"][1] then
					if  temp["indi"][1]["TOT_SHR"] and #temp["indi"][1]["TOT_SHR"] > 0 then
						Capital = temp["indi"][1]["TOT_SHR"][#temp["indi"][1]["TOT_SHR"]]
						if Capital == "nan" or tostring(Capital) == "nan" then
							if #temp["indi"][1]["TOT_SHR"]-1 > 0 then
								local arg = #temp["indi"][1]["TOT_SHR"]-1
								Capital = temp["indi"][1]["TOT_SHR"][arg]
							end
						end
						gCapitalTable[issueCode] = tonumber(Capital)
					end
					if temp["indi"][1]["TOT_FLOAT_SHR"] and #temp["indi"][1]["TOT_FLOAT_SHR"] > 0 then
						local Shares = temp["indi"][1]["TOT_FLOAT_SHR"][#temp["indi"][1]["TOT_FLOAT_SHR"]]
						if Shares == "nan" or tostring(Shares) == "nan" then
							if #temp["indi"][1]["TOT_FLOAT_SHR"]-1 > 0 then
								local arg = #temp["indi"][1]["TOT_FLOAT_SHR"]-1
								Shares = temp["indi"][1]["TOT_FLOAT_SHR"][arg]
							end
						end
						gSharesTable[issueCode] = tonumber(Shares)
					end
				end
			end
		end
	end
	return string.format("%.0f",Capital)
end
function GetissueShares(issueCode)	--��ȡ��ͨ����Ϣ
	Writelog("GetissueShares")
	Writelog(issueCode)
	local Shares = 0
	local obj = toObjID(issueCode)
	local place = string.find(obj, "%.")
	if place then
		local inditype = string.sub(obj,place)
		if inditype == ".stk" then
			if gSharesTable[issueCode] then
				Shares = gSharesTable[issueCode]
			else
				Writelog(obj)
				local nowtime = GetDate() .. "000000"
				local temp1 = GetData("dhd",{"TOT_FLOAT_SHR"},{obj},{},nil,nil,19900101000000,tonumber(nowtime))
				Writelog(serialize(temp1))
				local temp = temp1.data
				if temp and temp["indi"] and temp["indi"][1] then
					if temp["indi"][1]["TOT_FLOAT_SHR"] and #temp["indi"][1]["TOT_FLOAT_SHR"] > 0 then
						Shares = temp["indi"][1]["TOT_FLOAT_SHR"][#temp["indi"][1]["TOT_FLOAT_SHR"]]
						if Shares == "nan" or tostring(Shares) == "nan" then
							if #temp["indi"][1]["TOT_FLOAT_SHR"]-1 > 0 then
								local arg = #temp["indi"][1]["TOT_FLOAT_SHR"]-1
								Shares = temp["indi"][1]["TOT_FLOAT_SHR"][arg]
							end
						end
						gSharesTable[issueCode] = tonumber(Shares)
					end
					if  temp["indi"][1]["TOT_SHR"] and #temp["indi"][1]["TOT_SHR"] > 0 then
						local Capital = temp["indi"][1]["TOT_SHR"][#temp["indi"][1]["TOT_SHR"]]
						if Capital == "nan" or tostring(Capital) == "nan" then
							if #temp["indi"][1]["TOT_SHR"]-1 > 0 then
								local arg = #temp["indi"][1]["TOT_SHR"]-1
								Capital = temp["indi"][1]["TOT_SHR"][arg]
							end
						end
						gCapitalTable[issueCode] = tonumber(Capital)
					end
				end
			end
		end
	end
	return string.format("%.0f",Shares)
end
--[[function GetShares()		--��ȡ��ͨ������
	local temp = Get(DB,"", "IssueMaster")
	if temp then
		for i,v in pairs(temp.IssueCode) do
			gSharesTable[v] = tonumber(temp.Shares[i])
		end
	end
	Writelog(serialize(gSharesTable))
end]]
function GetIndustry()		--��ȡ��ҵ����
	local temp = Get(DB,"SectorCategoryID = '3'", "SectorHeader")
	local temp1 = Get(DB,"SectorCategoryID = '3'", "SectorIssue")
	Writelog(serialize(temp))
	Writelog(serialize(temp1))
	if temp1 and temp then --���������Ϣ�б�
		local arg = {}
		for i,v in pairs(temp.SectorCode) do
			local code = tonumber(v)
			arg[code] = temp.ReserveString[i]

		end
		gIndustrySum = #temp.SectorCode
		for i,v in pairs(temp1.IssueCode) do
			gIndustryTable[v] = arg[tonumber(temp1.SectorCode[i])]
			local temp = toObjID(v)
			StartPrice(temp,"No5Market")
		end
	end
	Writelog(serialize(gIndustryTable))
end
function GetIssueName()		--��ȡ��Լ��������
	Writelog("GetIssueName")
	gIssueNameList = {}
	local IssueMasterlist = Get(DB,"", "IssueMaster")
	if IssueMasterlist then --���������Ϣ�б�
		for i,v in pairs(IssueMasterlist.IssueCode) do
			gIssueNameList[v] = IssueMasterlist.IssueShortLocalName[i] or "-"
		end
	end
end
function GetInventory()		--��ȡ�������
	Writelog("GetInventory")
	gCombinList = {}
	gCombinIssueList = {}
	local InventoryHeaderlist = Get(DB,"", "InventoryHeader")
	local InventoryOrderlist = Get(DB,"", "InventoryOrder")

	Writelog(serialize(InventoryHeaderlist))
	Writelog(serialize(InventoryOrderlist))
	progressBar(12)
	--��ȡ300ȫ�����������
	Writelog("��ȡ300ȫ�����������")
	if InventoryOrderlist then --���������ϸ��
		local tempTable = {}
		local tempTable1= {}
		for i,v in pairs(InventoryOrderlist.InventoryModelID) do
			local issuecode = InventoryOrderlist.IssueCode[i]
			if not tempTable1[issuecode] then
				tempTable1[issuecode] = 1
				local temp = toObjID(issuecode)
				StartPrice(temp,"No5Market")
			end
		end
		local sum = 0
		for issuecode , v in pairs (tempTable1) do
			local obj = toObjID(issuecode)
			local place = string.find(obj, "%.")
			if place then
				local inditype = string.sub(obj,place)
				if inditype == ".stk" then
					sum = sum + 1
					table.insert(tempTable,obj)
					if sum == 30 then
						CapitalShares(tempTable)
						tempTable = {}
						sum = 0
					end
				end
			end
		end

	end
	progressBar(20)
	Writelog("���������Ϣ�б�")
	if InventoryHeaderlist then --���������Ϣ�б�
		for i,v in pairs(InventoryHeaderlist.InventoryModelID) do
			local UserID = InventoryHeaderlist.Owner[i]
			local ReserveString = InventoryHeaderlist.ReserveString[i]
			if gUSERID == UserID or ReserveString == "1" then			--������ϻ��������
				gCombinList[v] = {}
				if InventoryHeaderlist.ModelDescription[i] == "-" then
					gCombinList[v].CombinName = v
				else
					gCombinList[v].CombinName = InventoryHeaderlist.ModelDescription[i]
				end
				gCombinList[v].BaseIndexCode = InventoryHeaderlist.BaseIndexCode[i]
				gCombinList[v].BaseName = gIssueNameList[gCombinList[v].BaseIndexCode]
				local ChangeDate = InventoryHeaderlist.TimeStamp[i]
				if ChangeDate ~= "-" then
					ChangeDate = string.sub(ChangeDate,1,10)
				end
				gCombinList[v].UserID = UserID
				gCombinList[v].ChangeDate = ChangeDate
				gCombinList[v].Number = 0
				gCombinList[v].WeightCover = 0
				gCombinList[v].IndustryCover = 0
				gCombinList[v].ExpValue = 0
				gCombinList[v].AnalDays = 100
				gCombinList[v].BaseDate = gKlineindexTable.time[#gKlineindexTable.time]
				gCombinList[v].BasePrice = gKlineindexTable.close[#gKlineindexTable.time]
				gCombinList[v].LastValue = 0
				gCombinList[v].Price = 0
				gCombinList[v].BaseWeight = 0
				gCombinList[v].Weight = 0
				gCombinList[v].PreQty = "1.000"
				gCombinList[v].PreCast = gCombinList[v].BasePrice * 300
				gCombinList[v].AllCheck = "0"
				gCombinList[v].KeepCheck = "0"
				gCombinList[v].Check1 = "1"
				gCombinList[v].Check2 = "1"
				gCombinList[v].Check3 = "1"

				--���BaseIndexCode Ϊ0 ��ʾΪϵͳ��ϣ�Ϊ1��ʾΪ�Խ���ϡ�ֻ��Ϊ1�Ż���ʾ������б���Ϊ0��ʾ�ں�Լ���С�
				if gCombinList[v].BaseIndexCode == "1" then
					gCombinList[v].BaseIndexCode = "M000300"
					gCombinList[v].BaseName = gIssueNameList["M000300"] or "����300"
				end
				gCombinIssueList[v] = {}
				gCombinIndustryList[v] = {}
			end
		end
	end
	progressBar(22)
	Writelog("���������ϸ��")
	if InventoryOrderlist then --���������ϸ��
		local sum = #InventoryOrderlist.IssueCode
		local tempsum = 0
		for i,v in pairs(InventoryOrderlist.InventoryModelID) do
			tempsum = tempsum + 1
			local issuecode = InventoryOrderlist.IssueCode[i]
			--������ϳɷֹ��б�
			if gCombinIssueList[v] then
				if sum > 0 then
					local Bar = (tempsum/sum) * 70
					Bar = Bar + 22
					Bar = math.ceil(Bar)
					progressBar(Bar)
				end
				--��ȡ��Լ��ʷ�۸��
				--[[if not gKlineTable[issuecode] then
					gKlineTable[issuecode]={time={},close={}}
					local KlineTable = GetKLine(toObjID(issuecode), "1d", nil, nil, -_AnalDays, _AnalDays)
					for i,v in pairs(KlineTable.time) do
						table.insert(gKlineTable[issuecode].time,string.sub(v,1,8))
						table.insert(gKlineTable[issuecode].close,KlineTable.close[i])
					end
				end]]
				if not gCombinIssueList[v][issuecode] then
					gCombinIssueList[v][issuecode] = {}
					gCombinList[v].Number = gCombinList[v].Number + 1
				end
				local temp = gCombinIssueList[v][issuecode]
				temp.Number = tonumber(InventoryOrderlist.InventoryOrderNo[i])
				temp.IssueName = gIssueNameList[issuecode] or "-"
				temp.Qty = math.ceil(InventoryOrderlist.Quantity[i])
				temp.Weight = string.format("%.02f",InventoryOrderlist.GeneralDouble1[i])
				temp.Value = 0
				temp.BaseWeight = string.format("%.02f",InventoryOrderlist.ReserveDouble2[i])
				temp.BaseValue = temp.Qty*getPrice(issuecode,gKlineindexTable.time[#gKlineindexTable.time])
				temp.Industry = gIndustryTable[issuecode] or "-"
				temp.Shares = GetissueShares(issuecode)
				temp.SharesValue = 0
				local ChangeDate = InventoryOrderlist.TimeStamp[i]
				if ChangeDate ~= "-" then
					ChangeDate = string.sub(ChangeDate,1,10)
				end
				temp.ChangeDate = ChangeDate
				temp.Capital = GetCapital(issuecode)

				--ͳ������ڱ��Ȩ�غ�
				gCombinList[v].BaseWeight = gCombinList[v].BaseWeight + temp.BaseWeight
				gCombinList[v].Weight = gCombinList[v].Weight + temp.Weight
				--�����Լ���гɷֹ���������
				--[[if gCombinList[v].BaseIndexCode ~= "M000300" then
					local Price = GetforPrice(issuecode,"lastclose")
					if Price and Price ~= 0 then
					temp.Qty = math.ceil(gKlineindexTable.close[#gKlineindexTable.time]*300*temp.Weight/100/Price)
					end
				end]]
			end
			if gCombinIndustryList[v] then
				local IndustryName = gIndustryTable[issuecode] or "-"
				if not gCombinIndustryList[v][IndustryName] then
					gCombinIndustryList[v][IndustryName] = {CodeNumber=0,Value=0,IndustryWeight=0,IndustryBaseWeight=0,BaseWeight=0,Weight=0,Shares=0,Capital=0}
				end
				local tempTable = gCombinIndustryList[v][IndustryName]
				tempTable.IndustryName = IndustryName
				tempTable.CodeNumber = tempTable.CodeNumber + 1
				tempTable.BaseWeight = tempTable.BaseWeight + gCombinIssueList[v][issuecode].BaseWeight
				tempTable.Weight = tempTable.Weight + gCombinIssueList[v][issuecode].Weight
				tempTable.Capital = tempTable.Capital + gCombinIssueList[v][issuecode].Capital
			end
		end
	end

end
function CapitalShares(tempTable)			--���ܻ�ȡ��ͨ�ɺ��ܹɱ�����
	Writelog("CapitalShares")
	Writelog(serialize(tempTable))
	local nowtime = GetDate() .. "000000"
	local temp1 = GetData("dhd",{"TOT_SHR","TOT_FLOAT_SHR"},tempTable,{},nil,nil,19901101000000,tonumber(nowtime))
	Writelog(serialize(temp1))
	local temp = temp1.data
	if temp and temp["indi"] then
		for i,info in pairs (temp["indi"]) do
			local IssueCode = ObjID2IssueCode(temp["obj"][i])
			local Capital = 0
			local Shares = 0
			if #info["TOT_SHR"] > 0 then
				Capital = info["TOT_SHR"][#info["TOT_SHR"]]
			end
			if #info["TOT_FLOAT_SHR"] > 0 then
				Shares = info["TOT_FLOAT_SHR"][#info["TOT_FLOAT_SHR"]]
			end
			Writelog(IssueCode)
			Writelog(Capital)
			Writelog(Shares)
			if Capital == "nan" or tostring(Capital) == "nan" then
				if #info["TOT_SHR"]-1 > 0 then
					local arg = #info["TOT_SHR"]-1
					Capital = info["TOT_SHR"][arg]
				end
			end
			if Shares == "nan" or tostring(Shares) == "nan" then
				if #info["TOT_FLOAT_SHR"]-1 > 0 then
					local arg = #info["TOT_FLOAT_SHR"]-1
					Shares = info["TOT_FLOAT_SHR"][arg]
				end
			end
			Writelog(Capital)
			Writelog(Shares)
			gCapitalTable[IssueCode] = tonumber(Capital)
			gSharesTable[IssueCode] = tonumber(Shares)
		end
	end
end
function GetforPrice(issuecode,Type)		--��ȡ����
	local Price = 0
	if gPriceTable[issuecode] then
		Price = gPriceTable[issuecode][Type]
	else
		Price = GetPrice(issuecode)[Type]
		local temp = toObjID(issuecode)
		StartPrice(temp,"No5Market")
	end
	return Price
end
function SendIDtoUI()			--����������ϴ�����Ϣ
	Writelog("SendIDtoUI")
	local lt={}
	lt.CombinCode=creatID()
	SendToUIScript("SendIDtoUI",lt);
end
function SendCombinList()		--��������б���Ϣ
	Writelog("SendCombinList")
	local tempnumber = 1
	local Table={Number={},CombinCode={},CombinName={},CodeNumber={},WeightCover={},IndustryCover={},PreQty={},ExpValue={},CC={},Warp={},
	Beta={},Alpha={},BasePrice={},Fit={},FitValue={},LastValue={},BaseDate={},AnalDays={},BaseIndexCode={},ChangeDate={},UserID={}}
	for combinCode,info in pairs(gCombinList) do
		if info.BaseIndexCode == "M000300" then		--ֻ�������BaseIndexCode �Ż���ʾ
			info.No = tempnumber
			table.insert(Table.Number,info.No)
			table.insert(Table.CombinCode,combinCode)
			table.insert(Table.CombinName,info.CombinName)
			table.insert(Table.CodeNumber,gCombinList[combinCode].Number)
			table.insert(Table.WeightCover,info.WeightCover or "")
			table.insert(Table.IndustryCover,info.IndustryCover or "")
			table.insert(Table.PreQty,info.PreQty or "")
			table.insert(Table.UserID,info.UserID or "")

			table.insert(Table.ExpValue,info.ExpValue or "")
			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")
			table.insert(Table.BasePrice,info.BasePrice or "")
			table.insert(Table.Fit,info.Fit or "")

			table.insert(Table.FitValue,info.FitValue or "")
			table.insert(Table.LastValue,info.Price or "")
			table.insert(Table.BaseDate,info.BaseDate or "")
			table.insert(Table.AnalDays,info.AnalDays or "")
			table.insert(Table.BaseIndexCode,info.BaseIndexCode or "")
			table.insert(Table.ChangeDate,info.ChangeDate or "")
			tempnumber = tempnumber + 1
		end
	end
	SendToUI("CombinTable",Table)
end


function SendIssueList()		--����ȫ����������Ϣ
	Writelog("SendIssueList")
	if gCombinIssueList[_CurrentCombin] then
		local templist = gCombinIssueList[_CurrentCombin]
		local Table={Number={},IssueCode={},IssueName={},Qty={},Price={},Status={}, Value={},Weight={},BaseWeight={},Industry={},CC={},
			Warp={},Beta={},Alpha={},Shares={},Capital={}}
		for issue,info in pairs(templist) do
			table.insert(Table.Number,info.Number)
			table.insert(Table.IssueCode,issue)
			table.insert(Table.IssueName,info.IssueName or "")
			table.insert(Table.Qty,info.Qty or "")
			local tempPrice = 0
			local tempStatus = ""
			if gPriceTable[issue] then
				tempPrice = gPriceTable[issue].new or 0
				tempStatus = gPriceTable[issue].Status or ""
			end
			table.insert(Table.Price,tempPrice)

			table.insert(Table.Status,tempStatus)
			table.insert(Table.Value,string.format("%.02f",tempPrice*info.Qty))

			table.insert(Table.Weight,info.Weight or "")
			table.insert(Table.BaseWeight,info.BaseWeight or "")
			table.insert(Table.Industry,info.Industry or "")
			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")

			table.insert(Table.Shares,info.Shares or "")
			table.insert(Table.Capital,info.Capital or "")
		end
		SendToUI("CombinIssueEvent",Table)
	end
end
function SendIndustryList()		--������ҵ������Ϣ

	Writelog("SendIndustryList")
	if gCombinIndustryList[_CurrentCombin] then
		local templist = gCombinIndustryList[_CurrentCombin]
		Writelog(serialize(templist))
		local Table={Number={},Industry={},CodeNumber={},Value={},IndustryWeight={},BaseWeight={},CC={},Warp={},Beta={},Alpha={},
			Shares={},Capital={}}
			local Number = 0
		for Industry,info in pairs(templist) do
			Number = Number + 1
			table.insert(Table.Number,Number)
			table.insert(Table.Industry,Industry)
			table.insert(Table.CodeNumber,info.CodeNumber)
			table.insert(Table.Value,info.Value or "")
			table.insert(Table.IndustryWeight,info.IndustryWeight or "")

			table.insert(Table.BaseWeight,info.IndustryBaseWeight or "")

			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")
			table.insert(Table.Shares,info.Shares or "")
			table.insert(Table.Capital,info.Capital or "")
		end
		SendToUI("SectorTable",Table)
	end
end
function SendCurrentCombinList(CombinCode)	--��������б���Ϣ
	Writelog("SendCurrentCombinList")
	if gCombinList[CombinCode] then
		local info = gCombinList[CombinCode]
		local Table={Number={},CombinCode={},CombinName={},CodeNumber={},WeightCover={},IndustryCover={},PreQty={},ExpValue={},CC={},Warp={},
		Beta={},Alpha={},BasePrice={},Fit={},FitValue={},LastValue={},BaseDate={},AnalDays={},BaseIndexCode={},ChangeDate={},UserID={}}
		if info.BaseIndexCode == "M000300" then		--ֻ�������BaseIndexCode �Ż���ʾ
			table.insert(Table.Number,info.No)
			table.insert(Table.CombinCode,CombinCode)
			table.insert(Table.CombinName,info.CombinName)
			table.insert(Table.CodeNumber,info.Number)
			table.insert(Table.WeightCover,info.WeightCover or "")
			table.insert(Table.IndustryCover,info.IndustryCover or "")
			table.insert(Table.PreQty,info.PreQty or "")
			table.insert(Table.UserID,info.UserID or "")
			table.insert(Table.ExpValue,info.ExpValue or "")
			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")
			table.insert(Table.BasePrice,info.BasePrice or "")
			table.insert(Table.Fit,info.Fit or "")

			table.insert(Table.FitValue,info.FitValue or "")
			table.insert(Table.LastValue,info.Price or "")
			table.insert(Table.BaseDate,info.BaseDate or "")
			table.insert(Table.AnalDays,info.AnalDays or "")
			table.insert(Table.BaseIndexCode,info.BaseIndexCode or "")
			table.insert(Table.ChangeDate,info.ChangeDate or "")
			SendToUI("CombinTable",Table)
		end
	end
end
function SendCurrentIndustry(CombinCode)		--���µ�ǰ�����ҵ��Ϣ
	Writelog("SendCurrentIndustry")
	if gCombinIndustryList[CombinCode] then
		local Table={Number={},Industry={},CodeNumber={},Value={},IndustryWeight={},BaseWeight={},CC={},Warp={},Beta={},Alpha={},
		Shares={},Capital={}}
		local Number = 0
		for Industry,info in pairs(gCombinIndustryList[CombinCode]) do
			Number = Number + 1
			table.insert(Table.Number,Number)
			table.insert(Table.Industry,info.IndustryName)
			table.insert(Table.CodeNumber,info.CodeNumber)
			table.insert(Table.Value,string.format("%.02f",info.Value))
			table.insert(Table.IndustryWeight,info.IndustryWeight or "")

			table.insert(Table.BaseWeight,info.IndustryBaseWeight or "")

			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")
			table.insert(Table.Shares,string.format("%.02f",info.Shares))
			table.insert(Table.Capital,info.Capital or "")
		end
		SendToUI("SectorTable",Table)
	end
end

function SendCurrentIssue(PriceTable)		--������������Ϣ
	Writelog("SendCurrentIssue")
	local info = gCombinIssueList[_CurrentCombin][PriceTable.IssueCode]
	local Table={Number={},IssueCode={},IssueName={},Qty={},Price={},Status={}, Value={},Weight={},BaseWeight={},Industry={},CC={},
		Warp={},Beta={},Alpha={},Shares={},Capital={}}
	table.insert(Table.Number,info.Number)
	table.insert(Table.IssueCode,PriceTable.IssueCode)
	table.insert(Table.IssueName,info.IssueName or "")
	table.insert(Table.Qty,info.Qty or "")
	table.insert(Table.Price,PriceTable.new)
	table.insert(Table.Status,PriceTable.Status)
	table.insert(Table.Value,string.format("%.02f",PriceTable.new*info.Qty))

	table.insert(Table.Weight,info.Weight or "")
	table.insert(Table.BaseWeight,info.BaseWeight or "")
	table.insert(Table.Industry,info.Industry or "")
	table.insert(Table.CC,info.CC or "")
	table.insert(Table.Warp,info.Warp or "")
	table.insert(Table.Beta,info.Beta or "")
	table.insert(Table.Alpha,info.Alpha or "")

	table.insert(Table.Shares,info.Shares or "")
	table.insert(Table.Capital,info.Capital or "")
	SendToUI("CombinIssueEvent",Table)
end
function ClickCombinTable(arg)			--˫������б�
	Writelog("ClickCombinTable")
	local CombinCode = arg.CombinCode
	Writelog(CombinCode)
	--��ǰ��ϲ����ڴ������
	--[[if _CurrentCombin ~= "" and gCombinIssueList[_CurrentCombin] then
		--ɾ��֮ǰ��ϳɷֹ�����.
		Writelog("delect")
		local templist = gCombinIssueList[_CurrentCombin]
		for issue,info in pairs(templist) do
			local temp = toObjID(issue)
			StopPrice(temp)
		end
	end]]
	--���µ�ǰ���
	_CurrentCombin = CombinCode
	--ע�ᵱǰ��ϳɷֹ����顣
	--Writelog("add")
	--[[for issue,info in pairs(gCombinIssueList[_CurrentCombin]) do
		local temp = toObjID(issue)
		StartPrice(temp,"No5Market")
	end]]
	--������������Ϣ
	SendCombinEvent(_CurrentCombin)
	--���͵�ǰ����б�
	SendCombinList()
	--���͵�ǰ�����ϸ����ʾ
	SendIssueList()
	--������ҵ��Ϣ��
	SendIndustryList()
end
function DelectCombin(arg)		--ɾ����ϰ�ť
	Writelog("DelectCombin")
	local CombinCode= arg.CombinCode
	if gCombinList[CombinCode] then
		local condition = string.format("InventoryModelID = '%s'",CombinCode)
		Delete(DB, condition, "InventoryHeader")
		condition = string.format("InventoryModelID = '%s'",CombinCode)
		Delete(DB, condition, "InventoryOrder")
		gCombinList[CombinCode] = nil
		gCombinIssueList[CombinCode] = nil
	end
	SendCombinList()		--��������б���Ϣ
end
function creatID()--������ϱ�����Ϣ
	local strDate = os.date("%Y%m%d", os.time())
	local portID = ""
	local SubmitNo = 1; --�µ����кţ�Ϊ�˱�֤ÿ��CombinCode��Ψһ
	local strSubmitNo = string.format("%03d",SubmitNo); --��ʽ����3λ
	portID = string.format("%s%s%s",gUSERID,strDate,strSubmitNo);
	while findID(portID) do
		SubmitNo = SubmitNo + 1;
		strSubmitNo = string.format("%03d",SubmitNo);
		portID = string.format("%s%s%s",gUSERID,strDate,strSubmitNo);
	end
	local log = "createportID by the function of creatIDtodisposition:"..portID
	Writelog(log);
	return portID;
end
function findID(portID)  --�ҵ�������ϱ��
	for CombinCode, info in pairs(gCombinList) do
		if portID == CombinCode then
			return true
		end
	end
	return false
end

function OnPrice(objID,lt)	--����ص�
	local IssueCode = ObjID2IssueCode(objID)
	if not gPriceTable[IssueCode] then gPriceTable[IssueCode] = {} end
	local tempTable = gPriceTable[IssueCode]
	local status = OnstateJudge(objID,lt)
	tempTable.IssueCode = IssueCode
	tempTable.new = lt.new or 0
	tempTable.lastclose = lt.lastclose or 0
	tempTable.Status = status
	if IssueCode == "M000300" and gCombinIssueList[_CurrentCombin] then
		SendCombinEvent(_CurrentCombin)		--�������ʵʱˢ����Ϣ
		SendCurrentIndustry(_CurrentCombin)		--ˢ����ҵʵʱ��Ϣ
	end
	if gCombinIssueList[_CurrentCombin] and gCombinIssueList[_CurrentCombin][IssueCode] then
		SendCurrentIssue(tempTable)				--ˢ�º�Լʵʱ��Ϣ
	end
end
function SendCombinEvent(CombinCode)		-- �������ʵʱˢ����Ϣ
	Writelog("SendCombinEvent")
	--�������������ֵ
	local Value = 0
	local BaseValue = 0
	for issue, info in pairs(gCombinIssueList[CombinCode]) do
		if gPriceTable[issue] then
			local LastPrice = gPriceTable[issue].new or 0
			info.Value = info.Qty * LastPrice				--��Լ��ֵ
			info.SharesValue = info.Shares * LastPrice		--��Լ��ͨ����ֵ
			Value = Value + info.Value						--�����ֵ
			BaseValue = BaseValue + info.BaseValue			--��ϻ�׼��ֵ
		end

	end
	--���������ֵ
	gCombinList[CombinCode].LastValue = string.format("%.02f",Value)
	--��������ּ�
	if tonumber(BaseValue) > 0 then
	gCombinList[CombinCode].Price = string.format("%.02f",gCombinList[CombinCode].BasePrice * (Value/BaseValue))
	else
	gCombinList[CombinCode].Price = "0.00"
	end
	--����������³���ֵ
	gCombinList[CombinCode].ExpValue = ExpValueEvent(gCombinList[CombinCode])

	--���������϶�
	local temp = CalculateFit(CombinCode)

	gCombinList[CombinCode].Fit = string.format("%.02f",temp.Fit)
	gCombinList[CombinCode].FitValue = string.format("%.02f",temp.FitValue)

	--���������ҵ��ֵ����ͨ����ֵ
	SetIndustryValue(CombinCode)

	if _CurrentCombin == CombinCode then
		local lt={}
		lt.Value=gCombinList[CombinCode].LastValue
		lt.ExpValue = gCombinList[CombinCode].ExpValue
		lt.Fit = gCombinList[CombinCode].Fit
		SendToUIScript("SendCombinEvent",lt)
		SendCurrentCombinList(CombinCode)
	end
end
function SetIndustryValue(CombinCode)		--���������ҵ��ֵ
	Writelog("SetIndustryValue")
	--��϶�Ӧ��ҵ������ֵ
	for IndustryName,v in pairs (gCombinIndustryList[CombinCode]) do
		gCombinIndustryList[CombinCode][IndustryName].Value = 0
		gCombinIndustryList[CombinCode][IndustryName].Shares = 0
	end
	for issue, info in pairs(gCombinIssueList[CombinCode]) do
		local IndustryName = gIndustryTable[issue] or "-"
		if gCombinIndustryList[CombinCode][IndustryName] then
			local IndustryList = gCombinIndustryList[CombinCode][IndustryName]
			IndustryList.Value = IndustryList.Value + gCombinIssueList[CombinCode][issue].Value
			IndustryList.Shares = IndustryList.Shares + gCombinIssueList[CombinCode][issue].SharesValue
		end
	end
end
function OnstateJudge(issueCode,lt)--��Ʊ״̬�ж�
	local askQty1 = lt.sellvolume1 or 0;
	local askQty2 = lt.sellvolume2 or 0;
	local askQty3 = lt.sellvolume3 or 0;
	local askQty4 = lt.sellvolume4 or 0;
	local askQty5 = lt.sellvolume5 or 0;
	local bidQty1 = lt.buyvolume1 or 0;
	local bidQty2 = lt.buyvolume2 or 0;
	local bidQty3 = lt.buyvolume3 or 0;
	local bidQty4 = lt.buyvolume4 or 0;
	local bidQty5 = lt.buyvolume5 or 0;

	--local gLogs = string.format("issueCode:%s stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
	--Writelog(gLogs); -- for not normal only.

	if (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
		--gLogs = sys_format("issueCode:%s SP stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
		--writeLog(gLogs);
		return "ͣ��";	--SusPend ͣ��
	elseif (askQty1 > 0 or askQty2 > 0 or askQty3 > 0 or askQty4 > 0 or askQty5 > 0) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
		--gLogs = sys_format("issueCode:%s DL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
		--writeLog(gLogs);
		return "��ͣ";	--Decline Limit ��ͣ
	elseif (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 > 0 or bidQty2 > 0 or bidQty3 > 0 or bidQty4 > 0 or bidQty5 > 0) then
		--gLogs = sys_format("issueCode:%s SL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
		--writeLog(gLogs);
		return "��ͣ";	--Surged Limit ��ͣ
	else
		return "����";	--NorMal ����
	end
end

----------------
--�½�����߼�--
----------------
gCurrentList = {IndustryName={},IndustryCode={}}		--��ǰ�����Ϣ��
gCurrentIssueList = {}			--��ǰ�����ϸ��
gBeiXuanCombinCode = ""			--��ǰ��ѡ��Ϻ�
function IndustryInit(arg)		--��ϳ�ʼ��
	Writelog("IndustryInit")
	gCurrentList = {IndustryName={},IndustryCode={}}
	gCurrentIssueList = {}
	--���ͺ�Լ��
	--local tempTable = {CombinCode={},CombinName={},IndustryName={},BaseIndexCode={},BaseName={},AnalDays={},LastValue={},PreQty={},
	--PreCast={},BaseDate={},BasePrice={},AllCheck={},KeepCheck={},Check1={},Check2={},Check3={}}
	local combincode = arg.CombinCode
	for i,info in pairs(gCombinList)do
		if info.BaseIndexCode ~= "M000300" then	--Ϊ0��ʾ���Ϊ��Լ�����
			table.insert(gCurrentList.IndustryName,info.CombinName)
			table.insert(gCurrentList.IndustryCode,i)
		end
	end
	if gCombinList[combincode] then
		--��ǰ����Ѵ���
		local tempList = gCombinList[combincode]
		gCurrentList.CombinCode = combincode
		gCurrentList.CombinName = tempList.CombinName
		gCurrentList.Number = tempList.Number
		gCurrentList.WeightCover = tempList.WeightCover
		gCurrentList.IndustryCover = tempList.IndustryCover
		gCurrentList.ExpValue = tempList.ExpValue
		gCurrentList.BaseIndexCode = tempList.BaseIndexCode
		gCurrentList.BaseName = tempList.BaseName
		gCurrentList.AnalDays = tempList.AnalDays
		gCurrentList.BaseDate = tempList.BaseDate
		gCurrentList.BasePrice = tempList.BasePrice
		gCurrentList.Price = tempList.Price
		gCurrentList.LastValue = tempList.LastValue
		gCurrentList.PreQty = tempList.PreQty
		gCurrentList.PreCast = tempList.PreCast
		gCurrentList.AllCheck = tempList.AllCheck
		gCurrentList.KeepCheck = tempList.KeepChec
		gCurrentList.Check1 = tempList.Check1
		gCurrentList.Check2 = tempList.Check2
		gCurrentList.Check3 = tempList.Check3
		gCurrentList.UserID = tempList.UserID

		for issue,info in pairs  (gCombinIssueList[combincode]) do
			gCurrentIssueList[issue] = {}
			gCurrentIssueList[issue].IsCheck = "0"
			gCurrentIssueList[issue].IssueCode = issue
			gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
			gCurrentIssueList[issue].Number = info.Number
			gCurrentIssueList[issue].Qty = info.Qty
			gCurrentIssueList[issue].Weight = info.Weight
			gCurrentIssueList[issue].BaseWeight = GetBaseWeight(issue) or info.BaseWeight
			if gPriceTable[issue] then
				gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
				gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
				gCurrentIssueList[issue].Status = gPriceTable[issue].Status
			else
				gCurrentIssueList[issue].LastPrice = GetPrice(issue).new
				gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose
				gCurrentIssueList[issue].Status = "-"
				local temp = toObjID(issue)
				StartPrice(temp,"No5Market")
			end
			gCurrentIssueList[issue].Industry = info.Industry
			gCurrentIssueList[issue].Shares = info.Shares
			gCurrentIssueList[issue].Capital = info.Capital
		end
		sendCrrentIssue("all")
	else
		--�����
		gCurrentList.CombinCode = combincode
		gCurrentList.CombinName = combincode
		gCurrentList.Number = 0
		gCurrentList.WeightCover = 0
		gCurrentList.IndustryCover = 0
		gCurrentList.ExpValue = 0
		gCurrentList.BaseIndexCode = "M000300"
		gCurrentList.BaseName = "����300"
		gCurrentList.AnalDays = "100"
		gCurrentList.BaseDate = gKlineindexTable.time[#gKlineindexTable.time]
		gCurrentList.BasePrice = gKlineindexTable.close[#gKlineindexTable.time]
		gCurrentList.Price = 0
		gCurrentList.LastValue = 0
		gCurrentList.PreQty = 1
		gCurrentList.PreCast = gKlineindexTable.close[#gKlineindexTable.time] * 300
		gCurrentList.AllCheck = "0"
		gCurrentList.KeepCheck ="0"
		gCurrentList.Check1 = "1"
		gCurrentList.Check2 = "1"
		gCurrentList.Check3 = "1"
		gCurrentList.UserID = gUSERID
	end

	gCurrentList.levelCheck = "0"
	SendToUIScript("SetAll",gCurrentList);
	SendInformation()
	--���ͻ�׼��Լ�۸��
	--[[local KlineTable = GetKLine("SH000300.index", "1d", nil, nil, -100, 100)
	tempTable = {time={},close={}}
	for i,v in pairs(KlineTable.time) do
		table.insert(tempTable.time,v)
		table.insert(tempTable.close,KlineTable.close[i])
	end
	SendToUIScript("KlineindexOut",tempTable);]]

	--����Ĭ�Ϻ�Լ��[����300]
	--local arg= {CombinCode = "300ȫ����"}
	--OnSelectIndustryList(arg)
end

function OnSelectIndustryList(arg)		--��Լ��ѡ���߼�
	Writelog("OnSelectIndustryList")
	gBeiXuanCombinCode = arg.CombinCode
	local templist = {IssueCode={},Number={},IssueName={},Weight={},Industry={},Qty={}}
	if gCombinIssueList[gBeiXuanCombinCode] then
		for issue,info in pairs (gCombinIssueList[gBeiXuanCombinCode]) do
			if gCurrentList.levelCheck == "1" then
				if tonumber(info.Weight) > tonumber(gCurrentList.level) then
					table.insert(templist.IssueCode,issue)
					table.insert(templist.Number,info.Number)
					table.insert(templist.IssueName,gIssueNameList[issue])
					table.insert(templist.Weight,info.Weight)
					if gPriceTable[issue] and info.Qty == 0 then
						local Price = gPriceTable[issue].lastclose
						if Price and Price ~= 0 then
						info.Qty = math.ceil(gKlineindexTable.close[#gKlineindexTable.time]*300*info.Weight/100/Price)
						end
					end
					table.insert(templist.Qty,info.Qty)
					table.insert(templist.Industry,info.Industry or "")
				end
			else
				table.insert(templist.IssueCode,issue)
				table.insert(templist.Number,info.Number)
				table.insert(templist.IssueName,gIssueNameList[issue])
				table.insert(templist.Weight,info.Weight)
				if gPriceTable[issue] and info.Qty == 0 then
					local Price = gPriceTable[issue].lastclose
					if Price and Price ~= 0 then
					info.Qty = math.ceil(gKlineindexTable.close[#gKlineindexTable.time]*300*info.Weight/100/Price)
					end
				end
				table.insert(templist.Qty,info.Qty)
				table.insert(templist.Industry,info.Industry or "")
			end
		end
	end
	Writelog(serialize(templist))
	SendToUIScript("IndustryIssueList",templist);
end
function GetBaseWeight(issue)	--��ȡ300ȫ���Ʊ��Ȩ��
	local Weight = nil
	if gCombinIssueList["300ȫ����"] and gCombinIssueList["300ȫ����"][issue] then
		Weight = gCombinIssueList["300ȫ����"][issue].Weight
	end
	return Weight
end
function TimeChange(arg)		--��׼���ڱ仯
	Writelog("TimeChange")
	gCurrentList.BaseDate = arg.BaseDate
	for i,v in pairs(gKlineindexTable.time) do
		if v == arg.BaseDate then
			gCurrentList.BasePrice = gKlineindexTable.close[i]
		end
	end
	SendToUIScript("TimeChangeOut",gCurrentList);
end
function CreateNumber()			--�ұ��
	local temp = 1
	while fundnumber(temp) do
		temp = temp + 1;
	end
	return temp
end
function fundnumber(temp)		--�ұ��
	for issue,info in pairs (gCurrentIssueList) do
		if temp == info.Number then
			return true
		end
	end
	return false
end
function AddIssueCode(arg)		--���Ӻ�Լ
	Writelog("AddIssueCode")
	local issue = arg.IssueCode
	if not gCurrentIssueList[issue] then
		gCurrentIssueList[issue] = {}
		gCurrentIssueList[issue].IsCheck = "0"
		gCurrentIssueList[issue].IssueCode = issue
		gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
		gCurrentIssueList[issue].Number = CreateNumber()
		gCurrentIssueList[issue].Qty = arg.Qty
		gCurrentIssueList[issue].Weight = arg.Weight
		gCurrentIssueList[issue].BaseWeight = arg.Weight
		if gPriceTable[issue] then
			gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
			gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
			gCurrentIssueList[issue].Status = gPriceTable[issue].Status
		else
			gCurrentIssueList[issue].LastPrice = GetPrice(issue).new
			gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose
			gCurrentIssueList[issue].Status = ""
			local temp = toObjID(issue)
			StartPrice(temp,"No5Market")
		end
		gCurrentIssueList[issue].Industry = gIndustryTable[issue] or "-"
		gCurrentIssueList[issue].Shares = GetissueShares(issue)
		gCurrentIssueList[issue].Capital = GetCapital(issue)
		gCurrentList.Number = gCurrentList.Number + 1
	end
	sendCrrentIssue(issue)
end
function AllAdd(arg)			--ȫ������
	for issue,info in pairs (gCombinIssueList[gBeiXuanCombinCode]) do
		if not gCurrentIssueList[issue] then
			gCurrentIssueList[issue] = {}
			gCurrentIssueList[issue].IsCheck = "0"
			gCurrentIssueList[issue].IssueCode = issue
			gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
			gCurrentIssueList[issue].Number = CreateNumber()
			gCurrentIssueList[issue].Qty = info.Qty
			gCurrentIssueList[issue].Weight = info.Weight
			gCurrentIssueList[issue].BaseWeight = info.Weight
			if gPriceTable[issue] then
				gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
				gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
				gCurrentIssueList[issue].Status = gPriceTable[issue].Status
			else
				gCurrentIssueList[issue].LastPrice = GetPrice(issue).new
				gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose
				gCurrentIssueList[issue].Status = ""
				local temp = toObjID(issue)
				StartPrice(temp,"No5Market")
			end
			gCurrentIssueList[issue].Industry = info.Industry
			gCurrentIssueList[issue].Shares = GetissueShares(issue)
			gCurrentIssueList[issue].Capital = GetCapital(issue)
			gCurrentList.Number = gCurrentList.Number + 1
		end
	end
	sendCrrentIssue("all")
end
function DelectIssue(arg)		--ɾ����Լ
	Writelog("DelectIssue")
	local tempcode = arg.IssueCode
	if gCurrentIssueList[tempcode] then
		gCurrentIssueList[tempcode] = nil
		gCurrentList.Number = gCurrentList.Number - 1
	end
end
function DelectAll(arg)			--ȫ��ɾ��
	Writelog("DelectAll")
	gCurrentIssueList = {}
	gCurrentList.Number = 0
end
function sendCrrentIssue(issue)	--���ͺ�Լ��Ϣ����ϱ�
	Writelog("sendCrrentIssue")
	local templist = {IssueCode={},Number={},IssueName={},Status={},Shares={},Weight={},Qty={},BaseWeight={},IsCheck={},Industry={}}
	if issue ~= "all" then
		local info = gCurrentIssueList[issue]
		table.insert(templist.IssueCode,info.IssueCode)
		table.insert(templist.Number,info.Number)
		table.insert(templist.IssueName,info.IssueName)
		table.insert(templist.Weight,info.Weight)
		table.insert(templist.Qty,info.Qty)
		table.insert(templist.Status,info.Status)
		table.insert(templist.Shares,info.Shares)
		table.insert(templist.IsCheck,info.IsCheck)
		table.insert(templist.Industry,info.Industry)
		if tonumber(info.BaseWeight) == 0 then
		table.insert(templist.BaseWeight,"")
		else
		table.insert(templist.BaseWeight,info.BaseWeight)
		end
	else
		for issuecode,info in pairs(gCurrentIssueList)do
			table.insert(templist.IssueCode,info.IssueCode)
			table.insert(templist.Number,info.Number)
			table.insert(templist.IssueName,info.IssueName)
			table.insert(templist.Weight,info.Weight)
			table.insert(templist.Qty,info.Qty)
			table.insert(templist.Status,info.Status)
			table.insert(templist.Shares,info.Shares)
			table.insert(templist.IsCheck,info.IsCheck)
			table.insert(templist.Industry,info.Industry)
			if tonumber(info.BaseWeight) == 0 then
			table.insert(templist.BaseWeight,"")
			else
			table.insert(templist.BaseWeight,info.BaseWeight)
			end
		end
	end
	Writelog(serialize(templist))
	SendToUIScript("CurrentIssueList",templist);
end
function ChangeIssueSet(arg)	--�޸ĺ�Լ����
	Writelog("ChangeIssueSet")
	Writelog(arg.IssueCode)
	Writelog(arg.Qty)
	Writelog(arg.Weight)
	if gCurrentIssueList[arg.IssueCode] then
		gCurrentIssueList[arg.IssueCode].Qty = arg.Qty
		gCurrentIssueList[arg.IssueCode].Weight = arg.Weight
		gCurrentIssueList[arg.IssueCode].IsCheck = "1"
		sendCrrentIssue(arg.IssueCode)
	end
end

function InputCheckEvent(arg)	--��ѡ����
	Writelog("InputCheckEvent")
	Writelog(arg.IssueCode)
	Writelog(arg.IsCheck)
	if arg.IsCheck == "1" then
		gCurrentIssueList[arg.IssueCode].IsCheck = "1"
	else
		gCurrentIssueList[arg.IssueCode].IsCheck = "0"
	end
	sendCrrentIssue(arg.IssueCode)
end

function InputAllCheck(arg)		--ȫ����ѡ
	Writelog("InputAllCheck")
	Writelog(arg.AllCheck)
	if arg.AllCheck == "True" then
		for i ,info in pairs(gCurrentIssueList) do
			info.IsCheck = "1"
		end
	else
		for i ,info in pairs(gCurrentIssueList) do
			info.IsCheck = "0"
		end
	end
	sendCrrentIssue("all")
end
function levelCheckEvent(arg)	--Ȩ������
	Writelog("levelCheckEvent")
	Writelog(arg.levelCheck)
	Writelog(arg.level)
	gCurrentList.levelCheck = arg.levelCheck
	gCurrentList.level = arg.level
	local lt = {}
	lt.CombinCode = gBeiXuanCombinCode
	OnSelectIndustryList(lt)
end

function DoEvent(arg)			--���㰴ť
	Writelog("DoEvent")
	Writelog(arg.PreCast)
	Writelog(arg.PreQty)
	Writelog(arg.PreQtyCheck)
	Writelog(arg.AnalDays)
	Writelog(arg.PreCheck)
	Writelog(arg.QtyCheck)
	Writelog(arg.KeepCheck)
	if arg.PreCheck == "True" then
		gCurrentList.Check3 = "1"
	else
		gCurrentList.Check3 = "0"
	end
	if arg.PreQtyCheck == "True" then
		gCurrentList.Check2 = "1"
	else
		gCurrentList.Check2 = "0"
	end
	if arg.QtyCheck == "True" then
		gCurrentList.Check1 = "1"
	else
		gCurrentList.Check1 = "0"
	end
	if arg.KeepCheck == "True" then
		gCurrentList.KeepCheck = "1"
	else
		gCurrentList.KeepCheck = "0"
	end
	gCurrentList.AnalDays = arg.AnalDays
	gCurrentList.PreQty = arg.PreQty
	gCurrentList.PreCast = arg.PreCast

	SetIssueList()
	CoverEvent(gCurrentList,gCurrentIssueList)
	gCurrentList.ExpValue = ExpValueEvent(gCurrentList)
	sendCrrentIssue("all")
	SendInformation()
end
function SetIssueList()			--�����߼�
	local PreCast = gCurrentList.PreCast	--Ԥ���µ��ܽ��
	local AllValue = 0
	if gCurrentList.Check1 == "1" then	--����������
		local TempValue = tonumber(PreCast)
		local AllWeight	 = 0
		for issue,info in pairs (gCurrentIssueList) do
			local Price = GetforPrice(issue,"new")		--��ȡ����
			if gCurrentList.Check3 == "1" then		--�����ռۼ���
				Price = info.PrePrice
			end
			if gCurrentList.KeepCheck == "0" then	--���������
				info.Qty = math.ceil(tonumber(info.Qty)/100) * 100
			end
			Price = tonumber(Price)
			if Price and Price ~= 0 then
			info.Value = info.Qty * Price
			else
			info.Value = 0
			end
			if info.IsCheck == "1" then			--��ѡ
				TempValue = TempValue - tonumber(info.Value)
			else
				AllWeight = AllWeight + tonumber(info.BaseWeight)
			end
		end
		if TempValue < 0 then
			PreCast = PreCast - TempValue
			TempValue = 0
		end
		local each = 0
		if AllWeight <= 0 then
			each = 0
		else
			each = TempValue / AllWeight
		end
		for issue,info in pairs (gCurrentIssueList) do
			local Price =GetforPrice(issue,"new")		--��ȡ����
			if gCurrentList.Check3 == "1" then		--�����ռۼ���
				Price = info.PrePrice
			end
			Price = tonumber(Price)
			if info.IsCheck == "1" then			--��ѡ
			else
				info.Value = each * tonumber(info.BaseWeight)
				if Price and Price ~= 0 then
				info.Qty = math.ceil(info.Value / Price)
				else
				info.Qty = 0
				end
				if gCurrentList.KeepCheck == "0" then	--���������
					info.Qty = math.ceil(tonumber(info.Qty)/100) * 100
				end
				if Price and Price ~= 0 then
				info.Value = info.Qty * Price
				else
				info.Value = 0
				end
			end
			info.Weight = string.format("%.02f",info.Value/PreCast * 100)
			AllValue = AllValue + info.Value
		end
	else							--��Ȩ�ؼ���
		local AllWeight = 0				--Ȩ�غ�
		local TempAll = 100
		for issue,info in pairs (gCurrentIssueList) do
			if info.IsCheck == "1" then			--��ѡ
				TempAll = TempAll - tonumber(info.Weight)
			else
				AllWeight = AllWeight + tonumber(info.BaseWeight)
			end
		end
		if TempAll < 0 then TempAll = 0 end
		local each = 0
		if AllWeight <= 0 then
			each = 0
		else
			each = TempAll / AllWeight
		end
		local Cast = PreCast/100
		for issue,info in pairs (gCurrentIssueList) do
			local Price = GetforPrice(issue,"new")		--��ȡ����
			if gCurrentList.Check3 == "1" then		--�����ռۼ���
				Price = info.PrePrice
			end
			Price = tonumber(Price)
			if info.IsCheck == "1" then			--��ѡ
			else
				info.Weight = each * info.BaseWeight
			end
			local Qty = 0
			if Price and Price ~= 0 then
			Qty = math.ceil(Cast*info.Weight/Price)
			end
			if gCurrentList.KeepCheck == "0" then	--���������
				Qty = math.ceil(tonumber(Qty)/100) * 100
			end
			info.Qty = Qty
			if Price and Price ~= 0 then
			info.Value = info.Qty * Price
			else
			info.Value = 0
			end
			if tonumber(info.Weight) > 100 then
				info.Weight = 100
			end
			info.Weight = string.format("%.02f",info.Weight)
			AllValue = AllValue + info.Value
		end

	end
	gCurrentList.LastValue = AllValue
end

function CoverEvent(combinTable,issueTable)	--Ȩ�ظ��ǣ���ҵ���Ǽ���
	Writelog("CoverEvent")
	--gIndexWeight
	--Ȩ�ظ���
	local WeightAll = 0
	local temp = {}
	for issue,info in pairs(issueTable)do
		WeightAll = WeightAll + info.BaseWeight
		if gIndustryTable[issue] then
			if not temp[gIndustryTable[issue]] then temp[gIndustryTable[issue]] = 1 end
		end
	end
	if WeightAll > gIndexWeight then WeightAll = gIndexWeight end
	combinTable.WeightCover = string.format("%.03f",WeightAll/gIndexWeight)
	--��ҵ����
	--gIndustrySum
	local sum = 0
	for i,v in pairs(temp)do
		sum = sum +1
	end
	combinTable.IndustryCover = string.format("%.02f",sum/gIndustrySum)
end
function ExpValueEvent(combinTable)		--����ֵ����
	local Value = 0
	if gPriceTable["M000300"] then
		local Price = gPriceTable["M000300"].new
		Value = Price * 300 * tonumber(combinTable.PreQty)
	else
		local Price = GetPrice("M000300").new
		Value = Price * 300 * tonumber(combinTable.PreQty)
	end
	return string.format("%.02f",Value - combinTable.LastValue)
end
function SendInformation()			--��ǰ��������Ϣ��ʾ
	local lt = {}
	lt.WeightCover = gCurrentList.WeightCover
	lt.ExpValue = gCurrentList.ExpValue
	lt.IndustryCover = gCurrentList.IndustryCover
	lt.LastValue = gCurrentList.LastValue
	lt.Number = gCurrentList.Number
	SendToUIScript("SendInformation",lt);
end
function OkButton(arg)			--ȷ�ϰ�ť�߼�
	Writelog("OkButton")
	gCurrentList.CombinName = arg.CombinName
	if not gCombinList[gCurrentList.CombinCode] then gCombinList[gCurrentList.CombinCode] = {} end
	local templist = gCombinList[gCurrentList.CombinCode]
	for item,v in pairs(gCurrentList)do
		if item ~= "IndustryName" and item ~= "IndustryCode" then
			templist[item] = v
		end
	end

	if not gCombinIssueList[gCurrentList.CombinCode] then gCombinIssueList[gCurrentList.CombinCode] = {} end
	templist = gCombinIssueList[gCurrentList.CombinCode]
	for issue,info in pairs (templist) do						--ɾ����϶���ĺ�Լ
		if not gCurrentIssueList[issue] then
			gCombinIssueList[gCurrentList.CombinCode][issue] = nil
			local condition = string.format("InventoryModelID = '%s' and IssueCode = '%s'",gCurrentList.CombinCode,issue)
			Delete(DB, condition, "InventoryOrder")
		end
	end

	gCombinList[gCurrentList.CombinCode].BaseWeight = 0
	gCombinList[gCurrentList.CombinCode].Weight = 0

	--������Ϻ�Լ��ϸ���������ҵ��ϸ��
	gCombinIndustryList[gCurrentList.CombinCode] = {}		--��ҵ���ÿ�
	local tempIndustrylist = gCombinIndustryList[gCurrentList.CombinCode]
	for issue,info in pairs(gCurrentIssueList)do
		if not templist[issue] then templist[issue] = {} end
		templist[issue].Number = info.Number
		templist[issue].IssueName = info.IssueName
		templist[issue].Qty = info.Qty
		templist[issue].Weight = info.Weight
		templist[issue].BaseWeight = info.BaseWeight
		templist[issue].BaseValue = info.Qty * getPrice(issue,gCurrentList.BaseDate)
		templist[issue].Industry = info.Industry
		templist[issue].Shares = info.Shares
		templist[issue].SharesValue = info.Shares * info.LastPrice
		templist[issue].Capital = info.Capital
		templist[issue].Value =  info.Qty * info.LastPrice
		if not tempIndustrylist[info.Industry] then
			tempIndustrylist[info.Industry] = {CodeNumber=0,Value=0,IndustryWeight=0,IndustryBaseWeight=0,BaseWeight=0,Weight=0,Shares=0,Capital=0}
		end
		local tempTable = tempIndustrylist[info.Industry]
		tempTable.IndustryName = info.Industry
		tempTable.CodeNumber = tempTable.CodeNumber + 1
		tempTable.BaseWeight = tempTable.BaseWeight + info.BaseWeight
		tempTable.Weight = tempTable.Weight + info.Weight
		tempTable.Value = tempTable.Value + templist[issue].Value
		tempTable.Capital = tempTable.Capital + templist[issue].Capital
		--ͳ������ڱ��Ȩ�غ�
		gCombinList[gCurrentList.CombinCode].BaseWeight = gCombinList[gCurrentList.CombinCode].BaseWeight + tempTable.BaseWeight
		gCombinList[gCurrentList.CombinCode].Weight = gCombinList[gCurrentList.CombinCode].Weight + tempTable.Weight

	end
	SetInDB(gCurrentList.CombinCode)
	SendIDtoUI()
	SendCombinList()
end
function SetInDB(CombinCode)	--�������ݿ������Ϣ
	Writelog("SetInDB")
	if gCombinList[CombinCode] and gCombinIssueList[CombinCode] then
		local temptime = os.date("%Y-%m-%d", os.time())
		local temp = {}
		temp.InventoryModelID = CombinCode
		temp.ModelCode = gCombinList[CombinCode].CombinCode
		temp.ModelDescription = gCombinList[CombinCode].CombinName
		temp.Owner = gUSERID
		temp.ReserveString = "0"	--˽��
		temp.BaseIndexCode = gCombinList[CombinCode].BaseIndexCode
		temp.CreateTime = temptime
		temp.TimeStamp = temptime
		if gCombinList[CombinCode].ChangeDate then
			local condition = string.format("InventoryModelID = '%s'",CombinCode)
			Modify(DB, condition, "InventoryHeader", temp)
			gCombinList[CombinCode].ChangeDate = temptime
		else
			gCombinList[CombinCode].ChangeDate = temptime
			Insert(DB, "InventoryHeader", temp)
		end

		for issue,info in pairs (gCombinIssueList[CombinCode]) do
			local inserTable = {}
			inserTable.InventoryModelID = CombinCode
			inserTable.InventoryOrderNo = info.Number
			inserTable.IssueCode = issue
			inserTable.Quantity = info.Qty
			inserTable.GeneralDouble1 = info.Weight
			inserTable.ReserveDouble2 = info.BaseWeight
			inserTable.CreateTime = temptime
			inserTable.TimeStamp = temptime
			if info.ChangeDate then
				local condition = string.format("InventoryModelID = '%s' and IssueCode = '%s'",CombinCode,issue)
				Modify(DB, condition, "InventoryOrder", inserTable)
				info.ChangeDate = temptime
			else
				info.ChangeDate = temptime
				Insert(DB, "InventoryOrder", inserTable)
			end
		end
	end
end
----------------
--��������߼�--
----------------
function ImportOut(arg)				--��������߼�
	Writelog("ImportOut")
	Writelog(serialize(arg))
	local text = arg.Data
	local Type = arg.Type
	local lines = getLines(text);
	local _ImportTable = {}
	for i, line in ipairs(lines) do
		local rtn = getNameAndValue(line);
		local issueCode = innerTrimAll(rtn[1]," ");
		local fundRate = innerTrimAll(rtn[2]," ");	--�ʽ����
		gLogs = string.format("in lines issueCode[%s],FundRate[%s]",issueCode,fundRate);
		Writelog(gLogs);
		if issueCode == "����" then
		else
			fundRate = tonumber(fundRate)
			if fundRate and fundRate > 0 then
				if issueCode and gIssueNameList[issueCode] then
					_ImportTable[issueCode] = fundRate;
				end
			end
		end
	end

	if Type == "1" then		--����
		for issue,v in pairs (_ImportTable) do
			if not gCurrentIssueList[issue] then
				gCurrentIssueList[issue] = {}
				gCurrentIssueList[issue].IssueCode = issue
				gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
				gCurrentIssueList[issue].Number = CreateNumber()
				gCurrentIssueList[issue].Weight = 0
				gCurrentIssueList[issue].BaseWeight = GetBaseWeight(issue) or 0
				if gPriceTable[issue] then
					gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
					gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
					gCurrentIssueList[issue].Status = gPriceTable[issue].Status
				else
					gCurrentIssueList[issue].LastPrice = GetPrice(issue).new
					gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose
					gCurrentIssueList[issue].Status = ""
					local temp = toObjID(issue)
					StartPrice(temp,"No5Market")
				end
				gCurrentIssueList[issue].Industry = gIndustryTable[issue] or "-"
				gCurrentIssueList[issue].Shares = GetissueShares(issue)
				gCurrentIssueList[issue].Capital = GetCapital(issue)
				gCurrentList.Number = gCurrentList.Number + 1
			end
			gCurrentIssueList[issue].IsCheck = "1"
			gCurrentIssueList[issue].Qty = v
		end
	else
		--Ȩ��
		for issue,v in pairs (_ImportTable) do
			if not gCurrentIssueList[issue] then
				gCurrentIssueList[issue] = {}
				gCurrentIssueList[issue].IssueCode = issue
				gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
				gCurrentIssueList[issue].Number = CreateNumber()
				gCurrentIssueList[issue].Qty = 0

				gCurrentIssueList[issue].BaseWeight = GetBaseWeight(issue) or 0
				if gPriceTable[issue] then
					gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
					gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
					gCurrentIssueList[issue].Status = gPriceTable[issue].Status
				else
					gCurrentIssueList[issue].LastPrice = GetPrice(issue).new
					gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose
					gCurrentIssueList[issue].Status = ""
					local temp = toObjID(issue)
					StartPrice(temp,"No5Market")
				end
				gCurrentIssueList[issue].Industry = gIndustryTable[issue] or "-"
				gCurrentIssueList[issue].Shares = GetissueShares(issue)
				gCurrentIssueList[issue].Capital = GetCapital(issue)
				gCurrentList.Number = gCurrentList.Number + 1
			end
			gCurrentIssueList[issue].IsCheck = "1"
			gCurrentIssueList[issue].Weight = v
		end
	end
	sendCrrentIssue("all")
end

function getLines(text1)			--��ҵ�����߼�����
	Writelog("getLines(text) execute");
    local text = text1.."\n"
	Writelog(text);
	local lines = {}
	local len = string.len(text)
	local lineBegin = 1
	for i = 1, len do
		local chr = string.sub(text, i, i)
		if chr == "\n" then
			if lineBegin < i-2 then
				local line = string.sub(text, lineBegin, i-1)
				table.insert(lines, line)
			end
			lineBegin = i + 1;
		end
	end
	return lines
end

function getNameAndValue(line)
	local lin = line
	local logs = string.format("getNameAndValue line = [%s]",lin);
	Writelog(logs);

	local rtn = {}
	local len = string.len(line);
	local str = 1;
	for i = 1, len do
		local chr = string.sub(line, i, i)
		if chr == "," then
			table.insert(rtn, string.sub(line, str, i-1))
			str = i + 1;
		end
		if i == len then
			table.insert(rtn, string.sub(line,str, i))
		end
	end
	return rtn
end

function innerTrimAll(line, trimChar)
	local len1 = string.len(line);
	local rt = "";
	for i = 1, len1 do
		local chr = string.sub(line,i,i);
		if trimChar ~= chr then
			rt = rt .. chr;
		end
	end
	return rt;
end

----------------
--���¼����߼�--
----------------
RecalculateType = "1"			--1��ʾ�����¼��㣬2��ʾ�����¼���ȫ��
function Recalculate(arg)		--���¼���
	Writelog("Recalculate")
	if gCombinList[arg.CombinCode] and  gCombinIssueList[arg.CombinCode] then
		if RecalculateType == "1" then
			progressBar(0)
		end
		local AnalDays = tonumber(gCombinList[arg.CombinCode].AnalDays)
		local index = GetBaseDateindex(arg.CombinCode)
		--��ȡ��Ϻ�Լ����
		GetklineTable(gCombinIssueList[arg.CombinCode])
		--����������
		local tempRate = CalculateModelEarnRate(index,AnalDays,gCombinIssueList[arg.CombinCode])
		--�������ϵ��
		local CC = CalculateCC(tempRate)
		--����������
		local warp = CalculateWarp(tempRate)
		--����Beta
		local Beta = CalculateBeta(tempRate)
		--����Alpha
		local Alpha = CalculateAlpha(Beta,tempRate)
		if RecalculateType == "1" then
			progressBar(75)
		end

		gCombinList[arg.CombinCode].CC = string.format("%.04f",CC)
		gCombinList[arg.CombinCode].Warp = string.format("%.04f",warp)
		gCombinList[arg.CombinCode].Beta = string.format("%.04f",Beta)
		gCombinList[arg.CombinCode].Alpha = string.format("%.04f",Alpha)

		--������ҵ������
		GetIndustryInformation(index,AnalDays,arg.CombinCode)
		if RecalculateType == "1" then
			progressBar(80)
		end
		--�����������
		GetIssueInformation(index,AnalDays,arg.CombinCode)
		if RecalculateType == "1" then
			progressBar(95)
		end
		--������������ֵ��Ϣ
		SendCombinEvent(arg.CombinCode)

		--������϶�
		local temp = CalculateFit(arg.CombinCode)

		gCombinList[arg.CombinCode].Fit = string.format("%.02f",temp.Fit)
		gCombinList[arg.CombinCode].FitValue = string.format("%.02f",temp.FitValue)

		SendCurrentCombinList(arg.CombinCode)
		if _CurrentCombin == arg.CombinCode then
			SendIssueList()
			SendIndustryList()
		end
		if RecalculateType == "1" then
			progressBar(100)
		end
	end
end
function GetklineTable(tablelist)				--��ȡ���ɺ�Լ��ʷ�۸�
	local sum = 0
	for issue,info in pairs (tablelist) do
		sum = sum + 1
	end
	local tempsum = 0
	for issuecode,info in pairs(tablelist)do
		--��ȡ��Լ��ʷ�۸��
		if not gKlineTable[issuecode] then
			gKlineTable[issuecode]={time={},close={}}
			local KlineTable = GetKLine(toObjID(issuecode), "1d", nil, nil, -_AnalDays, _AnalDays)
			for i,v in pairs(KlineTable.time) do
				table.insert(gKlineTable[issuecode].time,string.sub(v,1,8))
				table.insert(gKlineTable[issuecode].close,KlineTable.close[i])
			end
		end
		tempsum = tempsum + 1
		if sum > 0 and RecalculateType == "1" then
			local Bar = (tempsum/sum) * 70
			Bar = math.ceil(Bar)
			progressBar(Bar)
		end
	end
end
function GetBaseDateindex(CombinCode)
	local index = #gKlineindexTable.time
	local Time = gCombinList[CombinCode].BaseDate
	for i,k in pairs(gKlineindexTable.time)do
		if tonumber(Time) == tonumber(k) then
			index = i
		end
	end
	return index
end
function GetIssueInformation(index,AnalDays,CombinCode)		--�����������
	Writelog("GetIssueInformation")
	for issue,info in pairs (gCombinIssueList[CombinCode]) do
		local Table = {}
		Table[issue] = {}
		Table[issue].Qty = info.Qty
		--����������
		local tempRate = CalculateModelEarnRate(index,AnalDays,Table)
		--�������ϵ��
		local CC = CalculateCC(tempRate)
		--����������
		local warp = CalculateWarp(tempRate)
		--����Beta
		local Beta = CalculateBeta(tempRate)
		--����Alpha
		local Alpha = CalculateAlpha(Beta,tempRate)
		--�����Լ��׼��ֵ
		local BaseValue = info.Qty*getPrice(issue,gCombinList[CombinCode].BaseDate)
		info.CC = string.format("%.04f",CC)
		info.Warp = string.format("%.04f",warp)
		info.Beta = string.format("%.04f",Beta)
		info.Alpha = string.format("%.04f",Alpha)
		info.BaseValue = BaseValue

	end
end
function GetIndustryInformation(index,AnalDays,CombinCode)	--������ҵ������
	Writelog("GetIndustryInformation")
	local Table = {}
	for issue,info in pairs (gCombinIssueList[CombinCode]) do
		local IndustryName = gIndustryTable[issue] or "-"
		if not Table[IndustryName] then  Table[IndustryName]= {} end
		if not Table[IndustryName][issue] then  Table[IndustryName][issue] = {} end
		Table[IndustryName][issue].Qty = info.Qty
	end
	for Industry,info in pairs (gCombinIndustryList[CombinCode]) do
		--����������
		local tempRate = CalculateModelEarnRate(index,AnalDays,Table[Industry])
		--�������ϵ��
		local CC = CalculateCC(tempRate)
		--����������
		local warp = CalculateWarp(tempRate)
		--����Beta
		local Beta = CalculateBeta(tempRate)
		--����Alpha
		local Alpha = CalculateAlpha(Beta,tempRate)
		--������ҵȨ��
		if tonumber(gCombinList[CombinCode].Weight) > 0 then
		info.IndustryWeight = string.format("%.02f",tonumber(info.Weight) / tonumber(gCombinList[CombinCode].Weight) * 100)
		end
		--���Ȩ��
		if tonumber(gCombinList[CombinCode].BaseWeight) > 0 then
		info.IndustryBaseWeight = string.format("%.02f",tonumber(info.BaseWeight) / tonumber(gCombinList[CombinCode].BaseWeight) * 100)
		end
		info.CC = string.format("%.04f",CC)
		info.Warp = string.format("%.04f",warp)
		info.Beta = string.format("%.04f",Beta)
		info.Alpha = string.format("%.04f",Alpha)
	end
end
function GetKlineIssue(AnalDays,Table)			--��ȡ��Լ�۸�
	Writelog("GetKlineIssue")
	local KlineIssueTable = {}
	--��ȡ��Ϻ�Լ����
	for issue,info in pairs(Table)do
		local temp = GetKLine(toObjID(issue), "1d", nil, nil, -(AnalDays+1), AnalDays+1)
		KlineIssueTable[issue] = {time={},close={}}
		local temptable = KlineIssueTable[issue]
		if temp then
			for i,v in pairs (temp.time) do
				table.insert(temptable.time,string.sub(v,1,8))
				table.insert(temptable.close,temp.close[i])
			end
		end
	end
	Writelog(serialize(KlineIssueTable))
	return KlineIssueTable
end
function CalculateModelEarnRate(index,AnalDays,Table)	--�������������
	Writelog("CalculateModelEarnRate")


	local ValueTable = {}
	local RateTable = {}

	--ͨ������300�������ݼ��������ֵ
	local first = index - AnalDays + 1
	if first < 1 then first = 1 end
	for i=first,index do
		ValueTable[i] = 0
		for issue,info in pairs(Table)do
			local price = getPrice(issue,gKlineindexTable.time[i])
			ValueTable[i] = ValueTable[i] + info.Qty * price
		end
	end
	Writelog(serialize(ValueTable))
	Writelog("RateTable")
	--�������������
	for i,v in pairs (ValueTable) do
		if ValueTable[i] and ValueTable[i-1] then
			if tonumber(ValueTable[i-1]) > 0 then
			RateTable[i] = tonumber(ValueTable[i])/tonumber(ValueTable[i-1]) -1
			else
			RateTable[i] = 0
			end
		end
	end
	Writelog(serialize(RateTable))
	return RateTable
end
function CalculateCC(RateTable)		--�������ϵ��
	Writelog("CalculateCC")
	local mdlSum = 0
	local idxSum = 0
	local mdl2Sum = 0
	local idx2Sum = 0
	local mulMdlIdxSum = 0
	local count = 0
	local cc = 0
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			mdlSum = mdlSum + v
			idxSum = idxSum + gKlineindexTable.Rate[i]
			mdl2Sum = mdl2Sum + v * v
			idx2Sum = idx2Sum + gKlineindexTable.Rate[i] * gKlineindexTable.Rate[i]
			mulMdlIdxSum = mulMdlIdxSum + v * gKlineindexTable.Rate[i]
		end
	end

	local deno = math.pow(count*mdl2Sum - mdlSum * mdlSum, 0.5) * math.pow(count*idx2Sum - idxSum*idxSum, 0.5)
	if deno ~= 0 then
		cc = (count*mulMdlIdxSum - mdlSum*idxSum) / deno * 100
	end
	local resultLogs = string.format("CalculateCC end cc=%s",cc)
	Writelog(resultLogs)
	return cc

end
function getPrice(issue,time)
	local Price = 0
	if gKlineTable[issue] then
		local Table = gKlineTable[issue]
		for i,k in pairs(Table.time)do
			if k <= time then
				Price = Table.close[i]
			end
		end
		if not Price then
			local log = string.format("��ȡ��������[%s]�ļ۸�",time)
			Writelog(log)
			Price = 0
		end
	end
	return Price
end
function CalculateWarp(RateTable)	--����������
	local count = 0
	local earnSum = 0
	local warp = 0
	local warpTable = {}
	Writelog("CalculateWarp Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			table.insert(warpTable, v - gKlineindexTable.Rate[i])
			earnSum = earnSum + v - gKlineindexTable.Rate[i]
		end
	end
	Writelog("warpTable")
	if count ~= 0 then
		earnSum = earnSum / count
		for i =1, count do
			warp = warp + (warpTable[i] - earnSum) * (warpTable[i] - earnSum)
		end
		warp  = math.pow(warp / (count), 0.5)
	end
	local resultLogs = string.format("CalculateWarp end warp=%s",warp)
	Writelog(resultLogs)
	return warp * 100
end
function CalculateBeta(RateTable)	--���㱴��ϵ��
	Writelog("CalculateBeta Start")
	local beta = 0
	local variance = CalculateVariance(RateTable)		--
	if variance ~= 0 then
		beta = CalculateCovariance(RateTable) / variance
	end

	local resultLogs = string.format("CalculateBeta end beta=%s",beta)
	Writelog(resultLogs)
	return beta;
end
function CalculateCovariance(RateTable)		--beta����
	local mulMdlIdx = 0
	local mdlAverage = 0
	local idxAverage = 0
	local count = 0
	Writelog("CalculateCovariance Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			mdlAverage = mdlAverage + v
			idxAverage = idxAverage + gKlineindexTable.Rate[i]
			mulMdlIdx = mulMdlIdx + v * gKlineindexTable.Rate[i]
		end
	end

	if count > 0 then
		mdlAverage = mdlAverage / count;
		mulMdlIdx = mulMdlIdx / count;
		idxAverage =  idxAverage / count
	end


	local covariance = mulMdlIdx - mdlAverage * idxAverage

	local resultLogs = string.format("CalculateCovariance end covariance=%s",covariance)
	Writelog(resultLogs)

	return covariance
end
function CalculateVariance(RateTable)		--beta��ĸ
	local count = 0
	local average = 0
	local variance = 0
	local targetModelEarnRate = {}
	local resultLogs = ""
	Writelog("CalculateVariance Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			table.insert(targetModelEarnRate, gKlineindexTable.Rate[i])
			average = average + gKlineindexTable.Rate[i]
		end
	end

	if count == 0 then
		return 0
	end
	resultLogs = string.format("CalculateVariance  count=%d",count)
	Writelog(resultLogs)

	average = average / count

	for i = 1, count  do
		variance = variance + (targetModelEarnRate[i] - average) * (targetModelEarnRate[i] - average)
		resultLogs = string.format("CalculateVariance num:%d variance=%f",i, variance)
		Writelog(resultLogs)
	end

	variance  = variance / count
	resultLogs = string.format("CalculateVariance end variance=%s",variance)
	Writelog(resultLogs)
	return variance
end
function CalculateAlpha(beta,RateTable)		--����Alpha
	local averY = TotalModelEarnRate(RateTable).Average
	local averX = TotalIndexEarnRate(RateTable).Average
	return (averY - beta * averX) * 100
end
function TotalModelEarnRate(RateTable)--��������ʵĺ����ֵ
	local result = {}
	result.Total = 0
	result.Average = 0

	local count = 0
	Writelog("CalculateCovariance Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			result.Total = result.Total + v
		end
	end

	if count > 0 then
		result.Average = result.Total / count;
	end

	local resultLogs = string.format("TotalModelEarnRate end Total=%s, Aver=%s",result.Total, result.Average)
	Writelog(resultLogs)

	return result
end
function TotalIndexEarnRate(RateTable)--ָ�������ʵĺ����ֵ
	local result = {}
	result.Total = 0
	result.Average = 0
	local count = 0
	Writelog("TotalIndexEarnRate Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			result.Total = result.Total + gKlineindexTable.Rate[i]
		end
	end
	if count > 0 then
		result.Average = result.Total / count;
	end
	local resultLogs = string.format("TotalModelEarnRate end Total=%s, Aver=%s",result.Total, result.Average)
	Writelog(resultLogs)
	return result
end
function CalculateFit(CombinCode)			--��������Ŷ�
	Writelog("CalculateFix")
	local lt = {}
	local Value = tonumber(gCombinList[CombinCode].Price)  --����ּ�
	local BasePrice = 0
	if gPriceTable["M000300"] then
		BasePrice = tonumber(gPriceTable["M000300"].new)
	else
		BasePrice = tonumber(GetPrice("M000300").new)
	end
	lt.FitValue = Value - BasePrice
	if tonumber(lt.FitValue) > 0 then
		if BasePrice > 0 then
		lt.Fit =(BasePrice - lt.FitValue) / BasePrice * 100
		else
		lt.Fit = 0
		end
	else
		if BasePrice > 0 then
		lt.Fit =(BasePrice + lt.FitValue) / BasePrice * 100
		else
		lt.Fit = 0
		end
	end
	return lt
end
function RecalculateAll(arg)		--���¼�������
	Writelog("RecalculateAll")
	RecalculateType = "2"
	progressBar(0)
	local sum = 0
	for CombinCode,info in pairs (gCombinList) do
		sum = sum + 1
	end
	local tempsum = 0
	for CombinCode,info in pairs (gCombinList) do
		tempsum = tempsum + 1
		if sum > 0 then
			local Bar = (tempsum/sum) * 100
			Bar = math.ceil(Bar)
			progressBar(Bar)
		end
		local temp = {}
		temp.CombinCode = CombinCode
		Recalculate(temp)
	end
	RecalculateType = "1"
end


