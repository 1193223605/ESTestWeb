﻿
--委托成交回调
_OnEventExecution("OrderExecReply", {} , DTSMessageRecordAccess msg)
	local _String uniqueKeyCode = msg.getUniqueKeyCode();
	local _String message = msg.getMessageType ();
	local DTSOrderDetailRecordAccess order = msg.getOrderDetailRecord();
	local _String baMapID = order.getBAMapID();
	local investorID = "-"
	local accountCode = _PosBAMapAccount[baMapID] or "-"
	if _PosFundStatus[accountCode] then
		if _PosFundStatus[accountCode] then
			investorID = _PosFundStatus[accountCode].InvestorID
		end
	end

	local _String corpCode = order.getCorpCode();

	--价格格式化
	local issueCode = order.getIssueCode();
	local formatPriceExponent = getPriceFormat(issueCode)

	if _PosBAMapTable[baMapID] then
		local issueCode = order.getIssueCode();							--合约号
		local baSubID = order.getBASubID();								--BASubID
		local issueName = _PosIssueNameTable[issueCode];				--合约名称
		local buySell = order.getBuySell();								--买卖
		local openClose = order.getReserveInt1();						--开仓、平仓、平今
		--local creRed = order.getGeneralInt1()							--0普通委托, 1:申购. 2:赎回, 3:质押, 4:融资回购, 5:融券回购
		local orderQuantity = order.getOriginalQuantity();				--委托数量
		local orderPrice = order.getOrderPrice();						--委托价
		local orderTime = order.getOrderTime();							--委托时间
		local orderAcceptNo = order.getOrderAcceptNo();					--委托号
		local corpCode = order.getCorpCode();							--内部委托号

		local workingQuantity = order.getWorkingQuantity();				--挂盘数量
		local cancelQuantity = order.getCancelQuantity();				--撤单数量
		local unAcceptedQuantity = order.getUnacceptedQuantity();		--未报数量
		local rejectedQuantity = order.getRejectedQuantity();			--拒绝数量
		local executionQuantity = order.getExecutionQuantity();			--成交数量
		local executionValue = order.getExecutionValue();				--成交金额
		local execPrice = msg.getExecutionPrice()						--成交价格

		local marketCode = order.getMarketCode();						--市场号
		local market = ""
		local shareholderCode = ""
		if marketCode == "1" then
			market = "上交所"
		elseif marketCode == "2" then
			market = "深交所"
		elseif marketCode == "3" then
			market = "中金所"
		elseif marketCode == "4" then
			market = "上期"
		elseif marketCode == "5" then
			market = "郑商"
		elseif marketCode == "6" then
			market = "大商"
		end
		local productCode = order.getProductCode();						--产品代码
		--local marginFlag = order.getOrderMarginFlag();				--0:证券交易 2：开仓 4：平仓
		local generalString1 = order.getGeneralString1();				--客户号和交易密码
		local reserveString2 = order.getReserveString2()				--上海股东代码|深证股东代码
		local PCID = order.getPositionCheckID()							--持仓检查号
		--local batchID = order.getTargetPrice()						--匹配号

		--下单拒绝时交易号为""，输出为"-"
		if orderAcceptNo == "" then
			orderAcceptNo = "-"
		end

		--组合号
		local portID = sys_sub(baSubID, 2, -1)
		if portID == "" then
			portID = "-"
		end

		--设置成交额
		if executionValue ~= "" then
			executionValue = sys_format(formatPriceExponent, executionValue);
		end

		--设置委托价格
		if orderPrice ~= "" then
			orderPrice = sys_format(formatPriceExponent, orderPrice);
		end

		--设置委托时间
		if orderTime~="" then
			local tmpordtimeH = sys_sub(orderTime,1,2);
			local tmpordtimeM = sys_sub(orderTime,3,4);
			local tmpordtimeS = sys_sub(orderTime,5,6);
			local tmpordtimeHM = sys_sub(orderTime,7,9);
			orderTime = tmpordtimeH..":"..tmpordtimeM..":"..tmpordtimeS
		else
			orderTime = "-"
		end
		local DTSDate nowDate = _GetNowDate();		--获取当前日期
		local strDate = nowDate.asString("%Y%m%d");	--日期格式化成"20100127"

		--设置委托状态
		local status = "-"
		local statusFlag = "-";
		if orderQuantity == executionQuantity then
			status = "全部成交"
			statusFlag = "1"
		elseif executionQuantity >0 and orderQuantity > executionQuantity then
			if executionQuantity + cancelQuantity == orderQuantity then
				status = "部成部撤"
				statusFlag = "1"
			else
				status = "部分成交"
				statusFlag = "2"
			end
		elseif workingQuantity > 0 then
			status = "挂单"
			statusFlag = "2"
		elseif cancelQuantity > 0 then
			status = "撤单"
			statusFlag = "1"
		elseif unAcceptedQuantity > 0 then
			status = "未报"
			statusFlag = "1"
		elseif rejectedQuantity > 0 then
			status = "拒绝"
			statusFlag = "1"
		else
			status = "已报"
			statusFlag = "2"
		end

		local openCloseName = "-"
		if openClose == 0 then
			openCloseName = "开仓"
		elseif openClose == 1 then
			openCloseName = "平仓"
		elseif openClose == 2 then
			openCloseName = "平今"
		end
		local buySellName = "-"
		if buySell == "3" then
			buySellName = "买"
		elseif  buySell == "1" then
			buySellName = "卖"
		end
		--gtOrderList[PortID].StockOpen[CorpCode].各个字段 gtOrderList[PortID].FutureClose[CorpCode].各个字段
		gtOrderList[portID] = gtOrderList[portID] or {}
		gtOrderList[portID].StockOpen = gtOrderList[portID].StockOpen or {}
		gtOrderList[portID].StockClose = gtOrderList[portID].StockClose or {}
		gtOrderList[portID].FutureOpen = gtOrderList[portID].FutureOpen or {}
		gtOrderList[portID].FutureClose = gtOrderList[portID].FutureClose or {}
		local templist = {}
		if marketCode == "1" or marketCode == "2" then
			if buySell == "3" then
				gtOrderList[portID].StockOpen[corpCode] = gtOrderList[portID].StockOpen[corpCode] or {}
				templist = gtOrderList[portID].StockOpen[corpCode]
			elseif buySell == "1" then
				gtOrderList[portID].StockClose[corpCode] = gtOrderList[portID].StockClose[corpCode] or {}
				templist = gtOrderList[portID].StockClose[corpCode]
			end
		elseif marketCode == "3" then
			if buySell == "1" then
				gtOrderList[portID].FutureOpen[corpCode] = gtOrderList[portID].FutureOpen[corpCode] or {}
				templist = gtOrderList[portID].FutureOpen[corpCode]
			elseif buySell == "3" then
				gtOrderList[portID].FutureClose[corpCode] = gtOrderList[portID].FutureClose[corpCode] or {}
				templist = gtOrderList[portID].FutureClose[corpCode]
			end
		end
		local log = sys_format("OnExecOrder, msg=[%s], corpCode=[%s], orderAcceptNo=[%s], orderTime=[%s], PCID=[%s], issue=[%s], baSubID=[%s], bs=[%s], oc=[%s], orderPrice=[%s],orderQty=[%s], execQty=[%s], workingQty=[%s], cancelQty=[%s], unAcceptedQty=[%s], rejectedQty=[%s], status=[%s], statusFlag=[%s] investorID[%s] baMapID[%s] executionValue[%s]",
										message, corpCode, orderAcceptNo, orderTime, PCID, issueCode, baSubID,  buySellName, openCloseName, orderPrice, orderQuantity,executionQuantity, workingQuantity, cancelQuantity, unAcceptedQuantity, rejectedQuantity, status, statusFlag,investorID,baMapID,executionValue)
		_WriteErrorLog(log)

		templist.IssueCode = issueCode
		templist.IssueName = issueName
		templist.Market = market
		templist.BuySell = buySellName
		templist.OpenClose = openCloseName
		templist.EntrustPrice = orderPrice
		templist.EntrustQty = orderQuantity
		templist.DealQty = executionQuantity
		templist.AveragePrice = executionValue
		templist.CancellationQty = cancelQuantity
		templist.Time = orderTime
		templist.Date = strDate
		templist.ShareholderCode = shareholderCode
		templist.OrderAcceptNo = orderAcceptNo
		templist.Status = status
		templist.StatusFlag = statusFlag
		templist.WorkingQuantity = workingQuantity
		templist.PCID = PCID
		templist.ExecNo = "-"
		templist.ExecTime = "-"
		templist.ExecPrice = 0
		templist.ExecQuantity = 0
		templist.InvestorID = investorID

		if portID == gPortID then
			if marketCode == "1" or marketCode == "2" then
				SendStockOpenOrderEvent(gPortID,corpCode,templist)
			elseif marketCode == "3" then
				SendFutureOpenOrderEvent(gPortID,corpCode,templist)
			end
		end

		--成交回调，并发送成交
		if msg.getMessageType () == "L07" or msg.getMessageType () == "L18"  then
			local execPrice = msg.getExecutionPrice()				--成交价格
			local execQuantity = msg.getExecutionQuantity()		--成交数量
			local execTime = msg.getExecutionTime()				--成交时间
			local execNo = msg.getExecutionNo()						--成交号

			if execPrice ~= "" then
				execPrice = sys_format(formatPriceExponent, execPrice);
			end
			if execNo == "" then	--内部成交的成交号为空
				execNo = "-"
			end
			local log = sys_format("execTime:%s",execTime)
			_WriteAplLog(log)
			if execTime ~= "" then
				execTime = formatTime(execTime)
			end
			log = sys_format("execTime:%s",execTime)
			_WriteAplLog(log)
			local execLog = sys_format("OnExecOrder, execPrice:%s, execQuantity:%s, execTime:%s, execNo:%s",execPrice, execQuantity, execTime, execNo)
			_WriteErrorLog(execLog)

			local entrustQty = orderQuantity
			local entrustPrice = orderPrice
			local dealQty = execQuantity
			local averagePrice = execPrice
			local cancellationQty = cancelQuantity
			local tempExeclist = {}
			if marketCode == "1" or marketCode == "2" then
				if buySell == "3" then
					tempExeclist = gtOrderList[portID].StockOpen[corpCode]
				elseif buySell == "1" then
					tempExeclist = gtOrderList[portID].StockClose[corpCode]
				end
			elseif marketCode == "3" then
				if buySell == "1" then
					tempExeclist = gtOrderList[portID].FutureOpen[corpCode]
				elseif buySell == "3" then
					tempExeclist = gtOrderList[portID].FutureClose[corpCode]
				end
			end
			tempExeclist.ExecNo = execNo
			tempExeclist.ExecTime = execTime
			tempExeclist.ExecPrice = execPrice
			tempExeclist.ExecQuantity = execQuantity
			tempExeclist.OpenClose = openCloseName

			if portID == gPortID then
				if marketCode == "1" or marketCode == "2" then
					SendStockOpenOrderEvent(gPortID,corpCode,tempExeclist)
					SendStockOpenExecuteEvent(gPortID,corpCode,tempExeclist)
				elseif marketCode == "3" then
					SendFutureOpenOrderEvent(gPortID,corpCode,tempExeclist)
					SendFutureOpenExecuteEvent(gPortID,corpCode,tempExeclist)
				end
				--showArbitragePosition()

				--RefreshArbitrageInfo(portID)
				--SendArbitrageInfo(portID)
			end
		end
	end
_End

