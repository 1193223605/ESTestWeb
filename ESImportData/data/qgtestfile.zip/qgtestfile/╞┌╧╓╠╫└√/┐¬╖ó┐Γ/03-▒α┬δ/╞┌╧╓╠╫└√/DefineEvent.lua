﻿---------------------------初始化事件Begin---------------------------
--发送读取到的组合信息
_DefineEventObject CreateCombinTableEvent _AS _Output
	_DefFld("InventoryID", _String, 100)
	_DefFld("ModelDescription", _String, 100)
	_DefFld("IssueCode", _String, 12)
	_DefFld("Quantity", _String, 12)
	_DefKeyField("InventoryID");
	_DefKeyField("IssueCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
--重新读取组合信息
_DefineEventObject RefreshCombin  _AS _Input

_End
--重新计算组合信息显示
_DefineEventObject RefreshCombinInfo  _AS _Input

_End

--可用全平
_DefineEventObject CloseOrderQty  _AS _Input
	_DefFld("Button", _String, 2)
_End
--发送IF信息
_DefineEventObject CreateIFTableEvent _AS _Output
	_DefFld("IF1", _String, 6)
	_DefFld("IF2", _String, 6)
	_DefFld("IF3", _String, 6)
	_DefFld("IF4", _String, 6)
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
--发送账户信息
_DefineEventObject CreateStockIDEvent _AS _Output
	_DefFld("BAMapID", _String, 200)			--账户列表
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
--发送账户信息
_DefineEventObject CreateFutureIDEvent _AS _Output
	_DefFld("BAMapID", _String, 200)			--账户列表
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--平仓查询资金状况显示
_DefineEventObject QueryCloseFund _AS _Input
	_DefFld("BAMapID",_String,32)		--BAMapID
    _DefFld("IssueCode", _String, 12)
	_DefFld("CombinCode", _String, 100)
_End

--单笔委托
_DefineEventObject FireEvent _AS _Input
	_DefFld("CombinCode",_String,100)
	_DefFld("BAMapID",_String,32)		--BAMapID,平仓应用
    _DefFld("IssueCode", _String, 20)
    _DefFld("BuySell", _String, 1)
    _DefFld("OpenClose", _String, 1)
	_DefFld("Price", _String, 13)
    _DefFld("Quantity", _Int, 8)
_End
--单笔委托资金显示
_DefineEventObject FundReply _AS _Output
    _DefFld("IssueCode", _String, 20)
    _DefFld("AvlibFund", _String, 20)
    _DefFld("AvlibOpenatQty", _String, 20)
    _DefFld("AvlibBuyCloseQty", _String, 20)
    _DefFld("AvlibSellCloseQty", _String, 20)

    _DefKeyField("IssueCode")
    _SetBufferedFlag(2) -- use map mode
_End
--根据CorpCode撤单
_DefineEventObject CancelSingleOrder _AS _Input
	_DefFld("CorpCode", _String, 20);	--内部委托号
_End
--改价重下
_DefineEventObject AmendSingleOrder _AS _Input
	_DefFld("CorpCode", _String, 20);	--内部委托号
	_DefFld("IssueCode", _String, 20);	--IssueCode
	_DefFld("BuySell", _String, 5);	--方向
	_DefFld("OrderPrice", _String, 20);	--改价
_End
--Define basePrice Object
_DefineEventObject BasePriceEvent _AS _Output
	_DefFld("IssueCode",_String ,20);				--合约
	_DefFld("IssueShortName",_String ,30);		--合约名称
	_DefFld("LastPrice",_String,15);       			--最新
	_DefFld("LastVolume",_String,15);      	    	--现量
	_DefFld("BidPrice_1",_String,15);      			--买价
	_DefFld("BidQty_1",_String,15);        	    	--买量
	_DefFld("AskPrice_1",_String,15);  				--卖价
	_DefFld("AskQty_1",_String,15);        			--卖量
	_DefFld("BidPrice_2",_String,15);      			--买价
	_DefFld("BidQty_2",_String,15);        	    	--买量
	_DefFld("AskPrice_2",_String,15);  				--卖价
	_DefFld("AskQty_2",_String,15);        			--卖量
	_DefFld("BidPrice_3",_String,15);      			--买价
	_DefFld("BidQty_3",_String,15);        	    	--买量
	_DefFld("AskPrice_3",_String,15);  				--卖价
	_DefFld("AskQty_3",_String,15);        			--卖量
	_DefFld("BidPrice_4",_String,15);      			--买价
	_DefFld("BidQty_4",_String,15);        	    	--买量
	_DefFld("AskPrice_4",_String,15);  				--卖价
	_DefFld("AskQty_4",_String,15);        			--卖量
	_DefFld("BidPrice_5",_String,15);      			--买价
	_DefFld("BidQty_5",_String,15);        	    	--买量
	_DefFld("AskPrice_5",_String,15);  				--卖价
	_DefFld("AskQty_5",_String,15);        			--卖量
	_DefFld("UpperLimitPrice",_String,20);			--涨停价
	_DefFld("LowerLimitPrice",_String,20);			--跌停价
	_DefFld("TotalAskQty",_String,20);			--总卖量
	_DefFld("TotalBidQty",_String,20);			--总买量

	_DefKeyField("IssueCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

_DefineEventObject Initialized _AS _Output
	_DefFld("Flag",_String,2);

	_SetBufferedFlag(2);
_End

_DefineEventObject SendAutoMessage _AS _Output	--给出下单提示框显示
	_DefFld("Title",_String,50);
	_DefFld("TxT",_String,500);
	_SetBufferedFlag(2);
_End

----------------------------初始化事件End----------------------------

--------------------------组合相关事件Begin--------------------------
--创建组合 接收
_DefineEventObject CreateCombin _AS _Input
	_DefFld("CombinName", _String, 100)
	_DefFld("StockCode", _String, 100)				--股票
	_DefFld("StockNum", _String, 12)
	_DefFld("StockBuy", _String, 12)
	_DefFld("StockSell", _String, 12)
	_DefFld("FutureCode", _String, 12)				--期货
	_DefFld("FutureNum", _String, 12)
	_DefFld("FutureBuy", _String, 12)
	_DefFld("FutureSell", _String, 12)
_End

--创建组合 发送
_DefineEventObject InventoryListTable _AS _Output
	_DefFld("CombinName", _String, 100)
	_DefFld("SpotVarieties", _String, 12)
	_DefFld("ContractNo", _String, 12)
	_DefFld("StockStatus", _String, 12)
	_DefFld("FutureStatus", _String, 12)
	_DefFld("Basis", _String, 12)
	_DefFld("SpotMarket", _String, 12)
	_DefFld("FutureMarket", _String, 12)
	_DefFld("Open", _String, 12)
	_DefFld("PositionBasis", _String, 12)
	_DefFld("SpotValuePosition", _String, 12)
	_DefFld("FutureValuePosition", _String, 12)
	_DefFld("OpenPosition", _String, 12)
	_DefFld("BasicEarnings", _String, 12)
	_DefFld("EstimatedEarnings", _String, 12)
	_DefFld("AlphaReturns", _String, 12)
	_DefFld("OpenReturn", _String, 12)
	_DefFld("ChargeCost", _String, 12)
	_DefFld("EstimatedCost", _String, 12)
	_DefFld("PortID", _String, 20)

	_DefFld("Stock", _String, 100)
	_DefFld("StockNum", _String, 12)
	_DefFld("StockBuy", _String, 12)
	_DefFld("StockSell", _String, 12)
	_DefFld("Future", _String, 12)
	_DefFld("FutureNum", _String, 12)
	_DefFld("FutureBuy", _String, 12)
	_DefFld("FutureSell", _String, 12)

	_DefKeyField("PortID");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--保存组合信息
_DefineEventObject SaveCombinDataEvent _AS _Output
	_DefFld("CombinName", _String, 100)
	_DefFld("Stock", _String, 100)
	_DefFld("StockNum", _String, 12)
	_DefFld("StockBuy", _String, 12)
	_DefFld("StockSell", _String, 12)
	_DefFld("Future", _String, 12)
	_DefFld("FutureNum", _String, 12)
	_DefFld("FutureBuy", _String, 12)
	_DefFld("FutureSell", _String, 12)
	_DefFld("OpenNum", _String, 12)
	_DefFld("CloseNum", _String, 12)
	_DefFld("StockStatus", _String, 20)
	_DefFld("FutureStatus", _String, 20)
	_DefFld("PortID", _String, 20)

	_DefKeyField("PortID");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--修改组合
_DefineEventObject ModifyCombin _AS _Input
	_DefFld("PortID", _String, 20)
	_DefFld("CombinName", _String, 100)
	_DefFld("Number", _String, 12)
	_DefFld("StockCode", _String, 100)
	_DefFld("StockNum", _String, 12)
	_DefFld("StockBuy", _String, 12)
	_DefFld("StockSell", _String, 12)
	_DefFld("FutureCode", _String, 12)
	_DefFld("FutureNum", _String, 12)
	_DefFld("FutureBuy", _String, 12)
	_DefFld("FutureSell", _String, 12)
_End

--删除组合
_DefineEventObject DelCombin _AS _Input
	_DefFld("PortID", _String, 20)
_End

--选择组合
_DefineEventObject ChooseCombin _AS _Input
	_DefFld("PortID", _String, 20)
_End

--开仓设置股票
_DefineEventObject SetIssueEvent _AS _Input
	_DefFld("PortID", _String, 20)
	_DefFld("IssueCode", _String, 15)
	_DefFld("StockPrice", _String, 20)
	_DefFld("StockTick", _String, 20)
	_DefFld("UserPos", _String, 5)
	_DefFld("NotBuy", _String, 5)
	_DefFld("Qty", _String, 20)
	_DefFld("Price", _String, 20)
_End

--平仓设置股票
_DefineEventObject SetIssueCloseEvent _AS _Input
	_DefFld("PortID", _String, 20)
	_DefFld("IssueCode", _String, 15)
	_DefFld("StockPrice", _String, 20)
	_DefFld("StockTick", _String, 20)
	_DefFld("SavePos", _String, 5)
	_DefFld("NotSell", _String, 5)
	_DefFld("Qty", _String, 20)
	_DefFld("Price", _String, 20)
_End

--套利信息
_DefineEventObject ArbitrageInfo _AS _Output
	--基本信息
	_DefFld("CombinName", _String, 100)						--套利组合名
	_DefFld("Status", _String, 20)							--状态
	_DefFld("Stock", _String, 20)							--现货
	_DefFld("SampleNum", _String, 20)						--样本数
	_DefFld("Future", _String, 20)							--期货
	_DefFld("FutureNum", _String, 20)						--期货分数
	_DefFld("StartTime", _String, 20)						--建仓开始时间
	_DefFld("EndTime", _String, 20)							--平仓开始时间
	--现货
	_DefFld("BuyAmount", _String, 20)						--买入金额
	_DefFld("SpotBuyChargeCost", _String, 20)				--买入冲击成本
	_DefFld("SellAmount", _String, 20)						--卖出金额
	_DefFld("SpotSellChargeCost", _String, 20)				--卖出冲击成本
	_DefFld("SpotMarketValue", _String, 20)					--持仓市值
	_DefFld("SpotVarieties", _String, 20)					--品种数
	_DefFld("SpotTradeFee", _String, 20)					--交易费用
	_DefFld("SpotFloatStatus", _String, 20)					--浮动盈亏
	_DefFld("SpotGainLoss", _String, 20)					--现货盈亏
	--期货
	_DefFld("OpenPrice", _String, 20)						--建仓均价
	_DefFld("FutureBuyChargeCost", _String, 20)				--建仓冲击成本
	_DefFld("ClosePrice", _String, 20)						--平仓均价
	_DefFld("FutureSellChargeCost", _String, 20)			--平仓冲击成本
	_DefFld("FutureTradeFee", _String, 20)					--交易费用
	_DefFld("ContractsNum", _String, 20)					--平仓合约数
	_DefFld("Price", _String, 20)							--当前价格
	_DefFld("FutureFloatStatus", _String, 20)				--浮动盈亏
	_DefFld("FutureGainLoss", _String, 20)					--期货盈亏
	--套利
	_DefFld("Exposure", _String, 20)						--建仓敞口
	_DefFld("OpenBasis", _String, 20)						--建仓基差
	_DefFld("OpenPoint", _String, 20)						--建仓点
	_DefFld("CloseBasis", _String, 20)						--平仓基差
	_DefFld("ClosePoint", _String, 20)						--平仓点
	_DefFld("BasisRevenue", _String, 20)					--基差收益
	_DefFld("AlphaRevenue", _String, 20)					--α收益
	_DefFld("ExposureRevenue", _String, 20)					--敞口收益
	_DefFld("ImpactCosts", _String, 20)						--冲击成本
	_DefFld("EstimatedCost", _String, 20)					--预估费用
	_DefFld("PoorMarket", _String, 20)						--市值差
	_DefFld("EstimatedRevenue", _String, 20)				--预估收益
	_DefFld("RateReturn", _String, 20)						--收益率
_End
---------------------------组合相关事件End---------------------------

---------------------------现货相关表Begin---------------------------
--现货建平仓表控件
_DefineEventObject OpenPosTableEvent _AS _Output	--现货建仓控件
	_DefFld("BuyNo", _String, 15)					--买入品种
	_DefFld("BuyAmount", _String, 15)				--买入委托金额
	_DefFld("SellNo", _String, 15)					--卖出品种
	_DefFld("SellAmount", _String, 15)				--卖出委托金额
	_DefFld("DealAmount", _String, 15)				--成交金额
	_DefFld("NotSellQty", _String, 15)				--盘口不足
	_DefFld("NotBuyQty", _String, 15)				--盘口不足
	_DefFld("SP", _String, 15)						--停牌
	_DefFld("SL", _String, 15)						--涨停
	_DefFld("DL", _String, 15)						--跌停
_End
--现货建仓表
_DefineEventObject StockOpenPosTable _AS _Output	--建仓单
	_DefFld("IssueCode", _String, 15)				--合约代码
	_DefFld("IssueName", _String, 20)				--合约名称
	_DefFld("SampleNum", _String, 15)				--样本数量
	_DefFld("Rose", _String, 10)					--涨幅
	_DefFld("LastPrice", _String, 15)				--最新价
	_DefFld("StockPrice", _String, 20)				--取价方式
	_DefFld("BuyPrice", _String, 15)				--委买价格
	_DefFld("BuyQty", _String, 10)					--委买数量
	_DefFld("Handicap", _String, 15)				--盘口
	_DefFld("DealQty", _String, 10)					--成交数量
	_DefFld("DealPrice", _String, 15)				--成交价格
	_DefFld("HaveQty", _String, 10)					--拥有数量
	_DefFld("Inventory", _String, 10)				--使用库存量
	_DefFld("SellingQuantity", _String, 10)			--卖盘数量
	_DefFld("UserPos", _String, 5)					--使用库存
	_DefFld("NotBuy", _String, 5)					--不买入

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End


--现货平仓表
_DefineEventObject StockClosePosTable _AS _Output	--建仓单
	_DefFld("IssueCode", _String, 15)				--合约代码
	_DefFld("IssueName", _String, 20)				--合约名称
	_DefFld("SampleNum", _String, 15)				--样本数量
	_DefFld("Rose", _String, 10)					--涨幅
	_DefFld("LastPrice", _String, 15)				--最新价
	_DefFld("StockPrice", _String, 20)				--取价方式
	_DefFld("BuyingCost", _String, 15)				--买入成本
	_DefFld("SellPrice", _String, 10)				--委卖价格
	_DefFld("SellQty", _String, 10)					--委卖数量
	_DefFld("Handicap", _String, 15)				--盘口
	_DefFld("DealQty", _String, 10)					--成交数量
	_DefFld("DealPrice", _String, 15)				--成交价格
	_DefFld("HaveQty", _String, 10)					--拥有数量
	_DefFld("AvlQty", _String, 10)					--可用数量
	_DefFld("BuyingQuantity", _String, 10)			--买盘数量
	_DefFld("SaveQty", _String, 10)					--留存量
	_DefFld("SavePos", _String, 5)					--留存
	_DefFld("NotSell", _String, 5)					--不卖出

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--委托表
_DefineEventObject StockOrderEvent _AS _Output
	_DefFld("PortID", _String, 25)					--组合号
	_DefFld("CorpCode", _String, 25)				--委托号
	_DefFld("Time", _String, 25)					--时间
	_DefFld("Date", _String, 40)					--日期
	_DefFld("IssueCode", _String, 15)				--合约
	_DefFld("IssueName", _String, 20)				--合约名称
	_DefFld("BuySell", _String, 10)
	_DefFld("EntrustQty", _String, 8)
	_DefFld("EntrustPrice", _String, 8)
	_DefFld("DealQty", _String, 15)
	_DefFld("AveragePrice", _String, 10)
	_DefFld("CancellationQty",_String,10)
	_DefFld("Market", _String, 10)
	_DefFld("Other", _String, 20)
	_DefFld("WorkingQty", _String, 25)				--挂单
	_DefFld("OrderAcceptNo", _String, 25)			--柜台号
	_DefFld("StatusFlag", _String, 1)				--1:可撤委托
	_DefFld("InvestorID", _String, 30)

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
_End

--成交表
_DefineEventObject StockExecuteEvent _AS _Output
	_DefFld("PortID", _String, 25)
	_DefFld("CorpCode", _String, 25)
	_DefFld("ExecNo", _String, 25)
	_DefFld("Date", _String, 40)
	_DefFld("IssueCode", _String, 15)
	_DefFld("IssueName", _String, 20)
	_DefFld("BuySell", _String, 10)
	_DefFld("EntrustQty", _String, 25)
	_DefFld("EntrustPrice", _String, 25)
	_DefFld("DealQty", _String, 25)
	_DefFld("AveragePrice", _String, 25)
	_DefFld("CancellationQty", _String, 25)
	_DefFld("Explain", _String, 25)
	_DefFld("OrderAcceptNo", _String, 25)			--柜台号
	_DefFld("InvestorID", _String, 30)

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
_End

--持仓信息表
_DefineEventObject CombineInfoPosition _AS _Output
	_DefFld("IsChecked", _String, 1)				--勾选
	_DefFld("IssueCode", _String, 15)				--合约
	_DefFld("HaveQty", _String, 10)					--拥股数量
	_DefFld("AvlQty", _String, 10)					--可用数量
	_DefFld("CanFundNo", _String, 15)				--可申赎数
	_DefFld("CostPrice", _String, 15)				--成本价
	_DefFld("LastPrice", _String, 15)				--现价
	_DefFld("MarketValue", _String, 15)				--市值
	_DefFld("FloatStatus", _String, 15)				--浮动盈亏
	_DefFld("ProfitAndLoss", _String, 15)			--盈亏比
	_DefFld("Market", _String, 10)					--市场
	_DefFld("ShareholderNo", _String, 15)			--股东代码
	_DefFld("TodayBuyQty", _String, 10)				--当日买入数量
	_DefFld("TodaySellQty", _String, 10)			--当日卖出数量

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--套利持仓信息表
_DefineEventObject ArbitragePositionInfo _AS _Output
	_DefFld("CombinCode", _String, 100)				--组合号
	_DefFld("BAMapID", _String, 25)					--账号
	_DefFld("IssueCode", _String, 15)				--合约
	_DefFld("IssueName", _String, 20)				--名称
	_DefFld("ArbitrageQty", _String, 10)			--组合持仓量
	_DefFld("AvlQty", _String, 10)					--可用数量
	_DefFld("CostPrice", _String, 15)				--成本价
	_DefFld("Rose", _String, 10)					--涨幅
	_DefFld("BuySell", _String, 10)					--买卖
	_DefFld("ValuationPL", _String, 15)				--浮动盈亏
	_DefFld("LastPrice", _String, 15)				--最新价
	_DefFld("InvestorID", _String, 30)

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--勾选持仓
_DefineEventObject InputPositionCheck _AS _Input
	_DefFld("IssueCode", _String, 8)
	_DefFld("IsChecked", _String, 1);
_End
----------------------------现货相关表End----------------------------

---------------------------期货相关表Begin---------------------------
--期货建仓表
_DefineEventObject FutureOpenPosTable _AS _Output
	_DefFld("IssueCode", _String, 15)
	_DefFld("Rose", _String, 10)
	_DefFld("LastPrice", _String, 15)
	_DefFld("BuySell", _String, 8)
	_DefFld("OpenClose", _String, 8)
	_DefFld("FuturePrice", _String, 15)
	_DefFld("EntrustPrice", _String, 15)
	_DefFld("EntrustQty", _String, 10)
	_DefFld("DealQty", _String, 10)
	_DefFld("DealPrice", _String, 15)

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--期货平仓表
_DefineEventObject FutureClosePosTable _AS _Output
	_DefFld("IssueCode", _String, 15)
	_DefFld("Rose", _String, 10)
	_DefFld("LastPrice", _String, 15)
	_DefFld("BuySell", _String, 8)
	_DefFld("OpenClose", _String, 8)
	_DefFld("FuturePrice", _String, 15)
	_DefFld("EntrustPrice", _String, 15)
	_DefFld("EntrustQty", _String, 10)
	_DefFld("DealQty", _String, 10)
	_DefFld("DealPrice", _String, 15)

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--委托表
_DefineEventObject FutureOrderEvent _AS _Output
	_DefFld("PortID", _String, 25)					--组合号
	_DefFld("CorpCode", _String, 25)				--委托号
	_DefFld("IssueCode", _String, 15)				--合约
	_DefFld("BuySell", _String, 8)					--买卖
	_DefFld("OpenClose", _String, 8)				--开平
	_DefFld("EntrustPrice", _String, 15)     		--委托价格
	_DefFld("EntrustQty", _String, 10)				--委托手数
	_DefFld("Status", _String, 20)					--委托状态
	_DefFld("DealPrice",_String,10)					--成交价
	_DefFld("DealQty",_String,10)					--成交手数
	_DefFld("WorkingQty", _String, 10)				--挂单数量
	_DefFld("CancellationQty", _String, 10)			--撤单数量
	_DefFld("BatchNumber", _String, 12)				--批号
	_DefFld("Date", _String, 40)         			--交易时间
	_DefFld("InvestorID", _String, 30)

	_DefFld("StatusFlag", _String, 1)				--1:可撤委托

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
_End

--成交表
_DefineEventObject FutureExecuteEvent _AS _Output
	_DefFld("PortID", _String, 25)					--组合号
	_DefFld("CorpCode", _String, 25)
	_DefFld("ExecNo", _String, 25)
	_DefFld("Date", _String, 40)
	_DefFld("IssueCode", _String, 15)
	_DefFld("BuySell", _String, 10)
	_DefFld("OpenClose", _String, 10)
	_DefFld("DealQty", _String, 25)
	_DefFld("DealPrice", _String, 20)
	_DefFld("CancellationQty", _String, 25)
	_DefFld("OrderAcceptNo", _String, 25)
	_DefFld("Status", _String, 20)
	_DefFld("InvestorID", _String, 30)

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
_End



--套利持仓表
_DefineEventObject FutureArbitragePosInfo _AS _Output
	_DefFld("CombinCode", _String, 100)
	_DefFld("BAMapID", _String, 25)
	_DefFld("IssueCode", _String, 25)
	_DefFld("Position", _String, 25)
	_DefFld("AvlQty", _String, 25)
	_DefFld("AverageCost", _String, 25)
	_DefFld("Rose", _String, 25)
	_DefFld("BuySell", _String, 25)
	_DefFld("ValuationPL", _String, 25)
	_DefFld("LastPrice", _String, 25)
	_DefFld("InvestorID", _String, 30)

	_DefKeyField("IssueCode")
	_DefKeyField("BuySell")
	_SetBufferedFlag(2)
_End
---------------------------------XH----------------------------------
--------------------------下单控件事件Begin--------------------------
--自动下单成功后通知界面
_DefineEventObject Notice _AS _Output
	_DefFld("PortID", _String, 30)
	_DefFld("OC", _String, 25)
	_DefFld("StockStatus", _String, 25)
	_DefFld("FutureStatus", _String, 25)

_End

--显示盘口基差和基差
_DefineEventObject ShowBasisBets _AS _Output
	_DefFld("OpenBasis", _String, 25)
	_DefFld("CloseBasis", _String, 25)
	_DefFld("OpenBets", _String, 25)
	_DefFld("CloseBets", _String, 25)
	_DefFld("gPortID", _String, 30)
_End

--接收开仓股票期货数据事件
_DefineEventObject GetBuyOrderLog _AS _Input
	_DefFld("Open", _String, 20);        -- 开仓类型
_End

--接收平仓股票期货数据事件
_DefineEventObject GetSellOrderLog _AS _Input
	_DefFld("Close", _String, 20);       -- 平仓类型
_End



--根据CorpCode撤单
_DefineEventObject CancelOrder _AS _Input
	_DefFld("CancelIssue", _String, 20);
_End

--追全单
_DefineEventObject AllAmendOrder _AS _Input
	_DefFld("AllAmend", _String, 20);	 -- 开全追/平全追
_End

--追单
_DefineEventObject AmendOrder _AS _Input
	_DefFld("AmendIssue", _String, 20);
_End

--自动开平仓
_DefineEventObject AutoOrder _AS _Input
	_DefFld("State", _String, 20); -- 自动开/自动平

	_DefFld("Basis1", _String, 20);  -- 基差
	_DefFld("CloseTouch1", _String, 20);   -- 触发单选
	_DefFld("Close1", _String, 8);     -- 自动关闭勾选状态
	_DefFld("Ss1", _String, 8);   -- 秒数
	_DefFld("Yes1", _String, 20);  -- 是否确认委托
	_DefFld("OnOff1", _String, 20);  -- 开仓开关

	_DefFld("Basis2", _String, 20);  -- 基差
	_DefFld("CloseTouch2", _String, 20);   -- 触发单选
	_DefFld("Close2", _String, 8);     -- 自动关闭勾选状态
	_DefFld("Ss2", _String, 8);   -- 秒数
	_DefFld("Yes2", _String, 20);  -- 是否确认委托
	_DefFld("OnOff2", _String, 20);  -- 是否确认委托

	--Open
	_DefFld("OpenPortID", _String, 20);  -- 组合号
	_DefFld("OpenstockQty", _String, 20);  -- 股票份数
	_DefFld("OpenstockGetPice", _String, 20);   -- 股票取价方式
	_DefFld("Openstocktick", _String, 8);     -- 股票取价步长
	_DefFld("OpenfutureQty", _String, 8);   -- 期货份数
	_DefFld("OpenfutureGetPice	", _String, 20);  -- 期货取价方式
	_DefFld("Openfuturetick", _String, 20);  -- 期货取价步长

	--Close
	_DefFld("ClosePortID", _String, 20);  -- 组合号
	_DefFld("ClosestockQty", _String, 20);  -- 股票份数
	_DefFld("ClosestockGetPice", _String, 20);   -- 股票取价方式
	_DefFld("Closestocktick", _String, 8);     -- 股票取价步长
	_DefFld("ClosefutureQty", _String, 8);   -- 期货份数
	_DefFld("ClosefutureGetPice	", _String, 20);  -- 期货取价方式
	_DefFld("Closefuturetick", _String, 20);  -- 期货取价步长

	_DefFld("OldStockStatus", _String, 20);  -- 旧的股票状态
	_DefFld("OldFutureStatus", _String, 20);  -- 旧的期货状态
_End

_DefineEventObject OrderOutBox _AS _Output
	_DefFld("PortID", _String, 20);
	_DefFld("PortName", _String, 20);
	_DefFld("OC", _String, 20);
	_DefFld("IF", _String, 20);

_End

_DefineEventObject YesOrder _AS _Output
	_DefFld("PortID", _String, 20);
	_DefFld("PortName", _String, 20);
	_DefFld("OC", _String, 20);
	_DefFld("Status", _String, 20);
_End

--系统日志
_DefineEventObject SystemLog _AS _Output
	_DefFld("LogTime", _String, 12);
	_DefFld("LogMessage", _Meta, 4);
	_SetBufferedFlag(1);
_End;

_DefineEventObject SetBAMapID _AS _Input
	_DefFld("Flag", _String, 20)
	_DefFld("StockInvestorID", _String, 20)
	_DefFld("FutureInvestorID", _String, 20)
_End

--Change开平仓价格数量
--股票开仓份数
_DefineEventObject openStockQty _AS _Input
	_DefFld("OpenStockQty", _String, 20);   -- 股票委托份数
_End

--股票开仓取价方式
_DefineEventObject openStockPrice _AS _Input
	_DefFld("OpenStockPrice", _String, 20);   -- 股票委托份数
_End

--股票开仓价格浮动
_DefineEventObject openStockchange _AS _Input
	_DefFld("OpenStockchange", _String, 20);   -- 股票委托份数
_End

--期货开仓份数
_DefineEventObject openFutureQty _AS _Input
	_DefFld("OpenFutureQty", _String, 20);   -- 股票委托份数
_End

--期货开仓取价份数
_DefineEventObject openFuturePrice _AS _Input
	_DefFld("OpenFuturePrice", _String, 20);   -- 股票委托份数
_End

--期货开仓价格浮动
_DefineEventObject openFuturechange _AS _Input
	_DefFld("OpenFuturechange", _String, 20);   -- 股票委托份数
_End


--股票平仓取价方式
_DefineEventObject closeStockPrice _AS _Input
	_DefFld("CloseStockPrice", _String, 20);   -- 股票委托份数
_End

--股票平仓价格浮动
_DefineEventObject closeStockchange _AS _Input
	_DefFld("CloseStockchange", _String, 20);   -- 股票委托份数
_End


--期货平仓取价方式
_DefineEventObject closeFuturePrice _AS _Input
	_DefFld("CloseFuturePrice", _String, 20);   -- 股票委托份数
_End

--期货平仓价格浮动
_DefineEventObject closeFuturechange _AS _Input
	_DefFld("CloseFuturechange", _String, 20);   -- 股票委托份数
_End
---------------------------下单控件事件End---------------------------
---------------------------柜台资金事件------------------------------
--建仓刷新资金界面事件
_DefineEventObject refreshFund _AS _Input

_End


--发送柜台资金信息显示
_DefineEventObject sendFundOut _AS _Output
	_DefFld("stockAvlFund", _String, 30)
	_DefFld("stockOrderFund", _String, 30)
	_DefFld("stockAssetValue", _String, 30)
	_DefFld("stockMargin", _String, 30)
	_DefFld("stockBalance", _String, 30)

	_DefFld("futureAvlFund", _String, 30)
	_DefFld("futureOrderFund", _String, 30)
	_DefFld("futureAssetValue", _String, 30)
	_DefFld("futureMargin", _String, 30)
	_DefFld("futureBalance", _String, 30)

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--发送柜台持仓信息显示
_DefineEventObject CombineInfoPos _AS _Output
	_DefFld("InvestorID", _String, 30)
	_DefFld("BuySell", _String, 30)
	_DefFld("IssueName", _String, 30)
	_DefFld("IssueCode", _String, 20)
	_DefFld("MarketType", _String, 20)
	_DefFld("Quantity", _String, 30)
	_DefFld("ReportQty", _String, 30)

	_DefFld("RedeemQty", _String, 30)
	_DefFld("AvQty", _String, 30)
	_DefFld("AvSellQty", _String, 30)
	_DefFld("AvePrice", _String, 30)
	_DefFld("Margin", _String, 30)
	_DefFld("PL", _String, 30)
	_DefFld("CostValue", _String, 30)

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--发送柜台持仓信息显示
_DefineEventObject FutCombinPos _AS _Output
	_DefFld("InvestorID", _String, 30)
	_DefFld("BuySell", _String, 30)
	_DefFld("IssueName", _String, 30)
	_DefFld("IssueCode", _String, 20)
	_DefFld("MarketType", _String, 20)
	_DefFld("Quantity", _String, 30)
	_DefFld("AvQty", _String, 30)
	_DefFld("AvSellQty", _String, 30)
	_DefFld("AvePrice", _String, 30)
	_DefFld("Margin", _String, 30)
	_DefFld("PL", _String, 30)
	_DefFld("CostValue", _String, 30)

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

_DefineEventObject SetRateEvent _AS _Input
_End

_DefineEventObject SetRateEventData _AS _Output
    _DefFld("SHBuyFare", _String, 12)  --上海买入佣金费率
	_DefFld("SHSellFare", _String, 12) --上海卖出佣金费率
	_DefFld("SHBuyStampTax", _String, 12)--上海买入印花税率
	_DefFld("SHSellStampTax", _String, 12)--上海卖出印花税率
	_DefFld("SHBuyTransferExpense", _String, 12)--上海买入过户税率
	_DefFld("SHSellTransferExpense", _String, 12)--上海卖出过户税率
	_DefFld("SZBuyFare", _String, 12)--深证买入佣金费率
	_DefFld("SZSellFare", _String, 12)--深证卖出佣金费率
	_DefFld("SZBuyStampTax", _String, 12)--深证买入印花税率
	_DefFld("SZSellStampTax", _String, 12)--深证卖出印花税率
	_DefFld("BuyRatio", _String, 12)--中金所买入佣金费率
	_DefFld("SellRatio", _String, 12)--中金所卖出佣金费率
	_DefFld("BuyTCloseRatio", _String, 12)--中金所买入平今仓
	_DefFld("SellTCloseRatio", _String, 12)--中金所卖出平今仓
	_DefFld("BuyHCloseRatio", _String, 12)--中金所买入平历史仓
	_DefFld("SellHCloseRatio", _String, 12)--中金所买入平历史仓
	_DefFld("BalanceRatio", _String, 12)--中金所保证金比例
	_DefFld("FundYearRate", _String, 12)--中金所资金年利率

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

_DefineEventObject SaveArbitrageInfo _AS _Output
    _DefFld("PortID",_String,48)--组合号
	_DefFld("StartTime",_String,48)--开仓时间
	_DefFld("EndTime",_String,48)--平仓时间
	_DefFld("BuyAmount",_String,12) --现货买入金额
	_DefFld("SpotBuyChargeCost",_String,12)--现货买入冲击成本
	_DefFld("SellAmount",_String,12)--现货卖出金额
	_DefFld("SpotSellChargeCost",_String,12)--现货卖出冲击成本
	_DefFld("SpotTradeFee",_String,12)--现货交易费用
	_DefFld("SpotGainLoss",_String,12)--现货盈亏
	_DefFld("OpenPrice",_String,12)--建仓均价
	_DefFld("FutureBuyChargeCost",_String,12)--冲击成本
	_DefFld("OpenQtySum",_Int,4)--建仓总数量
	_DefFld("ClosePrice",_String,12)--平仓均价
	_DefFld("FutureSellChargeCost",_String,12)--冲击成本
	_DefFld("CloseQtySum",_Int,4)--平仓总数量
	_DefFld("FutureTradeFee",_String,12)--交易费用
	_DefFld("FutureGainLoss",_String,12)--期货盈亏
	_DefFld("OpenHS300Price",_String,12)--建仓沪深300的最新价
	_DefFld("CloseHS300Price",_String,12)--平仓沪深300的最新价
	_DefFld("OpenFuturePrice",_String,12)--建仓期指的最新价
	_DefFld("CloseFuturePrice",_String,12)--平仓期指的最新价

	_DefKeyField("PortID")
_End
