﻿--跨期套利初始版1.01
--Release version:1.001.20141126
--套利持仓添加汇总行实时盈亏计算,实时盈亏 = 平仓盈亏 + 浮动盈亏
--套利列表修改实时盈亏,实时盈亏 = 平仓盈亏 + 浮动盈亏
--Release version: 1.001.20141119
--修正自动开仓获取数据错误的BUG
--将多仓空仓修改为近月远月
--Release version: 1.001.20140305
_WriteAplLog("跨期套利初始版 Version:2.003 2014-03-05")

require("Position")
require("DefineEvent_KQ")
require("Trade_KQ")
require("Z_OnEvent_KQ")


_DefineStrategyParameters
	_Number _Refreash = 5					_Comment	"组合持仓刷新时间"
_End

-----------------
--Pos库调用函数--
-----------------
init()
function init()
	_InitializeFlag = 0					--初始化完成

	gStrDate = _PosGetYMD()
	gtFutureList = {}
	gFutureNo = 0
	gtHisData ={}
	_PriceTable ={}
	_logNo = 0
	gUserID = _GetDealerID()
	gtBackHand = {}					--反手委托表
	gAccountList={}					--资金账号表
	gQueryFund = {}					--柜台资金信息表
	gtPositionTable = {}			--持仓表
	gFuturebaMapID = ""				--期货账号
	gtInvestorIDMap = {}			--柜台账户查找下单账户
	gtOrderList = {}		    	--委托表 gtOrderList[PortID].FutureOpen[CorpCode].各个字段 gtOrderList[PortID].FutureClose[CorpCode].各个字段
	preClose ={}
	k1Min={}
	_IsHDSRegistered = {}			--订阅HDS行情
	gtPriceTable = {}				--行情表
	currentTime="091600"

	initk1Min()						--图表时间格式

	gtFoldExist = {}				--套利持仓折叠表
	gtCombinList = {}				--跨期套利组合表
	gtArbitragePositionTable = {}	--套利持仓表
	HS300preClose =0

	gkaiguan1 = "1"
	gkaiguan2 = "1"

	gtOrderMessage = {}             --止盈止损下单数据临时存储表
	gtCloseUpDown = {}              --止盈止损数据存表
	gtUpDownKaiGuan = {}            --止盈止损开关表
	gtKQOrderList = {}              --手动下单时存储另一边的下单数据
	gtAutoOrderList = {}
	gtBasis = {}
	gtBasis.Price1 = "自动盘口"
	gtBasis.Tick1  = "不浮动"
	gtBasis.Price2 = "自动盘口"
	gtBasis.Tick2  = "不浮动"
	gtBasis.Price3 = "自动盘口"
	gtBasis.Tick3  = "不浮动"
	gtBasis.Price4 = "自动盘口"
	gtBasis.Tick4  = "不浮动"

	gFutureCurrent = ""             --当月
	gFutureNextMonth = ""  			--下月
	gFutureSeasonMonth = ""			--下季
	gFutureNextSeason = ""			--远月


	gHedgeFlag = "0"				--交易编码
	--单笔委托--
	_Querylist = {}					--单笔合约维护表
	_QueryIssue = ""				--单笔委托中当前显示合约
	_DD = 0							--单笔委托资金状况显示标识
	_QueryTable = {}				--单笔委托中资金状况显示使用表
	_gRefreash = _Refreash
	TT = 0

	--注册M000300HDS-1m输出事件
	_IsHDSRegistered["M000300"] = _IsHDSRegistered["M000300"] or {}
	local DTSTime nowtime = _GetNowTime();
	local StartTime = gStrDate .. "000000000000"
	local EndTime = gStrDate .. "235900000000"
	local cond = sys_format("IssueCode#%s;_TimeKey#%s:%s","M000300", StartTime, EndTime)
	_RegisterEventObject(PortfolioID="HDS_PID" , StrageyID="HDS_SID", EventID="k1mEvent", condition=cond);
	local log = "Register k1mEvent:" .. cond
	_WriteErrorLog(log)
	---------------

	_RegisterPrice(_IssueCode = "M000300", _MarketCode = "1")
	--getHisData("M000300")
	--找出当前交易的四个股指期货合约及各自的上市日期
	local issueMasterCondition = "ExpirationDate >= '"..gStrDate.."' and UnderlyingAssetCode = 'IF' and ProductCode = '31' and IssueCode IN (select IssueCode from IssueMarketTable where MarketCode = '3' and ListedDate <= '"..gStrDate.."') ORDER BY IssueCode";
	_GetCommonData(dataName = "IssueMaster", condition = issueMasterCondition, tablename = "IssueMaster");

	ReadFuture() -- 发送4个期货到界面

	--注册对应期货合约HDS-1m输出事件
	for i,issueCode in pairs(gtFutureList) do
		--获取股指历史数据
		--getHisData(v)
		--从HDS读当天的历史K线数据
		------QYM------
		_IsHDSRegistered[issueCode] = _IsHDSRegistered[issueCode] or {}
		local DTSTime nowtime = _GetNowTime();
		local StartTime = gStrDate .. "000000000000"
		local EndTime = gStrDate .. "235900000000"
		local cond = sys_format("IssueCode#%s;_TimeKey#%s:%s",issueCode, StartTime, EndTime)
		_RegisterEventObject(PortfolioID="HDS_PID" , StrageyID="HDS_SID", EventID="k1mEvent", condition=cond);
		local log = "Register k1mEvent:" .. cond
		_WriteErrorLog(log)
		---------------


	end
	--图形默认显示
	--showGraph(gtFutureList[0])

	PosInitialize()
	PosAddBAMapIDForCurrentUser()
	PosStart()
end

function OnPositionInitialized()
	getPreClose("M000300")
	for i,v in pairs(gtFutureList) do
		getPreClose(v)
	end
	local futureID = ""
	for baMapID, dummy in pairs(_PosUserBAMapTable[gUserID]) do
		local accountCode = _PosBAMapAccount[baMapID]
		if accountCode then
			if _PosFundStatus[accountCode] then
				local investorID = _PosFundStatus[accountCode].InvestorID
				local accountType = _PosFundStatus[accountCode].Type
				local condition = sys_sub(baMapID,-3,-1)
				if condition == "000" then
					if accountType == "F" then
						local fund = _PosFundStatus[accountCode].AvlFund
						fund = fund.getNumberValue();
						if fund < 1000000000 then				--000子账号添加资金满足子账号一定有钱
							local temp = 1000000000 - fund
							PosAdjustFund(accountCode, temp)
						end
						sys_insert(gAccountList,investorID)
						futureID = futureID .. investorID .. ";"
						gtInvestorIDMap[investorID] = baMapID 	 --建立一一对应表,统一用999子账户下单
					end
				end
			end
		end
	end

	--发送到界面账户列表
	local DTSEvent CreateFutureID = _CreateEventObject("CreateFutureIDEvent")
	CreateFutureID._SetFld("BAMapID",futureID)
	_SendToClients(CreateFutureID)

	DTSEvent SaveCombinDataEvent = _CreateEventObject("SaveCombinDataEvent");
	DTSDynamicData CombinDynamicData = _CreateDynamicData(TSInstanceName = "CombinDataList", fileType = _DataOtherType, SaveCombinDataEvent SaveCombinDataEvent);
	_WriteErrorLog("准备读取历史套利组合")
	CombinDynamicData._GetDynamicData(dataName = "CombinDataList", condition = "");

	--提示期货到期时间
	local issueCode = gtFutureList[0]
	local ExpirationDate = _PosIssueExpirationDateTable[issueCode]
	local numExpirationDate = ExpirationDate.getNumberValue()
	local RemainderDate = 1
	local TradingDate = _PosComingTradingDate[1]
	TradingDate = TradingDate.getNumberValue()

	while numExpirationDate > TradingDate do
		TradingDate = _PosComingTradingDate[RemainderDate]
		TradingDate = TradingDate.getNumberValue()
		RemainderDate = RemainderDate + 1
	end

	log = sys_format("期货[%s]到期日期为[%s],共计[%s]个交易日",issueCode,ExpirationDate,RemainderDate)
	sendSysLog(log)

	if gFuturebaMapID ~= "" then
		local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
		if futureAccountCode then
			local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
			local clientID = _PosFundStatus[futureAccountCode].ClientID
			if futureInvestorID and clientID then
				--刷新柜台资金
				L2cQueryMarketFund(futureInvestorID, clientID, gFuturebaMapID)
				--刷新柜台持仓
				L2cQueryMarketPosition(futureInvestorID,clientID, gFuturebaMapID,"")
			end
		end
	end

	_InitializeFlag = 1						--初始化完成
	_WriteErrorLog("POS库初始化完毕")

	_StartTimer(_TimerName="TimeInterval",_Interval=1000)

	sendSysLog("初始化完成。")
end


function OnPositionError(errorInfo)
--本模块发现错误时调用，逻辑由策略填写，比如输出到界面或写日志。
--errorInfo：出错信息，字符串 。

end

function OnBackTestDayEnd()

end

function OnExecution(position, exec)
--新成交，exec结构参见OpenExecList 。

end

function OnOrder(position, order)

end

function OnPositionChanged(position, reason)
--持仓变化时调用，逻辑由策略填写。
--position 变化的持仓，结构见数据接口；
--reason 变化原因POS_REASON_ORDER_CHANGE或POS_REASON_PRICE_CHANGE。

end

function OnPrice(issueCode, priceInfo)
	--_WriteAplLog("OnPrice#########")
end

--------------
--查询数据库--
--------------
--找出当前交易的四个股指期货合约
_OnCommonData(dataName = "IssueMaster", DTSIssueMaster issueMaster)
	local issueCode = issueMaster.getIssueCode();
	local gFutureMarket = issueMaster.getPriorMarket();
	sendFlPriceEvt(issueCode,"-","-","-","-","-","-")
	sendFlPriceEvt2(issueCode,"-","-","-","-","-","-")
	if gFutureNo == 0 then
		gtFutureList[0] = issueCode;--当月
		gFutureCurrent = issueCode
	elseif gFutureNo == 1 then
		gtFutureList[1] = issueCode;--次月
		gFutureNextMonth = issueCode
	elseif gFutureNo == 2 then
		gtFutureList[2] = issueCode;--季月
		gFutureSeasonMonth = issueCode
	elseif gFutureNo == 3 then
		gtFutureList[3] = issueCode;--隔季
		gFutureNextSeason = issueCode
	else
		_WriteAplLog("Future record error!");
	end
	_RegisterPrice(_IssueCode = issueCode, _MarketCode = gFutureMarket)
	gFutureNo = gFutureNo + 1;
_End

----------------
--事件回调定义--
----------------
_OnDynamicData(_dataName="CombinDataList", SaveCombinDataEvent evt)		--读取历史组合
	local CombinCode = evt._GetFld("CombinCode");
	local InvestorID = evt._GetFld("InvestorID");
	local Issue1 = evt._GetFld("Issue1");
	local Issue2 = evt._GetFld("Issue2");
	local Status = evt._GetFld("Status");
	local AvlQty = evt._GetFld("AvlQty");
	local BuyQty = evt._GetFld("BuyQty");
	local SellQty = evt._GetFld("SellQty");
	local InPrice = evt._GetFld("InPrice");
	local OutPrice = evt._GetFld("OutPrice");
	local buyOutAmount = evt._GetFld("buyOutAmount");
	local buyOutQty = evt._GetFld("buyOutQty");
	local sellOutAmount = evt._GetFld("sellOutAmount");
	local sellOutQty = evt._GetFld("sellOutQty");
	local Fare = evt._GetFld("Fare");

	gtCombinList[CombinCode] = {}
	gtCombinList[CombinCode].Issue1 = Issue1
	gtCombinList[CombinCode].Issue2 = Issue2
	gtCombinList[CombinCode].Status = Status
	gtCombinList[CombinCode].AvlQty = AvlQty
	gtCombinList[CombinCode].BuyQty = BuyQty
	gtCombinList[CombinCode].SellQty = SellQty
	gtCombinList[CombinCode].InPrice = InPrice
	gtCombinList[CombinCode].OutPrice = OutPrice
	gtCombinList[CombinCode].buyOutAmount = buyOutAmount
	gtCombinList[CombinCode].buyOutQty = buyOutQty
	gtCombinList[CombinCode].sellOutAmount = sellOutAmount
	gtCombinList[CombinCode].sellOutQty = sellOutQty
	gtCombinList[CombinCode].Fare = Fare
	gtCombinList[CombinCode].StopFlag = "止盈止损启动"
	gtCombinList[CombinCode].InvestorID = InvestorID
_End

_OnDynamicData(_dataName="k1m" ,k1mEvent evt);
    local issue = evt._GetFld("IssueCode")
    local close = evt._GetFld("ClosePrice")
    local time = evt._GetFld("Time")
	local log = sys_format("k1m:IssueCode:%s,ClosePrice:%s,Time:%s",issue,close,time)
	_WriteAplLog(log)
	if gtHisData[issue][time]==nil then
		gtHisData[issue][time] = close.getNumberValue()
	end
_End;

-- HS300昨收价加载
_OnDynamicData(dataName="k1d",k1dEvent k1dEvent)
	local  closePrice = k1dEvent._GetFld("ClosePrice")
	local _String issueCode = k1dEvent._GetFld("IssueCode")
	closePrice = closePrice.getNumberValue()
	local log = sys_format("k1d:IssueCode%s;ClosePrice:%s", issueCode, closePrice)
	_WriteAplLog(log)
	preClose[issueCode] = closePrice
_End

--选择跨期股指组合
_OnEventDefined(selSp selSp)
	--选中行合约
	local Issue1 = selSp._GetFld("Issue1")
	--跨期组合另一腿（选中列合约）
	local Issue2 = selSp._GetFld("Issue2")
	--获取取价方式计算基差
	local issuetype = sys_sub(Issue2,1,2)
	if Issue1 ~= Issue2 and issuetype == "IF" then
		local month1 = sys_sub(Issue1,3,-1)
		local month2 = sys_sub(Issue2,3,-1)
		month1 = month1.getNumberValue()
		month2 = month2.getNumberValue()
		if month1 > month2 then
			gtBasis.Issue1 = Issue2
			gtBasis.Issue2 = Issue1
		else
			gtBasis.Issue1 = Issue1
			gtBasis.Issue2 = Issue2
		end
		refreshBasis()
	end
	gklineType = "0"
	gIssue1 = Issue1
	gIssue2 = Issue2

	Refreshkline(Issue1,Issue2)
_End

--确认账号选择回调
_OnEventDefined(SetBAMapID stockID)
	_WriteErrorLog("SetBAMapID begin")
	if _InitializeFlag == 1 then
		local futureInvestorID = stockID._GetFld("FutureInvestorID");
		local flag = stockID._GetFld("Flag");
		local log = sys_format("SetBAMapID:futureInvestorID[%s],flag[%s]",futureInvestorID,flag)
		_WriteErrorLog(log)
		if flag == "确认账号" then
			if futureInvestorID and futureInvestorID ~= "" then
				gFuturebaMapID = gtInvestorIDMap[futureInvestorID]
				local log = sys_format("SetBAMapID:FuturebaMapID[%s]",gFuturebaMapID)
				_WriteErrorLog(log)
				ClearTable()

				for CombinCode, info in pairs (gtCombinList) do
					SendCombinList(CombinCode,futureInvestorID)					--刷新套利组合表
				end

				RefreshArbitragePosition();	--刷新套利持仓

				gtPositionTable = {}		--重新读取柜台持仓数据

				if _PosBAMapAccount[gFuturebaMapID] then
					local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
					if futureAccountCode and _PosFundStatus[futureAccountCode] then
						local clientID = _PosFundStatus[futureAccountCode].ClientID
						--刷新柜台资金
						L2cQueryMarketFund(futureInvestorID, clientID, gFuturebaMapID)
						--刷新柜台持仓
						L2cQueryMarketPosition(futureInvestorID,clientID, gFuturebaMapID,"")
					end
				end
			else
				sendSysLog("资金账户设置错误")
				local log = sys_format("futureInvestorID[%s]",futureInvestorID)
				_WriteErrorLog(log)
			end
		elseif flag == "更换账号" then
			--清除账户信息
			gFuturebaMapID = ""
			--清空之前账户套利持仓
			local DTSEvent Arbitrage = _CreateEventObject("FutureArbitragePosInfo")
			Arbitrage._SetFld("CombinCode","clear")
			_SendToClients(Arbitrage)
			gtFoldExist = {}		--清空表头标志

			--清空套利列表持仓数量
			for CombinCode, info in pairs (gtCombinList) do
				SendCombinList(CombinCode,"")
			end
		else
			if _PosBAMapAccount[gFuturebaMapID] then
				local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
				if futureAccountCode and _PosFundStatus[futureAccountCode] then
					local clientID = _PosFundStatus[futureAccountCode].ClientID
					local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
					if clientID and futureInvestorID then
						--刷新柜台资金
						L2cQueryMarketFund(futureInvestorID, clientID, gFuturebaMapID)
						--刷新柜台持仓
						L2cQueryMarketPosition(futureInvestorID,clientID, gFuturebaMapID,"")
					end
				end
			end
		end
	else
		sendSysLog("初始化还没有完成")
	end
_End


_OnEventDefined(RefreshFund refresh)							--刷新柜台资金持仓
	if _InitializeFlag == 1 then
		_WriteErrorLog("refreshFund")
		if _PosBAMapAccount[gFuturebaMapID] then
			local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
			if futureAccountCode then
				local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
				local clientID = _PosFundStatus[futureAccountCode].ClientID

				gtPositionTable = {}		--重新读取柜台持仓数据
				--刷新资金柜台
				L2cQueryMarketFund(futureInvestorID, clientID, gFuturebaMapID)
				--刷新持仓柜台
				L2cQueryMarketPosition(futureInvestorID,clientID,gFuturebaMapID,"")
			end
		end
	else
		sendSysLog("初始化还没有完成")
	end
_End

--删除套利
_OnEventDefined(CombinControl3 Combin)
	local CombinCode = Combin._GetFld("CombinCode")
	if CombinCode and CombinCode ~= "" then
		SaveCombinDataEvent._SetFld("CombinCode", CombinCode);
		CombinDynamicData._Clear()
		gtCombinList[CombinCode] = nil

		local DTSEvent combin = _CreateEventObject("CombinList")
		combin._SetFld("CombinCode",CombinCode)
		combin._SetFld("clear","1")
		_SendToClients(combin)

		local DTSEvent Arbitrage = _CreateEventObject("FutureArbitragePosInfo")
		local UniqueKeyCode = "表头" .. CombinCode
		Arbitrage._SetFld("CombinCode",CombinCode)
		Arbitrage._SetFld("UniqueKeyCode",UniqueKeyCode)
		Arbitrage._SetFld("MainRowFlag","1")
		Arbitrage._SetFld("clear","1")
		_SendToClients(Arbitrage)
		gtFoldExist[CombinCode] = nil			--清空表头标志

		gtUpDownKaiGuan[CombinCode] = nil-- 清开关
	end
_End
--清空套利
_OnEventDefined(CombinControl4 Combin)
	for CombinCode,value in pairs(gtCombinList) do
		SaveCombinDataEvent._SetFld("CombinCode", CombinCode);
		CombinDynamicData._Clear()
	end
	gtCombinList = {}

	local DTSEvent combin = _CreateEventObject("CombinList")
	combin._SetFld("CombinCode","clear")
	_SendToClients(combin)

	local DTSEvent Arbitrage = _CreateEventObject("FutureArbitragePosInfo")
	Arbitrage._SetFld("CombinCode","clear")
	_SendToClients(Arbitrage)
	gtFoldExist = {}			--清空表头标志

	gtUpDownKaiGuan = {}-- 清开关

_End

_OnEventDefined(AmendSingleOrder aoEvent,sessionID)				--改价
	if _InitializeFlag == 1 then
		local corpCode = aoEvent._GetFld("CorpCode")
		local IssueCode = aoEvent._GetFld("IssueCode")
		local BuySell = aoEvent._GetFld("BuySell")
		local OrderPrice = aoEvent._GetFld("OrderPrice")
		local log = sys_format("改价下单:CorpCode:%s,IssueCode:%s,BulSell:%s,OrderPrice:%s",corpCode,IssueCode,BuySell,OrderPrice)
		_WriteAplLog(log)
		if corpCode and IssueCode and BuySell then
			local ret = PosAmendOrder(corpCode, OrderPrice)
			if ret.Result then
			else
				local log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
				_WriteAplLog(log)
				log = sys_format("下单错误原因：[%s]",ret.Reason)
				sendSysLog(log)
			end
		else
			sendSysLog("系统找不到改价单或价格")
		end
	else
		sendSysLog("初始化还没有完成")
	end
_End

_OnEventDefined(CancelSingleOrder coEvent,sessionID)			--撤单
	if _InitializeFlag == 1 then
		local corpCode = coEvent._GetFld("CorpCode")
		local log = sys_format("撤单:交易号:%s",corpCode)
		_WriteAplLog(log)
		sendSysLog(log)
		if corpCode then
			local ret = PosCancelOrder(corpCode)
			if ret.Result then
			else
				log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
				_WriteAplLog(log)
				log = sys_format("下单错误原因：[%s]",ret.Reason)
				sendSysLog(log)
			end
		else
			sendSysLog("系统找不到改价单")
		end
	else
		sendSysLog("初始化还没有完成")
	end
_End

_OnEventDefined(QueryCloseFund qfEvent)							--平仓查询资金状况回调
	if _InitializeFlag == 1 then
		local issueCode = qfEvent._GetFld("IssueCode")
		local BAMapID = qfEvent._GetFld("BAMapID")
		local CombinCode = qfEvent._GetFld("CombinCode")
		local market = _PosIssueMarketTable[issueCode]
		_DD = 0
		if market then
			_QueryIssue = issueCode
			_PosRegisterPrice(issueCode)
			if market=="1" or  market=="2"  then --股票

			else      --期货
				BAMapID = gFuturebaMapID
				if CombinCode == "" then
					local condition = sys_sub(gFuturebaMapID,1,-4)
					BAMapID = condition .. "999"			--柜台持仓委托使用-999子账号
				end
				local accountCode = _PosBAMapAccount[BAMapID]
				if _PosPriceTable[_QueryIssue] then
					sendFundReplyClose(BAMapID,accountCode,CombinCode)
				else
					_DD = 1
					_QueryTable["CombinCode"] = CombinCode
					_QueryTable["AccountCode"] = accountCode
					_QueryTable["BAMapID"] = BAMapID
				end
			end
		end
	else
		sendSysLog("初始化还没有完成")
	end
_End

_OnEventDefined(FireEvent fire,sessionID)						--单笔委托
	if _InitializeFlag == 1 then
		_WriteErrorLog("FireEvent...");

		local CombinCode = fire._GetFld("CombinCode");
		local BAMapID = fire._GetFld("BAMapID");
		local issueCode = fire._GetFld("IssueCode");
		local bs = fire._GetFld("BuySell");
		local oc = fire._GetFld("OpenClose");
		if gtArbitragePositionTable[CombinCode] or CombinCode == "" then
			if gFuturebaMapID ~= "" then
				local flag = 1
				local temp = sys_sub(issueCode,1,2);
				if not _PosPriceTable[issueCode] then
				   flag = 0
				end
				local market = _PosIssueMarketTable[issueCode]
				if market and flag==1 then
					if market=="1" or  market=="2" then --股票
						flag = 0
						sendSysLog("请输入期货合约")
					else     --期货
						BAMapID = gFuturebaMapID
						if CombinCode == "" then
							local condition = sys_sub(gFuturebaMapID,1,-4)
							BAMapID = condition .. "999"			--柜台持仓委托使用-999子账号
						end
					end
				else
					flag = 0
					sendSysLog("合约不存在或者没有行情")
				end
				if flag ~= 0 then
					--非上期若选择了平今指令，自动发出为平仓
					oc = oc.getNumberValue()	--add
					if _PosIssueMarketTable[issueCode] ~= "4" and oc == 2 then
						oc = 1
					end

					local basubID
					local BuySell = ""
					if oc == 0 then
						basubID = bs..CombinCode
						if bs == "1" then
							BuySell = "卖开仓"
						else
							BuySell = "买开仓"
						end
					else
						if bs == "1" then
							basubID = "3"..CombinCode
							BuySell = "卖平仓"
						else
							basubID = "1"..CombinCode
							BuySell = "买平仓"
						end
					end

					local Price = fire._GetFld("Price");
					local quantity = fire._GetFld("Quantity");
					local logs = sys_format("FireEvent:basubID:%s,BAMapID:%s, issue:%s,BuySell:%s,OpenClose:%s,quantity:%d",basubID,BAMapID,issueCode,bs,oc,quantity)
					_WriteErrorLog(logs)
					log = sys_format("组合号:[%s],BaMapID:[%s],下单合约:[%s],下单数量:[%s],价格:[%s],方向:[%s]",CombinCode,BAMapID,issueCode,quantity,Price,BuySell)
					sendSysLog(log)
					if BAMapID ~= "" then
						local ret = PosSubmitSingleOrder(BAMapID,basubID,issueCode,bs,oc, Price,quantity, 0, "",nil,gHedgeFlag);
						if ret.Result then
							--local log = sys_format("下单成功")
							--sendSysLog(log)
						else
							local log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
							_WriteErrorLog(log)
							log = sys_format("下单错误原因：[%s]",ret.Reason)
							sendSysLog(log)
						end
					end

				end
			else
				sendSysLog("单笔委托：请确认资金账号")
			end
		else
			sendSysLog("单笔委托：设置组合号不存在")
		end
	else
		sendSysLog("初始化还没有完成")
	end
_End;

_OnEventDefined(SetRateInEvent evt)					--交易编码设置
	if _InitializeFlag == 1 then
		local HedgeFlag = evt._GetFld("HedgeFlag")
		if HedgeFlag == "投机" then
			gHedgeFlag = "0"
		elseif HedgeFlag == "套保" then
			gHedgeFlag = "1"
		elseif HedgeFlag == "套利" then
			gHedgeFlag = "2"
		else
			gHedgeFlag = "0"
		end
		local log = sys_format("设置期货账号交易编码为[%s]",HedgeFlag)
		sendSysLog(log)
	else
		sendSysLog("初始化还没有完成")
	end
_End
--获取交易费率,深证我们取000001(平安银行)的费率为基准，上海我们取600000(浦发银行)的费率为基准，
--中金所我们取当月合约的费率。
_OnEventDefined(SetRateEvent evt)
	_WriteErrorLog("SetRateEvent")
	if _InitializeFlag == 1 then
		 local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	 if futureAccountCode then
		 local futureFareTable = _PosGetFare(futureAccountCode,gFutureCurrent)

		 local DTSEvent fareEvent = _CreateEventObject("SetRateEventData")
		 local buyRatio  = futureFareTable.OpenDropRatio or "-" --中金所买入佣金费率
		 if buyRatio ~= "-" then
			buyRatio = buyRatio * 1000
			buyRatio = sys_format("%.03f",buyRatio)
		 end
		 local sellRatio = futureFareTable.OpenDropRatio or "-" --中金所卖出佣金费率
		 if sellRatio ~= "-" then
			sellRatio = sellRatio * 1000
			sellRatio = sys_format("%.03f",sellRatio)
		 end
		 local buyTCloseRatio = futureFareTable.DropCuFareRatio or "-"--中金所买入平今仓
		 if buyTCloseRatio ~= "-" then
			buyTCloseRatio = buyTCloseRatio * 1000
			buyTCloseRatio = sys_format("%.03f",buyTCloseRatio)
		 end
		 local sellTCloseRatio  = futureFareTable.DropCuFareRatio or "-" --中金所卖出平今仓
		 if sellTCloseRatio ~= "-" then
			sellTCloseRatio = sellTCloseRatio * 1000
			sellTCloseRatio = sys_format("%.03f",sellTCloseRatio)
		 end
		 local buyHCloseRatio = futureFareTable.OpenDropRatio or "-" --中金所买入平历史仓
		 if buyHCloseRatio ~= "-" then
			buyHCloseRatio = buyHCloseRatio * 1000
			buyHCloseRatio = sys_format("%.03f",buyHCloseRatio)
		 end
		 local sellHCloseRatio = futureFareTable.OpenDropRatio or "-" --中金所买入平历史仓
		 if sellHCloseRatio ~= "-" then
			sellHCloseRatio = sellHCloseRatio * 1000
			sellHCloseRatio = sys_format("%.03f",sellHCloseRatio)
		 end

		 local balanceRatio = _PosGetBail(futureAccountCode, gFutureCurrent, "-", gHedgeFlag) or "-"--中金所保证金比例
		 if balanceRatio ~= "-" then
			balanceRatio = balanceRatio * 100
			balanceRatio = sys_format("%d",balanceRatio)
		 end
		 local fundYearRate  =  60.000 --中金所资金年利率
		 if fundYearRate ~= "-" then
			fundYearRate = sys_format("%.03f",fundYearRate)
		 end
		 local HedgeFlag = ""--"0\":投机,\"1\":套保,\"2\":套利
		if gHedgeFlag == "0" then
			HedgeFlag = "投机"
		elseif gHedgeFlag == "1" then
			HedgeFlag = "套保"
		elseif gHedgeFlag == "2" then
			HedgeFlag = "套利"
		end
		 fareEvent._SetFld("BuyRatio",buyRatio)
		 fareEvent._SetFld("SellRatio",sellRatio)
		 fareEvent._SetFld("BuyTCloseRatio",buyTCloseRatio)
		 fareEvent._SetFld("SellTCloseRatio",sellTCloseRatio)
		 fareEvent._SetFld("BuyHCloseRatio",buyHCloseRatio)
		 fareEvent._SetFld("SellHCloseRatio",sellHCloseRatio)
		 fareEvent._SetFld("BalanceRatio",balanceRatio)
		 fareEvent._SetFld("FundYearRate",fundYearRate)
		fareEvent._SetFld("HedgeFlag",HedgeFlag)
		 _SendToClients(fareEvent)
		 	else
		sendSysLog("资金账号不存在，请先确认资金账号,再查询费率")
	end
	else
		sendSysLog("初始化还没有完成")
	end
_End

--反手委托回调
_OnEventDefined(RrightBackHand RrightBackHandEvent)
	_WriteAplLog("RrightBackHand");

	if _InitializeFlag ~= 1 then	-- 第一次刷新完成
		sendSysLog("请等待程序启动完毕再操作!");
	else
		local issueCode = RrightBackHandEvent._GetFld("IssueCode");
		local side      = RrightBackHandEvent._GetFld("Side");
		local qty = RrightBackHandEvent._GetFld("Quantity");
		local moveQty = RrightBackHandEvent._GetFld("MoveQuantity")
		local way = RrightBackHandEvent._GetFld("Way");
		local price1
		local price2
		local portID = ""
		local condition = sys_sub(gFuturebaMapID,1,-4)
		local tempbamapid = condition .. "999"			--柜台持仓委托使用-999子账号
		if way == "反手委托" then
			price1 = RrightBackHandEvent._GetFld("Price1")
			price2 = RrightBackHandEvent._GetFld("Price2")
		elseif way == "涨跌停反手" then
			if side == "卖" then
				price1 = _PosPriceTable[issueCode].UpLimitPrice -- 跌停价
				price2 = _PosPriceTable[issueCode].UpLimitPrice -- 涨停价
			elseif side == "买" then
				price1 = _PosPriceTable[issueCode].LowLimitPrice -- 跌停价
				price2 = _PosPriceTable[issueCode].LowLimitPrice -- 跌停价
			end
		end

		gtBackHand[portID] = gtBackHand[portID] or {}
		gtBackHand[portID].IssueCode     = issueCode
		gtBackHand[portID].Quantity      = qty
		gtBackHand[portID].MoveQuantity  = moveQty
		gtBackHand[portID].Price1        = price1
		gtBackHand[portID].Price2 	     = price2
		gtBackHand[portID].Side          = side

		local logss = sys_format("组合号[%s];合约名称[%s];持仓状态[%s];持仓量[%s];移动量[%s];平仓价[%s];开仓价[%s];",portID,issueCode,side,qty,moveQty,price1,price2);
		_WriteErrorLog(logss)
		sendSysLog(logss)

		if qty < 1 then
			sendSysLog("无仓位可以移，不能移动！");
		elseif moveQty < 1 then
			sendSysLog("反手数量必须大于1！");
		elseif qty >= 1 and moveQty >= 1 then

			if not issueCode or issueCode == "" then
				sendSysLog("移仓的合约代码无效，不能移动！");
			else
				local p1 = _PosIssueProductCodeTable[issueCode];
				if p1 ~= "31" then
					sendSysLog("移仓的合约代码不是股指期货代码，不能移动！");
				elseif (issueCode ~= gFutureCurrent) and (issueCode ~= gFutureNextMonth) and (issueCode ~= gFutureSeasonMonth) and (issueCode ~= gFutureNextSeason) then
					sendSysLog("移仓的合约代码不可交易，不能移动！");
				else
					local preID = nil;
					if side == "买" then
						preID = "3";
					elseif  side == "卖" then
						preID = "1";
					elseif (side ~= "买" and side ~= "卖") then
						local logs = sys_format("证券/合约多空无效，代码:%s,多空:%s.",issueCode,side);
						sendSysLog(logs);
					else
						preID = side;
					end
					if preID then
						local bamapid = tempbamapid
						local tempkey = issueCode .. "." .. preID .. "." .. gHedgeFlag
						_WriteErrorLog(tempkey)
						local futureInvestorID = ""
						bool okFlag = true;
						if _PosBAMapAccount[tempbamapid] then
							local futureAccountCode = _PosBAMapAccount[tempbamapid]
							futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
						else
							okFlag = false;
						end
						local posAvlQty = 0
						--增加显示柜台持仓
						if okFlag and gtPositionTable[futureInvestorID] then
							if gtPositionTable[futureInvestorID][tempkey] then
								posAvlQty = gtPositionTable[futureInvestorID][tempkey].AvQty or "0"
								posAvlQty = posAvlQty.getNumberValue()
								if posAvlQty < qty then
									okFlag = false;
								end
							else
								okFlag = false;
							end
						end

						if okFlag then
							backHandOrder(gtBackHand[portID],portID,tempbamapid) -- 反手委托
							sendSysLog("请刷新后确认！");
						else
							local logs = sys_format("所选合约无有效数量，请刷新后，确认有持仓才可以移动，代码:%s,资金账号:%s.",issueCode,futureInvestorID);
							sendSysLog(logs);
						end
					end
				end
			end
		end
	end
_End

function backHandOrder(order,portID,baMapID)

	local BuySell

	if order.Side ~= "买" then
		_WriteErrorLog("反手空")

		BASubID  = "1" .. portID
		BASubID2 = "3" .. portID
		BuySell  = "3"

		local ret = PosSubmitSingleOrder(baMapID, BASubID, order.IssueCode, BuySell, 1, order.Price1, order.Quantity, 0, "",nil,gHedgeFlag)
		if ret.Result then
			PosSubmitSingleOrder(baMapID, BASubID2, order.IssueCode, BuySell, 0, order.Price2, order.MoveQuantity, 0, "",nil,gHedgeFlag)
		else
			sendSysLog(ret.Reason)
		end

	elseif order.Side ~= "卖" then
		_WriteErrorLog("反手买")

		BASubID  = "3" .. portID
		BASubID2 = "1" .. portID
		BuySell  = "1"

		local ret = PosSubmitSingleOrder(baMapID, BASubID, order.IssueCode, BuySell, 1, order.Price1, order.Quantity, 0, "",nil,gHedgeFlag)
		if ret.Result then
			PosSubmitSingleOrder(baMapID, BASubID2, order.IssueCode, BuySell, 0, order.Price2, order.MoveQuantity, 0, "",nil,gHedgeFlag)
		else
			sendSysLog(ret.Reason)
		end
	end

end

--快速平仓回调
_OnEventDefined(QuickSell QuickSellEvent)
	_WriteAplLog("QuickSell");
	local issueCode = QuickSellEvent._GetFld("IssueCode");

	if _InitializeFlag ~= 1 then	-- 第一次刷新完成
		sendSysLog("请等待程序启动完毕再操作!");
	elseif not _PosPriceTable[issueCode] then
		local log = sys_format("[%s]没有行情!",issueCode)
		sendSysLog(log);
	else
		local side      = QuickSellEvent._GetFld("Side");
		local portID = ""
		local qty       = QuickSellEvent._GetFld("Quantity");
		local price = 0
		price = _PosPriceTable[issueCode].AskPrice1 or 0
		local BASubID = "1"..portID
		local BuySell = "3"
		local BSStr = "买平仓"
		if side == "买" then
			BuySell = "1"
			BASubID = "3"..portID
			BSStr = "卖平仓"
			price = _PosPriceTable[issueCode].BidPrice1 or 0
		end
		local condition = sys_sub(gFuturebaMapID,1,-4)
		local tempbamapid = condition .. "999"			--柜台持仓委托使用-999子账号
		log = sys_format("快捷平仓:下单合约:[%s],下单数量:[%s],价格:[%s],方向:[%s]",issueCode,qty,price,BSStr)
		sendSysLog(log)
		local ret = PosSubmitSingleOrder(tempbamapid, BASubID, issueCode, BuySell, 1, price, qty, 0, "",nil,gHedgeFlag)
		if not ret.Result then
			sendSysLog(ret.Reason)
		end
	end
_End
--快捷锁仓回调
_OnEventDefined(LockOrder LockOrderEvent)
	_WriteAplLog("LockOrder");
	local issueCode = LockOrderEvent._GetFld("IssueCode");

	if _InitializeFlag ~= 1 then	-- 第一次刷新完成
		sendSysLog("请等待程序启动完毕再操作!");
	elseif not _PosPriceTable[issueCode] then
		local log = sys_format("[%s]没有行情!",issueCode)
		sendSysLog(log);
	else
		local side      = LockOrderEvent._GetFld("Side");
		local portID = ""
		local qty       = LockOrderEvent._GetFld("Quantity");
		local price = 0
		price = _PosPriceTable[issueCode].AskPrice1 or 0
		local BASubID = "3"..portID
		local BuySell = "3"
		local openclose = 0
		local BSStr = "买开仓"
		if side == "买" then
			BuySell = "1"
			BASubID = "1"..portID
			BSStr = "卖开仓"
			price = _PosPriceTable[issueCode].BidPrice1 or 0
		end
		local condition = sys_sub(gFuturebaMapID,1,-4)
		local tempbamapid = condition .. "999"			--柜台持仓委托使用-999子账号
		local log = sys_format("快捷锁仓:下单合约:[%s],下单数量:[%s],价格:[%s],方向:[%s]",issueCode,qty,price,BSStr)
		sendSysLog(log)
		local ret = PosSubmitSingleOrder(tempbamapid, BASubID, issueCode, BuySell, openclose, price, qty, 0, "",nil,gHedgeFlag)
		if not ret.Result then
			sendSysLog(ret.Reason)
		end
	end
_End

--K线调用
_OnEventDefined(k1mEvent evt)
	--_WriteErrorLog("k1mEvent")
    DTSEvent kevent = _CreateEventObject("klineEvent")
    local issue = evt._GetFld("IssueCode")
    local close = evt._GetFld("ClosePrice")
    local timekey = evt._GetTimeKey()

	gtPriceTable[issue] = gtPriceTable[issue] or {}
	gtPriceTable[issue][timekey] = close
	gtPriceTable[issue].LastPrice = close
	gtPriceTable[issue].LastTime = timekey
    --[[
    local temp = {}
    temp.LastPrice = close
    temp.Time = timekey
    sys_insert(gtPriceTable[issue],temp)
    ]]
    local log = sys_format("IssueCode[%s],ClosePrice[%s],TimeKey[%s]",issue,close,timekey)
    --_WriteErrorLog(log)
_End

--------------------------------------------------------------------------------------
--输入成交逻辑处理
--------------------------------------------------------------------------------------

_OnEventDefined(InputExecution inputExecutionEvent)
	if _InitializeFlag ~= 1 then	-- 第一次刷新完成
		sendSysLog("请等待程序启动完毕再操作!");
	else
		local issueCode = inputExecutionEvent._GetFld("IssueCode");
		local bs = inputExecutionEvent._GetFld("BuySell");
		local buySell = "";
		local log = "";
		local validDataFlag = true;
		if issueCode == "" or (not _PosIssueMarketTable[issueCode]) then
			sendSysLog("输入成交的合约不存在！");
			validDataFlag = false;
		end
		if bs == "买" then
			buySell = "3";
		elseif bs == "卖" then
			buySell = "1";
		else
			sendSysLog("输入成交的买卖错误！");
			validDataFlag = false;
		end
		local oc = inputExecutionEvent._GetFld("OpenClose");
		local openClose = -1;
		if oc == "开仓" then
			openClose = 0;
		elseif oc == "平仓" then
			openClose = 1;
		else
			sendSysLog("输入成交的开平仓错误！");
			validDataFlag = false;
		end
		local price = inputExecutionEvent._GetFld("Price");
		if price == "" or price <= 0 then
			sendSysLog("输入成交的价格错误！");
			validDataFlag = false;
		end
		local quantity = inputExecutionEvent._GetFld("Quantity");
		if quantity == "" or quantity <= 0 then
			sendSysLog("输入成交的数量错误！");
			validDataFlag = false;
		end
		local portID = inputExecutionEvent._GetFld("PortID");
		if portID == "" then
			sendSysLog("输入成交的组合编号错误！");
			validDataFlag = false;
		end
		local execDate = inputExecutionEvent._GetFld("ExecDate");
		_WriteAplLog(execDate)
		if execDate ~= "T" and execDate ~= "T-1" then
			sendSysLog("输入成交日期错误！");
			validDataFlag = false;
		else
			execDate = DateFormat(execDate)
		end
		_WriteAplLog(execDate)
		if not gtCombinList[portID] then
			sendSysLog("输入下单组合号不存在对应套利组合！");
			validDataFlag = false;
		end
		if validDataFlag then
			local logs = sys_format("内部下单：%s%s%s，数量%s,价格%s",issueCode,bs,oc,quantity,price);
			_WriteAplLog(logs);
			sendSysLog(logs);
			internalExecution(issueCode,buySell,openClose,quantity,price,execDate,portID);
		end
	end
_End;
function DateFormat(line)
	if line == "T" then
		return nil
	else
		return _PosTradingDate[1]
	end
end
--模拟成交Unikey
function CreateUKey(msgType)
	local nowTime = GetHMS()
	gUKeySeq = gUKeySeq or 0
	gUKeySeq = gUKeySeq + 1
	return sys_format("%3s0%s%010d", msgType, nowTime, gUKeySeq)
end
--内部成交新下单接口修改
function internalExecution(issueCode,buySell,openClose,quantity,price,execDate,portID)
	local checkflag = true
	local baMapID = "";
	local productCode = _PosIssueProductCodeTable[issueCode];
	if productCode == "10" or productCode == "03" or productCode == "02" then	--证券
		_WriteAplLog("跨期内部成交只支持期货！")
		sendSysLog("跨期内部成交只支持期货！")
		checkflag = false
		return
	else	--期货
		baMapID = gFuturebaMapID;
	end

	--修正下单的控制权限DealerID
	local dealerID = _PosGetBAMapID2UserID(baMapID)
	local _String strDealerID = dealerID

	local accountCode = _PosBAMapAccount[baMapID]
	local fundStatus = _PosFundStatus[accountCode]

	if fundStatus then

	else
		local internalLog = sys_format("内部成交：无子账户[%s]对应的资金账户",baMapID)
		_WriteAplLog(internalLog)
		sendSysLog(internalLog);
		checkflag = false
		return
	end

	--通过portID生成baSubID
	local baSubID = "";
	if (openClose == 0 and buySell == "3") or (openClose == 1 and buySell == "1") then	--买开或卖平
		baSubID = "3"..portID;	--多头
	elseif (openClose == 0 and buySell == "1") or (openClose == 1 and buySell == "3") then	--卖开或买平
		baSubID = "1"..portID;	--空头
	else
		_WriteAplLog("BaSubID Error!")
		sendSysLog("BaSubID Error!")
		checkflag = false
		return
	end
	if openClose ~= 0 then--如果是平仓，检查可用数量
		local avlQty = 0
		local posKey = baMapID .. "." .. baSubID .. "." .. issueCode
		local position = _PosPositionTable[posKey]
		if position then
			avlQty = position.AvlQuantity
		end
		if avlQty < quantity then
			local log = sys_format("内部成交失败: 持仓 [ %s ] 可用数量 [ %s ] 小于平仓数量 [ %s ]", posKey, avlQty, quantity)
			sendSysLog(log)
			checkflag = false
			return
		end
	end

	if checkflag == true then
		local execKey = nil
		local creRed = 0--内部成交暂时用0,只支持普通的买卖
		if execDate then
			execKey = CreateUKey("L18")
		end
		local ret = _PosMoveInternalExecution(baMapID, baSubID, issueCode,buySell,openClose,quantity,price,execDate,execKey, nil, creRed,gHedgeFlag)
		if not ret.Result then
			local logs = ret.Reason;
			sendSysLog(logs);
			return
		end
	end
	return true
end
----------------
--柜台资金查询--
----------------
function L2cQueryMarketFund(investorID, clientID, baMapID)
	_WriteErrorLog("Enter L2cQueryMarketFund")
	local type = _PosClient[clientID].Type
	local passWord = _GetInvestorPWD(baMapID)

	--模拟柜台密码无效，90环境取不到密码，因此写死
              --passWord = "123456"
	if passWord and passWord ~= "" and passWord ~= " " then
		local log = sys_format("L2cQueryMarketFund, baMapID=%s, clientID=%s, investorID=%s", baMapID, clientID, investorID)
		_WriteErrorLog(log)

		if type == "F" then--客户资金查询—上期综合期货
			local log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的资金信息处于请求状态",clientID, investorID)
			_WriteErrorLog(log)

			--local SUBJECT = Subject_SQZH
			local DTSSubmitEvent qryFundEvent;
			--消息头
			qryFundEvent.setField("MessageType","Q13") 		--客户资金查询
			qryFundEvent.setField("InvestorID",investorID) --资金帐号
			qryFundEvent.setField("Password",passWord)       --密码
			qryFundEvent.setField("WorkstationNo","660")   	--默认本机
			--New Add
			qryFundEvent.setField("ClientID",clientID)   	--加入总账户信息

			--消息体
			local DTSSubmitEvent queryList
			local DTSSubmitEvent query1
			query1.setField("function_id","KHZJLS")     --功能号
			queryList.append(query1)
			qryFundEvent.spliceArray("MessageDetail", queryList)
			_QryMarket("Fund_SQZH",qryFundEvent)
		end
	else
		local log = sys_format("GetInvestorPWD Failed ClientID:%s,InvestorID:%s",clientID,investorID)
		_WriteErrorLog(log)
		local loog = sys_format("请确认账号[%s]是否认证通过",investorID)
		--sendSysLog(loog)
	end
	_WriteErrorLog("Complete L2cQueryMarketFund")
end

--上期综合期货柜台资金回调
_OnQryMarketResult("Fund_SQZH",DTSSubmitEvent rplEvt)
    _WriteErrorLog("Fund_SQZH:HaveKHZJ______________JZZQ")

	local clientMessageID = rplEvt.getField("ClientMessageID")
	_WriteErrorLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	_WriteErrorLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	_WriteErrorLog(clientID)

	if investorID and investorID ~= "" and investorID ~= " " then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
			if topField.isArray() then --MessageDetail
					local index = 0
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					_WriteErrorLog(log)
					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)
					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Fund_SQZH :error_no=%d,error_msg=%s",error_no,error_msg)
					_WriteErrorLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end
					if flag == 1 then
						local available_balance = rplMsg.getField("available_balance");     --可用资金
                        local post_balance      = rplMsg.getField("post_balance");          --帐户余额
                        local frozen_amount     = rplMsg.getField("frozen_amount");         --冻结金额
                        local fetch_balance     = rplMsg.getField("fetch_balance");         --可取资金
                        local total_balance     = rplMsg.getField("total_balance");         --总资产

	                    local fund = {}
	                    fund.clientMessageID    = clientMessageID
	                    fund.clientID           = clientID
	                    fund.investorID         = investorID
	                    fund.post_balance       = post_balance
	                    fund.frozen_amount      = frozen_amount
	                    fund.available_balance  = available_balance
	                    fund.fetch_balance      = fetch_balance
	                    fund.total_balance      = total_balance

	                    L2cOnQueryMarket("Fund",fund)
						log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的资金信息处于已回复状态",clientID, investorID)
						_WriteErrorLog(log)

					else
						onQryFlag = false
						log = sys_format("Qry Fund_SQZH Failed :error_no=%d,error_msg=%s",error_no,error_msg)
						_WriteErrorLog(log)
					end
				--end
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				_WriteErrorLog(logstr)
			end
	else
		_WriteErrorLog("Fund_SQZH:未获取到投资者账户")
	end
_End

-- 发送4IF到界面
function ReadFuture()
	local DTSEvent CreateIF = _CreateEventObject("CreateIFTableEvent")
	local IF1 = gFutureCurrent
	local IF2 = gFutureNextMonth
	local IF3 = gFutureSeasonMonth
	local IF4 = gFutureNextSeason
	CreateIF._SetFld("IF1",IF1)
	CreateIF._SetFld("IF2",IF2)
	CreateIF._SetFld("IF3",IF3)
	CreateIF._SetFld("IF4",IF4)
	_SendToClients(CreateIF)
end
----------------
--柜台持仓查询--
----------------
--查询所有柜台的持仓信息
function L2cQueryMarketPosition(investorID,clientID,baMapID,issueCode)
	_WriteErrorLog("Enter L2cQueryMarketPosition")

	local type = _PosClient[clientID].Type
	local passWord = _GetInvestorPWD(baMapID)

    --模拟柜台密码无效，90环境取不到密码，因此写死
    --passWord = "123456"
	if passWord and passWord ~= "" and passWord ~= " " then
		local log = sys_format("QryMarketPos, baMapID=%s, clientID=%s, investorID=%s, issueCode=%s", baMapID, clientID, investorID, issueCode)
		_WriteErrorLog(log)

		if type == "F" then--客户持仓查询—上期综合期货
			local log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的持仓信息处于请求状态",clientID, investorID)
			_WriteErrorLog(log)

			--local SUBJECT = Subject_SQZH
			local DTSSubmitEvent qryPosEvent;
			--消息头
			qryPosEvent.setField("MessageType","Q14") 		--客户持仓查询
			qryPosEvent.setField("InvestorID",investorID) --资金帐号
			qryPosEvent.setField("Password",passWord)       --密码
			qryPosEvent.setField("WorkstationNo","660")   	--默认本机
			--New Add
			qryPosEvent.setField("ClientID",clientID)   	--加入总账户信息

			--消息体
			local DTSSubmitEvent queryList
			local DTSSubmitEvent query1
			query1.setField("function_id","KHCCLS")     --功能号

			--Set IssueCode 单个合约查询，issueCode为空时查所有持仓
			--query1.setField("issue_code",issueCode)     --功能号
			queryList.append(query1)
			qryPosEvent.spliceArray("MessageDetail", queryList)
			_QryMarket("Pos_SQZH",qryPosEvent)
		elseif type == "M" then--客户持仓信息查询--金证融资融券柜台
			_WriteErrorLog("账号为融资融券账号，暂不支持")
		end
	else
		local log = sys_format("GetInvestorPWD Failed ClientID:%s,InvestorID:%s",clientID,investorID)
		_WriteErrorLog(log)
	end
end


--上期综合期货柜台持仓回调
_OnQryMarketResult("Pos_SQZH",DTSSubmitEvent rplEvt)
    _WriteErrorLog("Pos_SQZH:HaveKHZJ______________JZZQ")
	local encode = rplEvt.encode()
	local startLog = sys_format("******柜台资金查询 Fund_SQZH Start :encode = [%s]*******",encode)
	_WriteErrorLog(startLog)
    local clientMessageID = rplEvt.getField("ClientMessageID")
	_WriteErrorLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	_WriteErrorLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	_WriteErrorLog(clientID)

	local onQryFlag = true
	if investorID and investorID ~= "" and investorID ~= " " then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
			if topField.isArray() then --MessageDetail
			    local positionList = {}
			    local InvestorID = ""
				for index = 0, topField.size()-1, 1 do
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					_WriteErrorLog(log)

					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)

					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Pos_SQZH :error_no=%d,error_msg=%s",error_no,error_msg)
					_WriteErrorLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end
					if flag == 1 then
					    local issueCode = rplMsg.getField("issue_code")
					    if issueCode ~= false and issueCode ~= "" and issueCode ~= " " and issueCode ~= nil then
					        local issue_code	      = rplMsg.getField("issue_code")          --证券代码
							local issue_name
							if issue_code then
								issue_name = _PosIssueNameTable[issue_code] --rplMsg.getField("contract_name")		--合约名称
								if issue_name == nil then
									issue_name = issue_code
								end
							end
                            local exchange_type	      = rplMsg.getField("exchange_type")       --交易所
                            local position_qty	      = rplMsg.getField("position_qty")        --今持仓量
                            local available_qty	      = rplMsg.getField("available_qty")       --可用数量
                            local enable_redeem_qty	  = rplMsg.getField("enable_redeem_qty")   --可赎回数量
                            local enable_report_qty	  = rplMsg.getField("enable_report_qty")   --可申购数量
                            local enable_sell_qty	  = rplMsg.getField("enable_sell_qty")     --可卖出数量
                            local pos_average_price	  = rplMsg.getField("pos_average_price")   --持仓均价
                            local assign_cost_price	  = rplMsg.getField("assign_cost_price")   --摊薄成本价
                            local margin	          = rplMsg.getField("margin")              --保证金
                            local profit_total	      = rplMsg.getField("profit_total")        --累计盈亏
                            local profit_float	      = rplMsg.getField("profit_float")        --浮动盈亏
                            local entrust_bs	      = rplMsg.getField("entrust_bs")          --买卖方向
                            local insure_flag	      = rplMsg.getField("insure_flag")         --投机套保标志
                            local position_cost       = rplMsg.getField("position_cost")       --持仓成本--持仓均价
                            local position_str	      = rplMsg.getField("position_str")        --定位串


							local cost = 0
							if position_cost ~= "" and position_cost ~= nil and position_cost ~= false then
								local contractSize = _PosIssueContractSizeTable[issue_code]
								if position_qty ~= 0 and position_qty ~= "0" and contractSize ~= nil then
									cost = position_cost / position_qty / contractSize
									cost=sys_format("%.2f",cost)
								end
							end
							if position_qty ~= "" and position_qty ~= nil and position_qty ~= "0" and position_qty ~= 0 then
								if entrust_bs == "2" then
									entrust_bs = "1"
								end
								local position = {}
								position.clientMessageID    = clientMessageID
								position.investorID         = investorID
								position.clientID           = clientID
								InvestorID = clientID
								position.issue_code	        = issue_code
								position.issue_name	        = issue_name
								position.exchange_type	    = exchange_type
								position.position_qty	    = position_qty
								position.available_qty	    = position_qty
								position.enable_redeem_qty	= enable_redeem_qty
								position.enable_report_qty	= enable_report_qty
								position.enable_sell_qty	= enable_sell_qty
								position.pos_average_price	= cost
								position.assign_cost_price	= assign_cost_price
								position.margin	            = margin
								position.profit_total	    = profit_total
								position.profit_float	    = profit_float
								position.entrust_bs	        = entrust_bs
								position.insure_flag	    = insure_flag
								position.position_cost      = position_cost
								position.position_str	    = position_str

								sys_insert(positionList, position)
							end
					    end
					else
						log = sys_format("Qry Pos_SQZH :error_no=%d,error_msg=%s",error_no,error_msg)
						_WriteErrorLog(log)
					end
				end
				positionList.investorID = InvestorID
				L2cOnQueryMarket("Position",positionList)
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				_WriteErrorLog(logstr)
			end
		local log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的柜台持仓信息处于已回复状态", clientID, investorID)
		_WriteErrorLog(log)
	else
		_WriteErrorLog("Pos_RZRQ:未获取到柜台投资者持仓")
	end
_End

function L2cOnQueryMarket(BusinessType, listInfo)		--柜台回调返回函数
	if BusinessType == "Position" then
		for i,info in pairs (listInfo) do
			if i ~= "investorID" then
				--柜台返回持仓
				local investorID	      = info.investorID	         --资金账号
				local issue_code	      = info.issue_code	         --证券代码
				local issue_name	      = info.issue_name          --证券名称
				local exchange_type	      = info.exchange_type       --交易所
				local position_qty	      = info.position_qty        --今持仓量
				local available_qty	      = info.available_qty       --可用数量
				local enable_redeem_qty	  = info.enable_redeem_qty   --可赎回数量
				local enable_report_qty	  = info.enable_report_qty   --可申购数量
				local enable_sell_qty	  = info.enable_sell_qty     --可卖出数量
				local pos_average_price	  = info.pos_average_price   --持仓均价
				local assign_cost_price	  = info.assign_cost_price   --摊薄成本价
				local margin	          = info.margin            	 --保证金
				local profit_total	      = info.profit_total        --累计盈亏
				local profit_float	      = info.profit_float        --浮动盈亏
				local entrust_bs	      = info.entrust_bs          --买卖方向
				local insure_flag	      = info.insure_flag         --投机套保标志
				local position_cost       = info.position_cost       --持仓成本
				local position_str	      = info.position_str        --定位串
				entrust_bs = entrust_bs.toString()
				if not gtPositionTable[investorID] then
					gtPositionTable[investorID] = {}
					_WriteErrorLog(investorID)
				end
				local key = issue_code .. "." .. entrust_bs .. "." .. insure_flag
				if not  gtPositionTable[investorID][key] then
					gtPositionTable[investorID][key] = {}
					_WriteErrorLog(key)
				end
				local poslist = gtPositionTable[investorID][key]
				poslist.BuySell = entrust_bs
				poslist.InvestorID = investorID
				poslist.IssueName = issue_name
				poslist.IssueCode = issue_code
				poslist.MarketType = exchange_type
				poslist.Quantity = position_qty
				poslist.ReportQty = enable_report_qty
				poslist.RedeemQty = enable_redeem_qty
				poslist.AvQty = available_qty
				poslist.AvSellQty = enable_sell_qty
				poslist.AvePrice = pos_average_price
				poslist.Margin = margin
				poslist.PL = profit_float
				poslist.hedgeType = insure_flag
				poslist.CostValue = position_cost
			end
		end

		SendQueryPos()

	elseif BusinessType == "Fund" then
		--柜台返回资金

		local investorID = listInfo.investorID
		local clientID = listInfo.clientID
		local available_balance = listInfo.available_balance
		local frozen_amount = listInfo.frozen_amount
		local post_balance = listInfo.post_balance
		local fetch_balance = listInfo.fetch_balance
		local total_balance = listInfo.total_balance
		if not gQueryFund[investorID] then
			gQueryFund[investorID] = {AvlFund=0,OrderFund=0,AssetValue=0,Margin=0,Balance=0}
		end
		gQueryFund[investorID].ClientID = clientID
		gQueryFund[investorID].AvlFund = available_balance		 --可用资金
		gQueryFund[investorID].OrderFund = frozen_amount		--冻结金额
		gQueryFund[investorID].AssetValue = total_balance		--总资产
		gQueryFund[investorID].Margin = post_balance			--帐户余额
		gQueryFund[investorID].Balance = fetch_balance			--可取资金

		SendQueryFund()				--刷新资金信息
	end
end

function SendQueryFund()										--刷新柜台资金信息显示
	_WriteErrorLog("SendQueryFund")
	local futureAvlFund = 0
	local futureOrderFund = 0
	local futureAssetValue = 0
	local futureMargin = 0
	local futureBalance = 0
	local futureAccountCode = nil

	if _PosBAMapAccount[gFuturebaMapID] then
		futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	end

	if futureAccountCode then
		local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
		if gQueryFund[futureInvestorID] then
			futureAvlFund = gQueryFund[futureInvestorID].AvlFund
			futureOrderFund = gQueryFund[futureInvestorID].OrderFund
			futureAssetValue = gQueryFund[futureInvestorID].AssetValue
			futureMargin = gQueryFund[futureInvestorID].Margin
			futureBalance = gQueryFund[futureInvestorID].Balance
		end
	end

	futureAvlFund = dataformat(futureAvlFund)
	futureOrderFund = dataformat(futureOrderFund)
	futureAssetValue = dataformat(futureAssetValue)
	futureMargin = dataformat(futureMargin)
	futureBalance = dataformat(futureBalance)
	_WriteErrorLog(futureAvlFund)
	local DTSEvent sendFundOut = _CreateEventObject("FundStatus")
	sendFundOut._SetFld("KYFund",futureAvlFund)
	sendFundOut._SetFld("DJFund",futureOrderFund)
	sendFundOut._SetFld("DTFund",futureAssetValue)
	sendFundOut._SetFld("BZFund",futureMargin)
	_SendToClients(sendFundOut)
end


function SendQueryPos()											--刷新柜台持仓
	_WriteErrorLog("SendQueryPos")
	local futureAccountCode = nil
	if _PosBAMapAccount[gFuturebaMapID] then
		futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	end
	local temp1 = {}
	if futureAccountCode then
		local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
		if gtPositionTable[futureInvestorID] then
			temp1 = gtPositionTable[futureInvestorID]
		end
	end
	for key,info in pairs(temp1)do
		sendQuerysinglePos(info,"future")
	end
	_WriteErrorLog("SendQueryPos end")
end


function sendQuerysinglePos(poslist,EventID)					--刷新柜台持仓单笔显示
	local InvestorID = poslist.InvestorID or ""
	local BuySell = poslist.BuySell or ""
	local IssueName = poslist.IssueName or ""
	local IssueCode = poslist.IssueCode or ""
	local MarketType = poslist.MarketType or ""
	local Quantity = poslist.Quantity or 0
	local ReportQty = poslist.ReportQty or 0
	local RedeemQty = poslist.RedeemQty or 0
	local AvQty = poslist.AvQty or 0
	local AvSellQty = poslist.AvSellQty or 0
	local AvePrice = poslist.AvePrice	or 0
	local Margin = poslist.Margin	or 0
	local PL = poslist.PL	or 0
	local hedgeType = poslist.hedgeType or "0"
	local CostValue = poslist.CostValue	or 0
	AvePrice = dataformat(AvePrice)
	Margin = dataformat(Margin)
	PL = dataformat(PL)
	CostValue = dataformat(CostValue)
	if BuySell == "3" then
		BuySell = "买"
	elseif BuySell == "1" then
		BuySell = "卖"
	end
	if not BuySell then
		BuySell = "-"
	end
	if MarketType == "1" then
		MarketType = "上交所"
	elseif  MarketType == "2" then
		MarketType = "深交所"
	elseif MarketType == "3" then
		MarketType = "中金所"
	elseif MarketType == "4" then
	MarketType = "上期所"
	elseif MarketType == "5" then
		MarketType = "郑期所"
	elseif MarketType == "6" then
		MarketType = "大期所"
	end
	if hedgeType == "0" then
		hedgeType = "投机"
	elseif hedgeType == "1" then
		hedgeType = "套保"
	elseif hedgeType == "2" then
		hedgeType = "套利"
	end

	if EventID == "future" then
		local DTSEvent sendPosOut = _CreateEventObject("FutCombinPos")
		sendPosOut._SetFld("InvestorID",InvestorID)
		sendPosOut._SetFld("BuySell",BuySell)
		sendPosOut._SetFld("IssueName",IssueName)
		sendPosOut._SetFld("IssueCode",IssueCode)
		sendPosOut._SetFld("MarketType",MarketType)
		sendPosOut._SetFld("Quantity",Quantity)
		sendPosOut._SetFld("AvQty",AvQty)
		sendPosOut._SetFld("AvSellQty",AvSellQty)
		sendPosOut._SetFld("AvePrice",AvePrice)
		sendPosOut._SetFld("Margin",Margin)
		sendPosOut._SetFld("PL",PL)
		sendPosOut._SetFld("HedgeType",hedgeType)
		sendPosOut._SetFld("CostValue",CostValue)

		_SendToClients(sendPosOut)
	end
end


--------------
--自定义函数--
--------------
--[[
function sendTickerEvt(pairCode,lnSpread,TimeKey)	-- 发送图形TICKER事件
	local DTSEvent tickerEvt = _CreateEventObject("tickerEvt")
	tickerEvt._SetFld("pairCode",pairCode)
	tickerEvt._SetFld("lnSpread",lnSpread)
	tickerEvt._SetFld("_TimeKey",TimeKey)
	_SendToClients(tickerEvt)
end
]]

function sendFlPriceEvt(IssueCode,lastPrice,spread,price0,price1,price2,price3)--发送价差表事件
	DTSEvent flPriceEvt = _CreateEventObject("flPriceEvt")
	flPriceEvt._SetFld("IssueCode",IssueCode)
	flPriceEvt._SetFld("lastPrice",lastPrice)
	flPriceEvt._SetFld("price0",price0)
	flPriceEvt._SetFld("price1",price1)
	flPriceEvt._SetFld("price2",price2)
	flPriceEvt._SetFld("price3",price3)
	flPriceEvt._SetFld("spread",spread)
	_SendToClients(flPriceEvt)
end

function sendFlPriceEvt2(IssueCode,lastPrice,BestBid1,BestBid2,Volume,BestAsk,Rose)--发送价差表事件
	DTSEvent flPriceEvt2 = _CreateEventObject("flPriceEvt2")
	flPriceEvt2._SetFld("IssueCode",IssueCode)
	flPriceEvt2._SetFld("lastPrice",lastPrice)
	flPriceEvt2._SetFld("BestBid1",BestBid1)
	flPriceEvt2._SetFld("BestBid2",BestBid2)
	flPriceEvt2._SetFld("Volume",Volume)
	flPriceEvt2._SetFld("BestAsk",BestAsk)
	flPriceEvt2._SetFld("Rose",Rose)
	_SendToClients(flPriceEvt2)
end

function initk1Min()											--初始化分钟交易时段
	local str =""
	-- 0916-0959
	for a1 =16,59 do
		str = sys_format("09%s00",a1)
		sys_insert( k1Min,str)
	end

	-- 1000-1059
	for a2 =0,59 do
		if a2<10 then
			str = sys_format("100%s00",a2)
		else
			str = sys_format("10%s00",a2)
		end
		sys_insert( k1Min,str)
	end

	-- 1100-1130
	for a3 =0,30 do
		if a3<10 then
			str = sys_format("110%s00",a3)
		else
			str = sys_format("11%s00",a3)
		end
		sys_insert( k1Min,str)
	end

	-- 1301-1359
	for a4 =1,59 do
		if a4<10 then
			str = sys_format("130%s00",a4)
		else
			str = sys_format("13%s00",a4)
		end
		sys_insert( k1Min,str)
	end

	-- 1400-1459
	for a5 =0,59 do
		if a5<10 then
			str = sys_format("140%s00",a5)
		else
			str = sys_format("14%s00",a5)
		end
		sys_insert( k1Min,str)
	end

	-- 1500-1515
	for a6 =0,15 do
		if a6<10 then
			str = sys_format("150%s00",a6)
		else
			str = sys_format("15%s00",a6)
		end
		sys_insert( k1Min,str)
	end


end

function getPreClose(is)										--获取HS300昨日收盘
	local startTimeKey = _PosTradingDate[1].."000000000000"
	local toTimeKey = _PosTradingDate[1].."235959000000"
	local DTSEvent k1dEvent = _CreateEventObject("k1dEvent")
	local DTSDynamicData k1dData = _CreateDynamicData(TSInstanceName="_auto_k1dEvent", fileType=_DataYearType, k1dEvent k1dEvent, portfolioID="HDS_PID", strategyID="HDS_SID")
	local cond = sys_format("IssueCode#%s;_TimeKey#%s:%s",is,startTimeKey,toTimeKey)
	_WriteAplLog(cond)
	k1dData._GetDynamicData(dataName="k1d", condition=cond)
end


function getHisData(issueCode)									--加载历史1m线数据
	local DTSEvent k1mEvent = _CreateEventObject("k1mEvent")
	local DTSDynamicData k1mData = _CreateDynamicData(TSInstanceName="_auto_k1mEvent", fileType=_DataDayType, k1mEvent k1mEvent, portfolioID="HDS_PID", strategyID="HDS_SID");
	local fromdate = gStrDate .. "000000000000"
	local toDate = gStrDate .. "235959000000"
	local cond = sys_format("getHisData:k1m:IssueCode#%s;_TimeKey#%s:%s", issueCode, fromdate, toDate)
	_WriteAplLog(cond)
	k1mData._GetDynamicData(dataName="k1m", condition=cond);
end



function refreshPrice(timekey)									--价格更新时回调刷新图形和价差表
	local time = sys_sub(timekey,9,14)
	if currentTime< time then
		currentTime = time
	end
	local p ={}
	for i,v in pairs(gtFutureList) do
		p[v]="-"
		if gtPriceTable[v] then
			local lp=gtPriceTable[v].LastPrice
			if lp ~="" and lp ~="-" then
				p[v]= lp.getNumberValue()
			end
		end
	end

	p["M000300"]="-"
	if gtPriceTable["M000300"] then
		local lp=gtPriceTable["M000300"].LastPrice
		if lp ~="" and lp ~="-" then
			p["M000300"]=lp.getNumberValue()
		end
	end


	for i,v in pairs(gtFutureList) do

		local sp = "-"
		if p["M000300"]~="-" and p[v]~="-" then
		   sp = p[v] - p["M000300"]
		end

		local ps0="-"
		local s0 =gtFutureList[0]
		if v ~= s0 then
			if p[v]~="-" and p[s0]~="-" then
				ps0 = p[v] - p[s0]
			end
		end

		local ps1="-"
		local s1 =gtFutureList[1]
		if v ~= s1 then
			if p[v]~="-" and p[s1]~="-" then
				ps1 = p[v] - p[s1]
			end
		end

		local ps2="-"
		local s2 =gtFutureList[2]
		if v ~= s2 then
			if p[v]~="-" and p[s2]~="-" then
				ps2 = p[v] - p[s2]
			end
		end

		local ps3="-"
		local s3 =gtFutureList[3]
		if v ~= s3 then
			if p[v]~="-" and p[s3]~="-" then
				ps3 = p[v] - p[s3]
			end
		end

	    sendFlPriceEvt(v,p[v],sp,ps0,ps1,ps2,ps3)  --发送价差表事件
	end
end

function sendSysLog(logInfo)									--日志提示
	local DTSTime now =  _GetNowTime();
    local nowStr = now.asString("%H%M%S");
	local logTime = sys_sub(nowStr,1,2)..":"..sys_sub(nowStr,3,4)..":"..sys_sub(nowStr,5,6)
	local logMsg = sys_format("%s",logInfo)
	local DTSEvent sysLog = _CreateEventObject("SystemLog")
	sysLog._SetFld("LogTime",logTime)
	sysLog._SetFld("LogMsg",logMsg)
	sysLog._SetFld("LogNo",_logNo)
	_logNo = _logNo +1

	_SendToClients(sysLog)
end
function SendOrder(portID)										--刷新委托表
	if gtOrderList[portID] then
		for StockFuture,tableInfo in pairs(gtOrderList[portID]) do
			if StockFuture == "FutureOpen" or StockFuture == "FutureClose" then
				for corpCode,info in pairs(tableInfo) do
					SendFutureOpenOrderEvent(portID,corpCode,info)
					status = info.Status
					if status == "全部成交" or status =="部成部撤" or status == "部分成交" then
						SendFutureOpenExecuteEvent(portID,corpCode,info)
					end
				end
			end
		end
	end
end

function SendFutureOpenOrderEvent(portID,corpCode,info)			--刷新期货委托表
	_WriteErrorLog("SendFutureOpenOrderEvent")
	local issueCode = info.IssueCode or "-"
	local status = info.Status or "-"
	local buySell = info.BuySell or "-"

	local entrustPrice = info.EntrustPrice or "-"
	local entrustQty = info.EntrustQty or ""
	local dealQty = info.DealQty or "-"
	local cancelQuantity = info.CancellationQty or "-"
	local date = info.Date or "-"
	local orderAcceptNo = info.OrderAcceptNo or "-"
	local statusFlag = info.StatusFlag or "-"
	local workingQuantity = info.WorkingQuantity or "-"
	local openClose = info.OpenClose or "-"

	local dealPrice = info.DealPrice or "-"
	local investorID = info.InvestorID or "-"
	local hedgeFlag = info.HedgeFlag or "-"
	if buySell == "3" then
		buySell = "买"
	elseif buySell == "1" then
		buySell = "卖"
	end
	if openClose == 0 then
		openClose = "开仓"
	elseif openClose == 1 then
		openClose = "平仓"
	end
	if hedgeFlag == "0" then
		hedgeFlag = "投机"
	elseif hedgeFlag == "1" then
		hedgeFlag = "套保"
	elseif hedgeFlag == "2" then
		hedgeFlag = "套利"
	end
	local flag = info.Flag or "-"
	if flag ~= "初始化内部成交" then

		local DTSEvent ord = _CreateEventObject("FutureOrderEvent")
		ord._SetFld("PortID", portID)
		ord._SetFld("CorpCode", corpCode)
		ord._SetFld("IssueCode", issueCode)
		ord._SetFld("BuySell", buySell)
		ord._SetFld("OpenClose", openClose)
		ord._SetFld("EntrustPrice", entrustPrice)
		ord._SetFld("EntrustQty", entrustQty)
		ord._SetFld("Status", status)
		ord._SetFld("DealPrice", dealPrice)
		ord._SetFld("DealQty", dealQty)
		ord._SetFld("CancellationQty", cancelQuantity)
		ord._SetFld("WorkingQty", workingQuantity)
		ord._SetFld("BatchNumber", orderAcceptNo)
		ord._SetFld("Date", date)
		ord._SetFld("StatusFlag", statusFlag)
		ord._SetFld("InvestorID", investorID)
		ord._SetFld("HedgeFlag", hedgeFlag)
		ord._SetFld("Flag", flag)						--备注
		_SendToClients(ord);
	end
end


function SendFutureOpenExecuteEvent(portID,corpCode,info)		--刷新期货成交表
	_WriteErrorLog("SendFutureOpenExecuteEvent")
	local execNo = info.ExecNo or "-"
	local execTime = info.ExecTime or "-"
	local issueCode = info.IssueCode or "-"
	local buySell = info.BuySell or "-"
	local dealQty = info.ExecQuantity or "-"
	local cancellationQty = info.CancellationQty or "-"
	local status = info.Status or "-"
	local orderAcceptNo = info.OrderAcceptNo or "-"
	local openClose = info.OpenClose or "-"
	local dealPrice = info.ExecPrice or ""
	local investorID = info.InvestorID or "-"
	local hedgeFlag = info.HedgeFlag or "-"
	if buySell == "3" then
		buySell = "买"
	elseif buySell == "1" then
		buySell = "卖"
	end
	if openClose == 0 then
		openClose = "开仓"
	elseif openClose == 1 then
		openClose = "平仓"
	end
	if hedgeFlag == "0" then
		hedgeFlag = "投机"
	elseif hedgeFlag == "1" then
		hedgeFlag = "套保"
	elseif hedgeFlag == "2" then
		hedgeFlag = "套利"
	end
	local flag = info.Flag or "-"
	if flag ~= "初始化内部成交" then
		local execLog = sys_format("SendFutureOpenExecuteEvent,corpCode:%s,issueCode:%s, execNo:%s,execPrice:%s, execQuantity:%s, execTime:%s",corpCode,issueCode,execNo,dealPrice, dealQty, execTime)
		_WriteErrorLog(execLog)
		local DTSEvent exec = _CreateEventObject("FutureExecuteEvent")
		exec._SetFld("PortID", portID);
		exec._SetFld("CorpCode", corpCode);
		exec._SetFld("ExecNo", execNo);
		exec._SetFld("Date", execTime)
		exec._SetFld("IssueCode", issueCode);
		exec._SetFld("BuySell", buySell)
		exec._SetFld("OpenClose", openClose)
		exec._SetFld("DealQty", dealQty);
		exec._SetFld("DealPrice", dealPrice);
		exec._SetFld("CancellationQty", cancellationQty);
		exec._SetFld("Status", status);
		exec._SetFld("OrderAcceptNo", orderAcceptNo)
		exec._SetFld("InvestorID", investorID)
		exec._SetFld("HedgeFlag", hedgeFlag)
		_SendToClients(exec)
	end
end

function RefreshArbitragePosition()								--刷新套利持仓
	gtArbitragePositionTable = {}
	--_WriteAplLog("RefreshArbitragePosition")

	local futureAccountCode = nil
	if _PosBAMapAccount[gFuturebaMapID] then
		futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	end
	if futureAccountCode then
		if _PosFundStatus[futureAccountCode] then
			local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
			if futureInvestorID then
				for key, pos in pairs(_PosPositionTable) do
					local bAMapID = pos.BAMapID
					local accountCode = _PosBAMapAccount[bAMapID]
					if _PosFundStatus[accountCode] and accountCode then
						local investorID = _PosFundStatus[accountCode].InvestorID
						if gtInvestorIDMap[investorID] then
							RefreshOneArbitragePosition(pos,investorID)
						end
					end
				end
			end
		end
	end
	for combinCode,value in pairs (gtArbitragePositionTable) do
		showArbitragePosition(combinCode)						--发送持仓到界面
	end
end

function RefreshOneArbitragePosition(pos,investorID)			--逐个保存套利组合持仓数据
	local baMapID = pos.BAMapID
	local baSubID = pos.BASubID
	local longShort = sys_sub(baSubID,1,1)
	local combinCode = sys_sub(baSubID,2,-1)
	if sys_sub(combinCode, 1, 2) == "KQ" then
		local issueCode = pos.IssueCode
		local issueName = _PosIssueNameTable[issueCode]
		local quantity = pos.Quantity or 0
		local avlQty = 0
		if gtPositionTable[investorID] then
			local Poskey = issueCode .. "." .. longShort .. "." .. gHedgeFlag
			if gtPositionTable[investorID][Poskey] then
				avlQty = gtPositionTable[investorID][Poskey].AvQty or 0
			end
		end
		local amount = pos.Amount or 0
		local costPrice = 0
		local MarketCode = _PosIssueMarketTable[issueCode]
		if MarketCode and quantity ~= 0 then
			if MarketCode == "1" or MarketCode == "2" then
				costPrice = amount / quantity
			elseif MarketCode == "3" then
				costPrice = amount / quantity / 300
			end
		end
		local longShortStr = ""
		if longShort == "1" then
			longShortStr = "卖"
		elseif longShort == "3" then
			longShortStr = "买"
		end
		local rose = 0
		local lastPrice = 0
		local priceInfo = _PosPriceTable[issueCode]
		if priceInfo and costPrice > 0 then
			lastPrice = priceInfo.LastPrice or 0
			if lastPrice ~= 0 then
				rose = (lastPrice - costPrice) / costPrice
			end
		end
		local valuationPL = pos.ValuationPL or 0
		local realizedPL = pos.RealizedPL or 0
		local key = investorID .. issueCode .. longShort

		gtArbitragePositionTable[combinCode] = gtArbitragePositionTable[combinCode] or {}
		gtArbitragePositionTable[combinCode][key] = gtArbitragePositionTable[combinCode][key] or {}
		gtArbitragePositionTable[combinCode][key].IssueName = issueName
		gtArbitragePositionTable[combinCode][key].IssueCode = issueCode
		gtArbitragePositionTable[combinCode][key].Quantity = quantity
		gtArbitragePositionTable[combinCode][key].AvlQty = avlQty
		gtArbitragePositionTable[combinCode][key].CostPrice = costPrice
		gtArbitragePositionTable[combinCode][key].Rose = rose
		gtArbitragePositionTable[combinCode][key].LastPrice = lastPrice
		gtArbitragePositionTable[combinCode][key].BuySell = longShortStr
		gtArbitragePositionTable[combinCode][key].Amount = amount
		gtArbitragePositionTable[combinCode][key].ValuationPL = valuationPL + realizedPL
		gtArbitragePositionTable[combinCode][key].CombinCode = combinCode
		gtArbitragePositionTable[combinCode][key].BAMapID = baMapID
		--gtArbitragePositionTable[combinCode][key].AverageCost = averageCost
		--gtArbitragePositionTable[combinCode][key].Future = future
		gtArbitragePositionTable[combinCode][key].InvestorID = investorID
		gtArbitragePositionTable[combinCode][key].LongShort = longShort
		---组合显示统计需要的数据
		gtArbitragePositionTable[combinCode][key].CumulationPL = pos.CumulationPL
		gtArbitragePositionTable[combinCode][key].CumulationDividend = pos.CumulationDividend
		--gtArbitragePositionTable[combinCode][key].CumulationFare = pos.CumulationFare
		gtArbitragePositionTable[combinCode][key].Fare = pos.Fare
		--gtArbitragePositionTable[combinCode][key].RealizedPL = pos.RealizedPL
	end
end


function showArbitragePosition(combinCode)	                --发送当前组合套利持仓到界面
	--_WriteErrorLog("showArbitragePosition")
	local DTSEvent Arbitrage = _CreateEventObject("FutureArbitragePosInfo")
	if gtArbitragePositionTable[combinCode] and gtCombinList[combinCode] then
		local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
		local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
		local sumPL = 0
		local sumBAMapID = ""
		local sumInvestorID = futureInvestorID
		if futureAccountCode then
			for key,info in pairs(gtArbitragePositionTable[combinCode]) do
				local investorID = info.InvestorID  or "-"
				if futureInvestorID == investorID then			--只刷新当前账号下
					local issueCode = info.IssueCode or "-"
					local issueName = info.IssueName or "-"
					local quantity = info.Quantity or 0
					local avlQty = info.AvlQty or 0
					local costPrice = info.CostPrice or 0
					local rose = info.Rose or 0
					local lastPrice = info.LastPrice or 0
					local buySell = info.BuySell or "-"
					--local combinCode = info.CombinCode or 0
					local baMapID = info.BAMapID or 0
					local valuationPL = info.ValuationPL or 0

					rose = sys_format("%.02f",rose * 100)
					costPrice = sys_format("%.02f",costPrice)
					lastPrice = sys_format("%.02f",lastPrice)
					valuationPL = sys_format("%.02f",valuationPL)
					--统计项计算
					sumPL = sumPL + valuationPL
					sumBAMapID = baMapID
					gtCombinList[combinCode].ValuationPL = sumPL

					quantity = sys_format("%.0f",quantity)
					avlQty = sys_format("%.0f",avlQty)

					local MarketCode = _PosIssueMarketTable[issueCode]
					if MarketCode == "1" or MarketCode == "2" then
						--
						return
					elseif MarketCode == "3" then
						local key = buySell .. combinCode .. issueCode
						Arbitrage._SetFld("CombinCode",combinCode)
						Arbitrage._SetFld("BAMapID",baMapID)
						Arbitrage._SetFld("IssueCode",issueCode)
						Arbitrage._SetFld("Position",quantity)
						Arbitrage._SetFld("AvlQty",avlQty)
						Arbitrage._SetFld("AverageCost",costPrice)
						Arbitrage._SetFld("Rose",rose)
						Arbitrage._SetFld("BuySell",buySell)
						Arbitrage._SetFld("ValuationPL",valuationPL)
						Arbitrage._SetFld("LastPrice",lastPrice)
						Arbitrage._SetFld("InvestorID",investorID)
						Arbitrage._SetFld("UniqueKeyCode",key)
						Arbitrage._SetFld("MainRowFlag","2")
						if quantity ~= "0" then --数量不为0显示该条持仓
							Arbitrage._SetFld("clear","0")
						else
							Arbitrage._SetFld("clear","1")
						end
						_SendToClients(Arbitrage)

						--local log = sys_format("combinCode[%s],baMapID[%s],issueCode[%s],quantity[%s],avlQty[%s],costPrice[%s],rose[%s],buySell[%s],valuationPL[%s],lastPrice[%s],investorID[%s],key[%s]"
						--						,combinCode,baMapID,issueCode,quantity,avlQty,costPrice,rose,buySell,valuationPL,lastPrice,investorID,key)
						--_WriteErrorLog(log)
					end
				end
			end
			if sumBAMapID ~= "" then --汇总行
				if not gtFoldExist[combinCode] then
					gtFoldExist[combinCode] = {};
				end
				local CombinIssueCode = ""
				if combinCode == "KQ" then 						--单边
					combinCode = "单边"
				else
					local issue1 = sys_sub(combinCode,4,9)
					local issue2 = sys_sub(combinCode,10,15)
					CombinIssueCode = issue1 .. " - " .. issue2
				end
				local UniqueKeyCode = "表头" .. combinCode
				Arbitrage._SetFld("CombinCode",combinCode)
				Arbitrage._SetFld("BAMapID",sumBAMapID)
				Arbitrage._SetFld("IssueCode",CombinIssueCode)
				Arbitrage._SetFld("Position","")
				Arbitrage._SetFld("AvlQty","")
				Arbitrage._SetFld("AverageCost","")
				Arbitrage._SetFld("Rose","")
				Arbitrage._SetFld("BuySell","")
				Arbitrage._SetFld("ValuationPL",sumPL)
				Arbitrage._SetFld("LastPrice","")
				Arbitrage._SetFld("InvestorID",sumInvestorID)
				Arbitrage._SetFld("UniqueKeyCode",UniqueKeyCode)
				Arbitrage._SetFld("MainRowFlag","1")
				Arbitrage._SetFld("clear","0")
				_SendToClients(Arbitrage)
				_WriteErrorLog("合并表头")
			end
		end
	end
end

function dataformat(arg)										--格式调整
	if arg and arg ~= "" then
		arg = arg.getNumberValue()
		arg = sys_format("%.02f",arg)
	else
		arg = "0.00"
	end
	return arg
end

function ClearTable() 											--清空表
end
function sendFundReplyClose(BAMapID,AccountCode,CombinCode)		--单笔委托中资金关联信息显示
	_WriteErrorLog("sendFundReply")

	local marketCode = _PosIssueMarketTable[_QueryIssue]
	if marketCode then
		local bailRatio = _PosGetBail(AccountCode, _QueryIssue)				--这里返回的是投机或者套保保证金率
		local AvailableFund = _PosFundStatus[AccountCode]["AvlFund"]		--可用资金
		local AvailableOpenQty = 0 														--可开仓数
		local AvailableBuyCloseQuantity = 0											--可平仓数/买
		local AvailableSellCloseQuantity = 0											--可平仓数/卖

		if _PosPriceTable[_QueryIssue] then
			local lastPrice = _PosPriceTable[_QueryIssue].LastPrice
			if lastPrice ~= 0 and lastPrice then
				lastPrice = lastPrice.getNumberValue()
				local contractSize = _PosIssueContractSizeTable[_QueryIssue]
				local availableOpenQuantity = AvailableFund / lastPrice / contractSize / bailRatio
				AvailableOpenQty = sys_floor(availableOpenQuantity)
				local log = sys_format("sendFundReply--IssueCode:%s,availableOpenQuantity:%s AvailableOpenQty:%s,AvlibFund:%s, contractSize:%s, lastPrice:%s, bailRatio:%s",
											_QueryIssue,availableOpenQuantity,AvailableOpenQty, AvailableFund, contractSize, lastPrice, bailRatio)
				--_WriteErrorLog(log)
			end
		else
			_RegisterPrice(_IssueCode = _QueryIssue, _MarketCode = marketCode)
		end

		AvailableFund = sys_format("%.2f",_PosFundStatus[AccountCode]["AvlFund"])
		local qrylog = sys_format("sendFundReply--BAMapID:%s, AccountCode:%s, CombinCode:%s",
											BAMapID, AccountCode, CombinCode)
		--_WriteErrorLog(qrylog)
		--取得多头可用数量
		local posKey = BAMapID .. ".3" ..CombinCode.. "." .. _QueryIssue
		if _PosPositionTable[posKey] then
			AvailableSellCloseQuantity = _PosPositionTable[posKey].AvlQuantity	--即可卖平数量
		end

		--取得空头可用数量
		posKey = BAMapID .. ".1" ..CombinCode.. "." .. _QueryIssue
		if _PosPositionTable[posKey] then
			AvailableBuyCloseQuantity = _PosPositionTable[posKey].AvlQuantity	--即可买平数量
		end



		DTSEvent fundReply = _CreateEventObject("FundReply")
		fundReply._SetFld("IssueCode", _QueryIssue)
		fundReply._SetFld("AvlibFund", AvailableFund)
		AvailableOpenQty = sys_format("%.0f",AvailableOpenQty)
		AvailableBuyCloseQuantity = sys_format("%.0f",AvailableBuyCloseQuantity)
		AvailableSellCloseQuantity = sys_format("%.0f",AvailableSellCloseQuantity)
		qrylog = sys_format("sendFundReply--BAMapID:%s,CombinCode:%s,IssueCode:%s, AvlibFund:%s, AvlibOpenatQty:%s, AvlibBuyCloseQty:%s, AvlibSellCloseQty:%s",
											BAMapID,CombinCode,_QueryIssue, AvailableFund, AvailableOpenQty, AvailableBuyCloseQuantity, AvailableSellCloseQuantity)
		_WriteErrorLog(qrylog)
		fundReply._SetFld("AvlibOpenatQty", AvailableOpenQty)
		fundReply._SetFld("AvlibBuyCloseQty", AvailableBuyCloseQuantity)
		fundReply._SetFld("AvlibSellCloseQty", AvailableSellCloseQuantity);
		_SendToClients(fundReply);
	end
end
----------
--定时器--
----------
_OnEventTimer(_TimerName="TimeInterval")
	if _DD == 1 then				--刷新单笔委托资金信息
		if _PosPriceTable[_QueryIssue] then
			_DD = 0
			local CombinCode = _QueryTable["CombinCode"]
			local accountCode = _QueryTable["AccountCode"]
			local BAMapID = 	_QueryTable["BAMapID"]
			sendFundReplyClose(BAMapID,accountCode,CombinCode)
		end
	end

	if TT >= _gRefreash then
		TT = 0
		RefreshArbitragePosition()

		--刷新套利列表__浮动盈亏
		for subID,info in pairs(gtCombinList) do
			local issue1 = info.Issue1
			local issue2 = info.Issue2
			local buyValuationPL = 0
			local sellValuationPL = 0
			local BuyQty = 0
			local SellQty = 0
			local Fare = 0

			local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]

			if gtArbitragePositionTable[subID] and futureAccountCode then
				local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID or ""

				local key = futureInvestorID .. issue1 .. "3"
				if gtArbitragePositionTable[subID][key] then
					buyValuationPL = gtArbitragePositionTable[subID][key].ValuationPL or 0
					BuyQty = gtArbitragePositionTable[subID][key].Quantity or 0
					Fare = Fare + gtArbitragePositionTable[subID][key].Fare
				end

				key = futureInvestorID .. issue2 .. "1"
				if gtArbitragePositionTable[subID][key] then
					sellValuationPL = gtArbitragePositionTable[subID][key].ValuationPL or 0
					SellQty = gtArbitragePositionTable[subID][key].Quantity or 0
					Fare = Fare + gtArbitragePositionTable[subID][key].Fare
				end

				local ValuationPL = buyValuationPL + sellValuationPL
				ValuationPL = sys_format("%0.1f",ValuationPL)
				gtCombinList[subID].ValuationPL = ValuationPL
				gtCombinList[subID].BuyQty = BuyQty
				gtCombinList[subID].SellQty = SellQty
				gtCombinList[subID].Fare = Fare
				SendCombinList(subID,futureInvestorID)
			else
				local log = sys_format("not gtArbitragePositionTable:CombinCode[%s]",subID)
				_WriteErrorLog(log)
			end
		end
	end
	TT = TT + 1

_End


--------------------
-------QYM----------
--------------------
function getPriceFormat(issueCode)								--得到价格格式字符串
	local priceExponent = _PosIssueExponentTable[issueCode]
	if not priceExponent then
		priceExponent = -3
	end
	local priceExponentabs = sys_abs(priceExponent)
	local formatStr = sys_format("%%.%df", priceExponentabs)
	return formatStr
end
function GetHMS()
	local DTSTime nowtime = _GetNowTime();
	local smtime = nowtime.asString("%H%M%S");
	return smtime
end
function formatTime(time)
	local ftTime = time
	local colon = sys_sub(time, 3, 3)
	if colon ~= ":" then
		local hh = sys_sub(time ,1, 2)
		local mm = sys_sub(time ,3, 4)
		local ss = sys_sub(time ,5, 6)
		ftTime = hh .. ":" .. mm .. ":" .. ss
	end
	return ftTime
end

function creatID(issue1,issue2)												--创建组合编码信息
	local portID = ""
	local SubmitNo = 1; --下单序列号，为了保证每个CombinCode的唯一
	local strSubmitNo = sys_format("%03d",SubmitNo); --格式化成3位
	portID = sys_format("KQ_%s%s_%s",issue1,issue2,strSubmitNo);
	while findID(portID) do
		SubmitNo = SubmitNo + 1;
		strSubmitNo = sys_format("%03d",SubmitNo);
		portID = sys_format("KQ_%s%s_%s",issue1,issue2,strSubmitNo);
	end
	local log = "createportID by the function of creatIDtodisposition:"..portID
	--_WriteErrorLog(log);
	return portID;
end
function findID(portID)  										--找到最新组合编号
	for CombinCode, info in pairs(gtCombinList) do
		if portID == CombinCode then
			return true
		end
	end
	if gtArbitragePositionTable[portID] then
		return true
	end
	if gtOrderList[portID] then
		return true
	end
	return false
end


function getKlineTime(time)	--时分秒 转为 20位整数分钟时间
	local date = gStrDate
	local hh = sys_sub(time,1,2).toInt()
	local mm = sys_sub(time,3,4).toInt()
	local ss = sys_sub(time,5,6).toInt()

	local toTolSS = hh*60+mm
	if ss~=0 then toTolSS=toTolSS+1 end
	mm = toTolSS%60
	hh = (toTolSS - mm)/60

	local hhStr = 0
	local mmStr = 0
	if hh <10 then
		hhStr = "0"..hh.toString()
	else
		hhStr = hh.toString()
	end

	if mm <10 then
		mmStr = "0"..mm.toString()
	else
		mmStr = mm.toString()
	end

	local hhmm = hh*60+mm
	if hhmm > 690 and hhmm < 780 then 	--时间在11:30分到13:00之间
		hhStr = "11"
		mmStr = "30"
	end

	local result = date..hhStr..mmStr.."00000000"
	local log = sys_format("resulttime:%s",result)
	--_WriteErrorLog(log)
	return result
end

function Refreshkline(issue1,issue2)
	_WriteErrorLog("Refreshkline")
	gklineType = "0"
	SendHistoryKlineGraph(issue1,issue2)
end

function SendHistoryKlineGraph(issue1,issue2)
	_WriteErrorLog("SendHistoryKlineGraph")
	local price1 = preClose[issue1] or preClose["M000300"]
	local price2 = preClose[issue2] or preClose["M000300"]
	local log = sys_format("preClose[%s]=%s,preClose[%s]=%s",issue1,price1,issue2,price2)
	_WriteErrorLog(log)

	for index,time in pairs(k1Min) do
		local price = 0
		local pairCode = ""

		if time > currentTime then
			log =sys_format("读取历史K线结束 : %s , %s",time,currentTime)
			_WriteAplLog(log)
			break
		end
		local k1MinTime = sys_sub(time,1,6)
		k1MinTime = getKlineTime(k1MinTime)
		if gtPriceTable[issue1] then
			if gtPriceTable[issue1][k1MinTime] then
				price1 = gtPriceTable[issue1][k1MinTime]
			end
		end

		if issue2 == issue1 then								--刷单边
			price2 = 0
			pairCode = issue1
		else 													--刷跨期或基差
			if gtPriceTable[issue2] then
				if gtPriceTable[issue2][k1MinTime] then
					price2 = gtPriceTable[issue2][k1MinTime]
				end
			end
			pairCode = issue1 .. "-" .. issue2
		end
		if price1 and price2 then
			price = price1 - price2
		end
		log = sys_format("pairCode[%s],price[%s],k1MinTime[%s]",pairCode,price,k1MinTime)
		--_WriteErrorLog(log)
		sendklineEvent(pairCode,price,k1MinTime)
	end
	gklineType = "1"
end

function SendKlineGraph()
	--_WriteErrorLog("SendKlineGraph")

	if gtPriceTable[gIssue1] and gtPriceTable[gIssue2] then
		local price = 0
		local pairCode = ""
		local TimeKey = ""
		if gIssue1 == gIssue2 then 			--刷单边
			price = gtPriceTable[gIssue1].LastPrice or 0
			pairCode = gIssue1
			TimeKey = gtPriceTable[gIssue1].LastTime
		else 								--刷跨期或基差
			local price1 = gtPriceTable[gIssue1].LastPrice or preClose[gIssue1] or preClose["M000300"]
			local price2 = gtPriceTable[gIssue2].LastPrice or preClose[gIssue2] or preClose["M000300"]
			if price1 and price2 then
				price = price1 - price2
				pairCode = gIssue1 .. "-" .. gIssue2
				TimeKey = gtPriceTable[gIssue1].LastTime
			end
		end
		sendklineEvent(pairCode,price,TimeKey)
	end
end

function sendklineEvent(pairCode,lnSpread,TimeKey)
	local DTSEvent klineEvent = _CreateEventObject("klineEvent")
	klineEvent._SetFld("pairCode",pairCode)
	klineEvent._SetFld("lnSpread",lnSpread)
	klineEvent._SetFld("_TimeKey",TimeKey)
	_SendToClients(klineEvent)
end



function SendCombinList(CombinCode,InvestorID)
	local list = gtCombinList[CombinCode]
	if list then
		local investorID = list.InvestorID
		local Issue1 = list.Issue1 or "-"
		local Issue2 = list.Issue2 or "-"
		local Status = list.Status or "-"
		local AvlQty = list.AvlQty or "-"
		local BuyQty
		local SellQty
		local ValuationPL
		if investorID == InvestorID and InvestorID ~= "" then--当前账户显示套利持仓,非当前持仓显示0
			BuyQty = list.BuyQty or "-"
			SellQty = list.SellQty or "-"
			ValuationPL = list.ValuationPL or "-"
		else
			local log = sys_format("表中investorID[%s],当前InvestorID[%s]",investorID,InvestorID)
			_WriteErrorLog(log)
			BuyQty = 0
			SellQty = 0
			ValuationPL = "0.0"
		end
		local InPrice = list.InPrice or "-"
		local OutPrice = list.OutPrice or "-"
		local Fare = list.Fare or "-"
		local StopFlag = list.StopFlag or "-"

		--local log = sys_format("Issue1[%s],Issue2[%s],BuyQty[%s],SellQty[%s],InPrice[%s],OutPrice[%s],ValuationPL[%s],Fare[%s]",Issue1,Issue2,BuyQty,SellQty,InPrice,OutPrice,ValuationPL,Fare)
		--_WriteErrorLog(log)

		local DTSEvent combin = _CreateEventObject("CombinList")
		combin._SetFld("CombinCode",CombinCode)
		combin._SetFld("Issue1",Issue1)
		combin._SetFld("Issue2",Issue2)
		combin._SetFld("Status",Status)
		combin._SetFld("AvlQty",AvlQty)
		combin._SetFld("BuyQty",BuyQty)
		combin._SetFld("SellQty",SellQty)
		combin._SetFld("InPrice",InPrice)
		combin._SetFld("OutPrice",OutPrice)
		combin._SetFld("ValuationPL",ValuationPL)
		combin._SetFld("Fare",Fare)
		combin._SetFld("clear","0")
		combin._SetFld("StopFlag",StopFlag)
		_SendToClients(combin)
	end
end

function SaveCombinData(CombinCode,table)							--动态保存组合信息
	local DTSEvent saveCombin = _CreateEventObject("SaveCombinDataEvent");
	SaveCombinDataEvent._SetFld("CombinCode", CombinCode);
	CombinDynamicData._Clear()											--清楚之前保存的数据
	_WriteErrorLog("ClearData:CombinDataList")

	local Issue1 = table.Issue1
	local Issue2 = table.Issue2
	local AvlQty = table.AvlQty
	local Status = table.Status
	local BuyQty = table.BuyQty
	local SellQty = table.SellQty
	local InPrice = table.InPrice
	local OutPrice = table.OutPrice
	local buyOutAmount = table.buyOutAmount
	local buyOutQty = table.buyOutQty
	local sellOutAmount = table.sellOutAmount
	local sellOutQty = table.sellOutQty
	local Fare = table.Fare
	local InvestorID = table.InvestorID

	saveCombin._SetFld("CombinCode", CombinCode);
	saveCombin._SetFld("Issue1", Issue1);
	saveCombin._SetFld("Issue2", Issue2);
	saveCombin._SetFld("AvlQty", AvlQty);
	saveCombin._SetFld("Status", Status);
	saveCombin._SetFld("BuyQty", BuyQty);
	saveCombin._SetFld("SellQty", SellQty);
	saveCombin._SetFld("InPrice", InPrice);
	saveCombin._SetFld("OutPrice", OutPrice);
	saveCombin._SetFld("buyOutAmount", buyOutAmount);
	saveCombin._SetFld("buyOutQty", buyOutQty);
	saveCombin._SetFld("sellOutAmount", sellOutAmount);
	saveCombin._SetFld("sellOutQty", sellOutQty);
	saveCombin._SetFld("Fare", Fare);
	saveCombin._SetFld("InvestorID", InvestorID);

	CombinDynamicData._SaveData("CombinDataList",saveCombin)
	_WriteErrorLog("SaveData:CombinDataList")
end
