﻿--跨期套利初始版1.01
--Release version: 1.001.20141119
--修正自动开仓获取数据错误的BUG
--将多仓空仓修改为近月远月
--Release version: 1.001.20140305
--监听价格，生成相应合约的_PriceTable[issueCode]
_OnEventPrice(_PriceName="futurePrice", {} , DTSPrice price);
	local Flag = 0
    local issueCode = price.getIssueCode();
	if not priceInfo then --可能由于外部策略订阅，价格在持仓初始化完成前先来了，还是要记录下来
		--_WriteErrorLog("有没_PosPriceTable表")
		_PosPriceTable[issueCode] = {}
		priceInfo = _PosPriceTable[issueCode]

	end
	if not _Querylist[issueCode] then
		_Querylist[issueCode] = 1
		Flag = 1
	end
    local priceExponent = 2
    local priceExponentabs = sys_abs(priceExponent);
    local formatStr = sys_format("%%.%df", priceExponentabs)
	local time = price.getLastVolumeTimeStamp();
	local lastPrice = price.getEstLastPrice();	   --最新价

	--已订阅价格的issueCode
	if _IsHDSRegistered[issueCode] and lastPrice then
		--期指行情表
		if issueCode ~= "M000300" then
			--local BestBid = price.getMMBestBid();
			local BestBid1 = price.getMMBestBid1();		--昨结算
			local BestBid2 = price.getMMBestBid2();		--持仓量
			local LNBestBid = price.getMMLNBestBid();	--昨日持仓
			local Volume = price.getVolume();			--成交量
--~ 			if not BestBid and BestBid == "" then
--~ 				BestBid = ""
--~ 			end
--~ 			local log = sys_format("IssueCode[%s],BestBid[%s] ",issueCode,BestBid)
--~ 			_WriteErrorLog(log)
			--local log = sys_format("IssueCode[%s],昨结算[%s],持仓量[%s],昨日持仓[%s],成交量[%s],最新价[%s] BestBid[%s] ClearingPrice[%s]",issueCode,BestBid1,BestBid2,LNBestBid,Volume,lastPrice,BestBid,ClearingPrice)
			--_WriteErrorLog(log)

			local strLastPrice = "-"
			local numLastPrice = 0
			if lastPrice ~= "" then
				strLastPrice =  sys_format("%.01f",lastPrice);
				numLastPrice = strLastPrice.getNumberValue();
			else
				log = sys_format("IssueCode[%s],lastPrice[%s],strLastPrice[%s],numLastPrice[%s]",issueCode,lastPrice,strLastPrice,numLastPrice)
				_WriteErrorLog(log)
			end

			local strBestBid1 = "-"
			local numBestBid1 = 0
			if BestBid1 and BestBid1 ~= "" then
				strBestBid1 = sys_format("%.01f",BestBid1);
				numBestBid1 = strBestBid1.getNumberValue();
			else
				log = sys_format("IssueCode[%s],BestBid1[%s],strBestBid1[%s],numBestBid1[%s]",issueCode,BestBid1,strBestBid1,numBestBid1)
				_WriteErrorLog(log)
			end

			local strBestBid2 = "-"
			local numBestBid2 = 0
			if BestBid2 and BestBid2 ~= "" then
				strBestBid2 = sys_format("%.0f",BestBid2);
				numBestBid2 = strBestBid2.getNumberValue();
			else
				log = sys_format("IssueCode[%s],BestBid2[%s],strBestBid2[%s],numBestBid2[%s]",issueCode,BestBid2,strBestBid2,numBestBid2)
				_WriteErrorLog(log)
			end

			local strLNBestBid = "-"
			local numLNBestBid = 0
			if LNBestBid and LNBestBid ~= "" then
				strLNBestBid = sys_format("%.0f",LNBestBid);
				numLNBestBid = strLNBestBid.getNumberValue();
			else
				log = sys_format("IssueCode[%s],LNBestBid[%s],strLNBestBid[%s],numLNBestBid[%s]",issueCode,LNBestBid,strLNBestBid,numLNBestBid)
				_WriteErrorLog(log)
			end

			local strVolume = "-"
			local numVolume = 0
			if Volume and Volume ~= "" then
				strVolume = sys_format("%.0f",Volume);
				numVolume = strVolume.getNumberValue();
			else
				log = sys_format("IssueCode[%s],Volume[%s],strVolume[%s],numVolume[%s]",issueCode,Volume,strVolume,numVolume)
				_WriteErrorLog(log)
			end

			local BestAsk = "-"
			local strBestAsk = 0
			if numBestBid2 and numLNBestBid then
				BestAsk = numBestBid2 - numLNBestBid 	--增仓量
				strBestAsk = sys_format("%.0f",BestAsk);
			else
				log = sys_format("IssueCode[%s],numBestBid2[%s],numLNBestBid[%s]",issueCode,numBestBid2,numLNBestBid)
				_WriteErrorLog(log)
			end

			local Rose = "0.00" 						--涨幅
			if numLastPrice and numBestBid1 and numBestBid1 ~= 0 then
				Rose = (numLastPrice - numBestBid1) / numBestBid1
				Rose = sys_format("%.02f",Rose * 100)
			else
				log = sys_format("IssueCode[%s],numLastPrice[%s],numBestBid1[%s]",issueCode,numLastPrice,numBestBid1)
				_WriteErrorLog(log)
			end

			--刷新期指行情表
			sendFlPriceEvt2(issueCode,strLastPrice,strBestBid1,strBestBid2,strVolume,BestAsk,Rose)
		end
			--log = sys_format("IssueCode[%s],昨结算[%s],持仓量[%s],昨日持仓[%s],成交量[%s],增仓量[%s],涨幅[%s]",issueCode,numBestBid1,numBestBid2,numLNBestBid,numVolume,BestAsk,Rose)
			--_WriteErrorLog(log)
		local timekey = "00000000000000000000"
		--log = sys_format("futurePrice:time[%s]",time)
		--_WriteErrorLog(log)
		if time ~= "0" and time ~= "" and time then
			timekey = getKlineTime(time)
		end

		gtPriceTable[issueCode] = gtPriceTable[issueCode] or {}
		gtPriceTable[issueCode][timekey] = lastPrice
		gtPriceTable[issueCode].LastPrice = lastPrice
		gtPriceTable[issueCode].LastTime = timekey


		--刷新溢价表
		refreshPrice(timekey)

		if (issueCode == gIssue1 or issueCode == gIssue2 or issueCode == "M000300") and gklineType == "1" then
			--刷新价差图
			SendKlineGraph()
		end

		--刷新交易台基差
		if issueCode == gtBasis.Issue1 or issueCode == gtBasis.Issue2 then
			local a = {}
			a = refreshBasis()
			AutoOrder(a.basis1,a.basis2)
		end

		if issueCode == gFutureCurrent or issueCode == gFutureNextMonth or issueCode == gFutureSeasonMonth or issueCode == gFutureNextSeason then
			CloseUpDown()
		end
	end
	--单笔委托行情信息显示
	if _QueryIssue == issueCode or Flag == 1 then
		if _PosPriceTable[issueCode] then
			local PriceInfo = _PosPriceTable[issueCode]
			local issueName = _PosIssueNameTable[issueCode]
			local LastPrice = PriceInfo.LastPrice or 0
			local AskPrice1 = PriceInfo.AskPrice1 or 0
			local AskPrice2 = PriceInfo.AskPrice2 or 0
			local AskPrice3 = PriceInfo.AskPrice3 or 0
			local AskPrice4 = PriceInfo.AskPrice4 or 0
			local AskPrice5 = PriceInfo.AskPrice5 or 0
			local BidPrice1 = PriceInfo.BidPrice1 or 0
			local BidPrice2 = PriceInfo.BidPrice2 or 0
			local BidPrice3 = PriceInfo.BidPrice3 or 0
			local BidPrice4 = PriceInfo.BidPrice4 or 0
			local BidPrice5 = PriceInfo.BidPrice5 or 0
			local AskQuantity1 = PriceInfo.AskQuantity1 or 0
			local AskQuantity2 = PriceInfo.AskQuantity2 or 0
			local AskQuantity3 = PriceInfo.AskQuantity3 or 0
			local AskQuantity4 = PriceInfo.AskQuantity4 or 0
			local AskQuantity5 = PriceInfo.AskQuantity5 or 0
			local BidQuantity1 = PriceInfo.BidQuantity1 or 0
			local BidQuantity2 = PriceInfo.BidQuantity2 or 0
			local BidQuantity3 = PriceInfo.BidQuantity3 or 0
			local BidQuantity4 = PriceInfo.BidQuantity4 or 0
			local BidQuantity5 = PriceInfo.BidQuantity5 or 0
			local UpLimitPrice = PriceInfo.UpLimitPrice or 0
			local LowLimitPrice = PriceInfo.LowLimitPrice or 0
			local fttotalAskQty = AskQuantity1 + AskQuantity2 + AskQuantity3 + AskQuantity4 + AskQuantity5
			if fttotalAskQty ~= 0 then
				fttotalAskQty = sys_format("%d",fttotalAskQty);
			else
				fttotalAskQty = "-"
			end
			PriceInfo.totalAskQty = fttotalAskQty
			local fttotalBidQty = BidQuantity1 + BidQuantity2 + BidQuantity3 + BidQuantity4 + BidQuantity5
			if fttotalBidQty ~= 0 then
				fttotalBidQty = sys_format("%d", fttotalBidQty);
			else
				fttotalBidQty = "-"
			end
			--hongwen.kang20120508
			if LastPrice == 0 then
				LastPrice = "-"
			end
			if AskPrice1 == 0 then
				AskPrice1 = "-"
			end
			if AskPrice2 == 0 then
				AskPrice2 = "-"
			end
			if AskPrice3 == 0 then
				AskPrice3 = "-"
			end
			if AskPrice4 == 0 then
				AskPrice4 = "-"
			end
			if AskPrice5 == 0 then
				AskPrice5 = "-"
			end
			if BidPrice1 == 0 then
				BidPrice1 = "-"
			end
			if BidPrice2 == 0 then
				BidPrice2 = "-"
			end
			if BidPrice3 == 0 then
				BidPrice3 = "-"
			end
			if BidPrice4 == 0 then
				BidPrice4 = "-"
			end
			if BidPrice5 == 0 then
				BidPrice5 = "-"
			end
			PriceInfo.totalBidQty = fttotalBidQty
			local totalAskQty = PriceInfo.totalAskQty
			local totalBidQty = PriceInfo.totalBidQty
			AskQuantity1  = sys_format("%.0f",AskQuantity1)
			AskQuantity2  = sys_format("%.0f",AskQuantity2)
			AskQuantity3  = sys_format("%.0f",AskQuantity3)
			AskQuantity4  = sys_format("%.0f",AskQuantity4)
			AskQuantity5  = sys_format("%.0f",AskQuantity5)
			BidQuantity1  = sys_format("%.0f",BidQuantity1)
			BidQuantity2  = sys_format("%.0f",BidQuantity2)
			BidQuantity3  = sys_format("%.0f",BidQuantity3)
			BidQuantity4  = sys_format("%.0f",BidQuantity4)
			BidQuantity5  = sys_format("%.0f",BidQuantity5)
			local DTSEvent BaseEvent=_CreateEventObject("BasePriceEvent");
			BaseEvent._SetFld("IssueCode",issueCode);
			BaseEvent._SetFld("IssueShortName",issueName);
			BaseEvent._SetFld("LastPrice",LastPrice);
			BaseEvent._SetFld("AskPrice_1",AskPrice1);
			BaseEvent._SetFld("AskPrice_2",AskPrice2);
			BaseEvent._SetFld("AskPrice_3",AskPrice3);
			BaseEvent._SetFld("AskPrice_4",AskPrice4);
			BaseEvent._SetFld("AskPrice_5",AskPrice5);
			BaseEvent._SetFld("BidPrice_1",BidPrice1);
			BaseEvent._SetFld("BidPrice_2",BidPrice2);
			BaseEvent._SetFld("BidPrice_3",BidPrice3);
			BaseEvent._SetFld("BidPrice_4",BidPrice4);
			BaseEvent._SetFld("BidPrice_5",BidPrice5);
			BaseEvent._SetFld("AskQty_1",AskQuantity1);
			BaseEvent._SetFld("AskQty_2",AskQuantity2);
			BaseEvent._SetFld("AskQty_3",AskQuantity3);
			BaseEvent._SetFld("AskQty_4",AskQuantity4);
			BaseEvent._SetFld("AskQty_5",AskQuantity5);
			BaseEvent._SetFld("BidQty_1",BidQuantity1);
			BaseEvent._SetFld("BidQty_2",BidQuantity2);
			BaseEvent._SetFld("BidQty_3",BidQuantity3);
			BaseEvent._SetFld("BidQty_4",BidQuantity4);
			BaseEvent._SetFld("BidQty_5",BidQuantity5);
			BaseEvent._SetFld("UpperLimitPrice",UpLimitPrice);
			BaseEvent._SetFld("LowerLimitPrice",LowLimitPrice);
			BaseEvent._SetFld("TotalAskQty",totalAskQty);
			BaseEvent._SetFld("TotalBidQty",totalBidQty);
			_SendToClients(BaseEvent);
		end
	end

_End;

function refreshBasis()
	local gtbasis = {}

	local issue1 = gtBasis.Issue1
	local issue2 = gtBasis.Issue2
	local price1 = gtBasis.Price1
	local tick1  = gtBasis.Tick1
	local price2 = gtBasis.Price2
	local tick2  = gtBasis.Tick2
	local price3 = gtBasis.Price3
	local tick3  = gtBasis.Tick3
	local price4 = gtBasis.Price4
	local tick4  = gtBasis.Tick4

	price1 = GetOrderPrice(issue1,0,1,price1,tick1)  -- 买开多价格
	price2 = GetOrderPrice(issue2,0,1,price2,tick2)  -- 买开空价格
	price3 = GetOrderPrice(issue1,1,1,price3,tick3)  -- 卖开多价格
	price4 = GetOrderPrice(issue2,1,1,price4,tick4)  -- 卖开空价格

	local basis1 = price1 - price4
	local basis2 = price2 - price3
	local DTSEvent Basis = _CreateEventObject("BuySellBasisEvent")
	Basis._SetFld("Basis1",basis1)
	Basis._SetFld("Basis2",basis2)
	_SendToClients(Basis)

	basis1 = basis1.getNumberValue()
	basis2 = basis2.getNumberValue()

	gtbasis.basis1 = basis1
	gtbasis.basis2 = basis2

	return gtbasis
end

function GetOrderPrice(issueCode,oc,quantity,price,Tick)		--获取当前合约行情
	local OpenPrice = 0
	local Auto = {}
	local priceInfo = _PosPriceTable[issueCode]
	if priceInfo then
		if price == "自动盘口" then
			OpenPrice = getMarketPrice(issueCode,oc,quantity,1)
		elseif price == "卖10价" then
			OpenPrice =  priceInfo.AskPrice10 or 0
		elseif price == "卖9价" then
			OpenPrice =  priceInfo.AskPrice9 or 0
		elseif price == "卖8价" then
			OpenPrice =  priceInfo.AskPrice8 or 0
		elseif price == "卖7价" then
			OpenPrice =  priceInfo.AskPrice7 or 0
		elseif price == "卖6价" then
			OpenPrice =  priceInfo.AskPrice6 or 0
		elseif price == "卖5价" then
			OpenPrice =  priceInfo.AskPrice5 or 0
		elseif price == "卖4价" then
			OpenPrice =  priceInfo.AskPrice4 or 0
		elseif price == "卖3价" then
			OpenPrice =  priceInfo.AskPrice3 or 0
		elseif price == "卖2价" then
			OpenPrice =  priceInfo.AskPrice2 or 0
		elseif price == "卖1价" then
			OpenPrice =  priceInfo.AskPrice1 or 0
		elseif price == "最新价" then
			OpenPrice =  priceInfo.LastPrice or 0
		elseif price == "买1价" then
			OpenPrice =  priceInfo.BidPrice1 or 0
		elseif price == "买2价" then
			OpenPrice =  priceInfo.BidPrice2 or 0
		elseif price == "买3价" then
			OpenPrice =  priceInfo.BidPrice3 or 0
		elseif price == "买4价" then
			OpenPrice =  priceInfo.BidPrice4 or 0
		elseif price == "买5价" then
			OpenPrice =  priceInfo.BidPrice5 or 0
		elseif price == "买6价" then
			OpenPrice =  priceInfo.BidPrice6 or 0
		elseif price == "买7价" then
			OpenPrice =  priceInfo.BidPrice7 or 0
		elseif price == "买8价" then
			OpenPrice =  priceInfo.BidPrice8 or 0
		elseif price == "买9价" then
			OpenPrice =  priceInfo.BidPrice9 or 0
		elseif price == "买10价" then
			OpenPrice =  priceInfo.BidPrice10 or 0
		elseif price == "AdjustedLNC" then
			OpenPrice = priceInfo.AdjustedLNC or 0
		elseif price == "涨停价" then
			OpenPrice = priceInfo.UpLimitPrice or 0
		elseif price == "跌停价" then
			OpenPrice = priceInfo.LowLimitPrice or 0
			--WriteAplLog()
		end
	end

	local tick = _PosIssuePriceTickTable[issueCode]
	if Tick == "不浮动" then
		OpenPrice = OpenPrice + 0
	elseif Tick == "上浮20单位" then
		OpenPrice = OpenPrice + 20*tick
	elseif Tick == "上浮10单位" then
		OpenPrice = OpenPrice + 10*tick
	elseif Tick == "上浮5单位" then
		OpenPrice = OpenPrice + 5*tick
	elseif Tick == "上浮4单位" then
		OpenPrice = OpenPrice + 4*tick
	elseif Tick == "上浮3单位" then
		OpenPrice = OpenPrice + 3*tick
	elseif Tick == "上浮2单位" then
		OpenPrice = OpenPrice + 2*tick
	elseif Tick == "上浮1单位" then
		OpenPrice = OpenPrice + 1*tick
	elseif Tick == "下浮1单位" then
		OpenPrice = OpenPrice - 1*tick
	elseif Tick == "下浮2单位" then
		OpenPrice = OpenPrice - 2*tick
	elseif Tick == "下浮3单位" then
		OpenPrice = OpenPrice - 3*tick
	elseif Tick == "下浮4单位" then
		OpenPrice = OpenPrice - 4*tick
	elseif Tick == "下浮5单位" then
		OpenPrice = OpenPrice - 5*tick
	elseif Tick == "下浮10单位" then
		OpenPrice = OpenPrice - 10*tick
	elseif Tick == "下浮20单位" then
		OpenPrice = OpenPrice - 20*tick
	else
		--WriteAplLog()
	end

	return OpenPrice
end

function getMarketPrice(IssueCode,OC,Quantity,Confidence)		--返回自动盘口价格和数量
	local marketPrice = 0
 	local priceInfo = _PosPriceTable[IssueCode]
 	if priceInfo then
  		local askPrice1 = priceInfo.AskPrice1 or 0
	  	local askPrice2 = priceInfo.AskPrice2 or 0
	 	local askPrice3 = priceInfo.AskPrice3 or 0
	 	local askPrice4 = priceInfo.AskPrice4 or 0
	 	local askPrice5 = priceInfo.AskPrice5 or 0
		local askPrice6 = priceInfo.AskPrice6 or 0
	  	local askPrice7 = priceInfo.AskPrice7 or 0
	 	local askPrice8 = priceInfo.AskPrice8 or 0
	 	local askPrice9 = priceInfo.AskPrice9 or 0
	 	local askPrice10 = priceInfo.AskPrice10 or 0
	    local bidPrice1 = priceInfo.BidPrice1 or 0
	    local bidPrice2 = priceInfo.BidPrice2 or 0
	    local bidPrice3 = priceInfo.BidPrice3 or 0
	    local bidPrice4 = priceInfo.BidPrice4 or 0
	    local bidPrice5 = priceInfo.BidPrice5 or 0
		local bidPrice6 = priceInfo.BidPrice6 or 0
	    local bidPrice7 = priceInfo.BidPrice7 or 0
	    local bidPrice8 = priceInfo.BidPrice8 or 0
	    local bidPrice9 = priceInfo.BidPrice9 or 0
	    local bidPrice10 = priceInfo.BidPrice10 or 0
	    local askQty1 = priceInfo.AskQuantity1 or 0
	    local askQty2 = priceInfo.AskQuantity2 or 0
	    local askQty3 = priceInfo.AskQuantity3 or 0
	    local askQty4 = priceInfo.AskQuantity4 or 0
	    local askQty5 = priceInfo.AskQuantity5 or 0
		local askQty6 = priceInfo.AskQuantity6 or 0
	    local askQty7 = priceInfo.AskQuantity7 or 0
	    local askQty8 = priceInfo.AskQuantity8 or 0
	    local askQty9 = priceInfo.AskQuantity9 or 0
	    local askQty10 = priceInfo.AskQuantity10 or 0
	    local bidQty1 = priceInfo.BidQuantity1 or 0
	    local bidQty2 = priceInfo.BidQuantity2 or 0
	    local bidQty3 = priceInfo.BidQuantity3 or 0
	    local bidQty4 = priceInfo.BidQuantity4 or 0
        local bidQty5 = priceInfo.BidQuantity5 or 0
		local bidQty6 = priceInfo.BidQuantity6 or 0
	    local bidQty7 = priceInfo.BidQuantity7 or 0
	    local bidQty8 = priceInfo.BidQuantity8 or 0
	    local bidQty9 = priceInfo.BidQuantity9 or 0
        local bidQty10 = priceInfo.BidQuantity10 or 0

	    if OC == 0 then
			Quantity = Quantity.getNumberValue()
	  		local Quantity1 = Quantity - askQty1*Confidence  --除去卖1量以后还需要交易的数量
	   		local Quantity2 = Quantity1 - askQty2*Confidence --除去卖2量以后还需要交易的数量
	  		local Quantity3 = Quantity2 - askQty3*Confidence --除去卖3量以后还需要交易的数量
	  		local Quantity4 = Quantity3 - askQty4*Confidence --除去卖4量以后还需要交易的数量
	 		local Quantity5 = Quantity4 - askQty5*Confidence
			local Quantity6 = Quantity5 - askQty6*Confidence
			local Quantity7 = Quantity6 - askQty7*Confidence
			local Quantity8 = Quantity7 - askQty8*Confidence
			local Quantity9 = Quantity8 - askQty9*Confidence
			local Quantity10 = Quantity9 - askQty10*Confidence
	  	        if Quantity1 <= 0 then   --卖1量足够
	   			    marketPrice = askPrice1
	            elseif Quantity2 <= 0 then  --卖2量足够
	   			    marketPrice = askPrice2
	   			elseif Quantity3 <= 0 then  --卖3量足够
	    			marketPrice = askPrice3
	  		    elseif Quantity4 <= 0 then  --卖4量足够
	   				marketPrice = askPrice4
	            elseif Quantity5 <= 0 then --卖5量
	   			    marketPrice = askPrice5
				elseif Quantity6 <= 0 then
	   			    marketPrice = askPrice6
				elseif Quantity7 <= 0 then
	   			    marketPrice = askPrice7
				elseif Quantity8 <= 0 then
	   			    marketPrice = askPrice8
				elseif Quantity9 <= 0 then
	   			    marketPrice = askPrice9
				else
	   			    marketPrice = askPrice10
	   			end
	    else
	   		local Quantity1 = Quantity - bidQty1*Confidence  --除去买1量以后还需要交易的数量
	   	    local Quantity2 = Quantity1 - bidQty2*Confidence --除去买2量以后还需要交易的数量
	        local Quantity3 = Quantity2 - bidQty3*Confidence --除去买3量以后还需要交易的数量
	        local Quantity4 = Quantity3 - bidQty4*Confidence --除去买4量以后还需要交易的数量
			local Quantity5 = Quantity4 - bidQty5*Confidence
			local Quantity6 = Quantity5 - bidQty6*Confidence
			local Quantity7 = Quantity6 - bidQty7*Confidence
			local Quantity8 = Quantity7 - bidQty8*Confidence
			local Quantity9 = Quantity8 - bidQty9*Confidence
			local Quantity10 = Quantity9 - bidQty10*Confidence
			if Quantity1 <= 0 then   --买1量足够
				marketPrice = bidPrice1
			elseif Quantity2 <= 0 then  --买2量足够
				marketPrice = bidPrice2
			elseif Quantity3 <= 0 then  --买3量足够
				marketPrice = bidPrice3
			elseif Quantity4 <= 0 then  --买4量足够
				marketPrice = bidPrice4
			elseif Quantity5 <= 0 then --买5量以上
				marketPrice = bidPrice5
			elseif Quantity6 <= 0 then
				marketPrice = bidPrice6
			elseif Quantity7 <= 0 then
				marketPrice = bidPrice7
			elseif Quantity8 <= 0 then
				marketPrice = bidPrice8
			elseif Quantity9 <= 0 then
				marketPrice = bidPrice9
			else
				marketPrice = bidPrice10
   	        end
        end
    end

	return marketPrice
end

------------
--回调模块--
------------
-- 改变取价方式计算基差
_OnEventDefined(GetPriceForBasisEvent GetPriceForBasis)
	local no = GetPriceForBasis._GetFld("No");
	if no == "1" then
		local price1 = GetPriceForBasis._GetFld("Price1");
		gtBasis.Price1 = price1
	elseif no == "2" then
		local price2 = GetPriceForBasis._GetFld("Price2");
		gtBasis.Price2 = price2
	elseif no == "3" then
		local price3 = GetPriceForBasis._GetFld("Price3");
		gtBasis.Price3 = price3
	elseif no == "4" then
		local price4 = GetPriceForBasis._GetFld("Price4");
		gtBasis.Price4 = price4
	elseif no == "5" then
		local tick1 = GetPriceForBasis._GetFld("Tick1");
		gtBasis.Tick1  = tick1
	elseif no == "6" then
		local tick2 = GetPriceForBasis._GetFld("Tick2");
		gtBasis.Tick2  = tick2
	elseif no == "7" then
		local tick3   = GetPriceForBasis._GetFld("Tick3");
		gtBasis.Tick3  = tick3
	elseif no == "8" then
		local tick4 = GetPriceForBasis._GetFld("Tick4");
		gtBasis.Tick4  = tick4
	end

_End

-- 手动开仓回调
_OnEventDefined(HandOrderEvent handOrder)

	local states = handOrder._GetFld("States");
	local issue1 = handOrder._GetFld("Issue1");
	local issue2 = handOrder._GetFld("Issue2");
	local qty1   = handOrder._GetFld("Qty1");
	local qty2   = handOrder._GetFld("Qty2");
	qty1 = qty1.getNumberValue()
	qty2 = qty2.getNumberValue()
	local price1 = handOrder._GetFld("Price1");
	local tick1  = handOrder._GetFld("Tick1");
	local price2 = handOrder._GetFld("Price2");
	local tick2  = handOrder._GetFld("Tick2");

	local orderWay = handOrder._GetFld("OrderWay");
	local order123 = handOrder._GetFld("Order123");
	local runP1    = handOrder._GetFld("RunP1");
	local runT1    = handOrder._GetFld("RunT1");
	local runS1    = handOrder._GetFld("RunS1");
	local runP2    = handOrder._GetFld("RunP2");
	local runT2    = handOrder._GetFld("RunT2");
	local runS2    = handOrder._GetFld("RunS2");
	local runNum    = handOrder._GetFld("RunNum");

	runS1  = runS1.getNumberValue()
	runS2  = runS2.getNumberValue()
	runNum = runNum.getNumberValue()

	local log = sys_format("issue1 = %s,issue2 = %s,qty1 = %s,qty2 = %s,price1 = %s,tick1 = %s,price2 = %s,tick2 = %s,orderWay = %s,order123 = %s",
		issue1,issue2,qty1,qty2,price1,tick1,price2,tick2,orderWay,order123)
	_WriteErrorLog(log)

	local iss1 = sys_sub(issue1,3,-1)
	iss1 = iss1.getNumberValue()
	local iss2 = sys_sub(issue2,3,-1)
	iss2 = iss2.getNumberValue()

	local portID = creatID(issue1,issue2)
	local batchID = sys_sub(portID,-3,-1)

	local buySell1 = "3"
	local buySell2 = "1"
	local baSubID1 = "3" .. portID
	local baSubID2 = "1" .. portID

	if not gtCombinList[portID] then
		gtCombinList[portID] = {}
		gtCombinList[portID].PortID = portID
		gtCombinList[portID].States = states
		gtCombinList[portID].Issue1 = issue1
		gtCombinList[portID].Issue2 = issue2
		gtCombinList[portID].Qty1   = qty1
		gtCombinList[portID].Qty2   = qty2
		gtCombinList[portID].Price1 = price1
		gtCombinList[portID].Tick1  = tick1
		gtCombinList[portID].Price2 = price2
		gtCombinList[portID].Tick2  = tick2
		gtCombinList[portID].RunP1  = runP1
		gtCombinList[portID].RunT1  = runT1
		gtCombinList[portID].RunS1  = runS1
		gtCombinList[portID].RunP2  = runP2
		gtCombinList[portID].RunT2  = runT2
		gtCombinList[portID].RunS2  = runS2
		gtCombinList[portID].RunNum = runNum
		gtCombinList[portID].BS1    = buySell1
		gtCombinList[portID].BS2    = buySell2
		gtCombinList[portID].BaSubID1 = baSubID1
		gtCombinList[portID].BaSubID2 = baSubID2
		--qym
		gtCombinList[portID].AvlQty = qty1
		gtCombinList[portID].Status = "建仓"
		gtCombinList[portID].StopFlag = "止盈止损启动"
		gtCombinList[portID].BuyQty = "-"
		gtCombinList[portID].SellQty = "-"
		local buyPrice = GetOrderPrice(issue1,0,qty1,price1,tick1).getNumberValue()
		local sellPrice = GetOrderPrice(issue2,1,qty2,price2,tick2).getNumberValue()
		local InPrice = sys_format("%0.1f",buyPrice - sellPrice)
		gtCombinList[portID].InPrice = InPrice
		gtCombinList[portID].OutPrice = "-"
		gtCombinList[portID].ValuationPL = 0
		gtCombinList[portID].Fare = 0
		local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
		local futureInvestorID = ""
		if futureAccountCode then
			futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID or ""
			gtCombinList[portID].InvestorID = futureInvestorID
		end
		SaveCombinData(portID,gtCombinList[portID]) 		--保存套利列表
		SendCombinList(portID,futureInvestorID)				--创建套利列表
	end


	local Price1 = GetOrderPrice(issue1,0,qty1,price1,tick1)
	local Price2 = GetOrderPrice(issue2,1,qty2,price2,tick2)

	local Plog = sys_format("Price1 = %s,Price2 = %s",Price1,Price2)
	--_WriteErrorLog(Plog)
	local order = gtCombinList[portID]

	if (states == "正向开仓" and orderWay == "近期优先" and iss1 < iss2) or (states == "反向开仓" and orderWay == "远期优先" and iss1 > iss2)
		or (states == "正向开仓" and orderWay == "远期优先" and iss1 > iss2) or (states == "反向开仓" and orderWay == "近期优先" and iss1 < iss2) then

		OrderKQ(order,order123,Price1,Price2,batchID,"0") -- 下单

	elseif (states == "正向开仓" and orderWay == "近期优先" and iss1 > iss2) or (states == "反向开仓" and orderWay == "远期优先" and iss1 < iss2)
		or (states == "正向开仓" and orderWay == "远期优先" and iss1 < iss2) or (states == "反向开仓" and orderWay == "近期优先" and iss1 > iss2) then

		OrderKQ(order,order123,Price1,Price2,batchID,"1") -- 下单
	end

_End

function ClearAutoList(order)

	if order.States == "自动开仓" then
		gtAutoOrderList["自动开仓"] = {}
		gkaiguan1 = "1"
	elseif order.States == "自动开反仓" then
		gtAutoOrderList["自动开反仓"] = {}
		gkaiguan2 = "1"
	end
end

function Notice(states)
	if states == "自动开仓" then
		gkaiguan1 = "1"
	elseif states == "自动开反仓" then
		gkaiguan2 = "1"
	end

	local DTSEvent notice = _CreateEventObject("Notice")
		notice._SetFld("States",states)
		_SendToClients(notice)
end

function GetToPrice(issue,P)
	local price
	if P == "自动盘口" then
		if issue == "Issue1" then
			price = "AskPrice1"
		elseif issue == "Issue2" then
			price = "BidPrice1"
		end
	elseif P == "卖5价" then
		price = "AskPrice5"
	elseif P == "卖4价" then
		price = "AskPrice4"
	elseif P == "卖3价" then
		price = "AskPrice3"
	elseif P == "卖2价" then
		price = "AskPrice2"
	elseif P == "卖1价" then
		price = "AskPrice1"
	elseif P == "最新价" then
		price = "LastPrice"
	elseif P == "买5价" then
		price = "BidPrice5"
	elseif P == "买4价" then
		price = "BidPrice4"
	elseif P == "买3价" then
		price = "BidPrice3"
	elseif P == "买2价" then
		price = "BidPrice2"
	elseif P == "买1价" then
		price = "BidPrice1"
	elseif P == "跌停价" then
		price = "LowLimitPrice"
	elseif P == "涨停价" then
		price = "UpLimitPrice"

	end
	return price

end

function GetToTick(t)
	local tick = 0
	if t == "不浮动" then
		tick = 0
	elseif t == "上浮20单位" then
		tick = 20
	elseif t == "上浮10单位" then
		tick = 10
	elseif t == "上浮5单位" then
		tick = 5
	elseif t == "上浮4单位" then
		tick = 4
	elseif t == "上浮3单位" then
		tick = 3
	elseif t == "上浮2单位" then
		tick = 2
	elseif t == "上浮1单位" then
		tick = 1
	elseif t == "下浮20单位" then
		tick = -20
	elseif t == "下浮10单位" then
		tick = -10
	elseif t == "下浮5单位" then
		tick = -5
	elseif t == "下浮4单位" then
		tick = -4
	elseif t == "下浮3单位" then
		tick = -3
	elseif t == "下浮2单位" then
		tick = -2
	elseif t == "下浮1单位" then
		tick = -1
	end
	return tick
end
function OrderKQ( order,order123,Price1,Price2,batchID,No )

	if No == "0" then
		if order123 == "1" then
			local ret1 = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID1, order.Issue1, order.BS1, 0, Price1, order.Qty1, 0, "")
			if ret1.Result then
				local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
					order.States,order.Issue1,Price1,order.Qty1,order.RunS1,order.RunNum,order.RunP1,order.RunT1)
				sendSysLog(log)

				if order.RunS1 <= 0 then
				else
					local pcid = ret1.PositionCheckID;
					local priceType = GetToPrice("Issue1",order.RunP1)
					local tick = GetToTick(order.RunT1)

					local log = sys_format("pcid = %s,RunS1 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
						pcid,order.RunS1,order.RunNum,priceType,tick)
					_WriteErrorLog(log)
					PosSetAutoAmend(pcid, order.RunS1, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
				end

			end
			local ret2 = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID2, order.Issue2, order.BS2, 0, Price2, order.Qty2, 0, "")
			if ret2.Result then
				local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
					order.States,order.Issue2,Price2,order.Qty2,order.RunS2,order.RunNum,order.RunP2,order.RunT2)
				sendSysLog(log)

				if order.RunS2 <= 0 then
				else
					local pcid = ret2.PositionCheckID;
					local priceType = GetToPrice("Issue2",order.RunP2)
					local tick = GetToTick(order.RunT2)

					local log = sys_format("pcid = %s,RunS2 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
						pcid,order.RunS2,order.RunNum,priceType,tick)
					_WriteErrorLog(log)
					PosSetAutoAmend(pcid, order.RunS2, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
				end
			end
			ClearAutoList(order)

		elseif order123 == "2" then
			local ret = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID1, order.Issue1, order.BS1, 0, Price1, order.Qty1, 0, "")
			if ret.Result then
				local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
					order.States,order.Issue1,Price1,order.Qty1,order.RunS1,order.RunNum,order.RunP1,order.RunT1)
				sendSysLog(log)

				if order.RunS1 <= 0 then
				else
					local pcid = ret.PositionCheckID;
					local priceType = GetToPrice("Issue1",order.RunP1)
					local tick = GetToTick(order.RunT1)

					local log = sys_format("pcid = %s,RunS1 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
						pcid,order.RunS1,order.RunNum,priceType,tick)
					_WriteErrorLog(log)
					PosSetAutoAmend(pcid, order.RunS1, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
				end

				local ret1 = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID2, order.Issue2, order.BS2, 0, Price2, order.Qty2, 0, "")
				if ret1.Result then
					local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
						order.States,order.Issue2,Price2,order.Qty2,order.RunS2,order.RunNum,order.RunP2,order.RunT2)
					sendSysLog(log)

					if order.RunS2 <= 0 then
					else
						local pcid = ret1.PositionCheckID;
						local priceType = GetToPrice("Issue2",order.RunP2)
						local tick = GetToTick(order.RunT2)

						local log = sys_format("pcid = %s,RunS2 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
							pcid,order.RunS2,order.RunNum,priceType,tick)
						_WriteErrorLog(log)
						PosSetAutoAmend(pcid, order.RunS2, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
					end
					ClearAutoList(order)

				else
					local log = ret1.Reason
					_WriteErrorLog(log)
					ClearAutoList(order)

				end

			else
				local log = ret.Reason
				_WriteErrorLog(log)
				ClearAutoList(order)

			end

		elseif order123 == "3" then
			local tOtherSide = {};

			tOtherSide.BAMapID = gFuturebaMapID;
			tOtherSide.IssueCode = order.Issue2;
			tOtherSide.BASubID = order.BaSubID2
			tOtherSide.BuySell = order.BS2;
			tOtherSide.OpenClose = 0;
			tOtherSide.Quantity = order.Qty2;
			tOtherSide.Price = order.Price2;
			tOtherSide.Tick = order.Tick2
			tOtherSide.States = order.States

			tOtherSide.RunP = order.RunP2
			tOtherSide.RunT = order.RunT2
			tOtherSide.RunS = order.RunS2
			tOtherSide.RunNum = order.RunNum
			tOtherSide.Iss = "Issue2"

			gtKQOrderList[batchID] = gtKQOrderList[batchID] or {}
			gtKQOrderList[batchID].tOtherSide = gtKQOrderList[batchID].tOtherSide or {}
			gtKQOrderList[batchID].tOtherSide = tOtherSide

			local ret = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID1, order.Issue1, order.BS1, 0, Price1, order.Qty1, 0, "",batchID)
			if ret.Result then
				local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
					order.States,order.Issue1,Price1,order.Qty1,order.RunS1,order.RunNum,order.RunP1,order.RunT1)
				sendSysLog(log)

				if order.RunS1 <= 0 then
				else
					local pcid = ret.PositionCheckID;
					local priceType = GetToPrice("Issue1",order.RunP1)
					local tick = GetToTick(order.RunT1)

					local log = sys_format("pcid = %s,RunS1 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
						pcid,order.RunS1,order.RunNum,priceType,tick)
					_WriteErrorLog(log)
					PosSetAutoAmend(pcid, order.RunS1, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
				end
				ClearAutoList(order)
			else
				local log = ret.Reason
				_WriteErrorLog(log)
				ClearAutoList(order)

			end
		end

	elseif No == "1" then
		if order123 == "1" then
			local ret1 = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID2, order.Issue2, order.BS2, 0, Price2, order.Qty2, 0, "")
			if ret1.Result then
				local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
					order.States,order.Issue2,Price2,order.Qty2,order.RunS2,order.RunNum,order.RunP2,order.RunT2)
				sendSysLog(log)

				if order.RunS2 <= 0 then
				else
					local pcid = ret1.PositionCheckID;
					local priceType = GetToPrice("Issue2",order.RunP2)
					local tick = GetToTick(order.RunT2)

					local log = sys_format("pcid = %s,RunS2 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
						pcid,order.RunS2,order.RunNum,priceType,tick)
					_WriteErrorLog(log)
					PosSetAutoAmend(pcid, order.RunS2, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
				end

			end
			local ret2 = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID1, order.Issue1, order.BS1, 0, Price1, order.Qty1, 0, "")
			if ret2.Result then
				local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
					order.States,order.Issue1,Price1,order.Qty1,order.RunS1,order.RunNum,order.RunP1,order.RunT1)
				sendSysLog(log)

				if order.RunS1 <= 0 then
				else
					local pcid = ret2.PositionCheckID;
					local priceType = GetToPrice("Issue1",order.RunP1)
					local tick = GetToTick(order.RunT1)

					local log = sys_format("pcid = %s,RunS1 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
						pcid,order.RunS1,order.RunNum,priceType,tick)
					_WriteErrorLog(log)
					PosSetAutoAmend(pcid, order.RunS2, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
				end
			end
			ClearAutoList(order)

		elseif order123 == "2" then
			local ret = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID2, order.Issue2, order.BS2, 0, Price2, order.Qty2, 0, "")
			if ret.Result then
				local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
					order.States,order.Issue2,Price2,order.Qty2,order.RunS2,order.RunNum,order.RunP2,order.RunT2)
				sendSysLog(log)

				if order.RunS2 <= 0 then
				else
					local pcid = ret.PositionCheckID;
					local priceType = GetToPrice("Issue2",order.RunP2)
					local tick = GetToTick(order.RunT2)

					local log = sys_format("pcid = %s,RunS2 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
						pcid,order.RunS2,order.RunNum,priceType,tick)
					_WriteErrorLog(log)
					PosSetAutoAmend(pcid, order.RunS2, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
				end

				local ret1 = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID1, order.Issue1, order.BS1, 0, Price1, order.Qty1, 0, "")
				if ret1.Result then
					local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
						order.States,order.Issue1,Price1,order.Qty1,order.RunS1,order.RunNum,order.RunP1,order.RunT1)
					sendSysLog(log)

					if order.RunS1 <= 0 then
					else
						local pcid = ret1.PositionCheckID;
						local priceType = GetToPrice("Issue1",order.RunP1)
						local tick = GetToTick(order.RunT1)

						local log = sys_format("pcid = %s,RunS1 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
							pcid,order.RunS1,order.RunNum,priceType,tick)
						_WriteErrorLog(log)
						PosSetAutoAmend(pcid, order.RunS1, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
					end

					ClearAutoList(order)

				else
					local log = ret1.Reason
					_WriteErrorLog(log)
					ClearAutoList(order)

				end

			else
				local log = ret.Reason
				_WriteErrorLog(log)
				ClearAutoList(order)

			end

		elseif order123 == "3" then
			local tOtherSide = {};

			tOtherSide.BAMapID = gFuturebaMapID;
			tOtherSide.IssueCode = order.Issue1;
			tOtherSide.BASubID = order.BaSubID1
			tOtherSide.BuySell = order.BS1;
			tOtherSide.OpenClose = 0;
			tOtherSide.Quantity = order.Qty1;
			tOtherSide.Price = order.Price1;
			tOtherSide.Tick = order.Tick1
			tOtherSide.States = order.States

			tOtherSide.RunP = order.RunP1
			tOtherSide.RunT = order.RunT1
			tOtherSide.RunS = order.RunS1
			tOtherSide.RunNum = order.RunNum
			tOtherSide.Iss = "Issue1"

			gtKQOrderList[batchID] = gtKQOrderList[batchID] or {}
			gtKQOrderList[batchID].tOtherSide = gtKQOrderList[batchID].tOtherSide or {}
			gtKQOrderList[batchID].tOtherSide = tOtherSide

			local ret = PosSubmitSingleOrder(gFuturebaMapID, order.BaSubID2, order.Issue2, order.BS2, 0, Price2, order.Qty2, 0, "",batchID)
			if ret.Result then
				local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
					order.States,order.Issue2,Price2,order.Qty2,order.RunS2,order.RunNum,order.RunP2,order.RunT2)
				sendSysLog(log)

				if order.RunS2 <= 0 then
				else
					local pcid = ret.PositionCheckID;
					local priceType = GetToPrice("Issue2",order.RunP2)
					local tick = GetToTick(order.RunT2)

					local log = sys_format("pcid = %s,RunS2 = %s,RunNum = %s,priceType = %s,POS_ADJ_BY_TICK,tick = %s",
						pcid,order.RunS2,order.RunNum,priceType,tick)
					_WriteErrorLog(log)
					PosSetAutoAmend(pcid, order.RunS2, order.RunNum, priceType, POS_ADJ_BY_TICK, tick)
				end
			else
				local log = ret.Reason
				_WriteErrorLog(log)
				ClearAutoList(order)

			end
		end
	end
end

-- 自动开仓回调

_OnEventDefined(AutoOrderEvent autoOrder)
	local set1 = autoOrder._GetFld("Set1"); -- 正向开关 -- “0”表示开；“1”表示关
	local set2 = autoOrder._GetFld("Set2"); -- 反向开关
	local states = autoOrder._GetFld("States");
	local issue1 = autoOrder._GetFld("Issue1");
	local issue2 = autoOrder._GetFld("Issue2");
	local qty1   = autoOrder._GetFld("Qty1");
	local qty2   = autoOrder._GetFld("Qty2");

	qty1 = qty1.getNumberValue()
	qty2 = qty2.getNumberValue()

	local price1 = autoOrder._GetFld("Price1");
	local tick1  = autoOrder._GetFld("Tick1");
	local price2 = autoOrder._GetFld("Price2");
	local tick2  = autoOrder._GetFld("Tick2");

	local orderWay = autoOrder._GetFld("OrderWay");
	local order123 = autoOrder._GetFld("Order123");
	local runP1    = autoOrder._GetFld("RunP1");
	local runT1    = autoOrder._GetFld("RunT1");
	local runS1    = autoOrder._GetFld("RunS1");
	local runP2    = autoOrder._GetFld("RunP2");
	local runT2    = autoOrder._GetFld("RunT2");
	local runS2    = autoOrder._GetFld("RunS2");
	local basis1   = autoOrder._GetFld("Basis1");
	local basis2   = autoOrder._GetFld("Basis2");
	local runNum   = autoOrder._GetFld("RunNum");

	runS1  = runS1.getNumberValue()
	runS2  = runS2.getNumberValue()
	runNum = runNum.getNumberValue()
	local log = sys_format("AutoOrderEvent:issue1 = %s,issue2 = %s",issue1,issue2)
	_WriteErrorLog(log)
	local iss1 = ""
	local iss2 = ""
	if set1 == "1" then
		gkaiguan1 = "1"
		gtAutoOrderList["自动开仓"] = {}
	end
	if set2 == "1" then
		gkaiguan2 = "1"
		gtAutoOrderList["自动开反仓"] = {}
	end



	if issue1 and issue1 ~= "" and issue2 and issue2~="" then
		iss1 = sys_sub(issue1,3,-1)
		iss1 = iss1.getNumberValue()
		iss2 = sys_sub(issue2,3,-1)
		iss2 = iss2.getNumberValue()

		local portID = creatID(issue1,issue2)
		local batchID = sys_sub(portID,-3,-1)

		local buySell1 = "3"
		local buySell2 = "1"
		local baSubID1 = "3" .. portID
		local baSubID2 = "1" .. portID

		if states == "自动开仓" then
			basis1 = basis1.getNumberValue()
			local log = sys_format("存basis1 = %s",basis1)
			--_WriteErrorLog(log)
			if set1 == "0" then
				gkaiguan1 = "0"
				gtAutoOrderList["自动开仓"] = gtAutoOrderList["自动开仓"] or {}
				gtAutoOrderList["自动开仓"].PortID = portID
				gtAutoOrderList["自动开仓"].Issue1 = issue1
				gtAutoOrderList["自动开仓"].Issue2 = issue2
				gtAutoOrderList["自动开仓"].Qty1   = qty1
				gtAutoOrderList["自动开仓"].Qty2   = qty2
				gtAutoOrderList["自动开仓"].Price1 = price1
				gtAutoOrderList["自动开仓"].Tick1  = tick1
				gtAutoOrderList["自动开仓"].Price2 = price2
				gtAutoOrderList["自动开仓"].Tick2  = tick2
				gtAutoOrderList["自动开仓"].RunP1  = runP1
				gtAutoOrderList["自动开仓"].RunT1  = runT1
				gtAutoOrderList["自动开仓"].RunS1  = runS1
				gtAutoOrderList["自动开仓"].RunP2  = runP2
				gtAutoOrderList["自动开仓"].RunT2  = runT2
				gtAutoOrderList["自动开仓"].RunS2  = runS2
				gtAutoOrderList["自动开仓"].RunNum  = runNum
				gtAutoOrderList["自动开仓"].BS1    = buySell1
				gtAutoOrderList["自动开仓"].BS2    = buySell2
				gtAutoOrderList["自动开仓"].BaSubID1 = baSubID1
				gtAutoOrderList["自动开仓"].BaSubID2 = baSubID2
				gtAutoOrderList["自动开仓"].OrderWay = orderWay
				gtAutoOrderList["自动开仓"].Order123 = order123
				gtAutoOrderList["自动开仓"].Basis1   = basis1
				gtAutoOrderList["自动开仓"].Iss1     = iss1
				gtAutoOrderList["自动开仓"].Iss2     = iss2
				gtAutoOrderList["自动开仓"].BatchID  = batchID
				gtAutoOrderList["自动开仓"].States   = "自动开仓"

			elseif set1 == "1" then
				gkaiguan1 = "1"
				gtAutoOrderList["自动开仓"] = {}
			end

		elseif states == "自动开反仓" then
			basis2 = basis2.getNumberValue()
			local log = sys_format("存basis2 = %s",basis2)
			_WriteErrorLog(log)
			if set2 == "0" then
				gkaiguan2 = "0"
				gtAutoOrderList["自动开反仓"] = gtAutoOrderList["自动开仓"] or {}
				gtAutoOrderList["自动开反仓"].PortID = portID
				gtAutoOrderList["自动开反仓"].Issue1 = issue1
				gtAutoOrderList["自动开反仓"].Issue2 = issue2
				gtAutoOrderList["自动开反仓"].Qty1   = qty1
				gtAutoOrderList["自动开反仓"].Qty2   = qty2
				gtAutoOrderList["自动开反仓"].Price1 = price1
				gtAutoOrderList["自动开反仓"].Tick1  = tick1
				gtAutoOrderList["自动开反仓"].Price2 = price2
				gtAutoOrderList["自动开反仓"].Tick2  = tick2
				gtAutoOrderList["自动开反仓"].RunP1  = runP1
				gtAutoOrderList["自动开反仓"].RunT1  = runT1
				gtAutoOrderList["自动开反仓"].RunS1  = runS1
				gtAutoOrderList["自动开反仓"].RunP2  = runP2
				gtAutoOrderList["自动开反仓"].RunT2  = runT2
				gtAutoOrderList["自动开反仓"].RunS2  = runS2
				gtAutoOrderList["自动开反仓"].RunNum  = runNum
				gtAutoOrderList["自动开反仓"].BS1    = buySell1
				gtAutoOrderList["自动开反仓"].BS2    = buySell2
				gtAutoOrderList["自动开反仓"].BaSubID1 = baSubID1
				gtAutoOrderList["自动开反仓"].BaSubID2 = baSubID2
				gtAutoOrderList["自动开反仓"].OrderWay = orderWay
				gtAutoOrderList["自动开反仓"].Order123 = order123
				gtAutoOrderList["自动开反仓"].Basis2   = basis2
				gtAutoOrderList["自动开反仓"].Iss1     = iss1
				gtAutoOrderList["自动开反仓"].Iss2     = iss2
				gtAutoOrderList["自动开反仓"].BatchID  = batchID
				gtAutoOrderList["自动开反仓"].States   = "自动开反仓"

			elseif set2 == "1" then
				gkaiguan2 = "1"
				gtAutoOrderList["自动开反仓"] = {}
			end
		end
	end
_End

function AutoOrder(b1,b2)
	--_WriteErrorLog("AutoOrder")

	local submit1 = {}
	local submit2 = {}

	if gkaiguan1 == "1" and gkaiguan2 == "1" then
	else
		submit1 = gtAutoOrderList["自动开仓"]
		submit2 = gtAutoOrderList["自动开反仓"]

		if gkaiguan1 == "0" then
			if submit1 then
				if b1 > submit1.Basis1 then
					local portID = submit1.PortID
					local Price1 = GetOrderPrice(submit1.Issue1,0,submit1.Qty1,submit1.Price1,submit1.Tick1)
					local Price2 = GetOrderPrice(submit1.Issue2,1,submit1.Qty2,submit1.Price2,submit1.Tick2)
					buyPrice = Price1.getNumberValue()
					sellPrice = Price2.getNumberValue()

					if not gtCombinList[portID] then
						gtCombinList[portID] = {}
						--qym
						gtCombinList[portID].Issue1 = submit1.Issue1
						gtCombinList[portID].Issue2 = submit1.Issue2
						gtCombinList[portID].AvlQty = submit1.Qty1
						gtCombinList[portID].Status = "建仓"
						gtCombinList[portID].StopFlag = "止盈止损启动"
						gtCombinList[portID].BuyQty = "-"
						gtCombinList[portID].SellQty = "-"
						local InPrice = sys_format("%0.2f",buyPrice - sellPrice)
						gtCombinList[portID].InPrice = InPrice
						gtCombinList[portID].OutPrice = "-"
						gtCombinList[portID].ValuationPL = 0
						gtCombinList[portID].Fare = 0
						local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
						local futureInvestorID = ""
						if futureAccountCode then
							futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID or ""
							gtCombinList[portID].InvestorID = futureInvestorID
						end

						SaveCombinData(portID,gtCombinList[portID]) 		--保存套利列表
						SendCombinList(portID,futureInvestorID)
					end

					local log = sys_format("Issue1 = %s,Issue2 = %s,states = %s,OrderWay = %s",submit1.Issue1,submit1.Issue2,submit1.States,submit1.OrderWay)
					_WriteErrorLog(log)
					if (submit1.States == "自动开仓" and submit1.OrderWay == "近期优先" and submit1.Iss1 < submit1.Iss2)
					or (submit1.States == "自动开仓" and submit1.OrderWay == "远期优先" and submit1.Iss1 > submit1.Iss2) then

						_WriteErrorLog("自动开仓下单逻辑")
						Notice(submit1.States)
						OrderKQ( submit1,submit1.Order123,Price1,Price2,submit1.BatchID,"0" )
					elseif (submit1.States == "自动开仓" and submit1.OrderWay == "远期优先" and submit1.Iss1 < submit1.Iss2)
					or (submit1.States == "自动开仓" and submit1.OrderWay == "近期优先" and submit1.Iss1 > submit1.Iss2) then

						_WriteErrorLog("自动开仓下单逻辑")
						Notice(submit1.States)
						OrderKQ( submit1,submit1.Order123,Price1,Price2,submit1.BatchID,"1" )
					end
				end
			end
		end

		if gkaiguan2 == "0" then
			if submit2 then
				if b2 < submit2.Basis2 then
					local portID = submit2.PortID
					local Price1 = GetOrderPrice(submit2.Issue1,0,submit2.Qty1,submit2.Price1,submit2.Tick1)
					local Price2 = GetOrderPrice(submit2.Issue2,1,submit2.Qty2,submit2.Price2,submit2.Tick2)
					buyPrice = Price1.getNumberValue()
					sellPrice = Price2.getNumberValue()

					if not gtCombinList[portID] then
						gtCombinList[portID] = {}
						--qym
						gtCombinList[portID].Issue1 = submit2.Issue1
						gtCombinList[portID].Issue2 = submit2.Issue2
						gtCombinList[portID].AvlQty = submit2.Qty1
						gtCombinList[portID].Status = "建仓"
						gtCombinList[portID].StopFlag = "止盈止损启动"
						gtCombinList[portID].BuyQty = "-"
						gtCombinList[portID].SellQty = "-"
						local InPrice = sys_format("%0.2f",buyPrice - sellPrice)
						gtCombinList[portID].InPrice = InPrice
						gtCombinList[portID].OutPrice = "-"
						gtCombinList[portID].ValuationPL = 0
						gtCombinList[portID].Fare = 0
						local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
						local futureInvestorID = ""
						if futureAccountCode then
							futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID or ""
							gtCombinList[portID].InvestorID = futureInvestorID
						end

						SaveCombinData(portID,gtCombinList[portID]) 		--保存套利列表
						SendCombinList(portID,futureInvestorID)
					end

					local log = sys_format("Issue1 = %s,Issue2 = %s,states = %s,OrderWay = %s",submit2.Issue1,submit2.Issue2,submit2.States,submit2.OrderWay)
					_WriteErrorLog(log)
					if (submit2.States == "自动开反仓" and submit2.OrderWay == "近期优先" and submit2.Iss1 < submit2.Iss2)
					or (submit2.States == "自动开反仓" and submit2.OrderWay == "远期优先" and submit2.Iss1 > submit2.Iss2) then

						_WriteErrorLog("自动开反仓下单逻辑")
						Notice(submit2.States)
						OrderKQ( submit2,submit2.Order123,Price1,Price2,submit2.BatchID,"0" )

					elseif (submit2.States == "自动开反仓" and submit2.OrderWay == "近期优先" and submit2.Iss1 > submit2.Iss2)
					or (submit2.States == "自动开反仓" and submit2.OrderWay == "远期优先" and submit2.Iss1 < submit2.Iss2) then

						_WriteErrorLog("自动开反仓下单逻辑")
						Notice(submit2.States)
						OrderKQ( submit2,submit2.Order123,Price1,Price2,submit2.BatchID,"1" )

					end
				end
			end
		end
	end
end

--套利平仓
_OnEventDefined(CombinControl1 Combin)
	local combinCode = Combin._GetFld("CombinCode")
	local issue1 = Combin._GetFld("Issue1")
	local issue2 = Combin._GetFld("Issue2")
	local qty1 = Combin._GetFld("Qty1")
	local qty2 = Combin._GetFld("Qty2")
	local price1 = Combin._GetFld("Price1")
	local price2 = Combin._GetFld("Price2")
	local tick1 = Combin._GetFld("Tick1")
	local tick2 = Combin._GetFld("Tick2")

	local buySell1 = "1"
	local buySell2 = "3"
	local baSubID1 = "3" .. combinCode
	local baSubID2 = "1" .. combinCode

	price1 = GetOrderPrice(issue1,1,qty1,price1,tick1)
	price2 = GetOrderPrice(issue2,0,qty2,price2,tick2)

	qty1 = qty1.getNumberValue()
	qty2 = qty2.getNumberValue()

	local key1    = gFuturebaMapID .. "." .. baSubID1 .. "." .. issue1;
	local posQty1
	if _PosPositionTable[key1] then
		posQty1 = _PosPositionTable[key1].AvlQuantity
	end

	local posQty2
	local key2    = gFuturebaMapID .. "." .. baSubID2 .. "." .. issue2;
	if _PosPositionTable[key2] then
		posQty2 = _PosPositionTable[key2].AvlQuantity
	end

	if qty1 > posQty1 then
		qty1 = posQty1
	end

	if qty2 > posQty2 then
		qty2 = posQty2
	end

	if qty1 > 0 then
		local ret1 = PosSubmitSingleOrder(gFuturebaMapID, baSubID1, issue1, buySell1, 1, price1, qty1, 0, "")
		if ret1.Result then
			local log = sys_format("平多仓：合约[%s],价格[%s],数量[%s],",issue1,price1,qty1)
			sendSysLog(log)

	else
		local log = ret1.Reason
		sendSysLog(log)

		end
	end

	if qty2 > 0 then
		local ret2 = PosSubmitSingleOrder(gFuturebaMapID, baSubID2, issue2, buySell2, 1, price2, qty2, 0, "")
		if ret2.Result then
			local log = sys_format("平空仓：合约[%s],价格[%s],数量[%s],",issue2,price2,qty2)
			sendSysLog(log)

	else
		local log = ret2.Reason
		sendSysLog(log)

		end
	end

	gtCombinList[combinCode] = gtCombinList[combinCode] or {}
	gtCombinList[combinCode].Status = "平仓"
	if price1 and price2 then
		gtCombinList[combinCode].OutPrice = price1 - price2
	end
	local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	local futureInvestorID = ""
	if futureAccountCode then
		futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
	end
	SendCombinList(combinCode,futureInvestorID)


_End
--套利止损
_OnEventDefined(CombinControl2 Combin)
	local combinCode = Combin._GetFld("CombinCode")
	local issue1 = Combin._GetFld("Issue1")
	local issue2 = Combin._GetFld("Issue2")
	local qty1 = Combin._GetFld("Qty1")
	local qty2 = Combin._GetFld("Qty2")
	local price1 = Combin._GetFld("Price1")
	local price2 = Combin._GetFld("Price2")
	local price3 = Combin._GetFld("Price3")
	local price4 = Combin._GetFld("Price4")
	local tick1 = Combin._GetFld("Tick1")
	local tick2 = Combin._GetFld("Tick2")
	local tick3 = Combin._GetFld("Tick3")
	local tick4 = Combin._GetFld("Tick4")
	local zhiYing = Combin._GetFld("ZhiYing")   --复选止盈框
	local zhiSun = Combin._GetFld("ZhiSun")		--复选止损框
	local ok = Combin._GetFld("OK")             --复选下单确认框
	local upDian = Combin._GetFld("UpDian")     --止盈点
	local downDian = Combin._GetFld("DownDian") --止损点

	local gouxuan1
	local gouxuan2
	local gouxuan3
	if zhiYing == "0" then
		gouxuan1 = "是"
	else
		gouxuan1 = "否"
	end

	if zhiSun == "0" then
		gouxuan2 = "是"
	else
		gouxuan2 = "否"
	end

	if ok == "0" then
		gouxuan3 = "是"
	else
		gouxuan3 = "否"
	end

	local log = sys_format("止盈止损设置：组合号[%s],多头数量[%s],空头数量[%s],止盈勾选[%s],止盈点[%s],止损勾选[%s],止损点[%s],触发提示[%s]",
		combinCode,qty1,qty2,gouxuan1,upDian,gouxuan2,downDian,gouxuan3)
	sendSysLog(log)

	local buySell1 = "1"
	local buySell2 = "3"
	local baSubID1 = "3" .. combinCode
	local baSubID2 = "1" .. combinCode

	if qty1 then
		qty1     = qty1.getNumberValue()
		local key1    = gFuturebaMapID .. "." .. baSubID1 .. "." .. issue1;
		local posQty1
		if _PosPositionTable then
			posQty1 = _PosPositionTable[key1].AvlQuantity -- 持仓量
		end

		if qty1 > posQty1 then
			qty1 = posQty1
		end
	end

	if qty2 then
		qty2     = qty2.getNumberValue()
		local key2    = gFuturebaMapID .. "." .. baSubID2 .. "." .. issue2;
		local posQty2
		if _PosPositionTable[key2] then
			posQty2 = _PosPositionTable[key2].AvlQuantity -- 持仓量
		end

		if qty2 > posQty2 then
			qty2 = posQty2
		end
	end

	if upDian then
		upDian   = upDian.getNumberValue()
	end

	if downDian then
		downDian = downDian.getNumberValue()
	end

	gtCloseUpDown[combinCode] = gtCloseUpDown[combinCode] or {}
	gtCloseUpDown[combinCode].Issue1   = issue1
	gtCloseUpDown[combinCode].Issue2   = issue2
	gtCloseUpDown[combinCode].Qty1     = qty1
	gtCloseUpDown[combinCode].Qty2     = qty2
	gtCloseUpDown[combinCode].Price1   = price1
	gtCloseUpDown[combinCode].Price2   = price2
	gtCloseUpDown[combinCode].Price3   = price3
	gtCloseUpDown[combinCode].Price4   = price4
	gtCloseUpDown[combinCode].Tick1    = tick1
	gtCloseUpDown[combinCode].Tick2    = tick2
	gtCloseUpDown[combinCode].Tick3    = tick3
	gtCloseUpDown[combinCode].Tick4    = tick4
	gtCloseUpDown[combinCode].ZhiYing  = zhiYing
	gtCloseUpDown[combinCode].ZhiSun   = zhiSun
	gtCloseUpDown[combinCode].OK       = ok
	gtCloseUpDown[combinCode].UpDian   = upDian
	gtCloseUpDown[combinCode].DownDian = downDian
	gtCloseUpDown[combinCode].BuySell1 = buySell1
	gtCloseUpDown[combinCode].BuySell2 = buySell2
	gtCloseUpDown[combinCode].BaSubID1 = baSubID1
	gtCloseUpDown[combinCode].BaSubID2 = baSubID2

_End

-- 止盈止损开关
_OnEventDefined(StopProfit stopProfit)
	local combinCode = stopProfit._GetFld("CombinCode")
	local kaiguan = stopProfit._GetFld("Kaiguan")

	local log = sys_format("Kaiguan = %s",kaiguan)
	_WriteErrorLog(log)

	if gtCloseUpDown[combinCode] then
		--gtCloseUpDown[combinCode] = gtCloseUpDown[combinCode] or {}
		gtUpDownKaiGuan[combinCode] = gtUpDownKaiGuan[combinCode] or {}
		local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
		local futureInvestorID = ""
		if futureAccountCode then
			futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
		end
		if kaiguan == "0" then
			gtUpDownKaiGuan[combinCode].Kaiguan = 0

			gtCombinList[combinCode] = gtCombinList[combinCode] or {}
			gtCombinList[combinCode].StopFlag = "止盈止损关闭"

			SendCombinList(combinCode,futureInvestorID)

		elseif kaiguan == "1" then
			gtUpDownKaiGuan[combinCode] = nil

			gtCombinList[combinCode] = gtCombinList[combinCode] or {}
			gtCombinList[combinCode].StopFlag = "止盈止损启动"

			SendCombinList(combinCode,futureInvestorID)

		end
	else
		local DTSEvent setMessageNow = _CreateEventObject("SetMessageNow") -- 止盈止损触发告知界面
		setMessageNow._SetFld("No","1")
		_SendToClients(setMessageNow)

		UpDownNotice()

	end

_End

--接受止盈止损确认回调
_OnEventDefined(BackMessage backMessage)
	local combinCode = backMessage._GetFld("CombinCode")
	local ok = backMessage._GetFld("Yes")

	if ok == "yes" then
		OrderUpDown(combinCode,gtOrderMessage[combinCode])

	elseif ok == "no" then

	end

_End


function CloseUpDown() -- 止盈止损判断逻辑
	for combinCode,value in pairs(gtUpDownKaiGuan) do
		-- 计算实时盈亏
		if gtCloseUpDown[combinCode] then
			if 	gtCombinList[combinCode] then
				local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
				local futureInvestorID = ""
				if futureAccountCode then
					futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
				end
				local info   = gtCombinList[combinCode]
				local issue1 = info.Issue1
				local issue2 = info.Issue2
				local buyValuationPL = 0
				local sellValuationPL = 0

				local gValuationPL
				if gtArbitragePositionTable[combinCode] and futureAccountCode then
					local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID or ""

					if info.BuyQty and info.BuyQty ~= "-" then
						local key = futureInvestorID .. issue1 .. "3"
						if gtArbitragePositionTable[combinCode][key] then
							buyValuationPL = gtArbitragePositionTable[combinCode][key].ValuationPL or 0
						end
					end

					if info.SellQty and info.SellQty ~= "-" then
						local key = futureInvestorID .. issue2 .. "1"
						if gtArbitragePositionTable[combinCode][key] then
							sellValuationPL = gtArbitragePositionTable[combinCode][key].ValuationPL or 0
						end
					end

					local ValuationPL = buyValuationPL + sellValuationPL
					ValuationPL = sys_format("%0.1f",ValuationPL)
					gValuationPL = ValuationPL.getNumberValue()

					gtCombinList[combinCode].ValuationPL = ValuationPL
					SendCombinList(combinCode,futureInvestorID)
				else
					local log = sys_format("not gtArbitragePositionTable:CombinCode[%s]",combinCode)
					_WriteErrorLog(log)
				end

				--止盈止损满足逻辑
				local table = gtCloseUpDown[combinCode]
				local zhiYing = table.ZhiYing -- 止盈复选框
				local zhiSun  = table.ZhiSun  -- 止损复选框

				local upDian = table.UpDian
				local downDian = table.DownDian

				local log = sys_format("ValuationPL(盈亏) = %s,止盈点 = %s,止损点 = %s",gValuationPL,upDian,downDian)
				_WriteErrorLog(log)

				if zhiYing == "0" then -- 开启止盈
					if gValuationPL > upDian then -- 实时盈亏大于止盈点
						local log = sys_format("ValuationPL(盈亏) = %s,止盈点 = %s",gValuationPL,upDian)
						_WriteErrorLog(log)

						gtUpDownKaiGuan[combinCode] = nil-- 清开关
						UpDownNotice()

						gtCombinList[combinCode] = gtCombinList[combinCode] or {}
						gtCombinList[combinCode].StopFlag = "止盈止损启动"
						SendCombinList(combinCode,futureInvestorID)

						OrderMessage(combinCode,table,"1") -- 存下单数据
						if table.OK == "0" then -- 开启下单提示
							local DTSEvent yesMessage = _CreateEventObject("YesMessage") -- 发送下单提示到界面
							yesMessage._SetFld("CombinCode",combinCode)
							_SendToClients(yesMessage)

						else
							local tabletype = gtOrderMessage[combinCode]
							OrderUpDown(combinCode,tabletype) -- 止盈下单

							--table = {}
						end

					end

				elseif zhiYing == "1" then

				end

				if zhiSun == "0" then -- 开始止损
					if gValuationPL < downDian then -- 实时盈亏小于止损点
						local log = sys_format("ValuationPL(盈亏) = %s,止损点 = %s",gValuationPL,downDian)
						_WriteErrorLog(log)

						gtUpDownKaiGuan[combinCode] = nil -- 清开关
						UpDownNotice()

						gtCombinList[combinCode] = gtCombinList[combinCode] or {}
						gtCombinList[combinCode].StopFlag = "止盈止损启动"
						SendCombinList(combinCode,futureInvestorID)

						OrderMessage(combinCode,table,"2")
						if table.OK == "0" then -- 开启下单提示
							local DTSEvent yesMessage = _CreateEventObject("YesMessage") -- 发送下单提示到界面
							yesMessage._SetFld("CombinCode",combinCode)
							_SendToClients(yesMessage)

						else
							local tabletype = gtOrderMessage[combinCode]
							OrderUpDown(combinCode,tabletype) -- 止损下单

							--table = {}
						end

					end

				elseif zhiSun == "1" then

				end
			end
		end
	end

end

function OrderMessage(combinCode,table,type)
	local issue1
	local issue2
	local qty1
	local qty2
	local price1
	local price2
	local tick1
	local tick2
	local buySell1
	local buySell2
	local baSubID1
	local baSubID2

	if not gtOrderMessage[combinCode] then
		gtOrderMessage[combinCode] = {}
	end

	if type == "1" then
		issue1   = table.Issue1
		issue2   = table.Issue2
		qty1     = table.Qty1
		qty2     = table.Qty2
		price1   = table.Price1
		price2   = table.Price2
		tick1    = table.Tick1
		tick2    = table.Tick2
		buySell1 = table.BuySell1
		buySell2 = table.BuySell2
		baSubID1 = table.BaSubID1
		baSubID2 = table.BaSubID2

		gtOrderMessage[combinCode].Price1   = price1
		gtOrderMessage[combinCode].Price2   = price2
		gtOrderMessage[combinCode].Tick1    = tick1
		gtOrderMessage[combinCode].Tick2    = tick2

	elseif type == "2" then
		issue1   = table.Issue1
		issue2   = table.Issue2
		qty1     = table.Qty1
		qty2     = table.Qty2
		price3   = table.Price3
		price4   = table.Price4
		tick3    = table.Tick3
		tick4    = table.Tick4
		buySell1 = table.BuySell1
		buySell2 = table.BuySell2
		baSubID1 = table.BaSubID1
		baSubID2 = table.BaSubID2

		gtOrderMessage[combinCode].Price1   = price3
		gtOrderMessage[combinCode].Price2   = price4
		gtOrderMessage[combinCode].Tick1    = tick3
		gtOrderMessage[combinCode].Tick2    = tick4

	end

	gtOrderMessage[combinCode].Issue1   = issue1
	gtOrderMessage[combinCode].Issue2   = issue2
	gtOrderMessage[combinCode].Qty1     = qty1
	gtOrderMessage[combinCode].Qty2     = qty2
	gtOrderMessage[combinCode].BuySell1 = buySell1
	gtOrderMessage[combinCode].BuySell2 = buySell2
	gtOrderMessage[combinCode].BaSubID1 = baSubID1
	gtOrderMessage[combinCode].BaSubID2 = baSubID2

end

function OrderUpDown(combinCode,table)
	_WriteErrorLog("进入OrderUpDown")
	local price1 = GetOrderPrice(table.Issue1,1,table.Qty1,table.Price1,table.Tick1)
	local price2 = GetOrderPrice(table.Issue2,0,table.Qty2,table.Price2,table.Tick2)

	if table.Qty1 > 0 then
		local ret1 = PosSubmitSingleOrder(gFuturebaMapID, table.BaSubID1, table.Issue1, table.BuySell1, 1, price1, table.Qty1, 0, "")
		if ret1.Result then
			local log = sys_format("止盈止损，平多仓：合约[%s],价格[%s],数量[%s],",table.Issue1,price1,table.Qty1)
			sendSysLog(log)

		else
			local log = ret1.Reason
			sendSysLog(log)

		end
	end

	if table.Qty2 > 0 then
		local ret2 = PosSubmitSingleOrder(gFuturebaMapID, table.BaSubID2, table.Issue2, table.BuySell2, 1, price2, table.Qty2, 0, "")
		if ret2.Result then
			local log = sys_format("止盈止损，平空仓：合约[%s],价格[%s],数量[%s],",table.Issue2,price2,table.Qty2)
			sendSysLog(log)

		else
			local log = ret2.Reason
			sendSysLog(log)

		end
	end

	gtCombinList[combinCode] = gtCombinList[combinCode] or {}
	gtCombinList[combinCode].Status = "平仓"

	if price1 and price2 then
		gtCombinList[combinCode].OutPrice = price1 - price2
	end

	local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	local futureInvestorID = ""
	if futureAccountCode then
		futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
	end
	SendCombinList(combinCode,futureInvestorID)

end

function UpDownNotice()
	local DTSEvent upDownNotice = _CreateEventObject("UpDownNotice") -- 止盈止损触发告知界面
	upDownNotice._SetFld("No","1")
	_SendToClients(upDownNotice)

end
