--@@����������Ϲ���
--version:1.001.20141125
--��ϼ۲�ͼ�޸�:
--1.��ָ�ڻ�ѡ����������Լ����ú�Լ�����õ����������
--2.ͼ�δ�������Լ�������ݿ�ʼ���
_WriteAplLog("����������Ϲ��� Version:2.003 2014-02-18")
date = require('date')
local luasql = require("luasql.mysql");
require "serialize"
require "callMATLAB"
local cipher = require("dts.util.Cipher");
------------------
--���ݿ�����߼�--
------------------
local DTS_DB_SERVER_NAME = os.getenv("DTS_DB_SERVER_NAME");
local DTS_DB_SERVER_HOST = os.getenv("DTS_HOSTNAME");
local _,_,DTS_DB_SERVER_IP = DTS_DB_SERVER_NAME:find("PORT%s*=%s*([^;]+)");
local DTS_DB_DB_NAME = os.getenv("DTS_DB_DB_NAME");
local DTS_DB_USER_NAME = cipher.decrypt(os.getenv("DTS_DB_USER_NAME"));
local DTS_DB_PASSWD = cipher.decrypt(os.getenv("DTS_DB_PASSWD"));

_WriteAplLog(DTS_DB_SERVER_NAME)
_WriteAplLog(DTS_DB_SERVER_HOST)
_WriteAplLog(DTS_DB_SERVER_IP)
_WriteAplLog(DTS_DB_DB_NAME)
_WriteAplLog(DTS_DB_USER_NAME)
_WriteAplLog(DTS_DB_PASSWD)

local env = assert(luasql.mysql());

local function Close(dataEx)
    dataEx.con:close();
    dataEx.con = nil;
end

local function Commit(dataEx)
    dataEx.con:commit();
end

local function Rollback(dataEx)
    dataEx.con:rollback();
end

local function Insert(dataEx, tablename, tableobject)
    local insertKeys = {};
    local insertValues = {};
    for k, v in pairs(tableobject) do
        insertKeys[#insertKeys + 1] = k;
        insertValues[#insertValues + 1] = "'" .. v .. "'";
    end
    local strSql = string.format("insert into %sTable (%s) values (%s)",
        tablename, table.concat(insertKeys, ","), table.concat(insertValues, ","));
	_WriteAplLog(strSql)
    local res = dataEx.con:execute(strSql);
    Commit(dataEx);
end

local function Modify(dataEx ,condition, tablename, tableobject)
    local updateValues = {}
    for k, v in pairs(tableobject) do
        updateValues[#updateValues + 1] = k .. "= '" .. v .. "'"
    end
    local where = (type(condition) == "string" and #condition > 0 and "where") or "";
    local strSql = string.format("update %sTable set %s %s %s", tablename, table.concat(updateValues, ","), where, condition);
	_WriteAplLog(strSql)
    local res = dataEx.con:execute(strSql);
    Commit(dataEx);
end

local function Delete(dataEx, condition, tablename)
    local where = (type(condition) == "string" and #condition > 0 and "where") or "";
    local strSql = string.format("delete from %sTable %s %s", tablename, where, condition);
	_WriteAplLog(strSql)
    local res = dataEx.con:execute(strSql);
    Commit(dataEx);
end

local function Get(dataEx, condition, tablename)
	local where = (type(condition) == "string" and #condition > 0 and "where") or "";
	local strSql = string.format("select * from %sTable %s %s", tablename, where, condition);
	_WriteAplLog(strSql)
	local cur = dataEx.con:execute(strSql);
	local columns = cur:getcolnames();
	local colTypes = cur:getcoltypes();

    local totype = {};
    local default = {};
    for i,v in ipairs(colTypes) do
        if (string.match(v,"number")) then
            totype[i] = tonumber;
            default[i] = 0;
        else
            totype[i] = function(data)
            	return data
        	end;
            default[i] = "-";
        end
    end
	row = cur:fetch({}, "a");
	local result = {}
	while row do
		for i,v in pairs (columns) do
			if not result[v] then result[v] = {} end
			table.insert(result[v],row[v] or default[i])
		end
		row = cur:fetch(row,"a")
	end

	return result
end

function Connect(params)
    params = params or {};
    local connectHost = params.IP
    local connectIP = tonumber(params.PORT)
    local connectDB = params.DB
    local connectUser = params.USER
    local connectPwd = params.PWD
    local dataEx = {};
    dataEx.con = assert(env:connect(connectDB, connectUser, connectPwd, connectHost, connectIP));
    dataEx.Close = Close;
    dataEx.Insert = Insert;
    dataEx.Modify = Modify;
    dataEx.Delete = Delete;
    dataEx.Get = Get;
    return dataEx;
end


--------------------
--��Ϲ��������߼�--
--------------------
_glogFlag = "0"		--��־��ʾ��Ϣ��ʾ
_AnalDays = 201		--��ʼ����ǰ��ȡ��������
_CurrentCombin = ""	--��ǰ��ϱ��
gIssueNameList = {}	--��Լ���Ʊ�
gCombinList = {}  --�����Ϣ�б�
gCombinIssueList = {}  --�����ϸ��
gCombinIndustryList = {} --�����ҵ��
gPriceTable = {}  --��Լ�����
gIndustryTable = {} --��ҵ����
gSharesTable = {} --��ͨ����Ϣ��
gCapitalTable = {}  --�ܹɱ���Ϣ��
gIndustrySum = 0	--��ҵ����(������ҵ����)
gIndexWeight = 1	--����300ȫȨ��ֵ(����Ȩ�ظ���)
gKlineindexTable = {time={},close={},Rate={}}		--ָ���۸��
gKlineTable = {}		--��Լ�۸��
ETFIDtoName = {}		--ETF�ɷֹ��嵥��
gSFIFTable = {}
gConnect={IP=DTS_DB_SERVER_HOST,PORT = DTS_DB_SERVER_IP,DB =DTS_DB_DB_NAME,USER = DTS_DB_USER_NAME,PWD=DTS_DB_PASSWD} --���ݿ����Ӵ�
--gConnect={IP="10.15.118.27",PORT = "3306",DB ="dtsdb",USER = "dtsweb",PWD="dtsweb"} --���ݿ����Ӵ�  ��˾����
--gConnect={IP="10.29.19.21",PORT = "3306",DB ="dtsdb",USER = "dtsweb",PWD="dtsweb"} --���ݿ����Ӵ�	��³����
function init(arg)  --��ʼ��
	--��ʼ��
	Writelog("init")
	progressBar(0,"��ʼ��")
	--��ȡ����300���̼�
	local KlineTable = GetKLine("SH000300.index", "1d", nil, nil, -_AnalDays, _AnalDays)

	--_WriteAplLog(serialize(KlineTable))

	for i,v in pairs(KlineTable.time) do
		table.insert(gKlineindexTable.time,string.sub(v,1,8))
		table.insert(gKlineindexTable.close,KlineTable.close[i])
		if KlineTable.close[i] and KlineTable.close[i-1] then
			if tonumber(KlineTable.close[i-1]) > 0 then
				gKlineindexTable.Rate[i] = tonumber(KlineTable.close[i])/tonumber(KlineTable.close[i-1]) -1
			else
				gKlineindexTable.Rate[i] = 0
			end
		end
	end
	--Writelog(serialize(gKlineindexTable))
	SetPriceHandler("OnPrice")
	StartPrice("SH000300.index","No5Market")
	progressBar(5,"�������ݿ�")
	--��ȡ�û���
	gUSERID = GetDTSUserID()
	Writelog(gUSERID)
	--�������ݿ�
	DB = Connect(gConnect)

	--��ȡ���ݿ��Լ����
	GetIssueName()
	progressBar(8,"��ȡ��ҵ����")
	--��ȡ���ݿ��Լ��ͨ������
	--GetShares()
	--��ȡ���ݿ���ҵ����
	GetIndustry()
	progressBar(10,"��ȡ�������")
	Writelog("GetInventory")
	--��ȡ���ݿ��������
	GetInventory()
	Writelog("GetInventory end")
	progressBar(90,"��ȡ��Լ������")
	--��ȡ���ݿ�ETF����С�塢��ҵ�塢��֤A�ɵȷ���
	GetInventory2()
	--��ȡ���ݿ�ETF�嵥����
	GetInventory3()
	Writelog("GetInventory2 end")

	--���㻦��300��Ȩ����ֵ
	if gCombinIssueList["300ȫ����"] then
		gIndexWeight = 0
		for issue,info in pairs(gCombinIssueList["300ȫ����"])do
			gIndexWeight = gIndexWeight + tonumber(info.Weight)
		end
	end
	--������ϵ�Ȩ�ظ��ǣ���ҵ����
	for combin,v in pairs (gCombinList) do
		CoverEvent(gCombinList[combin],gCombinIssueList[combin])
	end
	progressBar(95,"��������б�")
	--ȡ��ָ�ڻ��ĵ������ʷ���ݺͶ�������
	getDataForIF()
	--��ù�ָ�ڻ�������������
	GetSFIFData()
	--����������ݵ�����ǰ̨
	SendCombinList()		--��������б���Ϣ
	SendIDtoUI()		--����������ϴ������뵽����
	--Close(DB)			--�ر����ݿ�����
	Writelog("init end")
	progressBar(100)
end
function progressBar(arg,flag)			--������
	local lt={}
	lt.Bar=arg
	if flag then
		lt.Flag = flag
	else
		lt.Flag = ""
	end
	SendToUIScript("SendprogressBar",lt);
end
function Writelog(arg)			--��ʾ��־���
	if _glogFlag == "1" then
		_WriteAplLog(arg)
	end
end
function GetCapital(issueCode)	--��ȡ�ܹɱ���Ϣ
	--Writelog("GetCapital")
	--Writelog(issueCode)
	local Capital = 0
	local obj = toObjID(issueCode)
	local place = string.find(obj, "%.")
	if place then
		local inditype = string.sub(obj,place)
		if inditype == ".stk" then
			if gCapitalTable[issueCode] then
				Capital = gCapitalTable[issueCode]
			else
				--Writelog(obj)
				local nowtime = GetDate() .. "000000"
				local temp1 = GetData("dhd",{"TOT_SHR","TOT_FLOAT_SHR"},{obj},{},nil,nil,19900101000000,tonumber(nowtime))
				Writelog(serialize(temp1))
				local temp = temp1.data
				if temp and temp["indi"] and temp["indi"][1] then
					if  temp["indi"][1]["TOT_SHR"] and #temp["indi"][1]["TOT_SHR"] > 0 then
						Capital = temp["indi"][1]["TOT_SHR"][#temp["indi"][1]["TOT_SHR"]]
						if Capital == "nan" or tostring(Capital) == "nan" then
							if #temp["indi"][1]["TOT_SHR"]-1 > 0 then
								local arg = #temp["indi"][1]["TOT_SHR"]-1
								Capital = temp["indi"][1]["TOT_SHR"][arg]
							end
						end
						gCapitalTable[issueCode] = tonumber(Capital)
						--Writelog(Capital)
					end
					if temp["indi"][1]["TOT_FLOAT_SHR"] and #temp["indi"][1]["TOT_FLOAT_SHR"] > 0 then
						local Shares = temp["indi"][1]["TOT_FLOAT_SHR"][#temp["indi"][1]["TOT_FLOAT_SHR"]]
						if Shares == "nan" or tostring(Shares) == "nan" then
							if #temp["indi"][1]["TOT_FLOAT_SHR"]-1 > 0 then
								local arg = #temp["indi"][1]["TOT_FLOAT_SHR"]-1
								Shares = temp["indi"][1]["TOT_FLOAT_SHR"][arg]
							end
						end
						gSharesTable[issueCode] = tonumber(Shares)
						--Writelog(Shares)
					end
				end
			end
		end
	end
	return string.format("%.0f",Capital)
end
function GetissueShares(issueCode)	--��ȡ��ͨ����Ϣ
	--Writelog("GetissueShares")
	--Writelog(issueCode)
	local Shares = 0
	local obj = toObjID(issueCode)
	local place = string.find(obj, "%.")
	if place then
		local inditype = string.sub(obj,place)
		if inditype == ".stk" then
			if gSharesTable[issueCode] then
				Shares = gSharesTable[issueCode]
			else
				Writelog(obj)
				local nowtime = GetDate() .. "000000"
				local temp1 = GetData("dhd",{"TOT_SHR","TOT_FLOAT_SHR"},{obj},{},nil,nil,19900101000000,tonumber(nowtime))
				Writelog(serialize(temp1))
				local temp = temp1.data
				if temp and temp["indi"] and temp["indi"][1] then
					if temp["indi"][1]["TOT_FLOAT_SHR"] and #temp["indi"][1]["TOT_FLOAT_SHR"] > 0 then
						Shares = temp["indi"][1]["TOT_FLOAT_SHR"][#temp["indi"][1]["TOT_FLOAT_SHR"]]
						if Shares == "nan" or tostring(Shares) == "nan" then
							if #temp["indi"][1]["TOT_FLOAT_SHR"]-1 > 0 then
								local arg = #temp["indi"][1]["TOT_FLOAT_SHR"]-1
								Shares = temp["indi"][1]["TOT_FLOAT_SHR"][arg]
							end
						end
						gSharesTable[issueCode] = tonumber(Shares)
						--Writelog(Shares)
					end
					if  temp["indi"][1]["TOT_SHR"] and #temp["indi"][1]["TOT_SHR"] > 0 then
						local Capital = temp["indi"][1]["TOT_SHR"][#temp["indi"][1]["TOT_SHR"]]
						if Capital == "nan" or tostring(Capital) == "nan" then
							if #temp["indi"][1]["TOT_SHR"]-1 > 0 then
								local arg = #temp["indi"][1]["TOT_SHR"]-1
								Capital = temp["indi"][1]["TOT_SHR"][arg]
							end
						end
						gCapitalTable[issueCode] = tonumber(Capital)
						--Writelog(Capital)
					end
				end
			end
		end
	end
	return string.format("%.0f",Shares)
end
--[[function GetShares()		--��ȡ��ͨ������
	local temp = Get(DB,"", "IssueMaster")
	if temp then
		for i,v in pairs(temp.IssueCode) do
			gSharesTable[v] = tonumber(temp.Shares[i])
		end
	end
	Writelog(serialize(gSharesTable))
end]]
function GetIndustry()		--��ȡ��ҵ����
	local temp = Get(DB,"SectorCategoryID = '3'", "SectorHeader")
	local temp1 = Get(DB,"SectorCategoryID = '3'", "SectorIssue")
	Writelog(serialize(temp))
	Writelog(serialize(temp1))
	if temp1 and temp then --���������Ϣ�б�
		local arg = {}
		for i,v in pairs(temp.SectorCode) do
			local code = tonumber(v)
			arg[code] = temp.ReserveString[i]

		end
		gIndustrySum = #temp.SectorCode
		for i,v in pairs(temp1.IssueCode) do
			gIndustryTable[v] = arg[tonumber(temp1.SectorCode[i])]
			local temp = toObjID(v)
			StartPrice(temp,"No5Market")
		end
	end
	Writelog(serialize(gIndustryTable))
end
function GetIssueName()		--��ȡ��Լ��������
	Writelog("GetIssueName")
	gIssueNameList = {}
	local IssueMasterlist = Get(DB,"", "IssueMaster")
	if IssueMasterlist then --���������Ϣ�б�
		for i,v in pairs(IssueMasterlist.IssueCode) do
			gIssueNameList[v] = IssueMasterlist.IssueShortLocalName[i] or "-"
		end
	end
end
function GetInventory()		--��ȡ�������
	Writelog("GetInventory")
	gCombinList = {}
	gCombinIssueList = {}
	local InventoryHeaderlist = Get(DB,"", "InventoryHeader")
	local InventoryOrderlist = Get(DB,"", "InventoryOrder")

	Writelog(serialize(InventoryHeaderlist))
	Writelog(serialize(InventoryOrderlist))
	progressBar(12)
	Writelog("���������Ϣ�б�")
	if InventoryHeaderlist then --���������Ϣ�б�
		for i,v in pairs(InventoryHeaderlist.InventoryModelID) do
			local UserID = InventoryHeaderlist.Owner[i]
			local ReserveString = InventoryHeaderlist.ReserveString[i]
			if gUSERID == UserID or ReserveString == "1" then			--������ϻ��������
				gCombinList[v] = {}
				if InventoryHeaderlist.ModelDescription[i] == "-" then
					gCombinList[v].CombinName = v
				else
					gCombinList[v].CombinName = InventoryHeaderlist.ModelDescription[i]
				end
				gCombinList[v].BaseIndexCode = InventoryHeaderlist.BaseIndexCode[i]
				gCombinList[v].BaseName = gIssueNameList[gCombinList[v].BaseIndexCode]
				local ChangeDate = InventoryHeaderlist.TimeStamp[i]
				if ChangeDate ~= "-" then
					ChangeDate = string.sub(ChangeDate,1,10)
				end
				gCombinList[v].UserID = UserID
				gCombinList[v].ChangeDate = ChangeDate
				gCombinList[v].Number = 0
				gCombinList[v].WeightCover = 0
				gCombinList[v].IndustryCover = 0
				gCombinList[v].ExpValue = 0
				gCombinList[v].AnalDays = 100
				gCombinList[v].BaseDate = gKlineindexTable.time[#gKlineindexTable.time]
				gCombinList[v].BasePrice = gKlineindexTable.close[#gKlineindexTable.time]
				gCombinList[v].LastValue = 0
				gCombinList[v].Price = 0
				gCombinList[v].BaseWeight = 0
				gCombinList[v].Weight = 0
				gCombinList[v].PreQty = "1.000"
				gCombinList[v].PreCast = gCombinList[v].BasePrice * 300
				gCombinList[v].AllCheck = "0"
				gCombinList[v].KeepCheck = "0"
				gCombinList[v].Check1 = "1"
				gCombinList[v].Check2 = "1"
				gCombinList[v].Check3 = "1"

				--���BaseIndexCode Ϊ0 ��ʾΪϵͳ��ϣ�Ϊ1��ʾΪ�Խ���ϡ�ֻ��Ϊ1�Ż���ʾ������б���Ϊ0��ʾ�ں�Լ���С�
				if gCombinList[v].BaseIndexCode == "1" then
					gCombinList[v].BaseIndexCode = "M000300"
					gCombinList[v].BaseName = gIssueNameList["M000300"] or "����300"
				end
				gCombinIssueList[v] = {}
				gCombinIndustryList[v] = {}
			end
		end
	end
	progressBar(15,"��ȡ�����ͨ������")
	Writelog("��ȡ�������ͨ������")
	if InventoryOrderlist and InventoryOrderlist.InventoryModelID then--��ȡ�������ʷ����ͨ������
		local tempTable = {}
		local tempTable1= {}
		for i,v in pairs(InventoryOrderlist.InventoryModelID) do
			local issuecode = InventoryOrderlist.IssueCode[i]
			local combincode = InventoryOrderlist.InventoryModelID[i]
			if not tempTable1[issuecode] and gCombinIssueList[combincode] then
				tempTable1[issuecode] = 1
				local temp = toObjID(issuecode)
				StartPrice(temp,"No5Market")
			end
		end
		local sum = 0
		for issuecode , v in pairs (tempTable1) do
			local obj = toObjID(issuecode)
			local place = string.find(obj, "%.")
			if place then
				local inditype = string.sub(obj,place)
				if inditype == ".stk" then
					sum = sum + 1
					table.insert(tempTable,obj)
					if sum == 300 then
						CapitalShares(tempTable)
						tempTable = {}
						sum = 0
					end
				end
			end
		end
	end
	progressBar(40,"��ȡ�������ʷ�۸�")
	Writelog("���������ϸ��")
	if InventoryOrderlist and InventoryOrderlist.InventoryModelID then --���������ϸ��
		local sum = #InventoryOrderlist.IssueCode
		local tempsum = 0
		for i,v in pairs(InventoryOrderlist.InventoryModelID) do
			tempsum = tempsum + 1
			local issuecode = InventoryOrderlist.IssueCode[i]
			--������ϳɷֹ��б�
			if gCombinIssueList[v] then
				if sum > 0 then
					local Bar = (tempsum/sum) * 50
					Bar = Bar + 40
					Bar = math.ceil(Bar)
					progressBar(Bar)
				end
				--��ȡ��Լ��ʷ�۸��
				if not gKlineTable[issuecode] then
					gKlineTable[issuecode]={time={},close={}}
					--_WriteAplLog(toObjID(issuecode))
					local KlineTable = GetKLine(toObjID(issuecode), "1d", nil, nil, -_AnalDays, _AnalDays,1)
					--_WriteAplLog(serialize(KlineTable))
					if KlineTable and KlineTable.time then
						for i,v in pairs(KlineTable.time) do
							table.insert(gKlineTable[issuecode].time,string.sub(v,1,8))
							table.insert(gKlineTable[issuecode].close,KlineTable.close[i])
						end
					end
				end
				if not gCombinIssueList[v][issuecode] then
					gCombinIssueList[v][issuecode] = {}
					gCombinList[v].Number = gCombinList[v].Number + 1
				end
				local temp = gCombinIssueList[v][issuecode]
				temp.Number = tonumber(InventoryOrderlist.InventoryOrderNo[i])
				temp.IssueName = gIssueNameList[issuecode] or "-"
				temp.Qty = math.ceil(InventoryOrderlist.Quantity[i])
				temp.Weight = string.format("%.02f",InventoryOrderlist.GeneralDouble1[i])
				temp.Value = 0
				temp.BaseWeight = string.format("%.02f",InventoryOrderlist.ReserveDouble2[i])
				temp.BaseValue = temp.Qty*getPrice(issuecode,gKlineindexTable.time[#gKlineindexTable.time])
				temp.Industry = gIndustryTable[issuecode] or "-"
				temp.Shares = GetissueShares(issuecode)
				temp.SharesValue = 0
				local ChangeDate = InventoryOrderlist.TimeStamp[i]
				if ChangeDate ~= "-" then
					ChangeDate = string.sub(ChangeDate,1,10)
				end
				temp.ChangeDate = ChangeDate
				temp.Capital = GetCapital(issuecode)
				-------------------------------------------------Byhan		�������ռ��ֶ�
				temp.LNC = 0
				if gKlineTable[issuecode] then
					temp.LNC = gKlineTable[issuecode].close[#gKlineTable[issuecode].close] or 0
					if gKlineTable[issuecode].time[#gKlineTable[issuecode].time] == os.date("%Y%m%d", os.time()) then
						temp.LNC = gKlineTable[issuecode].close[#gKlineTable[issuecode].close - 1] or 0
					end
				end
				------------------------------------------------------------------------
				--ͳ������ڱ��Ȩ�غ�
				gCombinList[v].BaseWeight = gCombinList[v].BaseWeight + temp.BaseWeight
				gCombinList[v].Weight = gCombinList[v].Weight + temp.Weight
				--�����Լ���гɷֹ���������
				--[[if gCombinList[v].BaseIndexCode ~= "M000300" then
					local Price = GetforPrice(issuecode,"lastclose")
					if Price and Price ~= 0 then
					temp.Qty = math.ceil(gKlineindexTable.close[#gKlineindexTable.time]*300*temp.Weight/100/Price)
					end
				end]]
			end
			if gCombinIndustryList[v] then
				local IndustryName = gIndustryTable[issuecode] or "-"
				if not gCombinIndustryList[v][IndustryName] then
					gCombinIndustryList[v][IndustryName] = {CodeNumber=0,Value=0,IndustryWeight=0,IndustryBaseWeight=0,BaseWeight=0,Weight=0,Shares=0,Capital=0}
				end
				local tempTable = gCombinIndustryList[v][IndustryName]
				tempTable.IndustryName = IndustryName
				tempTable.CodeNumber = tempTable.CodeNumber + 1
				tempTable.BaseWeight = tempTable.BaseWeight + gCombinIssueList[v][issuecode].BaseWeight
				tempTable.Weight = tempTable.Weight + gCombinIssueList[v][issuecode].Weight
				tempTable.Capital = tempTable.Capital + gCombinIssueList[v][issuecode].Capital
			end
		end
	end
end

function GetInventory2()			--ETF����С�塢��ҵ�塢��֤A�ɵȷ���
	Writelog("GetInventory2")

	--ETF
	local condition = string.format("ProductCode = '%02d'",3)
	local temp1 = Get(DB,condition, "IssueMaster")
	--_WriteAplLog(serialize(temp1))
	--��С��
	condition = string.format("ProductCode = '%s' and IssueCode LIKE '002%%' and PriorMarket = '2'",10)
	local temp2 = Get(DB,condition, "IssueMaster")
	--_WriteAplLog(serialize(temp2))
	--��ҵ��
	condition = string.format("ProductCode = '%s' and IssueCode LIKE '300%%' and PriorMarket = '2'",10)
	local temp3 = Get(DB,condition, "IssueMaster")
	--_WriteAplLog(serialize(temp3))
	--��֤A��
	condition = string.format("ProductCode = '%s' and IssueCode LIKE '6%%' and PriorMarket = '1'",10)
	local temp4 = Get(DB,condition, "IssueMaster")
	--��֤A��
	condition = string.format("ProductCode = '%s' and IssueCode LIKE '00%%' and PriorMarket = '2'",10)
	local temp5 = Get(DB,condition, "IssueMaster")
	--_WriteAplLog(serialize(temp4))
	local tempTable = {}
	local tempTable1= {}
	for i,issuecode in pairs(temp1.IssueCode) do
		if not tempTable1[issuecode] then
			tempTable1[issuecode] = 1
			local temp = toObjID(issuecode)
			StartPrice(temp,"No5Market")
		end
	end
	for i,issuecode in pairs(temp2.IssueCode) do
		if not tempTable1[issuecode] then
			tempTable1[issuecode] = 1
			local temp = toObjID(issuecode)
			StartPrice(temp,"No5Market")
		end
	end
	for i,issuecode in pairs(temp3.IssueCode) do
		if not tempTable1[issuecode] then
			tempTable1[issuecode] = 1
			local temp = toObjID(issuecode)
			StartPrice(temp,"No5Market")
		end
	end
	for i,issuecode in pairs(temp4.IssueCode) do
		if not tempTable1[issuecode] then
			tempTable1[issuecode] = 1
			local temp = toObjID(issuecode)
			StartPrice(temp,"No5Market")
		end
	end

	for i,issuecode in pairs(temp5.IssueCode) do
		if not tempTable1[issuecode] then
			tempTable1[issuecode] = 1
			local temp = toObjID(issuecode)
			StartPrice(temp,"No5Market")
		end
	end
	--progressBar(78,"��ȡ��Լ����ͨ������")
	--[[local sum = 0
	for issuecode,v in pairs (tempTable1) do
		local obj = toObjID(issuecode)
		local place = string.find(obj, "%.")
		if place then
			local inditype = string.sub(obj,place)
			if inditype == ".stk" then
				sum = sum + 1
				table.insert(tempTable,obj)
				if sum == 300 then
					CapitalShares(tempTable)
					tempTable = {}
					sum = 0
				end
			end
		end
	end]]
	progressBar(92,"ע���Լ������")
	GetInDB("ETF",temp1)
	--progressBar(91)
	GetInDB("��С��",temp2)
	--progressBar(92)
	GetInDB("��ҵ��",temp3)
	--progressBar(93)
	GetInDB("��֤A��",temp4)
	--progressBar(94)
	GetInDB("��֤A��",temp5)

end
function GetInventory3()		--��ȡETF�嵥����
	Writelog("GetInventory3")
	local timeday = os.date("%Y%m%d", os.time())
	Writelog(timeday)
	--ETF
	local condition = string.format("TradingDay = '%s'",timeday)
	local temp1 = Get(DB,condition, "DTSETFList")
	--ETFlist
	local temp2 = Get(DB,condition, "DTSETFComponent")
	if temp1 and temp1.ETFID then
		for i,etfid in pairs(temp1.ETFID) do
			if not ETFIDtoName[etfid] then
			ETFIDtoName[etfid] = {}
			end
			ETFIDtoName[etfid].IssueCode = temp1.IssueCode[i]
			ETFIDtoName[etfid].FundName = temp1.FundName[i]
		end
	end
	local tempTable1= {}
	if temp2 and temp2.IssueCode then
		for i,issuecode in pairs(temp2.IssueCode) do
			if not tempTable1[issuecode] then
				tempTable1[issuecode] = 1
				local temp = toObjID(issuecode)
				StartPrice(temp,"No5Market")
			end
			local Name = temp2.ETFID[i]
			if not gCombinList[Name] then
				gCombinList[Name] = {}
				if ETFIDtoName[Name] then
				gCombinList[Name].CombinName = ETFIDtoName[Name].FundName
				else
				gCombinList[Name].CombinName = Name
				end
				gCombinList[Name].BaseIndexCode = "-"
				gCombinList[Name].BaseName = "-" --gIssueNameList[gCombinList[v].BaseIndexCode]

				gCombinList[Name].UserID = "999"
				gCombinList[Name].ChangeDate = "-"
				gCombinList[Name].Number = 0
				gCombinList[Name].WeightCover = 0
				gCombinList[Name].IndustryCover = 0
				gCombinList[Name].ExpValue = 0
				gCombinList[Name].AnalDays = 100
				gCombinList[Name].BaseDate = gKlineindexTable.time[#gKlineindexTable.time]
				gCombinList[Name].BasePrice = gKlineindexTable.close[#gKlineindexTable.time]
				gCombinList[Name].LastValue = 0
				gCombinList[Name].Price = 0
				gCombinList[Name].BaseWeight = 0
				gCombinList[Name].Weight = 0
				gCombinList[Name].PreQty = "1.000"
				gCombinList[Name].PreCast = gCombinList[Name].BasePrice * 300
				gCombinList[Name].AllCheck = "0"
				gCombinList[Name].KeepCheck = "0"
				gCombinList[Name].Check1 = "1"
				gCombinList[Name].Check2 = "1"
				gCombinList[Name].Check3 = "1"

				gCombinIssueList[Name] = {}
				gCombinIndustryList[Name] = {}
			end
			--������ϳɷֹ��б�
			if gCombinIssueList[Name] then
				if not gCombinIssueList[Name][issuecode] then
					gCombinIssueList[Name][issuecode] = {}
					gCombinList[Name].Number = gCombinList[Name].Number + 1
				end
				local temp = gCombinIssueList[Name][issuecode]


				temp.Number = gCombinList[Name].Number
				temp.IssueName = gIssueNameList[issuecode] or "-"
				temp.Qty = tonumber(temp2.Quantity[i])
				temp.Weight = 0
				temp.Value = 0
				temp.BaseWeight = 0
				temp.BaseValue = 0
				temp.Industry = gIndustryTable[issuecode] or "-"
				temp.Shares = 0--GetissueShares(issuecode)
				temp.SharesValue = 0
				temp.ChangeDate = "-"
				temp.Capital = 0--GetCapital(issuecode)
			end
			if gCombinIndustryList[Name] then
				local IndustryName = gIndustryTable[issuecode] or "-"
				if not gCombinIndustryList[Name][IndustryName] then
					gCombinIndustryList[Name][IndustryName] = {CodeNumber=0,Value=0,IndustryWeight=0,IndustryBaseWeight=0,BaseWeight=0,Weight=0,Shares=0,Capital=0}
				end
				local tempTable = gCombinIndustryList[Name][IndustryName]
				tempTable.IndustryName = IndustryName
				tempTable.CodeNumber = tempTable.CodeNumber + 1
				tempTable.Capital = tempTable.Capital + gCombinIssueList[Name][issuecode].Capital
			end
		end
	end
end
function GetInDB(Name,List)								--�����б���Ϣ
	if List and List.IssueCode then
		Writelog(Name)
		gCombinList[Name] = {}
		gCombinList[Name].CombinName = Name
		gCombinList[Name].BaseIndexCode = "-"
		gCombinList[Name].BaseName = "-" --gIssueNameList[gCombinList[v].BaseIndexCode]

		gCombinList[Name].UserID = "999"
		gCombinList[Name].ChangeDate = "-"
		gCombinList[Name].Number = 0
		gCombinList[Name].WeightCover = 0
		gCombinList[Name].IndustryCover = 0
		gCombinList[Name].ExpValue = 0
		gCombinList[Name].AnalDays = 100
		gCombinList[Name].BaseDate = gKlineindexTable.time[#gKlineindexTable.time]
		gCombinList[Name].BasePrice = gKlineindexTable.close[#gKlineindexTable.time]
		gCombinList[Name].LastValue = 0
		gCombinList[Name].Price = 0
		gCombinList[Name].BaseWeight = 0
		gCombinList[Name].Weight = 0
		gCombinList[Name].PreQty = "1.000"
		gCombinList[Name].PreCast = gCombinList[Name].BasePrice * 300
		gCombinList[Name].AllCheck = "0"
		gCombinList[Name].KeepCheck = "0"
		gCombinList[Name].Check1 = "1"
		gCombinList[Name].Check2 = "1"
		gCombinList[Name].Check3 = "1"

		gCombinIssueList[Name] = {}
		gCombinIndustryList[Name] = {}
		for i,issuecode in pairs(List.IssueCode) do
			--������ϳɷֹ��б�
			if gCombinIssueList[Name] then
				if not gCombinIssueList[Name][issuecode] then
					gCombinIssueList[Name][issuecode] = {}
					gCombinList[Name].Number = gCombinList[Name].Number + 1
				end
				local temp = gCombinIssueList[Name][issuecode]
				temp.Number = gCombinList[Name].Number
				temp.IssueName = gIssueNameList[issuecode] or "-"
				temp.Qty = 0
				temp.Weight = 0
				temp.Value = 0
				temp.BaseWeight = 0
				temp.BaseValue = 0
				temp.Industry = gIndustryTable[issuecode] or "-"
				temp.Shares = 0--GetissueShares(issuecode)
				temp.SharesValue = 0
				temp.ChangeDate = "-"
				temp.Capital = 0--GetCapital(issuecode)
			end
			if gCombinIndustryList[Name] then
				local IndustryName = gIndustryTable[issuecode] or "-"
				if not gCombinIndustryList[Name][IndustryName] then
					gCombinIndustryList[Name][IndustryName] = {CodeNumber=0,Value=0,IndustryWeight=0,IndustryBaseWeight=0,BaseWeight=0,Weight=0,Shares=0,Capital=0}
				end
				local tempTable = gCombinIndustryList[Name][IndustryName]
				tempTable.IndustryName = IndustryName
				tempTable.CodeNumber = tempTable.CodeNumber + 1
				tempTable.Capital = tempTable.Capital + gCombinIssueList[Name][issuecode].Capital
			end
		end
	end
end
function CapitalShares(tempTable)			--���ܻ�ȡ��ͨ�ɺ��ܹɱ�����
	Writelog("CapitalShares")
	Writelog(serialize(tempTable))
	local nowtime = GetDate() .. "000000"
	local temp1 = GetData("dhd",{"TOT_SHR","TOT_FLOAT_SHR"},tempTable,{},nil,nil,19901101000000,tonumber(nowtime))
	Writelog(serialize(temp1))
	local temp = temp1.data
	if temp and temp["indi"] then
		for i,info in pairs (temp["indi"]) do
			local IssueCode = ObjID2IssueCode(temp["obj"][i])
			local Capital = 0
			local Shares = 0
			if #info["TOT_SHR"] > 0 then
				Capital = info["TOT_SHR"][#info["TOT_SHR"]]
			end
			if #info["TOT_FLOAT_SHR"] > 0 then
				Shares = info["TOT_FLOAT_SHR"][#info["TOT_FLOAT_SHR"]]
			end
			Writelog(IssueCode)
			Writelog(Capital)
			Writelog(Shares)
			if Capital == "nan" or tostring(Capital) == "nan" then
				if #info["TOT_SHR"]-1 > 0 then
					local arg = #info["TOT_SHR"]-1
					Capital = info["TOT_SHR"][arg]
				end
			end
			if Shares == "nan" or tostring(Shares) == "nan" then
				if #info["TOT_FLOAT_SHR"]-1 > 0 then
					local arg = #info["TOT_FLOAT_SHR"]-1
					Shares = info["TOT_FLOAT_SHR"][arg]
				end
			end
			Writelog(Capital)
			Writelog(Shares)
			gCapitalTable[IssueCode] = tonumber(Capital)
			gSharesTable[IssueCode] = tonumber(Shares)
		end
	end
end
function GetforPrice(issuecode,Type)		--��ȡ����
	local Price = 0
	if gPriceTable[issuecode] then
		Price = gPriceTable[issuecode][Type]
	else
		Price = GetPrice(issuecode)[Type]
		local temp = toObjID(issuecode)
		StartPrice(temp,"No5Market")
	end
	return Price
end
function SendIDtoUI()			--����������ϴ�����Ϣ
	Writelog("SendIDtoUI")
	local lt={}
	lt.CombinCode=creatID()
	SendToUIScript("SendIDtoUI",lt);
end
function SendCombinList()		--��������б���Ϣ
	Writelog("SendCombinList")
	local tempnumber = 1
	local Table={Number={},CombinCode={},CombinName={},CodeNumber={},WeightCover={},IndustryCover={},PreQty={},ExpValue={},CC={},Warp={},
	Beta={},Alpha={},BasePrice={},Fit={},FitValue={},LastValue={},BaseDate={},AnalDays={},BaseIndexCode={},ChangeDate={},UserID={}}
	for combinCode,info in pairs(gCombinList) do
		if info.BaseIndexCode == "M000300" then		--ֻ�������BaseIndexCode �Ż���ʾ
			info.No = tempnumber
			table.insert(Table.Number,info.No)
			table.insert(Table.CombinCode,combinCode)
			table.insert(Table.CombinName,info.CombinName)
			table.insert(Table.CodeNumber,gCombinList[combinCode].Number)
			table.insert(Table.WeightCover,info.WeightCover or "")
			table.insert(Table.IndustryCover,info.IndustryCover or "")
			table.insert(Table.PreQty,info.PreQty or "")
			table.insert(Table.UserID,info.UserID or "")

			table.insert(Table.ExpValue,info.ExpValue or "")
			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")
			table.insert(Table.BasePrice,info.BasePrice or "")
			table.insert(Table.Fit,info.Fit or "")

			table.insert(Table.FitValue,info.FitValue or "")
			table.insert(Table.LastValue,info.Price or "")
			table.insert(Table.BaseDate,info.BaseDate or "")
			table.insert(Table.AnalDays,info.AnalDays or "")
			table.insert(Table.BaseIndexCode,info.BaseIndexCode or "")
			table.insert(Table.ChangeDate,info.ChangeDate or "")
			tempnumber = tempnumber + 1
		end
	end
	SendToUI("CombinTable",Table)
end


function SendIssueList()		--����ȫ����������Ϣ
	Writelog("SendIssueList")
	if gCombinIssueList[_CurrentCombin] then
		local templist = gCombinIssueList[_CurrentCombin]
		local Table={Number={},IssueCode={},IssueName={},Qty={},Price={},Status={}, Value={},Weight={},BaseWeight={},Industry={},CC={},
			Warp={},Beta={},Alpha={},Shares={},Capital={},Exchange = {},ExchangeRatio={}}
		for issue,info in pairs(templist) do
			table.insert(Table.Number,info.Number)
			table.insert(Table.IssueCode,issue)
			table.insert(Table.IssueName,info.IssueName or "")
			table.insert(Table.Qty,info.Qty or "")
			local tempPrice = 0
			local tempStatus = ""
			if gPriceTable[issue] then
				tempPrice = gPriceTable[issue].new or 0
				tempStatus = gPriceTable[issue].Status or ""
			end
			table.insert(Table.Price,tempPrice)

			table.insert(Table.Status,tempStatus)
			table.insert(Table.Value,string.format("%.02f",tempPrice*info.Qty))

			table.insert(Table.Weight,info.Weight or "")
			table.insert(Table.BaseWeight,info.BaseWeight or "")
			table.insert(Table.Industry,info.Industry or "")
			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")

			table.insert(Table.Shares,info.Shares or "")
			table.insert(Table.Capital,info.Capital or "")
			--------------------------------------------�����ǵ����ǵ���
			local lnc = info.LNC or 0
			local ratio = string.format("%.2f",0)
			local exchange = string.format("%.2f",0)

			if lnc~= 0 then
				ratio = string.format("%.2f",(tempPrice - lnc)/lnc*100)
			end
			if tempStatus == "ͣ��" then
				table.insert(Table.Exchange,exchange)
				table.insert(Table.ExchangeRatio,exchange)
			else
				table.insert(Table.Exchange,string.format("%.2f",tempPrice - lnc))
				table.insert(Table.ExchangeRatio,ratio)
			end
			--local log = string.format("��ʼ���ǵ�,��Լ:%s,���¼�:%s,���ռ�:%s",issue,tempPrice,lnc)
			--Writelog(log)
			-------------------------------------------------
		end
		SendToUI("CombinIssueEvent",Table)
	end
end
function SendIndustryList()		--������ҵ������Ϣ

	Writelog("SendIndustryList")
	if gCombinIndustryList[_CurrentCombin] then
		local templist = gCombinIndustryList[_CurrentCombin]
		Writelog(serialize(templist))
		local Table={Number={},Industry={},CodeNumber={},Value={},IndustryWeight={},BaseWeight={},CC={},Warp={},Beta={},Alpha={},
			Shares={},Capital={}}
			local Number = 0
		for Industry,info in pairs(templist) do
			Number = Number + 1
			table.insert(Table.Number,Number)
			table.insert(Table.Industry,Industry)
			table.insert(Table.CodeNumber,info.CodeNumber)
			table.insert(Table.Value,info.Value or "")
			table.insert(Table.IndustryWeight,info.IndustryWeight or "")

			table.insert(Table.BaseWeight,info.IndustryBaseWeight or "")

			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")
			table.insert(Table.Shares,info.Shares or "")
			table.insert(Table.Capital,info.Capital or "")
		end
		SendToUI("SectorTable",Table)
	end
end
function SendCurrentCombinList(CombinCode)	--��������б���Ϣ
	Writelog("SendCurrentCombinList")
	if gCombinList[CombinCode] then
		local info = gCombinList[CombinCode]
		local Table={Number={},CombinCode={},CombinName={},CodeNumber={},WeightCover={},IndustryCover={},PreQty={},ExpValue={},CC={},Warp={},
		Beta={},Alpha={},BasePrice={},Fit={},FitValue={},LastValue={},BaseDate={},AnalDays={},BaseIndexCode={},ChangeDate={},UserID={}}
		if info.BaseIndexCode == "M000300" then		--ֻ�������BaseIndexCode �Ż���ʾ
			table.insert(Table.Number,info.No)
			table.insert(Table.CombinCode,CombinCode)
			table.insert(Table.CombinName,info.CombinName)
			table.insert(Table.CodeNumber,info.Number)
			table.insert(Table.WeightCover,info.WeightCover or "")
			table.insert(Table.IndustryCover,info.IndustryCover or "")
			table.insert(Table.PreQty,info.PreQty or "")
			table.insert(Table.UserID,info.UserID or "")
			table.insert(Table.ExpValue,info.ExpValue or "")
			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")
			table.insert(Table.BasePrice,info.BasePrice or "")
			table.insert(Table.Fit,info.Fit or "")

			table.insert(Table.FitValue,info.FitValue or "")
			table.insert(Table.LastValue,info.Price or "")
			table.insert(Table.BaseDate,info.BaseDate or "")
			table.insert(Table.AnalDays,info.AnalDays or "")
			table.insert(Table.BaseIndexCode,info.BaseIndexCode or "")
			table.insert(Table.ChangeDate,info.ChangeDate or "")
			SendToUI("CombinTable",Table)
		end
	end
end
function SendCurrentIndustry(CombinCode)		--���µ�ǰ�����ҵ��Ϣ
	Writelog("SendCurrentIndustry")
	if gCombinIndustryList[CombinCode] then
		local Table={Number={},Industry={},CodeNumber={},Value={},IndustryWeight={},BaseWeight={},CC={},Warp={},Beta={},Alpha={},
		Shares={},Capital={}}
		local Number = 0
		for Industry,info in pairs(gCombinIndustryList[CombinCode]) do
			Number = Number + 1
			table.insert(Table.Number,Number)
			table.insert(Table.Industry,info.IndustryName)
			table.insert(Table.CodeNumber,info.CodeNumber)
			table.insert(Table.Value,string.format("%.02f",info.Value))
			table.insert(Table.IndustryWeight,info.IndustryWeight or "")

			table.insert(Table.BaseWeight,info.IndustryBaseWeight or "")

			table.insert(Table.CC,info.CC or "")
			table.insert(Table.Warp,info.Warp or "")
			table.insert(Table.Beta,info.Beta or "")
			table.insert(Table.Alpha,info.Alpha or "")
			table.insert(Table.Shares,string.format("%.02f",info.Shares))
			table.insert(Table.Capital,info.Capital or "")
		end
		SendToUI("SectorTable",Table)
	end
end

function SendCurrentIssue(PriceTable)		--������������Ϣ
	Writelog("SendCurrentIssue")
	local info = gCombinIssueList[_CurrentCombin][PriceTable.IssueCode]
	local Table={Number={},IssueCode={},IssueName={},Qty={},Price={},Status={}, Value={},Weight={},BaseWeight={},Industry={},CC={},
		Warp={},Beta={},Alpha={},Shares={},Capital={},Exchange = {},ExchangeRatio = {}}
	table.insert(Table.Number,info.Number)
	table.insert(Table.IssueCode,PriceTable.IssueCode)
	table.insert(Table.IssueName,info.IssueName or "")
	table.insert(Table.Qty,info.Qty or "")
	table.insert(Table.Price,PriceTable.new)
	table.insert(Table.Status,PriceTable.Status)
	table.insert(Table.Value,string.format("%.02f",PriceTable.new*info.Qty))

	table.insert(Table.Weight,info.Weight or "")
	table.insert(Table.BaseWeight,info.BaseWeight or "")
	table.insert(Table.Industry,info.Industry or "")
	table.insert(Table.CC,info.CC or "")
	table.insert(Table.Warp,info.Warp or "")
	table.insert(Table.Beta,info.Beta or "")
	table.insert(Table.Alpha,info.Alpha or "")

	table.insert(Table.Shares,info.Shares or "")
	table.insert(Table.Capital,info.Capital or "")
	-----------------------------------------�����ǵ����ǵ����ֶ�
	local lnc = PriceTable.lastclose or 0
	local exchange = string.format("%.2f",0)
	local ratio = string.format("%.2f",0)
	if lnc ~= 0 then
		ratio = string.format("%.2f",(PriceTable.new - lnc)/lnc*100)
	end

	if PriceTable.Status == "ͣ��" then
		table.insert(Table.Exchange,exchange)
		table.insert(Table.ExchangeRatio,exchange)
	else
		table.insert(Table.Exchange,string.format("%.2f",PriceTable.new - lnc))
		table.insert(Table.ExchangeRatio,ratio)
	end


	--local log = string.format("ʵʱ�����ǵ�,��Լ:%s,���¼�:%s,���ռ�:%s",PriceTable.IssueCode,PriceTable.new,lnc)
	--Writelog(log)
	----------------------------------------------------
	SendToUI("CombinIssueEvent",Table)
end
function ClickCombinTable(arg)			--˫������б�
	Writelog("ClickCombinTable")
	local CombinCode = arg.CombinCode
	Writelog(CombinCode)
	--��ǰ��ϲ����ڴ������
	--[[if _CurrentCombin ~= "" and gCombinIssueList[_CurrentCombin] then
		--ɾ��֮ǰ��ϳɷֹ�����.
		Writelog("delect")
		local templist = gCombinIssueList[_CurrentCombin]
		for issue,info in pairs(templist) do
			local temp = toObjID(issue)
			StopPrice(temp)
		end
	end]]
	progressBar(0,"���͵�ǰ�������")
	if _CurrentCombin ~= CombinCode then
		clearCombinLine()
		if gLeft == "��Ӧ���" or gRight == "��Ӧ���" then
			clearFittingGraph()
		end
	end

	--���µ�ǰ���
	_CurrentCombin = CombinCode
	--ע�ᵱǰ��ϳɷֹ����顣
	--Writelog("add")
	--[[for issue,info in pairs(gCombinIssueList[_CurrentCombin]) do
		local temp = toObjID(issue)
		StartPrice(temp,"No5Market")
	end]]
	--������������Ϣ
	SendCombinEvent(_CurrentCombin)
	--���͵�ǰ����б�
	SendCombinList()
	--���͵�ǰ�����ϸ����ʾ
	SendIssueList()
	--������ҵ��Ϣ��
	SendIndustryList()
	progressBar(50,"�������ͼ������")
	--sendRecordCombinLine()
	if gtActiveTable[_CurrentCombin] then--�л�Ϊ�Ѿ��������ϣ���Ҫ������ݲ����¼���
		reCalcCombin(_CurrentCombin)
		GetCalcCombinHistory(_CurrentCombin,gCombinList[_CurrentCombin].BaseDate)
	end
	progressBar(100)
end
function DelectCombin(arg)		--ɾ����ϰ�ť
	Writelog("DelectCombin")
	local CombinCode= arg.CombinCode
	if gCombinList[CombinCode] then
		local condition = string.format("InventoryModelID = '%s'",CombinCode)
		Delete(DB, condition, "InventoryHeader")
		condition = string.format("InventoryModelID = '%s'",CombinCode)
		Delete(DB, condition, "InventoryOrder")
		gCombinList[CombinCode] = nil
		gCombinIssueList[CombinCode] = nil
	end
	SendCombinList()		--��������б���Ϣ
end
function creatID()--������ϱ�����Ϣ
	local strDate = os.date("%Y%m%d", os.time())
	local portID = ""
	local SubmitNo = 1; --�µ����кţ�Ϊ�˱�֤ÿ��CombinCode��Ψһ
	local strSubmitNo = string.format("%03d",SubmitNo); --��ʽ����3λ
	portID = string.format("%s%s%s",gUSERID,strDate,strSubmitNo);
	while findID(portID) do
		SubmitNo = SubmitNo + 1;
		strSubmitNo = string.format("%03d",SubmitNo);
		portID = string.format("%s%s%s",gUSERID,strDate,strSubmitNo);
	end
	local log = "createportID by the function of creatIDtodisposition:"..portID
	Writelog(log);
	return portID;
end
function findID(portID)  --�ҵ�������ϱ��
	for CombinCode, info in pairs(gCombinList) do
		if portID == CombinCode then
			return true
		end
	end
	return false
end

function OnPrice(objID,lt)	--����ص�
	local IssueCode = ObjID2IssueCode(objID)
	if not gPriceTable[IssueCode] then gPriceTable[IssueCode] = {} end
	local tempTable = gPriceTable[IssueCode]
	local status = OnstateJudge(objID,lt)
	tempTable.IssueCode = IssueCode
	tempTable.new = lt.new or 0
	tempTable.lastclose = lt.lastclose or 0
	tempTable.Status = status
	GetIssueInfo(IssueCode,lt)
	if IssueCode == "M000300" and gCombinIssueList[_CurrentCombin] then
		SendCombinEvent(_CurrentCombin)		--�������ʵʱˢ����Ϣ
		SendCurrentIndustry(_CurrentCombin)		--ˢ����ҵʵʱ��Ϣ
		CalNowConbinInfo(lt)
	end
	if gCombinIssueList[_CurrentCombin] and gCombinIssueList[_CurrentCombin][IssueCode] then
		SendCurrentIssue(tempTable)				--ˢ�º�Լʵʱ��Ϣ
	end

	--add by lee:���¹�ָ�ڻ��ͻ���300�ķ���k������
	if lt.time then
		if gIssueTableForIF[IssueCode] then --��ָ�ڻ�����300
			local index = gIndexForIF[IssueCode]
			local size = #gKlineTableForIF[IssueCode].time
			local currentMinute = string.sub(lt.time,1,4)
			currentMinute = os.date("%Y%m%d") .. currentMinute .. "00"
			local lastMinute = gKlineTableForIF[IssueCode].time[size] or "00000000000000"
			if currentMinute == lastMinute then
				if lt.volume > gKlineTableForIF[IssueCode].volume[size] then
					gKlineTableForIF[IssueCode].close[size] = lt.new
					gKlineTableForIF[IssueCode].volume[size] = gKlineTableForIF[IssueCode].volume[size] + lt.nowvol
				end
			elseif currentMinute > lastMinute then
				if IssueCode ~= "M000300" then --����300������������������貹��
					while currentMinute > gBaseTime[size+1] do --��ָ�ڻ����ջ�׼ʱ��㣬������ȱʧ����
						table.insert(gKlineTableForIF[IssueCode].time,gBaseTime[size+1])
						if size == 0 then
							local lastClose = getLastClose(IssueCode,index)
							if lastClose then
								table.insert(gKlineTableForIF[IssueCode].close,lastClose)
							else
								table.insert(gKlineTableForIF[IssueCode].close,"-")
								local logs = string.format("δ��ȡ��[%s]�����ռ�",IssueCode)
								Writelog(logs)
							end
						else
							table.insert(gKlineTableForIF[IssueCode].close,gKlineTableForIF[IssueCode].close[size])
						end
						table.insert(gKlineTableForIF[IssueCode].volume,0)
						table.insert(gKlineTableForIF[IssueCode].issueCode,IssueCode)
						size = #gKlineTableForIF[IssueCode].time
					end
				end
				table.insert(gKlineTableForIF[IssueCode].time,currentMinute)
				table.insert(gKlineTableForIF[IssueCode].close,lt.new)
				table.insert(gKlineTableForIF[IssueCode].volume,lt.nowvol)
				table.insert(gKlineTableForIF[IssueCode].issueCode,IssueCode)
			end
			size = #gKlineTableForIF[IssueCode].time
			local updatekline = {time = {},close = {},volume = {},issueCode = {}}
			table.insert(updatekline.time,gKlineTableForIF[IssueCode].time[size])
			table.insert(updatekline.close,gKlineTableForIF[IssueCode].close[size])
			table.insert(updatekline.volume,gKlineTableForIF[IssueCode].volume[size])
			table.insert(updatekline.issueCode,gKlineTableForIF[IssueCode].issueCode[size])
			if gCurrentFutureIssue == IssueCode then
				SendToUI('FutureCloseGraph',updatekline)
				SendToUI('FutureVolumeGraph',updatekline)
			end

		--local logs = string.format("issueCode:%s,time:%s,close:%s,volume:%s",IssueCode,gKlineTableForIF[IssueCode].time[size],gKlineTableForIF[IssueCode].close[size],gKlineTableForIF[IssueCode].volume[size])
		--Writelog(logs)
		end
	end

	if gCombinIssueList[_CurrentCombin] and FittingGraphType == "1"then
		if IssueCode == gRight or IssueCode == gLeft or IssueCode == "M000300" then
			SendFittingGraph(lt)
		end
	end
end
function SendCombinEvent(CombinCode)		-- �������ʵʱˢ����Ϣ
	Writelog("SendCombinEvent")
	--�������������ֵ
	local Value = 0
	local BaseValue = 0
	for issue, info in pairs(gCombinIssueList[CombinCode]) do
		if gPriceTable[issue] then
			local LastPrice = tonumber(GetforPrice(issue,"new"))

			if LastPrice == 0 then
				LastPrice = tonumber(GetforPrice(issue,"lastclose"))
			end
			info.Value = info.Qty * LastPrice				--��Լ��ֵ
			info.SharesValue = info.Shares * LastPrice		--��Լ��ͨ����ֵ
			Value = Value + info.Value						--�����ֵ
			BaseValue = BaseValue + info.BaseValue			--��ϻ�׼��ֵ
		end

	end
	--���������ֵ
	gCombinList[CombinCode].LastValue = string.format("%.02f",Value)
	--��������ּ�
	if tonumber(BaseValue) > 0 then
	gCombinList[CombinCode].Price = string.format("%.02f",gCombinList[CombinCode].BasePrice * (Value/BaseValue))
	else
	gCombinList[CombinCode].Price = "0.00"
	end
	--����������³���ֵ
	gCombinList[CombinCode].ExpValue = ExpValueEvent(gCombinList[CombinCode])

	--���������϶�
	local temp = CalculateFit(CombinCode)

	gCombinList[CombinCode].Fit = string.format("%.02f",temp.Fit)
	gCombinList[CombinCode].FitValue = string.format("%.02f",temp.FitValue)

	--���������ҵ��ֵ����ͨ����ֵ
	SetIndustryValue(CombinCode)

	if _CurrentCombin == CombinCode then
		local lt={}
		lt.Value=gCombinList[CombinCode].LastValue
		lt.ExpValue = gCombinList[CombinCode].ExpValue
		lt.Fit = gCombinList[CombinCode].Fit
		SendToUIScript("SendCombinEvent",lt)
		SendCurrentCombinList(CombinCode)
	end
end
function SetIndustryValue(CombinCode)		--���������ҵ��ֵ
	Writelog("SetIndustryValue")
	--��϶�Ӧ��ҵ������ֵ
	for IndustryName,v in pairs (gCombinIndustryList[CombinCode]) do
		gCombinIndustryList[CombinCode][IndustryName].Value = 0
		gCombinIndustryList[CombinCode][IndustryName].Shares = 0
	end
	for issue, info in pairs(gCombinIssueList[CombinCode]) do
		local IndustryName = gIndustryTable[issue] or "-"
		if gCombinIndustryList[CombinCode][IndustryName] then
			local IndustryList = gCombinIndustryList[CombinCode][IndustryName]
			IndustryList.Value = IndustryList.Value + gCombinIssueList[CombinCode][issue].Value
			IndustryList.Shares = IndustryList.Shares + gCombinIssueList[CombinCode][issue].SharesValue
		end
	end
end
function OnstateJudge(issueCode,lt)--��Ʊ״̬�ж�
	local askQty1 = lt.sellvolume1 or 0;
	local askQty2 = lt.sellvolume2 or 0;
	local askQty3 = lt.sellvolume3 or 0;
	local askQty4 = lt.sellvolume4 or 0;
	local askQty5 = lt.sellvolume5 or 0;
	local bidQty1 = lt.buyvolume1 or 0;
	local bidQty2 = lt.buyvolume2 or 0;
	local bidQty3 = lt.buyvolume3 or 0;
	local bidQty4 = lt.buyvolume4 or 0;
	local bidQty5 = lt.buyvolume5 or 0;

	--local gLogs = string.format("issueCode:%s stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
	--Writelog(gLogs); -- for not normal only.

	if (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
		--gLogs = sys_format("issueCode:%s SP stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
		--writeLog(gLogs);
		return "ͣ��";	--SusPend ͣ��
	elseif (askQty1 > 0 or askQty2 > 0 or askQty3 > 0 or askQty4 > 0 or askQty5 > 0) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
		--gLogs = sys_format("issueCode:%s DL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
		--writeLog(gLogs);
		return "��ͣ";	--Decline Limit ��ͣ
	elseif (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 > 0 or bidQty2 > 0 or bidQty3 > 0 or bidQty4 > 0 or bidQty5 > 0) then
		--gLogs = sys_format("issueCode:%s SL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
		--writeLog(gLogs);
		return "��ͣ";	--Surged Limit ��ͣ
	else
		return "����";	--NorMal ����
	end
end

----------------
--�½�����߼�--
----------------
gCurrentList = {IndustryName={},IndustryCode={}}		--��ǰ�����Ϣ��
gCurrentIssueList = {}			--��ǰ�����ϸ��
gBeiXuanCombinCode = ""			--��ǰ��ѡ��Ϻ�
gBaseRateSet = 0.01			--Ĭ�ϱ��Ȩ��
function IndustryInit(arg)		--��ϳ�ʼ��
	Writelog("IndustryInit")
	CreateLog("������...")
	gCurrentList = {IndustryName={},IndustryCode={},ETFName={},ETFCode={}}
	gCurrentIssueList = {}
	--���ͺ�Լ��
	--local tempTable = {CombinCode={},CombinName={},IndustryName={},BaseIndexCode={},BaseName={},AnalDays={},LastValue={},PreQty={},
	--PreCast={},BaseDate={},BasePrice={},AllCheck={},KeepCheck={},Check1={},Check2={},Check3={}}
	local combincode = arg.CombinCode
	for i,info in pairs(gCombinList)do
		if info.BaseIndexCode ~= "M000300" then	--Ϊ0��ʾ���Ϊ��Լ�����
			if not ETFIDtoName[i] then			--��Լ���б�
			table.insert(gCurrentList.IndustryName,info.CombinName)
			table.insert(gCurrentList.IndustryCode,i)
			else
			local name = string.format("%s %s",ETFIDtoName[i].IssueCode,ETFIDtoName[i].FundName)
			table.insert(gCurrentList.ETFName,name)
			table.insert(gCurrentList.ETFCode,i)
			end
		end
	end
	if gCombinList[combincode] then
		--��ǰ����Ѵ���
		local tempList = gCombinList[combincode]
		gCurrentList.CombinCode = combincode
		gCurrentList.CombinName = tempList.CombinName
		gCurrentList.Number = tempList.Number
		gCurrentList.WeightCover = tempList.WeightCover
		gCurrentList.IndustryCover = tempList.IndustryCover
		gCurrentList.ExpValue = tempList.ExpValue
		gCurrentList.BaseIndexCode = tempList.BaseIndexCode
		gCurrentList.BaseName = tempList.BaseName
		gCurrentList.AnalDays = tempList.AnalDays
		gCurrentList.BaseDate = tempList.BaseDate
		gCurrentList.BasePrice = tempList.BasePrice
		gCurrentList.Price = tempList.Price
		gCurrentList.LastValue = tempList.LastValue
		gCurrentList.PreQty = tempList.PreQty
		gCurrentList.PreCast = tempList.PreCast
		gCurrentList.AllCheck = tempList.AllCheck
		gCurrentList.KeepCheck = tempList.KeepChec
		gCurrentList.Check1 = tempList.Check1
		gCurrentList.Check2 = tempList.Check2
		gCurrentList.Check3 = tempList.Check3
		gCurrentList.UserID = tempList.UserID

		for issue,info in pairs  (gCombinIssueList[combincode]) do
			gCurrentIssueList[issue] = {}
			gCurrentIssueList[issue].IsCheck = "0"
			gCurrentIssueList[issue].IssueCode = issue
			gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
			gCurrentIssueList[issue].Number = info.Number
			gCurrentIssueList[issue].Qty = info.Qty
			gCurrentIssueList[issue].Weight = info.Weight
			gCurrentIssueList[issue].BaseWeight = GetBaseWeight(issue) or info.BaseWeight
			if gPriceTable[issue] then
				gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
				gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
				gCurrentIssueList[issue].Status = gPriceTable[issue].Status
			else
				gCurrentIssueList[issue].LastPrice = GetPrice(issue).new or 0
				gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose or 0
				gCurrentIssueList[issue].Status = "-"
				local temp = toObjID(issue)
				StartPrice(temp,"No5Market")
			end
			gCurrentIssueList[issue].Industry = info.Industry
			gCurrentIssueList[issue].Shares = info.Shares
			gCurrentIssueList[issue].Capital = info.Capital
			gCurrentIssueList[issue].Value = gCurrentIssueList[issue].LastPrice * gCurrentIssueList[issue].Qty
			gCurrentIssueList[issue].Flag = "1"
		end
		sendCrrentIssue("all")
	else
		--�����
		gCurrentList.CombinCode = combincode
		gCurrentList.CombinName = combincode
		gCurrentList.Number = 0
		gCurrentList.WeightCover = 0
		gCurrentList.IndustryCover = 0
		gCurrentList.ExpValue = 0
		gCurrentList.BaseIndexCode = "M000300"
		gCurrentList.BaseName = "����300"
		gCurrentList.AnalDays = "100"
		gCurrentList.BaseDate = gKlineindexTable.time[#gKlineindexTable.time]
		gCurrentList.BasePrice = gKlineindexTable.close[#gKlineindexTable.time]
		gCurrentList.Price = 0
		gCurrentList.LastValue = 0
		gCurrentList.PreQty = 1
		gCurrentList.PreCast = gKlineindexTable.close[#gKlineindexTable.time] * 300
		gCurrentList.AllCheck = "0"
		gCurrentList.KeepCheck ="0"
		gCurrentList.Check1 = "1"
		gCurrentList.Check2 = "1"
		gCurrentList.Check3 = "1"
		gCurrentList.UserID = gUSERID

	end
	gCurrentList.BaseRateSet = gBaseRateSet
	gCurrentList.levelCheck = "0"
	gCurrentList.level = "0"
	SendToUIScript("SetAll",gCurrentList);
	SendInformation()
	--���ͻ�׼��Լ�۸��
	--[[local KlineTable = GetKLine("SH000300.index", "1d", nil, nil, -100, 100)
	tempTable = {time={},close={}}
	for i,v in pairs(KlineTable.time) do
		table.insert(tempTable.time,v)
		table.insert(tempTable.close,KlineTable.close[i])
	end
	SendToUIScript("KlineindexOut",tempTable);]]

	--����Ĭ�Ϻ�Լ��[����300]
	--local arg= {CombinCode = "300ȫ����"}
	--OnSelectIndustryList(arg)
	CreateLog("OK")
end
function RateSetEvent(arg)			--��ȡ���Ȩ��������Ϣ
	Writelog("RateSetEvent")
	gBaseRateSet = tonumber(arg.Rate)
	Writelog(gBaseRateSet)
	local lt = {}
	lt.CombinCode = gBeiXuanCombinCode
	OnSelectIndustryList(lt)
	DoEventlogic()
end
function OnSelectIndustryList(arg)		--��Լ��ѡ���߼�
	Writelog("OnSelectIndustryList")
	CreateLog("���ڶ�ȡ����...")
	gBeiXuanCombinCode = arg.CombinCode
	local templist = {IsCheck={},IssueCode={},Number={},IssueName={},Weight={},Industry={},Qty={}}
	if gCombinIssueList[gBeiXuanCombinCode] then
		for issue,info in pairs (gCombinIssueList[gBeiXuanCombinCode]) do
			if (gCurrentList.levelCheck == "1" and tonumber(info.Weight) > tonumber(gCurrentList.level)) or gCurrentList.levelCheck ~= "1" then
				if gCurrentIssueList[issue] then
					table.insert(templist.IsCheck,"1")
				else
					table.insert(templist.IsCheck,"0")
				end
				table.insert(templist.IssueCode,issue)
				table.insert(templist.Number,info.Number)
				table.insert(templist.IssueName,gIssueNameList[issue])
				if tonumber(info.Weight) == 0 then
					table.insert(templist.Weight,gBaseRateSet)
				else
					table.insert(templist.Weight,info.Weight)
				end
				if gPriceTable[issue] and info.Qty == 0 then
					local Price = gPriceTable[issue].lastclose
					if Price and Price ~= 0 then
					info.Qty = math.ceil(gKlineindexTable.close[#gKlineindexTable.time]*300*info.Weight/100/Price)
					end
				end
				table.insert(templist.Qty,info.Qty)
				table.insert(templist.Industry,info.Industry or "")
			end
		end
	end
	Writelog(serialize(templist))
	SendToUIScript("IndustryIssueList",templist);
	CreateLog("OK")
end
function OnSelectIndustrysingle(issue)	--����ˢ�±�ѡ����Լ
	local templist = {IsCheck={},IssueCode={},Number={},IssueName={},Weight={},Industry={},Qty={}}
	if gCombinIssueList[gBeiXuanCombinCode] then
		Writelog(serialize(gCombinIssueList[gBeiXuanCombinCode]))
		if gCombinIssueList[gBeiXuanCombinCode][issue] then
			local info = gCombinIssueList[gBeiXuanCombinCode][issue]
			if (gCurrentList.levelCheck == "1" and tonumber(info.Weight) > tonumber(gCurrentList.level)) or gCurrentList.levelCheck ~= "1" then
				if gCurrentIssueList[issue] then
					table.insert(templist.IsCheck,"1")
				else
					table.insert(templist.IsCheck,"0")
				end
				table.insert(templist.IssueCode,issue)
				table.insert(templist.Number,info.Number)
				table.insert(templist.IssueName,gIssueNameList[issue])
				if tonumber(info.Weight) == 0 then
					table.insert(templist.Weight,gBaseRateSet)
				else
					table.insert(templist.Weight,info.Weight)
				end
				table.insert(templist.Qty,info.Qty)
				table.insert(templist.Industry,info.Industry or "")
			end
		end
	end

	Writelog(serialize(templist))
	SendToUIScript("SingleIndustryIssueList",templist);
end
function GetBaseWeight(issue)	--��ȡ300ȫ���Ʊ��Ȩ��
	local Weight = nil
	if gCombinIssueList["300ȫ����"] and gCombinIssueList["300ȫ����"][issue] then
		Weight = gCombinIssueList["300ȫ����"][issue].Weight
	end
	return Weight
end
function TimeChange(arg)		--��׼���ڱ仯
	Writelog("TimeChange")
	gCurrentList.BaseDate = arg.BaseDate
	for i,v in pairs(gKlineindexTable.time) do
		if v == arg.BaseDate then
			gCurrentList.BasePrice = gKlineindexTable.close[i]
		end
	end
	SendToUIScript("TimeChangeOut",gCurrentList);
end
function CreateNumber()			--�ұ��
	local temp = 1
	while fundnumber(temp) do
		temp = temp + 1;
	end
	return temp
end
function fundnumber(temp)		--�ұ��
	for issue,info in pairs (gCurrentIssueList) do
		if temp == info.Number then
			return true
		end
	end
	return false
end
function AddIssueCode(arg)		--���Ӻ�Լ
	Writelog("AddIssueCode")
	local issue = arg.IssueCode
	if not gCurrentIssueList[issue] then
		gCurrentIssueList[issue] = {}
		gCurrentIssueList[issue].IsCheck = "0"
		gCurrentIssueList[issue].IssueCode = issue
		gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
		gCurrentIssueList[issue].Number = CreateNumber()

		gCurrentIssueList[issue].Qty = arg.Qty
		gCurrentIssueList[issue].Weight = arg.Weight
		gCurrentIssueList[issue].BaseWeight = arg.Weight
		gCurrentIssueList[issue].Flag = "1"
		--_WriteAplLog(gBeiXuanCombinCode)
		if gCombinIssueList[gBeiXuanCombinCode]and gCombinIssueList[gBeiXuanCombinCode][issue] then

			local Weight = gCombinIssueList[gBeiXuanCombinCode][issue].Weight
			--_WriteAplLog(Weight)
			if tonumber(Weight) == 0 then
				gCurrentIssueList[issue].Flag = "3"
			end
		end
		if gPriceTable[issue] then
			gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
			gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
			gCurrentIssueList[issue].Status = gPriceTable[issue].Status
		else
			gCurrentIssueList[issue].LastPrice = GetPrice(issue).new or 0
			gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose or 0
			gCurrentIssueList[issue].Status = ""
			local temp = toObjID(issue)
			StartPrice(temp,"No5Market")
		end
		gCurrentIssueList[issue].Industry = gIndustryTable[issue] or "-"
		gCurrentIssueList[issue].Shares = GetissueShares(issue)
		gCurrentIssueList[issue].Capital = GetCapital(issue)
		gCurrentIssueList[issue].Value = gCurrentIssueList[issue].LastPrice * gCurrentIssueList[issue].Qty
		gCurrentList.Number = gCurrentList.Number + 1
		gCurrentList.LastValue = gCurrentList.LastValue + gCurrentIssueList[issue].Value
	end
	OnSelectIndustrysingle(issue)
	sendCrrentIssue(issue)
	SendInformation()
end
function AllAdd(arg)			--ȫ������
	Writelog("AllAdd")
	CreateLog("���ڶ�ȡ����...")
	for issue,info in pairs (gCombinIssueList[gBeiXuanCombinCode]) do
		if not gCurrentIssueList[issue] then
			if (gCurrentList.levelCheck == "1" and tonumber(info.Weight) > tonumber(gCurrentList.level)) or gCurrentList.levelCheck ~= "1" then
				gCurrentIssueList[issue] = {}
				gCurrentIssueList[issue].IsCheck = "0"
				gCurrentIssueList[issue].IssueCode = issue
				gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
				gCurrentIssueList[issue].Number = CreateNumber()
				gCurrentIssueList[issue].Qty = info.Qty
				if tonumber(info.Weight) == 0 then
					gCurrentIssueList[issue].Weight = gBaseRateSet
					gCurrentIssueList[issue].BaseWeight = gBaseRateSet
					gCurrentIssueList[issue].Flag = "3"
				else
					gCurrentIssueList[issue].Weight = info.Weight
					gCurrentIssueList[issue].BaseWeight = info.Weight
				end
				if gPriceTable[issue] then
					gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
					gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
					gCurrentIssueList[issue].Status = gPriceTable[issue].Status
				else
					gCurrentIssueList[issue].LastPrice = GetPrice(issue).new or 0
					gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose or 0
					gCurrentIssueList[issue].Status = ""
					local temp = toObjID(issue)
					StartPrice(temp,"No5Market")
				end
				gCurrentIssueList[issue].Industry = info.Industry
				gCurrentIssueList[issue].Shares = GetissueShares(issue)
				gCurrentIssueList[issue].Capital = GetCapital(issue)
				gCurrentIssueList[issue].Value = gCurrentIssueList[issue].LastPrice * gCurrentIssueList[issue].Qty
				gCurrentList.Number = gCurrentList.Number + 1
				gCurrentList.LastValue = gCurrentList.LastValue + gCurrentIssueList[issue].Value
			end
		end
	end
	sendCrrentIssue("all")
	local lt = {}
	lt.CombinCode = gBeiXuanCombinCode
	OnSelectIndustryList(lt)
	SendInformation()
	CreateLog("OK")
	--��ȡ��ͨ����Ϣ
	--CreateLog("���ڶ�ȡ��ͨ������")
	--for issue,info in pairs(gCurrentIssueList) do
	--	gCurrentIssueList[issue].Shares = GetissueShares(issue)
	--	gCurrentIssueList[issue].Capital = GetCapital(issue)
	--end
	--CreateLog("OK")
	--sendCrrentIssue("all")
end
function CreateLog(arg)			--���ͽ���log
	local temp = {}
	temp.CreateLog = arg
	SendToUIScript("CreateLog",temp);
end
function DelectIssue(arg)		--ɾ����Լ
	Writelog("DelectIssue")
	local tempcode = arg.IssueCode
	if gCurrentIssueList[tempcode] then
		local templist = {IssueCode={},Number={},IssueName={},Status={},Shares={},Weight={},Qty={},BaseWeight={},IsCheck={},Industry={},Flag={}}
		table.insert(templist.Number,gCurrentIssueList[tempcode].Number)
		table.insert(templist.IssueCode,tempcode)
		table.insert(templist.Flag,"2")
		SendToUIScript("CurrentIssueList",templist);
		gCurrentList.LastValue = gCurrentList.LastValue - gCurrentIssueList[tempcode].Value
		gCurrentList.Number = gCurrentList.Number - 1
		gCurrentIssueList[tempcode] = nil
		OnSelectIndustrysingle(tempcode)
		SendInformation()
	end
end
function DelectAll(arg)			--ȫ��ɾ��
	Writelog("DelectAll")
	gCurrentIssueList = {}
	gCurrentList.LastValue = 0
	gCurrentList.Number = 0
	SendInformation()
	local lt = {}
	lt.CombinCode = gBeiXuanCombinCode
	OnSelectIndustryList(lt)
end
function sendCrrentIssue(issue)	--���ͺ�Լ��Ϣ����ϱ�
	Writelog("sendCrrentIssue")
	local templist = {IssueCode={},Number={},IssueName={},Status={},Shares={},Weight={},Qty={},BaseWeight={},IsCheck={},Industry={},Flag={}}
	if issue ~= "all" then
		local info = gCurrentIssueList[issue]
		table.insert(templist.IssueCode,info.IssueCode)
		table.insert(templist.Number,info.Number)
		table.insert(templist.IssueName,info.IssueName)
		table.insert(templist.Weight,info.Weight)
		table.insert(templist.Qty,info.Qty)
		table.insert(templist.Status,info.Status)
		table.insert(templist.Shares,info.Shares)
		table.insert(templist.IsCheck,info.IsCheck)
		table.insert(templist.Industry,info.Industry)
		if tonumber(info.BaseWeight) == 0 then
		table.insert(templist.BaseWeight,"")
		else
		table.insert(templist.BaseWeight,info.BaseWeight)
		end
		table.insert(templist.Flag,info.Flag)
	else
		for issuecode,info in pairs(gCurrentIssueList)do
			table.insert(templist.IssueCode,info.IssueCode)
			table.insert(templist.Number,info.Number)
			table.insert(templist.IssueName,info.IssueName)
			table.insert(templist.Weight,info.Weight)
			table.insert(templist.Qty,info.Qty)
			table.insert(templist.Status,info.Status)
			table.insert(templist.Shares,info.Shares)
			table.insert(templist.IsCheck,info.IsCheck)
			table.insert(templist.Industry,info.Industry)
			if tonumber(info.BaseWeight) == 0 then
			table.insert(templist.BaseWeight,"")
			else
			table.insert(templist.BaseWeight,info.BaseWeight)
			end
			table.insert(templist.Flag,info.Flag)
		end
	end
	Writelog(serialize(templist))
	SendToUIScript("CurrentIssueList",templist);
end
function ChangeIssueSet(arg)	--�޸ĺ�Լ����
	Writelog("ChangeIssueSet")
	Writelog(arg.IssueCode)
	Writelog(arg.Qty)
	Writelog(arg.Weight)
	if gCurrentIssueList[arg.IssueCode] then
		gCurrentIssueList[arg.IssueCode].Qty = arg.Qty
		gCurrentIssueList[arg.IssueCode].Weight = arg.Weight
		gCurrentIssueList[arg.IssueCode].IsCheck = "1"
		--DoEventlogic()
	end
end

function InputCheckEvent(arg)	--��ѡ����
	Writelog("InputCheckEvent")
	Writelog(arg.IssueCode)
	Writelog(arg.IsCheck)
	if arg.IsCheck == "1" then
		gCurrentIssueList[arg.IssueCode].IsCheck = "1"
	else
		gCurrentIssueList[arg.IssueCode].IsCheck = "0"
	end
	--DoEventlogic()
end

function InputAllCheck(arg)		--ȫ����ѡ
	Writelog("InputAllCheck")
	Writelog(arg.AllCheck)
	if arg.AllCheck == "True" then
		for i ,info in pairs(gCurrentIssueList) do
			info.IsCheck = "1"
		end
	else
		for i ,info in pairs(gCurrentIssueList) do
			info.IsCheck = "0"
		end
	end
end
function levelCheckEvent(arg)	--Ȩ������
	Writelog("levelCheckEvent")
	Writelog(arg.levelCheck)
	Writelog(arg.level)
	gCurrentList.levelCheck = arg.levelCheck
	gCurrentList.level = arg.level
	local lt = {}
	lt.CombinCode = gBeiXuanCombinCode
	OnSelectIndustryList(lt)
end
function SPEventlogic(arg)		--���ͣ��
	Writelog("SPEventlogic")
	Writelog(serialize(arg))
	local SPList = arg.SPList
	local SP = arg.SP
	local List = arg.List
	local Check1 = gCurrentList.Check1
	if SPList == "��Ȩ�ط�����������й�Ʊ" then
		if SP then
			for i,issue in pairs (SP.IssueCode) do
				if gCurrentIssueList[issue] and SP.IsCheck[i] == "1" then
					gCurrentList.Number = gCurrentList.Number - 1
					gCurrentIssueList[issue] = nil
				end
			end
		end
	elseif SPList == "��Ȩ�ط����ͬ��ҵ������Ʊ" then
		if SP then
			local Industrylist = {}
			local CurrentIndustrylist = {}
			gCurrentList.Check1 = "0"		--Ȩ��
			for i,issue in pairs (SP.IssueCode) do
				if gCurrentIssueList[issue] and SP.IsCheck[i] == "1" then
					gCurrentList.Number = gCurrentList.Number - 1
					local Industry = gCurrentIssueList[issue].Industry
					if not Industrylist[Industry] then
						Industrylist[Industry] = 0
					end
					Industrylist[Industry] = Industrylist[Industry] + gCurrentIssueList[issue].Weight
					gCurrentIssueList[issue] = nil
				end
			end
			for issue,info in pairs(gCurrentIssueList)do
				local Industry = gCurrentIssueList[issue].Industry
				if not CurrentIndustrylist[Industry] then
					CurrentIndustrylist[Industry] = 0
				end
				CurrentIndustrylist[Industry] = CurrentIndustrylist[Industry] + info.Weight
			end

			for issue,info in pairs(gCurrentIssueList)do
				if Industrylist[info.Industry] then
					info.Weight = info.Weight + info.Weight * Industrylist[info.Industry] / CurrentIndustrylist[info.Industry]

					info.IsCheck = "1"
				end
			end
		end
	elseif SPList == "�����ƽ�ָ�ͬ��ҵ������Ʊ" then
		if SP then
			local Industrylist = {}
			local CurrentIndustrylist = {}
			gCurrentList.Check1 = "1"		--����
			for i,issue in pairs (SP.IssueCode) do
				if gCurrentIssueList[issue] and SP.IsCheck[i] == "1" then
					gCurrentList.Number = gCurrentList.Number - 1
					local Industry = gCurrentIssueList[issue].Industry
					if not Industrylist[Industry] then
						Industrylist[Industry] = 0
					end
					Industrylist[Industry] = Industrylist[Industry] + gCurrentIssueList[issue].Value
					gCurrentIssueList[issue] = nil
				end
			end
			for issue,info in pairs(gCurrentIssueList)do
				local Industry = gCurrentIssueList[issue].Industry
				if not CurrentIndustrylist[Industry] then
					CurrentIndustrylist[Industry] = 0
				end
				CurrentIndustrylist[Industry] = CurrentIndustrylist[Industry] + 1
			end

			for issue,info in pairs(gCurrentIssueList)do
				if Industrylist[info.Industry] then
					local Price =tonumber(GetforPrice(issue,"new"))		--��ȡ����
					if Price and Price ~= 0 then
					info.Qty = info.Qty + Industrylist[info.Industry] / CurrentIndustrylist[info.Industry] / Price
					info.Qty = math.ceil(tonumber(info.Qty))
					end
					info.IsCheck = "1"
				end
			end
		end
	elseif SPList == "�����ƽ�ָ������������������Ʊ" then
		if SP then
			local Industrylist = {}
			local CurrentIndustrylist = {}
			gCurrentList.Check1 = "1"		--����
			for i,issue in pairs (SP.IssueCode) do
				if gCurrentIssueList[issue] and SP.IsCheck[i] == "1" then
					gCurrentList.Number = gCurrentList.Number - 1
					gCurrentIssueList[issue] = nil
				end
			end
		end
	elseif SPList == "ȫ�������ָ����Ʊ" then
		if SP and List then
			local Industrylist = 0
			local CurrentIndustrylist = {}
			local sum = 0
			gCurrentList.Check1 = "1"		--����
			for i,issue in pairs (SP.IssueCode) do
				if gCurrentIssueList[issue] and SP.IsCheck[i] == "1" then
					gCurrentList.Number = gCurrentList.Number - 1
					Industrylist = Industrylist + gCurrentIssueList[issue].Value
					gCurrentIssueList[issue] = nil
				end
			end
			for i,issue in pairs (List.IssueCode) do
				if gCurrentIssueList[issue] and List.IsCheck[i] == "1" then
					sum = sum + 1
				end
			end
			for i,issue in pairs (List.IssueCode) do
				if gCurrentIssueList[issue] and List.IsCheck[i] == "1" then
					local info = gCurrentIssueList[issue]
					local Price =tonumber(GetforPrice(issue,"new"))		--��ȡ����
					if Price and Price ~= 0 then
					info.Qty = info.Qty + Industrylist / Price
					info.Qty = math.ceil(tonumber(info.Qty))
					end
					info.IsCheck = "1"
				end
			end
		end
	elseif SPList == "������Ӧ����" then
		if SP then
			gCurrentList.Check1 = "1"		--����
			for i,issue in pairs (SP.IssueCode) do
				if gCurrentIssueList[issue] and SP.IsCheck[i] == "1" then
					gCurrentList.Number = gCurrentList.Number - 1
					gCurrentIssueList[issue] = nil
				end
			end
			for issue,info in pairs(gCurrentIssueList)do
				info.IsCheck = "1"
			end
		end
	end
	DoEventlogic()
	local lt = {}
	lt.CombinCode = gBeiXuanCombinCode
	OnSelectIndustryList(lt)
	gCurrentList.Check1 = Check1
end


function IndustrySetOut(arg)	--�Զ�����
    Writelog("IndustrySetOut start " .. serialize(arg))
	local CombinCode = arg.IndustryName
	local IndustrySet = arg.IndustrySet
	CreateLog("������...")
	if gCombinIndustryList[CombinCode] then
        local FilterIssue = {}
		if IndustrySet == "Ȩ�ش�С" then
            local SelectCount = tonumber(arg.Qty)
            FilterIssue = FilterIssueByWeightLarge(CombinCode, SelectCount)

		elseif IndustrySet == "Ȩ������" then
			local MinWeight = tonumber(arg.Weight1)
			local MaxWeight = tonumber(arg.Weight2)
            FilterIssue = FilterIssueByWeightArea(CombinCode, MinWeight, MaxWeight)

		elseif IndustrySet == "ǿ�ƹ�" then
			local SelectCount = tonumber(arg.Qty)
            local StrongType = arg.QSList
            FilterIssue = FilterIssueByStrong(CombinCode, SelectCount, StrongType)

		elseif IndustrySet == "��ҵ�ֲ�" then
			local SectorID = arg.SerList
            FilterIssue = FilterIssueBySector(CombinCode, SectorID)
		end

        --�Զ������������
        gCurrentIssueList = {}
        gCurrentList.LastValue = 0
        gCurrentList.Number = 0
        for i, kIssue in pairs(FilterIssue) do
            AddAutoIssueCode(kIssue, CombinCode)
        end

        --�Զ�����������
        local lt = {}
        lt.CombinCode = gBeiXuanCombinCode
        OnSelectIndustryList(lt)

        sendCrrentIssue("all")		--ˢ��������ѡ�������
        SendInformation()
	end
	CreateLog("OK")
    Writelog("IndustrySetOut end")
end


function AddAutoIssueCode(issue, CombinCode)--�����Զ�������Ʊ
	Writelog("AddIssueCode start " .. issue .. "," .. CombinCode)
	if not gCurrentIssueList[issue] then
		gCurrentIssueList[issue] = {}
		gCurrentIssueList[issue].IsCheck = "0"
		gCurrentIssueList[issue].IssueCode = issue
		gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
		gCurrentIssueList[issue].Number = CreateNumber()
		gCurrentIssueList[issue].Qty = gCombinIssueList[CombinCode][issue].Qty
		gCurrentIssueList[issue].Weight = gCombinIssueList[CombinCode][issue].Weight
		gCurrentIssueList[issue].BaseWeight = gCombinIssueList[CombinCode][issue].Weight
		if gPriceTable[issue] then
			gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
			gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
			gCurrentIssueList[issue].Status = gPriceTable[issue].Status
		else
			gCurrentIssueList[issue].LastPrice = GetPrice(issue).new or 0
			gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose or 0
			gCurrentIssueList[issue].Status = ""
			local temp = toObjID(issue)
			StartPrice(temp,"No5Market")
		end
		gCurrentIssueList[issue].Industry = gIndustryTable[issue] or "-"
		gCurrentIssueList[issue].Shares = GetissueShares(issue)
		gCurrentIssueList[issue].Capital = GetCapital(issue)
		gCurrentIssueList[issue].Value = gCurrentIssueList[issue].LastPrice * gCurrentIssueList[issue].Qty
		gCurrentList.Number = gCurrentList.Number + 1
		gCurrentList.LastValue = gCurrentList.LastValue + gCurrentIssueList[issue].Value
	end
end



function FilterIssueByWeightLarge(CombinCode, SelectCount)--��Ȩ�ش�С
    Writelog("FilterIssueByWeightLarge start " .. CombinCode .. "," .. SelectCount)

    local ret = {}
    local List = {}
    for kIssue, v in pairs(gCombinIssueList[CombinCode]) do
        local temp = {}
        temp.IssueCode = kIssue
        temp.Weight = v.Weight
        table.insert(List, temp)
    end

    local sortFunc = function(a, b) return b.Weight < a.Weight end
    table.sort(List,sortFunc)

    local count = 0
    for n, v in pairs (List) do
        count = count + 1
        if count > SelectCount then
            break
        else
            local IssueCode = v.IssueCode
            table.insert(ret, IssueCode)
        end
    end
    Writelog("FilterIssueByWeightLarge end " .. serialize(ret))
    return ret
end


function FilterIssueByWeightArea(CombinCode, MinWeight, MaxWeight)--��Ȩ������
    Writelog("FilterIssueByWeightArea start " .. CombinCode .. "," .. MinWeight .. "," .. MaxWeight)

    local ret = {}
    local List = gCombinIssueList[CombinCode]
    for issue,v in pairs (List) do
        local Weight = tonumber(v.Weight)
        if Weight >= MinWeight and Weight <= MaxWeight then
            table.insert(ret, issue)
        end
    end
    Writelog("FilterIssueByWeightArea end " .. serialize(ret))

    return ret
end


function FilterIssueBySector(CombinCode, SectorID)--����ҵ�ֲ�
    Writelog("FilterIssueBySector start " .. CombinCode .. "," .. SectorID)
    local ret = {}

    for issue, v in pairs (gCombinIssueList[CombinCode]) do
        if gIndustryTable[issue] == SectorID then
            table.insert(ret, issue)
        end
    end

    Writelog("FilterIssueBySector end " .. serialize(ret))
    return ret
end


function FilterIssueByStrong(CombinCode, SelectCount, StrongType)--��ǿ�ƹ�
    Writelog("FilterIssueByStrong start " .. CombinCode .. "," .. SelectCount .. "," .. StrongType)
    local ret = {}
    local List = {}
    for kIssue, v in pairs(gCombinIssueList[CombinCode]) do
        local objID = toObjID(kIssue)
        local start = tonumber(-StrongType)
        local count = tonumber(StrongType)

        local KLine = GetKLine(objID, "1d", nil, nil, start, count,1)
        local KLineSize = #KLine.obj
        if KLine.obj and KLineSize > 0 then
            local HisClose = KLine["close"][1]
            local LastClose = KLine["close"][KLineSize]
            local UpRate = LastClose / HisClose - 1
--           local log = string.format("FilterIssueByStrong Test %s,%s,%s,%f,%f,%f",objID,KLine["time"][1],KLine["time"][KLineSize],HisClose,LastClose,UpRate)
--            _WriteAplLog(log)
            local temp = {}
            temp.IssueCode = kIssue
            temp.UpRate = UpRate
            table.insert(List, temp)
        end
    end

    local sortFunc = function(a, b) return b.UpRate < a.UpRate end
    table.sort(List,sortFunc)

    local count = 0
    for n, v in pairs (List) do
        count = count + 1
        if count > SelectCount then
            break
        else
            local IssueCode = v.IssueCode
            table.insert(ret, IssueCode)
        end
    end
    Writelog("FilterIssueByStrong end " .. serialize(ret))
    return ret
end



function DoEvent(arg)			--���㰴ť�ص�
	Writelog("DoEvent")
	Writelog(arg.PreCast)
	Writelog(arg.PreQty)
	Writelog(arg.PreQtyCheck)
	Writelog(arg.AnalDays)
	Writelog(arg.PreCheck)
	Writelog(arg.QtyCheck)
	Writelog(arg.KeepCheck)
	if arg.PreCheck == "True" then
		gCurrentList.Check3 = "1"
	else
		gCurrentList.Check3 = "0"
	end
	if arg.PreQtyCheck == "True" then
		gCurrentList.Check2 = "1"
	else
		gCurrentList.Check2 = "0"
	end
	if arg.QtyCheck == "True" then
		gCurrentList.Check1 = "1"
	else
		gCurrentList.Check1 = "0"
	end
	if arg.KeepCheck == "True" then
		gCurrentList.KeepCheck = "1"
	else
		gCurrentList.KeepCheck = "0"
	end
	gCurrentList.AnalDays = arg.AnalDays
	gCurrentList.PreQty = arg.PreQty
	gCurrentList.PreCast = arg.PreCast

	DoEventlogic()
end
function DoEventlogic()			--��������
	SetIssueList()		--�����߼�
	CoverEvent(gCurrentList,gCurrentIssueList)			--Ȩ�ظ��ǣ���ҵ����
	gCurrentList.ExpValue = ExpValueEvent(gCurrentList)		--����ֵ����
	sendCrrentIssue("all")		--ˢ��������ѡ�������
	SendInformation()		--��ǰ��������Ϣ��ʾ
end
function SetIssueList()			--�����߼�
	local PreCast = gCurrentList.PreCast	--Ԥ���µ��ܽ��
	local AllValue = 0
	if gCurrentList.Check1 == "1" then	--����������
		local TempValue = tonumber(PreCast)
		local AllWeight	 = 0
		for issue,info in pairs (gCurrentIssueList) do
			local Price = GetforPrice(issue,"new")		--��ȡ����
			if gCurrentList.Check3 == "1" then		--�����ռۼ���
				Price = info.PrePrice
			end
			if gCurrentList.KeepCheck == "0" then	--���������
				info.Qty = math.ceil(tonumber(info.Qty)/100) * 100
			end
			Price = tonumber(Price)
			if Price and Price ~= 0 then
			info.Value = info.Qty * Price
			else
			info.Value = 0
			end
			if info.IsCheck == "1" then			--��ѡ
				TempValue = TempValue - tonumber(info.Value)	--Ԥ�����-��ѡ�еĺ�Լ���=��ʣ��Ľ��
			else
				if tonumber(info.BaseWeight) == 0 then			--���û�б��Ȩ�ػ�Ϊ0 ��ʹ��Ĭ�����ñ��Ȩ��
				AllWeight = AllWeight + tonumber(gBaseRateSet)--��û�й�ѡ�ĺ�Լ���Ȩ���ۼ�
				else
				AllWeight = AllWeight + tonumber(info.BaseWeight)--��û�й�ѡ�ĺ�Լ���Ȩ���ۼ�
				end
			end
		end
		if TempValue < 0 then	--�����ѡ�еĺ�Լ���ʹ���Ԥ�����
			PreCast = PreCast - TempValue
			TempValue = 0
		end
		local each = 0
		if AllWeight <= 0 then
			each = 0
		else
			each = TempValue / AllWeight
		end
		for issue,info in pairs (gCurrentIssueList) do
			local Price =GetforPrice(issue,"new")		--��ȡ����
			if gCurrentList.Check3 == "1" then		--�����ռۼ���
				Price = info.PrePrice
			end
			Price = tonumber(Price)
			if info.IsCheck == "1" then			--��ѡ
			else
				if tonumber(info.BaseWeight) == 0 then	--���û�б��Ȩ�ػ�Ϊ0 ��ʹ��Ĭ�����ñ��Ȩ��
				info.Value = each * tonumber(gBaseRateSet)
				else
				info.Value = each * tonumber(info.BaseWeight)
				end
				if Price and Price ~= 0 then
				info.Qty = math.ceil(info.Value / Price)
				else
				info.Qty = 0
				end
				if gCurrentList.KeepCheck == "0" then	--���������
					info.Qty = math.ceil(tonumber(info.Qty)/100) * 100
				end
				if Price and Price ~= 0 then
				info.Value = info.Qty * Price
				else
				info.Value = 0
				end
			end
			info.Weight = string.format("%.02f",info.Value/PreCast * 100)
			AllValue = AllValue + info.Value
		end
	else							--��Ȩ�ؼ���
		local AllWeight = 0				--Ȩ�غ�
		local TempAll = 100
		for issue,info in pairs (gCurrentIssueList) do
			if info.IsCheck == "1" then			--��ѡ
				TempAll = TempAll - tonumber(info.Weight)
			else
				if tonumber(info.BaseWeight) == 0 then	--���û�б��Ȩ�ػ�Ϊ0 ��ʹ��Ĭ�����ñ��Ȩ��
				AllWeight = AllWeight + tonumber(gBaseRateSet)
				else
				AllWeight = AllWeight + tonumber(info.BaseWeight)
				end
			end
		end
		if TempAll < 0 then TempAll = 0 end
		local each = 0
		if AllWeight <= 0 then
			each = 0
		else
			each = TempAll / AllWeight
		end
		local Cast = PreCast/100
		for issue,info in pairs (gCurrentIssueList) do
			local Price = GetforPrice(issue,"new")		--��ȡ����
			if gCurrentList.Check3 == "1" then		--�����ռۼ���
				Price = info.PrePrice
			end
			Price = tonumber(Price)
			if info.IsCheck == "1" then			--��ѡ
			else
				if tonumber(info.BaseWeight) == 0 then	--���û�б��Ȩ�ػ�Ϊ0 ��ʹ��Ĭ�����ñ��Ȩ��
				info.Weight = each * tonumber(gBaseRateSet)
				else
				info.Weight = each * tonumber(info.BaseWeight)
				end
			end
			local Qty = 0
			if Price and Price ~= 0 then
			Qty = math.ceil(Cast*info.Weight/Price)
			end
			if gCurrentList.KeepCheck == "0" then	--���������
				Qty = math.ceil(tonumber(Qty)/100) * 100
			end
			info.Qty = Qty
			if Price and Price ~= 0 then
			info.Value = info.Qty * Price
			else
			info.Value = 0
			end
			if tonumber(info.Weight) > 100 then
				info.Weight = 100
			end
			info.Weight = string.format("%.02f",info.Weight)
			AllValue = AllValue + info.Value
		end

	end
	gCurrentList.LastValue = AllValue
end

function CoverEvent(combinTable,issueTable)	--Ȩ�ظ��ǣ���ҵ���Ǽ���
	Writelog("CoverEvent")
	--gIndexWeight
	--Ȩ�ظ���
	local WeightAll = 0
	local temp = {}
	for issue,info in pairs(issueTable)do
		WeightAll = WeightAll + info.BaseWeight
		if gIndustryTable[issue] then
			if not temp[gIndustryTable[issue]] then temp[gIndustryTable[issue]] = 1 end
		end
	end
	if WeightAll > gIndexWeight then WeightAll = gIndexWeight end
	combinTable.WeightCover = string.format("%.03f",WeightAll/gIndexWeight)
	--��ҵ����
	--gIndustrySum
	local sum = 0
	for i,v in pairs(temp)do
		sum = sum +1
	end
	combinTable.IndustryCover = string.format("%.02f",sum/gIndustrySum)
end
function ExpValueEvent(combinTable)		--����ֵ����
	local Value = 0
	if gPriceTable["M000300"] then
		local Price = gPriceTable["M000300"].new
		Value = Price * 300 * tonumber(combinTable.PreQty)
	else
		local Price = GetPrice("M000300").new
		Value = Price * 300 * tonumber(combinTable.PreQty)
	end
	return string.format("%.02f",Value - combinTable.LastValue)
end
function SendInformation()			--��ǰ��������Ϣ��ʾ
	local lt = {}
	lt.WeightCover = gCurrentList.WeightCover or ""
	lt.ExpValue = gCurrentList.ExpValue or ""
	lt.IndustryCover = gCurrentList.IndustryCover or ""
	lt.LastValue = gCurrentList.LastValue or 0
	lt.Number = gCurrentList.Number or ""
	if lt.Number == 0 then
	lt.LastValue = "0"
	else
	lt.LastValue = string.format("%.02f",lt.LastValue)
	end
	SendToUIScript("SendInformation",lt);
end
function OkButton(arg)			--ȷ�ϰ�ť�߼�
	Writelog("OkButton")
	gCurrentList.CombinName = arg.CombinName
	if not gCombinList[gCurrentList.CombinCode] then gCombinList[gCurrentList.CombinCode] = {} end
	local templist = gCombinList[gCurrentList.CombinCode]
	for item,v in pairs(gCurrentList)do
		if item ~= "IndustryName" and item ~= "IndustryCode" and item ~= "ETFName" and item ~= "ETFCode" then
			templist[item] = v
		end
	end

	if not gCombinIssueList[gCurrentList.CombinCode] then gCombinIssueList[gCurrentList.CombinCode] = {} end
	templist = gCombinIssueList[gCurrentList.CombinCode]
	for issue,info in pairs (templist) do						--ɾ����϶���ĺ�Լ
		if not gCurrentIssueList[issue] then
			gCombinIssueList[gCurrentList.CombinCode][issue] = nil
			local condition = string.format("InventoryModelID = '%s' and IssueCode = '%s'",gCurrentList.CombinCode,issue)
			Delete(DB, condition, "InventoryOrder")
		end
	end

	gCombinList[gCurrentList.CombinCode].BaseWeight = 0
	gCombinList[gCurrentList.CombinCode].Weight = 0

	--������Ϻ�Լ��ϸ���������ҵ��ϸ��
	gCombinIndustryList[gCurrentList.CombinCode] = {}		--��ҵ���ÿ�
	local tempIndustrylist = gCombinIndustryList[gCurrentList.CombinCode]
	for issue,info in pairs(gCurrentIssueList)do
		if not templist[issue] then templist[issue] = {} end
		templist[issue].Number = info.Number
		templist[issue].IssueName = info.IssueName
		templist[issue].Qty = info.Qty
		templist[issue].Weight = info.Weight
		templist[issue].BaseWeight = info.BaseWeight
		templist[issue].BaseValue = info.Qty * getPrice(issue,gCurrentList.BaseDate)
		templist[issue].Industry = info.Industry
		templist[issue].Shares = info.Shares
		templist[issue].SharesValue = info.Shares * info.LastPrice
		templist[issue].Capital = info.Capital
		templist[issue].Value =  info.Qty * info.LastPrice
		templist[issue].LNC =  info.PrePrice
		if not tempIndustrylist[info.Industry] then
			tempIndustrylist[info.Industry] = {CodeNumber=0,Value=0,IndustryWeight=0,IndustryBaseWeight=0,BaseWeight=0,Weight=0,Shares=0,Capital=0}
		end
		local tempTable = tempIndustrylist[info.Industry]
		tempTable.IndustryName = info.Industry
		tempTable.CodeNumber = tempTable.CodeNumber + 1
		tempTable.BaseWeight = tempTable.BaseWeight + info.BaseWeight
		tempTable.Weight = tempTable.Weight + info.Weight
		tempTable.Value = tempTable.Value + templist[issue].Value
		tempTable.Capital = tempTable.Capital + templist[issue].Capital
		--ͳ������ڱ��Ȩ�غ�
		gCombinList[gCurrentList.CombinCode].BaseWeight = gCombinList[gCurrentList.CombinCode].BaseWeight + tempTable.BaseWeight
		gCombinList[gCurrentList.CombinCode].Weight = gCombinList[gCurrentList.CombinCode].Weight + tempTable.Weight

	end
	SetInDB(gCurrentList.CombinCode)
	SendIDtoUI()
	SendCombinList()
end
function SetInDB(CombinCode)	--�������ݿ������Ϣ
	Writelog("SetInDB")
	if gCombinList[CombinCode] and gCombinIssueList[CombinCode] then
		local temptime = os.date("%Y-%m-%d", os.time())
		local temp = {}
		temp.InventoryModelID = CombinCode
		temp.ModelCode = gCombinList[CombinCode].CombinCode
		temp.ModelDescription = gCombinList[CombinCode].CombinName
		temp.Owner = gUSERID
		temp.ReserveString = "0"	--˽��
		temp.BaseIndexCode = gCombinList[CombinCode].BaseIndexCode
		temp.CreateTime = temptime
		temp.TimeStamp = temptime
		if gCombinList[CombinCode].ChangeDate then
			local condition = string.format("InventoryModelID = '%s'",CombinCode)
			Modify(DB, condition, "InventoryHeader", temp)
			gCombinList[CombinCode].ChangeDate = temptime
		else
			gCombinList[CombinCode].ChangeDate = temptime
			Insert(DB, "InventoryHeader", temp)
		end

		for issue,info in pairs (gCombinIssueList[CombinCode]) do
			local inserTable = {}
			inserTable.InventoryModelID = CombinCode
			inserTable.InventoryOrderNo = info.Number
			inserTable.IssueCode = issue
			inserTable.Quantity = info.Qty
			inserTable.GeneralDouble1 = info.Weight
			inserTable.ReserveDouble2 = info.BaseWeight
			inserTable.CreateTime = temptime
			inserTable.TimeStamp = temptime
			if info.ChangeDate then
				local condition = string.format("InventoryModelID = '%s' and IssueCode = '%s'",CombinCode,issue)
				Modify(DB, condition, "InventoryOrder", inserTable)
				info.ChangeDate = temptime
			else
				info.ChangeDate = temptime
				Insert(DB, "InventoryOrder", inserTable)
			end
		end
	end
end
----------------
--��������߼�--
----------------
function ImportOut(arg)				--��������߼�
	Writelog("ImportOut")
	Writelog(serialize(arg))
	local text = arg.Data
	local Type = arg.Type
	local lines = getLines(text);
	local _ImportTable = {}
	for i, line in ipairs(lines) do
		local rtn = getNameAndValue(line);
		local issueCode = innerTrimAll(rtn[1]," ");
		local fundRate = innerTrimAll(rtn[2]," ");	--�ʽ����
		gLogs = string.format("in lines issueCode[%s],FundRate[%s]",issueCode,fundRate);
		Writelog(gLogs);
		if issueCode == "����" then
		else
			fundRate = tonumber(fundRate)
			if fundRate and fundRate > 0 then
				if issueCode and gIssueNameList[issueCode] then
					_ImportTable[issueCode] = fundRate;
				end
			end
		end
	end

	if Type == "1" then		--����
		for issue,v in pairs (_ImportTable) do
			if not gCurrentIssueList[issue] then
				gCurrentIssueList[issue] = {}
				gCurrentIssueList[issue].IssueCode = issue
				gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
				gCurrentIssueList[issue].Number = CreateNumber()
				gCurrentIssueList[issue].Weight = 0
				gCurrentIssueList[issue].BaseWeight = GetBaseWeight(issue) or 0
				if gPriceTable[issue] then
					gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
					gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
					gCurrentIssueList[issue].Status = gPriceTable[issue].Status
				else
					gCurrentIssueList[issue].LastPrice = GetPrice(issue).new or 0
					gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose or 0
					gCurrentIssueList[issue].Status = ""
					local temp = toObjID(issue)
					StartPrice(temp,"No5Market")
				end
				gCurrentIssueList[issue].Industry = gIndustryTable[issue] or "-"
				gCurrentIssueList[issue].Shares = GetissueShares(issue)
				gCurrentIssueList[issue].Capital = GetCapital(issue)
				gCurrentIssueList[issue].Value = gCurrentIssueList[issue].LastPrice * v
				gCurrentList.Number = gCurrentList.Number + 1
				gCurrentList.LastValue = gCurrentList.LastValue + gCurrentIssueList[issue].Value
			end
			gCurrentIssueList[issue].IsCheck = "1"
			gCurrentIssueList[issue].Qty = v
		end
	else
		--Ȩ��
		for issue,v in pairs (_ImportTable) do
			if not gCurrentIssueList[issue] then
				gCurrentIssueList[issue] = {}
				gCurrentIssueList[issue].IssueCode = issue
				gCurrentIssueList[issue].IssueName = gIssueNameList[issue]
				gCurrentIssueList[issue].Number = CreateNumber()
				gCurrentIssueList[issue].Qty = 0

				gCurrentIssueList[issue].BaseWeight = GetBaseWeight(issue) or 0
				if gPriceTable[issue] then
					gCurrentIssueList[issue].LastPrice = gPriceTable[issue].new
					gCurrentIssueList[issue].PrePrice = gPriceTable[issue].lastclose
					gCurrentIssueList[issue].Status = gPriceTable[issue].Status
				else
					gCurrentIssueList[issue].LastPrice = GetPrice(issue).new or 0
					gCurrentIssueList[issue].PrePrice = GetPrice(issue).lastclose or 0
					gCurrentIssueList[issue].Status = ""
					local temp = toObjID(issue)
					StartPrice(temp,"No5Market")
				end
				gCurrentIssueList[issue].Industry = gIndustryTable[issue] or "-"
				gCurrentIssueList[issue].Shares = GetissueShares(issue)
				gCurrentIssueList[issue].Capital = GetCapital(issue)
				gCurrentList.Number = gCurrentList.Number + 1
			end
			gCurrentIssueList[issue].IsCheck = "1"
			gCurrentIssueList[issue].Weight = v
		end
	end
	sendCrrentIssue("all")
	local lt = {}
	lt.CombinCode = gBeiXuanCombinCode
	OnSelectIndustryList(lt)
	SendInformation()
end

function getLines(text1)			--��ҵ�����߼�����
	Writelog("getLines(text) execute");
    local text = text1.."\n"
	Writelog(text);
	local lines = {}
	local len = string.len(text)
	local lineBegin = 1
	for i = 1, len do
		local chr = string.sub(text, i, i)
		if chr == "\n" then
			if lineBegin < i-2 then
				local line = string.sub(text, lineBegin, i-1)
				table.insert(lines, line)
			end
			lineBegin = i + 1;
		end
	end
	return lines
end

function getNameAndValue(line)
	local lin = line
	local logs = string.format("getNameAndValue line = [%s]",lin);
	Writelog(logs);

	local rtn = {}
	local len = string.len(line);
	local str = 1;
	for i = 1, len do
		local chr = string.sub(line, i, i)
		if chr == "," then
			table.insert(rtn, string.sub(line, str, i-1))
			str = i + 1;
		end
		if i == len then
			table.insert(rtn, string.sub(line,str, i))
		end
	end
	return rtn
end

function innerTrimAll(line, trimChar)
	local len1 = string.len(line);
	local rt = "";
	for i = 1, len1 do
		local chr = string.sub(line,i,i);
		if trimChar ~= chr then
			rt = rt .. chr;
		end
	end
	return rt;
end

----------------
--���¼����߼�--
----------------
RecalculateType = "1"			--1��ʾ�����¼��㣬2��ʾ�����¼���ȫ��
function Recalculate(arg)		--���¼���
	Writelog("Recalculate")
	if gCombinList[arg.CombinCode] and  gCombinIssueList[arg.CombinCode] then
		if RecalculateType == "1" then
			progressBar(0,"��ȡ��ʷ�۸�����")
		end
		local AnalDays = tonumber(gCombinList[arg.CombinCode].AnalDays)
		local index = GetBaseDateindex(arg.CombinCode)
		--��ȡ��Ϻ�Լ����
		GetklineTable(gCombinIssueList[arg.CombinCode])
		--����������
		local tempRate = CalculateModelEarnRate(index,AnalDays,gCombinIssueList[arg.CombinCode])
		--�������ϵ��
		local CC = CalculateCC(tempRate)
		--����������
		local warp = CalculateWarp(tempRate)
		--����Beta
		local Beta = CalculateBeta(tempRate,CC)
		--����Alpha
		local Alpha = CalculateAlpha(Beta,tempRate)
		if RecalculateType == "1" then
			progressBar(50)
		end

		gCombinList[arg.CombinCode].CC = string.format("%.04f",CC)
		gCombinList[arg.CombinCode].Warp = string.format("%.04f",warp)
		gCombinList[arg.CombinCode].Beta = string.format("%.04f",Beta)
		gCombinList[arg.CombinCode].Alpha = string.format("%.04f",Alpha)

		--������ҵ������
		GetIndustryInformation(index,AnalDays,arg.CombinCode)
		if RecalculateType == "1" then
			progressBar(60)
		end
		--�����������
		GetIssueInformation(index,AnalDays,arg.CombinCode)
		if RecalculateType == "1" then
			progressBar(65)
		end
		--������������ֵ��Ϣ
		SendCombinEvent(arg.CombinCode)

		--������϶�
		local temp = CalculateFit(arg.CombinCode)

		gCombinList[arg.CombinCode].Fit = string.format("%.02f",temp.Fit)
		gCombinList[arg.CombinCode].FitValue = string.format("%.02f",temp.FitValue)

		SendCurrentCombinList(arg.CombinCode)
		if _CurrentCombin == arg.CombinCode then
			SendIssueList()
			SendIndustryList()
		end
		if RecalculateType == "1" then
			progressBar(80,"ˢ��ͼ��")
		end
		gtCombinLine[arg.CombinCode] = {}
		--���¼������ͼ��
		reCalcCombin(arg.CombinCode)
		GetCalcCombinHistory(arg.CombinCode,gCombinList[arg.CombinCode].BaseDate)

		if RecalculateType == "1" then
			progressBar(100)
		end
	end
end
function GetklineTable(tablelist)				--��ȡ���ɺ�Լ��ʷ�۸�
	local sum = 0
	for issue,info in pairs (tablelist) do
		sum = sum + 1
	end
	local tempsum = 0
	for issuecode,info in pairs(tablelist)do
		--��ȡ��Լ��ʷ�۸��
		if not gKlineTable[issuecode] then
			gKlineTable[issuecode]={time={},close={}}
			local KlineTable = GetKLine(toObjID(issuecode), "1d", nil, nil, -_AnalDays, _AnalDays,1)
			--_WriteAplLog(serialize(KlineTable))
			if KlineTable and KlineTable.time then
				for i,v in pairs(KlineTable.time) do
					table.insert(gKlineTable[issuecode].time,string.sub(v,1,8))
					table.insert(gKlineTable[issuecode].close,KlineTable.close[i])
				end
			end
		end
		tempsum = tempsum + 1
		if sum > 0 and RecalculateType == "1" then
			local Bar = (tempsum/sum) * 50
			Bar = math.ceil(Bar)
			progressBar(Bar)
		end
	end
end
function GetBaseDateindex(CombinCode)
	local index = #gKlineindexTable.time
	local Time = gCombinList[CombinCode].BaseDate
	for i,k in pairs(gKlineindexTable.time)do
		if tonumber(Time) == tonumber(k) then
			index = i
		end
	end
	return index
end
function GetIssueInformation(index,AnalDays,CombinCode)		--�����������
	Writelog("GetIssueInformation")
	for issue,info in pairs (gCombinIssueList[CombinCode]) do
		local Table = {}
		Table[issue] = {}
		Table[issue].Qty = info.Qty
		--����������
		local tempRate = CalculateModelEarnRate(index,AnalDays,Table)
		--�������ϵ��
		local CC = CalculateCC(tempRate)
		--����������
		local warp = CalculateWarp(tempRate)
		--����Beta
		local Beta = CalculateBeta(tempRate,CC)
		--����Alpha
		local Alpha = CalculateAlpha(Beta,tempRate)
		--�����Լ��׼��ֵ
		local BaseValue = info.Qty*getPrice(issue,gCombinList[CombinCode].BaseDate)
		info.CC = string.format("%.04f",CC)
		info.Warp = string.format("%.04f",warp)
		info.Beta = string.format("%.04f",Beta)
		info.Alpha = string.format("%.04f",Alpha)
		info.BaseValue = BaseValue

	end
end
function GetIndustryInformation(index,AnalDays,CombinCode)	--������ҵ������
	Writelog("GetIndustryInformation")
	local Table = {}
	for issue,info in pairs (gCombinIssueList[CombinCode]) do
		local IndustryName = gIndustryTable[issue] or "-"
		if not Table[IndustryName] then  Table[IndustryName]= {} end
		if not Table[IndustryName][issue] then  Table[IndustryName][issue] = {} end
		Table[IndustryName][issue].Qty = info.Qty
	end
	for Industry,info in pairs (gCombinIndustryList[CombinCode]) do
		--����������
		local tempRate = CalculateModelEarnRate(index,AnalDays,Table[Industry])
		--�������ϵ��
		local CC = CalculateCC(tempRate)
		--����������
		local warp = CalculateWarp(tempRate)
		--����Beta
		local Beta = CalculateBeta(tempRate,CC)
		--����Alpha
		local Alpha = CalculateAlpha(Beta,tempRate)
		--������ҵȨ��
		if tonumber(gCombinList[CombinCode].Weight) > 0 then
		info.IndustryWeight = string.format("%.02f",tonumber(info.Weight) / tonumber(gCombinList[CombinCode].Weight) * 100)
		end
		--���Ȩ��
		if tonumber(gCombinList[CombinCode].BaseWeight) > 0 then
		info.IndustryBaseWeight = string.format("%.02f",tonumber(info.BaseWeight) / tonumber(gCombinList[CombinCode].BaseWeight) * 100)
		end
		info.CC = string.format("%.04f",CC)
		info.Warp = string.format("%.04f",warp)
		info.Beta = string.format("%.04f",Beta)
		info.Alpha = string.format("%.04f",Alpha)
	end
end
function CalculateModelEarnRate(index,AnalDays,Table)	--�������������
	Writelog("CalculateModelEarnRate")


	local ValueTable = {}
	local RateTable = {}

	--ͨ������300�������ݼ��������ֵ
	local first = index - AnalDays
	if first < 1 then first = 1 end
	for i=first,index do
		ValueTable[i] = 0
		for issue,info in pairs(Table)do
			local price = getPrice(issue,gKlineindexTable.time[i])
			ValueTable[i] = ValueTable[i] + info.Qty * price
		end
	end
	--Writelog(serialize(ValueTable))
	Writelog("RateTable")
	--�������������
	for i,v in pairs (ValueTable) do
		if ValueTable[i] and ValueTable[i-1] then
			if tonumber(ValueTable[i-1]) > 0 then
			RateTable[i] = tonumber(ValueTable[i])/tonumber(ValueTable[i-1]) -1
			else
			RateTable[i] = 0
			end
		end
	end
	Writelog(serialize(RateTable))
	return RateTable
end
function CalculateCC(RateTable)		--�������ϵ��
	Writelog("CalculateCC")
	local mdlSum = 0
	local idxSum = 0
	local mdl2Sum = 0
	local idx2Sum = 0
	local mulMdlIdxSum = 0
	local count = 0
	local cc = 0
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			mdlSum = mdlSum + v
			idxSum = idxSum + gKlineindexTable.Rate[i]
			mdl2Sum = mdl2Sum + v * v
			idx2Sum = idx2Sum + gKlineindexTable.Rate[i] * gKlineindexTable.Rate[i]
			mulMdlIdxSum = mulMdlIdxSum + v * gKlineindexTable.Rate[i]
		end
	end

	local deno = math.pow(count*mdl2Sum - mdlSum * mdlSum, 0.5) * math.pow(count*idx2Sum - idxSum*idxSum, 0.5)
	if deno ~= 0 then
		cc = (count*mulMdlIdxSum - mdlSum*idxSum) / deno * 100
	end
	local resultLogs = string.format("CalculateCC end cc=%s",cc)
	Writelog(resultLogs)
	return cc

end
function getPrice(issue,time)
	local Price = 0
	if gKlineTable[issue] then
		local Table = gKlineTable[issue]
		for i,k in pairs(Table.time)do
			if k <= time then
				Price = Table.close[i]
			end
		end
	else
		local log = string.format("��ȡ����[%s]����[%s]�ļ۸�",time,issue)
		Writelog(log)
	end
	return Price
end
function CalculateWarp(RateTable)	--����������
	local count = 0
	local earnSum = 0
	local warp = 0
	local warpTable = {}
	Writelog("CalculateWarp Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			table.insert(warpTable, v - gKlineindexTable.Rate[i])
			earnSum = earnSum + v - gKlineindexTable.Rate[i]
		end
	end
	Writelog("warpTable")
	if count ~= 0 then
		earnSum = earnSum / count
		for i =1, count do
			warp = warp + (warpTable[i] - earnSum) * (warpTable[i] - earnSum)
		end
		if count > 1 then
		warp  = math.pow(warp / (count-1), 0.5)
		else
		warp  = math.pow(warp, 0.5)
		end
	end
	local resultLogs = string.format("CalculateWarp end warp=%s",warp)
	Writelog(resultLogs)
	return warp * 100
end
function CalculateBeta(RateTable,CC)	--���㱴��ϵ��
	Writelog("CalculateBeta Start")
	local beta = 0
	local variance = CalculateVariance(RateTable)		--
	if variance ~= 0 then
		beta = CalculateCovariance(RateTable) / variance * CC / 100
	end

	local resultLogs = string.format("CalculateBeta end beta=%s",beta)
	Writelog(resultLogs)
	return beta;
end
function CalculateCovariance(RateTable)		--beta����
	local covariance = 0
	local average = 0
	local resultLogs = ""
	local targetmdlRate = {}
	local count = 0
	Writelog("CalculateCovariance Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			table.insert(targetmdlRate, v)
			average = average + v
		end
	end

	if count == 0 then
		return 0
	end
	resultLogs = string.format("CalculateCovariance  count=%d",count)
	Writelog(resultLogs)

	average = average / count

	for i = 1, count  do
		covariance = covariance + (targetmdlRate[i] - average) * (targetmdlRate[i] - average)
		resultLogs = string.format("CalculateCovariance num:%d variance=%f",i, covariance)
		Writelog(resultLogs)
	end
	covariance  = math.pow(covariance / count, 0.5)

	local resultLogs = string.format("CalculateCovariance end covariance=%s",covariance)
	Writelog(resultLogs)

	return covariance
end
function CalculateVariance(RateTable)		--beta��ĸ
	local count = 0
	local average = 0
	local variance = 0
	local targetModelEarnRate = {}
	local resultLogs = ""
	Writelog("CalculateVariance Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			table.insert(targetModelEarnRate, gKlineindexTable.Rate[i])
			average = average + gKlineindexTable.Rate[i]
		end
	end

	if count == 0 then
		return 0
	end
	resultLogs = string.format("CalculateVariance  count=%d",count)
	Writelog(resultLogs)

	average = average / count

	for i = 1, count  do
		variance = variance + (targetModelEarnRate[i] - average) * (targetModelEarnRate[i] - average)
		resultLogs = string.format("CalculateVariance num:%d variance=%f",i, variance)
		Writelog(resultLogs)
	end

	variance  = math.pow(variance / count, 0.5)
	resultLogs = string.format("CalculateVariance end variance=%s",variance)
	Writelog(resultLogs)
	return variance
end
function CalculateAlpha(beta,RateTable)		--����Alpha
	local averY = TotalModelEarnRate(RateTable).Average
	local averX = TotalIndexEarnRate(RateTable).Average
	return (averY - beta * averX) * 100
end
function TotalModelEarnRate(RateTable)--��������ʵĺ����ֵ
	local result = {}
	result.Total = 0
	result.Average = 0

	local count = 0
	Writelog("CalculateCovariance Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			result.Total = result.Total + v
		end
	end

	if count > 0 then
		result.Average = result.Total / count;
	end

	local resultLogs = string.format("TotalModelEarnRate end Total=%s, Aver=%s",result.Total, result.Average)
	Writelog(resultLogs)

	return result
end
function TotalIndexEarnRate(RateTable)--ָ�������ʵĺ����ֵ
	local result = {}
	result.Total = 0
	result.Average = 0
	local count = 0
	Writelog("TotalIndexEarnRate Start")
	for i,v in pairs(RateTable) do
		if gKlineindexTable.Rate[i] then
			count = count + 1
			result.Total = result.Total + gKlineindexTable.Rate[i]
		end
	end
	if count > 0 then
		result.Average = result.Total / count;
	end
	local resultLogs = string.format("TotalModelEarnRate end Total=%s, Aver=%s",result.Total, result.Average)
	Writelog(resultLogs)
	return result
end
function CalculateFit(CombinCode)			--��������Ŷ�
	Writelog("CalculateFix")
	local lt = {}
	local Value = tonumber(gCombinList[CombinCode].Price)  --����ּ�
	local BasePrice = 0
	if gPriceTable["M000300"] then
		BasePrice = tonumber(gPriceTable["M000300"].new)
	else
		BasePrice = tonumber(GetPrice("M000300").new)
	end
	lt.FitValue = Value - BasePrice
	if tonumber(lt.FitValue) > 0 then
		if BasePrice > 0 then
		lt.Fit =(BasePrice - lt.FitValue) / BasePrice * 100
		else
		lt.Fit = 0
		end
	else
		if BasePrice > 0 then
		lt.Fit =(BasePrice + lt.FitValue) / BasePrice * 100
		else
		lt.Fit = 0
		end
	end
	return lt
end
function RecalculateAll(arg)		--���¼�������
	Writelog("RecalculateAll")
	RecalculateType = "2"
	progressBar(0)
	local sum = 0
	for CombinCode,info in pairs (gCombinList) do
		if info.BaseIndexCode == "M000300" then
			sum = sum + 1
		end
	end
	local tempsum = 0
	for CombinCode,info in pairs (gCombinList) do
		if info.BaseIndexCode == "M000300" then
			tempsum = tempsum + 1
			if sum > 0 then
				local Bar = (tempsum/sum) * 100
				Bar = math.ceil(Bar)
				local log = info.CombinName .. " ������..."
				progressBar(Bar,log)
			end
			local temp = {}
			temp.CombinCode = CombinCode
			Recalculate(temp)
		end
	end
	--reDealAllCombinLine()--���¼����������������
	RecalculateType = "1"
end

------------------------
--��ָ�ڻ���ʱͼ�߼���--
------------------------
gKlineTableForIF = {}   --��ָ�ڻ��۸��
gCurrentFutureIssue = "" --��ǰѡ�еĹ�ָ�ڻ���Լ
gIssueTableForIF = {} --��ָ�ڻ���Լ��
gIndexForIF = {} -- ��ָ��Լ��ţ�1������ 2������ 3������ 4������
gBaseTime = {} --��ָ�ڻ�ʱ���׼��
function getDataForIF() --��ȡ��ָ�ڻ�k������
	--��ȡ��ָ�ڻ��ĵ��¡����¡����º͸�����Լ��Ϣ
	local nowDate = os.date("%Y%m%d");
	local nowTime = os.date("%Y%m%d%H%M".."00");
	local issueMasterCondition = "ExpirationDate >= '"..nowDate.."' and UnderlyingAssetCode = 'IF' and ProductCode = '31' and IssueCode IN (select IssueCode from IssueMarketTable where MarketCode = '3' and ListedDate <= '"..nowDate.."') ORDER BY IssueCode";
	local IFinfo = Get(DB,issueMasterCondition, "IssueMaster")
	local issueTableForIF = IFinfo["IssueCode"]
	--�������ӻ���300��Լ
	table.insert(issueTableForIF,"M000300")
	--ʹ��������Լ���ʱ���׼
	local lastTradingDay = getLastTradingDay()
	Writelog("lastTradingDay: ".. lastTradingDay)
	--local klineData = GetKLine("SFIF0001.cmdty", "1m",lastTradingDay,nowDate)
	--[[for i,time in pairs(klineData.time) do
		local subTime = string.sub(time,9,-1)
		local strTime = nowDate .. subTime
		table.insert(gBaseTime,strTime)
	end]]

	local k1Min = initk1Min()
	for i,time in ipairs(k1Min) do
		local strTime = nowDate .. time
		table.insert(gBaseTime,strTime)
	end

	Writelog(serialize(gBaseTime))
	--���ɺ�Լ���ݱ�
	for i,issue in pairs(issueTableForIF) do
		gIssueTableForIF[issue] = issue
		gIndexForIF[issue] = i
		if not gKlineTableForIF[issue] then
			--��ȡ������ʷ��ָ�ڻ�����������
			getHistoryData(issue,i)
			--���Ĺ�ָ�ڻ�����
			StartPrice(toObjID(issue),"No5Market")
		end
	end
	Writelog(serialize(gKlineTableForIF))
	Writelog(serialize(gIssueTableForIF))
	table.remove(issueTableForIF) --�Ƴ�M000300�������ָ��������ʾ
	SendToUIScript('SendFutureIssue', issueTableForIF)
end
function getHistoryData(issueCode,index) --��ȡ������ʷ��ָ�ڻ�����������
	local nowDate = os.date("%Y%m%d");
	local nowTime = os.date("%Y%m%d%H%M".."00");
	gKlineTableForIF[issueCode] = {time = {},close = {},volume = {},issueCode = {}} --���������
	--��ȡ������ʷ1����k��
	local klineData = GetKLine(toObjID(issueCode), "1m",nowDate,nowTime)
	_WriteAplLog("getHistoryData:"..issueCode..";index"..index)
	_WriteAplLog(serialize(klineData))
	if klineData.time then
		if type(klineData.time) == "table" then
			local j = 1;
			for i,time in pairs(klineData.time) do
				if issueCode ~= "M000300" then
					while time > gBaseTime[j] do
						table.insert(gKlineTableForIF[issueCode].time,gBaseTime[j])
						if i > 1 then
							table.insert(gKlineTableForIF[issueCode].close,klineData.close[i-1])
						else
							local lastClose = getLastClose(issueCode,index)
							if lastClose then
								table.insert(gKlineTableForIF[issueCode].close,lastClose)
							else
								table.insert(gKlineTableForIF[issueCode].close,"-")
								local logs = string.format("δ��ȡ��[%s]�����ռ�",issueCode)
								Writelog(logs)
							end
						end
						table.insert(gKlineTableForIF[issueCode].volume,0)
						table.insert(gKlineTableForIF[issueCode].issueCode,issueCode)
						j = j + 1
					end
				end
				table.insert(gKlineTableForIF[issueCode].time,time)
				table.insert(gKlineTableForIF[issueCode].close,klineData.close[i])
				table.insert(gKlineTableForIF[issueCode].volume,klineData.volume[i])
				table.insert(gKlineTableForIF[issueCode].issueCode,issueCode)
				j = j + 1
			end
		end
	end
end

function initk1Min()	--��ʼ�����ӽ���ʱ��
	local str =""
	local k1Min = {}
	-- 0916-0959
	for a1 =16,59 do
		str = string.format("09%s00",a1)
		table.insert(k1Min,str)
	end

	-- 1000-1059
	for a2 =0,59 do
		if a2<10 then
			str = string.format("100%s00",a2)
		else
			str = string.format("10%s00",a2)
		end
		table.insert( k1Min,str)
	end

	-- 1100-1130
	for a3 =0,30 do
		if a3<10 then
			str = string.format("110%s00",a3)
		else
			str = string.format("11%s00",a3)
		end
		table.insert(k1Min,str)
	end

	-- 1301-1359
	for a4 =1,59 do
		if a4<10 then
			str = string.format("130%s00",a4)
		else
			str = string.format("13%s00",a4)
		end
		table.insert( k1Min,str)
	end

	-- 1400-1459
	for a5 =0,59 do
		if a5<10 then
			str = string.format("140%s00",a5)
		else
			str = string.format("14%s00",a5)
		end
		table.insert( k1Min,str)
	end

	-- 1500-1515
	for a6 =0,15 do
		if a6<10 then
			str = string.format("150%s00",a6)
		else
			str = string.format("15%s00",a6)
		end
		table.insert( k1Min,str)
	end
	return k1Min
end




function getLastClose(issueCode,index) --ȡ���ռ�
	local nowDate = os.date("%Y%m%d");
	local objID;
	if string.sub(issueCode,1,2) == "IF" then
		if index then
			if index == 1 then
				objID = "SFIF0001.cmdty" --����������Լ
			elseif index == 2 then
				objID = "SFIF0002.cmdty" --����������Լ
			elseif index == 3 then
				objID = "SFIF0003.cmdty" --����������Լ
			elseif index == 4 then
				objID = "SFIF0004.cmdty" --����������Լ
			end
		end
	else
		objID = toObjID(issueCode)
	end
	local klineData = GetKLine(objID,"1m",nil,nowDate,-1,1)
	local lastClose = klineData.close[1]
	return lastClose
end
function getLastTradingDay() --��ȡ��һ��������
	local nowDate = os.date("%Y%m%d");
	local klineData = GetKLine(toObjID("M000300"), "1d",nil,nowDate,-1,1)
	local lastTradingDay = klineData.time[1]
	return lastTradingDay
end

function OnSelectFutureIssue(arg) --�л���ָ��Լ�ص�
	local log = "select".. " " .. arg.FutureIssue
	Writelog(log)
	local futureIssue = arg.FutureIssue
	if futureIssue and futureIssue ~= "" then
		gCurrentFutureIssue = futureIssue
		showFutureGraph(futureIssue)
	end
end
function OnRecalculate(arg) --�ӻ�ȡ��ʷk��������ʾ��ָ�ڻ���ʱͼ
	local log = "recalculate target:".. arg.FutureIssue
	Writelog(log)
	local futureIssue = arg.FutureIssue
	if futureIssue and futureIssue ~= "" then
		gCurrentFutureIssue = futureIssue
		getHistoryData(futureIssue)
		showFutureGraph(futureIssue)
	end
end
function showFutureGraph(futureIssue) --��ʾ��ָ�ڻ���ʱͼ
	local DataForShow = gKlineTableForIF[futureIssue]
	Writelog(serialize(DataForShow))
	SendToUI('FutureCloseGraph',DataForShow)
	SendToUI('FutureVolumeGraph',DataForShow)
end

--------------------
--GetKLine��Ȩ����--
--------------------
gRightsChangeData = {}

--����LAPI��ȡ����ɷֺ�ȳ�Ȩ��Ϣ
--@param objID  Ҫ��Ȩ�Ķ��󣬸�ʽΪ��SH600000.stk
function getchuquan(objID)
	if gRightsChangeData[objID] then
		t_chuquan = gRightsChangeData[objID]
		return
	end

	local issueCode = getIssueCode(objID)

	local rData = Get(DB,"IssueCode = '" .. tostring(issueCode) .. "'", "RightsChange")
	--_WriteAplLog(serialize(rData))
	local ret = {}
	if rData and rData.RightsChangeDate then
		for i, rDate in ipairs(rData.RightsChangeDate) do
			local t = {time="",peigujia=0,peigushu=0,songgushu=0,fenhong=0,zongguben=0,xishu=0}
			t.time = tostring(rData.RightsChangeDate[i] .."000000")
			t.peigujia = 0
			t.peigushu = 0
			t.songgushu = rData.Numerator[i] / rData.Denominator[i] - 1
			t.fenhong = tonumber(rData.Dividend[i]) or 0
			t.zongguben = t.peigushu + t.songgushu
			t.xishu = 1
			table.insert(ret,t)
		end
	end
	t_chuquan = ret
--	_WriteAplLog(serialize(t_chuquan))
	gRightsChangeData[objID] = ret
end

--���Ӿ���
--@param objID  Ҫ��Ȩ�Ķ��󣬸�ʽΪ��SH600000.stk
--@param lt    K������table
function igetprice(objID,lt)
	if not lt then return nil end
	if not lt.time then return nil end

	lt.average = {}
	for seq=1, #lt.time do
		--lt.average[seq] = lt.amount[seq]/lt.volume[seq]/100
		lt.average[seq] = lt.amount[seq]/lt.volume[seq]   -- ���ݿ����volume�ǹ�������������
	end
	t_price = lt
end

-------------
--��Ȩ
--@param objID  Ҫ��Ȩ�Ķ��󣬸�ʽΪ��SH600000.stk
--@param lt    K������table
--@param settings   ��Ȩѡ���ʽΪtable {forward = nil,back=1,dengbi=nil,withvol=1}  nil������ѡ�У�������ʾѡ��
function fuquan(objID,lt, settings)
	igetprice(objID,lt)
	getchuquan(objID)
	local ret = do_fuquan(objID, settings)
	return ret
end


--��Ȩ������
--@param objID  Ҫ��Ȩ�Ķ��󣬸�ʽΪ��SH600000.stk
--@param settings   ��Ȩѡ���ʽΪtable {forward = nil,back=1,dengbi=nil,withvol=1}  nil������ѡ�У�������ʾѡ��
function do_fuquan(objID,settings)
	if not t_price or not t_chuquan then return nil end

	local ret={}
	if settings.back and settings.dengbi  then
		ret = do_xianghoudengbi_fuquan(settings.withvol)
	elseif settings.back == nil and settings.dengbi then
		ret = do_dengbi_fuquan(settings.withvol)
	elseif settings.back and settings.dengbi==nil then
		ret = do_xianghou_fuquan(settings.withvol)
	elseif settings.back == nil and settings.dengbi==nil then
		if settings.forward == nil and settings.withvol == nil then
			return t_price
		end
		ret = do_default_fuquan(settings.withvol)
	end

	ret.average = nil
	return ret

end

--Ĭ�ϸ�Ȩ
--@param with_volume  �ɽ��������� nilΪ������������Ϊ����
function do_default_fuquan(with_volume)
	local ret = t_price
	for seq1,t1 in pairs(t_chuquan) do
		for seq=1,table.getn(ret.time) do
			local t={time="",open=0,close=0,high=0,low=0,volume=0,amount=0,average=0}
			t.time = ret.time[seq]
			t.open = ret.open[seq]
			t.close = ret.close[seq]
			t.high = ret.high[seq]
			t.low = ret.low [seq]
			t.volume = ret.volume[seq]
			t.amount = ret.amount[seq]
			t.average = ret.average[seq]
			if t.time<t1.time then
				local newprice = qianfuquan(t,t1,with_volume)
				ret.open[seq] = newprice.open
				ret.close[seq] = newprice.close
				ret.high[seq] = newprice.high
				ret.low[seq] = newprice.low
				ret.average[seq] = newprice.average
				ret.volume[seq] = newprice.volume
				ret.amount[seq] = newprice.amount
			end
		end
	end
	return ret
end

--ǰ��Ȩ
--@param price  ��Ȩǰ��ĳһ��K�ߵļ۸�
--@param chuquan  ĳһ�յĳ�Ȩ��Ϣ
--@param with_volume  �ɽ����������
function qianfuquan(price,chuquan,with_volume)
	local ret = {open=0,close=0,high=0,low=0,volume=0,amount=0,average=0}
	for key,value in pairs(price) do
		if key == "open" or key=="close" or key=="high" or key=="low" or key=="average" then
			local newvalue = (value-chuquan.fenhong+chuquan.peigujia*chuquan.peigushu)/(1+chuquan.songgushu+chuquan.peigushu)
			ret[key] = newvalue
		else
			ret[key] = value
		end
	end
	if with_volume then
		ret.volume = price.volume*(1+chuquan.zongguben)
		--ret.amount = ret.volume*price.average*100
		ret.amount = ret.volume*ret.average
	end

	return  ret
end

--���Ȩ
--@param with_volume  �ɽ��������� nilΪ������������Ϊ����
function do_xianghou_fuquan(with_volume)
	local ret = t_price
	for seq1=table.getn(t_chuquan),1,-1 do
		local t1 = t_chuquan[seq1]
		for seq=table.getn(ret.time),1,-1 do
			local t={time="",open=0,close=0,high=0,low=0,volume=0,amount=0,average=0}
			t.time = ret.time[seq]
			t.open = ret.open[seq]
			t.close = ret.close[seq]
			t.high = ret.high[seq]
			t.low = ret.low [seq]
			t.volume = ret.volume[seq]
			t.amount = ret.amount[seq]
			t.average = ret.average[seq]
			if t.time>=t1.time then
				local newprice = houfuquan(t,t1,with_volume)
				ret.open[seq] = newprice.open
				ret.close[seq] = newprice.close
				ret.high[seq] = newprice.high
				ret.low[seq] = newprice.low
				ret.average[seq] = newprice.average
				ret.volume[seq] = newprice.volume
				ret.amount[seq] = newprice.amount
			end
		end
	end
	return ret
end

--��Ȩ
--@param price  ��Ȩǰ��ĳһ��K�ߵļ۸�
--@param chuquan  ĳһ�յĳ�Ȩ��Ϣ
--@param with_volume  �ɽ����������
function houfuquan(price,chuquan,with_volume)
	local ret = {open=0,close=0,high=0,low=0,volume=0,amount=0,average=0}
	for key,value in pairs(price) do
		if key == "open" or key=="close" or key=="high" or key=="low" or key=="average" then
			local newvalue = value*(1+chuquan.songgushu+chuquan.peigushu) - chuquan.peigujia*chuquan.peigushu+chuquan.fenhong
			ret[key] = newvalue
		else
			ret[key] = value
		end
	end
	if with_volume then
		ret.volume = price.volume/(1+chuquan.zongguben)
		--ret.amount = ret.volume*price.average*100
		ret.amount = ret.volume*ret.average
	end

	return  ret
end

--�ȱȸ�Ȩ
--@param with_volume  �ɽ��������� nilΪ������������Ϊ����
function do_dengbi_fuquan(with_volume)
	local t_xishu = t_chuquan
	local ret = t_price
	for seq=1,table.getn(ret.time) do
		local t={}
		t.time = ret.time[seq]
		t.open = ret.open[seq]
		t.close = ret.close[seq]
		t.high = ret.high[seq]
		t.low = ret.low [seq]
		t.volume = ret.volume[seq]
		t.amount = ret.amount[seq]
		t.average = ret.average[seq]
		for seq1,xishu in pairs(t_xishu) do
			if xishu.time>=t.time then
				local newprice = dengbifuquan(t,xishu,with_volume)
				t = newprice
			end
		end
		ret.open[seq] = t.open
		ret.close[seq] = t.close
		ret.high[seq] = t.high
		ret.low[seq] = t.low
		ret.average[seq] = t.average
		ret.volume[seq] = t.volume
--		ret.amount[seq] = t.amount
	end
	return ret
end

--�ȱȸ�Ȩ
--@param price  ��Ȩǰ��ĳһ��K�ߵļ۸�
--@param chuquan  ĳһ�յĳ�Ȩ��Ϣ
--@param with_volume  �ɽ����������
function dengbifuquan(price,xishu,with_volume)
	local ret = {open=0,close=0,high=0,low=0,volume=0,average=0}
	for key,value in pairs(price) do
		if key == "open" or key=="close" or key=="high" or key=="low" or key=="average" then
			ret[key] = value*xishu.xishu
		else
			ret[key] = value
		end
	end
	if with_volume then
		ret.volume = price.volume/xishu.xishu
		--ret.amount = ret.volume*ret.average -- ��Ϊ������ޱ仯�����Բ��ü���
	end
	return  ret
end

--���ȱȸ�Ȩ
--@param with_volume  �ɽ��������� nilΪ������������Ϊ����
function do_xianghoudengbi_fuquan(with_volume)
	t_xishu = t_chuquan
	local ret = t_price
	for seq=1,table.getn(ret.time) do
		local t = {time="",open=0,close=0,high=0,low=0,volume=0,amount=0,average=0}
		t.time = ret.time[seq]
		t.open = ret.open[seq]
		t.close = ret.close[seq]
		t.high = ret.high[seq]
		t.low = ret.low [seq]
		t.volume = ret.volume[seq]
		t.amount = ret.amount[seq]
		t.average = ret.average[seq]
		for seq1,xishu in pairs(t_xishu) do
			if xishu.time<=t.time then
				local newprice = xianghoudengbifuquan(t,xishu,with_volume)
				t = newprice
			end
		end
		ret.open[seq] = t.open
		ret.close[seq] = t.close
		ret.high[seq] = t.high
		ret.low[seq] = t.low
		ret.average[seq] = t.average
		ret.volume[seq] = t.volume
--		ret.amount[seq] = t.amount
	end
	return ret
end

--���ȱȸ�Ȩ
--@param price  ��Ȩǰ��ĳһ��K�ߵļ۸�
--@param chuquan  ĳһ�յĳ�Ȩ��Ϣ
--@param with_volume  �ɽ����������
function xianghoudengbifuquan(price,xishu,with_volume)
	local ret = {open=0,close=0,high=0,low=0,volume=0,average=0}
	for key,value in pairs(price) do
		if key == "open" or key=="close" or key=="high" or key=="low" or key=="average" then
			ret[key] = value/xishu.xishu
		else
			ret[key] = value
		end
	end
	if with_volume then
		ret.volume = price.volume*xishu.xishu
		--ret.amount = ret.volume*ret.average
	end
	return  ret
end

---��Ȩ
-- @param objID ������롣��SH600000.stk
-- @param ret  K������table
-- @param split  ��Ȩѡ��
function DoFuquan(objID,ret,split)
	if split == nil or split <= 0 then return ret end

	local settings = {}
	if split == 1 then
		settings.forward = 1
	elseif split == 2 then
		settings.back = 1
	elseif split == 3 then
		settings.dengbi = 1
	elseif split == 4 then
		settings.foward = 1
		settings.withvol = 1
	elseif split == 5 then
		settings.back = 1
		settings.withvol = 1
	elseif split == 6 then
		settings.dengbi = 1
		settings.withvol = 1
	elseif split == 7 then
		settings.back = 1
		settings.dengbi = 1
	elseif split == 8 then
		settings.back = 1
		settings.dengbi = 1
		settings.withvol = 1
	end

	return fuquan(objID, ret,settings)
end
--*********************************************************
--��ʼ�Ż��Ի������ش���
--*********************************************************
local lastValueList = {}
local matlabret = _StartMATLAB()
if not matlabret then
	ExportMatlabError()
end

function ExportMatlabError()
	local error_string=_getErrorMsg()
	_WriteAplLog("Matlab Error="..error_string)
end

function GetLongerIndex300Table( timeLength )
	local retIndexTable = {time={},close={},Rate={}}		--ָ���۸��
	local tempKLine = GetKLine("SH000300.index", "1d", nil, nil, -timeLength, timeLength)

	for i,v in pairs(tempKLine.time) do
		table.insert( retIndexTable.time, string.sub(v,1,8))
		table.insert( retIndexTable.close, tempKLine.close[i])
		if tempKLine.close[i] and tempKLine.close[i-1] then
			if tonumber( tempKLine.close[i-1] ) > 0 then
				retIndexTable.Rate[i] = tonumber(tempKLine.close[i])/tonumber(tempKLine.close[i-1]) -1
			else
				retIndexTable.Rate[i] = 0
			end
		end
	end
	return retIndexTable
end

function GetAllKLineForMatlab( codeList, timeLength, lastCloseList )
	--_WriteAplLog("GetAllKLineForMatlab")
	--_WriteAplLog(timeLength)
	local allKLines = {}
	for objID, v in pairs(codeList)do
		local oneKLine = {}
		local aLine = GetKLine(objID, "1d", nil, nil, -timeLength, timeLength, 1)
		for i,v in pairs( aLine.time ) do
			local curDate = string.sub(v,1,8)
			if aLine.close[i] and aLine.close[i-1] then
				oneKLine[curDate] = tonumber(aLine.close[i])/ tonumber(aLine.close[i-1]) -1
			else
				oneKLine[curDate] = 0
			end
			lastClose = aLine.close[i]
		end
		allKLines[objID] = oneKLine
		--_WriteAplLog(serialize(oneKLine))
		table.insert( lastCloseList, lastClose )
	end
	return allKLines
end

function GetPortfolioListForMatlab()
	local portfolioList = gCombinIssueList[_CurrentCombin]
	if not portfolioList then
		local log = "����ѡ��ϣ���Ż������"
		SendToUIScript("OptimizeError",log)
		return nil
	end
	Writelog( "_CurrentCombin=".._CurrentCombin.." and "..serialize(portfolioList) )
	return portfolioList
end

function CreateMatlabOneRow( codeList, curDate, srcTable )
	local newDayList = {}
	for objID, v in pairs(codeList)do
		if not srcTable[objID][curDate] then
			table.insert(newDayList, 0)
		else
			table.insert(newDayList, srcTable[objID][curDate])
		end
	end
	return newDayList
end

function GetPortfolioListMatlab(arg)
	local portfolioList = GetPortfolioListForMatlab()
	if not portfolioList then
		return
	end

	local codeInfoList = {}
	for code,info in pairs(portfolioList)do
		local objID = toObjID(code)
		codeInfoList[code] = {}
		codeInfoList[code].Status = gPriceTable[code].Status
		codeInfoList[code].Market = getMarketCode(objID)
		codeInfoList[code].IssueName = info["IssueName"]
		codeInfoList[code].Qty = info["Qty"] or 0
		codeInfoList[code].BaseWeight = info["BaseWeight"]
		codeInfoList[code].Industry = info["Industry"]
		codeInfoList[code].Number = info["Number"]
	end
	local resultArr = {}
	resultArr.portfolioList = codeInfoList
	SendToUIScript("OptimizeReady",resultArr)
end

function CalMatlabOptimizeValue(arg)
	local path=os.getenv("DTS_DATA")
	path=path.."/StrategyList/OptimizeFile/"
	Writelog("Matlab file path "..path)
	assert(_MATLABAddPath(path))

	local portfolioList = GetPortfolioListForMatlab()
	if not portfolioList then
		return
	end

	local curObjIDList = {}
	local codeInfoList = {}
	local stockNumber = 0
	for code,info in pairs(portfolioList)do
		stockNumber = stockNumber + 1
		local objID = toObjID(code)
		curObjIDList[objID] = code
		codeInfoList[code] = {}
		codeInfoList[code].Status = gPriceTable[code].Status
		codeInfoList[code].Market = getMarketCode(objID)
		codeInfoList[code].IssueName = info["IssueName"]
		codeInfoList[code].Qty = info["Qty"] or 0
		codeInfoList[code].BaseWeight = info["BaseWeight"]
		codeInfoList[code].Industry = info["Industry"]
		codeInfoList[code].Number = info["Number"]
	end

	Writelog( "_CombinCode=".._CurrentCombin.." and "..serialize(curObjIDList) )
	local EXTRA_DAY_NUMBER = 2 --����Ϊ��ȷ���������ڹ�Ʊ������һ�������죬����Ϊ��ȷ����һ����Ч�����ʲ�Ϊ0���ټӸ������졣���Զ�����Ҫ2��
	local price = {}

	local days = tonumber(gCombinList[_CurrentCombin].AnalDays)
	--_WriteAplLog("days")
	if days <= stockNumber - EXTRA_DAY_NUMBER then
		days = stockNumber + EXTRA_DAY_NUMBER
	end
	--Writelog(days)
	local allKLines = GetAllKLineForMatlab( curObjIDList, days, price )

	local holdings = {}
	local totalVol = 0
	for objID, code in pairs(curObjIDList)do
		local volume = codeInfoList[code].Qty or 0
		totalVol = totalVol + volume
		table.insert( holdings, {volume} )
	end

	if totalVol == 0 then
		SendToUIScript("OptimizeError", "�Բ��𣬸���ϵ������������㣬�޷��Ż���")
		return
	end

	local in_ret = {}
	local st_ret = {}
	local lastDate = 0
	local begNo = _AnalDays-days+1
	local endNo = _AnalDays
	local index300Table =  gKlineindexTable
	if _AnalDays <= days then
		begNo = EXTRA_DAY_NUMBER
		endNo = days
		index300Table = GetLongerIndex300Table(days)
	end
	--_WriteAplLog("begNo-endNo")
	--_WriteAplLog(begNo)
	--_WriteAplLog(endNo)
	for i= begNo, endNo do
		local curIFVal = index300Table.Rate[i] or 0
		local new_ele = {curIFVal}
		table.insert( in_ret, new_ele)
		local curDate =  index300Table.time[i]
		--_WriteAplLog(curDate)
		table.insert(st_ret, CreateMatlabOneRow( curObjIDList, curDate, allKLines) )
		lastDate = curDate
	end
	Writelog("Matlab �����ʱ�:")
	Writelog(serialize(in_ret))
	Writelog(serialize(st_ret))

	if 1 ~= _SetMATLABVar('in_ret', in_ret) then
		ExportMatlabError()
		SendToUIScript("OptimizeError", "�޷��Ż������ʵ�ڻ��������ʡ�" )
		return
	end

	if 1 ~= _SetMATLABVar('holdings', holdings) then
		ExportMatlabError()
		SendToUIScript("OptimizeError", "�޷��Ż������ʵ����ϵ�����������" )
		return
	end

	if 1 ~= _SetMATLABVar('st_ret', st_ret) then
		ExportMatlabError()
		SendToUIScript("OptimizeError", "�޷��Ż������ʵ����ϵ������ʡ�" )
		return
	end

	if 1 ~= _SetMATLABVar('price', price) then
		ExportMatlabError()
		SendToUIScript("OptimizeError", "�޷��Ż������ʵ����ϵ����̼ۡ�" )
		return
	end

	local destAction = 'main_cor'
	if "TE" == arg.state then
		destAction = 'main_te'
	end

	if false==_MATLABDoFile(destAction) then--ע�ⲻҪ������׺".m"
		ExportMatlabError()
		SendToUIScript("OptimizeError", "�޷��Ż��������Ż��㷨��" )
		return
	end

	local resultArr = {}
	resultArr.rho = _GetMATLABVar('rho')
	resultArr.tr_err = _GetMATLABVar('tr_err')
	resultArr.alpha = _GetMATLABVar('alpha')
	resultArr.beta = _GetMATLABVar('beta')
	resultArr.adj_rho = _GetMATLABVar('adj_rho')
	resultArr.adj_tr_err = _GetMATLABVar('adj_tr_err')
	resultArr.adj_alpha = _GetMATLABVar('adj_alpha')
	resultArr.adj_beta = _GetMATLABVar('adj_beta')
	resultArr.portfolioList = codeInfoList

	local adj_holdings = _GetMATLABVar('adj_holdings')
	local adj_w = _GetMATLABVar('adj_w')
	local counter = 1
	lastValueList[_CurrentCombin] = {}
	for objID, code in pairs(curObjIDList)do
		lastValueList[_CurrentCombin][code] = {}
		if type(adj_holdings) == "number" then
			codeInfoList[code].NewQty = adj_holdings
			lastValueList[_CurrentCombin][code].NewQty = adj_holdings
		else
			codeInfoList[code].NewQty = adj_holdings[counter][1]
			lastValueList[_CurrentCombin][code].NewQty = adj_holdings[counter][1]
		end

		if type(adj_w) == "number" then
			lastValueList[_CurrentCombin][code].NewWeight = adj_w * 100
		else
			lastValueList[_CurrentCombin][code].NewWeight = adj_w[counter][1] * 100
		end
		counter = counter + 1
	end
	if gCombinList[_CurrentCombin] then
		gCombinList[_CurrentCombin].CC = string.format("%.04f",resultArr.rho*100)
		gCombinList[_CurrentCombin].Warp = string.format("%.04f",resultArr.tr_err*100)
		gCombinList[_CurrentCombin].Beta = string.format("%.04f",resultArr.beta)
		gCombinList[_CurrentCombin].Alpha = string.format("%.04f",resultArr.alpha * 100)
		gCombinList[_CurrentCombin].adj_CC = string.format("%.04f",resultArr.adj_rho*100)
		gCombinList[_CurrentCombin].adj_Warp = string.format("%.04f",resultArr.adj_tr_err*100)
		gCombinList[_CurrentCombin].adj_Beta = string.format("%.04f",resultArr.adj_beta)
		gCombinList[_CurrentCombin].adj_Alpha = string.format("%.04f",resultArr.adj_alpha * 100)
		SendCurrentCombinList(_CurrentCombin)
	end
	SendToUIScript("OptimizeResult",resultArr)
end

function SetMatlab2DB(arg)
	local portfolioList = GetPortfolioListForMatlab()
	if not portfolioList then
		return
	end

	if not  lastValueList[_CurrentCombin] then
		SendToUIScript("OptimizeError", "�����Ż�����ϣ�Ȼ������滻��")
		return
	end

	for code,info in pairs(portfolioList) do
		--local log = "Qty="..info.Qty..";NewQty="..lastValueList[_CurrentCombin][code].NewQty
		--log = log..";Weight="..info.Weight..";NewWeight="..lastValueList[_CurrentCombin][code].NewWeight
		--SendToUIScript("OptimizeError", log)
		info.Qty = lastValueList[_CurrentCombin][code].NewQty
		info.Weight = string.format("%.2f",lastValueList[_CurrentCombin][code].NewWeight)
	end
	if gCombinList[_CurrentCombin] then
		gCombinList[_CurrentCombin].CC = gCombinList[_CurrentCombin].adj_CC or gCombinList[_CurrentCombin].CC
		gCombinList[_CurrentCombin].Warp = gCombinList[_CurrentCombin].adj_Warp or gCombinList[_CurrentCombin].Warp
		gCombinList[_CurrentCombin].Beta = gCombinList[_CurrentCombin].adj_Beta or gCombinList[_CurrentCombin].Beta
		gCombinList[_CurrentCombin].Alpha = gCombinList[_CurrentCombin].adj_Alpha or gCombinList[_CurrentCombin].Alpha
	end
	SetInDB(_CurrentCombin)
	SendCurrentCombinList(_CurrentCombin)
	SendToUIScript("OptimizeDone", _CurrentCombin.."��������Ȩ���ѱ��滻")
end
--*********************************************************
--�����Ż��Ի������ش���
--*********************************************************
---------------------------------------------------------------------------------------
------------------------------������Ʒ���ͼ-------------------------------------------
---------------------------------------------------------------------------------------
gtCombinLine = {} --�洢��
gtIssueTable = {} --��׼�����̼�
gTimeRecordTable = {} --��¼����ʱ��
gtTimeStdTable = nil --M000300ʱ���¼
gRecordTime = nil --��¼ʱ��
gtActiveTable = {} --��ϼ���
function getHistoricalData(issueCode)--��ȡָ����Ʊ������ʷ����
	Writelog("getHistoricalData:"..issueCode)
	local today = GetDate()
	local nowTime = GetTime()
	local nowDateTime = today..string.sub(nowTime,1,4).."00"
	local startTime = today
	if not gtIssueTable[issueCode] then
		gtIssueTable[issueCode] = {}
	end
	if not gTimeRecordTable[issueCode]  then
		startTime = today .. "083000"

	else
		startTime = string.sub(gTimeRecordTable[issueCode],1,12).."00"
		if tonumber(string.sub(nowTime,1,4)) > 1505 and tonumber(string.sub(gTimeRecordTable[issueCode],9,12)) == 1500 then
			return
		end
	end

	local endTime = today .."170000"

	local KlineTable = GetKLine(toObjID(issueCode), "1m",startTime,endTime)
	--_WriteAplLog(serialize(KlineTable))
	if KlineTable.time then
		if type(KlineTable.time) == "table" then
			for i,time in pairs(KlineTable.time) do
				local log = string.format("getHistoricalData : nowDateTime = %s,IssueCode = %s, time = %s,price = %s,volume = %s",nowDateTime,issueCode,string.sub(time,1,14),KlineTable.close[i],KlineTable.volume[i])
				Writelog(log)
				local datetime = string.sub(time,1,14)
				if tonumber(datetime) <= tonumber(nowDateTime) then
					if not gtIssueTable[issueCode][datetime] then
						gtIssueTable[issueCode][datetime] = {}
					end
					--��¼��ȡ�����ʱ��
					if not gTimeRecordTable[issueCode] then
						gTimeRecordTable[issueCode] = datetime
					else
						if tonumber(gTimeRecordTable[issueCode]) < tonumber(datetime) then
							gTimeRecordTable[issueCode] = datetime
						end
					end
					gtIssueTable[issueCode][datetime].datetime = string.sub(time,1,14)
					gtIssueTable[issueCode][datetime].price = KlineTable.close[i]
					gtIssueTable[issueCode][datetime].volume= KlineTable.volume[i]
					gtIssueTable[issueCode][datetime].nowvolume= KlineTable.volume[i]
				end
			end
		end
	end
end

function getStdTime() --��M000300Ϊ��׼���ʱ���
	Writelog("getStdTime")
	local today = GetDate()
	local nowTime = GetTime()
	local nowDateTime = today..string.sub(nowTime,1,4).."00"
	local startTime = ""
	if not gTimeRecordTable["M000300"]  then
		startTime = today .. "083000"
	else
		startTime = string.sub(gTimeRecordTable["M000300"],1,12).."00"
	end
	local endTime = today .."170000"
	local KlineTable = GetKLine(toObjID("M000300"), "1m",startTime,endTime)
	if KlineTable and KlineTable.time then
		for i,info in pairs(KlineTable.time) do
			if tonumber(info) > tonumber(nowDateTime) then
				KlineTable.time[i] = nil
			end
		end
		gtTimeStdTable = KlineTable.time
		Writelog(serialize(KlineTable))
	end

end

function getCombinIssueInfo(CombinName) --���ָ����ϳɷֹ�����
	if not gCombinList[CombinName] then
		return
	end
	if gCombinList[CombinName].BaseIndexCode ~= "M000300" then
		return
	end
	for issueCode,info in pairs(gCombinIssueList[CombinName])do
		getHistoricalData(issueCode)
	end
end


function CalcCombinInfo(CombinName,dateTime)--����ָ��ʱ������ּ���ɽ�����
	local BasePrice = gCombinList[CombinName].BasePrice
	local sigmaNowPrice = 0--���ּ�*����
	local sigmaYstPrice = 0--����׼*����
	local CombinVolume = 0
	local  slog = string.format("Search CombinName = %s,DateTime = %s",CombinName,dateTime)
	Writelog(slog)
	if gCombinList[CombinName] then
		for issueCode,info in pairs(gCombinIssueList[CombinName])do
			if not gtIssueTable[issueCode] then
				local lostLog = string.format("No Issue Data : issueCode = [%s]",issueCode)
				Writelog(lostLog)
				return
			end
			if gtIssueTable[issueCode][dateTime] then
				local issueInfo = gtIssueTable[issueCode][dateTime]
				local nowPrice = issueInfo.price
				local nowVolume = issueInfo.nowvolume

				local poslog = string.format("issueCode = %s,nowPrice = %s ,nowVolume = %s",issueCode,nowPrice,nowVolume)
				Writelog(poslog)
				sigmaNowPrice = sigmaNowPrice + nowPrice * info.Qty
				CombinVolume = CombinVolume + nowVolume
			else
				if string.sub(dateTime,1,8) == GetDate() then -- ����
					--Writelog(issueCode)
					--local nowPrice = GetforPrice(issueCode,"new")		--��ȡ����
					local nowPrice = 0
					local formerTime = nil--��ñȵ�ǰ��׼ʱ��С����С����
					for i,stdTime in pairs(gtTimeStdTable) do
						if tonumber(stdTime) < tonumber(dateTime) then
							if gtIssueTable[issueCode][stdTime] then
								formerTime = stdTime
							end
						else
							break
						end
					end

					if formerTime then
						nowPrice = gtIssueTable[issueCode][formerTime].price
					end
					if nowPrice == 0 then
						nowPrice = GetforPrice(issueCode,"lastclose")
					end
					local nowVolume = 0
					sigmaNowPrice = sigmaNowPrice + nowPrice * info.Qty

					CombinVolume = CombinVolume + nowVolume
				end
			end
			sigmaYstPrice = sigmaYstPrice + gCombinIssueList[CombinName][issueCode].BaseValue
		end

		if not gCombinList[CombinName].RecordTime then
			gCombinList[CombinName].RecordTime = dateTime
		else
			local lastTime = gCombinList[CombinName].RecordTime
			if tonumber(lastTime) < tonumber(dateTime) then
				gCombinList[CombinName].RecordTime  = dateTime
			end
		end
	end
	local CombinPrice = 0
	if sigmaYstPrice ~= 0 then
		CombinPrice = BasePrice * sigmaNowPrice /sigmaYstPrice
	end

	local log = string.format("CalcCombinInfo : CombinName = %s,DateTime = %s,sigmaNowPrice = %s,sigmaYstPrice = %s,CombinPrice = %s,CombinVolume = %s",CombinName,dateTime,sigmaNowPrice,sigmaYstPrice,CombinPrice,CombinVolume)
	Writelog(log)
	if not gtCombinLine[CombinName] then
		gtCombinLine[CombinName] = {}
	end
	if not gtCombinLine[CombinName][dateTime] then
		gtCombinLine[CombinName][dateTime] = {}
	end
	gtCombinLine[CombinName][dateTime].CombinName = CombinName
	gtCombinLine[CombinName][dateTime].DateTime = dateTime
	gtCombinLine[CombinName][dateTime].CombinPrice = CombinPrice
	gtCombinLine[CombinName][dateTime].CombinVolume = CombinVolume
end


function GetIssueInfo(IssueCode,lt)--��ȡ��ǰ���������Լ������
	if not _CurrentCombin or _CurrentCombin == "" then
		return
	end
	if not gCombinIssueList[_CurrentCombin] then
		return
	end
	if not gCombinIssueList[_CurrentCombin][IssueCode] then
		return
	end
	--local tmpString = string.format("CalNowConbinInfo:IssueCode = %s:",IssueCode)
	--for key,value in pairs(lt) do
	--	tmpString = string.format("%s%s = %s;",tmpString,key,value)
	--end
	--Writelog(tmpString)

	if not lt.time then
		return
	end

	local today = GetDate()
	local nowTime = string.sub(lt.time,1,4).."00"
	local dateTime = today..nowTime
	local flag = false

	--��Լ���ݸ�ֵ
	if not gtIssueTable[IssueCode] then
		gtIssueTable[IssueCode] = {}
	end
	if not gtIssueTable[IssueCode][dateTime] then
		gtIssueTable[IssueCode][dateTime]  = {}
		gtIssueTable[IssueCode][dateTime].nowvolume = lt.nowvol
		gtIssueTable[IssueCode][dateTime].dateTime = dateTime
		gtIssueTable[IssueCode][dateTime].price = lt.new
		gtIssueTable[IssueCode][dateTime].volume = lt.volume
	else--�ж���Ч����
		if not gtIssueTable[IssueCode][dateTime].volume or lt.volume > gtIssueTable[IssueCode][dateTime].volume then
			gtIssueTable[IssueCode][dateTime].nowvolume = gtIssueTable[IssueCode][dateTime].nowvolume + lt.nowvol
			flag = true
		end
		if not gtIssueTable[IssueCode][dateTime].price or lt.price ~= gtIssueTable[IssueCode][dateTime].price then
			flag = true
		end
	end

	if flag == false then
		return
	end
	gtIssueTable[IssueCode][dateTime].dateTime = dateTime
	gtIssueTable[IssueCode][dateTime].price = lt.new
	gtIssueTable[IssueCode][dateTime].volume = lt.volume
	local plog = string.format("CalNowConbinInfo Get Info : IssueCode = %s,Time = %s,price = %s,newVolume = %s,Volume = %s",
	IssueCode,lt.time,lt.new,lt.nowvol,lt.volume)
	Writelog(plog)
end


function CalNowConbinInfo(lt)--���㵱ǰ������ּ�
	if _CurrentCombin and _CurrentCombin ~= "" then
		if not lt.time then
			return
		end
		if not gtActiveTable[_CurrentCombin] then
			return
		end
		if not gtCombinLine[_CurrentCombin] then
			--gtCombinLine[_CurrentCombin] = {}
			return
		end
		local sigmaNowPrice = 0--���ּ�*��������
		local sigmaYstPrice = 0--����׼*��������
		local CombinPrice = 0
		local CombinVolume = 0
		local today = GetDate()
		local nowTime = lt.time

		--��¼��ǰ�ı�׼ʱ��(M000300)
		local dateTime = today..string.sub(nowTime,1,4).."00"
		if not gtTimeStdTable or #gtTimeStdTable == 0 then
			gtTimeStdTable = {}
			table.insert(gtTimeStdTable,dateTime)
		else
			local size = #gtTimeStdTable
			local lastTime = gtTimeStdTable[size]
			if tonumber(lastTime) < tonumber(dateTime) then
				table.insert(gtTimeStdTable,dateTime)
			end
		end

		gRecordTime = dateTime

		if not gtCombinLine[_CurrentCombin][dateTime] then
			gtCombinLine[_CurrentCombin][dateTime] = {}
		end
		local CombinPrice = gCombinList[_CurrentCombin].Price
		gtCombinLine[_CurrentCombin][dateTime].CombinName = _CurrentCombin
		gtCombinLine[_CurrentCombin][dateTime].DateTime = DateTime
		gtCombinLine[_CurrentCombin][dateTime].CombinPrice = CombinPrice

		for issueCode,info in pairs(gCombinIssueList[_CurrentCombin])do
			if gtIssueTable[issueCode][dateTime] then
				CombinVolume = CombinVolume + gtIssueTable[issueCode][dateTime].nowvolume
			end
		end
		gtCombinLine[_CurrentCombin][dateTime].CombinVolume = CombinVolume
		local log = string.format("CalNowConbinInfo Result: CombinName = %s,DateTime = %s,sigmaNowPrice = %s,sigmaYstPrice = %s,CombinPrice = %s,CombinVolume = %s",_CurrentCombin,dateTime,sigmaNowPrice,sigmaYstPrice,CombinPrice,CombinVolume)
		Writelog(log)

		--���͵���������
		sendSingleCombinLine(_CurrentCombin,dateTime)
	end
end








function CalcCombinAllData(CombinName)--����ָ����ϵ���������
	if gCombinList[CombinName] then
		local value = gCombinList[CombinName]
		if value.BaseIndexCode == "M000300" then
			for i,datetime in pairs(gtTimeStdTable)do
				if not gCombinList[CombinName].RecordTime then
					CalcCombinInfo(CombinName,datetime)
				else
					local lastTime = gCombinList[CombinName].RecordTime
					if not gtCombinLine then
						CalcCombinInfo(CombinName,datetime)
					elseif not gtCombinLine[CombinName][datetime] or tonumber(lastTime) <= tonumber(datetime) then
						CalcCombinInfo(CombinName,datetime)
					end
				end
			end
		end
	end
end

function sendSingleCombinLine(CombinName,dateTime)--���͵���������
	Writelog("sendSingleCombinLine")
	if gCombinIssueList[_CurrentCombin] then
		local Table={CombinName={},DateTime={},CombinPrice={},CombinVolume={},M000300Price={}}
		local info = gtCombinLine[CombinName][dateTime]
		if gKlineTableForIF["M000300"] then
			local info2 = gKlineTableForIF["M000300"].close
			if info2 then
				local M000300Price = info2[#info2]
				table.insert(Table.M000300Price,M000300Price or "")
			end
		end
		table.insert(Table.CombinName,CombinName)
		table.insert(Table.DateTime,dateTime or "")
		local combinPrice = info.CombinPrice
		if combinPrice then
			combinPrice = string.format("%.2f",info.CombinPrice)
		end
		table.insert(Table.CombinPrice,combinPrice or "")
		table.insert(Table.CombinVolume,info.CombinVolume or "")
		SendToUI("CombinLine",Table)
	end
end


function sendAllCombinLine(CombinCode)--���͵�ǰ�������ͼ
	if CombinCode == _CurrentCombin and _CurrentCombin ~= "" then
		Writelog("sendAllCombinLine")
		if gtCombinLine[_CurrentCombin] then
			local Table={CombinName={},DateTime={},CombinPrice={},CombinVolume={},M000300Price={}}
			local info = gtCombinLine[_CurrentCombin]
			local info2 = gKlineTableForIF["M000300"]
			local M000300Price = getLastClose("M000300") or 0
			--[[
			if info then
				_WriteAplLog(serialize(gtCombinLine[_CurrentCombin]))
				for dateTime,value in pairs(info)do
					table.insert(Table.CombinName,value.CombinName)
					table.insert(Table.DateTime,dateTime or "")
					local combinPrice = value.CombinPrice
					if combinPrice then
						combinPrice = string.format("%.2f",value.CombinPrice)
					end
					table.insert(Table.CombinPrice,combinPrice or "")
					table.insert(Table.CombinVolume,value.CombinVolume or "")
				end
			end
			]]
			if info and info2 then
				--_WriteAplLog(serialize(info2))
				if info2.time then
					for index,dateTime in pairs(info2.time) do
						table.insert(Table.DateTime,dateTime or "")
						local combinPrice = ""
						local combinVolume = ""
						if info[dateTime] then
							combinName = info[dateTime].CombinName
							combinPrice = info[dateTime].CombinPrice
							combinVolume = info[dateTime].CombinVolume
							if combinPrice then
								combinPrice = string.format("%.2f",combinPrice)
							end
						end
						table.insert(Table.CombinName,combinName or "")
						table.insert(Table.CombinPrice,combinPrice or "")
						table.insert(Table.CombinVolume,combinVolume or "")
						M000300Price = info2.close[index]
						table.insert(Table.M000300Price,M000300Price or "")
					end
				end
			end

			SendToUI("CombinLine",Table)
		else
			Writelog("gtCombinLine _CurrentCombin Empty")
		end
	end
end
function reCalcCombin(CombinCode)--���¼���һ�����
	Writelog("reCalcCombin")
	if not gtActiveTable then
		gtActiveTable = {}
	end
	gtActiveTable[CombinCode] = 1
	if not gtTimeStdTable or #gtTimeStdTable == 0 then
		getStdTime()
	end
	getCombinIssueInfo(CombinCode)
	CalcCombinAllData(CombinCode)
	sendAllCombinLine(CombinCode)
end

function clearCombinLine()--�����
	SendToUI('CombinLine', '$clear')
end
-------------------------------------------------------------------------
---------------------------������Ʒ���ͼEnd-----------------------------
-------------------------------------------------------------------------

-------------------------------------------------------------------------
---------------------------��ϲ�ֵͼ------------------------------------
-------------------------------------------------------------------------
gHistoryFittingKey = ""
gLeft = ""
gRight = ""
function clearFittingGraph()--��ͼ
	--δѡ���Ӧ���ʱ����ͼ
	SendToUI('FittingGraph', '$clear')
end

function RefreshFittingGraph(arg)--������ϲ�ֵͼ�¼�
	Writelog("RefreshFittingGraph")
	progressBar(0,"����ͼ������")
	clearFittingGraph()
	local CombinCode = arg.CombinCode
	gLeft = arg.Left
	gRight = arg.Right

	if gLeft == "����300" then
		gLeft = "M000300"
	end
	if gRight == "����300" then
		gRight = "M000300"
	end
	local log = string.format("CombinCode[%s],Left[%s],Right[%s]",CombinCode,gLeft,gRight)
	Writelog(log)
	if gLeft == "��Ӧ���" or gRight == "��Ӧ���" then
		if gCombinIssueList[_CurrentCombin] and CombinCode == _CurrentCombin then
			FittingGraphType = "0"
			SendHistoryFittingGraph()
		end
	else
		FittingGraphType = "0"
		SendHistoryFittingGraph()
	end
	progressBar(100)
end

function SendHistoryFittingGraph()--ˢ����ʷ��ϲ�ֵͼ
	Writelog("SendHistoryFittingGraph")
	gHistoryFittingKey = _CurrentCombin .. gLeft .. gRight

	local LeftPrice = 0
	local RightPrice = 0

	local nowTime = os.date("%Y%m%d%H%M".."00");
	Writelog(string.format("nowTime[%s]",nowTime))

	if gLeft == "��Ӧ���" and gCombinList[_CurrentCombin] then
		LeftPrice = gCombinList[_CurrentCombin].BasePrice
		Writelog(string.format("LeftBasePrice[%s]",LeftPrice))
	elseif gLeft == "M000300" then
		LeftPrice = getLastClose(gLeft)
		Writelog(string.format("M000300ClosePrice[%s]",LeftPrice))
	end

	if gRight == "��Ӧ���" and gCombinList[_CurrentCombin] then
		RightPrice = gCombinList[_CurrentCombin].BasePrice
		Writelog(string.format("RightBasePrice[%s]",RightPrice))
	elseif gRight == "M000300" then
		RightPrice = getLastClose(gRight)
		Writelog(string.format("M000300ClosePrice[%s]",RightPrice))
	end
	local LeftTime = 0
	local Table={ClosePrice={},IssueCode={},_TimeKey={}}
	progressBar(50)
	if gBaseTime then
		local i=1
		local j=1
		for number,value in pairs(gBaseTime)do
			if value >= nowTime then
				break;
			end
			--ȡ��������ֵ
			if gLeft == "��Ӧ���" then
				if gtCombinLine[_CurrentCombin] then
					--Writelog(string.format("��gtCombinLine[_CurrentCombin]"))
					LeftTime = value
					if gtCombinLine[_CurrentCombin][value] then
						LeftPrice = gtCombinLine[_CurrentCombin][value].CombinPrice
						Writelog(string.format("��Ӧ���:LeftPrice[%s],LeftTime[%s]",LeftPrice,LeftTime))
					end
				end
			elseif gKlineTableForIF[gLeft] then
				if gKlineTableForIF[gLeft].close then
					LeftTime = value
					Writelog(string.format("%s:LeftTime[%s]",gLeft,LeftTime))
					if LeftTime == gKlineTableForIF[gLeft].time[i] then
						LeftPrice = gKlineTableForIF[gLeft].close[i]
						Writelog(string.format("%s:LeftPrice[%s]",gLeft,LeftPrice))
						i=i+1
					end
				end
			end
			--�Ҷ�Ӧ����������ֵ
			if gRight == "��Ӧ���" then
				if gtCombinLine[_CurrentCombin] then
					--Writelog(string.format("��gtCombinLine[_CurrentCombin]"))
					if gtCombinLine[_CurrentCombin][LeftTime] then
						RightPrice = gtCombinLine[_CurrentCombin][LeftTime].CombinPrice
						Writelog(string.format("��Ӧ���:RightPrice[%s]",RightPrice))
					end
				end
			elseif gKlineTableForIF[gRight] then
				if gKlineTableForIF[gRight].close then
					Writelog(string.format("%s:LeftTime[%s],RightTime",gRight,LeftTime,gKlineTableForIF[gRight].time[j]))
					if LeftTime == gKlineTableForIF[gRight].time[j] then
						RightPrice =  gKlineTableForIF[gRight].close[j]
						Writelog(string.format("%s:RightPrice[%s]",gRight,RightPrice))
						j=j+1
					end
				end
			end

			local ClosePrice = LeftPrice - RightPrice
			ClosePrice = string.format("%.2f",ClosePrice)
			Writelog(string.format("ClosePrice[%s],LeftPrice[%s],RightPrice[%s],",ClosePrice,LeftPrice,RightPrice))
			table.insert(Table.ClosePrice,ClosePrice)
			table.insert(Table.IssueCode,gHistoryFittingKey)
			table.insert(Table._TimeKey,LeftTime)
		end
		--Writelog(serialize(Table))
		SendToUI("FittingGraph",Table)
		FittingGraphType = "1"
	else
		Writelog("ʱ���û����")
	end
end

function SendFittingGraph(lt)--ˢ��ʵʱ��ϲ�ֵͼ
	--Writelog("SendFittingGraph")
	if gHistoryFittingKey and gHistoryFittingKey ~= "" then
		local Table={ClosePrice={},IssueCode={},_TimeKey={}}
		local LeftPrice = 0
		local RightPrice = 0
		local ClosePrice = 0
		local today = GetDate()
		local nowTime = lt.time
		if not nowTime then
			return
		end
		local dateTime = today .. string.sub(nowTime,1,4) .. "00"

		if gLeft == "��Ӧ���" then
			if gCombinList[_CurrentCombin] then
				LeftPrice = gCombinList[_CurrentCombin].Price
			end
		elseif gKlineTableForIF[gLeft] then
			if gKlineTableForIF[gLeft].close then
				LeftPrice = gKlineTableForIF[gLeft].close[#gKlineTableForIF[gLeft].close]
				nowTime = gKlineTableForIF[gLeft].time[#gKlineTableForIF[gLeft].time]
			end
		end

		if gRight == "��Ӧ���" then
			if gCombinList[_CurrentCombin] then
				RightPrice = gCombinList[_CurrentCombin].Price
			end
		elseif gKlineTableForIF[gRight] then
			if gKlineTableForIF[gRight].close then
				RightPrice = gKlineTableForIF[gRight].close[#gKlineTableForIF[gRight].close]
				nowTime = gKlineTableForIF[gRight].time[#gKlineTableForIF[gRight].time]
			end
		end
		if LeftPrice and RightPrice then
			ClosePrice = LeftPrice - RightPrice
		end

		table.insert(Table.ClosePrice,ClosePrice)
		table.insert(Table.IssueCode,gHistoryFittingKey)
		table.insert(Table._TimeKey,nowTime)

		SendToUI("FittingGraph",Table)
	end
end
-------------------------------------------------------------------------
---------------------------��ϲ�ֵͼEnd---------------------------------
-------------------------------------------------------------------------



-------------------------------------------------------------------------
---------------------------�����ʷ����ͼ--------------------------------
-------------------------------------------------------------------------
gHistorygGraph = {}		--�����ʷ����ͼ��  ����ϴ���gCombinList�е�combinCodeΪkey
gTimeToIndex = {}		--ͨ�����ڷ���gKlineindexTable�е����
gAllIssueKLineByDate = {}	--��IssueCode��DateΪKey��K�߱�	 gAllIssueKLineByDate[IssueCode][Date] = {close =9.6 ,volume=5510}

--��ȡ���Ҽ��������ʷ����
--����CombinCode:�������,dateTime:����
function GetCalcCombinHistory(CombinName,dateTime)
	Writelog("��ȡ���Ҽ������:"..CombinName.."��ʷ����:"..dateTime)
	--[[
	--�Ѿ������� ������ִ��
	if gHistorygGraph[CombinName] then
		if gHistorygGraph[CombinName][dateTime] then
			sendCombinHistoryLine(CombinName,dateTime)
			return
		end
	end]]
	---------------------���� gTimeToIndex ��
	if #gTimeToIndex == 0 then
		for i,timeDate in pairs(gKlineindexTable.time) do
			gTimeToIndex[timeDate] = i
		end
	end
	--------------------�����ж�
	if not CombinName or not dateTime then
		return
	end
	if not gCombinList[CombinName] or not gCombinIssueList[CombinName] then
		return
	end
	if not gTimeToIndex[dateTime] then
		return
	end

	local startDate = gKlineindexTable.time[1]
	local endDate = gKlineindexTable.time[#gKlineindexTable.time]
	-------------------��ȡK��
	for issueCode ,data in pairs(gCombinIssueList[CombinName]) do
		if not gAllIssueKLineByDate[issueCode] then				--�Ѿ���ȡ���Ĳ����ٻ�ȡ��
			local kLine = GetKLine(toObjID(issueCode), "1d", startDate, endDate, nil, nil,1)
			--_WriteAplLog(serialize(kLine))
			if kLine and kLine.time then
				for i,v in pairs(kLine.time) do
					local tempTime = string.sub(v,1,8)
					gAllIssueKLineByDate[issueCode] = gAllIssueKLineByDate[issueCode] or {}
					gAllIssueKLineByDate[issueCode][tempTime] = gAllIssueKLineByDate[issueCode][tempTime] or {}
					gAllIssueKLineByDate[issueCode][tempTime].close = kLine.close[i]
					gAllIssueKLineByDate[issueCode][tempTime].volume = kLine.volume[i]
					local log = string.format("��ȡK������:��Լ:%s,ʱ��:%s,���̼�:%s,�ɽ���:%s",issueCode,tempTime,kLine.close[i],kLine.volume[i])
					Writelog(log)
				end

				local kLinelast = GetKLine(toObjID(issueCode), "1d", nil, startDate, -1, 1,1)
				local lnc = 0
				if kLine and kLine.time then
					lnc = kLine.close[1]
				end
				local lastLnc = nil
				for i,v in pairs(gKlineindexTable.time) do
					lastLnc = lastLnc or lnc
					if not gAllIssueKLineByDate[issueCode][v] then
						gAllIssueKLineByDate[issueCode][v] = {}
						if i == 1 then
							gAllIssueKLineByDate[issueCode][v].close = lnc
							gAllIssueKLineByDate[issueCode][v].volume = 0
						else
							gAllIssueKLineByDate[issueCode][v].close = gAllIssueKLineByDate[issueCode][gKlineindexTable.time[i-1]].close or 0
							gAllIssueKLineByDate[issueCode][v].volume = 0
						end
						local log = string.format("����K��,��Լ:%s,����:%s,�۸�:%s",issueCode,v,gAllIssueKLineByDate[issueCode][v].close)
						Writelog(log)
					end

				end


			end
		end
	end
	------------------��ʼ���������ʷ�۸�

	local baseDate = gKlineindexTable.time[gTimeToIndex[dateTime]]	--��׼��
	local basePrice = gKlineindexTable.close[gTimeToIndex[dateTime]]	--��׼ֵ
	Writelog("K�߿�ʼ����:"..startDate.."  K�߿�ʼ����:"..endDate)
	for i,IndexTime in pairs(gKlineindexTable.time) do
		local sumIssueAmount = 0
		local sumBaseAmount = 0
		local sumVolume = 0
		local combinPrice = 0
		for issueCode ,data in pairs(gCombinIssueList[CombinName]) do
			---------------����
			local closePrice = 0
			local closeVolume = 0
			if gAllIssueKLineByDate[issueCode] then
				if gAllIssueKLineByDate[issueCode][IndexTime] then
					closePrice = gAllIssueKLineByDate[issueCode][IndexTime].close or 0
					closeVolume = gAllIssueKLineByDate[issueCode][IndexTime].volume or 0
				end
			end
			local qty = data.Qty or 0
			--�ּ�*����
			sumIssueAmount = sumIssueAmount + closePrice*qty

			local baseIssuePrice = 0
			if gAllIssueKLineByDate[issueCode] then
				if gAllIssueKLineByDate[issueCode][baseDate] then
					baseIssuePrice = gAllIssueKLineByDate[issueCode][baseDate].close or 0
				end
			end
			--��׼��*����
			sumBaseAmount = sumBaseAmount + baseIssuePrice*qty
			sumVolume = sumVolume + closeVolume
			if sumBaseAmount > 0 then
				combinPrice = basePrice*(sumIssueAmount/sumBaseAmount)
			end
		end
		gHistorygGraph[CombinName] = gHistorygGraph[CombinName] or {}
		gHistorygGraph[CombinName][dateTime] = gHistorygGraph[CombinName][dateTime] or {CombinPrice = {},CombinVolume = {},_TimeKey = {},M000300Price={},CombinName={},DateTime={}}
		table.insert(gHistorygGraph[CombinName][dateTime].CombinPrice,combinPrice)
		table.insert(gHistorygGraph[CombinName][dateTime].CombinVolume,sumVolume)
		table.insert(gHistorygGraph[CombinName][dateTime]._TimeKey,IndexTime.."000000")
		table.insert(gHistorygGraph[CombinName][dateTime].M000300Price,gKlineindexTable.close[gTimeToIndex[IndexTime]] or 0)
		table.insert(gHistorygGraph[CombinName][dateTime].CombinName,CombinName)
		table.insert(gHistorygGraph[CombinName][dateTime].DateTime,IndexTime)
		local log = string.format("����õ�:%s�����ʷ����ͼ,ʱ��:%s,�۸�:%s,�ɽ���:%s,ָ����׼����:%s,��׼ֵ:%s",CombinName,IndexTime,combinPrice,sumVolume,baseDate,basePrice)
		Writelog(log)

	end

	sendCombinHistoryLine(CombinName,dateTime)

	--��������
end

--�����ݷ��͵�����
function sendCombinHistoryLine(CombinName,dateTime)
	if not gHistorygGraph[CombinName] then
		return
	end
	if not gHistorygGraph[CombinName][dateTime] then
		return
	end

	SendToUI("CombinHistoryLine",gHistorygGraph[CombinName][dateTime])

end



-------------------------------------------------------------------------
---------------------------�����ʷ����ͼEnd--------------------------------
-------------------------------------------------------------------------




-------------------------------------------------------------------------
---------------------------��ʷ��ϲ�ֵͼ---------------------------------
-------------------------------------------------------------------------
gHistoryLeft = ""
gHistoryRight = ""
function clearFittingHistoryGraph()--��ͼ
	--δѡ���Ӧ���ʱ����ͼ
	SendToUI('FittingHistoryGraph', '$clear')
end

function sendFittingHistoryGraph(fittingKey)
	if not gFittingHistory[fittingKey] then
		return
	end

	SendToUI("FittingHistoryGraph",gFittingHistory[fittingKey])
end


gFittingHistory = {}		--��ʷ��ϲ��  �������Ϊkey  �����Ϊ	��Ϻ�..��ߺ�Լ..�ұߺ�Լ

function RefreshFittingHistoryGraph(arg)--������ʷ��ϲ�ֵͼ�¼�����ȡ���Ҽ������ֵ
	Writelog("RefreshFittingHistoryGraph"..arg.Left.."-"..arg.Right.."("..arg.CombinCode..")")
	progressBar(0,"����ͼ������")
	clearFittingHistoryGraph()
	local CombinCode = arg.CombinCode
	gHistoryLeft = arg.Left
	gHistoryRight = arg.Right

	if gHistoryLeft == "����300" then
		gHistoryLeft = "M000300"
	end
	if gHistoryRight == "����300" then
		gHistoryRight = "M000300"
	end
	local log = string.format("CombinCode[%s],Left[%s],Right[%s]",CombinCode,gHistoryLeft,gHistoryRight)
	Writelog(log)
	local fittingKey = CombinCode .. gHistoryLeft .. gHistoryRight
	Writelog("ˢ����ʷ���:"..fittingKey)
	--[[if gFittingHistory[fittingKey] then
		if #gFittingHistory[fittingKey] > 0 then
			sendFittingHistoryGraph(fittingKey)
			progressBar(100)
			return
		end
	end]]

	progressBar(20,"��ȡK������")
	local startDate = gKlineindexTable.time[1]
	local endDate = gKlineindexTable.time[#gKlineindexTable.time]
	if gHistoryLeft == "��Ӧ���" or gHistoryRight == "��Ӧ���" then
		if not gHistorygGraph[CombinCode] then		--��Ӧ��ϵ����ֵû�����ֱ���˳�
			progressBar(100)
			return
		end
		if not gCombinList[CombinCode] then			--û�и������Ϣ��ֱ���˳�
			progressBar(100)
			return
		end
		if not gHistorygGraph[CombinCode][gCombinList[CombinCode].BaseDate] then  --��Ӧ��ϵ����ֵû�����ֱ���˳�
			progressBar(100)
			return
		end
	end

	if gHistoryLeft ~= "��Ӧ���" then
		--_WriteAplLog(gHistoryLeft)
		if not gAllIssueKLineByDate[gHistoryLeft] then				--�Ѿ���ȡ���Ĳ����ٻ�ȡ��
			local kLine = GetKLine(toObjID(gHistoryLeft), "1d", startDate, endDate, nil, nil,1)
			if kLine and kLine.time then
				for i,v in pairs(kLine.time) do
					local tempTime = string.sub(v,1,8)
					gAllIssueKLineByDate[gHistoryLeft] = gAllIssueKLineByDate[gHistoryLeft] or {}
					gAllIssueKLineByDate[gHistoryLeft][tempTime] = gAllIssueKLineByDate[gHistoryLeft][tempTime] or {}
					gAllIssueKLineByDate[gHistoryLeft][tempTime].close = kLine.close[i]
					gAllIssueKLineByDate[gHistoryLeft][tempTime].volume = kLine.volume[i]
					local log = string.format("��ȡK������:��Լ:%s,ʱ��:%s,���̼�:%s",gHistoryLeft,tempTime,kLine.close[i])
					Writelog(log)
				end
				local kLinelast = GetKLine(toObjID(gHistoryLeft), "1d", nil, startDate, -1, 1,1)
				local lnc = 0
				if kLine and kLine.time then
					lnc = kLine.close[1]
				end
				local lastLnc = nil
				for i,v in pairs(gKlineindexTable.time) do
					lastLnc = lastLnc or lnc
					if not gAllIssueKLineByDate[gHistoryLeft][v] then
						gAllIssueKLineByDate[gHistoryLeft][v] = {}
						if i == 1 then
							gAllIssueKLineByDate[gHistoryLeft][v].close = lnc
							gAllIssueKLineByDate[gHistoryLeft][v].volume = 0
						else
							gAllIssueKLineByDate[gHistoryLeft][v].close = gAllIssueKLineByDate[gHistoryLeft][gKlineindexTable.time[i-1]].close or 0
							gAllIssueKLineByDate[gHistoryLeft][v].volume = 0
						end
						local log = string.format("����K��,��Լ:%s,����:%s,�۸�:%s",gHistoryLeft,v,gAllIssueKLineByDate[gHistoryLeft][v].close)
						Writelog(log)
					end

				end

			end
		end
		if not gAllIssueKLineByDate[gHistoryLeft] then
			progressBar(100)
			return
		end
	end

	if gHistoryRight ~= "��Ӧ���" then
		--_WriteAplLog(gHistoryRight)
		if not gAllIssueKLineByDate[gHistoryRight] then				--�Ѿ���ȡ���Ĳ����ٻ�ȡ��
			local kLine = GetKLine(toObjID(gHistoryRight), "1d", startDate, endDate, nil, nil,1)
			--_WriteAplLog("gHistoryRight:"..gHistoryRight.." "..serialize(kLine))
			if kLine and kLine.time then
				for i,v in pairs(kLine.time) do
					local tempTime = string.sub(v,1,8)
					gAllIssueKLineByDate[gHistoryRight] = gAllIssueKLineByDate[gHistoryRight] or {}
					gAllIssueKLineByDate[gHistoryRight][tempTime] = gAllIssueKLineByDate[gHistoryRight][tempTime] or {}
					gAllIssueKLineByDate[gHistoryRight][tempTime].close = kLine.close[i]
					gAllIssueKLineByDate[gHistoryRight][tempTime].volume = kLine.volume[i]
					local log = string.format("��ȡK������:��Լ:%s,ʱ��:%s,���̼�:%s",gHistoryRight,tempTime,kLine.close[i])
					Writelog(log)
				end
				local kLinelast = GetKLine(toObjID(gHistoryRight), "1d", nil, startDate, -1, 1,1)
				local lnc = 0
				if kLine and kLine.time then
					lnc = kLine.close[1]
				end
				local lastLnc = nil
				for i,v in pairs(gKlineindexTable.time) do
					lastLnc = lastLnc or lnc
					if not gAllIssueKLineByDate[gHistoryRight][v] then
						gAllIssueKLineByDate[gHistoryRight][v] = {}
						if i == 1 then
							gAllIssueKLineByDate[gHistoryRight][v].close = lnc
							gAllIssueKLineByDate[gHistoryRight][v].volume = 0
						else
							gAllIssueKLineByDate[gHistoryRight][v].close = gAllIssueKLineByDate[gHistoryRight][gKlineindexTable.time[i-1]].close or 0
							gAllIssueKLineByDate[gHistoryRight][v].volume = 0
						end
						local log = string.format("����K��,��Լ:%s,����:%s,�۸�:%s",gHistoryRight,v,gAllIssueKLineByDate[gHistoryRight][v].close)
						_WriteAplLog(log)
					end

				end

			end
		end
		if not gAllIssueKLineByDate[gHistoryRight] then
			progressBar(100)
			return
		end
	end
	progressBar(40,"������ʷ��ϲ�")

	--��ʼ����
	for i,IndexTime in pairs(gKlineindexTable.time) do
		local leftPrice = 0
		local rightPrice = 0
		if gHistoryLeft == "��Ӧ���" or gHistoryRight == "��Ӧ���" then			--���
			if gCombinIssueList[_CurrentCombin] and CombinCode == _CurrentCombin then
				if gHistoryLeft == "��Ӧ���" then
					if gHistorygGraph[CombinCode][gCombinList[CombinCode].BaseDate].CombinPrice then
						leftPrice = gHistorygGraph[CombinCode][gCombinList[CombinCode].BaseDate].CombinPrice[i] or 0
					end
					if gAllIssueKLineByDate[gHistoryRight] then
						if gAllIssueKLineByDate[gHistoryRight][IndexTime] then
							rightPrice = gAllIssueKLineByDate[gHistoryRight][IndexTime].close or 0
						end
						if gIndexForIF[gHistoryRight] then --�ж��Ƿ�Ϊ����������Լ,�����滻
							if gIndexForIF[gHistoryRight] == 1 then
								rightPrice = gSFIFTable[IndexTime].close or 0
							end
						end
					end
				elseif gHistoryRight == "��Ӧ���" then
					if gHistorygGraph[CombinCode][gCombinList[CombinCode].BaseDate].CombinPrice then
						rightPrice = gHistorygGraph[CombinCode][gCombinList[CombinCode].BaseDate].CombinPrice[i] or 0
					end
					if gAllIssueKLineByDate[gHistoryLeft] then
						if gAllIssueKLineByDate[gHistoryLeft][IndexTime] then
							leftPrice = gAllIssueKLineByDate[gHistoryLeft][IndexTime].close or 0
						end
						if gIndexForIF[gHistoryLeft] then --�ж��Ƿ�Ϊ����������Լ�������滻
							if gIndexForIF[gHistoryLeft] == 1 then
								leftPrice = gSFIFTable[IndexTime].close or 0
							end
						end
					end
				end
			else
				progressBar(100)
				return
			end
		else															--IF
			if gAllIssueKLineByDate[gHistoryLeft][IndexTime] then
				leftPrice = gAllIssueKLineByDate[gHistoryLeft][IndexTime].close or 0
				if gIndexForIF[gHistoryLeft] then
					if gIndexForIF[gHistoryLeft] == 1 then
						leftPrice = gSFIFTable[IndexTime].close or 0
					end
				end
			end
			if gAllIssueKLineByDate[gHistoryRight][IndexTime] then
				rightPrice = gAllIssueKLineByDate[gHistoryRight][IndexTime].close or 0
				if gIndexForIF[gHistoryRight] then --�ж��Ƿ�Ϊ����������Լ
					if gIndexForIF[gHistoryRight] == 1 then
						rightPrice = gSFIFTable[IndexTime].close or 0
					end
				end
			end
		end
		if leftPrice ~= 0 and rightPrice ~= 0 then
			gFittingHistory[fittingKey] = gFittingHistory[fittingKey] or {_TimeKey = {},IssueCode = {},ClosePrice = {}}
			local StartTime = GetStartDate(gHistoryLeft,gHistoryRight)
			_WriteAplLog("���ͼ�ο�ʼ����:"..StartTime)
			if IndexTime >= StartTime then
				table.insert(gFittingHistory[fittingKey]._TimeKey,IndexTime.."000000")
				table.insert(gFittingHistory[fittingKey].IssueCode,fittingKey)
				table.insert(gFittingHistory[fittingKey].ClosePrice,leftPrice-rightPrice)
				local log = string.format("������ʷ�������:%s,ʱ��:%s,�۸�:%s,leftPrice:%s,rightPrice:%s",fittingKey,IndexTime,leftPrice-rightPrice,leftPrice,rightPrice)
				_WriteAplLog(log)
			end
		end
	end
	progressBar(70,"��ʾ��ʷ��ϲ�")
	sendFittingHistoryGraph(fittingKey)
	progressBar(100)
end

--��õ�����������
function GetSFIFData()
	local startDate = gKlineindexTable.time[1]
	local endDate = gKlineindexTable.time[#gKlineindexTable.time]
	local KLine = GetKLine("SFIF0001.cmdty", "1d", startDate, endDate, nil, nil,1)
	if KLine and KLine.time then
		for i,v in pairs(KLine.time) do
			local tempTime = string.sub(v,1,8)
			gSFIFTable = gSFIFTable or {}
			gSFIFTable[tempTime] = gSFIFTable[tempTime] or {}
			gSFIFTable[tempTime].close = KLine.close[i]
			gSFIFTable[tempTime].volume = KLine.volume[i]
			local log = string.format("��ȡK������:��Լ:%s,ʱ��:%s,���̼�:%s,�ɽ���:%s","SFIF0001",tempTime,KLine.close[i],KLine.volume[i])
			_WriteAplLog(log)
		end

		local kLinelast = GetKLine("SFIF0001.cmdty", "1d", nil, startDate, -1, 1,1)
		local lnc = 0
		if KLine and KLine.time then
			lnc = KLine.close[1]
		end
		local lastLnc = nil
		for i,v in pairs(gKlineindexTable.time) do
			lastLnc = lastLnc or lnc
			if not gSFIFTable[v] then
				gSFIFTable[v] = {}
				if i == 1 then
					gSFIFTable[v].close = lnc
					gSFIFTable[v].volume = 0
				else
					gSFIFTable[v].close = gSFIFTable[gKlineindexTable.time[i-1]].close or 0
					gSFIFTable[v].volume = 0
				end
				local log = string.format("����K��,��Լ:%s,����:%s,�۸�:%s","SFIF0001",v,gSFIFTable[v].close)
				_WriteAplLog(log)
			end

		end
	end
end

--�����С������
function GetStartDate(LeftIssue,RightIssue)
	_WriteAplLog("GetStartDate")
	local startDate = gKlineindexTable.time[1]
	local leftKLine = GetKLine(toObjID(LeftIssue), "1d", startDate, endDate, nil, nil,1)
	local rightKLine = GetKLine(toObjID(RightIssue), "1d", startDate, endDate, nil, nil,1)
	local LeftMinDate = startDate
	if leftKLine and leftKLine.time then
		for i,v in pairs(leftKLine.time) do
			if v then
				LeftMinDate = string.sub(v,1,8)
				break
			end
		end
	end
	_WriteAplLog("LeftMinDate:"..LeftMinDate)
	local RightMinDate = startDate
	if rightKLine and rightKLine.time then
		for i,v in pairs(rightKLine.time) do
			if v then
				RightMinDate = string.sub(v,1,8)
				break
			end
		end
	end
	_WriteAplLog("RightMinDate:"..RightMinDate)
	--���¹�ָ�ڻ���Լ����
	if gIndexForIF[LeftIssue] then
		if gIndexForIF[LeftIssue] == 1 then
			LeftMinDate = startDate
		end
	end
	if gIndexForIF[RightIssue] then
		if gIndexForIF[RightIssue] == 1 then
			RightMinDate = startDate
		end
	end
	local MinDate = LeftMinDate
	if RightMinDate >=  MinDate then
		MinDate = RightMinDate
	end
	return MinDate
end
-------------------------------------------------------------------------
---------------------------��ʷ��ϲ�ֵͼEnd-----------------------------
-------------------------------------------------------------------------




