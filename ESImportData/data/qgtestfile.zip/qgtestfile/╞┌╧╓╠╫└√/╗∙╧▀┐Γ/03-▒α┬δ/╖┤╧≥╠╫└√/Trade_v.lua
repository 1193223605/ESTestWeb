﻿--反向期现套利初始版1.01
--Release version: 1.001.20140305
-------------------------------XH-------------------------------

_OnEventDefined(VopenStockQty openStockQtyEvent)				--现货开仓份数控件
	if _InitializeFlag == 1 then
		local StockQty = openStockQtyEvent._GetFld("OpenStockQty")
		if gtCombinList[gPortID] then
			if StockQty ~= nil or StockQty ~= "" then
				StockQty = StockQty.getNumberValue()
				gtCombinList[gPortID].StockNum = StockQty -- 现货开仓份数
			end

			Refresh(gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VopenStockPrice openStockPriceEvent)				--现货开仓取价控件
	if _InitializeFlag == 1 then
		local StockPrice = openStockPriceEvent._GetFld("OpenStockPrice")
		if gtCombinList[gPortID] then
			for issue,v in pairs(gtCombinList[gPortID].List) do
				gtCombinList[gPortID].List[issue].StockSell = StockPrice	--现货开仓取价
			end
			gtCombinList[gPortID].StockSell = StockPrice
		end

		Refresh(gPortID)
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VopenStockchange openStockchangeEvent)				--现货tick控件
	if _InitializeFlag == 1 then
		local Stockchange = openStockchangeEvent._GetFld("OpenStockchange")
		if gtCombinList[gPortID] then
			for issue,v in pairs(gtCombinList[gPortID].List) do
				gtCombinList[gPortID].List[issue].StockSellTick = Stockchange 	--现货tick
			end
		end

		Refresh(gPortID)
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VopenFutureQty openFutureQtyEvent)				--期货开仓份数控件
	if _InitializeFlag == 1 then
		local FutureQty = openFutureQtyEvent._GetFld("OpenFutureQty")
		if gtCombinList[gPortID] then
			if FutureQty ~= nil or FutureQty ~= "" then
				FutureQty = FutureQty.getNumberValue()
				gtCombinList[gPortID].FutureNum = FutureQty	--期货开仓份数
			end

			Refresh(gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VopenFuturePrice openFuturePriceEvent)			--期货开仓取价控件
	if _InitializeFlag == 1 then
		local FuturePrice = openFuturePriceEvent._GetFld("OpenFuturePrice")
		if gtCombinList[gPortID] then
			gtCombinList[gPortID].FutureBuy = FuturePrice	--期货开仓取价

			Refresh(gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VopenFuturechange openFuturechangeEvent)			--期货tick控件
	if _InitializeFlag == 1 then
		local Futurechange = openFuturechangeEvent._GetFld("OpenFuturechange")
		if gtCombinList[gPortID] then
			gtCombinList[gPortID].FutureBuyTick = Futurechange	--期货tick

			Refresh(gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VcloseStockPrice closeStockPriceEvent)		--现货平仓取价控件
	if _InitializeFlag == 1 then
		local StockPrice = closeStockPriceEvent._GetFld("CloseStockPrice")
		if gtCombinList[gPortID] then
			for issue,v in pairs(gtCombinList[gPortID].List) do
				gtCombinList[gPortID].List[issue].StockBuy = StockPrice	--现货平仓取价
			end
			gtCombinList[gPortID].StockBuy = StockPrice
		end


		Refresh(gPortID)
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VcloseStockchange closeStockchangeEvent)		--现货tick控件
	if _InitializeFlag == 1 then
		local Stockchange = closeStockchangeEvent._GetFld("CloseStockchange")
		if gtCombinList[gPortID] then
			for issue,v in pairs(gtCombinList[gPortID].List) do
				gtCombinList[gPortID].List[issue].StockBuyTick = Stockchange	--现货tick
			end
		end

		Refresh(gPortID)
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

_OnEventDefined(VcloseFuturePrice closeFuturePriceEvent)		--期货平仓取价控件
	if _InitializeFlag == 1 then
		local FuturePrice = closeFuturePriceEvent._GetFld("CloseFuturePrice")

		if gtCombinList[gPortID] then
			gtCombinList[gPortID].FutureSell = FuturePrice	--期货平仓取价

			Refresh(gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VcloseFuturechange closeFuturechangeEvent)		--期货平仓tick控件
	if _InitializeFlag == 1 then
		local Futurechange = closeFuturechangeEvent._GetFld("CloseFuturechange")
		if gtCombinList[gPortID] then
			gtCombinList[gPortID].FutureSellTick = Futurechange	--期货平仓tick

			Refresh(gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End



_OnEventDefined(VGetBuyOrderLog MessageEvent)			--接收开仓数据
	_WriteErrorLog("开仓事件！")
	if _InitializeFlag == 1 then
		local state = MessageEvent._GetFld("Open") -- 下单类型
		_WriteErrorLog(state)
		if state == "建仓" then
			--_WriteErrorLog("建仓函数")
			local StockOrder = CheckStock("手动",gPortID,"Open") -- 检查股票
			if StockOrder.submitFlag then
				local FutureOrder = CheckFuture("手动",gPortID,"Open") -- 检查期货
				if FutureOrder.submitFlag then
					local submit = FutureOrder.order
					--不做可用资金检查
					--local OrderFlag = CheckOrder("建仓",gPortID,submit,StockOrder.order) -- 检查柜台可用资金
					--if OrderFlag  == "Yes" then
						openStock(gPortID,StockOrder.order); -- 买入组合
						openFuture(gPortID,FutureOrder.order) -- 卖出期货
					--end
				end
			end

		elseif state == "卖出组合" then
			local Order = CheckStock("手动",gPortID,"Open")  -- 检查股票
			if Order.submitFlag then
				--不做检查
				--local OrderFlag = CheckOrder("卖出组合",gPortID,{},Order.order) -- 信用账户信用额度检查
				--if OrderFlag  == "Yes" then
					openStock(gPortID,Order.order); -- 买入组合
				--end
			end

		elseif state == "买入期货" then
			local Order = CheckFuture("手动",gPortID,"Open") -- 检查期货
			if Order.submitFlag then
				local submit = Order.order
				--不做检查
				--local OrderFlag = CheckOrder("买入期货",gPortID,submit,{}) -- 期货账户可用资金检查
				--if OrderFlag  == "Yes" then
					openFuture(gPortID,submit) -- 卖出期货
				--end
			end

		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VGetSellOrderLog MessageEvent)		--接收平仓数据
	_WriteErrorLog("平仓事件！")
	if _InitializeFlag == 1 then
		local state = MessageEvent._GetFld("Close") -- 下单类型
		if state == "平仓" then
			local StockOrder = CheckStock("手动",gPortID,"Close") -- 检查股票
			if StockOrder.submitFlag then
				local FutureOrder = CheckFuture("手动",gPortID,"Close") -- 检查期货
				if FutureOrder.submitFlag then
					closeStock(gPortID,StockOrder.order); -- 买券还券
					closeFuture(gPortID,FutureOrder.order) -- 卖出期货
				end
			end

		elseif state == "买入组合" then
			local Order = CheckStock("手动",gPortID,"Close") -- 检查股票
			if Order.submitFlag then
				--local OrderFlag = CheckOrder("买入组合",gPortID,{},Order.order) -- 信用账户可用资金检查
				--if OrderFlag  == "Yes" then
					closeStock(gPortID,Order.order); --买券还券
				--end
			end

		elseif state == "卖出期货" then
			local Order = CheckFuture("手动",gPortID,"Close") -- 检查期货
			if Order.submitFlag then
				closeFuture(gPortID,Order.order) -- 卖出期货
			end

		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End


_OnEventDefined(VAutoOrder AutoOrderEvent)			--自动开平仓设置回调
	if _InitializeFlag == 1 then
		local state = AutoOrderEvent._GetFld("State")
		if state == "自动开" then
			_WriteErrorLog("自动开")
			local portID      = AutoOrderEvent._GetFld("OpenPortID")
			local onOff1      = AutoOrderEvent._GetFld("OnOff1")
			_WriteErrorLog(portID)
			if onOff1 == "0" then		--开启自动开仓逻辑
				--_WriteErrorLog("onOff1 == 0")
				gtCombinList[portID].StockStatus  =  "自动建仓" 								--状态
				gtCombinList[portID].FutureStatus  =  "自动建仓" 								--状态
				InventoryListTable(portID)

				--获取开仓条件
				local basis1      = AutoOrderEvent._GetFld("Basis1")

				local CloseTouch1 = AutoOrderEvent._GetFld("CloseTouch1")
				local close1      = AutoOrderEvent._GetFld("Close1")
				local ss1         = AutoOrderEvent._GetFld("Ss1")
				if basis1 ~= "-" and basis1 ~= "" and basis1 ~= nil then
					basis1 = basis1.getNumberValue()
				end
				if ss1 ~= "-" and ss1 ~= "" and ss1 ~= nil then
					ss1 = ss1.getNumberValue()
				end

				local yes1        = AutoOrderEvent._GetFld("Yes1")
				--local onOff1      = AutoOrderEvent._GetFld("OnOff1")
				local time1       = getNowTime() -- 秒
				--local portID      = AutoOrderEvent._GetFld("OpenPortID")


				local CloseTouch1char = "是"
				if CloseTouch1 == "1" then
					CloseTouch1char = "否"
				end
				local close1char = "是"
				if close1 == "1" then
					close1char = "否"
				end
				local yes1char = "是"
				if yes1 == "1" then
					yes1char = "否"
				end
				local log = sys_format("接收自动开仓数据：基差[%s],触发单选[%s],无响应勾选[%s],秒数[%s],是否确认委托[%s]",basis1,CloseTouch1char,close1char,ss1,yes1char)
				_WriteErrorLog(log)
				sendLog(log,portID)
				--存现货数据
				if gtCombinList[portID] then
					for issue,v in pairs(gtCombinList[portID].List) do
						--local orderBuyQty  = v.OrderBuyQty     -- 委买数量
						--local stockBuy     = v.StockBuy        -- 取价方式
						--local stockBuyTick = v.StockBuyTick   -- 股票tick
						local orderSellQty  = v.OrderSellQty     -- 委买数量
						local stockSell     = v.StockSell        -- 取价方式
						local stockSellTick = v.StockSellTick   -- 股票tick

						local log = sys_format("存现货数据：orderSellQty[%s],stockSell[%s],stockSellTick[%s]",orderSellQty,stockSell,stockSellTick)
						_WriteErrorLog(log)

						gtAutoOrder[portID] = gtAutoOrder[portID] or {}
						gtAutoOrder[portID].List = gtAutoOrder[portID].List or {}
						gtAutoOrder[portID].List[issue] = gtAutoOrder[portID].List[issue] or {}
						--gtAutoOrder[portID].List[issue].OrderBuyQty  = orderBuyQty
						--gtAutoOrder[portID].List[issue].StockBuy     = stockBuy
						--gtAutoOrder[portID].List[issue].StockBuyTick = stockBuyTick
						gtAutoOrder[portID].List[issue].OrderSellQty  = orderSellQty
						gtAutoOrder[portID].List[issue].StockSell     = stockSell
						gtAutoOrder[portID].List[issue].StockSellTick = stockSellTick

					end

					--存期货数据
					local future         = gtCombinList[portID].Future
					local futureNum      = gtCombinList[portID].FutureNum
					--local futureSell     = gtCombinList[portID].FutureSell
					--local futureSellTick = gtCombinList[portID].FutureSellTick
					local futureBuy     = gtCombinList[portID].FutureBuy
					local futureBuyTick = gtCombinList[portID].FutureBuyTick

					local log = sys_format("存期货数据：future[%s],orderBuyQty[%s],futureSell[%s],futureSellTick[%s]",future,futureNum,futureBuy,futureBuyTick)
					_WriteErrorLog(log)

					gtAutoOrder[portID].Future          = future
					gtAutoOrder[portID].FutureNum       = futureNum
					gtAutoOrder[portID].FutureBuy      = futureBuy
					gtAutoOrder[portID].FutureBuyTick  = futureBuyTick

					--存设置数据
					gtAutoOrder[portID].basis1      = basis1             -- 基差
					gtAutoOrder[portID].CloseTouch1 = CloseTouch1        -- 触发方式
					gtAutoOrder[portID].close1      = close1             -- 无响应
					gtAutoOrder[portID].ss1         = ss1                -- 秒
					gtAutoOrder[portID].yes1        = yes1               -- 确认提示
					gtAutoOrder[portID].time1       = time1              -- 设置时间
					gtAutoOrder[portID].onOff1      = onOff1             -- 开关标志
				end
				sendLog("已保存当前组合委托融券卖出取价方式和期货买开取价方式.",portID)
			else
				--_WriteErrorLog("onOff1 == 1")
				gtCombinList[portID].StockStatus  =  "新建" 								--状态
				gtCombinList[portID].FutureStatus  =  "新建" 								--状态
				InventoryListTable(portID)
				SaveCombinData(portID,gtCombinList[portID])
				gtAutoOrder[portID] = nil
			end



		elseif state == "自动平" then

			local portID      = AutoOrderEvent._GetFld("ClosePortID")
			local onOff2 	  = AutoOrderEvent._GetFld("OnOff2")

			if onOff2 == "0" then		--开启自动平仓逻辑
				local oldStockStatus = AutoOrderEvent._GetFld("OldStockStatus")
				local oldFutureStatus = AutoOrderEvent._GetFld("OldFutureStatus")
				local log = sys_format("oldStockStatus = %s,oldFutureStatus = %s",oldStockStatus,oldFutureStatus)
				_WriteErrorLog(log)

				gtSaveOld[portID] = gtSaveOld[portID] or {}
				gtSaveOld[portID].oldStockStatus = oldStockStatus
				gtSaveOld[portID].oldFutureStatus = oldFutureStatus
				local log1 = sys_format("StockStatus = %s,FutureStatus = %s",gtSaveOld[portID].oldStockStatus,gtSaveOld[portID].oldFutureStatus)
				_WriteErrorLog(log1)

				gtCombinList[portID].StockStatus  =  "自动平仓" 								--状态
				gtCombinList[portID].FutureStatus  =  "自动平仓" 								--状态
				InventoryListTable(portID)

				--获取平仓条件
				local basis2 = AutoOrderEvent._GetFld("Basis2")
				local CloseTouch2 = AutoOrderEvent._GetFld("CloseTouch2")
				local close2 = AutoOrderEvent._GetFld("Close2")
				local ss2 = AutoOrderEvent._GetFld("Ss2")
				if basis2 ~= "-" and basis2 ~= "" and basis2 ~= nil then
					basis2 = basis2.getNumberValue()
				end
				if ss2 ~= "-" and ss2 ~= "" and ss2 ~= nil then
					ss2 = ss2.getNumberValue()
				end

				local yes2 = AutoOrderEvent._GetFld("Yes2")
				--local onOff2 = AutoOrderEvent._GetFld("OnOff2")
				local time2 = getNowTime() -- 秒
				--local portID      = AutoOrderEvent._GetFld("ClosePortID")
				local CloseTouch1char = "是"
				if CloseTouch2 == "1" then
					CloseTouch1char = "否"
				end
				local close1char = "是"
				if close2 == "1" then
					close1char = "否"
				end
				local yes1char = "是"
				if yes2 == "1" then
					yes1char = "否"
				end
				local logs = sys_format("接收自动平仓数据：基差[%s],触发单选[%s],无响应勾选[%s],秒数[%s],是否确认委托[%s]",basis2,CloseTouch1char,close1char,ss2,yes1char)
				_WriteErrorLog(logs)
				sendLog(logs,portID)
				--存现货数据
				if gtCombinList[portID] then
					for issue,v in pairs(gtCombinList[portID].List) do
						--local orderSellQty = v.OrderSellQty     -- 委买数量
						--local stockSell    = v.StockSell        -- 取价方式
						--local stockSellTick = v.StockSellTick   -- 股票tick
						local orderBuyQty = v.OrderBuyQty     -- 委买数量
						local stockBuy    = v.StockBuy        -- 取价方式
						local stockBuyTick = v.StockBuyTick   -- 股票tick

						local log = sys_format("存现货数据：orderBuyQty[%s],stockBuy[%s],stockBuyTick[%s]",orderBuyQty,stockBuy,stockBuyTick)
						_WriteErrorLog(log)

						gtAutoOrder[portID] = gtAutoOrder[portID] or {}
						gtAutoOrder[portID].List = gtAutoOrder[portID].List or {}
						gtAutoOrder[portID].List[issue] = gtAutoOrder[portID].List[issue] or {}
						--gtAutoOrder[portID].List[issue].OrderSellQty  = orderSellQty
						--gtAutoOrder[portID].List[issue].StockSell     = stockSell
						--gtAutoOrder[portID].List[issue].StockSellTick = stockSellTick
						gtAutoOrder[portID].List[issue].OrderBuyQty  = orderBuyQty
						gtAutoOrder[portID].List[issue].StockBuy     = stockBuy
						gtAutoOrder[portID].List[issue].StockBuyTick = stockBuyTick

					end

					--存期货数据
					local future         = gtCombinList[portID].Future
					local futureNum      = gtCombinList[portID].FutureNum
					--local futureBuy      = gtCombinList[portID].FutureBuy
					--local futureBuyTick  = gtCombinList[portID].FutureBuyTick

					local futureSell      = gtCombinList[portID].FutureSell
					local futureSellTick  = gtCombinList[portID].FutureSellTick

					local log = sys_format("存期货数据：future[%s],orderSellQty[%s],futureSell[%s],futureSellTick[%s]",future,futureNum,futureSell,futureSellTick)
					_WriteErrorLog(log)

					gtAutoOrder[portID].Future 		    = future
					gtAutoOrder[portID].FutureNum       = futureNum
					--gtAutoOrder[portID].FutureBuy       = futureBuy
					--gtAutoOrder[portID].FutureBuyTick   = futureBuyTick
					gtAutoOrder[portID].FutureSell       = futureSell
					gtAutoOrder[portID].FutureSellTick   = futureSellTick

					gtAutoOrder[portID].basis2      = basis2             -- 基差
					gtAutoOrder[portID].CloseTouch2 = CloseTouch2        -- 触发方式
					gtAutoOrder[portID].close2      = close2             -- 无响应
					gtAutoOrder[portID].ss2 	    = ss2                -- 秒
					gtAutoOrder[portID].yes2 	    = yes2               -- 确认提示
					gtAutoOrder[portID].time2 	    = time2              -- 设置时间
					gtAutoOrder[portID].onOff2 	    = onOff2             -- 开关标志
				end
				sendLog("已保存当前组合委托买券还券取价方式和期货卖平取价方式.",portID)
			else

				gtCombinList[portID].StockStatus  = gtSaveOld[portID].oldStockStatus 								--状态
				gtCombinList[portID].FutureStatus  = gtSaveOld[portID].oldFutureStatus 								--状态
				InventoryListTable(portID)
				SaveCombinData(portID,gtCombinList[portID])
				gtAutoOrder[portID] = nil
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

_OnEventDefined(VYesOrder YesOrderEvent)					--确认下单回调
	if _InitializeFlag == 1 then
		local PortID = YesOrderEvent._GetFld("PortID")
		local logs = sys_format("PortID = %s",PortID)
		_WriteErrorLog(logs)
		local PortIDName = YesOrderEvent._GetFld("PortIDName")
		local OC = YesOrderEvent._GetFld("OC")
		local Status = YesOrderEvent._GetFld("Status")

		if Status == "Yes" then
			if OC == "0" then

				local StockOrder = CheckStock("自动并确认",PortID,"Open") -- 检查股票
				if StockOrder.submitFlag then
					local FutureOrder = CheckFuture("自动并确认",PortID,"Open") -- 检查期货
					if FutureOrder.submitFlag then
						local submit = FutureOrder.order
						--不做资金检查
						--local OrderFlag = CheckOrder("建仓",PortID,submit,StockOrder.order) -- 检查柜台可用资金
						local OrderFlag = "Yes"
						if OrderFlag  == "Yes" then
							openStock(PortID,StockOrder.order); -- 买入组合
							openFuture(PortID,FutureOrder.order) -- 卖出期货

							gtCombinList[PortID].StockStatus  =   "建仓" 								--状态
							gtCombinList[PortID].FutureStatus  =  "建仓" 								--状态
							InventoryListTable(PortID)
							SaveCombinData(PortID,gtCombinList[PortID])
						else
							gtCombinList[PortID].StockStatus   =  "新建" 								--状态
							gtCombinList[PortID].FutureStatus  =  "新建" 								--状态
							InventoryListTable(PortID)
							SaveCombinData(PortID,gtCombinList[PortID])

							Notice(PortID,"新建","新建")
						end
					end
				end

			elseif OC == "1" then

				local StockOrder = CheckStock("自动并确认",PortID,"Close") -- 检查股票
				if StockOrder.submitFlag then
					local FutureOrder = CheckFuture("自动并确认",PortID,"Close") -- 检查期货
					if FutureOrder.submitFlag then
						closeStock(PortID,StockOrder.order); -- 买入组合
						closeFuture(PortID,FutureOrder.order) -- 卖出期货

						gtCombinList[PortID].StockStatus  =   "平仓" 								--状态
						gtCombinList[PortID].FutureStatus  =  "平仓" 								--状态
						InventoryListTable(PortID)
						SaveCombinData(PortID,gtCombinList[PortID])
					end
				end

			end
		else
			if OC == "0" then
				gtCombinList[PortID].StockStatus  =   "新建" 								--状态
				gtCombinList[PortID].FutureStatus  =  "新建" 								--状态
				InventoryListTable(PortID)
				SaveCombinData(PortID,gtCombinList[PortID])

			elseif OC == "1" then
				gtCombinList[PortID].StockStatus  = gtSaveOld[PortID].oldStockStatus 								--状态
				gtCombinList[PortID].FutureStatus  = gtSaveOld[PortID].oldFutureStatus 								--状态
				local log = sys_format("StockStatus = %s,FutureStatus = %s",gtCombinList[PortID].StockStatus,gtCombinList[PortID].FutureStatus)
				_WriteErrorLog(log)

				InventoryListTable(PortID)
				SaveCombinData(PortID,gtCombinList[PortID])

			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

_OnEventDefined(VCancelOrder CancelOrderEvent)					--撤单
	if _InitializeFlag == 1 then
		local CancelIssue = CancelOrderEvent._GetFld("CancelIssue")

		if gtOrderList[gPortID] then
			if CancelIssue == "撤卖股票" then
			_WriteErrorLog("撤卖股票")
				for CorpCode,v in pairs(gtOrderList[gPortID].StockOpen) do
					local state = v.StatusFlag
					if state == "2" then
						local ret = PosCancelOrder(CorpCode)
						if not ret.Result then
							local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]撤单失败",gPortID,v.IssueCode,CorpCode)
							_WriteErrorLog(log)
						else
							--_WriteErrorLog("[%]撤单成功",CorpCode)
						end
					else
						local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]无可撤",gPortID,v.IssueCode,CorpCode)
						_WriteErrorLog(log)
					end
				end

			elseif CancelIssue == "撤买期货" then
			_WriteErrorLog("撤买期货")
				for CorpCode,v in pairs(gtOrderList[gPortID].FutureOpen) do
					local state = v.StatusFlag
					if state == "2" then
						local ret = PosCancelOrder(CorpCode)
						if not ret.Result then
							local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]撤单失败",gPortID,v.IssueCode,CorpCode)
							_WriteErrorLog(log)
						else
							--_WriteErrorLog("[%]撤单成功",CorpCode)
						end
					else
						local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]无可撤",gPortID,v.IssueCode,CorpCode)
						_WriteErrorLog(log)
					end
				end

			elseif CancelIssue == "撤买股票" then
			_WriteErrorLog("撤买股票")
			for CorpCode,v in pairs(gtOrderList[gPortID].StockClose) do
					local state = v.StatusFlag
					if state == "2" then
						local ret = PosCancelOrder(CorpCode)
						if not ret.Result then
							local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]撤单失败",gPortID,v.IssueCode,CorpCode)
							_WriteErrorLog(log)
						else
							--_WriteErrorLog("[%]撤单成功",CorpCode)
						end
					else
						local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]无可撤",gPortID,v.IssueCode,CorpCode)
						_WriteErrorLog(log)
					end
				end

			elseif CancelIssue == "撤卖期货" then
			_WriteErrorLog("撤卖期货")
			for CorpCode,v in pairs(gtOrderList[gPortID].FutureClose) do
					local state = v.StatusFlag
					if state == "2" then
						local ret = PosCancelOrder(CorpCode)
						if not ret.Result then
							local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]撤单失败",gPortID,v.IssueCode,CorpCode)
							_WriteErrorLog(log)
						else
							--_WriteErrorLog("[%]撤单成功",CorpCode)
						end
					else
						local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]无可撤",gPortID,v.IssueCode,CorpCode)
						_WriteErrorLog(log)
					end
				end

			else
				--_WriteErrorLog()
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

_OnEventDefined(VAllAmendOrder AllAmendOrderEvent) -- 追全单
	if _InitializeFlag == 1 then
		_WriteErrorLog("追单回调")
		local AllAmend = AllAmendOrderEvent._GetFld("AllAmend")
		if gtOrderList[gPortID] then
			if AllAmend == "追开单" then
			_WriteErrorLog("追开")
				for CorpCode,v in pairs(gtOrderList[gPortID].StockOpen) do
					local status = v.Status
					local statusFlag = v.StatusFlag

					if statusFlag == "2" then
						local WorkingQty = v.WorkingQuantity
						local WorkingQty1 = WorkingQty.toString()
						local issue = v.IssueCode
						if gtCombinList[gPortID] then
							if gtCombinList[gPortID].List[issue] then
								local stockPrice = gtCombinList[gPortID].List[issue].StockSell
								local stockTick = gtCombinList[gPortID].List[issue].StockSellTick

								local newPrice = GetOrderPrice(issue,0,WorkingQty1,stockPrice,stockTick) -- 股票委托价格
								local log = sys_format("CorpCode = %s,newPrice = %s",CorpCode,newPrice)
								_WriteErrorLog(log)
								local ret = PosAmendOrder(CorpCode,newPrice)
								if not ret.Result then
									local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]追单失败",gPortID,issue,CorpCode)
									_WriteErrorLog(log)
								else
									local log = sys_format("[%s]追单成功",CorpCode)
									_WriteErrorLog(log)
								end
							end
						end
					end
				end

				for CorpCode,v in pairs(gtOrderList[gPortID].FutureOpen) do
					local status = v.Status
					local statusFlag = v.StatusFlag

					if statusFlag == "2" then
						local WorkingQty   = v.WorkingQuantity -- 挂单数量
						local WorkingQty1 = WorkingQty.toString()
						local issue = v.IssueCode
						if gtCombinList[gPortID] then
							if gtCombinList[gPortID].Future == issue then
								local futurePrice = gtCombinList[gPortID].FutureBuy
								local futureTick = gtCombinList[gPortID].FutureBuyTick

								local newPrice = GetOrderPrice(issue,1,WorkingQty1,futurePrice,futureTick) -- 期货委托价格
								local log = sys_format("CorpCode = %s,newPrice = %s",CorpCode,newPrice)
								_WriteErrorLog(log)
								local ret = PosAmendOrder(CorpCode,newPrice)
								if not ret.Result then
									local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]追单失败",gPortID,issue,CorpCode)
									_WriteErrorLog(log)
								else
									local log = sys_format("[%s]追单成功",CorpCode)
									_WriteErrorLog(log)
								end
							end
						end
					end
				end

			elseif AllAmend == "追平单" then
			_WriteErrorLog("追平")
				for CorpCode,v in pairs(gtOrderList[gPortID].StockClose) do
					local status = v.Status
					local statusFlag = v.StatusFlag

					if statusFlag == "2" then
						local WorkingQty   = v.WorkingQuantity -- 挂单数量
						local WorkingQty1 = WorkingQty.toString()
						local issue = v.IssueCode
						if gtCombinList[gPortID] then
							if gtCombinList[gPortID].List[issue] then
								local stockPrice = gtCombinList[gPortID].List[issue].StockBuy
								local stockTick = gtCombinList[gPortID].List[issue].StockBuyTick

								local newPrice = GetOrderPrice(issue,1,WorkingQty1,stockPrice,stockTick) -- 股票委托价格
								local log = sys_format("CorpCode = %s,newPrice = %s",CorpCode,newPrice)
								_WriteErrorLog(log)
								local ret = PosAmendOrder(CorpCode,newPrice)
								if not ret.Result then
									local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]追单失败",gPortID,issue,CorpCode)
									_WriteErrorLog(log)
								else
									local log = sys_format("[%s]追单成功",CorpCode)
									_WriteErrorLog(log)
								end
							end
						end
					end
				end

				for CorpCode,v in pairs(gtOrderList[gPortID].FutureClose) do
					local status = v.Status
					local statusFlag = v.StatusFlag

					if statusFlag == "2" then
						local WorkingQty   = v.WorkingQuantity -- 挂单数量
						local WorkingQty1 = WorkingQty.toString()
						local issue = v.IssueCode
						if gtCombinList[gPortID] then
							if issue == gtCombinList[gPortID].Future then
								local futurePrice = gtCombinList[gPortID].FutureSell
								local futureTick = gtCombinList[gPortID].FutureSellTick

								local newPrice = GetOrderPrice(issue,0,WorkingQty1,futurePrice,futureTick) -- 期货委托价格
								local log = sys_format("CorpCode = %s,newPrice = %s",CorpCode,newPrice)
								_WriteErrorLog(log)
								local ret = PosAmendOrder(CorpCode,newPrice)
								if not ret.Result then
									local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]追单失败",gPortID,issue,CorpCode)
									_WriteErrorLog(log)
								else
									local log = sys_format("[%s]追单成功",CorpCode)
									_WriteErrorLog(log)
								end
							end
						end
					end
				end
			else

			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

_OnEventDefined(VAmendOrder AmendOrderEvent) -- 追单
	if _InitializeFlag == 1 then
		local AmendIssue = AmendOrderEvent._GetFld("AmendIssue")

		if gtOrderList[gPortID] then

			if AmendIssue == "开追股票" then
			_WriteErrorLog("开追股票")
				for CorpCode,v in pairs(gtOrderList[gPortID].StockOpen) do
					local status = v.Status
					local statusFlag = v.StatusFlag
					if statusFlag == "2" then
						local WorkingQty = v.WorkingQuantity
						local WorkingQty1 = WorkingQty.toString()
						local issue = v.IssueCode
						if gtCombinList[gPortID] then
							if gtCombinList[gPortID].List[issue] then
								local stockPrice = gtCombinList[gPortID].List[issue].StockSell
								local stockTick = gtCombinList[gPortID].List[issue].StockSellTick
								local log1 = sys_format("开追股票：取价方式 = %s,stockTick[%s],WorkingQty1[%s]",stockPrice,stockTick,WorkingQty1)
								_WriteErrorLog(log1)

								local newPrice = GetOrderPrice(issue,0,WorkingQty1,stockPrice,stockTick) -- 股票委托价格
								local log = sys_format("CorpCode = %s,newPrice = %s",CorpCode,newPrice)
								_WriteErrorLog(log)
								local ret = PosAmendOrder(CorpCode,newPrice)
								if not ret.Result then
									local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]追单失败",gPortID,issue,CorpCode)
									_WriteErrorLog(log)
								else
									local log = sys_format("[%s]追单成功",CorpCode)
									_WriteErrorLog(log)
								end
							end
						end
					end
				end

			elseif AmendIssue == "平追股票" then
			_WriteErrorLog("平追股票")
				for CorpCode,v in pairs(gtOrderList[gPortID].StockClose) do
					local status = v.Status
					local statusFlag = v.StatusFlag
					if statusFlag == "2" then
						local WorkingQty   = v.WorkingQuantity -- 挂单数量
						local WorkingQty1 = WorkingQty.toString()
						local issue = v.IssueCode
						if gtCombinList[gPortID] then
							if gtCombinList[gPortID].List[issue] then
								local stockPrice = gtCombinList[gPortID].List[issue].StockBuy
								local stockTick = gtCombinList[gPortID].List[issue].StockBuyTick

								local log1 = sys_format("平追股票：取价方式 = %s",stockPrice)
								_WriteErrorLog(log1)

								local newPrice = GetOrderPrice(issue,1,WorkingQty1,stockPrice,stockTick) -- 股票委托价格
								local log = sys_format("CorpCode = %s,newPrice = %s",CorpCode,newPrice)
								_WriteErrorLog(log)
								local ret = PosAmendOrder(CorpCode,newPrice)
								if not ret.Result then
									local log = sys_format("gPortID：[%s]，issue：[%s]，[%s]追单失败",gPortID,issue,CorpCode)
									_WriteErrorLog(log)
								else
									local log = sys_format("[%s]追单成功",CorpCode)
									_WriteErrorLog(log)
								end
							end
						end
					end
				end
			elseif AmendIssue == "开追期货" then
			_WriteErrorLog("开追期货")
				for CorpCode,v in pairs(gtOrderList[gPortID].FutureOpen) do
					local status = v.Status
					local statusFlag = v.StatusFlag
					if statusFlag == "2" then
						local WorkingQty   = v.WorkingQuantity -- 挂单数量
						local WorkingQty1 = WorkingQty.toString()
						local issue = v.IssueCode
						if gtCombinList[gPortID] then
							if issue == gtCombinList[gPortID].Future then
								local futurePrice = gtCombinList[gPortID].FutureBuy
								local futureTick = gtCombinList[gPortID].FutureBuyTick

								local log1 = sys_format("开追期货:取价方式 = %s",futurePrice)
								_WriteErrorLog(log1)

								local newPrice = GetOrderPrice(issue,1,WorkingQty1,futurePrice,futureTick) -- 期货委托价格
								local log = sys_format("CorpCode = %s,newPrice = %s",CorpCode,newPrice)
								_WriteErrorLog(log)
								PosAmendOrder(CorpCode,newPrice)
							end
						end
					end
				end

			elseif AmendIssue == "平追期货" then
			_WriteErrorLog("平追期货")
				for CorpCode,v in pairs(gtOrderList[gPortID].FutureClose) do
					local status = v.Status
					local statusFlag = v.StatusFlag
					if statusFlag == "2" then
						local WorkingQty   = v.WorkingQuantity -- 挂单数量
						local WorkingQty1 = WorkingQty.toString()
						local issue = v.IssueCode
						if gtCombinList[gPortID] then
							if issue == gtCombinList[gPortID].Future then
								local futurePrice = gtCombinList[gPortID].FutureSell
								local futureTick = gtCombinList[gPortID].FutureSellTick

								local log1 = sys_format("平追期货:取价方式 = %s,futureTick[%s],WorkingQty1[%s]",futurePrice,futureTick,WorkingQty1)
								_WriteErrorLog(log1)

								local newPrice = GetOrderPrice(issue,0,WorkingQty1,futurePrice,futureTick) -- 期货委托价格
								local log = sys_format("CorpCode = %s,newPrice = %s",CorpCode,newPrice)
								_WriteErrorLog(log)
								PosAmendOrder(CorpCode,newPrice)
							end
						end
					end
				end
			else
				--_WriteErrorLog()
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

--------------------------------------------------------------------------------------
--输入成交逻辑处理
--------------------------------------------------------------------------------------

_OnEventDefined(VInputExecution inputExecutionEvent)
	if _InitializeFlag ~= 1 then	-- 第一次刷新完成
		sendLog("请等待程序启动完毕再操作!");
	else
		local issueCode = inputExecutionEvent._GetFld("IssueCode");
		local bs = inputExecutionEvent._GetFld("BuySell");
		local buySell = "";
		local log = "";
		local validDataFlag = true;
		if issueCode == "" or (not _PosIssueMarketTable[issueCode]) then
			sendLog("输入成交的合约不存在！");
			validDataFlag = false;
		end
		local oc = inputExecutionEvent._GetFld("OpenClose");
		local openClose = -1;
		if oc == "开仓" then
			openClose = 0;
		elseif oc == "平仓" then
			openClose = 1;
		else
			sendLog("输入成交的开平仓错误！");
			validDataFlag = false;
		end

		if bs == "普通买入"then
			buySell = "3";
		elseif bs == "普通卖出" then
			buySell = "1";
		elseif bs == "融券卖出" then
			buySell = "1";
			openClose = 4
		elseif bs == "买券还券" then
			buySell = "3";
			openClose = 5
		else
			sendLog("输入成交的买卖错误！");
			validDataFlag = false;
		end


		local price = inputExecutionEvent._GetFld("Price");
		if price == "" or price <= 0 then
			sendLog("输入成交的价格错误！");
			validDataFlag = false;
		end
		local quantity = inputExecutionEvent._GetFld("Quantity");
		if quantity == "" or quantity <= 0 then
			sendLog("输入成交的数量错误！");
			validDataFlag = false;
		end
		local portID = inputExecutionEvent._GetFld("PortID");
		if portID == "" then
			sendLog("输入成交的组合编号错误！");
			validDataFlag = false;
		end
		local execDate = inputExecutionEvent._GetFld("ExecDate");
		_WriteErrorLog(execDate)
		if execDate ~= "T" and execDate ~= "T-1" then
			sendLog("输入成交日期错误！");
			validDataFlag = false;
		else
			execDate = DateFormat(execDate)
		end
		_WriteErrorLog(execDate)
		if not gtCombinList[portID] then
			sendLog("输入下单组合号不存在对应套利组合！");
			validDataFlag = false;
		end
		if validDataFlag then
			local logs = sys_format("内部下单：%s%s%s，数量%s,价格%s",issueCode,bs,oc,quantity,price);
			_WriteErrorLog(logs);
			sendLog(logs,portID);
			internalExecution(issueCode,buySell,openClose,quantity,price,execDate,portID);
		end
	end
_End;
function DateFormat(line)
	if line == "T" then
		return nil
	else
		return _PosTradingDate[1]
	end
end
--模拟成交Unikey
function CreateUKey(msgType)
	local nowTime = GetHMS()
	gUKeySeq = gUKeySeq or 0
	gUKeySeq = gUKeySeq + 1
	return sys_format("%3s0%s%010d", msgType, nowTime, gUKeySeq)
end
function GetHMS()
	local DTSTime nowtime = _GetNowTime();
	local smtime = nowtime.asString("%H%M%S");
	return smtime
end
--内部成交新下单接口修改
function internalExecution(issueCode,buySell,openClose,quantity,price,execDate,portID)
	local baMapID = "";
	local productCode = _PosIssueProductCodeTable[issueCode];
	if productCode == "10" or productCode == "03" or productCode == "02" then	--证券
		baMapID = gMarginbaMapID;
	else	--期货
		baMapID = gFuturebaMapID;
	end

	--修正下单的控制权限DealerID
	local dealerID = _PosGetBAMapID2UserID(baMapID)
	local _String strDealerID = dealerID

	local accountCode = _PosBAMapAccount[baMapID]
	local fundStatus = _PosFundStatus[accountCode]
	local checkflag = true
	if fundStatus then

	else
		local internalLog = sys_format("内部成交：无子账户[%s]对应的资金账户",baMapID)
		_WriteErrorLog(internalLog)
		sendLog(internalLog);
		checkflag = false
	end

	--通过portID生成baSubID
	local baSubID = "";
	if (openClose == 0 and buySell == "3") or (openClose == 1 and buySell == "1") then	--买开或卖平
		baSubID = "3"..portID;	--多头
	elseif (openClose == 0 and buySell == "1") or (openClose == 1 and buySell == "3") then	--卖开或买平
		baSubID = "1"..portID;	--空头
	elseif (openClose == 4 and buySell == "1") or (openClose == 5 and buySell == "3") then --融资卖出开仓or买券还券平仓
		baSubID = "1"..portID;
	else
		_WriteErrorLog("BaSubID Error!")
		sendLog("BaSubID Error!");
		checkflag = false
	end
	if openClose == 1 or openClose == 2 or openClose == 5 then--如果是平仓，检查可用数量
		local avlQty = 0
		local posKey = baMapID .. "." .. baSubID .. "." .. issueCode
		local position = _PosPositionTable[posKey]
		if position then
			avlQty = position.AvlQuantity
		end
		if avlQty < quantity then
			local log = sys_format("内部成交失败: 持仓 [ %s ] 可用数量 [ %s ] 小于平仓数量 [ %s ]", posKey, avlQty, quantity)
			sendLog(log)
			checkflag = false
		end
	end

	if checkflag == true then
		local execKey = nil
		local creRed = 0--内部成交暂时用0,只支持普通的买卖
		if execDate then
			execKey = CreateUKey("L18")
		end
		local ret = _PosMoveInternalExecution(baMapID, baSubID, issueCode,buySell,openClose,quantity,price,execDate,execKey, nil, creRed,gHedgeFlag)
		if not ret.Result then
			logs = ret.Reason;
			sendLog(logs);
			return
		end
	end
	return true
end


_OnEventDefined(VMtPosLogic mtPosLogicEvent)	--柜台持仓清仓逻辑
	_WriteErrorLog("MtPosLogic")
	if _InitializeFlag == 1 then
		local IssueList = mtPosLogicEvent._GetFld("IssueList");
		local QtyList = mtPosLogicEvent._GetFld("QtyList");
		local price = mtPosLogicEvent._GetFld("Price");
		local tick = mtPosLogicEvent._GetFld("Tick");
		--_WriteErrorLog(IssueList)
		--_WriteErrorLog(price)
		--_WriteErrorLog(tick)
		local templist = getNameAndValue(IssueList)
		local qtylist = getNameAndValue(QtyList)
		local condition = sys_sub(gMarginbaMapID,1,-4)
		local tempbamapid = condition .. "999"			--柜台持仓委托使用-999子账号
		local bamapID = gMarginbaMapID
		if _PosBAMapAccount[tempbamapid] then
			bamapID = tempbamapid
		end
		local AccountCode = _PosBAMapAccount[bamapID]
		local InvestorID = _PosFundStatus[AccountCode].InvestorID
		--_WriteErrorLog(bamapID)
		--_WriteErrorLog(AccountCode)
		--_WriteErrorLog(InvestorID)
		if templist and qtylist then
			for i ,issueCode in pairs (templist) do
				_WriteErrorLog(issueCode)
				if qtylist[i] then
					local quantity = qtylist[i].getNumberValue();
					_WriteErrorLog(quantity)
					if quantity > 0 then
						local basubID = "1"
						local bs = "3"
						local oc = 5
						local Price = GetOrderPrice(issueCode,oc,quantity,price,tick)
						if Price ~= 0 then
							local logs = sys_format("FireEvent:basubID:%s,BAMapID:%s, issue:%s,BuySell:%s,OpenClose:%s,quantity:%d",basubID,bamapID,issueCode,bs,oc,quantity)
							_WriteErrorLog(logs)
							log = sys_format("柜台清仓:下单合约:[%s],下单数量:[%s],价格:[%s],方向:[%s]",issueCode,quantity,Price,"买券还券平仓")
							sendLog(log)
							local ret = SubmitSingleOrder(bamapID,basubID,issueCode,bs,oc, Price,quantity, 0, "",nil,gHedgeFlag);
							if ret.Result then
								--local log = sys_format("下单成功")
								--sendLog(log,gPortID)
							else
								local log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
								_WriteErrorLog(log)
								log = sys_format("下单错误原因：[%s]",ret.Reason)
								sendLog(log,gPortID)
							end
						else
							log = sys_format("组合号:[%s],下单合约:[%s]获取不到行情，请稍后再试!",gPortID,issueCode)
							sendLog(log,gPortID)
						end
					end
				end
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End;
_OnEventDefined(VClearIFPos clearifPosEvent)	--期货柜台持仓清仓逻辑
	_WriteErrorLog("ClearIFPos")
	if _InitializeFlag == 1 then
		local issueCode = clearifPosEvent._GetFld("IssueCode");
		local BuySell = clearifPosEvent._GetFld("BuySell");
		local Qty = clearifPosEvent._GetFld("Qty");
		local price = clearifPosEvent._GetFld("Price");
		local tick = clearifPosEvent._GetFld("Tick");
		_WriteErrorLog(issueCode)
		_WriteErrorLog(BuySell)
		_WriteErrorLog(Qty)
		_WriteErrorLog(price)
		_WriteErrorLog(tick)
		local condition = sys_sub(gFuturebaMapID,1,-4)
		local tempbamapid = condition .. "999"			--柜台持仓委托使用-999子账号
		local bamapID = gFuturebaMapID
		if _PosBAMapAccount[tempbamapid] then
			bamapID = tempbamapid
		end
		local AccountCode = _PosBAMapAccount[bamapID]
		local InvestorID = _PosFundStatus[AccountCode].InvestorID
		local quantity = Qty.getNumberValue();
		if quantity > 0 then
			local basubID = "3"
			local bs = "1"
			local oc = 1
			local Price = GetOrderPrice(issueCode,oc,quantity,price,tick)
			local BSStr = "卖平仓"
			if BuySell ~= "买" then
				basubID = "1"
				bs = "3"
				Price = GetOrderPrice(issueCode,0,quantity,price,tick)
				BSStr = "买平仓"
			end
			if Price ~= 0 then
				local logs = sys_format("FireEvent:basubID:%s,BAMapID:%s, issue:%s,BuySell:%s,OpenClose:%s,quantity:%d",basubID,bamapID,issueCode,bs,oc,quantity)
				_WriteErrorLog(logs)
				log = sys_format("快捷平仓:下单合约:[%s],下单数量:[%s],价格:[%s],方向:[%s]",issueCode,quantity,Price,BSStr)
				sendLog(log)
				local ret = SubmitSingleOrder(bamapID,basubID,issueCode,bs,oc, Price,quantity, 0, "",nil,gHedgeFlag);
				if ret.Result then
					--local log = sys_format("下单成功")
					--sendLog(log,gPortID)
				else
					local log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
					_WriteErrorLog(log)
					log = sys_format("下单错误原因：[%s]",ret.Reason)
					sendLog(log,gPortID)
				end
			else
				log = sys_format("快速平仓:下单合约:[%s]获取不到行情，请稍后再试!",issueCode)
				sendLog(log,gPortID)
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End;
function getNameAndValue(line)
	local lin = line
	local logs = sys_format("getNameAndValue line = [%s]",lin);
	_WriteErrorLog(logs);

	local len = sys_len(line);
	if len > 1 then
		local rtn = {}
		local str = 1;
		for i = 1, len do
			local chr = sys_sub(line, i, i)
			if chr == "," then
				sys_insert(rtn, sys_sub(line, str, i-1))
				str = i + 1;
			end
		end
		return rtn
	end
	return nil
end
--行情回调
_OnEventPrice(_PriceName="MyPrice", {} , DTSPrice price);
	local issueCode = price.getIssueCode()
	local priceInfo = _PosPriceTable[issueCode]
	local Flag = 0
	if not priceInfo then --可能由于外部策略订阅，价格在持仓初始化完成前先来了，还是要记录下来
		--_WriteErrorLog("有没_PosPriceTable表")
		_PosPriceTable[issueCode] = {}
		priceInfo = _PosPriceTable[issueCode]

	end
	if not _Querylist[issueCode] then
		_Querylist[issueCode] = 1
		Flag = 1
	end
	local tick = _PosIssuePriceTickTable[issueCode]
	if _PosNeedAdjPrice then
		priceInfo.LastPrice = price.getEstLastPrice()
		priceInfo.LastTime = price.getLastVolumeTimeStamp();
		priceInfo.AskPrice6 = _PosPriceToNumber(price.getAskPrice_6(), tick)
		priceInfo.AskPrice7 = _PosPriceToNumber(price.getAskPrice_7(), tick)
		priceInfo.AskPrice8 = _PosPriceToNumber(price.getAskPrice_8(), tick)
		priceInfo.AskPrice9 = _PosPriceToNumber(price.getAskPrice_9(), tick)
		priceInfo.AskPrice10 = _PosPriceToNumber(price.getAskPrice_10(), tick)
		priceInfo.BidPrice6 = _PosPriceToNumber(price.getBidPrice_6(), tick)
		priceInfo.BidPrice7 = _PosPriceToNumber(price.getBidPrice_7(), tick)
		priceInfo.BidPrice8 = _PosPriceToNumber(price.getBidPrice_8(), tick)
		priceInfo.BidPrice9 = _PosPriceToNumber(price.getBidPrice_9(), tick)
		priceInfo.BidPrice10 = _PosPriceToNumber(price.getBidPrice_10(), tick)
		priceInfo.AskQuantity6 = _PosQuantityToNumber(price.getAskQty_6())
		priceInfo.AskQuantity7 = _PosQuantityToNumber(price.getAskQty_7())
		priceInfo.AskQuantity8 = _PosQuantityToNumber(price.getAskQty_8())
		priceInfo.AskQuantity9 = _PosQuantityToNumber(price.getAskQty_9())
		priceInfo.AskQuantity10 = _PosQuantityToNumber(price.getAskQty_10())
		priceInfo.BidQuantity6 = _PosQuantityToNumber(price.getBidQty_6())
		priceInfo.BidQuantity7 = _PosQuantityToNumber(price.getBidQty_7())
		priceInfo.BidQuantity8 = _PosQuantityToNumber(price.getBidQty_8())
		priceInfo.BidQuantity9 = _PosQuantityToNumber(price.getBidQty_9())
		priceInfo.BidQuantity10 = _PosQuantityToNumber(price.getBidQty_10())
	end
	if _QueryIssue == issueCode or Flag == 1 then
		if _PosPriceTable[issueCode] then
			local PriceInfo = _PosPriceTable[issueCode]
			local issueName = _PosIssueNameTable[issueCode]
			local LastPrice = PriceInfo.LastPrice or 0
			local AskPrice1 = PriceInfo.AskPrice1 or 0
			local AskPrice2 = PriceInfo.AskPrice2 or 0
			local AskPrice3 = PriceInfo.AskPrice3 or 0
			local AskPrice4 = PriceInfo.AskPrice4 or 0
			local AskPrice5 = PriceInfo.AskPrice5 or 0
			local BidPrice1 = PriceInfo.BidPrice1 or 0
			local BidPrice2 = PriceInfo.BidPrice2 or 0
			local BidPrice3 = PriceInfo.BidPrice3 or 0
			local BidPrice4 = PriceInfo.BidPrice4 or 0
			local BidPrice5 = PriceInfo.BidPrice5 or 0
			local AskQuantity1 = PriceInfo.AskQuantity1 or 0
			local AskQuantity2 = PriceInfo.AskQuantity2 or 0
			local AskQuantity3 = PriceInfo.AskQuantity3 or 0
			local AskQuantity4 = PriceInfo.AskQuantity4 or 0
			local AskQuantity5 = PriceInfo.AskQuantity5 or 0
			local BidQuantity1 = PriceInfo.BidQuantity1 or 0
			local BidQuantity2 = PriceInfo.BidQuantity2 or 0
			local BidQuantity3 = PriceInfo.BidQuantity3 or 0
			local BidQuantity4 = PriceInfo.BidQuantity4 or 0
			local BidQuantity5 = PriceInfo.BidQuantity5 or 0
			local UpLimitPrice = PriceInfo.UpLimitPrice or 0
			local LowLimitPrice = PriceInfo.LowLimitPrice or 0
			local fttotalAskQty = AskQuantity1 + AskQuantity2 + AskQuantity3 + AskQuantity4 + AskQuantity5
			if fttotalAskQty ~= 0 then
				fttotalAskQty = sys_format("%d",fttotalAskQty);
			else
				fttotalAskQty = "-"
			end
			PriceInfo.totalAskQty = fttotalAskQty
			local fttotalBidQty = BidQuantity1 + BidQuantity2 + BidQuantity3 + BidQuantity4 + BidQuantity5
			if fttotalBidQty ~= 0 then
				fttotalBidQty = sys_format("%d", fttotalBidQty);
			else
				fttotalBidQty = "-"
			end
			--hongwen.kang20120508
			if LastPrice == 0 then
				LastPrice = "-"
			end
			if AskPrice1 == 0 then
				AskPrice1 = "-"
			end
			if AskPrice2 == 0 then
				AskPrice2 = "-"
			end
			if AskPrice3 == 0 then
				AskPrice3 = "-"
			end
			if AskPrice4 == 0 then
				AskPrice4 = "-"
			end
			if AskPrice5 == 0 then
				AskPrice5 = "-"
			end
			if BidPrice1 == 0 then
				BidPrice1 = "-"
			end
			if BidPrice2 == 0 then
				BidPrice2 = "-"
			end
			if BidPrice3 == 0 then
				BidPrice3 = "-"
			end
			if BidPrice4 == 0 then
				BidPrice4 = "-"
			end
			if BidPrice5 == 0 then
				BidPrice5 = "-"
			end
			PriceInfo.totalBidQty = fttotalBidQty
			local totalAskQty = PriceInfo.totalAskQty
			local totalBidQty = PriceInfo.totalBidQty
			AskQuantity1  = sys_format("%.0f",AskQuantity1)
			AskQuantity2  = sys_format("%.0f",AskQuantity2)
			AskQuantity3  = sys_format("%.0f",AskQuantity3)
			AskQuantity4  = sys_format("%.0f",AskQuantity4)
			AskQuantity5  = sys_format("%.0f",AskQuantity5)
			BidQuantity1  = sys_format("%.0f",BidQuantity1)
			BidQuantity2  = sys_format("%.0f",BidQuantity2)
			BidQuantity3  = sys_format("%.0f",BidQuantity3)
			BidQuantity4  = sys_format("%.0f",BidQuantity4)
			BidQuantity5  = sys_format("%.0f",BidQuantity5)
			local DTSEvent BaseEvent=_CreateEventObject("VBasePriceEvent");
			BaseEvent._SetFld("IssueCode",issueCode);
			BaseEvent._SetFld("IssueShortName",issueName);
			BaseEvent._SetFld("LastPrice",LastPrice);
			BaseEvent._SetFld("AskPrice_1",AskPrice1);
			BaseEvent._SetFld("AskPrice_2",AskPrice2);
			BaseEvent._SetFld("AskPrice_3",AskPrice3);
			BaseEvent._SetFld("AskPrice_4",AskPrice4);
			BaseEvent._SetFld("AskPrice_5",AskPrice5);
			BaseEvent._SetFld("BidPrice_1",BidPrice1);
			BaseEvent._SetFld("BidPrice_2",BidPrice2);
			BaseEvent._SetFld("BidPrice_3",BidPrice3);
			BaseEvent._SetFld("BidPrice_4",BidPrice4);
			BaseEvent._SetFld("BidPrice_5",BidPrice5);
			BaseEvent._SetFld("AskQty_1",AskQuantity1);
			BaseEvent._SetFld("AskQty_2",AskQuantity2);
			BaseEvent._SetFld("AskQty_3",AskQuantity3);
			BaseEvent._SetFld("AskQty_4",AskQuantity4);
			BaseEvent._SetFld("AskQty_5",AskQuantity5);
			BaseEvent._SetFld("BidQty_1",BidQuantity1);
			BaseEvent._SetFld("BidQty_2",BidQuantity2);
			BaseEvent._SetFld("BidQty_3",BidQuantity3);
			BaseEvent._SetFld("BidQty_4",BidQuantity4);
			BaseEvent._SetFld("BidQty_5",BidQuantity5);
			BaseEvent._SetFld("UpperLimitPrice",UpLimitPrice);
			BaseEvent._SetFld("LowerLimitPrice",LowLimitPrice);
			BaseEvent._SetFld("TotalAskQty",totalAskQty);
			BaseEvent._SetFld("TotalBidQty",totalBidQty);
			_SendToClients(BaseEvent);
		end
	end


	if gtCombinList[gPortID] then
		local Futrue = gtCombinList[gPortID].Future
		if Futrue == issueCode then
			InventoryListTable(gPortID)
			FutureAllTable(gPortID)
			--显示基差敞口
			BasisBets(gPortID,"期货")
			ShowBasisBets("期货")
		elseif issueCode == "M000300" then
			--显示基差敞口
			BasisBets(gPortID,"沪深300")
			ShowBasisBets("沪深300")
		end
		if gtCombinList[gPortID].List[issueCode] then
			--刷新当前组合下的单个合约数据
			StockAllTable(gPortID,issueCode)
		end
	end

	if gFutureList[issueCode] or issueCode == "M000300" then
		IF(issueCode) -- 条件开仓
	end
_End

-- 期货移仓事件处理
_OnEventDefined(VMoveStockIndexFuture moveExecution)
	_WriteErrorLog("MoveStockIndexFuture");

	if _InitializeFlag ~= 1 then	-- 第一次刷新完成
		sendLog("请等待程序启动完毕再操作!",gPortID);
	else
		local issueCode = moveExecution._GetFld("IssueCode");
		local issueCode2 = moveExecution._GetFld("IssueCode2");
		local side = moveExecution._GetFld("Side");
		local portID = moveExecution._GetFld("PortID");
		local qty = moveExecution._GetFld("Quantity");
		local moveQty = moveExecution._GetFld("MoveQuantity")
		local oc = moveExecution._GetFld("OC")
		local price1 = moveExecution._GetFld("Price1")
		local price2 = moveExecution._GetFld("Price2")
		local tick1 = moveExecution._GetFld("tick1")
		local tick2 = moveExecution._GetFld("tick2")

		gtMoveFuture[portID] = gtMoveFuture[portID] or {}
		gtMoveFuture[portID].IssueCode     = issueCode
		gtMoveFuture[portID].IssueCode2    = issueCode2
		gtMoveFuture[portID].Quantity      = qty
		gtMoveFuture[portID].MoveQuantity  = moveQty
		gtMoveFuture[portID].Price1        = price1
		gtMoveFuture[portID].Price2 	   = price2
		gtMoveFuture[portID].Tick1         = tick1
		gtMoveFuture[portID].Tick2         = tick2
		gtMoveFuture[portID].OC            = oc
		gtMoveFuture[portID].Side          = side

		local logss = sys_format("当前合约[%s];展期合约[%s];持仓状态[%s];组合号[%s];持仓量[%s];移动量[%s];开平方式[%s];平仓价[%s];开仓价[%s];tick1[%s];tick2[%s];",issueCode,issueCode2,side,portID,qty,moveQty,oc,price1,price2,tick1,tick2);
		_WriteErrorLog(logss)
		local logs = sys_format("期货移仓 合约代码:%s, 多空:%s, 持仓数量:%s,移动数量:%s, 组合编号:%s 到新合约:%s.",issueCode,side,qty,moveQty,portID,issueCode2);
		sendLog(logs,portID)

		if qty >= moveQty then
			qty = moveQty

			if (not issueCode) or (not issueCode2) or (issueCode == "") or (issueCode2 == "") then
				sendLog("移仓的合约代码无效，不能移动！",portID);
			elseif issueCode == issueCode2 then
				sendLog("移仓的合约代码前后一样，不能移动！",portID);
			elseif qty < 1 then
				sendLog("无仓位可以移，不能移动！",portID);
			else
				local p1 = _PosIssueProductCodeTable[issueCode];
				local p2 = _PosIssueProductCodeTable[issueCode2];
				if (p1 ~= "31") or (p2 ~= "31") then
					sendLog("移仓的合约代码不是股指期货代码，不能移动！",portID);
				elseif (issueCode2 ~= gFutureCurrent) and (issueCode2 ~= gFutureNextMonth) and (issueCode2 ~= gFutureSeasonMonth) and (issueCode2 ~= gFutureNextSeason) then
					sendLog("移仓的合约代码不可交易，不能移动！",portID);
				else
					local preID = nil;
					if side == "买" then
						preID = "3";
					elseif  side == "卖" then
						preID = "1";
					elseif (side ~= "买" and side ~= "卖") then
						local logs = sys_format("证券/合约多空无效，代码:%s,多空:%s.",issueCode,side);
						sendLog(logs,portID);
					else
						preID = side;
					end
					if preID then
						local bamapid = gFuturebaMapID;
						local posKey = gFuturebaMapID .. "." .. preID .. portID .. "." .. issueCode ;
						local pos = _PosPositionTable[posKey];
						bool okFlag = true;
						if (not pos) then
							okFlag = false;
						else
							if pos.AvlQuantity < 1 then
								okFlag = false;
							end
						end
						if okFlag then
							shiftIFPosition(gtMoveFuture[portID],portID) -- 期货移仓
							sendLog("请刷新后确认！",portID);
						else
							local logs = sys_format("所选合约无有效数量，请刷新后，确认有持仓才可以移动，代码:%s,key:%s.",issueCode,posKey);
							sendLog(logs,portID);
						end
					end
				end
			end
		else
			sendLog("移动数量大于持仓量,移动无效",portID)
		end
	end

_End

function shiftIFPosition(order,portID)
	local BS
	local BS2

	if order.Side ~= "买" then
		BASubID = "1" .. portID
		BS = 0
		BS2 = 1
	elseif order.Side ~= "卖" then
		BASubID = "3" .. portID
		BS = 1
		BS2 = 0
	end

	if order.OC == "开平同时" then
		price  = GetOrderPrice(order.IssueCode,BS,order.Quantity,order.Price1,order.Tick1)
		price2 = GetOrderPrice(order.IssueCode2,BS2,order.MoveQuantity,order.Price2,order.Tick2)

		if order.Side ~= "买" then
			_WriteErrorLog("开平同时 -- 空头仓位")
			local ret = PosSubmitSingleOrder(gFuturebaMapID, BASubID, order.IssueCode, "3", 1, price, order.Quantity, 0, "",nil,gHedgeFlag)
			if ret.Result then
				gtCombinList[gPortID].Future = order.IssueCode2
				ClearFutureOpenClose()
				Refresh(portID) -- 刷 表
				PosSubmitSingleOrder(gFuturebaMapID, BASubID, order.IssueCode2, "1", 0, price2, order.MoveQuantity, 0, "",nil,gHedgeFlag)
			else
				sendLog(ret.Reason,portID)
			end

		elseif order.Side ~= "卖" then
			_WriteErrorLog("开平同时 -- 多头仓位")
			local ret = PosSubmitSingleOrder(gFuturebaMapID, BASubID, order.IssueCode, "1", 1, price, order.Quantity, 0, "",nil,gHedgeFlag)
			if ret.Result then
				gtCombinList[gPortID].Future = order.IssueCode2
				ClearFutureOpenClose()
				Refresh(portID) -- 刷 表
				PosSubmitSingleOrder(gFuturebaMapID, BASubID, order.IssueCode2, "3", 0, price2, order.MoveQuantity, 0, "",nil,gHedgeFlag)
			else
				sendLog(ret.Reason,portID)
			end
		end

	else

		gSubmitNo = gSubmitNo + 1;
		local strSubmitNo = sys_format("%05d",gSubmitNo); --格式化成3位

		local tOtherSide = {};
		price2 = GetOrderPrice(order.IssueCode2,BS2,order.MoveQuantity,order.Price2,order.Tick2)
		if order.OC == "开仓优先" then
			if order.Side ~= "买" then
				tOtherSide.BAMapID = gFuturebaMapID;
				tOtherSide.IssueCode = order.IssueCode;
				tOtherSide.BASubID = BASubID
				tOtherSide.Side = "3";
				tOtherSide.OpenClose = 1;
				tOtherSide.BS = BS;
				tOtherSide.Quantity = order.Quantity;
				tOtherSide.Price = order.Price1;
				tOtherSide.Tick = order.Tick1

				gtMoveFutureList[strSubmitNo] = gtMoveFutureList[strSubmitNo] or {}
				gtMoveFutureList[strSubmitNo].tOtherSide = gtMoveFutureList[strSubmitNo].tOtherSide or {}
				gtMoveFutureList[strSubmitNo].tOtherSide = tOtherSide

				local ret = PosSubmitSingleOrder(gFuturebaMapID, BASubID, order.IssueCode2, "1", 0, price2, order.MoveQuantity, 0, "",strSubmitNo,gHedgeFlag)
				if ret.Result then
					gtCombinList[portID].Future = order.IssueCode2
					ClearFutureOpenClose()
					Refresh(portID) -- 刷 表
				else
					sendLog(ret.Reason,portID)
				end


			else -- ~=卖
				tOtherSide.BAMapID = gFuturebaMapID;
				tOtherSide.IssueCode = order.IssueCode;
				tOtherSide.BASubID = BASubID
				tOtherSide.Side = "1";
				tOtherSide.OpenClose = 1;
				tOtherSide.BS = BS
				tOtherSide.Quantity = order.Quantity;
				tOtherSide.Price = order.Price1;
				tOtherSide.Tick = order.Tick1

				gtMoveFutureList[strSubmitNo] = gtMoveFutureList[strSubmitNo] or {}
				gtMoveFutureList[strSubmitNo].tOtherSide = gtMoveFutureList[strSubmitNo].tOtherSide or {}
				gtMoveFutureList[strSubmitNo].tOtherSide = tOtherSide

				local ret = PosSubmitSingleOrder(gFuturebaMapID, BASubID, order.IssueCode2, "3", 0, price2, order.MoveQuantity, 0, "",strSubmitNo,gHedgeFlag)
				if ret.Result then
					gtCombinList[portID].Future = order.IssueCode2
					ClearFutureOpenClose()
					Refresh(portID) -- 刷 表
				else
					sendLog(ret.Reason,portID)
				end

			end
		else -- 平仓优先
			price  = GetOrderPrice(order.IssueCode,BS,order.Quantity,order.Price1,order.Tick1)
			if order.Side ~= "买" then
				tOtherSide.BAMapID = gFuturebaMapID;
				tOtherSide.IssueCode = order.IssueCode2;
				tOtherSide.BASubID = BASubID
				tOtherSide.Side = "1";
				tOtherSide.OpenClose = 0;
				tOtherSide.BS = BS2
				tOtherSide.Quantity = order.MoveQuantity;
				tOtherSide.Price = order.Price2;
				tOtherSide.Tick = order.Tick2

				gtMoveFutureList[strSubmitNo] = gtMoveFutureList[strSubmitNo] or {}
				gtMoveFutureList[strSubmitNo].tOtherSide = gtMoveFutureList[strSubmitNo].tOtherSide or {}
				gtMoveFutureList[strSubmitNo].tOtherSide = tOtherSide

				local ret = PosSubmitSingleOrder(gFuturebaMapID, BASubID, order.IssueCode, "3", 1, price, order.Quantity, 0, "",strSubmitNo,gHedgeFlag)
				if ret.Result then
					gtCombinList[portID].Future = tOtherSide.IssueCode
					ClearFutureOpenClose()
					Refresh(portID) -- 刷 表
				else
					sendLog(ret.Reason,portID)
				end

			else -- ~=卖
				tOtherSide.BAMapID = gFuturebaMapID;
				tOtherSide.IssueCode = order.IssueCode2;
				tOtherSide.BASubID = BASubID
				tOtherSide.Side = "3";
				tOtherSide.OpenClose = 0;
				tOtherSide.BS = BS2
				tOtherSide.Quantity = order.MoveQuantity;
				tOtherSide.Price = order.Price2;
				tOtherSide.Tick = order.Tick2

				gtMoveFutureList[strSubmitNo] = gtMoveFutureList[strSubmitNo] or {}
				gtMoveFutureList[strSubmitNo].tOtherSide = gtMoveFutureList[strSubmitNo].tOtherSide or {}
				gtMoveFutureList[strSubmitNo].tOtherSide = tOtherSide

				local ret = PosSubmitSingleOrder(gFuturebaMapID, BASubID, order.IssueCode, "1", 1, price, order.Quantity, 0, "",strSubmitNo,gHedgeFlag)
				if ret.Result then
					gtCombinList[portID].Future = tOtherSide.IssueCode
					ClearFutureOpenClose()
					Refresh(portID) -- 刷 表
				else
					sendLog(ret.Reason,portID)
				end

			end
		end
	end
	--return;
end

function ClearFutureOpenClose()
--期货建仓表
	local DTSEvent FutureOpen = _CreateEventObject("VFutureOpenPosTable")
	FutureOpen._SetFld("IssueCode","Clear")
	_SendToClients(FutureOpen)

	--期货平仓表
	local DTSEvent FutureClose = _CreateEventObject("VFutureClosePosTable")
	FutureClose._SetFld("IssueCode","Clear")
	_SendToClients(FutureClose)
end

--反手委托回调
_OnEventDefined(VRrightBackHand RrightBackHandEvent)
	_WriteErrorLog("RrightBackHand");

	if _InitializeFlag ~= 1 then	-- 第一次刷新完成
		sendLog("请等待程序启动完毕再操作!",gPortID);
	else
		local issueCode = RrightBackHandEvent._GetFld("IssueCode");
		local side      = RrightBackHandEvent._GetFld("Side");
		local qty = RrightBackHandEvent._GetFld("Quantity");
		local moveQty = RrightBackHandEvent._GetFld("MoveQuantity")
		local way = RrightBackHandEvent._GetFld("Way");
		local price1
		local price2
		local portID = ""
		local condition = sys_sub(gFuturebaMapID,1,-4)
		local tempbamapid = condition .. "999"			--柜台持仓委托使用-999子账号
		if way == "反手委托" then
			price1 = RrightBackHandEvent._GetFld("Price1")
			price2 = RrightBackHandEvent._GetFld("Price2")
		elseif way == "涨跌停反手" then
			if side == "卖" then
				price1 = _PosPriceTable[issueCode].UpLimitPrice -- 跌停价
				price2 = _PosPriceTable[issueCode].UpLimitPrice -- 涨停价
			elseif side == "买" then
				price1 = _PosPriceTable[issueCode].LowLimitPrice -- 跌停价
				price2 = _PosPriceTable[issueCode].LowLimitPrice -- 跌停价
			end
		end

		gtBackHand[portID] = gtBackHand[portID] or {}
		gtBackHand[portID].IssueCode     = issueCode
		gtBackHand[portID].Quantity      = qty
		gtBackHand[portID].MoveQuantity  = moveQty
		gtBackHand[portID].Price1        = price1
		gtBackHand[portID].Price2 	     = price2
		gtBackHand[portID].Side          = side

		local logss = sys_format("反手:合约名称[%s];持仓状态[%s];持仓量[%s];移动量[%s];平仓价[%s];开仓价[%s];",issueCode,side,qty,moveQty,price1,price2);
		_WriteErrorLog(logss)
		sendLog(logss)

		if qty < 1 then
			sendLog("无仓位可以移，不能移动！");
		elseif moveQty < 1 then
			sendLog("反手数量必须大于1！");
		elseif qty >= 1 and moveQty >= 1 then

			if not issueCode or issueCode == "" then
				sendLog("移仓的合约代码无效，不能移动！");
			else
				local p1 = _PosIssueProductCodeTable[issueCode];
				if p1 ~= "31" then
					sendLog("移仓的合约代码不是股指期货代码，不能移动！");
				elseif (issueCode ~= gFutureCurrent) and (issueCode ~= gFutureNextMonth) and (issueCode ~= gFutureSeasonMonth) and (issueCode ~= gFutureNextSeason) then
					sendLog("移仓的合约代码不可交易，不能移动！");
				else
					local preID = nil;
					if side == "买" then
						preID = "3";
					elseif  side == "卖" then
						preID = "1";
					elseif (side ~= "买" and side ~= "卖") then
						local logs = sys_format("证券/合约多空无效，代码:%s,多空:%s.",issueCode,side);
						sendLog(logs);
					else
						preID = side;
					end
					if preID then
						local bamapid = tempbamapid
						local tempkey = issueCode .. "." .. preID .. "." .. gHedgeFlag
						_WriteErrorLog(tempkey)
						local futureInvestorID = ""
						bool okFlag = true;
						if _PosBAMapAccount[tempbamapid] then
							local futureAccountCode = _PosBAMapAccount[tempbamapid]
							futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
						else
							okFlag = false;
						end
						local posAvlQty = 0
						--增加显示柜台持仓
						if okFlag and gtPositionTable[futureInvestorID] then
							if gtPositionTable[futureInvestorID][tempkey] then
								posAvlQty = gtPositionTable[futureInvestorID][tempkey].AvQty or "0"
								posAvlQty = posAvlQty.getNumberValue()
								if posAvlQty < qty then
									okFlag = false;
								end
							else
								okFlag = false;
							end
						end

						if okFlag then
							backHandOrder(gtBackHand[portID],portID,tempbamapid) -- 反手委托
							sendLog("请刷新后确认！",portID);
						else
							local logs = sys_format("所选合约无有效数量，请刷新后，确认有持仓才可以移动，代码:%s,资金账号:%s.",issueCode,futureInvestorID);
							sendLog(logs,portID);
						end
					end
				end
			end
		end
	end
_End


function backHandOrder(order,portID,baMapID)

	local BuySell

	if order.Side ~= "买" then
		_WriteErrorLog("反手空")

		BASubID  = "1" .. portID
		BASubID2 = "3" .. portID
		BuySell  = "3"

		local ret = PosSubmitSingleOrder(baMapID, BASubID, order.IssueCode, BuySell, 1, order.Price1, order.Quantity, 0, "",nil,gHedgeFlag)
		if ret.Result then
			PosSubmitSingleOrder(baMapID, BASubID2, order.IssueCode, BuySell, 0, order.Price2, order.MoveQuantity, 0, "",nil,gHedgeFlag)
		else
			sendLog(ret.Reason,portID)
		end

	elseif order.Side ~= "卖" then
		_WriteErrorLog("反手买")

		BASubID  = "3" .. portID
		BASubID2 = "1" .. portID
		BuySell  = "1"

		local ret = PosSubmitSingleOrder(baMapID, BASubID, order.IssueCode, BuySell, 1, order.Price1, order.Quantity, 0, "",nil,gHedgeFlag)
		if ret.Result then
			PosSubmitSingleOrder(baMapID, BASubID2, order.IssueCode, BuySell, 0, order.Price2, order.MoveQuantity, 0, "",nil,gHedgeFlag)
		else
			sendLog(ret.Reason,portID)
		end
	end

end

--快捷锁仓回调
_OnEventDefined(VLockOrder LockOrderEvent)
	_WriteErrorLog("LockOrder");
	local issueCode = LockOrderEvent._GetFld("IssueCode");

	if _InitializeFlag ~= 1 then	-- 第一次刷新完成
		sendLog("请等待程序启动完毕再操作!",gPortID);
	elseif not _PosPriceTable[issueCode] then
		local log = sys_format("[%s]没有行情!",issueCode)
		sendLog(log,gPortID);
	else
		local side      = LockOrderEvent._GetFld("Side");
		local portID = ""
		local qty       = LockOrderEvent._GetFld("Quantity");
		local price = 0
		price = _PosPriceTable[issueCode].AskPrice1 or 0
		local BASubID = "3"..portID
		local BuySell = "3"
		local openclose = 0
		local BSStr = "买开仓"
		if side == "买" then
			BuySell = "1"
			BASubID = "1"..portID
			BSStr = "卖开仓"
			price = _PosPriceTable[issueCode].BidPrice1 or 0
		end
		local condition = sys_sub(gFuturebaMapID,1,-4)
		local tempbamapid = condition .. "999"			--柜台持仓委托使用-999子账号
		local log = sys_format("快捷锁仓:下单合约:[%s],下单数量:[%s],价格:[%s],方向:[%s]",issueCode,qty,price,BSStr)
		sendLog(log)
		local ret = PosSubmitSingleOrder(tempbamapid, BASubID, issueCode, BuySell, openclose, price, qty, 0, "",nil,gHedgeFlag)
		if not ret.Result then
			sendLog(ret.Reason,portID)
		end
	end
_End

function CheckStock(type,portID,status) -- 股票检查
	local log = sys_format("CheckStock:type=%s,portID=%s,status=%s",type,portID,status)
	_WriteErrorLog(log)
	--local hasCheckError = false;
	--local tSubmitOrder = {} -- 储存本次下单数据
	local SubmitOrder = {}
	local ret = {}
	local order = {} -- 储存下单数据
	local tempTable = {}
	if type == "手动" then
		tempTable = gtCombinList[portID]

	elseif type == "自动" then
		tempTable = gtAutoOrder[portID]

	elseif type == "自动并确认" then
		if status == "Open" then
			tempTable = gtYesOrder[portID]["Open"]

		elseif status == "Close" then
			tempTable = gtYesOrder[portID]["close"]
		end

	end

	if type == "手动" or type == "自动" then
		for k,v in pairs(tempTable.List) do
			if status == "Open" then	--融券卖出
				local stockTick     = v.StockSellTick
				local stockPrice    = v.StockSell
				local stockOrderQty = v.OrderSellQty
				stockOrderQty1      = stockOrderQty.toString()
				stockPrice = GetOrderPrice(k,0,stockOrderQty1,stockPrice,stockTick) -- 股票委托价格
				local LastPrice = GetOrderPrice(k,0,0,"最新价","不浮动")
				v.OpenLastPrice = LastPrice
				local temp = {}
					temp.IssueCode = k
					temp.OpenClose = 4
					temp.BuySell   = "1"
					temp.BAMapID   = gMarginbaMapID
					temp.BASubID   = "1" .. portID
					temp.Quantity  = stockOrderQty
					temp.Price     = stockPrice
					temp.CreRed    = 0
					sys_insert(order,temp)

			elseif status == "Close" then	--买券还券
				local stockPrice    = v.StockBuy
				local stockTick     = v.StockBuyTick
				local stockOrderQty = v.OrderBuyQty
				stockOrderQty1       = stockOrderQty.toString()
				stockPrice = GetOrderPrice(k,1,stockOrderQty1,stockPrice,stockTick) -- 股票委托价格
				local LastPrice = GetOrderPrice(k,0,0,"最新价","不浮动")
				v.CloseLastPrice = LastPrice
				local temp = {}
					temp.IssueCode = k
					temp.OpenClose = 5
					temp.BuySell   = "3"
					temp.BAMapID   = gMarginbaMapID
					temp.BASubID   = "1" .. portID
					temp.Quantity  = stockOrderQty
					temp.Price     = stockPrice
					temp.CreRed    = 0
					sys_insert(order,temp)
			end
		end
	else
		_WriteErrorLog("自动并确认--股票检查")
		for k,v in pairs(tempTable.List) do
			if status == "Open" then	--融券卖出
				local stockOrderQty = v.OrderSellQty

				local log = sys_format("stockOrderQty = %s",stockOrderQty)
				_WriteErrorLog(log)
				local stockPrice    = v.StockSellPrice
				local LastPrice = GetOrderPrice(k,0,0,"最新价","不浮动")
				v.OpenLastPrice = LastPrice
				local temp = {}
					temp.IssueCode = k
					temp.OpenClose = 4
					temp.BuySell   = "1"
					temp.BAMapID   = gMarginbaMapID
					temp.BASubID   = "1" .. portID
					temp.Quantity  = stockOrderQty
					temp.Price     = stockPrice
					temp.CreRed    = 0
					sys_insert(order,temp)

			elseif status == "Close" then	--买券还券
				local stockOrderQty = v.OrderBuyQty
				local stockPrice    = v.StockBuyPrice
				local LastPrice = GetOrderPrice(k,0,0,"最新价","不浮动")
				v.CloseLastPrice = LastPrice
				local temp = {}
					temp.IssueCode = k
					temp.OpenClose = 5
					temp.BuySell   = "3"
					temp.BAMapID   = gMarginbaMapID
					temp.BASubID   = "1" .. portID
					temp.Quantity  = stockOrderQty
					temp.Price     = stockPrice
					temp.CreRed    = 0
					sys_insert(order,temp)
			end
		end
	end

	ret = CheckOrder1(order)
	if ret.Result then

		submitFlag = true;
		SubmitOrder.submitFlag   = submitFlag
		SubmitOrder.order = order
	else
		local logs = sys_format("股票检查：%s",ret.Reason)
				sendLog(logs,portID);
		if type ~= "手动" then
			if status == "Open" then
				gtCombinList[portID].StockStatus   =  "新建" 								--状态
				gtCombinList[portID].FutureStatus  =  "新建" 								--状态
				InventoryListTable(portID)
				--SaveCombinData(portID,gtCombinList[portID])

				Notice(portID,"新建","新建")
				OrderOutBox(portID,"0","1")
			else
				gtCombinList[portID].StockStatus  = gtSaveOld[portID].oldStockStatus 								--状态
				gtCombinList[portID].FutureStatus  = gtSaveOld[portID].oldFutureStatus 							--状态
				InventoryListTable(portID)
				--SaveCombinData(portID,gtCombinList[portID])

				Notice(portID,gtCombinList[portID].StockStatus,gtCombinList[portID].FutureStatus)
				OrderOutBox(portID,"1","1")
			end
		end

		local log = sys_format("%s",ret.Reason)
		sendLog(log,portID);

		submitFlag = false;
		SubmitOrder.submitFlag   = submitFlag
		--SubmitOrder.order = {}
	end

	return SubmitOrder
end

function CheckFuture(type,portID,status) -- 期货检查
	local log = sys_format("CheckFuture type=%s,portID=%s,status=%s",type,portID,status)
	_WriteErrorLog(log)
	--多头检查
	local SubmitOrder = {}
	local ret = {}
	local order = {} -- 储存下单数据
	local tempTable = {}

	local futureIssue

	if type == "手动" then
		tempTable = gtCombinList[portID]
	elseif type == "自动" then
		tempTable = gtAutoOrder[portID]

	elseif type == "自动并确认" then
		if status == "Open" then
			_WriteErrorLog("自动并确认,Open")
			tempTable = gtYesOrder[portID]["Open"]

		elseif status == "Close" then
			tempTable = gtYesOrder[portID]["close"]
		end
	end

	if type == "手动" or type == "自动" then
		if status == "Open" then
			local futurTick = tempTable.FutureBuyTick
			futureIssue    = tempTable.Future

			local futureOrderQty = tempTable.FutureNum  -- 期货数量
			local futureOrderQty1 = futureOrderQty.toString()
			local futurPrice     = tempTable.FutureBuy -- 取价方式
			futurPrice = GetOrderPrice(futureIssue,1,futureOrderQty1,futurPrice,futurTick) -- 期货委托价格
			local LastPrice = GetOrderPrice(futureIssue,0,0,"最新价","不浮动")
			tempTable.OpenLastPrice = LastPrice
			local temp = {}
				temp.IssueCode = futureIssue
				temp.OpenClose = 0
				temp.BuySell   = "3"
				temp.BAMapID   = gFuturebaMapID
				temp.BASubID   = "3" .. portID
				temp.Quantity  = futureOrderQty
				temp.Price     = futurPrice
				temp.CreRed    = 0
				sys_insert(order,temp)

		elseif status == "Close" then
			local futurTick = tempTable.FutureSellTick
			futureIssue    = tempTable.Future
			local futureOrderQty = tempTable.FutureNum  -- 期货数量
			local futureOrderQty1 = futureOrderQty.toString()
			local futurPrice     = tempTable.FutureSell -- 取价方式
			futurPrice = GetOrderPrice(futureIssue,0,futureOrderQty1,futurPrice,futurTick) -- 期货委托价格
			local LastPrice = GetOrderPrice(futureIssue,0,0,"最新价","不浮动")
			tempTable.CloseLastPrice = LastPrice
			local temp = {}
				temp.IssueCode = futureIssue
				temp.OpenClose = 1
				temp.BuySell   = "1"
				temp.BAMapID   = gFuturebaMapID
				temp.BASubID   = "3" .. portID
				temp.Quantity  = futureOrderQty
				temp.Price     = futurPrice
				temp.CreRed    = 0
				sys_insert(order,temp)

		end
	else
		_WriteErrorLog("自动并确认--期货检查")
		if status == "Open" then
			futureIssue          = tempTable.Future
			local futureOrderQty = tempTable.FutureNum  -- 期货数量
			local futurPrice     = tempTable.FutureBuyPrice
			local LastPrice = GetOrderPrice(futureIssue,0,0,"最新价","不浮动")
			tempTable.OpenLastPrice = LastPrice
			local temp = {}
				temp.IssueCode = futureIssue
				temp.OpenClose = 0
				temp.BuySell   = "3"
				temp.BAMapID   = gFuturebaMapID
				temp.BASubID   = "3" .. portID
				temp.Quantity  = futureOrderQty
				temp.Price     = futurPrice
				temp.CreRed    = 0
				sys_insert(order,temp)

		elseif status == "Close" then
			futureIssue          = tempTable.Future
			local futureOrderQty = tempTable.FutureNum  -- 期货数量
			local futurPrice     = tempTable.FutureSellPrice
			local LastPrice = GetOrderPrice(futureIssue,0,0,"最新价","不浮动")
			tempTable.CloseLastPrice = LastPrice
			local temp = {}
				temp.IssueCode = futureIssue
				temp.OpenClose = 1
				temp.BuySell   = "1"
				temp.BAMapID   = gFuturebaMapID
				temp.BASubID   = "3" .. portID
				temp.Quantity  = futureOrderQty
				temp.Price     = futurPrice
				temp.CreRed    = 0
				sys_insert(order,temp)
		end
	end

	ret = CheckOrder1(order)
	if not ret.Result then
		local log = sys_format("期货检查：%s",ret.Reason)
				sendLog(log,portID);

		if type ~= "手动" then
			if status == "Open" then
				gtCombinList[portID].StockStatus   =  "新建" 								--状态
				gtCombinList[portID].FutureStatus  =  "新建" 								--状态
				InventoryListTable(portID)
				--SaveCombinData(portID,gtCombinList[portID])

				Notice(portID,"新建","新建")
				OrderOutBox(portID,"0","1")
			else
				gtCombinList[portID].StockStatus  = gtSaveOld[portID].oldStockStatus 								--状态
				gtCombinList[portID].FutureStatus  = gtSaveOld[portID].oldFutureStatus 								--状态
				InventoryListTable(portID)
				--SaveCombinData(portID,gtCombinList[portID])

				Notice(portID,gtCombinList[portID].StockStatus,gtCombinList[portID].FutureStatus)
				OrderOutBox(portID,"1","1")
			end
		end


		logs = sys_format("[%s]检查不通过，不能下单！",futureIssue);
		_WriteErrorLog(logs);
		sendLog(logs,portID);

		submitFlag = false
		SubmitOrder.submitFlag = submitFlag
	else
		submitFlag = true
		SubmitOrder.submitFlag = submitFlag
		SubmitOrder.order = order

	end

	return SubmitOrder
end


function openStock(portID,Order)		--融券卖出股票
	-- 置状态
	gtCombinList[portID].StockStatus  =  "建仓" 								--状态
	InventoryListTable(portID)
	SaveCombinData(portID,gtCombinList[portID])
	local staticInfo = CreateArbitrageInfo(portID,true)
	staticInfo.OpenHS300Price  = GetOrderPrice("M000300",0,0,"最新价","不浮动") --建仓沪深300的最新价
	staticInfo.StockStatus = "建仓"
	staticInfo.SaveFlag  = 1

	logs = sys_format("融券卖出股票：开始下单");
	sendLog(logs,portID);

	local OpenNo = 0

	for key,v in pairs(Order) do
		if v.Quantity ~= 0 then
			local ret = PosSubmitSingleOrder(v.BAMapID, v.BASubID, v.IssueCode, v.BuySell, v.OpenClose, v.Price, v.Quantity, 0, gUserID)
			if ret.Result then
				local log = sys_format("gMarginbaMapID = %s,longBaSubID = %s,issue = %s,stockPrice = %s,stockOrderQty = %s,gUserID = %s",v.BAMapID,v.BASubID,v.IssueCode,v.Price,v.Quantity,gUserID)
				_WriteErrorLog(log)
				OpenNo = OpenNo + 1
				gtCombinList[portID].OpenNum = OpenNo
			else
				local log = sys_format("融券卖出股票：未下单：issue[%s];数量[%s];价格[%s]",v.IssueCode,v.Quantity,v.Price)
				sendLog(log,portID);
			end
		else
			local log = sys_format("融券卖出股票：未下单：issue[%s];数量[%s];价格[%s]",v.IssueCode,v.Quantity,v.Price)
				sendLog(log,portID);
		end
	end

	local log = sys_format("融券卖出股票：股票下单个数：%s",OpenNo)
	sendLog(log,portID)

	--local log1 = sys_format("portID:[%s]，IssueCode[%s]，数量[%s]，价格[%s]，",portID,issue,stockOrderQty,stockPrice,)
	--sendLog(log1,portID)


end


function openFuture(portID,Order)		--买入期货
	gtCombinList[portID].FutureStatus = "建仓"
	InventoryListTable(portID)
	SaveCombinData(portID,gtCombinList[portID])
	local staticInfo = CreateArbitrageInfo(portID,true)
	staticInfo.OpenFuturePrice = GetOrderPrice(gtCombinList[portID].Future,0,0,"最新价","不浮动")  --平仓期指的最新价
	staticInfo.FutureStatus = "建仓"
	staticInfo.SaveFlag  = 1

	-- 期货下单
	for key,v in pairs(Order) do

		if v.Quantity ~= 0 then
			local ret1 = PosSubmitSingleOrder(v.BAMapID, v.BASubID, v.IssueCode, v.BuySell, v.OpenClose, v.Price, v.Quantity, 0, gUserID,nil,gHedgeFlag)
			if ret1.Result then
				local log = sys_format("gFuturebaMapID = %s,shortBaSubID = %s,futureIssue = %s,futurPrice = %s,futureOrderQty = %s,gUserID = %s",v.BAMapID,v.BASubID,v.IssueCode,v.Price,v.Quantity,gUserID)
				_WriteErrorLog(log)
			end

			if not ret1.Result then
				local log = sys_format("买入期货：%s",ret1.Reason)
				sendLog(log,portID);
				--logs = ret1.Reason;
				--sendLog(logs,portID);
			else
				local log = sys_format("买入期货：期货下单，合约：[%s];数量：[%s];价格：[%s];",v.IssueCode,v.Quantity,v.Price)
				sendLog(log,portID)
			end
		else
			local log = sys_format("买入期货：期货下单，合约：[%s];数量：[%s];价格：[%s];",v.IssueCode,v.Quantity,v.Price)
				sendLog(log,portID)
		end
	end

end


function closeStock(portID,Order)		--买券还券
	-- 置状态
	gtCombinList[portID].StockStatus  =  "平仓" 								--状态
	InventoryListTable(portID)
	SaveCombinData(portID,gtCombinList[portID])
	local staticInfo = CreateArbitrageInfo(portID,true)
	staticInfo.StockStatus = "平仓"
	staticInfo.CloseHS300Price  = GetOrderPrice("M000300",0,0,"最新价","不浮动") --建仓沪深300的最新价
	staticInfo.SaveFlag  = 1

	logs = sys_format("买券还券股票：开始下单");
	sendLog(logs,portID);

	local CloseNo = 0

	for k,v in pairs(Order) do
		local longBaSubID   = v.longBaSubID
		if v.Quantity ~= 0 then
			local ret = PosSubmitSingleOrder(v.BAMapID, v.BASubID, v.IssueCode, v.BuySell, v.OpenClose, v.Price, v.Quantity, 0, gUserID)
			if ret.Result then
				local log = sys_format("gMarginbaMapID = %s,longBaSubID = %s,issue = %s,stockPrice = %s,stockOrderQty = %s,gUserID = %s",v.BAMapID,v.BASubID,v.IssueCode,v.Price,v.Quantity,gUserID)
				_WriteErrorLog(log)
				CloseNo = CloseNo + 1
				gtCombinList[portID].CloseNum = CloseNo
			else
				local log = sys_format("买券还券股票：未下单：issue[%s];数量[%s];价格[%s]",v.IssueCode,v.Quantity,v.Price)
				sendLog(log,portID);
			end
		else
			local log = sys_format("买券还券卖出股票：未下单：issue[%s];数量[%s];价格[%s]",v.IssueCode,v.Quantity,v.Price)
				sendLog(log,portID);
		end
	end

	local log = sys_format("买券还券股票：股票下单个数：%s",CloseNo)
	sendLog(log,portID)
end


function closeFuture(portID,Order)		--卖出期货
	gtCombinList[portID].FutureStatus = "平仓"
	InventoryListTable(portID)
	SaveCombinData(portID,gtCombinList[portID])
	local staticInfo = CreateArbitrageInfo(portID,true)
	staticInfo.CloseFuturePrice = GetOrderPrice(gtCombinList[portID].Future,0,0,"最新价","不浮动")  --平仓期指的最新价
	staticInfo.FutureStatus = "平仓"
	staticInfo.SaveFlag  = 1

	for key,v in pairs(Order) do
	-- 期货下单
		if v.Quantity ~= 0 then
			local ret1 = PosSubmitSingleOrder(v.BAMapID, v.BASubID, v.IssueCode, v.BuySell, v.OpenClose, v.Price, v.Quantity, 0, gUserID,nil,gHedgeFlag)
			if ret1.Result then
				local log = sys_format("gFuturebaMapID = %s,shortBaSubID = %s,futureIssue = %s,futurPrice = %s,futureOrderQty = %s,gUserID = %s",v.BAMapID,v.BASubID,v.IssueCode,v.Price,v.Quantity,gUserID)
				_WriteErrorLog(log)
			end

			if not ret1.Result then
				local log = sys_format("卖出期货：%s",ret1.Reason)
				sendLog(log,portID);
				--logs = ret1.Reason;
				--sendLog(logs,portID);
			else
				local log = sys_format("卖出期货：期货下单，合约：[%s];数量：[%s];价格：[%s];",v.IssueCode,v.Quantity,v.Price)
				sendLog(log,portID)
			end
		else
			local log = sys_format("卖出期货：期货下单，合约：[%s];数量：[%s];价格：[%s];",v.IssueCode,v.Quantity,v.Price)
				sendLog(log,portID)
		end
	end
end



function priceToNumber(s)
	if not s then
		return nil;
	end
	if s == "" then
		return nil;
	end
	return s.getNumberValue();
end

function quantityToNumber(s)
	if not s then
		return 0;
	end
	if s == "" then
		return 0;
	end
	return s.getNumberValue();
end

function getNowTime() 					-- 时间化秒
	local DTSTime currentTime = _GetNowTime();
	local strCurrentTime = currentTime.asString("%H%M%S");

	local H = sys_sub(strCurrentTime,1,2)
	H = H.getNumberValue()
	local M = sys_sub(strCurrentTime,3,4)
	M = M.getNumberValue()
	local S = sys_sub(strCurrentTime,5,6)
	S = S.getNumberValue()

	local ss = H*3600 + M*60 + S
	return ss;
end


function Refresh(portID)				--刷新界面表格信息
	_WriteErrorLog("刷新")
	if gtCombinList[portID] then
		local log = sys_format("portID[%s]",portID)
		_WriteErrorLog(log)
		_WriteErrorLog("ClearTable")

		_WriteErrorLog("RefreshArbitrageSinglePos")
		RefreshArbitrageSinglePos(portID)								--刷新现货/期货 套利持仓

		InventoryListTable(portID)										--刷新组合信息表

		_WriteErrorLog("StockOpenPosTable")
		for issue,value in pairs(gtCombinList[portID].List) do
			StockAllTable(portID,issue)									--刷新现货建平仓表
		end
		_WriteErrorLog("SendPosTableEvent")
		SendPosTableEvent(portID)										--刷新现货建平仓控件
		_WriteErrorLog("SendStockOrder")
		SendStockOrder(portID)											--刷新现货/期货 委托/成交表
		SendStockOrder("-")												--刷新单边委托/成交表
--------------------------------------------------期货部分--------------------------------------------------
		_WriteErrorLog("FutureAllTable")
		FutureAllTable(portID)											--刷新期货建平仓表
--------------------------------------------------套利部分--------------------------------------------------
		_WriteErrorLog("RefreshArbitrageInfo")
		RefreshArbitrageInfo(portID)
		--_WriteErrorLog("SendArbitrageInfo")
		--SendArbitrageInfo(portID)
		_WriteErrorLog("BasisBets")
		BasisBets(portID,"双击")
		_WriteErrorLog("ShowBasisBets")
		ShowBasisBets("双击")												--刷新盘口基差敞口
	else
		_WriteErrorLog("未找到选中套利组合")
	end
end

function AutoOpen(portID,oc,way,yes) -- 自动下单条件触发
	if oc == "0" then
		if way == "1" then
			if yes == "不确认" then
				local StockOrder = CheckStock("自动",portID,"Open") -- 检查股票
				local name = gtCombinList[portID].CombinName
				local basis1 = gtAutoOrder[portID].basis1
				if StockOrder.submitFlag then
					local FutureOrder = CheckFuture("自动",portID,"Open") -- 检查期货
					if FutureOrder.submitFlag then
						local submit = FutureOrder.order
						--不做资金检查
						--local OrderFlag = CheckOrder("建仓",portID,submit,StockOrder.order) -- 检查柜台可用资金
						local OrderFlag = "Yes"
						if OrderFlag  == "Yes" then
							openStock(portID,StockOrder.order); -- 买入组合
							openFuture(portID,FutureOrder.order) -- 卖出期货

							gtCombinList[portID].StockStatus  =   "建仓" 								--状态
							gtCombinList[portID].FutureStatus  =  "建仓" 								--状态
							InventoryListTable(portID)
							SaveCombinData(portID,gtCombinList[portID])

							Notice(portID,"建仓","建仓") -- 刷当前状态
							OrderOutBox(portID,"0","1")
							local log = sys_format("组合名称[%s]满足建仓条件：大于基差[%s]触发下单成功。",name,basis1)
							SendAutoMessage("自动触发提示",log)

						else
							gtCombinList[portID].StockStatus   =  "新建" 								--状态
							gtCombinList[portID].FutureStatus  =  "新建" 								--状态
							InventoryListTable(portID)
							SaveCombinData(portID,gtCombinList[portID])

							Notice(portID,"新建","新建")
							OrderOutBox(portID,"0","1")
							local log = sys_format("组合名称[%s]满足建仓条件：大于基差[%s]触发下单失败。原因[%s]",name,basis1,"可用资金不足")
							SendAutoMessage("自动触发提示",log)
						end
					else
						local log = sys_format("组合名称[%s]满足建仓条件：大于基差[%s]触发下单失败。原因[%s]",name,basis1,"期货检查不通过")
						SendAutoMessage("自动触发提示",log)
					end
				else
					local log = sys_format("组合名称[%s]满足建仓条件：大于基差[%s]触发下单失败。原因[%s]",name,basis1,"股票检查不通过")
					SendAutoMessage("自动触发提示",log)
				end

			elseif yes == "确认" then
				SaveAuto("Open",portID)
			end
		elseif way == "3" then
			if yes == "不确认" then
				local StockOrder = CheckStock("自动",portID,"Open") -- 检查股票
				local name = gtCombinList[portID].CombinName
				local basis1 = gtAutoOrder[portID].basis1
				if StockOrder.submitFlag then
					local FutureOrder = CheckFuture("自动",portID,"Open") -- 检查期货
					if FutureOrder.submitFlag then
						local submit = FutureOrder.order
						--local OrderFlag = CheckOrder("建仓",portID,submit,StockOrder.order) -- 检查柜台可用资金
						local OrderFlag = "Yes"
						if OrderFlag  == "Yes" then
							openStock(portID,StockOrder.order); -- 买入组合
							openFuture(portID,FutureOrder.order) -- 卖出期货

							gtCombinList[portID].StockStatus  =   "建仓" 								--状态
							gtCombinList[portID].FutureStatus  =  "建仓" 								--状态
							InventoryListTable(portID)
							SaveCombinData(portID,gtCombinList[portID])

							Notice(portID,"建仓","建仓") -- 刷当前状态
							OrderOutBox(portID,"0","1")

							local log = sys_format("组合名称[%s]满足建仓条件：大于基差[%s]3次触发下单成功。",name,basis1)
							SendAutoMessage("自动触发提示",log)

						else
							gtCombinList[portID].StockStatus   =  "新建" 								--状态
							gtCombinList[portID].FutureStatus  =  "新建" 								--状态
							InventoryListTable(portID)
							SaveCombinData(portID,gtCombinList[portID])

							Notice(portID,"新建","新建")
							OrderOutBox(portID,"0","1")
							local log = sys_format("组合名称[%s]满足建仓条件：大于基差[%s]3次触发下单失败。原因[%s]",name,basis1,"可用资金不足")
							SendAutoMessage("自动触发提示",log)
						end
					else
						local log = sys_format("组合名称[%s]满足建仓条件：大于基差[%s]3次触发下单失败。原因[%s]",name,basis1,"期货检查不通过")
						SendAutoMessage("自动触发提示",log)
					end
				else
					local log = sys_format("组合名称[%s]满足建仓条件：大于基差[%s]3次触发下单失败。原因[%s]",name,basis1,"股票检查不通过")
					SendAutoMessage("自动触发提示",log)
				end

			elseif yes == "确认" then
				SaveAuto("Open",portID)
			end
		end

	elseif oc == "1" then
		if way == "1" then
			if yes == "不确认" then
				local StockOrder = CheckStock("自动",portID,"Close") -- 检查股票
				local name = gtCombinList[portID].CombinName
				local basis2 = gtAutoOrder[portID].basis2
				if StockOrder.submitFlag then
					local FutureOrder = CheckFuture("自动",portID,"Close") -- 检查期货
					if FutureOrder.submitFlag then
						closeStock(portID,StockOrder.order); -- 卖出组合
						closeFuture(portID,FutureOrder.order) -- 买入期货

						gtCombinList[portID].StockStatus  =   "平仓" 								--状态
						gtCombinList[portID].FutureStatus  =  "平仓" 								--状态
						InventoryListTable(portID)
						SaveCombinData(portID,gtCombinList[portID])

						Notice(portID,"平仓","平仓") -- 刷当前状态
						OrderOutBox(portID,"1","1")

						local log = sys_format("组合名称[%s]满足平仓条件：小于基差[%s]触发下单成功。",name,basis2)
						SendAutoMessage("自动触发提示",log)
					else
						local log = sys_format("组合名称[%s]满足平仓条件：小于基差[%s]触发下单失败。原因[%s]",name,basis2,"期货检查不通过")
						SendAutoMessage("自动触发提示",log)
					end
				else
					local log = sys_format("组合名称[%s]满足平仓条件：小于基差[%s]触发下单失败。原因[%s]",name,basis2,"股票检查不通过")
					SendAutoMessage("自动触发提示",log)
				end

			elseif yes == "确认" then
				SaveAuto("Close",portID)
			end
		elseif way == "3" then
			if yes == "不确认" then
				local StockOrder = CheckStock("自动",portID,"Close") -- 检查股票
				local name = gtCombinList[portID].CombinName
				local basis2 = gtAutoOrder[portID].basis2
				if StockOrder.submitFlag then
					local FutureOrder = CheckFuture("自动",portID,"Close") -- 检查期货
					if FutureOrder.submitFlag then
						closeStock(portID,StockOrder.order); -- 卖出组合
						closeFuture(portID,FutureOrder.order) -- 买入期货

						gtCombinList[portID].StockStatus  =   "平仓" 								--状态
						gtCombinList[portID].FutureStatus  =  "平仓" 								--状态
						InventoryListTable(portID)
						SaveCombinData(portID,gtCombinList[portID])

						Notice(portID,"平仓","平仓") -- 刷当前状态
						OrderOutBox(portID,"1","1")
						local log = sys_format("组合名称[%s]满足平仓条件：小于基差[%s]3次触发下单成功。",name,basis2)
						SendAutoMessage("自动触发提示",log)
					else
						local log = sys_format("组合名称[%s]满足平仓条件：小于基差[%s]3次触发下单失败。原因[%s]",name,basis2,"期货检查不通过")
						SendAutoMessage("自动触发提示",log)
					end
				else
					local log = sys_format("组合名称[%s]满足平仓条件：小于基差[%s]3次触发下单失败。原因[%s]",name,basis2,"股票检查不通过")
					SendAutoMessage("自动触发提示",log)
				end

			elseif yes == "确认" then
				SaveAuto("Close",portID)
			end
		end
	end
end

function SaveAuto(oc,portID) -- 保存自动下单信息
	if oc == "Open" then
		if gtAutoOrder[portID] then
			for key,v in pairs(gtAutoOrder[portID].List) do
				--获取股票数据
				local orderSellQty = v.OrderSellQty     -- 委买数量
				local stockSell    = v.StockSell        -- 取价方式
				local stockSellTick = v.StockSellTick   -- 股票tick
				local orderSellQty1 = orderSellQty.toString()
				local log = sys_format("orderSellQty = %s,stockSell = %s,stockSellTick = %s",orderSellQty,stockSell,stockSellTick)
				_WriteErrorLog(log)

				local stockSellPrice = GetOrderPrice(key,0,orderSellQty1,stockSell,stockSellTick) -- 股票委托价格
				_WriteErrorLog(stockSellPrice)
				local longBaSubID = "1" .. portID

				gtYesOrder[portID] = gtYesOrder[portID] or {}
				gtYesOrder[portID]["Open"] = gtYesOrder[portID]["Open"] or {}
				gtYesOrder[portID]["Open"].List = gtYesOrder[portID]["Open"].List or {}
				gtYesOrder[portID]["Open"].List[key] = {}
				gtYesOrder[portID]["Open"].List[key].OrderSellQty = orderSellQty
				gtYesOrder[portID]["Open"].List[key].StockSellPrice = stockSellPrice
				gtYesOrder[portID]["Open"].List[key].LongBaSubID = longBaSubID

			end

			--获取期货数据
			local future = gtAutoOrder[portID].Future
			local futureNum = gtAutoOrder[portID].FutureNum
			local logs = sys_format("futureNum = %s",futureNum)
			_WriteErrorLog(logs)
			local futureNum1 = futureNum.toString()
			local futureBuy = gtAutoOrder[portID].FutureBuy
			local futureBuyTick = gtAutoOrder[portID].FutureBuyTick
			local shortBaSubID = "3" .. portID
			local futureBuyPrice = GetOrderPrice(future,1,futureNum1,futureBuy,futureBuyTick) -- 期货委托价格

			gtYesOrder[portID]["Open"].Future = future
			gtYesOrder[portID]["Open"].ShortBaSubID = shortBaSubID
			gtYesOrder[portID]["Open"].FutureBuyPrice = futureBuyPrice
			gtYesOrder[portID]["Open"].FutureNum = futureNum
		end
	elseif oc == "Close" then
		if gtAutoOrder[portID] then
			for key,v in pairs(gtAutoOrder[portID].List) do
				--获取股票数据
				local orderBuyQty = v.OrderBuyQty     -- 委卖数量
				local orderBuyQty1 = orderBuyQty.toString()
				local stockBuy    = v.StockBuy        -- 取价方式
				local stockBuyTick = v.StockBuyTick   -- 股票tick

				local stockBuyPrice = GetOrderPrice(key,1,orderBuyQty1,stockBuy,stockBuyTick) -- 股票委托价格
				local longBaSubID = "1" .. portID

				gtYesOrder[portID] = gtYesOrder[portID] or {}
				gtYesOrder[portID]["close"] = gtYesOrder[portID]["close"] or {}
				gtYesOrder[portID]["close"].List = gtYesOrder[portID]["close"].List or {}
				gtYesOrder[portID]["close"].List[key] = {}
				gtYesOrder[portID]["close"].List[key].OrderBuyQty = orderBuyQty
				gtYesOrder[portID]["close"].List[key].StockBuyPrice = stockBuyPrice
				gtYesOrder[portID]["close"].List[key].LongBaSubID = longBaSubID

			end

			--获取期货数据
			local future = gtAutoOrder[portID].Future
			local futureNum = gtAutoOrder[portID].FutureNum
			local futureNum1 = futureNum.toString()
			local futureSell = gtAutoOrder[portID].FutureSell
			local futureSellTick = gtAutoOrder[portID].FutureSellTick
			local shortBaSubID = "3" .. portID
			local futureSellPrice = GetOrderPrice(future,0,futureNum1,futureSell,futureSellTick) -- 期货委托价格

			gtYesOrder[portID]["close"].Future = future
			gtYesOrder[portID]["close"].ShortBaSubID = shortBaSubID
			gtYesOrder[portID]["close"].FutureSellPrice = futureSellPrice
			gtYesOrder[portID]["close"].FutureNum = futureNum
		end
	else
	end
end

function YesOK(portID,oc,num,yes) -- 确认下单提示
	if oc == "Open" then
		if num == 1 then
			if yes  == "1" then
				gcount[portID].gAutoOpen3 = 0
				_WriteErrorLog("开：单次触发成功,无需确认！")
				AutoOpen(portID,"0","1","不确认") -- (portID,开平,触发方式,下单确认)
				--gtAutoOrder[portID].onOff1 = "1"

				gtAutoOrder[portID] = nil -- 清表
			else
				gcount[portID].gAutoOpen3 = 0
				_WriteErrorLog("开：单次触发成功,需确认！")
				AutoOpen(portID,"0","1","确认")
				OrderOutBox(portID,"0","0")
				--gtAutoOrder[portID].onOff1 = "1"
				gtAutoOrder[portID] = nil -- 清表

			end

		elseif num == 3 then
			if yes  == "1" then
				gcount[portID].gAutoOpen3 = 0
				_WriteErrorLog("开：多次触发成功,无需确认！")
				AutoOpen(portID,"0","3","不确认")
				--gtAutoOrder[portID].onOff1 = "1"

				gtAutoOrder[portID] = nil -- 清表

			else
				gcount[portID].gAutoOpen3 = 0
				_WriteErrorLog("开：多次触发成功,需确认！")
				AutoOpen(portID,"0","3","确认")
				OrderOutBox(portID,"0","0")
				--gtAutoOrder[portID].onOff1 = "1"
				gtAutoOrder[portID] = nil -- 清表

			end
		end

	elseif oc == "Close" then
		if num == 1 then
			if yes  == "1" then
				gcount[portID].gAutoClose3 = 0
				_WriteErrorLog("开：单次触发成功,无需确认！")
				AutoOpen(portID,"1","1","不确认")
				--gtAutoOrder[portID].onOff1 = "1"

				gtAutoOrder[portID] = nil -- 清表

			else
				gcount[portID].gAutoClose3 = 0
				_WriteErrorLog("开：单次触发成功,需确认！")
				AutoOpen(portID,"1","1","确认")
				OrderOutBox(portID,"1","0")
				--gtAutoOrder[portID].onOff1 = "1"
				gtAutoOrder[portID] = nil -- 清表

			end

		elseif num == 3 then
			if yes  == "1" then
				gcount[portID].gAutoClose3 = 0
				_WriteErrorLog("开：多次触发成功,无需确认！")
				AutoOpen(portID,"1","3","不确认")
				--gtAutoOrder[portID].onOff1 = "1"

				gtAutoOrder[portID] =nil -- 清表

			else
				gcount[portID].gAutoClose3 = 0
				_WriteErrorLog("开：多次触发成功,需确认！")
				AutoOpen(portID,"1","3","确认")
				OrderOutBox(portID,"1","0")
				--gtAutoOrder[portID].onOff1 = "1"
				gtAutoOrder[portID] = nil -- 清表

			end
		end
	end
end
function SendAutoMessage(title,txt) 	--给出下单提示框显示
	local DTSEvent set = _CreateEventObject("VSendAutoMessage")
	set._SetFld("Title",title)
	set._SetFld("TxT",txt)
	_SendToClients(set)
end

function getInjTime( InjTime )
	local i1 = sys_sub(InjTime,1,2)
   	local i2 = sys_sub(InjTime,3,4)
   	local i3 = sys_sub(InjTime,5,6)

   	local injTime = "(" .. i1 .. ":" .. i2 .. ":" .. i3 .. ")"
	return injTime
end

function BasisBets(portID, Type)	-- 盘口基差以及盘口、沪深300与期货的基差

	local openBasis = 0
	local openBets = 0
	local closeBasis = 0
	local closeBets = 0

	if portID ~= "" then
		if gtCombinList[portID] then

			local StockNum        = gtCombinList[portID].StockNum
			local future          = gtCombinList[portID].Future
			local futureNum       = gtCombinList[portID].FutureNum
			local futureNum1      = futureNum.toString()
			local longPrice       = GetOrderPrice("M000300",0,0,"最新价","不浮动")
			local futureSell      = gtCombinList[portID].FutureSell
			local futureSellTick  = gtCombinList[portID].FutureSellTick
			local futureSellPrice = GetOrderPrice(future,1,futureNum1,futureSell,futureSellTick)
			futureSellPrice       = futureSellPrice.getNumberValue() -- 期货委卖价格

			local futureBuy       = gtCombinList[portID].FutureBuy
			local futureBuyTick   = gtCombinList[portID].FutureBuyTick
			local futureBuyPrice  = GetOrderPrice(future,0,futureNum1,futureBuy,futureBuyTick)
			futureBuyPrice        = futureBuyPrice.getNumberValue() -- 期货委买价格

			local OpenSum  = 0
			local CloseSum = 0

			for issue,value in pairs(gtCombinList[portID].List) do
				local orderBuyQty    = value.OrderBuyQty
				local StockBuyPrice  = value.OrderBuyPrice
				local orderSellQty   = value.OrderSellQty
				local StockSellPrice = value.OrderSellPrice
				OpenSum  = OpenSum  + StockBuyPrice  * orderBuyQty
				CloseSum = CloseSum + StockSellPrice * orderSellQty
			end
			openBasis  = futureSellPrice - (OpenSum / 300 / futureNum)   -- 开仓盘口基差
			openBasis  =  sys_format("%.02f",openBasis)

			openBets   = longPrice * 300 - (OpenSum / StockNum)			-- 开仓盘口敞口
			openBets   =  sys_format("%.02f",openBets)

			closeBasis = futureBuyPrice - (CloseSum / 300 / futureNum) 	-- 平仓盘口基差
			closeBasis =  sys_format("%.02f",closeBasis)

			closeBets  = longPrice * 300 - (CloseSum / StockNum)		-- 平仓盘口敞口
			closeBets  =  sys_format("%.02f",closeBets)

			local log1 = sys_format("openBasis = %s,OpenBets = %s,CloseBasis = %s,CloseBets = %s",openBasis,openBets,closeBasis,closeBets)
			--_WriteErrorLog(log1)

			gtBasisBets[portID] = gtBasisBets[portID] or {}

			--gtBasisBets[portID].InjTime    = injTime
			gtBasisBets[portID].OpenBasis  = openBasis
			gtBasisBets[portID].OpenBets   = openBets
			gtBasisBets[portID].CloseBasis = closeBasis
			gtBasisBets[portID].CloseBets  = closeBets

			---------------------------------------沪深300与期货 基差

			hs300Price = hs300Price or 0
			issuePrice = issuePrice or 0

			local time1
			local time2
			if Type == "沪深300" then

				if _PosPriceTable["M000300"] then
					time1 = _PosPriceTable["M000300"].LastTime
					time1 = getInjTime(time1)
					hs300Price  = _PosPriceTable["M000300"].LastPrice or 0
					hs300Price  =  sys_format("%.02f",hs300Price)
				else
					hs300Price = 0
				end

				gtBasisBets[portID].HS300Price  = hs300Price
				gtBasisBets[portID].Time1  = time1

			elseif Type == "期货" then

				if _PosPriceTable[future] then
					time2 = _PosPriceTable[future].LastTime
					time2 = getInjTime(time2)
					issuePrice  = _PosPriceTable[future].LastPrice or 0
					issuePrice  =  sys_format("%.02f",issuePrice)
				else
					issuePrice = 0
				end

				gtBasisBets[portID].IssuePrice  = issuePrice
				gtBasisBets[portID].Time2  = time2
			elseif Type == "双击" then
				if _PosPriceTable["M000300"] then
					hs300Price  = _PosPriceTable["M000300"].LastPrice or 0
					hs300Price  =  sys_format("%.02f",hs300Price)

					time1 = _PosPriceTable["M000300"].LastTime
					time1 = getInjTime(time1)
					gtBasisBets[portID].Time1  = time1
				else
					hs300Price = 0
					gtBasisBets[portID].Time1  = "-"
				end

				if _PosPriceTable[future] then
					issuePrice = _PosPriceTable[future].LastPrice or 0
					issuePrice =  sys_format("%.02f",issuePrice)

					time2 = _PosPriceTable[future].LastTime
					time2 = getInjTime(time2)
					gtBasisBets[portID].Time2  = time2
				else
					issuePrice = 0
					gtBasisBets[portID].Time2  = "-"
				end

				gtBasisBets[portID].HS300Price  = hs300Price
				gtBasisBets[portID].IssuePrice  = issuePrice

			end

			local logz = sys_format("issuePrice = %s,hs300Price = %s",issuePrice,hs300Price)
			--_WriteErrorLog(logz)

			local hs300JC
			if issuePrice and hs300Price then
				hs300JC  = issuePrice - hs300Price
				hs300JC  =  sys_format("%.02f",hs300JC)
				gtBasisBets[portID].HS300JC  = hs300JC
			end

			---------------------------------------

			local log = sys_format("hs300JC1 = %s",hs300JC)
			--_WriteErrorLog(log)
		end
	end
end

function ShowBasisBets(Type) -- 显示基差敞口
	local DTSEvent set = _CreateEventObject("VShowBasisBets")
	if gtBasisBets[gPortID] then
		local openBasis  = gtBasisBets[gPortID].OpenBasis
		local openBets   = gtBasisBets[gPortID].OpenBets
		local closeBasis = gtBasisBets[gPortID].CloseBasis
		local closeBets  = gtBasisBets[gPortID].CloseBets

		local log = sys_format("OpenBasis = %s,OpenBets = %s,CloseBasis = %s,CloseBets = %s",openBasis,openBets,closeBasis,closeBets)
		--_WriteErrorLog(log)

		local hs300JC = gtBasisBets[gPortID].HS300JC

		local logx = sys_format("hs300JC2= %s",hs300JC)
			--_WriteErrorLog(logx)
		if Type == "沪深300" then
			local hs300   = gtBasisBets[gPortID].HS300Price
			local time1   = gtBasisBets[gPortID].Time1

			set._SetFld("OpenBasis",openBasis)
			set._SetFld("OpenBets",openBets)
			set._SetFld("CloseBasis",closeBasis)
			set._SetFld("CloseBets",closeBets)

			set._SetFld("HS300",hs300)
			set._SetFld("Time1",time1)
			set._SetFld("HS300JC",hs300JC)
			set._SetFld("Way","300")

			_SendToClients(set)
		elseif Type == "期货" then
			local issue   = gtBasisBets[gPortID].IssuePrice
			local time2   = gtBasisBets[gPortID].Time2

			set._SetFld("OpenBasis",openBasis)
			set._SetFld("OpenBets",openBets)
			set._SetFld("CloseBasis",closeBasis)
			set._SetFld("CloseBets",closeBets)

			set._SetFld("Issue",issue)
			set._SetFld("Time2",time2)
			set._SetFld("HS300JC",hs300JC)
			set._SetFld("Way","IF")

			_SendToClients(set)
		elseif Type == "双击" then
			local hs300   = gtBasisBets[gPortID].HS300Price
			local time1   = gtBasisBets[gPortID].Time1
			local issue   = gtBasisBets[gPortID].IssuePrice
			local time2   = gtBasisBets[gPortID].Time2

			set._SetFld("OpenBasis",openBasis)
			set._SetFld("OpenBets",openBets)
			set._SetFld("CloseBasis",closeBasis)
			set._SetFld("CloseBets",closeBets)

			set._SetFld("HS300",hs300)
			set._SetFld("Time1",time1)
			set._SetFld("Issue",issue)
			set._SetFld("Time2",time2)
			set._SetFld("HS300JC",hs300JC)
			set._SetFld("Way","双击")

			_SendToClients(set)
		end
	end
end

function CheckOrder(status,portID,order2,order1) -- 检查可用资金
	local log = sys_format("CheckOrder status=%s,portID=%s",status,portID)
	_WriteErrorLog(log)
	local OrderFlag = "No"

	local stockAvlFund  = 0		--信用账户可用资金，买券还券时检查
	local stockCreditFund = 0	--信用账户信用额度，开仓 融券卖出时检查
	local futureAvlFund = 0

	local marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
	local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]

	if marginAccountCode then
		local marginInvestorID = _PosFundStatus[marginAccountCode].InvestorID
		if gtQryMarginFund[marginInvestorID] then
			stockAvlFund = gtQryMarginFund[marginInvestorID].avl_capital	--信用账户可用资金
			stockCreditFund = gtQryMarginFund[marginInvestorID].avl_credit_amount	--信用账户信用额度
			stockAvlFund = stockAvlFund.getNumberValue()
			stockCreditFund = stockCreditFund.getNumberValue()
		end
	end
	if futureAccountCode then
		local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
		if gQueryFund[futureInvestorID] then
			futureAvlFund = gQueryFund[futureInvestorID].AvlFund
			futureAvlFund = futureAvlFund.getNumberValue()
		end
	end

	--if gtCombinList[portID] then
		if status == "建仓" then
			local log = sys_format("建仓：股票可用资金检查中...")
			_WriteErrorLog(log)
			sendLog(log,portID)
			if order1 then
				local SumPrice1 = 0
				local SumPrice2 = 0
				for i,value in pairs(order1) do
					local stockOrderQty = value.Quantity
					local stockPrice   = value.Price
					stockPrice = stockPrice.getNumberValue()

					SumPrice1 = SumPrice1 + stockOrderQty * stockPrice
				end

				if SumPrice1 > stockCreditFund then
					OrderFlag = "No"

					local log = sys_format("信用账号信用额度不足...下单失败")
					_WriteErrorLog(log)
					sendLog(log,portID)
				else
					local log1 = sys_format("信用账号信用额度检查完毕，检查期货账号可用资金...")
					_WriteErrorLog(log1)
					sendLog(log1,portID)

					for i,value in pairs(order2) do
						local price = value.Price
						local qty = value.Quantity
						price = price.getNumberValue()

						local log = sys_format("price = %s,qty = %s",price,qty)
						_WriteErrorLog(log)

						SumPrice2 = qty * price

						if SumPrice2 > futureAvlFund then
							OrderFlag = "No"

							local log2 = sys_format("期货账号可用资金不足...")
							_WriteErrorLog(log2)
							sendLog(log2,portID)
						else
							OrderFlag = "Yes"
							local log3 = sys_format("信用期货账号资金检查完毕，可以下单...")
							_WriteErrorLog(log3)
							sendLog(log3,portID)
						end
					end
				end
			else
				local log = sys_format("没有下单数据！")
				sendLog(log,portID)
				_WriteErrorLog(log)
			end

		elseif status == "卖出组合" then
			local log = sys_format("融券卖出组合：信用账户信用额度检查中...")
			_WriteErrorLog(log)
			sendLog(log,portID)
			local SumPrice1 = 0
			for issue,value in pairs(order1) do
				local stockOrderQty = value.Quantity
				local stockPrice   = value.Price
				stockPrice = stockPrice.getNumberValue()

				SumPrice1 = SumPrice1 + stockOrderQty * stockPrice
			end

			if SumPrice1 > stockCreditFund then
				OrderFlag = "No"

				local log1 = sys_format("信用账号信用额度不足...下单失败")
				_WriteErrorLog(log1)
				sendLog(log1,portID)
			else
				OrderFlag = "Yes"
				local log2 = sys_format("信用账号信用额度检查完毕，可以下单...")
				_WriteErrorLog(log2)
				sendLog(log2,portID)
			end
		elseif status == "买入组合" then
			local log = sys_format("买券还券：股票可用资金检查中...")
			_WriteErrorLog(log)
			sendLog(log,portID)
			local SumPrice1 = 0
			for issue,value in pairs(order1) do
				local stockOrderQty = value.Quantity
				local stockPrice   = value.Price
				stockPrice = stockPrice.getNumberValue()

				SumPrice1 = SumPrice1 + stockOrderQty * stockPrice
			end

			if SumPrice1 > stockAvlFund then
				OrderFlag = "No"

				local log1 = sys_format("信用账号可用资金不足...下单失败")
				_WriteErrorLog(log1)
				sendLog(log1,portID)
			else
				OrderFlag = "Yes"
				local log2 = sys_format("信用账号可用资金检查完毕，可以下单...")
				_WriteErrorLog(log2)
				sendLog(log2,portID)
			end
		elseif status == "买入期货" then
			local log = sys_format("买入期货：期货可用资金检查中...")
			--_WriteErrorLog(log)
			sendLog(log,portID)
			local SumPrice2 = 0
			for i,value in pairs(order2) do
				local price = value.Price
				local qty = value.Quantity
				price = price.getNumberValue()

				local log = sys_format("price = %s,qty = %s",price,qty)
				_WriteErrorLog(log)

				SumPrice2 = qty * price

				if SumPrice2 > futureAvlFund then
					OrderFlag = "No"
					local log1 = sys_format("期货账号可用资金不足...下单失败")
					_WriteErrorLog(log1)
					sendLog(log1,portID)
				else
					OrderFlag = "Yes"
					local log2 = sys_format("期货账号可用资金检查完毕，可以下单...")
					--_WriteErrorLog(log2)
					sendLog(log2,portID)
				end
			end
		end
	--end
	return OrderFlag
end

function CheckOrder1(orderTable) -- pos检查
	local ret = {}
	local pcidTable = {}
	local pcid2Table = {}
	--local quantity1Table = {}
	--local quantity2Table = {}
	for i, order in pairs(orderTable) do
		local issueCode = order.IssueCode
		local openClose = order.OpenClose
		local buySell = order.BuySell
		local baMapID = order.BAMapID
		local baSubID = order.BASubID
		local quantity = order.Quantity
		local quantity1 = quantity
		local quantity2 = 0
		local price = order.Price
		local creRed = order.CreRed

		local priorMarket = _PosIssueMarketTable[issueCode]
		if priorMarket == "1" or priorMarket == "2" then
			--[[if buySell == "3" then
				openClose = 0
			else
				openClose = 1
			end]]
			if buySell == "3" then	--买券还款
				openClose = 5
			else	--融券卖出
				openClose = 4
			end
		elseif priorMarket ~= "4" then
			if openClose == 3 or openClose == 2 then
				openClose = 1
			end
		else
			if openClose == 3 then
				local posKey = baMapID .. "." .. baSubID .. "." .. issueCode
				local avlTodayQty = 0
				local avlPrevQty = 0
				local pos = _PosPositionTable[posKey]
				if pos then
					avlTodayQty = pos.AvlTodayQuantity
					avlPrevQty = pos.AvlPrevQuantity
				end
				if quantity > avlTodayQty + avlPrevQty then
					ret.Result = false
					ret.Reason = "可用数量不足"
					return ret
				else
					if quantity > avlTodayQty then
						quantity1 = avlTodayQty
						quantity2 = quantity - quantity1
					end
				end
				if quantity1 > 0 then
					openClose = 2  --有今仓可平
				end
			end
		end
		order.RealOpenClose = openClose

		local ret1 = {}
		if quantity1 > 0 then
			ret1 = CheckOrderlogic(baMapID, baSubID, issueCode, buySell, openClose, price, quantity1, creRed)
			if not ret1.Result then
				return ret1
			else
				--pcidTable[i] = ret1.PositionCheckID
			end
		end
		local ret2 = {}
		if quantity2 > 0 then  --要用到昨仓
			ret2 = CheckOrderlogic(baMapID, baSubID, issueCode, buySell, 1, price, quantity2, creRed)
			if not ret2.Result then
				return ret2
			else
				--pcid2Table[i] = ret2.PositionCheckID
			end
		end
		--quantity1Table[i] = quantity1
		--quantity2Table[i] = quantity2
	end
	ret.Result = true
	return ret
end

function CheckOrderlogic(baMapID, baSubID, issueCode, buySell, openClose, price, quantity, creRed)	--pos检查
	local ret = {}
	if _PosStatus ~= POS_STATUS_NORMAL then
		ret.Result=false
		ret.Reason="初始化未完成，请稍候再试"
		return ret
	end

	if not _PosBAMapTable[baMapID] then
		ret.Result=false
		ret.Reason="子帐户未加入"
		return ret

	end

	if not _PosIssueMarketTable[issueCode] then
		ret.Result=false
		ret.Reason="代码错误"
		return ret
	end

	if buySell ~= "1" and buySell ~= "3" then
		ret.Result=false
		ret.Reason="买卖错误"
		return ret
	end

	if openClose ~= 0 and openClose ~= 1 and openClose ~= 2 and openClose ~= 3 and openClose ~= 4 and openClose ~= 5 and openClose ~= 6 and openClose ~= 7 and openClose ~= 8 then
		--包含融资融券交易
		ret.Result=false
		ret.Reason="开平错误"
		return ret
	end

	local direction = sys_sub(baSubID, 1, 1)
	if (direction ~= buySell and openClose == 0) or (direction == buySell and openClose ~= 0) and (openClose ~= 4 and openClose ~= 5) then
		--融资融券不做该检查
		ret.Result=false
		ret.Reason="买卖与持仓方向不符"
		return ret
	end

	if creRed ~= 0 and creRed ~= 1 and creRed ~= 2 then
		ret.Result = false
		ret.Reason="申赎错误"
		return ret
	end

	if creRed == 1 and (buySell == "1" or openClose == 1) then
		ret.Result = false
		ret.Reason="申赎与买卖开平不一致"
		return ret
	end

	if creRed == 2 and (buySell == "3" or openClose == 0) then
		ret.Result = false
		ret.Reason="申赎与买卖开平不一致"
		return ret
	end

	if quantity <= 0 then
		ret.Result = false
		ret.Reason="数量必须大于0"
		return ret
	end

	local DTSTime now = _GetNowTime();
	local nowHMS = now.asString("%H%M%S");
	local pcid = sys_format("%-10s%6s%04d",baMapID, nowHMS, _PosCheckIDSeq)

	local posKey = baMapID .. "." .. baSubID .. "." .. issueCode
	local position = _PosPositionTable[posKey]
	local isNewPosition = false

	local nearPosition
	local otherPosition
	local isNearNewPosition = false
	local isOtherNewPosition = false
	local nearIssue
	local otherIssue
	local nearPosKey
	local otherPosKey
	local nearUpperLimit
	local otherUpperLimit

	local productCode = _PosIssueProductCodeTable[issueCode]
	local isSpread = productCode == "26" or productCode == "36"
	if isSpread then
		nearIssue = _PosIssueNearMonthTable[issueCode]
		otherIssue = _PosIssueOtherMonthTable[issueCode]
		local portID = _PosGetPortID(baSubID)
		local nearBASubID
		local otherBASubID
		if openClose == 0 then
			if buySell == "3" then
				nearBASubID = "3" .. portID
				otherBASubID = "1" .. portID
			else
				nearBASubID = "1" .. portID
				otherBASubID = "3" .. portID
			end
		else
			if buySell == "3" then
				nearBASubID = "1" .. portID
				otherBASubID = "3" .. portID
			else
				nearBASubID = "3" .. portID
				otherBASubID = "1" .. portID
			end
		end
		nearPosKey = baMapID .. "." .. nearBASubID .. "." .. nearIssue
		otherPosKey = baMapID .. "." .. otherBASubID .. "." .. otherIssue
		nearPosition = _PosPositionTable[nearPosKey]
		otherPosition = _PosPositionTable[otherPosKey]

		if not nearPosition then
			isNearNewPosition = true
			--先生成position对象，但不加到全局表里，待检查通过后再加
			nearPosition = _PosNewPosition(baMapID, nearBASubID, nearIssue)
		end

		if not otherPosition then
			isOtherNewPosition = true
			--先生成position对象，但不加到全局表里，待检查通过后再加
			otherPosition = _PosNewPosition(baMapID, otherBASubID, otherIssue)
		end
	end

	if not position then
		isNewPosition = true
		--先生成position对象，但不加到全局表里，待检查通过后再加
		position = _PosNewPosition(baMapID, baSubID, issueCode)
	end

	if isSpread then
		local log = sys_format("before check order: issue=%s, nearAvlQty=%s, otherAvlQty=%s", issueCode, nearPosition.AvlQuantity, otherPosition.AvlQuantity)
		_WriteErrorLog(log)
	else
		local log = sys_format("before check order: issue=%s, avlQty=%s", issueCode, position.AvlQuantity)
		_WriteErrorLog(log)
	end

	local accountCode = _PosBAMapAccount[baMapID]

	if openClose == 0 or openClose ==4  then --开仓资金检查与冻结，申购ETF时的成份股和现金差额，现金替代冻结
		if creRed == 0 and openClose ~= 4 then --普通开仓单,融券卖出开仓不做资金检查
			local fundStatus = _PosFundStatus[accountCode]
			local requiredFund
			local nearFund
			local otherFund
			if isSpread then
				nearUpperLimit = _PosGetUpperLimit(nearIssue)
				otherUpperLimit = _PosGetUpperLimit(otherIssue)
				local nearContractSize = _PosIssueContractSizeTable[nearIssue]
				local otherContractSize = _PosIssueContractSizeTable[otherIssue]
				local nearBail = _PosGetBail(accountCode, nearIssue)
				local otherBail = _PosGetBail(accountCode, otherIssue)
				nearFund = nearUpperLimit * nearContractSize * nearBail * quantity
				otherFund = otherUpperLimit * otherContractSize * otherBail * quantity
				requiredFund = nearFund + otherFund
			else
				local contractSize = _PosIssueContractSizeTable[issueCode]
				local bail = _PosGetBail(accountCode, issueCode)
				requiredFund = price * quantity * bail * contractSize
			end
			if fundStatus.AvlFund < requiredFund then --资金不足
				ret.Result = false
				ret.Reason = sys_format("资金不足，需要%.02f元，现有%.02f元", requiredFund, fundStatus.AvlFund)
				return ret
			end
			--fundStatus.OrderFund = fundStatus.OrderFund + requiredFund
			--fundStatus.AvlFund = fundStatus.AvlFund - requiredFund
			--local avlFundLog = sys_format("POS:%s,AvlFund=%.2f,delta=%s",accountCode,fundStatus.AvlFund, -requiredFund)
			--_WriteErrorLog(avlFundLog)
			--if isSpread then
			--	nearPosition.WorkingAmountOfOpen = nearPosition.WorkingAmountOfOpen + nearFund
			--	otherPosition.WorkingAmountOfOpen = otherPosition.WorkingAmountOfOpen + otherFund
			--	local wmLog = sys_format("POS:%s,%s,%s,wmoNear=%.0f, wmoOther=%.0f, reqFund=%s", baMapID, baSubID, issueCode, nearPosition.WorkingAmountOfOpen, otherPosition.WorkingAmountOfOpen, requiredFund)
			--	_WriteErrorLog(wmLog)
			--else
			--	position.WorkingAmountOfOpen = position.WorkingAmountOfOpen + requiredFund
			--	local wmLog = sys_format("POS:%s,%s,%s,wmo=%.0f, reqFund=%s", baMapID, baSubID, issueCode, position.WorkingAmountOfOpen, requiredFund)
			--	_WriteErrorLog(wmLog)
			--end
		end
	else --平仓持仓检查与冻结
		local marketCode = _PosIssueMarketTable[issueCode]
		if isSpread then
			if nearPosition.AvlQuantity < quantity then
				ret.Result = false
				ret.Reason = nearIssue .. "可平数量不足"
				return ret
			end
			if otherPosition.AvlQuantity < quantity then
				ret.Result = false
				ret.Reason = otherIssue .. "可平数量不足"
				return ret
			end
		else
			if marketCode == "3" or  marketCode == "5" or marketCode == "6" or productCode == "02" then
				if position.AvlQuantity < quantity then
					ret.Result = false
					ret.Reason = issueCode .. "可平数量不足"
					return ret
				end
			elseif marketCode == "4" then
				if openClose == 1 then
					if position.AvlPrevQuantity < quantity then
						ret.Result = false
						ret.Reason = issueCode .. "可平数量不足"
						return ret
					end
				else
					if position.AvlTodayQuantity < quantity then
						ret.Result = false
						ret.Reason = issueCode .. "可平今数量不足"
						return ret
					end
				end
			else
				if creRed == 0 then --普通卖单
					if position.AvlQuantity < quantity then
						ret.Result = false
						ret.Reason = sys_format("%s可卖数量(%d)不足%d",issueCode, position.AvlQuantity, quantity)
						return ret
					end
				else --赎回ETF
					if position.AvlCreRedQuantity < quantity then
						ret.Result = false
						ret.Reason = issueCode .. "可赎回数量不足"
						return ret
					end
				end
			end
		end
	end
	ret.Result = true
	return ret
end

function Notice(portID,stockStatus,futureStatus)		--刷当前状态
	local DTSEvent set = _CreateEventObject("VNotice")
	set._SetFld("PortID",portID)
	set._SetFld("StockStatus",stockStatus)
	set._SetFld("FutureStatus",futureStatus)

	_SendToClients(set)
end
function OrderOutBox(PortID,OC,IF)
	local DTSEvent set = _CreateEventObject("VOrderOutBox")
	local PortIDName = gtCombinList[PortID].CombinName
	set._SetFld("PortName",PortIDName)
	set._SetFld("PortID",PortID)
	set._SetFld("OC",OC)
	set._SetFld("IF",IF)
	_SendToClients(set)
end
function IF(Futrue)									--条件单判断逻辑
	-- 条件触发开平仓
	-- 开仓

	if gtAutoOrder then
		local nowTime = getNowTime()
		local longPrice = GetOrderPrice("M000300",0,0,"最新价","不浮动")--最新价
		for key,v in pairs(gtAutoOrder) do
			local PortID = key
			local future = v.Future
			if future == Futrue or Futrue == "M000300" then
				local shortPrice = GetOrderPrice(future,0,0,"最新价","不浮动")	--最新价
				local nowbasis = shortPrice - longPrice

				local OnOff = v.onOff1
				--判断开仓
				if OnOff == "0" then
					--_WriteErrorLog("开仓条件开启")
					--_WriteErrorLog(Futrue)
					local close = v.close1 -- 是否触发XX秒无响应
					local ss = v.ss1
					local time = v.time1
					local basis = v.basis1 -- 设置基差
					local CloseTouch = v.CloseTouch1 -- 单次还是连续触发
					local yes = v.yes1

					--local log = sys_format("行情回调开仓：PortID[%s],close[%s],nowTime[%s],time[%s],ss[%s],nowbasis[%s],basis[%s],CloseTouch[%s],yes[%s]",PortID,close,nowTime,time,ss,nowbasis,basis,CloseTouch,yes)
					--_WriteErrorLog(log)

					if close == "0" then
						if nowTime - time < ss then -- 设置的时间范围内
							if nowbasis > basis then -- 满足基差
								gcount[PortID] = gcount[PortID] or {}
								gcount[PortID].gAutoOpen3 = gcount[PortID].gAutoOpen3 or 0
								gcount[PortID].gAutoOpen3 = gcount[PortID].gAutoOpen3 + 1
								if CloseTouch == "0" then -- 单次触发
									_WriteErrorLog("自动开仓：单次触发！")
									if yes  == "1" then
										_WriteErrorLog("自动开仓：无需确认！")
										YesOK(PortID,"Open",1,"1")

									else
										YesOK(PortID,"Open",1,"0")

									end
								else -- 连续满足三次条件
									local log = sys_format("gAutoOpen3 = %s",gcount[PortID].gAutoOpen3)
									_WriteErrorLog(log)
									if gcount[PortID].gAutoOpen3 == 3 then
										if yes  == "1" then
											YesOK(PortID,"Open",3,"1")

										else
											YesOK(PortID,"Open",3,"0")

										end
									end
								end
							else
								gcount[PortID] = gcount[PortID] or {}
								gcount[PortID].gAutoOpen3 = 0

							end
						else
							--gtAutoOrder[PortID].onOff1 = "1"
							gtAutoOrder[PortID] = nil -- 清表
							local time1 = nowTime - time
							local time2 = ss
							local log = sys_format("超出设定时间关闭条件单：time1 = %s,time2 = %s",time1,time2)
							_WriteErrorLog(log)

							gtCombinList[PortID].StockStatus   =  "新建" 								--状态
							gtCombinList[PortID].FutureStatus  =  "新建" 								--状态
							InventoryListTable(PortID)
							--SaveCombinData(PortID,gtCombinList[PortID])

							Notice(PortID,"新建","新建")
							OrderOutBox(PortID,"0","1")
						end
					else -- 没有勾选自动关闭时间
						if nowbasis > basis then -- 满足基差
							gcount[PortID] = gcount[PortID] or {}
							gcount[PortID].gAutoOpen3 = gcount[PortID].gAutoOpen3 or 0
							gcount[PortID].gAutoOpen3 = gcount[PortID].gAutoOpen3 + 1
							if CloseTouch == "0" then-- 单次触发
								if yes  == "1" then
									YesOK(PortID,"Open",1,"1")

								else
									YesOK(PortID,"Open",1,"0")

								end
							else -- 连续满足三次条件
								local log = sys_format("gAutoOpen3 = %s",gcount[PortID].gAutoOpen3)
								_WriteErrorLog(log)
								if gcount[PortID].gAutoOpen3 == 3 then
									if yes  == "1" then
										YesOK(PortID,"Open",3,"1")

									else
										YesOK(PortID,"Open",3,"0")

									end
								end
							end
						else
							gcount[PortID] = gcount[PortID] or {}
							gcount[PortID].gAutoOpen3 = 0
						end
					end
				elseif OnOff == "1" then
					--_WriteErrorLog("关闭条件开启")
					gcount[PortID] = gcount[PortID] or {}
					gcount[PortID].gAutoOpen3 = 0
					--_WriteErrorLog()
				end

				--判断平仓
				OnOff = v.onOff2
				if OnOff == "0" then
					--_WriteErrorLog("平仓条件开启")

					local close = v.close2 -- 是否触发XX秒无响应
					local ss = v.ss2
					local time = v.time2
					local basis = v.basis2 -- 设置基差
					local CloseTouch = v.CloseTouch2 -- 单次还是连续触发
					local yes = v.yes2

					--local log = sys_format("行情回调平仓：PortID[%s],close[%s],nowTime[%s],time[%s],ss[%s],nowbasis[%s],basis[%s],CloseTouch[%s],yes[%s]",PortID,close,nowTime,time,ss,nowbasis,basis,CloseTouch,yes)
					--_WriteErrorLog(log)

					if close == "0" then
						if nowTime - time < ss then -- 设置的时间范围内
							if nowbasis < basis then -- 满足基差
								gcount[PortID] = gcount[PortID] or {}
								gcount[PortID].gAutoClose3 = gcount[PortID].gAutoClose3 or 0
								gcount[PortID].gAutoClose3  = gcount[PortID].gAutoClose3 + 1
								if CloseTouch == "0" then-- 单次触发
									_WriteErrorLog("[平]：单次触发成功,无需确认！")
									if yes  == "1" then
										YesOK(PortID,"Close",1,"1")
									else
										YesOK(PortID,"Close",1,"0")

									end
								else -- 连续满足三次条件
									local log = sys_format("gAutoClose3 = %s",gcount[PortID].gAutoClose3)
									_WriteErrorLog(log)
									if gcount[PortID].gAutoClose3 == 3 then
										if yes  == "1" then
											YesOK(PortID,"Close",3,"1")

										else
											YesOK(PortID,"Close",3,"0")

										end
									end
								end
							else
								gcount[PortID] = gcount[PortID] or {}
								gcount[PortID].gAutoClose3 = 0
							end
						else
							--gtAutoOrder[PortID].onOff2 = "1"
							gtAutoOrder[PortID] = nil -- 清表
							local time1 = nowTime - time
							local time2 = ss
							local log = sys_format("超出设定时间关闭条件单：time1 = %s,time2 = %s",time1,time2)
							_WriteErrorLog(log)

							gtCombinList[PortID].StockStatus  = gtSaveOld[PortID].oldStockStatus 								--状态
							gtCombinList[PortID].FutureStatus  = gtSaveOld[PortID].oldFutureStatus 								--状态
							InventoryListTable(PortID)
							--SaveCombinData(PortID,gtCombinList[PortID])

							Notice(PortID,gtCombinList[PortID].StockStatus,gtCombinList[PortID].FutureStatus)
							OrderOutBox(PortID,"1","1")

						end
					else -- 没有勾选自动关闭时间
						if nowbasis < basis then -- 满足基差
							gcount[PortID] = gcount[PortID] or {}
							gcount[PortID].gAutoClose3 = gcount[PortID].gAutoClose3 or 0
							gcount[PortID].gAutoClose3 = gcount[PortID].gAutoClose3 + 1
							if CloseTouch == "0" then-- 单次触发
								if yes  == "1" then
									YesOK(PortID,"Close",1,"1")

								else
									YesOK(PortID,"Close",1,"0")

								end
							else -- 连续满足三次条件
								local log = sys_format("gAutoClose3 = %s",gcount[PortID].gAutoClose3)
									_WriteErrorLog(log)
								if gcount[PortID].gAutoClose3 == 3 then
									if yes  == "1" then
										YesOK(PortID,"Close",3,"1")

									else
										YesOK(PortID,"Close",3,"0")

									end
								end
							end
						else
							gcount[PortID] = gcount[PortID] or {}
							gcount[PortID].gAutoClose3 = 0
						end
					end
				elseif OnOff == "1" then
					--_WriteErrorLog("平仓条件关闭")
					gcount[PortID] = gcount[PortID] or {}
					gcount[PortID].gAutoClose3 = 0
					--_WriteErrorLog()
				end
			end
		end
	end

end
