﻿--反向期现套利初始版1.01
--Release version: 1.001.20140305
--委托成交回调
_OnEventExecution("OrderExecReply", {} , DTSMessageRecordAccess msg)
	local _String uniqueKeyCode = msg.getUniqueKeyCode();
	local _String message = msg.getMessageType ();
	local DTSOrderDetailRecordAccess order = msg.getOrderDetailRecord();
	local _String baMapID = order.getBAMapID();
	local investorID = "-"
	local clientID = "-"
	local accountCode = _PosBAMapAccount[baMapID] or "-"
	local accountType = ""
	if _PosFundStatus[accountCode] then
		investorID = _PosFundStatus[accountCode].InvestorID
		accountType = _PosFundStatus[accountCode].Type
	end
	if _PosAccountClientTable[accountCode] then
		clientID = _PosAccountClientTable[accountCode]
	end
	local _String corpCode = order.getCorpCode();
		--投机套保标识
	local orderHedgeFlag = order.getExternalSystemID()
	if _PosDBHedgeFlagTable[orderHedgeFlag] then
		orderHedgeFlag = _PosDBHedgeFlagTable[orderHedgeFlag]
	end
	--价格格式化
	local issueCode = order.getIssueCode();
	local formatPriceExponent = getPriceFormat(issueCode)

	if accountType ~= "S" and (POS_LOGIN_CHECK_FUT_ISSUE ~= issueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= issueCode) then
		local issueCode = order.getIssueCode();							--合约号
		local baSubID = order.getBASubID();								--BASubID
		local issueName = _PosIssueNameTable[issueCode];				--合约名称
		local buySell = order.getBuySell();								--买卖
		local openClose = order.getReserveInt1();						--开仓、平仓、平今
		--local creRed = order.getGeneralInt1()							--0普通委托, 1:申购. 2:赎回, 3:质押, 4:融资回购, 5:融券回购
		local orderQuantity = order.getOriginalQuantity();				--委托数量
		local orderPrice = order.getOrderPrice();						--委托价
		local orderTime = order.getOrderTime();							--委托时间
		local orderAcceptNo = order.getOrderAcceptNo();					--委托号
		local corpCode = order.getCorpCode();							--内部委托号

		local workingQuantity = order.getWorkingQuantity();				--挂盘数量
		local cancelQuantity = order.getCancelQuantity();				--撤单数量
		local unAcceptedQuantity = order.getUnacceptedQuantity();		--未报数量
		local rejectedQuantity = order.getRejectedQuantity();			--拒绝数量
		local executionQuantity = order.getExecutionQuantity();			--成交数量
		local executionValue = order.getExecutionValue();				--成交金额
		local execPrice = msg.getExecutionPrice()						--成交价格

		local marketCode = order.getMarketCode();						--市场号
		local market = ""
		local shareholderCode = ""
		if marketCode == "1" then
			market = "上交所"
		elseif marketCode == "2" then
			market = "深交所"
		elseif marketCode == "3" then
			market = "中金所"
		elseif marketCode == "4" then
			market = "上期"
		elseif marketCode == "5" then
			market = "郑商"
		elseif marketCode == "6" then
			market = "大商"
		end
		local productCode = order.getProductCode();						--产品代码
		--local marginFlag = order.getOrderMarginFlag();				--0:证券交易 2：开仓 4：平仓
		local generalString1 = order.getGeneralString1();				--客户号和交易密码
		local reserveString2 = order.getReserveString2()				--reason
		local PCID = order.getPositionCheckID()							--持仓检查号
		local batchID = order.getTargetPrice()					     	--匹配号

		--期货移仓开平优先下单
		if gtMoveFutureList[batchID] then
			if cancelQuantity + executionQuantity == orderQuantity then
				if gtMoveFutureList[batchID].tOtherSide then
					FristOpenClose(batchID)
				end
			end
		end

		--下单拒绝时交易号为""，输出为"-"
		if orderAcceptNo == "" then
			orderAcceptNo = "-"
		end

		--组合号
		local portID = sys_sub(baSubID, 2, -1)
		if portID == "" then
			portID = "-"
		end

		--设置成交额
--~ 		if executionValue ~= "" then
--~ 			executionValue = sys_format(formatPriceExponent, executionValue);
--~ 		end

		--设置委托价格
		if orderPrice ~= "" then
			orderPrice = sys_format(formatPriceExponent, orderPrice);
		end

		--设置委托时间
		if orderTime~="" then
			local tmpordtimeH = sys_sub(orderTime,1,2);
			local tmpordtimeM = sys_sub(orderTime,3,4);
			local tmpordtimeS = sys_sub(orderTime,5,6);
			local tmpordtimeHM = sys_sub(orderTime,7,9);
			orderTime = tmpordtimeH..":"..tmpordtimeM..":"..tmpordtimeS
		else
			orderTime = "-"
		end
		local DTSDate nowDate = _GetNowDate();		--获取当前日期
		local strDate = nowDate.asString("%Y%m%d");	--日期格式化成"20100127"

		--设置委托状态
		local status = "-"
		local statusFlag = "-";
		if orderQuantity == executionQuantity then
			status = "全部成交"
			statusFlag = "1"
		elseif executionQuantity >0 and orderQuantity > executionQuantity then
			if executionQuantity + cancelQuantity == orderQuantity then
				status = "部成部撤"
				statusFlag = "1"
			else
				status = "部分成交"
				statusFlag = "2"
			end
		elseif workingQuantity > 0 then
			status = "挂单"
			statusFlag = "2"
		elseif cancelQuantity > 0 then
			status = "撤单"
			statusFlag = "1"
		elseif unAcceptedQuantity > 0 then
			status = "未报"
			statusFlag = "1"
		elseif rejectedQuantity > 0 then
			status = "拒绝"
			statusFlag = "1"
		else
			status = "已报"
			statusFlag = "2"
		end

		local openCloseName = "-"
		if openClose == 0 or openClose == 4 then
			openCloseName = "开仓"
		elseif openClose == 1 or openClose == 5 then
			openCloseName = "平仓"
		elseif openClose == 2 then
			openCloseName = "平今"
		end
		local buySellName = "-"
		if buySell == "3" then
			buySellName = "买"
			if openClose == 4 then
				buySellName = "融资买入"
			elseif openClose == 5 then
				buySellName = "买券还券"
			elseif openClose == 7 then
				buySellName = "现金还款"
			elseif openClose == 8 then
				buySellName = "现金还券"
			end
		elseif  buySell == "1" then
			buySellName = "卖"
			if openClose == 4 then
				buySellName = "融券卖出"
			elseif openClose == 5 then
				buySellName = "卖券还款"
			elseif openClose == 7 then
				buySellName = "现金还款"
			end

		end
		--gtOrderList[PortID].StockOpen[CorpCode].各个字段 gtOrderList[PortID].FutureClose[CorpCode].各个字段
		gtOrderList[portID] = gtOrderList[portID] or {}
		gtOrderList[portID].StockOpen = gtOrderList[portID].StockOpen or {}
		gtOrderList[portID].StockClose = gtOrderList[portID].StockClose or {}
		gtOrderList[portID].FutureOpen = gtOrderList[portID].FutureOpen or {}
		gtOrderList[portID].FutureClose = gtOrderList[portID].FutureClose or {}
		local templist = {}
		if marketCode == "1" or marketCode == "2" then
			if buySell == "3" then
				gtOrderList[portID].StockClose[corpCode] = gtOrderList[portID].StockClose[corpCode] or {}
				templist = gtOrderList[portID].StockClose[corpCode]
			elseif buySell == "1" then
				gtOrderList[portID].StockOpen[corpCode] = gtOrderList[portID].StockOpen[corpCode] or {}
				templist = gtOrderList[portID].StockOpen[corpCode]
			end
		elseif marketCode == "3" then
			if buySell == "1" then
				gtOrderList[portID].FutureClose[corpCode] = gtOrderList[portID].FutureClose[corpCode] or {}
				templist = gtOrderList[portID].FutureClose[corpCode]
			elseif buySell == "3" then
				gtOrderList[portID].FutureOpen[corpCode] = gtOrderList[portID].FutureOpen[corpCode] or {}
				templist = gtOrderList[portID].FutureOpen[corpCode]
			end
		end
		local log = sys_format("OnExecOrder, msg=[%s], corpCode=[%s], orderAcceptNo=[%s], orderTime=[%s], PCID=[%s], issue=[%s], baSubID=[%s], bs=[%s], oc=[%s], orderPrice=[%s],orderQty=[%s], execQty=[%s], workingQty=[%s], cancelQty=[%s], unAcceptedQty=[%s], rejectedQty=[%s], status=[%s], statusFlag=[%s] investorID[%s] baMapID[%s] executionValue[%s] reserveString2[%s] oHedgeFlag[%s]",
										message, corpCode, orderAcceptNo, orderTime, PCID, issueCode, baSubID,  buySellName, openCloseName, orderPrice, orderQuantity,executionQuantity, workingQuantity, cancelQuantity, unAcceptedQuantity, rejectedQuantity, status, statusFlag,investorID,baMapID,executionValue,reserveString2,orderHedgeFlag)
		_WriteErrorLog(log)

		templist.IssueCode = issueCode
		templist.IssueName = issueName
		templist.Market = market
		templist.BuySell = buySellName
		templist.OpenClose = openCloseName
		templist.EntrustPrice = orderPrice
		templist.EntrustQty = orderQuantity
		templist.DealQty = executionQuantity
		templist.AveragePrice = executionValue
		local dealPrice = 0
		if executionQuantity and executionQuantity ~= 0 then
			if marketCode == "1" or marketCode == "2" then
			dealPrice = executionValue / executionQuantity
			elseif marketCode == "3" then
			dealPrice = executionValue / executionQuantity / 300
			end
			if dealPrice ~= "" then
				dealPrice = sys_format(formatPriceExponent, dealPrice);
			end
		end
		templist.ExecPrice = dealPrice
		templist.CancellationQty = cancelQuantity
		templist.Time = orderTime
		templist.Date = strDate
		templist.ShareholderCode = shareholderCode
		templist.OrderAcceptNo = orderAcceptNo
		templist.Status = status
		templist.StatusFlag = statusFlag
		templist.WorkingQuantity = workingQuantity
		templist.PCID = PCID
		templist.ExecNo = "-"
		templist.ExecTime = "-"
		templist.ExecQuantity = 0
		templist.InvestorID = investorID
		templist.HedgeFlag = orderHedgeFlag
		if msg.getMessageType () == "L04" and status == "拒绝" then
			templist.Flag = reserveString2
		elseif msg.getMessageType () == "L18" then
			local tempbamap = sys_sub(baMapID,-3,-1)
			if tempbamap == "999" then
			templist.Flag = "初始化内部成交"
			else
			templist.Flag = "内部成交"
			end
		end

		if portID == gPortID or portID == "-" then
			if marketCode == "1" or marketCode == "2" then
				SendStockOpenOrderEvent(portID,corpCode,templist)
			elseif marketCode == "3" then
				SendFutureOpenOrderEvent(portID,corpCode,templist)
			end
		end

		--成交回调，并发送成交
		if msg.getMessageType () == "L07" or msg.getMessageType () == "L18"  then
			local execPrice = msg.getExecutionPrice()				--成交价格
			local execQuantity = msg.getExecutionQuantity()		--成交数量
			local execTime = msg.getExecutionTime()				--成交时间
			local execNo = msg.getExecutionNo()						--成交号
			local execDate = msg.getGeneralString1() or ""					--成交日期
			if execPrice ~= "" then
				execPrice = sys_format(formatPriceExponent, execPrice);
			end
			if execNo == "" then	--内部成交的成交号为空
				execNo = "-"
			end
			local log = sys_format("execTime:%s",execTime)
			_WriteAplLog(log)
			if execTime ~= "" then
				execTime = formatTime(execTime)
			end
			log = sys_format("execTime:%s",execTime)
			_WriteAplLog(log)
			local execLog = sys_format("OnExecOrder, execPrice:%s, execQuantity:%s, execTime:%s, execNo:%s,execDate:%s",execPrice, execQuantity, execTime, execNo,execDate)
			_WriteErrorLog(execLog)

			local tempExeclist = {}
			if marketCode == "1" or marketCode == "2" then
				if buySell == "1" then
					tempExeclist = gtOrderList[portID].StockOpen[corpCode]
				elseif buySell == "3" then
					tempExeclist = gtOrderList[portID].StockClose[corpCode]
				end
			elseif marketCode == "3" then
				if buySell == "3" then
					tempExeclist = gtOrderList[portID].FutureOpen[corpCode]
				elseif buySell == "1" then
					tempExeclist = gtOrderList[portID].FutureClose[corpCode]
				end
			end
			tempExeclist.ExecNo = execNo
			tempExeclist.ExecTime = execTime
			tempExeclist.ExecQuantity = execQuantity

			if portID == gPortID or portID == "-" then
				if marketCode == "1" or marketCode == "2" then
					SendStockOpenOrderEvent(portID,corpCode,tempExeclist)
					SendStockOpenExecuteEvent(portID,corpCode,tempExeclist)
				elseif marketCode == "3" then
					SendFutureOpenOrderEvent(portID,corpCode,tempExeclist)
					SendFutureOpenExecuteEvent(portID,corpCode,tempExeclist)
				end
				--showArbitragePosition()

				--RefreshArbitrageInfo(portID)
				--SendArbitrageInfo(portID)
			end
			--实时同步柜台持仓逻辑
			if msg.getMessageType () == "L07" then
				if marketCode == "1" or marketCode == "2" then
					local tempqty = execQuantity.getNumberValue()
					local tempAmount = tempqty*execPrice.getNumberValue()
					local tempkey = issueCode..".1"
					if buySell == "1" and openClose == 4 then	--开仓 融券卖出
					elseif buySell == "3" and openClose == 5 then --平仓 买券还券
						tempqty = - tempqty
						tempAmount = -tempAmount
					end
					--local logs =sys_format("成交：tempqty=%s,tempAmount=%s,tempkey=%s",tempqty,tempAmount,tempkey)
					--_WriteErrorLog(logs)
					if gtQryMarginPosition[investorID] then
						if gtQryMarginPosition[investorID][tempkey] then
							--logs = sys_format("柜台持仓存在investorID=%s,tempkey=%s",investorID,tempkey)
							--_WriteErrorLog(logs)
							if  buySell == "1" and openClose == 4 then
								gtQryMarginPosition[investorID][tempkey].contract_qty = gtQryMarginPosition[investorID][tempkey].contract_qty + tempqty
								gtQryMarginPosition[investorID][tempkey].contract_amount = gtQryMarginPosition[investorID][tempkey].contract_amount + tempAmount
							elseif buySell == "3" and openClose == 5 then
								gtQryMarginPosition[investorID][tempkey].today_close_qty = gtQryMarginPosition[investorID][tempkey].today_close_qty - tempqty
								gtQryMarginPosition[investorID][tempkey].today_close_amount = gtQryMarginPosition[investorID][tempkey].today_close_amount - tempAmount
							end
							sendQuerysinglePos(gtQryMarginPosition[investorID][tempkey],"margin")
						elseif buySell ~= "3" and openClose ~= 5 then
							gtQryMarginPosition[investorID][tempkey] = {}
							gtQryMarginPosition[investorID][tempkey].InvestorID = investorID
							gtQryMarginPosition[investorID][tempkey].ClientID = clientID
							gtQryMarginPosition[investorID][tempkey].IssueCode = issueCode
							gtQryMarginPosition[investorID][tempkey].MarketType = marketCode
							gtQryMarginPosition[investorID][tempkey].contract_type = "1"
							gtQryMarginPosition[investorID][tempkey].contract_qty = tempqty
							gtQryMarginPosition[investorID][tempkey].contract_amount = tempAmount
							gtQryMarginPosition[investorID][tempkey].margin = 0
							gtQryMarginPosition[investorID][tempkey].close_qty = 0
							gtQryMarginPosition[investorID][tempkey].today_close_qty = 0
							gtQryMarginPosition[investorID][tempkey].close_amount = 0
							gtQryMarginPosition[investorID][tempkey].today_close_amount = 0
							gtQryMarginPosition[investorID][tempkey].contract_fare = 0
							gtQryMarginPosition[investorID][tempkey].contract_int = 0
							gtQryMarginPosition[investorID][tempkey].contract_int_paid  = 0
							sendQuerysinglePos(gtQryMarginPosition[investorID][tempkey],"margin")
						end
					end
				elseif marketCode == "3" then
					if gtPositionTable[investorID] then
						local tempsubid = buySell
						local tempqty = execQuantity.getNumberValue()
						local tempAvlQty = 0

						tempAvlQty = tempqty
						if buySell == "3" and (openClose == 1 or openClose == 2) then
							tempsubid = "1"
							tempqty = -tempqty
							tempAvlQty = tempqty
						elseif buySell == "1" and (openClose == 1 or openClose == 2) then
							tempsubid = "3"
							tempqty = -tempqty
							tempAvlQty = tempqty
						end
						local tempkey = issueCode .. "." .. tempsubid .. "." .. orderHedgeFlag
						if gtPositionTable[investorID][tempkey] then
							local PosQuantity = gtPositionTable[investorID][tempkey].Quantity
							local PosAvQty = gtPositionTable[investorID][tempkey].AvQty
							if PosQuantity and PosQuantity ~= "" then
								PosQuantity = PosQuantity.getNumberValue()
								gtPositionTable[investorID][tempkey].Quantity = PosQuantity + tempqty
							end
							if PosAvQty and PosAvQty ~= "" then
								PosAvQty = PosAvQty.getNumberValue()
								gtPositionTable[investorID][tempkey].AvQty = PosAvQty + tempAvlQty
							end
							sendQuerysinglePos(gtPositionTable[investorID][tempkey],"future")
						elseif openClose == 0 then 	--只有开仓时才新增
							gtPositionTable[investorID][tempkey] = {}
							local poslist = gtPositionTable[investorID][tempkey]
							poslist.BuySell = buySell
							poslist.InvestorID = investorID
							poslist.IssueName = issueName
							poslist.IssueCode = issueCode
							poslist.MarketType = marketCode
							poslist.Quantity = tempqty
							poslist.ReportQty = 0
							poslist.RedeemQty = 0
							poslist.AvQty = tempAvlQty
							poslist.AvSellQty = 0
							poslist.AvePrice = execPrice
							poslist.Margin = 0
							poslist.PL = 0
							poslist.hedgeType = orderHedgeFlag
							poslist.CostValue = execPrice * tempqty
							sendQuerysinglePos(gtPositionTable[investorID][tempkey],"future")
						end
					end
				end
			end
		end
	end
_End

function FristOpenClose(batchID)  --展期
	local submit = {}
	submit = gtMoveFutureList[batchID].tOtherSide
	price  = GetOrderPrice(submit.IssueCode,submit.BS,submit.Quantity,submit.Price,submit.Tick)

	PosSubmitSingleOrder(submit.BAMapID, submit.BASubID, submit.IssueCode, submit.Side, submit.OpenClose, price, submit.Quantity, 0, "")

	gtMoveFutureList[batchID].tOtherSide = nil
end
