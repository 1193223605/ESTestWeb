﻿--反向期现套利初始版1.01
--Release version: 1.001.20140305
--- 查柜台资金接口
---直接从柜台查资金接口
--@param InvestorID 投资者帐户号
--@param ClientID 客户号， 如00101
--@param BAMapID 子账户号， 如00101-001
function L2cQueryMarketFund(investorID, clientID, baMapID)
	_WriteErrorLog("Enter L2cQueryMarketFund")
	--local investorID = InvestorID
	--local baMapID = BAMapID
	--local clientID = ClientID
	local type = _PosClient[clientID].Type
	local passWord = _GetInvestorPWD(baMapID)

	--模拟柜台密码无效，90环境取不到密码，因此写死
              --passWord = "123456"

	if passWord and passWord ~= "" and passWord ~= " " then
		local log = sys_format("L2cQueryMarketFund, baMapID=%s, clientID=%s, investorID=%s", baMapID, clientID, investorID)
		_WriteErrorLog(log)

		if type == "S" then--客户资金查询—金证证券
			local log = sys_format("当前证券账号: ClientID=%s, InvestorID=%s 的资金信息处于请求状态",clientID, investorID)
			_WriteErrorLog(log)

			--local SUBJECT = Subject_JZ
			local DTSSubmitEvent qryFundEvent;
			--消息头
			qryFundEvent.setField("MessageType","Q13") 		--客户资金查询
			qryFundEvent.setField("InvestorID",investorID) --资金帐号
			qryFundEvent.setField("Password",passWord)       --密码
			qryFundEvent.setField("WorkstationNo","660")   	--默认本机
			--New Add
			qryFundEvent.setField("ClientID",clientID)   	--加入总账户信息

			--消息体
			local DTSSubmitEvent queryList
			local DTSSubmitEvent query1
			query1.setField("function_id","KHZJLS")     --功能号
			queryList.append(query1)
			qryFundEvent.spliceArray("MessageDetail", queryList)
			_QryMarket("Fund_JZZQ",qryFundEvent)

		elseif type == "F" then--客户资金查询—上期综合期货
			local log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的资金信息处于请求状态",clientID, investorID)
			_WriteErrorLog(log)

			--local SUBJECT = Subject_SQZH
			local DTSSubmitEvent qryFundEvent;
			--消息头
			qryFundEvent.setField("MessageType","Q13") 		--客户资金查询
			qryFundEvent.setField("InvestorID",investorID) --资金帐号
			qryFundEvent.setField("Password",passWord)       --密码
			qryFundEvent.setField("WorkstationNo","660")   	--默认本机
			--New Add
			qryFundEvent.setField("ClientID",clientID)   	--加入总账户信息

			--消息体
			local DTSSubmitEvent queryList
			local DTSSubmitEvent query1
			query1.setField("function_id","KHZJLS")     --功能号
			queryList.append(query1)
			qryFundEvent.spliceArray("MessageDetail", queryList)
			_QryMarket("Fund_SQZH",qryFundEvent)

		elseif type == "M" then--客户资金以及信用资金查询--金证融资融券柜台
			--_WriteErrorLog("账号为融资融券账号，暂不支持")
			local log = sys_format("当前信用账号: ClientID=%s, InvestorID=%s 的资金信息处于请求状态",clientID, investorID)
			_WriteErrorLog(log)

			--local SUBJECT = Subject_RZRQ
			local DTSSubmitEvent qryFundEvent
			--消息头
			qryFundEvent.setField("MessageType","Q19")		--信用资金查询
			qryFundEvent.setField("InvestorID",investorID)	--资金账户
			qryFundEvent.setField("Password",passWord)		--密码
			qryFundEvent.setField("WorkstationNo","660")	--默认本机
			--New Add
			qryFundEvent.setField("ClientID",clientID)	--总账户

			--消息体
			local DTSSubmitEvent queryList
			local DTSSubmitEvent query1
			query1.setField("function_id","XYZHZJLS")	--功能号
			query1.setField("balance_account",investorID)	--资产账号
			queryList.append(query1)
			qryFundEvent.spliceArray("MessageDetail",queryList)
			_QryMarket("Fund_RZRQ",qryFundEvent)
		end
	else
		local log = sys_format("GetInvestorPWD Failed ClientID:%s,InvestorID:%s",clientID,investorID)
		_WriteErrorLog(log)
		local loog = sys_format("请确认账号[%s]是否认证通过",investorID)
		sendLog(loog,gPortID)
	end
	_WriteErrorLog("Complete L2cQueryMarketFund")
end


--金证证券柜台资金回调
_OnQryMarketResult("Fund_JZZQ",DTSSubmitEvent rplEvt)
    _WriteErrorLog("Fund_JZZQ:HaveKHZJ______________JZZQ")

	local clientMessageID = rplEvt.getField("ClientMessageID")
	_WriteErrorLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	_WriteErrorLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	_WriteErrorLog(clientID)

	if investorID and investorID ~= "" and investorID ~= " " then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
		--rplEvt.getFirstField(fieldname, topField)
		--while not rplEvt.eof() do
			if topField.isArray() then --MessageDetail
				--for index = 0, topField.size(), 1 do
					local index = 0
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					_WriteErrorLog(log)

					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)

					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Fund_JZZQ :error_no=%d,error_msg=%s",error_no,error_msg)
					_WriteErrorLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end

					if flag == 1 then
						local available_balance = rplMsg.getField("available_balance");     --可用资金
                        local post_balance      = rplMsg.getField("post_balance");          --帐户余额
                        local frozen_amount     = rplMsg.getField("frozen_amount");         --冻结金额
                        local fetch_balance     = rplMsg.getField("fetch_balance");         --可取资金
                        local total_balance     = rplMsg.getField("total_balance");         --总资产

	                    local fund = {}
	                    fund.clientMessageID    = clientMessageID
	                    fund.clientID           = clientID
	                    fund.investorID         = investorID
	                    fund.post_balance       = post_balance
	                    fund.frozen_amount      = frozen_amount
	                    fund.available_balance  = available_balance
	                    fund.fetch_balance      = fetch_balance
	                    fund.total_balance      = total_balance

	                    L2cOnQueryMarket("Fund",fund)

						log = sys_format("当前证券账号: ClientID=%s, InvestorID=%s 的资金信息处于已回复状态",clientID, investorID)
						_WriteErrorLog(log)
					else
						log = sys_format("Qry Fund_JZZQ Failed :error_no=%d,error_msg=%s",error_no,error_msg)
						_WriteErrorLog(log)
					end
				--end
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				_WriteErrorLog(logstr)
			end

			--if not rplEvt.getNextField(fieldname, topField) then
			--	break
			--end
		--end
	else
		_WriteErrorLog("Fund_JZZQ:未获取到投资者账户")
	end
_End

--上期综合期货柜台资金回调
_OnQryMarketResult("Fund_SQZH",DTSSubmitEvent rplEvt)
    _WriteErrorLog("Fund_SQZH:HaveKHZJ______________JZZQ")

	local clientMessageID = rplEvt.getField("ClientMessageID")
	_WriteErrorLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	_WriteErrorLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	_WriteErrorLog(clientID)

	if investorID and investorID ~= "" and investorID ~= " " then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
		--rplEvt.getFirstField(fieldname, topField)
		--while not rplEvt.eof() do
			if topField.isArray() then --MessageDetail
				--for index = 0, topField.size(), 1 do
					local index = 0
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					_WriteErrorLog(log)

					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)

					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Fund_SQZH :error_no=%d,error_msg=%s",error_no,error_msg)
					_WriteErrorLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end
					if flag == 1 then
						local available_balance = rplMsg.getField("available_balance");     --可用资金
                        local post_balance      = rplMsg.getField("post_balance");          --帐户余额
                        local frozen_amount     = rplMsg.getField("frozen_amount");         --冻结金额
                        local fetch_balance     = rplMsg.getField("fetch_balance");         --可取资金
                        local total_balance     = rplMsg.getField("total_balance");         --总资产

	                    local fund = {}
	                    fund.clientMessageID    = clientMessageID
	                    fund.clientID           = clientID
	                    fund.investorID         = investorID
	                    fund.post_balance       = post_balance
	                    fund.frozen_amount      = frozen_amount
	                    fund.available_balance  = available_balance
	                    fund.fetch_balance      = fetch_balance
	                    fund.total_balance      = total_balance

	                    L2cOnQueryMarket("Fund",fund)
						log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的资金信息处于已回复状态",clientID, investorID)
						_WriteErrorLog(log)

					else
						onQryFlag = false
						log = sys_format("Qry Fund_SQZH Failed :error_no=%d,error_msg=%s",error_no,error_msg)
						_WriteErrorLog(log)
					end
				--end
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				_WriteErrorLog(logstr)
			end

			--if not rplEvt.getNextField(fieldname, topField) then
				--break
			--end

	else
		_WriteErrorLog("Fund_SQZH:未获取到投资者账户")
	end
_End

--金正融资融券柜台资金回调
_OnQryMarketResult("Fund_RZRQ",DTSSubmitEvent rplEvt)
	_WriteErrorLog("Fund_RZRQ:HaveKHZJ______________JZZQ")

	local clientMessageID = rplEvt.getField("ClientMessageID")
	_WriteErrorLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	_WriteErrorLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	_WriteErrorLog(clientID)

	if investorID and investorID ~= "" then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)

		while not rplEvt.eof() do
			if topField.isArray() then --MessageDetail
				--for index = 0, topField.size(), 1 do
					local index = 0
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					_WriteErrorLog(log)

					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)

					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Fund_RZRQ :error_no=%d,error_msg=%s",error_no,error_msg)
					_WriteErrorLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end
					if flag == 1 then
						local moneyType           = rplMsg.getField("money_type")            --货币代码
						local avlCreditAmount     = rplMsg.getField("avl_credit_amount")     --可用信用额度
						local usedCreditAmount    = rplMsg.getField("used_credit_amount")    --已用信用额度
						local avlMarginAmount     = rplMsg.getField("avl_margin_amount")     --可用保证金
						local usedMarginAmount    = rplMsg.getField("used_margin_amount")    --已用保证金
						local mtContractAmount    = rplMsg.getField("mt_contract_amount")    --未还融资合约金额
						local mtContractFare      = rplMsg.getField("mt_contract_fare")      --未还融资合约费用
						local mtContractInt       = rplMsg.getField("mt_contract_int")       --未还融资合约利息
						local ssContractAmount    = rplMsg.getField("ss_contract_amount")    --未还融券合约金额
						local ssContractFare      = rplMsg.getField("ss_contract_fare")      --未还融券合约费用
						local ssContractInt       = rplMsg.getField("ss_contract_int")       --未还融券合约利息
						local capitalBalance      = rplMsg.getField("capital_balance")       --资金余额
						local avlCapital          = rplMsg.getField("avl_capital")           --可用资金
						local mainRatio           = rplMsg.getField("main_ratio")            --维持担保比例
						local marketValue         = rplMsg.getField("market_value")          --市值

						gtQryMarginFund[investorID] = gtQryMarginFund[investorID] or {}

					    gtQryMarginFund[investorID].clientMessageID    = clientMessageID
	                    gtQryMarginFund[investorID].clientID           = clientID
	                    gtQryMarginFund[investorID].investorID         = investorID
			            gtQryMarginFund[investorID].money_type         = moneyType
			            gtQryMarginFund[investorID].avl_credit_amount  = avlCreditAmount or 0
			            gtQryMarginFund[investorID].used_credit_amount = usedCreditAmount or 0
			            gtQryMarginFund[investorID].avl_margin_amount  = avlMarginAmount or 0
			            gtQryMarginFund[investorID].used_margin_amount = usedMarginAmount or 0
			            gtQryMarginFund[investorID].mt_contract_amount = mtContractAmount or 0
			            gtQryMarginFund[investorID].mt_contract_fare   = mtContractFare or 0
			            gtQryMarginFund[investorID].mt_contract_int    = mtContractInt or 0
			            gtQryMarginFund[investorID].ss_contract_amount = ssContractAmount or 0
			            gtQryMarginFund[investorID].ss_contract_fare   = ssContractFare or 0
			            gtQryMarginFund[investorID].ss_contract_int    = ssContractInt or 0
			            gtQryMarginFund[investorID].capital_balance    = capitalBalance or 0
			            gtQryMarginFund[investorID].avl_capital        = avlCapital or 0
			            gtQryMarginFund[investorID].main_ratio         = mainRatio or 0
			            gtQryMarginFund[investorID].market_value       = marketValue or 0
						--L2cOnQueryMarket("Fund",fund)

						log = sys_format("当前信用账号: ClientID=%s, InvestorID=%s 的资金信息处于已回复状态avlCapital=%s,capitalBalance=%s,avlCreditAmount=%s,avlMarginAmount=%s", clientID, investorID,avlCapital,capitalBalance,avlCreditAmount,avlMarginAmount)
						_WriteErrorLog(log)
						SendQueryFund()				--刷新资金信息
					else
						log = sys_format("Qry Fund_RZRQ Failed :error_no=%d,error_msg=%s",error_no,error_msg)
						_WriteErrorLog(log)
					end
				--end
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				_WriteErrorLog(logstr)
			end
			break
		end
	else
		_WriteErrorLog("Fund_RZRQ:未获取到投资者账户")
	end
_End

------------
--持仓查询--
------------

--查询所有柜台的持仓信息
function L2cQueryMarketPosition(investorID,clientID,baMapID,issueCode)
	_WriteErrorLog("Enter L2cQueryMarketPosition")

	local type = _PosClient[clientID].Type
	local passWord = _GetInvestorPWD(baMapID)

    --模拟柜台密码无效，90环境取不到密码，因此写死
              --passWord = "123456"
	if passWord and passWord ~= "" and passWord ~= " " then
		local log = sys_format("QryMarketPos, baMapID=%s, clientID=%s, investorID=%s, issueCode=%s", baMapID, clientID, investorID, issueCode)
		_WriteErrorLog(log)

		if type == "S" then--客户持仓查询—金证证券
			local log = sys_format("当前证券账号: ClientID=%s, InvestorID=%s 的持仓信息处于请求状态",clientID, investorID)
			_WriteErrorLog(log)

			--local SUBJECT = Subject_JZ
			local DTSSubmitEvent qryPosEvent;
			--消息头
			qryPosEvent.setField("MessageType","Q14") 		--客户持仓查询
			qryPosEvent.setField("InvestorID",investorID) --资金帐号
			qryPosEvent.setField("Password",passWord)       --密码
			qryPosEvent.setField("WorkstationNo","660")   	--默认本机
			--New Add
			qryPosEvent.setField("ClientID",clientID)   	--加入总账户信息

			--消息体
			local DTSSubmitEvent queryList
			local DTSSubmitEvent query1
			query1.setField("function_id","KHCCLS")     --功能号

			--Set IssueCode 单个合约查询，issueCode为空时查所有持仓
			--query1.setField("issue_code",issueCode)     --功能号

			queryList.append(query1)
			qryPosEvent.spliceArray("MessageDetail", queryList)
			_QryMarket("Pos_JZZQ",qryPosEvent)
		elseif type == "F" then--客户持仓查询—上期综合期货
			local log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的持仓信息处于请求状态",clientID, investorID)
			_WriteErrorLog(log)

			--local SUBJECT = Subject_SQZH
			local DTSSubmitEvent qryPosEvent;
			--消息头
			qryPosEvent.setField("MessageType","Q14") 		--客户持仓查询
			qryPosEvent.setField("InvestorID",investorID) --资金帐号
			qryPosEvent.setField("Password",passWord)       --密码
			qryPosEvent.setField("WorkstationNo","660")   	--默认本机
			--New Add
			qryPosEvent.setField("ClientID",clientID)   	--加入总账户信息

			--消息体
			local DTSSubmitEvent queryList
			local DTSSubmitEvent query1
			query1.setField("function_id","KHCCLS")     --功能号

			--Set IssueCode 单个合约查询，issueCode为空时查所有持仓
			--query1.setField("issue_code",issueCode)     --功能号
			queryList.append(query1)
			qryPosEvent.spliceArray("MessageDetail", queryList)
			_QryMarket("Pos_SQZH",qryPosEvent)
		elseif type == "M" then--客户持仓信息查询--金证融资融券柜台
			--_WriteErrorLog("账号为融资融券账号，暂不支持")
			local log = sys_format("当前信用账号: ClientID=%s, InvestorID=%s 的持仓信息处于请求状态",clientID, investorID)
			_WriteErrorLog(log)
			local endDate = _PosGetYMD()
			local startDate = getBackDate(90)
			local SUBJECT = "Subject_RZRQ"
			local DTSSubmitEvent qryCreditContractEvent
			--消息头
			qryCreditContractEvent.setField("MessageType","Q18")		--信用合约查询
			qryCreditContractEvent.setField("InvestorID",investorID)	--资金账号
			qryCreditContractEvent.setField("Password",passWord)		--密码
			qryCreditContractEvent.setField("WorkstationNo","660")		--默认本机
			--New Add
			qryCreditContractEvent.setField("ClientID",clientID	)		--总账户

			--消息体
			local DTSSubmitEvent queryList
			local DTSSubmitEvent query1
			query1.setField("function_id","XYHYLS")     --功能号
			query1.setField("balance_account",investorID)   	--资产账户
			query1.setField("start_date",startDate)    --时间格式为：YYYY-MM-DD
			query1.setField("end_date",endDate)   	--时间格式为：YYYY-MM-DD

			queryList.append(query1)
			qryCreditContractEvent.spliceArray("MessageDetail", queryList)
			_QryMarket("Issue_RZRQ",SUBJECT,qryCreditContractEvent)

		end
	else
		local log = sys_format("GetInvestorPWD Failed ClientID:%s,InvestorID:%s",clientID,investorID)
		_WriteErrorLog(log)
	end
end

--金证证券柜台持仓回调
_OnQryMarketResult("Pos_JZZQ",DTSSubmitEvent rplEvt)
    _WriteErrorLog("Pos_JZZQ:HaveKHZJ______________JZZQ")
	local encode = rplEvt.encode()
	local startLog = sys_format("******柜台持仓查询 Pos_JZZQ Start :encode = [%s]*******",encode)
	_WriteErrorLog(startLog)
    local clientMessageID = rplEvt.getField("ClientMessageID")
	_WriteErrorLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	_WriteErrorLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	_WriteErrorLog(clientID)

	if investorID and investorID ~= "" and investorID ~= " " then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
		--rplEvt.getFirstField(fieldname, topField)
		--while not rplEvt.eof() do
			if topField.isArray() then --MessageDetail
			    local positionList = {}
			    local InvestorID = ""
				for index = 0, topField.size()-1, 1 do
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					_WriteErrorLog(log)

					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)
					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Pos_JZZQ :error_no=%d,error_msg=%s",error_no,error_msg)
					_WriteErrorLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end
					if flag == 1 then
						local issueCode = rplMsg.getField("issue_code")
						if issueCode ~= false and issueCode ~= "" and issueCode ~= " " and issueCode ~= nil then
                            local issue_code	      = rplMsg.getField("issue_code")          --证券代码
							--local issue_name	      = rplMsg.getField("issue_name")          --证券名称
							local issue_name
							if issue_code then
								issue_name = _PosIssueNameTable[issue_code] --rplMsg.getField("contract_name")		--合约名称
								if issue_name == nil then
									issue_name = issue_code
								end
							end
                            local exchange_type	      = rplMsg.getField("exchange_type")       --交易所
                            local position_qty	      = rplMsg.getField("position_qty")        --今持仓量
                            local available_qty	      = rplMsg.getField("available_qty")       --可用数量
                            local enable_redeem_qty	  = rplMsg.getField("enable_redeem_qty")   --可赎回数量
                            local enable_report_qty	  = rplMsg.getField("enable_report_qty")   --可申购数量
                            local enable_sell_qty	  = rplMsg.getField("enable_sell_qty")     --可卖出数量
                            local pos_average_price	  = rplMsg.getField("pos_average_price")   --持仓均价
                            local assign_cost_price	  = rplMsg.getField("assign_cost_price")   --摊薄成本价
                            local margin	          = rplMsg.getField("margin")              --保证金
                            local profit_total	      = rplMsg.getField("profit_total")        --累计盈亏
                            local profit_float	      = rplMsg.getField("profit_float")        --浮动盈亏
                            local entrust_bs	      = rplMsg.getField("entrust_bs")          --买卖方向
                            local insure_flag	      = rplMsg.getField("insure_flag")         --投机套保标志
                            local position_cost       = rplMsg.getField("position_cost")       --持仓成本
                            local position_str	      = rplMsg.getField("position_str")        --定位串


							local cost = 0
							if pos_average_price ~= "" and pos_average_price ~= nil and pos_average_price ~= false then
								cost = sys_format("%.2f", pos_average_price)
							end

							local quantity=0
							--local position_qty = rplMsg.getField("position_qty");--当前拥股,对应DTS的持仓量
							if position_qty ~= "" and position_qty ~= nil and position_qty ~= false then
								quantity = sys_format("%.0f", position_qty)
							end

							local avlQuantity=0
							--local available_qty = rplMsg.getField("available_qty");--可用数量
							if available_qty~= false and available_qty ~= "" and available_qty ~= nil then
								avlQuantity = sys_format("%.0f", available_qty);
							end

                            local position = {}
                            position.clientMessageID    = clientMessageID
                            position.investorID         = investorID
                            InvestorID = investorID
                            position.clientID           = clientID
                            position.issue_code	        = issue_code
                            position.issue_name	        = issue_name
                            position.exchange_type	    = exchange_type
                            position.position_qty	    = quantity
                            position.available_qty	    = avlQuantity
                            position.enable_redeem_qty	= enable_redeem_qty
                            position.enable_report_qty	= enable_report_qty
                            position.enable_sell_qty	= enable_sell_qty
                            position.pos_average_price	= cost
                            position.assign_cost_price	= assign_cost_price
                            position.margin	            = margin
                            position.profit_total	    = profit_total
                            position.profit_float	    = profit_float
                            position.entrust_bs	        = entrust_bs
                            position.insure_flag	    = insure_flag
                            position.position_cost      = position_cost
                            position.position_str	    = position_str

                            sys_insert(positionList, position)
						end
					else
						log = sys_format("Qry Pos_JZZQ Failed :error_no=%d,error_msg=%s",error_no,error_msg)
						_WriteErrorLog(log)
					end
				end
				positionList.investorID = InvestorID
				L2cOnQueryMarket("Position",positionList)
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				_WriteErrorLog(logstr)
			end

			--if not rplEvt.getNextField(fieldname, topField) then
				--break
			--end
		--end
		local log = sys_format("当前证券账号: ClientID=%s, InvestorID=%s 的柜台持仓信息处于已回复状态", clientID, investorID)
		_WriteErrorLog(log)
	else
		_WriteErrorLog("Pos_RZRQ:未获取到柜台投资者持仓")
	end
_End

--上期综合期货柜台持仓回调
_OnQryMarketResult("Pos_SQZH",DTSSubmitEvent rplEvt)
    _WriteErrorLog("Pos_SQZH:HaveKHZJ______________JZZQ")
	local encode = rplEvt.encode()
	local startLog = sys_format("******柜台持仓查询 Fund_SQZH Start :encode = [%s]*******",encode)
	_WriteErrorLog(startLog)
    local clientMessageID = rplEvt.getField("ClientMessageID")
	_WriteErrorLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	_WriteErrorLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	_WriteErrorLog(clientID)

	local onQryFlag = true
	if investorID and investorID ~= "" and investorID ~= " " then
		--local clientID = sys_sub(clientMessageID, 8, -1)
		--local investorID = _PosClient[clientID].InvestorID
		--local clientID = _PosInvestor2Client[investorID]
		--_WriteErrorLog(clientID)

		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
		--rplEvt.getFirstField(fieldname, topField)
		--while not rplEvt.eof() do
			if topField.isArray() then --MessageDetail
			    local positionList = {}
			    local InvestorID = ""
				for index = 0, topField.size()-1, 1 do
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					_WriteErrorLog(log)

					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)

					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Pos_SQZH :error_no=%d,error_msg=%s",error_no,error_msg)
					_WriteErrorLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end
					if flag == 1 then
					    local issueCode = rplMsg.getField("issue_code")
					    if issueCode ~= false and issueCode ~= "" and issueCode ~= " " and issueCode ~= nil then
					        local issue_code	      = rplMsg.getField("issue_code")          --证券代码
                            --local issue_name	      = rplMsg.getField("issue_name")          --证券名称
							local issue_name
							if issue_code then
								issue_name = _PosIssueNameTable[issue_code] --rplMsg.getField("contract_name")		--合约名称
								if issue_name == nil then
									issue_name = issue_code
								end
							end
                            local exchange_type	      = rplMsg.getField("exchange_type")       --交易所
                            local position_qty	      = rplMsg.getField("position_qty")        --今持仓量
                            local available_qty	      = rplMsg.getField("available_qty")       --可用数量
                            local enable_redeem_qty	  = rplMsg.getField("enable_redeem_qty")   --可赎回数量
                            local enable_report_qty	  = rplMsg.getField("enable_report_qty")   --可申购数量
                            local enable_sell_qty	  = rplMsg.getField("enable_sell_qty")     --可卖出数量
                            local pos_average_price	  = rplMsg.getField("pos_average_price")   --持仓均价
                            local assign_cost_price	  = rplMsg.getField("assign_cost_price")   --摊薄成本价
                            local margin	          = rplMsg.getField("margin")              --保证金
                            local profit_total	      = rplMsg.getField("profit_total")        --累计盈亏
                            local profit_float	      = rplMsg.getField("profit_float")        --浮动盈亏
                            local entrust_bs	      = rplMsg.getField("entrust_bs")          --买卖方向
                            local insure_flag	      = rplMsg.getField("insure_flag")         --投机套保标志
                            local position_cost       = rplMsg.getField("position_cost")       --持仓成本--持仓均价
                            local position_str	      = rplMsg.getField("position_str")        --定位串


							local cost = 0
							if position_cost ~= "" and position_cost ~= nil and position_cost ~= false then
								local contractSize = _PosIssueContractSizeTable[issue_code]
								if position_qty ~= 0 and position_qty ~= "0" and contractSize ~= nil then
									cost = position_cost / position_qty / contractSize
									cost=sys_format("%.2f",cost)
								end
							end
							if position_qty ~= "" and position_qty ~= nil and position_qty ~= "0" and position_qty ~= 0 then
								if entrust_bs == "2" then
									entrust_bs = "1"
								end

								local position = {}
								position.clientMessageID    = clientMessageID
								position.investorID         = investorID
								position.clientID           = clientID
								InvestorID = clientID
								position.issue_code	        = issue_code
								position.issue_name	        = issue_name
								position.exchange_type	    = exchange_type
								position.position_qty	    = position_qty
								position.available_qty	    = position_qty
								position.enable_redeem_qty	= enable_redeem_qty
								position.enable_report_qty	= enable_report_qty
								position.enable_sell_qty	= enable_sell_qty
								position.pos_average_price	= cost
								position.assign_cost_price	= assign_cost_price
								position.margin	            = margin
								position.profit_total	    = profit_total
								position.profit_float	    = profit_float
								position.entrust_bs	        = entrust_bs
								position.insure_flag	    = insure_flag
								position.position_cost      = position_cost
								position.position_str	    = position_str

								sys_insert(positionList, position)
							end
					    end
					else
						log = sys_format("Qry Pos_SQZH :error_no=%d,error_msg=%s",error_no,error_msg)
						_WriteErrorLog(log)
					end
				end
				positionList.investorID = InvestorID
				L2cOnQueryMarket("Position",positionList)
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				_WriteErrorLog(logstr)
			end

			--if not rplEvt.getNextField(fieldname, topField) then
				--break
			--end
		--end
		local log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的柜台持仓信息处于已回复状态", clientID, investorID)
		_WriteErrorLog(log)
	else
		_WriteErrorLog("Pos_RZRQ:未获取到柜台投资者持仓")
	end
_End

--柜台信用合约信息回调
_OnQryMarketResult("Issue_RZRQ",DTSSubmitEvent rplEvt)
    _WriteErrorLog("Issue_RZRQ")
	local encode = rplEvt.encode()
	local startLog = sys_format("******信用合柜台持仓查询 Pos_RZRQ Start :encode = [%s]*******",encode)
	_WriteErrorLog(startLog)
	local clientMessageID = rplEvt.getField("ClientMessageID")
	_WriteErrorLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	_WriteErrorLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	_WriteErrorLog(clientID)

	if investorID and investorID ~= "" then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
		--rplEvt.getFirstField(fieldname, topField)
		while not rplEvt.eof() do
			if topField.isArray() then --MessageDetail
			    gtQryMarginPosition[investorID] = {}
				for index = 0, topField.size()-1, 1 do
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					_WriteErrorLog(log)

					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)

					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Credit_RZRQ :error_no=%d,error_msg=%s",error_no,error_msg)
					_WriteErrorLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end
					if flag == 1 then
                        local open_date	         = rplMsg.getField("open_date")	             --合约开始日期
                        local close_date	     = rplMsg.getField("close_date")	             --合约了结日期
                        local issue_code	     = rplMsg.getField("issue_code")	             --证券代码
                        local exchange_type	     = rplMsg.getField("exchange_type")	         --市场代码
                        local contract_type	     = rplMsg.getField("contract_type")	         --合约类型
                        local contract_qty	     = rplMsg.getField("contract_qty")	             --合约数量
                        local contract_amount	 = rplMsg.getField("contract_amount")         --合约金额
                        local margin	         = rplMsg.getField("margin")	                 --保证金
                        local margin_ratio	     = rplMsg.getField("margin_ratio")	             --保证金比例
                        local close_qty	         = rplMsg.getField("close_qty")	             --已还数量
                        local today_close_qty	 = rplMsg.getField("today_close_qty")	         --实时已还数量
                        local close_amount	     = rplMsg.getField("close_amount")	             --已还金额
                        local today_close_amount = rplMsg.getField("today_close_amount")   	 --实时已还金额
                        local contract_int_date	 = rplMsg.getField("contract_int_date")	     --合约计息日期
                        local contract_fare	     = rplMsg.getField("contract_fare")	         --合约费用
                        local contract_int	     = rplMsg.getField("contract_int")	             --合约利息
                        local contract_int_paid	 = rplMsg.getField("contract_int_paid")	     --已还利息
                        local contract_id	     = rplMsg.getField("contract_id")	             --合同号

						log = sys_format("CreditPosition: ClientID=%s,InvestorID=%s,IssueCode=%s,contractID=%s,contract_qty=%s,contract_amount=%s,close_qty=%s,close_amount=%s,contract_type=%s", clientID, investorID,issue_code,contract_id,contract_qty,contract_amount,close_qty,close_amount,contract_type)
						_WriteErrorLog(log)
						if contract_type == "1" then --融资持仓不显示
							local poskey = issue_code.."."..contract_type
							if not gtQryMarginPosition[investorID][poskey] then
								gtQryMarginPosition[investorID][poskey] = {}
								gtQryMarginPosition[investorID][poskey].InvestorID = investorID
								gtQryMarginPosition[investorID][poskey].ClientID = clientID
								gtQryMarginPosition[investorID][poskey].IssueCode = issue_code
								gtQryMarginPosition[investorID][poskey].MarketType = exchange_type
								gtQryMarginPosition[investorID][poskey].contract_type = contract_type
								gtQryMarginPosition[investorID][poskey].contract_qty = 0
								gtQryMarginPosition[investorID][poskey].contract_amount = 0
								gtQryMarginPosition[investorID][poskey].margin = 0
								--gtQryMarginPosition[investorID][poskey].margin_ratio = 0
								gtQryMarginPosition[investorID][poskey].close_qty = 0
								gtQryMarginPosition[investorID][poskey].today_close_qty = 0
								gtQryMarginPosition[investorID][poskey].close_amount = 0
								gtQryMarginPosition[investorID][poskey].today_close_amount = 0
								gtQryMarginPosition[investorID][poskey].contract_fare = 0
								gtQryMarginPosition[investorID][poskey].contract_int = 0
								gtQryMarginPosition[investorID][poskey].contract_int_paid  = 0
							end
							if contract_qty and contract_qty ~= "" then
								gtQryMarginPosition[investorID][poskey].contract_qty = gtQryMarginPosition[investorID][poskey].contract_qty + contract_qty
							end
							if contract_amount and contract_amount ~="" then
								gtQryMarginPosition[investorID][poskey].contract_amount = gtQryMarginPosition[investorID][poskey].contract_amount + contract_amount
							end
							if margin and margin ~= "" then
								gtQryMarginPosition[investorID][poskey].margin = gtQryMarginPosition[investorID][poskey].margin + margin
							end
							if close_qty and close_qty ~= "" then
								gtQryMarginPosition[investorID][poskey].close_qty = gtQryMarginPosition[investorID][poskey].close_qty + close_qty
							end
							if today_close_qty and today_close_qty ~= "" then
								gtQryMarginPosition[investorID][poskey].today_close_qty = gtQryMarginPosition[investorID][poskey].today_close_qty + today_close_qty
							end
							if close_amount and close_amount ~= "" then
								gtQryMarginPosition[investorID][poskey].close_amount = gtQryMarginPosition[investorID][poskey].close_amount + close_amount
							end
							if today_close_amount and today_close_amount ~= "" then
								gtQryMarginPosition[investorID][poskey].today_close_amount = gtQryMarginPosition[investorID][poskey].today_close_amount + today_close_amount
							end
							if contract_fare and contract_fare ~= "" then
								gtQryMarginPosition[investorID][poskey].contract_fare = gtQryMarginPosition[investorID][poskey].contract_fare + contract_fare
							end
							if contract_int and contract_int ~= "" then
								gtQryMarginPosition[investorID][poskey].contract_int = gtQryMarginPosition[investorID][poskey].contract_int + contract_int
							end
							if contract_int_paid and contract_int_paid ~= "" then
								gtQryMarginPosition[investorID][poskey].contract_int_paid = gtQryMarginPosition[investorID][poskey].contract_int_paid + contract_int_paid
							end

							if not _PosPriceTable[issue_code] then
								_RegisterPrice(_IssueCode = issue_code, _MarketCode = exchange_type)
							end
						end
					else
						log = sys_format("Qry Issue_RZRQ Failed :error_no=%d,error_msg=%s",error_no,error_msg)
						_WriteErrorLog(log)
					end
				end
				SendQueryPos()	--刷新持仓
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				_WriteErrorLog(logstr)
			end
			break
		end
	else
		_WriteErrorLog("Issue_RZRQ:未获取到柜台信用合约信息")
	end
_End

function L2cOnQueryMarket(BusinessType, listInfo)		--柜台回调返回函数
	if BusinessType == "Position" then
		for i,info in pairs (listInfo) do
			if i ~= "investorID" then
				--柜台返回持仓
				local investorID	      = info.investorID	         --资金账号
				local issue_code	      = info.issue_code	         --证券代码
				local issue_name	      = info.issue_name          --证券名称
				local exchange_type	      = info.exchange_type       --交易所
				local position_qty	      = info.position_qty        --今持仓量
				local available_qty	      = info.available_qty       --可用数量
				local enable_redeem_qty	  = info.enable_redeem_qty   --可赎回数量
				local enable_report_qty	  = info.enable_report_qty   --可申购数量
				local enable_sell_qty	  = info.enable_sell_qty     --可卖出数量
				local pos_average_price	  = info.pos_average_price   --持仓均价
				local assign_cost_price	  = info.assign_cost_price   --摊薄成本价
				local margin	          = info.margin            	 --保证金
				local profit_total	      = info.profit_total        --累计盈亏
				local profit_float	      = info.profit_float        --浮动盈亏
				local entrust_bs	      = info.entrust_bs          --买卖方向
				local insure_flag	      = info.insure_flag         --投机套保标志
				local position_cost       = info.position_cost       --持仓成本
				local position_str	      = info.position_str        --定位串

--~ 				_WriteErrorLog(investorID)
--~ 				_WriteErrorLog(issue_code)
--~ 				_WriteErrorLog(issue_name)
--~ 				_WriteErrorLog(exchange_type)
--~ 				_WriteErrorLog(position_qty)
--~ 				_WriteErrorLog(available_qty)
--~ 				_WriteErrorLog(enable_redeem_qty)
--~ 				_WriteErrorLog(enable_sell_qty)
--~ 				_WriteErrorLog(pos_average_price)
--~ 				_WriteErrorLog(assign_cost_price)
--~ 				_WriteErrorLog(margin)
--~ 				_WriteErrorLog(profit_total)
--~ 				_WriteErrorLog(profit_float)
--~ 				_WriteErrorLog(entrust_bs)
--~ 				_WriteErrorLog(insure_flag)
--~ 				_WriteErrorLog(position_cost)
--~ 				_WriteErrorLog(position_str)
--~ 				_WriteErrorLog(entrust_bs)

				entrust_bs = entrust_bs.toString()
				if not gtPositionTable[investorID] then
					gtPositionTable[investorID] = {}
					_WriteErrorLog(investorID)
				end
				local MarketCode = _PosIssueMarketTable[issue_code]
				local key = issue_code .. "."
				if MarketCode == "1" or MarketCode == "2" then
				else
					key = issue_code .. "." .. entrust_bs .. "." .. insure_flag
				end

				if not  gtPositionTable[investorID][key] then
					gtPositionTable[investorID][key] = {}
					_WriteErrorLog(key)
				end
				local poslist = gtPositionTable[investorID][key]
				poslist.BuySell = entrust_bs
				poslist.InvestorID = investorID
				poslist.IssueName = issue_name
				poslist.IssueCode = issue_code
				poslist.MarketType = exchange_type
				poslist.Quantity = position_qty
				poslist.ReportQty = enable_report_qty
				poslist.RedeemQty = enable_redeem_qty
				poslist.AvQty = available_qty
				poslist.AvSellQty = enable_sell_qty
				poslist.AvePrice = pos_average_price
				poslist.Margin = margin
				poslist.PL = profit_float
				poslist.hedgeType = insure_flag
				poslist.CostValue = position_cost
			end
		end
		SendQueryPos()

	elseif BusinessType == "Fund" then
		--柜台返回资金

		local investorID = listInfo.investorID
		local clientID = listInfo.clientID
		local available_balance = listInfo.available_balance
		local frozen_amount = listInfo.frozen_amount
		local post_balance = listInfo.post_balance
		local fetch_balance = listInfo.fetch_balance
		local total_balance = listInfo.total_balance

--~ 		_WriteErrorLog(investorID)
--~ 		_WriteErrorLog(clientID)
--~ 		_WriteErrorLog(available_balance)
--~ 		_WriteErrorLog(frozen_amount)
--~ 		_WriteErrorLog(post_balance)
--~ 		_WriteErrorLog(fetch_balance)
--~ 		_WriteErrorLog(total_balance)
		if not gQueryFund[investorID] then
			gQueryFund[investorID] = {AvlFund=0,OrderFund=0,AssetValue=0,Margin=0,Balance=0}
		end
		gQueryFund[investorID].ClientID = clientID
		gQueryFund[investorID].AvlFund = available_balance		 --可用资金
		gQueryFund[investorID].OrderFund = frozen_amount		--冻结金额
		gQueryFund[investorID].AssetValue = total_balance		--总资产
		gQueryFund[investorID].Margin = post_balance			--帐户余额
		gQueryFund[investorID].Balance = fetch_balance			--可取资金

		SendQueryFund()				--刷新资金信息
	end
end


--取得n天之前的日期
function getBackDate(n)
	local calendarSize = sys_getSize(_PosTradingDate)
	local backDateIndex = 1
	if (calendarSize - n + 1) >= 1 then
		backDateIndex = calendarSize - n + 1
	end
	return _PosTradingDate[backDateIndex]
end
