﻿--反向期现套利初始版1.01
--Release version: 1.001.20140305
_WriteAplLog("反向期现套利初始版 Version:1.001 2014-03-05")
require("Position")
require("DefineEvent_v")
require("Trade_v")
require("QueryFundPos_v")
require("Z_OnEvent_v")

_DefineStrategyParameters
	_Number _Refreash = 5					_Comment	"组合持仓刷新时间"
_End
-----------------
--Pos库调用函数--
-----------------
Initialization()				--初始化
function Initialization()
	_InitializeFlag = 0
	gUserID = _GetDealerID();		--用户号
	gFutureCurrent = ""
	gFutureNextMonth = ""
	gFutureSeasonMonth = ""
	gFutureNextSeason = ""
	gFutureList={}					--当前期货表
	gtInventoryList = {}			--组合列表		gtInventoryList[InventoryID]
	gtInventoryName = {}			--组合名称表
	gtCombinList = {}				--套利组合列表	gtCombinList[PortID].各个字段
	gtOrderList = {}				--委托表 gtOrderList[PortID].StockOpen[CorpCode].各个字段 gtOrderList[PortID].FutureClose[CorpCode].各个字段

	gtStockPositionTable = {}		--现货持仓表
	gtFuturePositionTable = {}		--期货持仓表
	gtArbitragePositionTable = {}	--套利持仓
	gtArbitrageInfoTable = {}		--套利详情信息表
	gPortID = ""					--当前选中的套利组合号	"v20131011xxx",v表示反向套利
	gMarginbaMapID = ""				--信用账户
	gFuturebaMapID = ""				--期货账号
	gtInvestorIDMap = {}			--柜台账户查找下单账户
	gtMoveFuture = {}               --期货移仓数据表
	gtMoveFutureList = {}           --期货移仓开平优先存储下单信息
	gtBackHand = {}                 --反手委托表

	gtAutoOrder = {}
	gtYesOrder = {}
	gtBasisBets = {}                --基差敞口表
	gcount = {}
	--gAutoOpen3 = 0 					--计数器
	--gAutoClose3 = 0
	gtSaveOld = {}                  -- 存老的状态
	gSubmitNo = 0                   -- 存储唯一分辨码

	--xy
	gChooseCombinFlag = "0"			--选择组合标识
	gRefreshListFlag = "0"			--选择组合标识
	gQueryFund = {}					--柜台资金信息表(证券、期货账户)
	gtPositionTable = {}			--持仓表(证券、期货账户)
	gHedgeFlag = "0"				--交易编码
	--add by lianghui
	gtQryMarginFund = {}			--信用账户柜台资金信息
	gtQryMarginPosition = {}		--信用账户柜台持仓信息(信用记录)第一层key:investorID,第二层key:contract_id合同号
	--单笔委托--
	_Querylist = {}					--单笔合约维护表
	_QueryIssue = ""				--单笔委托中当前显示合约
	_DD = 0							--单笔委托资金状况显示标识
	_QueryTable = {}				--单笔委托中资金状况显示使用表
	_gRefreash = _Refreash
	TT = 0
	--初始化Position全局变量
	--_WriteErrorLog("POS库开始初始化")
	PosInitialize()
	PosAddBAMapIDForCurrentUser()
	PosStart();
end

function OnPositionInitialized()		--持仓初始化完毕逻辑
	_WriteErrorLog("POS库初始化完毕")
	local issueMarket = _PosIssueMarketTable["M000300"]
	_RegisterPrice(_IssueCode="M000300",_MarketCode=issueMarket)	--注册行情
	_StartTimer(_TimerName="TimeInterval",_Interval=1000)

	local marginID = ""
	local futureID = ""
	for baMapID, dummy in pairs(_PosUserBAMapTable[gUserID]) do
		local accountCode = _PosBAMapAccount[baMapID]
		local log = sys_format("baMapID[%s],accountCode[%s]",baMapID,accountCode)
		_WriteAplLog(log)
		if accountCode then
			if _PosFundStatus[accountCode] then
				local investorID = _PosFundStatus[accountCode].InvestorID
				local accountType = _PosFundStatus[accountCode].Type
				local condition = sys_sub(baMapID,-3,-1)
				if condition == "000" then
					local fund = _PosFundStatus[accountCode].AvlFund
					fund = fund.getNumberValue();
					if fund < 1000000000 then				--000子账号添加资金满足子账号一定有钱
						local temp = 1000000000 - fund
						PosAdjustFund(accountCode, temp)
					end
					if accountType == "M" then
						marginID = marginID .. investorID .. ";"
					elseif accountType == "F" then
						futureID = futureID .. investorID .. ";"
					end
					gtInvestorIDMap[investorID] = baMapID 							--建立一一对应表,统一用999子账户下单
				end
			end
		end
	end
	_WriteAplLog(marginID)
	_WriteAplLog(futureID)

	local DTSEvent CreateMarginID = _CreateEventObject("VCreateMarginIDEvent")
	CreateMarginID._SetFld("BAMapID",marginID)
	_SendToClients(CreateMarginID)

	local DTSEvent CreateFutureID = _CreateEventObject("VCreateFutureIDEvent")
	CreateFutureID._SetFld("BAMapID",futureID)
	_SendToClients(CreateFutureID)

	--获取组合信息
	InquireCombin()
	--刷新持仓
	--RefreshStockPosition();
	--RefreshArbitragePosition();

	DTSEvent SaveCombinDataEvent = _CreateEventObject("VSaveCombinDataEvent");
	DTSDynamicData CombinDynamicData = _CreateDynamicData(TSInstanceName = "CombinDataList", fileType = _DataOtherType, SaveCombinDataEvent SaveCombinDataEvent);
	_WriteErrorLog("准备读取历史套利组合")
	CombinDynamicData._GetDynamicData(dataName = "CombinDataList", condition = "");

	DTSEvent SaveArbitrageInfoEvent = _CreateEventObject("VSaveArbitrageInfo");
	DTSDynamicData gtSaveArbitrageInfo = _CreateDynamicData(TSInstanceName = "SaveArbitrageInfoData", fileType = _DataOtherType, SaveArbitrageInfo SaveArbitrageInfoEvent);
	gtSaveArbitrageInfo._GetDynamicData(dataName = "SaveArbitrageInfoData", condition = "");

	_InitializeFlag = 1						--初始化完成

	_WriteErrorLog("POS库初始化完毕")

	_StartTimer(_TimerName="initTimer",_Interval=10000,_MaxNumber=1)
	local DTSEvent Initialized = _CreateEventObject("VInitialized")
	Initialized._SetFld("Flag",1)
	_SendToClients(Initialized)

	sendLog("初始化完毕",gPortID)
end


function OnPositionChanged(pos, reason)	--持仓变动逻辑
end

function OnPositionError(errorInfo)
end

function OnPositionDebugInfo(debugInfo)
end

function OnBackTestDayEnd()
end

function OnExecution(position, exec)
	--计算组合的买入金额、卖出金额、冲击成本等

	local portID = sys_sub(position.BASubID, 2, -1)
	local staticInfo = gtArbitrageInfoTable[portID]
	if staticInfo and exec.MsgType ~= "L18" then

		local issue = exec.IssueCode
		local market = _PosIssueMarketTable[issue]
		if market =="1" or market =="2" then
			if exec.OpenClose == 0 or exec.OpenClose == 4 then  --开仓
			    if staticInfo.SellAmount =="-" then
					staticInfo.SellAmount = 0
				end

				if staticInfo.SpotSellChargeCost =="-" then
					staticInfo.SpotSellChargeCost = 0
				end
				if staticInfo.SpotTradeFee =="-" then
					staticInfo.SpotTradeFee = 0
				end

				local sell = exec.Quantity * exec.Price
				local cost = 0
				if gtCombinList[portID].List[issue] then
					local lastPrice = gtCombinList[portID].List[issue].OpenLastPrice
					if lastPrice then
						cost = exec.Quantity * (lastPrice - exec.Price)
					end
				end
				staticInfo.SellAmount = staticInfo.SellAmount + sell
				staticInfo.SpotSellChargeCost = staticInfo.SpotSellChargeCost + cost
				staticInfo.StartTime = getDateTime()
				staticInfo.SpotTradeFee = staticInfo.SpotTradeFee + exec.Fare
				staticInfo.SpotCumulationPL = staticInfo.SpotCumulationPL + exec.RealizedPL

			else     --平仓
				if staticInfo.BuyAmount =="-" then
					staticInfo.BuyAmount = 0
				end

				if staticInfo.SpotBuyChargeCost =="-" then
					staticInfo.SpotBuyChargeCost = 0
				end

				local buy = exec.Quantity * exec.Price
				local cost = 0
				if gtCombinList[portID].List[issue] then
					local lastPrice = gtCombinList[portID].List[issue].CloseLastPrice
					if lastPrice then
						cost = exec.Quantity * (exec.Price - lastPrice)
					end
				end
				staticInfo.BuyAmount = staticInfo.BuyAmount + buy
				staticInfo.SpotBuyChargeCost = staticInfo.SpotBuyChargeCost + cost
				staticInfo.EndTime = getDateTime()

				staticInfo.SpotTradeFee = staticInfo.SpotTradeFee + exec.Fare
				staticInfo.SpotCumulationPL = staticInfo.SpotCumulationPL + exec.RealizedPL

				--如果股票的被全部平仓后，把分红派息就转到累计平仓盈亏里了
				if position.Quantity <= 0 then
				  staticInfo.SpotCumulationPL = staticInfo.SpotCumulationPL +  position.CumulationDividend
				end
			end
		elseif market == "3"  then --期货
		    if exec.OpenClose == 0 then  --开仓

				if staticInfo.OpenPrice =="-" then
					staticInfo.OpenPrice = 0
				end

				if staticInfo.FutureBuyChargeCost =="-" then
					staticInfo.FutureBuyChargeCost = 0
				end

				if staticInfo.FutureTradeFee =="-" then
					staticInfo.FutureTradeFee = 0
				end


				staticInfo.OpenPrice = (staticInfo.OpenPrice * staticInfo.OpenQtySum  + exec.Quantity * exec.Price )/(staticInfo.OpenQtySum  + exec.Quantity)
				staticInfo.OpenQtySum = staticInfo.OpenQtySum + exec.Quantity

				local cost = 0
				if staticInfo.OpenFuturePrice then
					cost = (exec.Price - staticInfo.OpenFuturePrice ) * exec.Quantity * _PosIssueContractSizeTable[issue]
				end
				staticInfo.FutureBuyChargeCost = staticInfo.FutureBuyChargeCost + cost
				staticInfo.StartTime = getDateTime()

				staticInfo.FutureTradeFee = staticInfo.FutureTradeFee + exec.Fare
				staticInfo.FutureCumulationPL = staticInfo.FutureCumulationPL + exec.RealizedPL
			else
			    if staticInfo.ClosePrice =="-" then
					staticInfo.ClosePrice = 0
				end

				if staticInfo.FutureSellChargeCost =="-" then
					staticInfo.FutureSellChargeCost = 0
				end

			    staticInfo.ClosePrice = (staticInfo.ClosePrice * staticInfo.CloseQtySum  + exec.Quantity * exec.Price )/(staticInfo.CloseQtySum  + exec.Quantity)
				staticInfo.CloseQtySum = staticInfo.CloseQtySum + exec.Quantity

				local cost = 0
				if staticInfo.CloseFuturePrice then
					cost = (staticInfo.CloseFuturePrice - exec.Price) * exec.Quantity * _PosIssueContractSizeTable[issue]
				end
				staticInfo.FutureSellChargeCost = staticInfo.FutureSellChargeCost  + cost
				staticInfo.EndTime = getDateTime()

				staticInfo.FutureTradeFee = staticInfo.FutureTradeFee + exec.Fare
				staticInfo.FutureCumulationPL = staticInfo.FutureCumulationPL + exec.RealizedPL

			end
		end
		staticInfo.SaveFlag = 1
	end
end

function OnOrder(position, order)
end

function OnPrice(issueCode, priceInfo)
end

--------------
--查询数据库--
--------------
_OnCommonData(dataName = "InventoryHeader", DTSInventoryHeader inventoryHeader)				--查询组合表
	_WriteAplLog("InventoryHeaderTable")
	local inventoryModelID = inventoryHeader.getInventoryModelID();
	local inventoryname = inventoryHeader.getModelDescription();
	local baseIndexCode = inventoryHeader.getBaseIndexCode();
	local UserID = inventoryHeader.getOwner();
	local ReserveString = inventoryHeader.getReserveString();
	if baseIndexCode == "1" or baseIndexCode == "M000300" then
		if gUserID == UserID or ReserveString == "1" then
			gtInventoryList[inventoryModelID] = gtInventoryList[inventoryModelID] or {}
			if inventoryname and inventoryname ~= "" then
				gtInventoryName[inventoryModelID] = inventoryname
			else
				gtInventoryName[inventoryModelID] = inventoryModelID
			end
		end
	end
_End
_OnCommonData(dataName = "InventoryOrder", DTSInventoryOrder inventoryOrder)		--查询组合明细表
	--_WriteErrorLog("InventoryOrderTable")
	local inventoryModelID = inventoryOrder.getInventoryModelID();
	local issueCode = inventoryOrder.getIssueCode();
	local qty = inventoryOrder.getQuantity();
	if gtInventoryList[inventoryModelID] and _PosIssueMarketTable[issueCode] then
		gtInventoryList[inventoryModelID][issueCode] = gtInventoryList[inventoryModelID][issueCode] or {}
		if qty then
			qty = qty.getNumberValue()
		else
			qty = 0
		end
		gtInventoryList[inventoryModelID][issueCode].Quantity = qty
		local issueMarket = _PosIssueMarketTable[issueCode]
		_RegisterPrice(_IssueCode=issueCode,_MarketCode=issueMarket)
	end
_End
_OnCommonData(dataName = "IssueMasterIF", DTSIssueMaster issueMaster)		--取得可交易的股指期货合约
	--_WriteErrorLog("IssueMasterIF")
	local issueCode = issueMaster.getIssueCode();
	if gFutureNo == 0 then
		gFutureCurrent = issueCode;	--当月
		gFutureList[issueCode] = 1
	elseif gFutureNo == 1 then
		gFutureNextMonth = issueCode;	--次月
		gFutureList[issueCode] = 1
	elseif gFutureNo == 2 then
		gFutureSeasonMonth = issueCode;	--季月
		gFutureList[issueCode] = 1
	elseif gFutureNo == 3 then
		gFutureNextSeason = issueCode;	--隔季
		gFutureList[issueCode] = 1
	else
		--_WriteErrorLog("Future record error!");
	end
	gFutureNo = gFutureNo + 1;
	local issueMarket = _PosIssueMarketTable[issueCode]
	_RegisterPrice(_IssueCode=issueCode,_MarketCode=issueMarket)	--注册行情
_End
----------------
--事件回调定义--
----------------
_OnDynamicData(_dataName="CombinDataList", SaveCombinDataEvent evt)		--读取历史组合
	local Stock = evt._GetFld("Stock");
	local portID = evt._GetFld("PortID");
	local CombinName = evt._GetFld("CombinName");
	local log = sys_format("CombinDataList:CombinName[%s],PortID[%s],Stock[%s]",CombinName,portID,Stock)
	_WriteErrorLog(log)
	if gtInventoryList[Stock] then
		local StockNum = evt._GetFld("StockNum");
		local StockBuy = evt._GetFld("StockBuy");
		local StockSell = evt._GetFld("StockSell");
		local Future = evt._GetFld("Future");
		local FutureNum = evt._GetFld("FutureNum");
		local FutureBuy = evt._GetFld("FutureBuy");
		local FutureSell = evt._GetFld("FutureSell");
		local OpenNum = evt._GetFld("OpenNum");
		local CloseNum = evt._GetFld("CloseNum");
		local StockStatus = evt._GetFld("StockStatus");
		local FutureStatus = evt._GetFld("FutureStatus");
		local log = sys_format("Stock[%s],StockNum[%s],StockBuy[%s],StockSell[%s],Future[%s],FutureNum[%s],FutureBuy[%s],FutureSell[%s],StockStatus[%s],FutureStatus[%s]",Stock,StockNum,StockBuy,StockSell,Future,FutureNum,FutureBuy,FutureSell,StockStatus,FutureStatus)
		_WriteErrorLog(log)

		gtCombinList[portID] = {}
		gtCombinList[portID].List = {}
		gtCombinList[portID].CombinName = CombinName
		gtCombinList[portID].Stock = Stock
		gtCombinList[portID].StockNum = StockNum.getNumberValue()
		gtCombinList[portID].StockBuy = StockBuy
		gtCombinList[portID].StockSell = StockSell
		gtCombinList[portID].Future = Future
		gtCombinList[portID].FutureNum = FutureNum.getNumberValue()
		gtCombinList[portID].FutureBuy = FutureBuy
		gtCombinList[portID].FutureSell =FutureSell
		gtCombinList[portID].OpenNum = OpenNum
		gtCombinList[portID].CloseNum = CloseNum
		gtCombinList[portID].StockStatus = StockStatus
		gtCombinList[portID].FutureStatus = FutureStatus

		gtCombinList[portID].FutureBuyTick = "不浮动"							--期货tick
		gtCombinList[portID].FutureSellTick = "不浮动"							--期货tick
		gtCombinList[portID].InventoryNum = 0								--品种数量
		gtCombinList[portID].SP = 0											--停牌数量
		gtCombinList[portID].DL = 0											--涨停数量
		gtCombinList[portID].SL = 0											--跌停数量
		gtCombinList[portID].NotSellQty = 0									--盘口不足
		gtCombinList[portID].NotBuyQty = 0									--盘口不足

		for issue,value in pairs(gtInventoryList[Stock]) do
			gtCombinList[portID].InventoryNum = gtCombinList[portID].InventoryNum + 1
			gtCombinList[portID].List[issue] = {}
			gtCombinList[portID].List[issue].Quantity = value.Quantity
			gtCombinList[portID].List[issue].Status = "正常"
			gtCombinList[portID].List[issue].Inventory = 0		--使用库存量
			gtCombinList[portID].List[issue].SaveQty = 0		--留存量
			gtCombinList[portID].List[issue].OrderBuyPrice = 0		--委托买入价格
			gtCombinList[portID].List[issue].OrderSellPrice = 0		--委托卖出价格
			local OrderBuyQty = value.Quantity * StockNum.getNumberValue()
			OrderBuyQty = (sys_ceil(OrderBuyQty/100)*100)					--向上取100整 委托买入数量
			gtCombinList[portID].List[issue].OrderBuyQty = OrderBuyQty	--委托买入数量
			local OrderSellQty = value.Quantity * StockNum.getNumberValue()
			OrderSellQty = (sys_ceil(OrderSellQty/100)*100)		--向上取100整
			gtCombinList[portID].List[issue].OrderSellQty = OrderSellQty	--委托卖出数量
			gtCombinList[portID].List[issue].NotSellQty = "正常"	--卖盘盘口匹配
			gtCombinList[portID].List[issue].NotBuyQty = "正常"		--买盘盘口匹配
			gtCombinList[portID].List[issue].StockBuyTick = "不浮动" 	--现货tick
			gtCombinList[portID].List[issue].StockSellTick = "不浮动"	--现货tick
			gtCombinList[portID].List[issue].StockBuy = StockBuy	--现货买入取价方式
			gtCombinList[portID].List[issue].StockSell = StockSell	--现货卖出取价方式
			gtCombinList[portID].List[issue].ExecQuantity = 0 		--成交数量
			gtCombinList[portID].List[issue].ExecPrice = 0 			--成交均价
			gtCombinList[portID].List[issue].UserPos = "0" 			--使用库存
			gtCombinList[portID].List[issue].NotSell = "0" 			--不买入
			gtCombinList[portID].List[issue].SavePos = "0" 			--留存
			gtCombinList[portID].List[issue].NotBuy = "0" 			--不卖出
		end
	else
		local log = sys_format("读取历史套利组合失败:没有找到组合[%s]",Stock)
		sendLog(log,portID)
	end
_End
--读取保存的统计信息
_OnDynamicData(_dataName="SaveArbitrageInfoData", SaveArbitrageInfo evt)
    local portID = evt._GetFld("PortID")
	local buyAmount = evt._GetFld("BuyAmount") --现货买入金额
	local spotBuyChargeCost = evt._GetFld("SpotBuyChargeCost")--现货买入冲击成本
	local sellAmount = evt._GetFld("SellAmount")--现货卖出金额
	local spotSellChargeCost = evt._GetFld("SpotSellChargeCost")--现货卖出冲击成本
	local spotTradeFee = evt._GetFld("SpotTradeFee")--现货交易费用
	local spotGainLoss = evt._GetFld("SpotGainLoss")--现货盈亏
	local openPrice = evt._GetFld("OpenPrice")--建仓均价
	local futureBuyChargeCost = evt._GetFld("FutureBuyChargeCost")--冲击成本
	local closePrice = evt._GetFld("ClosePrice")--平仓均价
	local futureSellChargeCost = evt._GetFld("FutureSellChargeCost")--冲击成本
	local futureTradeFee = evt._GetFld("FutureTradeFee")--交易费用
	local futureGainLoss = evt._GetFld("FutureGainLoss")--期货盈亏

	local open300Price = evt._GetFld("OpenHS300Price")
	local openIFPrice = evt._GetFld("OpenFuturePrice")
	local close300Price = evt._GetFld("CloseHS300Price")
	local cloeIFPrice = evt._GetFld("CloseFuturePrice")
	local closeQty = evt._GetFld("CloseQtySum")
	local openQty = evt._GetFld("OpenQtySum")
	local startTime = evt._GetFld("StartTime")
	local endTime = evt._GetFld("EndTime")

	local staticInfo = CreateArbitrageInfo(portID, true)
	if staticInfo then
		staticInfo.PortID = portID
		staticInfo.BuyAmount = buyAmount  --现货买入金额
		staticInfo.SpotBuyChargeCost = spotBuyChargeCost--现货买入冲击成本
		staticInfo.SellAmount = sellAmount--现货卖出金额
		staticInfo.SpotSellChargeCost = spotSellChargeCost--现货卖出冲击成本
		staticInfo.SpotTradeFee = spotTradeFee--现货交易费用
		staticInfo.SpotCumulationPL = spotGainLoss--现货盈亏

		staticInfo.OpenPrice = openPrice--建仓均价
		staticInfo.FutureBuyChargeCost = futureBuyChargeCost--冲击成本
		staticInfo.ClosePrice = closePrice--平仓均价
		staticInfo.FutureSellChargeCost = futureSellChargeCost--冲击成本
		staticInfo.FutureTradeFee = futureTradeFee--交易费用
		staticInfo.FutureCumulationPL = futureGainLoss--期货盈亏

		staticInfo.OpenHS300Price  =open300Price --建仓沪深300的最新价
		staticInfo.OpenFuturePrice =openIFPrice --建仓期指的最新价
		staticInfo.CloseHS300Price  =close300Price --平仓沪深300的最新价
		staticInfo.CloseFuturePrice =cloeIFPrice  --平仓期指的最新价

		staticInfo.CloseQtySum =closeQty
		staticInfo.OpenQtySum =openQty
		staticInfo.StartTime =startTime
		staticInfo.EndTime =endTime
		local log = sys_format("Read,portID:%s, futureTradeFee:%s, startTime:%s,open300Price:%s,openIFPrice:%s,close300Price:%s,cloeIFPrice:%s,closeQty:%s, openQty:%s",
		  portID, staticInfo.FutureTradeFee,startTime,open300Price,openIFPrice,close300Price,cloeIFPrice,closeQty, openQty)
		_WriteAplLog(log)

		staticInfo.SaveFlag = 0
	else
	    local log = sys_format("套利组合统计显示失败:没有找到组合[%s]",portID)
		sendLog(log,portID)
	end
_End



_OnEventDefined(VCreateCombin combin)							--创建组合回调
	if _InitializeFlag == 1 then
		_WriteAplLog("CreateCombin")
		local combinName = combin._GetFld("CombinName");
		local stock = combin._GetFld("StockCode");
		local stockNum = combin._GetFld("StockNum");
		local stockBuy = combin._GetFld("StockBuy");
		local stockSell = combin._GetFld("StockSell");
		local future = combin._GetFld("FutureCode");
		local futureNum = combin._GetFld("FutureNum");
		local futureBuy = combin._GetFld("FutureBuy");
		local futureSell = combin._GetFld("FutureSell");
		CreateCombin(combinName,stock,stockNum,stockBuy,stockSell,future,futureNum,futureBuy,futureSell)
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VModifyCombin combin)								--修改组合回调
	if _InitializeFlag == 1 then
		_WriteAplLog("ModifyCombin")
		local portID = combin._GetFld("PortID");
		local combinName = combin._GetFld("CombinName");
		local number = combin._GetFld("Number");
		local stock = combin._GetFld("StockCode");
		local stockNum = combin._GetFld("StockNum");
		local stockBuy = combin._GetFld("StockBuy");
		local stockSell = combin._GetFld("StockSell");
		local future = combin._GetFld("FutureCode");
		local futureNum = combin._GetFld("FutureNum");
		local futureBuy = combin._GetFld("FutureBuy");
		local futureSell = combin._GetFld("FutureSell");

		if gtCombinList[portID] then
			_WriteErrorLog(stock)
			for i,k in pairs(gtInventoryName)do
				if stock == k then
					stock = i
				end
			end
			_WriteErrorLog(stock)
			gtCombinList[portID].CombinName = combinName
			gtCombinList[portID].StockNum = stockNum.getNumberValue()
			gtCombinList[portID].StockBuy = stockBuy
			gtCombinList[portID].StockSell = stockSell
			gtCombinList[portID].FutureNum = futureNum.getNumberValue()
			gtCombinList[portID].FutureBuy = futureBuy
			gtCombinList[portID].FutureSell = futureSell
			local loog = sys_format("修改组合[%s]",stock)
			_WriteAplLog(loog)
			for issue,info in pairs(gtCombinList[portID].List) do
				gtCombinList[portID].List[issue].StockBuy = stockBuy
				gtCombinList[portID].List[issue].StockSell = stockSell
			end

		else
			_WriteAplLog("无法修改套利组合")
		end
		SaveCombinData(portID,gtCombinList[portID])						--保存动态套利组合数据
		gPortID = portID
		ClearTable()
		Refresh(gPortID)
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VDelCombin combin)									--删除组合回调
	if _InitializeFlag == 1 then
		local portID = combin._GetFld("PortID");

		if gtCombinList[portID] then
			gtCombinList[portID] = nil
			gtAutoOrder[portID] = nil
			SaveCombinDataEvent._SetFld("PortID", portID);
			CombinDynamicData._Clear()											--清楚之前保存的数据
			SaveArbitrageInfoEvent._SetFld("PortID",portID)
			gtSaveArbitrageInfo._Clear()
			if gtArbitrageInfoTable[portID] then
				gtArbitrageInfoTable[portID] = nil
			end
			_WriteErrorLog("ClearData:CombinDataList")
			_WriteErrorLog(portID)
			local DTSEvent inventory = _CreateEventObject("VInventoryListTable")
			inventory._SetFld("PortID","Clear")										--套利组合号
			_SendToClients(inventory)
			ClearTable()
			for i,k in pairs(gtCombinList) do
				InventoryListTable(i)
			end
		else
			--_WriteErrorLog("无法删除套利组合")
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VRefreshCombin combin)								--重新读取组合信息
	if _InitializeFlag == 1 then
		ReadStock()
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VRefreshCombinInfo combin)								--刷新组合信息
	if _InitializeFlag == 1 then
		RefreshArbitragePosition()
		for portID,info in pairs(gtCombinList) do
			calculateInventory(portID)	--定时计算套利组合内相关数据（基差重要数据行情实时计算）
			if gtArbitrageInfoTable[portID] then
			CalculateStaticInfo(gtArbitrageInfoTable[portID])
			end
			InventoryListTable(portID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VRefreshList list)										--重新读取组合清单
	if _InitializeFlag == 1 then
		local portID = list._GetFld("PortID");
		if gtCombinList[portID] then
			if gRefreshListFlag == "0" then
				gRefreshListFlag = "1"
				ClearTable()
				ReadStock()
				RefreshList(portID)
				gRefreshListFlag = "0"
			else
				sendLog("刷新清单太快！",portID)
			end
		else
			_WriteAplLog("未找到套利组合")
			sendLog("未找到套利组合",portID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VSetBAMapID stockID)									--确认账号选择回调
	if _InitializeFlag == 1 then
		local marginInvestorID = stockID._GetFld("MarginInvestorID");
		local futureInvestorID = stockID._GetFld("FutureInvestorID");
		local flag = stockID._GetFld("Flag");
		local log = sys_format("SetBAMapID:marginInvestorID[%s],futureInvestorID[%s],flag[%s]",marginInvestorID,futureInvestorID,flag)
		_WriteErrorLog(log)
		if flag == "确认账号" then
			if marginInvestorID and futureInvestorID and marginInvestorID ~= "" and futureInvestorID ~= "" then
				gMarginbaMapID = gtInvestorIDMap[marginInvestorID]
				gFuturebaMapID = gtInvestorIDMap[futureInvestorID]
				local log = sys_format("SetBAMapID:MardinbaMapID[%s],FuturebaMapID[%s]",gMarginbaMapID,gFuturebaMapID)
				_WriteErrorLog(log)
				ClearTable()
				gPortID = ""
				--刷新持仓
				RefreshArbitragePosition();

				if _PosBAMapAccount[gMarginbaMapID] and _PosBAMapAccount[gFuturebaMapID] then
					local marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
					local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
					gtPositionTable = {}
					gtQryMarginPosition = {}
					if marginAccountCode then
						local marginInvestorID = _PosFundStatus[marginAccountCode].InvestorID
						local clientID = _PosFundStatus[marginAccountCode].ClientID
						--刷新资金柜台
						L2cQueryMarketFund(marginInvestorID, clientID, gMarginbaMapID)
						--刷新持仓柜台
						L2cQueryMarketPosition(marginInvestorID,clientID,gMarginbaMapID,"")
					end
					if futureAccountCode then
						local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
						local clientID = _PosFundStatus[futureAccountCode].ClientID
						--刷新资金柜台
						L2cQueryMarketFund(futureInvestorID, clientID, gFuturebaMapID)
						--刷新持仓柜台
						L2cQueryMarketPosition(futureInvestorID,clientID,gFuturebaMapID,"")
					end
				end
			else
				sendLog("资金账户设置错误","")
				local log = sys_format("marginInvestorID[%s],futureInvestorID[%s]",marginInvestorID,futureInvestorID)
				_WriteErrorLog(log)
			end
		elseif flag == "更换账号" then
			gMarginbaMapID = ""
			gFuturebaMapID = ""
			_WriteErrorLog("更换账号")
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VChooseCombin combin)								--套利组合选择回调
	if _InitializeFlag == 1 then
		_WriteErrorLog("ChooseCombin")
		local portID = combin._GetFld("PortID");
		_WriteErrorLog(portID)
		if gtCombinList[portID] then
			if gChooseCombinFlag == "0" then
				gChooseCombinFlag = "1"
				_WriteErrorLog("刷表")
				gPortID = portID
				ClearTable()
				Refresh(gPortID)
				gChooseCombinFlag = "0"
			else
				sendLog("刷新组合太快！",portID)
			end
		else
			_WriteAplLog("未找到套利组合")
			sendLog("未找到套利组合",portID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VCopyCombin combin)								--复制套利组合回调
	if _InitializeFlag == 1 then
		_WriteErrorLog("CopyCombin")
		local portID = combin._GetFld("PortID");
		_WriteErrorLog(portID)
		if gtCombinList[portID] then
			CopyCombin(portID)
		else
			_WriteAplLog("未找到套利组合")
			sendLog("未找到套利组合",portID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VSetIssueEvent setIssue)								--设置股票开仓库存量
	if _InitializeFlag == 1 then
		local portID = setIssue._GetFld("PortID");
		local issueCode = setIssue._GetFld("IssueCode");
		local stockPrice = setIssue._GetFld("StockPrice");
		local stockTick = setIssue._GetFld("StockTick");
		local userPos = setIssue._GetFld("UserPos");
		local notSell = setIssue._GetFld("NotSell");
		local qty = setIssue._GetFld("Qty");

		local log = sys_format("portID[%s],issueCode[%s],stockPrice[%s],stockTick[%s],userPos[%s],notSell[%s],qty[%s]",portID,issueCode,stockPrice,stockTick,userPos,notSell,qty)
		_WriteErrorLog(log)

		local combinList = gtCombinList[portID]
		if not combinList then
			log = sys_format("设置未成功:没有组合表[%s]",portID)
			_WriteErrorLog(log)
			sendLog(log,portID)
		else
			if not combinList.List[issueCode] then
				log = sys_format("设置未成功:组合下没有找到该合约[%s]",issueCode)
				_WriteErrorLog(log)
				sendLog(log,portID)
			else
				qty = qty.getNumberValue()
				gtCombinList[portID].List[issueCode].Inventory = qty
				gtCombinList[portID].List[issueCode].StockSellTick = stockTick
				gtCombinList[portID].List[issueCode].StockSell = stockPrice
				gtCombinList[portID].List[issueCode].UserPos = userPos
				gtCombinList[portID].List[issueCode].NotSell = notSell

				StockOpenPosTable(portID,issueCode)			--刷新开仓表
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VSetIssueCloseEvent setIssue)						--设置股票平仓留存量
	if _InitializeFlag == 1 then
		local portID = setIssue._GetFld("PortID");
		local issueCode = setIssue._GetFld("IssueCode");
		local stockPrice = setIssue._GetFld("StockPrice");
		local stockTick = setIssue._GetFld("StockTick");
		local savePos = setIssue._GetFld("SavePos");
		local notBuy = setIssue._GetFld("NotBuy");
		local qty = setIssue._GetFld("Qty");

		local log = sys_format("portID[%s],issueCode[%s],stockPrice[%s],stockTick[%s],savePos[%s],notBuy[%s],qty[%s]",portID,issueCode,stockPrice,stockTick,savePos,notBuy,qty)
		_WriteErrorLog(log)

		local combinList = gtCombinList[portID]
		if not combinList then
			log = sys_format("设置未成功:没有组合表[%s]",portID)
			_WriteErrorLog(log)
			sendLog(log,portID)
		else
			if not combinList.List[issueCode] then
				log = sys_format("设置未成功:组合下没有找到该合约[%s]",issueCode)
				_WriteErrorLog(log)
				sendLog(log,portID)
			else
				qty = qty.getNumberValue()
				gtCombinList[portID].List[issueCode].SaveQty = qty
				gtCombinList[portID].List[issueCode].StockBuyTick = stockTick
				gtCombinList[portID].List[issueCode].StockBuy = stockPrice
				gtCombinList[portID].List[issueCode].SavePos = savePos
				gtCombinList[portID].List[issueCode].NotBuy = notBuy

				StockClosePosTable(portID,issueCode)							--刷新平仓表
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VrefreshFund refreshFundEvent)					--刷新资金界面
	if _InitializeFlag == 1 then
		_WriteErrorLog("refreshFund")
		if _PosBAMapAccount[gMarginbaMapID] and _PosBAMapAccount[gFuturebaMapID] then
			local marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
			local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
			gtQryMarginPosition = {}
			gtPositionTable = {}
			if marginAccountCode then
				local marginInvestorID = _PosFundStatus[marginAccountCode].InvestorID
				local clientID = _PosFundStatus[marginAccountCode].ClientID
				--刷新资金柜台
				L2cQueryMarketFund(marginInvestorID, clientID, gMarginbaMapID)
				--刷新持仓柜台
				L2cQueryMarketPosition(marginInvestorID,clientID,gMarginbaMapID,"")
			end
			if futureAccountCode then
				local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
				local clientID = _PosFundStatus[futureAccountCode].ClientID
				--刷新资金柜台
				L2cQueryMarketFund(futureInvestorID, clientID, gFuturebaMapID)
				--刷新持仓柜台
				L2cQueryMarketPosition(futureInvestorID,clientID,gFuturebaMapID,"")
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VQueryCloseFund qfEvent)							--平仓查询资金状况回调
	if _InitializeFlag == 1 then
		local issueCode = qfEvent._GetFld("IssueCode")
		local BAMapID = qfEvent._GetFld("BAMapID")
		local CombinCode = qfEvent._GetFld("CombinCode")
		local market = _PosIssueMarketTable[issueCode]
		_DD = 0
		if market then
			_QueryIssue = issueCode
			_PosRegisterPrice(issueCode)
			if market=="1" or  market=="2"  then --股票
				BAMapID = gMarginbaMapID
				if CombinCode == "" then
					local condition = sys_sub(gMarginbaMapID,1,-4)
					BAMapID = condition .. "999"			--柜台持仓委托使用-999子账号
				end
			else      --期货
				BAMapID = gFuturebaMapID
				if CombinCode == "" then
					local condition = sys_sub(gFuturebaMapID,1,-4)
					BAMapID = condition .. "999"			--柜台持仓委托使用-999子账号
				end
			end
			local accountCode = _PosBAMapAccount[BAMapID]
			if _PosPriceTable[_QueryIssue] then
				sendFundReplyClose(BAMapID,accountCode,CombinCode)
			else
				_DD = 1
				_QueryTable["CombinCode"] = CombinCode
				_QueryTable["AccountCode"] = accountCode
				_QueryTable["BAMapID"] = BAMapID
			end
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VFireEvent fire,sessionID)						--单笔委托
	if _InitializeFlag == 1 then
		_WriteErrorLog("FireEvent...");

		local CombinCode = fire._GetFld("CombinCode");
		local BAMapID = fire._GetFld("BAMapID");
		local issueCode = fire._GetFld("IssueCode");
		local bs = fire._GetFld("BuySell");
		local oc = fire._GetFld("OpenClose");
		if gtCombinList[CombinCode] or CombinCode == "" then
			if gMarginbaMapID ~= "" and gFuturebaMapID ~= "" then
				local flag = 1
				local temp = sys_sub(issueCode,1,2);
				if not _PosPriceTable[issueCode] then
				   flag = 0
				end
				local market = _PosIssueMarketTable[issueCode]
				if market and flag==1 then
					if market=="1" or  market=="2"  then --股票
						BAMapID = gMarginbaMapID
						if CombinCode == "" then
							local condition = sys_sub(gMarginbaMapID,1,-4)
							BAMapID = condition .. "999"			--柜台持仓委托使用-999子账号
						end
					else     --期货
						BAMapID = gFuturebaMapID
						if CombinCode == "" then
							local condition = sys_sub(gFuturebaMapID,1,-4)
							BAMapID = condition .. "999"			--柜台持仓委托使用-999子账号
						end
					end
				else
					flag = 0
					sendLog("合约不存在或者没有行情",gPortID)
				end
				if flag ~= 0 then
					--非上期若选择了平今指令，自动发出为平仓
					oc = oc.getNumberValue()	--add
					if _PosIssueMarketTable[issueCode] ~= "4" and oc == 2 then
						oc = 1
					end

					local basubID
					local BuySell = ""
					if oc == 0 then
						basubID = bs..CombinCode
						if bs == "1" then
							BuySell = "卖开仓"
						else
							BuySell = "买开仓"
						end
					elseif oc == 1 or oc == 2 then
						if bs == "1" then
							basubID = "3"..CombinCode
							BuySell = "卖平仓"
						else
							basubID = "1"..CombinCode
							BuySell = "买平仓"
						end
					elseif oc == 4 and bs == "1" then
						basubID = "1"..CombinCode
						BuySell = "融券卖出开仓"
					elseif oc == 5 and bs == "3" then
						basubID = "1"..CombinCode
						BuySell = "买券还券平仓"
					end

					local Price = fire._GetFld("Price");
					local quantity = fire._GetFld("Quantity");
					local logs = sys_format("FireEvent:basubID:%s,BAMapID:%s, issue:%s,BuySell:%s,OpenClose:%s,quantity:%d",basubID,BAMapID,issueCode,bs,oc,quantity)
					_WriteErrorLog(logs)
					log = sys_format("BaMapID:[%s],下单合约:[%s],下单数量:[%s],价格:[%s],方向:[%s]",BAMapID,issueCode,quantity,Price,BuySell)
					sendLog(log,gPortID)
					if BAMapID ~= "" then
						local posCheck = true
						local poscheck = {}
						if CombinCode == "" then	-- -999子账户由于position不做检查，由策略自己检查
							local order = {}
							local temp = {}
							temp.IssueCode = issueCode
							temp.OpenClose = oc
							temp.BuySell = bs
							temp.BAMapID = BAMapID
							temp.BASubID = basubID
							temp.Quantity = quantity
							temp.Price = Price
							temp.CreRed = 0
							sys_insert(order,temp)
							poscheck = CheckOrder1(order)	--持仓检查
						end
						if poscheck.Result then
							posCheck = poscheck.Result
						end
						if posCheck then
							local ret = SubmitSingleOrder(BAMapID,basubID,issueCode,bs,oc, Price,quantity, 0, "",nil,gHedgeFlag);
							if ret.Result then
								local log = sys_format("下单完成")
								sendLog(log,gPortID)
							else
								local log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
								_WriteErrorLog(log)
								log = sys_format("下单失败,原因：[%s]",ret.Reason)
								sendLog(log,gPortID)
							end
						else
							log = sys_format("下单失败,原因：[%s]",poscheck.Reason)
							_WriteErrorLog(log)
							sendLog(log,gPortID)
						end
					end

				end
			else
				sendLog("单笔委托：请确认资金账号",gPortID)
			end
		else
			sendLog("单笔委托：设置组合号不存在",gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End;

_OnEventDefined(VAmendSingleOrder aoEvent,sessionID)				--改价
	if _InitializeFlag == 1 then
		local corpCode = aoEvent._GetFld("CorpCode")
		local IssueCode = aoEvent._GetFld("IssueCode")
		local BuySell = aoEvent._GetFld("BuySell")
		local OrderPrice = aoEvent._GetFld("OrderPrice")
		local log = sys_format("改价下单:CorpCode:%s,IssueCode:%s,BulSell:%s,OrderPrice:%s",corpCode,IssueCode,BuySell,OrderPrice)
		_WriteAplLog(log)
		if corpCode and IssueCode and BuySell then
			local ret = PosAmendOrder(corpCode, OrderPrice)
			if ret.Result then
			else
				local log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
				_WriteAplLog(log)
				log = sys_format("下单错误原因：[%s]",ret.Reason)
				sendLog(log,gPortID)
			end
		else
			sendLog("系统找不到改价单或价格",gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
_OnEventDefined(VCancelSingleOrder coEvent,sessionID)			--撤单
	if _InitializeFlag == 1 then
		local corpCode = coEvent._GetFld("CorpCode")
		local log = sys_format("撤单:交易号:%s",corpCode)
		_WriteAplLog(log)
		sendLog(log,gPortID)
		if corpCode then
			local ret = PosCancelOrder(corpCode)
			if ret.Result then
			else
				log = sys_format("ReasonCode:%s,Reason:%s,PositionCheckID:%s", ret.ReasonCode,ret.Reason,ret.PositionCheckID)
				_WriteAplLog(log)
				log = sys_format("下单错误原因：[%s]",ret.Reason)
				sendLog(log,gPortID)
			end
		else
			sendLog("系统找不到改价单",gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

_OnEventDefined(VCloseOrderQty CloseEvent,sessionID)			--可用全平
	if _InitializeFlag == 1 then
		_WriteAplLog("可用全平")
		local Button = CloseEvent._GetFld("Button")
		_WriteAplLog(Button)
		if gtCombinList[gPortID] and gtArbitragePositionTable[gPortID] then
			local tempList = {}
			local marginAccountCode = nil
			if _PosBAMapAccount[gMarginbaMapID] then
				marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
			else
				sendLog("资金账号不存在，请先确认资金账号",gPortID)
			end
			if marginAccountCode then
				if _PosFundStatus[marginAccountCode] then
					local marginInvestorID = _PosFundStatus[marginAccountCode].InvestorID
					for issue,info in pairs (gtCombinList[gPortID].List) do
						if Button == "1" then
							local sampleNum = info.Quantity			--样本数量
							local OrderBuyQty = sampleNum*gtCombinList[gPortID].StockNum--委托买入数量
							local savePos = info.SavePos				--使用留存量
							local saveQty = info.SaveQty				--留存数量
							local AvlQty = 0
							local key = marginInvestorID .. issue .. "1"
							if gtArbitragePositionTable[gPortID][key] then
								AvlQty = gtArbitragePositionTable[gPortID][key].AvlQty
							end
							saveQty = OrderBuyQty - AvlQty
							gtCombinList[gPortID].List[issue].SavePos = "1" 					--留存判断
							gtCombinList[gPortID].List[issue].NotBuy = "0" 					--不买入判断
							gtCombinList[gPortID].List[issue].SaveQty = saveQty 				--留存量
						else
							gtCombinList[gPortID].List[issue].SavePos = "0" 			--留存判断
							gtCombinList[gPortID].List[issue].SaveQty = 0 				--留存量
						end
						StockClosePosTable(gPortID,issue)								--刷新现货平仓表
					end
				end
			end
		else
			sendLog("当前套利组合或持仓不存在",gPortID)
		end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

_OnEventDefined(VSetRateInEvent evt)					--交易编码设置
	if _InitializeFlag == 1 then
		local HedgeFlag = evt._GetFld("HedgeFlag")
		if HedgeFlag == "投机" then
			gHedgeFlag = "0"
		elseif HedgeFlag == "套保" then
			gHedgeFlag = "1"
		elseif HedgeFlag == "套利" then
			gHedgeFlag = "2"
		else
			gHedgeFlag = "0"
		end
		local log = sys_format("设置期货账号交易编码为[%s]",HedgeFlag)
		sendLog(log,"")
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End
--获取交易费率,深证我们取000001(平安银行)的费率为基准，上海我们取600000(浦发银行)的费率为基准，
--中金所我们取当月合约的费率。
_OnEventDefined(VSetRateEvent evt)
	if _InitializeFlag == 1 then
		 local marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
		 local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	 if futureAccountCode and marginAccountCode then
		 local szFareTable = _PosGetFare(marginAccountCode, "000001")
		 local shFareTable = _PosGetFare(marginAccountCode, "600000")
		 local futureFareTable = _PosGetFare(futureAccountCode,gFutureCurrent)

		 local DTSEvent fareEvent = _CreateEventObject("VSetRateEventData")

		 local shBuyFare  = shFareTable.TraCommission or "-" --上海买入佣金费率
		if shBuyFare ~= "-" then
			shBuyFare = shBuyFare * 1000
			shBuyFare = sys_format("%.03f",shBuyFare)
		 end
		 local shSellFare = shFareTable.TraCommission or "-" --上海卖出佣金费率
		 if shSellFare ~= "-" then
			shSellFare = shSellFare * 1000
			shSellFare = sys_format("%.03f",shSellFare)
		 end
		 local shBuyStampTax = shFareTable.BuyStampTax or "-" --上海买入印花税率
		 if shBuyStampTax ~= "-" then
			shBuyStampTax = shBuyStampTax * 1000
			shBuyStampTax = sys_format("%.03f",shBuyStampTax)
		 end
		 local shSellStampTax = shFareTable.SellStampTax or "-" --上海卖出印花税率
		 if shSellStampTax ~= "-" then
			shSellStampTax = shSellStampTax * 1000
			shSellStampTax = sys_format("%.03f",shSellStampTax)
		 end
		 local shBuyTransferExpense = shFareTable.TransferExpense or "-"--上海买入过户税率
		 if shBuyTransferExpense ~= "-" then
			shBuyTransferExpense = shBuyTransferExpense * 1000
			shBuyTransferExpense = sys_format("%.03f",shBuyTransferExpense)
		 end
		 local shSellTransferExpense  = shFareTable.TransferExpense or "-" --上海买入佣金费率
		 if shSellTransferExpense ~= "-" then
			shSellTransferExpense = shSellTransferExpense * 1000
			shSellTransferExpense = sys_format("%.03f",shSellTransferExpense)
		 end

		 local szBuyFare  = szFareTable.TraCommission or "-" --深证买入佣金费率
		 if szBuyFare ~= "-" then
			szBuyFare = szBuyFare * 1000
			szBuyFare = sys_format("%.03f",szBuyFare)
		 end
		 local szSellFare = szFareTable.TraCommission or "-" --深证卖出佣金费率
		 if szSellFare ~= "-" then
			szSellFare = szSellFare * 1000
			szSellFare = sys_format("%.03f",szSellFare)
		 end
		 local szBuyStampTax = szFareTable.BuyStampTax or "-" --深证买入印花税率
		 if szBuyStampTax ~= "-" then
			szBuyStampTax = szBuyStampTax * 1000
			szBuyStampTax = sys_format("%.03f",szBuyStampTax)
		 end
		 local szSellStampTax = szFareTable.SellStampTax or "-" --深证卖出印花税率
		 if szSellStampTax ~= "-" then
			szSellStampTax = szSellStampTax * 1000
			szSellStampTax = sys_format("%.03f",szSellStampTax)
		 end

		 local buyRatio  = futureFareTable.OpenDropRatio or "-" --中金所买入佣金费率
		 if buyRatio ~= "-" then
			buyRatio = buyRatio * 1000
			buyRatio = sys_format("%.03f",buyRatio)
		 end
		 local sellRatio = futureFareTable.OpenDropRatio or "-" --中金所卖出佣金费率
		 if sellRatio ~= "-" then
			sellRatio = sellRatio * 1000
			sellRatio = sys_format("%.03f",sellRatio)
		 end
		 local buyTCloseRatio = futureFareTable.DropCuFareRatio or "-"--中金所买入平今仓
		 if buyTCloseRatio ~= "-" then
			buyTCloseRatio = buyTCloseRatio * 1000
			buyTCloseRatio = sys_format("%.03f",buyTCloseRatio)
		 end
		 local sellTCloseRatio  = futureFareTable.DropCuFareRatio or "-" --中金所卖出平今仓
		 if sellTCloseRatio ~= "-" then
			sellTCloseRatio = sellTCloseRatio * 1000
			sellTCloseRatio = sys_format("%.03f",sellTCloseRatio)
		 end
		 local buyHCloseRatio = futureFareTable.OpenDropRatio or "-" --中金所买入平历史仓
		 if buyHCloseRatio ~= "-" then
			buyHCloseRatio = buyHCloseRatio * 1000
			buyHCloseRatio = sys_format("%.03f",buyHCloseRatio)
		 end
		 local sellHCloseRatio = futureFareTable.OpenDropRatio or "-" --中金所买入平历史仓
		 if sellHCloseRatio ~= "-" then
			sellHCloseRatio = sellHCloseRatio * 1000
			sellHCloseRatio = sys_format("%.03f",sellHCloseRatio)
		 end
		 local balanceRatio = _PosGetBail(futureAccountCode, gFutureCurrent, "-", gHedgeFlag) or "-"--中金所保证金比例
		 if balanceRatio ~= "-" then
			balanceRatio = balanceRatio * 100
			balanceRatio = sys_format("%d",balanceRatio)
		 end
		 local fundYearRate  =  60.000 --中金所资金年利率
		 if fundYearRate ~= "-" then
			fundYearRate = sys_format("%.03f",fundYearRate)
		 end
		 local HedgeFlag = ""--"0\":投机,\"1\":套保,\"2\":套利
		if gHedgeFlag == "0" then
			HedgeFlag = "投机"
		elseif gHedgeFlag == "1" then
			HedgeFlag = "套保"
		elseif gHedgeFlag == "2" then
			HedgeFlag = "套利"
		end
		 fareEvent._SetFld("SHBuyFare",shBuyFare)
		 fareEvent._SetFld("SHSellFare",shSellFare)
		 fareEvent._SetFld("SHBuyStampTax",shBuyStampTax)
		 fareEvent._SetFld("SHSellStampTax",shSellStampTax)
		 fareEvent._SetFld("SHBuyTransferExpense",shBuyTransferExpense)
		 fareEvent._SetFld("SHSellTransferExpense",shSellTransferExpense)
		 fareEvent._SetFld("SZBuyFare",szBuyFare)
		 fareEvent._SetFld("SZSellFare",szSellFare)
		 fareEvent._SetFld("SZBuyStampTax",szBuyStampTax)
		 fareEvent._SetFld("SZSellStampTax",szSellStampTax)
		 fareEvent._SetFld("BuyRatio",buyRatio)
		 fareEvent._SetFld("SellRatio",sellRatio)
		 fareEvent._SetFld("BuyTCloseRatio",buyTCloseRatio)
		 fareEvent._SetFld("SellTCloseRatio",sellTCloseRatio)
		 fareEvent._SetFld("BuyHCloseRatio",buyHCloseRatio)
		 fareEvent._SetFld("SellHCloseRatio",sellHCloseRatio)
		 fareEvent._SetFld("BalanceRatio",balanceRatio)
		 fareEvent._SetFld("FundYearRate",fundYearRate)
		fareEvent._SetFld("HedgeFlag",HedgeFlag)
		 _SendToClients(fareEvent)
		 	else
	     sendLog("资金账号不存在，请先确认资金账号,再查询费率","")
	end
	else
		sendLog("初始化还没有完成",gPortID)
	end
_End

--------------
--自定义函数--
--------------
function SaveCombinData(portID,table)							--动态保存组合信息
	local DTSEvent saveCombin = _CreateEventObject("VSaveCombinDataEvent");
	SaveCombinDataEvent._SetFld("PortID", portID);
	CombinDynamicData._Clear()											--清楚之前保存的数据
	_WriteErrorLog("ClearData:CombinDataList")

	local CombinName = table.CombinName
	local Stock = table.Stock
	local StockNum = table.StockNum
	local StockBuy = table.StockBuy
	local StockSell = table.StockSell
	local Future = table.Future
	local FutureNum = table.FutureNum
	local FutureBuy = table.FutureBuy
	local FutureSell = table.FutureSell

	local OpenNum = table.OpenNum
	local CloseNum = table.CloseNum
	local StockStatus = table.StockStatus
	local FutureStatus = table.FutureStatus

	saveCombin._SetFld("PortID", portID);
	saveCombin._SetFld("CombinName", CombinName);
	saveCombin._SetFld("Stock", Stock);
	saveCombin._SetFld("StockNum", StockNum);
	saveCombin._SetFld("StockBuy", StockBuy);
	saveCombin._SetFld("StockSell", StockSell);
	saveCombin._SetFld("Future", Future);
	saveCombin._SetFld("FutureNum", FutureNum);
	saveCombin._SetFld("FutureBuy", FutureBuy);
	saveCombin._SetFld("FutureSell", FutureSell);

	saveCombin._SetFld("OpenNum", OpenNum);
	saveCombin._SetFld("CloseNum", CloseNum);
	saveCombin._SetFld("StockStatus", StockStatus);
	saveCombin._SetFld("FutureStatus", FutureStatus);

	CombinDynamicData._SaveData("CombinDataList",saveCombin)
	_WriteErrorLog("SaveData:CombinDataList")
end
function SubmitSingleOrder(baMapID, baSubID, issueCode,buySell, openClose, price, quantity, creRed, ownerID,batchID,hedgeFlag)--自定义下单函数
	return PosSubmitSingleOrder(baMapID, baSubID, issueCode, buySell, openClose, price, quantity, creRed, ownerID, batchID, hedgeFlag)
end
function sendFundReplyClose(BAMapID,AccountCode,CombinCode)		--单笔委托中资金关联信息显示
	_WriteErrorLog("sendFundReply")

	local marketCode = _PosIssueMarketTable[_QueryIssue]
	if marketCode then
		local bailRatio = _PosGetBail(AccountCode, _QueryIssue)				--这里返回的是投机或者套保保证金率
		local AvailableFund = _PosFundStatus[AccountCode]["AvlFund"]		--可用资金
		local AvailableOpenQty = 0 														--可开仓数
		local AvailableBuyCloseQuantity = 0											--可平仓数/买
		local AvailableSellCloseQuantity = 0											--可平仓数/卖

		if _PosPriceTable[_QueryIssue] then
			local lastPrice = _PosPriceTable[_QueryIssue].LastPrice
			if lastPrice ~= 0 and lastPrice then
				lastPrice = lastPrice.getNumberValue()
				local contractSize = _PosIssueContractSizeTable[_QueryIssue]
				local availableOpenQuantity = AvailableFund / lastPrice / contractSize / bailRatio
				AvailableOpenQty = sys_floor(availableOpenQuantity)
				local log = sys_format("sendFundReply--IssueCode:%s,availableOpenQuantity:%s AvailableOpenQty:%s,AvlibFund:%s, contractSize:%s, lastPrice:%s, bailRatio:%s",
											_QueryIssue,availableOpenQuantity,AvailableOpenQty, AvailableFund, contractSize, lastPrice, bailRatio)
				--_WriteErrorLog(log)
			end
		else
			_RegisterPrice(_IssueCode = _QueryIssue, _MarketCode = marketCode)
		end

		AvailableFund = sys_format("%.2f",_PosFundStatus[AccountCode]["AvlFund"])
		local qrylog = sys_format("sendFundReply--BAMapID:%s, AccountCode:%s, CombinCode:%s",
											BAMapID, AccountCode, CombinCode)
		--_WriteErrorLog(qrylog)
		--取得多头可用数量
		local posKey = BAMapID .. ".3" ..CombinCode.. "." .. _QueryIssue
		if _PosPositionTable[posKey] then
			AvailableSellCloseQuantity = _PosPositionTable[posKey].AvlQuantity	--即可卖平数量
		end

		--取得空头可用数量
		posKey = BAMapID .. ".1" ..CombinCode.. "." .. _QueryIssue
		if _PosPositionTable[posKey] then
			AvailableBuyCloseQuantity = _PosPositionTable[posKey].AvlQuantity	--即可买平数量
		end

		DTSEvent fundReply = _CreateEventObject("VFundReply")
		fundReply._SetFld("IssueCode", _QueryIssue)
		fundReply._SetFld("AvlibFund", AvailableFund)
		AvailableOpenQty = sys_format("%.0f",AvailableOpenQty)
		AvailableBuyCloseQuantity = sys_format("%.0f",AvailableBuyCloseQuantity)
		AvailableSellCloseQuantity = sys_format("%.0f",AvailableSellCloseQuantity)
		qrylog = sys_format("sendFundReply--BAMapID:%s,CombinCode:%s,IssueCode:%s, AvlibFund:%s, AvlibOpenatQty:%s, AvlibBuyCloseQty:%s, AvlibSellCloseQty:%s",
											BAMapID,CombinCode,_QueryIssue, AvailableFund, AvailableOpenQty, AvailableBuyCloseQuantity, AvailableSellCloseQuantity)
		_WriteErrorLog(qrylog)
		fundReply._SetFld("AvlibOpenatQty", AvailableOpenQty)
		fundReply._SetFld("AvlibBuyCloseQty", AvailableBuyCloseQuantity)
		fundReply._SetFld("AvlibSellCloseQty", AvailableSellCloseQuantity);
		_SendToClients(fundReply);
	end
end
function SendQueryFund()										--刷新柜台资金信息显示
	_WriteErrorLog("SendQueryFund")

	local avlCapital = 0
	local avlCreditAmount = 0
	local capitalBalance = 0
	local avlMarginAmount = 0

	local futureAvlFund = 0
	local futureOrderFund = 0
	local futureAssetValue = 0
	local futureMargin = 0
	local futureBalance = 0
	local marginAccountCode = nil
	local futureAccountCode = nil
	if _PosBAMapAccount[gMarginbaMapID] then
		marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
	end
	if _PosBAMapAccount[gFuturebaMapID] then
		futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	end

	if marginAccountCode then
		local marginInvestorID = _PosFundStatus[marginAccountCode].InvestorID
		if gtQryMarginFund[marginInvestorID] then
			avlCreditAmount	= gtQryMarginFund[marginInvestorID].avl_credit_amount
			avlMarginAmount	= gtQryMarginFund[marginInvestorID].avl_margin_amount
			capitalBalance = gtQryMarginFund[marginInvestorID].capital_balance
			avlCapital = gtQryMarginFund[marginInvestorID].avl_capital
		end
	end
	if futureAccountCode then
		local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
		if gQueryFund[futureInvestorID] then
			futureAvlFund = gQueryFund[futureInvestorID].AvlFund
			futureOrderFund = gQueryFund[futureInvestorID].OrderFund
			futureAssetValue = gQueryFund[futureInvestorID].AssetValue
			futureMargin = gQueryFund[futureInvestorID].Margin
			futureBalance = gQueryFund[futureInvestorID].Balance
		end
	end
	avlCreditAmount	= dataformat(avlCreditAmount)
	avlMarginAmount	= dataformat(avlMarginAmount)
	capitalBalance =  dataformat(capitalBalance)
	avlCapital = dataformat(avlCapital)

	futureAvlFund = dataformat(futureAvlFund)
	futureOrderFund = dataformat(futureOrderFund)
	futureAssetValue = dataformat(futureAssetValue)
	futureMargin = dataformat(futureMargin)
	futureBalance = dataformat(futureBalance)
	_WriteErrorLog(futureAvlFund)
	local DTSEvent sendFundOut = _CreateEventObject("VsendFundOut")

	sendFundOut._SetFld("avlCapital",avlCapital)
	sendFundOut._SetFld("capitalBalance",capitalBalance)
	sendFundOut._SetFld("avlMarginAmount",avlMarginAmount)
	sendFundOut._SetFld("avlCreditAmount",avlCreditAmount)

	sendFundOut._SetFld("futureAvlFund",futureAvlFund)
	sendFundOut._SetFld("futureOrderFund",futureOrderFund)
	sendFundOut._SetFld("futureAssetValue",futureAssetValue)
	sendFundOut._SetFld("futureMargin",futureMargin)
	sendFundOut._SetFld("futureBalance",futureBalance)

	_SendToClients(sendFundOut)
end
function SendQueryPos()											--刷新柜台持仓
	_WriteErrorLog("SendQueryPos")
	local marginAccountCode = nil
	if _PosBAMapAccount[gMarginbaMapID] then
		marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
	end
	local futureAccountCode = nil
	if _PosBAMapAccount[gFuturebaMapID] then
		futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	end
	local temp1 = {}
	local temp2 = {}
	if marginAccountCode then
		local marginInvestorID = _PosFundStatus[marginAccountCode].InvestorID
		if gtQryMarginPosition[marginInvestorID] then
			temp1 = gtQryMarginPosition[marginInvestorID]
		end
	end
	if futureAccountCode then
		local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
		if gtPositionTable[futureInvestorID] then
			temp2 = gtPositionTable[futureInvestorID]
		end
	end
	for contract_ID,info in pairs(temp1)do
		sendQuerysinglePos(info,"margin")
	end
	for key,info in pairs(temp2)do
		sendQuerysinglePos(info,"future")
	end
	_WriteErrorLog("SendQueryPos end")
end
function sendQuerysinglePos(poslist,EventID)	--刷新柜台持仓单笔显示
	local InvestorID = poslist.InvestorID or ""
	local IssueCode = poslist.IssueCode or ""
	local log = sys_format("sendQuerysinglePos investorID = %s,issueCode = %s",InvestorID,IssueCode)
	_WriteErrorLog(log)

	local MarketType = poslist.MarketType or ""
	if MarketType == "1" then
		MarketType = "上交所"
	elseif  MarketType == "2" then
		MarketType = "深交所"
	elseif MarketType == "3" then
		MarketType = "中金所"
	elseif MarketType == "4" then
	MarketType = "上期所"
	elseif MarketType == "5" then
		MarketType = "郑期所"
	elseif MarketType == "6" then
		MarketType = "大期所"
	end

	if EventID == "future" then
		local BuySell = poslist.BuySell or ""
		local IssueName = poslist.IssueName or ""

		local Quantity = poslist.Quantity or 0
		local ReportQty = poslist.ReportQty or 0
		local RedeemQty = poslist.RedeemQty or 0
		local AvQty = poslist.AvQty or 0
		local AvSellQty = poslist.AvSellQty or 0
		local AvePrice = poslist.AvePrice	or 0
		local Margin = poslist.Margin	or 0
		local PL = poslist.PL	or 0
		local CostValue = poslist.CostValue	or 0
		local hedgeType = poslist.hedgeType or "0"
		AvePrice = dataformat(AvePrice)
		Margin = dataformat(Margin)
		PL = dataformat(PL)
		CostValue = dataformat(CostValue)
		if BuySell == "3" then
			BuySell = "买"
		elseif BuySell == "1" then
			BuySell = "卖"
		end
		if not BuySell then
			BuySell = "-"
		end
		if hedgeType == "0" then
			hedgeType = "投机"
		elseif hedgeType == "1" then
			hedgeType = "套保"
		elseif hedgeType == "2" then
			hedgeType = "套利"
		end
		local DTSEvent sendPosOut = _CreateEventObject("VFutCombinPos")
		sendPosOut._SetFld("InvestorID",InvestorID)
		sendPosOut._SetFld("BuySell",BuySell)
		sendPosOut._SetFld("IssueName",IssueName)
		sendPosOut._SetFld("IssueCode",IssueCode)
		sendPosOut._SetFld("MarketType",MarketType)
		sendPosOut._SetFld("Quantity",Quantity)
		sendPosOut._SetFld("AvQty",AvQty)
		sendPosOut._SetFld("AvSellQty",AvSellQty)
		sendPosOut._SetFld("AvePrice",AvePrice)
		sendPosOut._SetFld("Margin",Margin)
		sendPosOut._SetFld("HedgeType",hedgeType)

		sendPosOut._SetFld("PL",PL)
		sendPosOut._SetFld("CostValue",CostValue)

		_SendToClients(sendPosOut)
	elseif EventID == "margin" then
		local DTSEvent sendPosOut = _CreateEventObject("VCombineInfoPos")
		local clientID = poslist.ClientID		--总账户
		local contractID = poslist.contract_id	--合约号
		local openDate = poslist.open_date		--合约开始日期
		local closeDate = poslist.close_date 	--合约结束日期
		local contractType = poslist.contract_type	--合约类型,"0":融资,"1":融券
		local orderQuantity = poslist.contract_qty or 0	--合约数量
		local orderAmount = poslist.contract_amount or 0	--合约金额
		local margin = poslist.margin or 0	--保证金
		local marginRatio = poslist.margin_ratio or 0	--保证金比例
		local closeQuantity = poslist.close_qty or 0		--已还数量
		local todayCloseQuantity = poslist.today_close_qty or 0	--实时已还数量
		local closeAmount = poslist.close_amount or 0	--已还金额
		local todayCloseAmount = poslist.today_close_amount or 0	--实时已还金额
		local contractFare = poslist.contract_fare or 0	--合约费用
		local contractInt = poslist.contract_int or 0	--合约利息
		local contractIntPaid = poslist.contact_int_paid or 0	--已还利息

		local paidQuantity = closeQuantity + todayCloseQuantity		--已还数量
		local paidAmount = closeAmount + todayCloseAmount			--已还金额
		local unPaidQuantity = orderQuantity - paidQuantity		--负债数量
		local unPaidAmount = orderAmount - paidAmount			--负债金额
		local costPrice = 0
		orderAmount = orderAmount.getNumberValue()
		if orderAmount ~= 0 then
			costPrice = orderQuantity/orderAmount
		end
		local pl = 0
		local lastPrice = 0
		if _PosPriceTable[IssueCode] then
			lastPrice = _PosPriceTable[IssueCode].LastPrice
		end
		if contractType == "0" then
			contractType = "融资"
			pl = (lastPrice - costPrice)*unPaidQuantity
		elseif contractType == "1" then
			contractType = "融券"
			pl = (costPrice - lastPrice)*unPaidQuantity
		end

		sendPosOut._SetFld("ContractID",contractID)
		sendPosOut._SetFld("InvestorID",InvestorID)
		sendPosOut._SetFld("IssueCode",IssueCode)
		local issueName = ""
		if _PosIssueNameTable[IssueCode] then
			issueName = _PosIssueNameTable[IssueCode]
		end
		sendPosOut._SetFld("IssueName",issueName)
		sendPosOut._SetFld("MarketCode",MarketType)

		sendPosOut._SetFld("ContractType",contractType)

		orderQuantity = sys_format("%.0f",orderQuantity)
		sendPosOut._SetFld("OpenQuantity",orderQuantity)

		unPaidQuantity = sys_format("%.0f",unPaidQuantity)
		sendPosOut._SetFld("UnPaidQuantity",unPaidQuantity)

		paidQuantity = sys_format("%.0f",paidQuantity)
		sendPosOut._SetFld("PaidQuantity",paidQuantity)

		orderAmount = sys_format("%.2f",orderAmount)
		sendPosOut._SetFld("OpenAmount",orderAmount)

		unPaidAmount = sys_format("%.2f",unPaidAmount)
		sendPosOut._SetFld("UnPaidAmount",unPaidAmount)

		paidAmount = sys_format("%.2f",paidAmount)
		sendPosOut._SetFld("PaidAmount",paidAmount)

		costPrice = sys_format("%.2f",costPrice)
		sendPosOut._SetFld("CostPrice",costPrice)

		pl = sys_format("%.2f",pl)
		sendPosOut._SetFld("PL",pl)

		sendPosOut._SetFld("ContractFare",contractFare)
		sendPosOut._SetFld("ContractInt",contractInt)
		sendPosOut._SetFld("ContractIntPaid",contractIntPaid)

		_SendToClients(sendPosOut)
	end


end
function dataformat(arg)										--格式调整
	if arg and arg ~= "" then
		arg = arg.getNumberValue()
		arg = sys_format("%.02f",arg)
	else
		arg = "0.00"
	end
	return arg
end
function InquireCombin()										--初始化组合，期货界面信息
	ReadStock()
	ReadFuture()
end

function ReadStock()											--读取数据库组合信息
	gtInventoryName = {}
	gtInventoryList = {}
	_GetCommonData(dataName = "InventoryHeader", condition = "", tablename = "InventoryHeader");

	_GetCommonData(dataName = "InventoryOrder", condition = "", tablename = "InventoryOrder");


	for inventoryID,v in pairs(gtInventoryList) do
		local inventoryName = gtInventoryName[inventoryID]
		local log = sys_format("发送组合到界面:InventoryID[%s],InventoryName[%s]",inventoryID,inventoryName)
		_WriteErrorLog(log)
		local DTSEvent CreateCombin = _CreateEventObject("VCreateCombinTableEvent")
		CreateCombin._SetFld("InventoryID",inventoryID)
		CreateCombin._SetFld("ModelDescription",inventoryName)
		_SendToClients(CreateCombin)
	end
end
function ReadFuture()											--读取数据库期货信息
	gFutureNo = 0
	local nowDate = GetYMD()
	local log = sys_format("nowDate[%s]",nowDate)
	--_WriteErrorLog(log)
	local sendifCondition = "ExpirationDate >= '" .. nowDate .. "' and UnderlyingAssetCode = 'IF' and ProductCode = '31' and IssueCode IN (select IssueCode from IssueMarketTable where MarketCode = '3' and ListedDate <= '"..nowDate.."') ORDER BY IssueCode";
	_GetCommonData(dataName = "IssueMasterIF", condition = sendifCondition, tablename = "IssueMaster");
	local DTSEvent CreateIF = _CreateEventObject("VCreateIFTableEvent")
	local IF1 = gFutureCurrent
	local IF2 = gFutureNextMonth
	local IF3 = gFutureSeasonMonth
	local IF4 = gFutureNextSeason
	CreateIF._SetFld("IF1",IF1)
	CreateIF._SetFld("IF2",IF2)
	CreateIF._SetFld("IF3",IF3)
	CreateIF._SetFld("IF4",IF4)
	_SendToClients(CreateIF)
end
function InventoryListTable(portID)								--套利组合表刷新
	local combinList = gtCombinList[portID]
	if not combinList then
		return "未找到套利组合"
	end
	local inventoryModelID = combinList.Stock
	local spotVarieties = combinList.InventoryNum
	local stockStatus = combinList.StockStatus
	local futureStatus = combinList.FutureStatus
	local combinName = combinList.CombinName
	local stock = combinList.Stock
	local stockNum = combinList.StockNum
	local stockBuy = combinList.StockBuy
	local stockSell = combinList.StockSell
	local future = combinList.Future
	local futureNum = combinList.FutureNum
	local futureBuy = combinList.FutureBuy
	local futureSell = combinList.FutureSell

	--local log1 = sys_format("stock[%s],stockNum[%s],stockBuy[%s],stockSell[%s],future[%s],futureNum[%s],futureBuy[%s],futureSell[%s],",stock,stockNum,stockBuy,stockSell,future,futureNum,futureBuy,futureSell)
	--_WriteAplLog(log1)



	local spotSpotMarket = combinList.spotSpotMarket or 0				--现货委托市值
	local spotValuePosition = combinList.spotValuePosition or 0			--现货持仓市值
	local futureSpotMarket = combinList.futureSpotMarket or 0			--期货委托市值
	local futureValuePosition =combinList.futureValuePosition or 0		--期货持仓市值

	local openPosition = combinList.openPosition or 0					--持仓敞口
	local open = combinList.open or 0									--敞口


	local basicEarnings = combinList.basicEarnings or "-"
	local estimatedEarnings = combinList.estimatedEarnings or "-"
	local alphaReturns = combinList.alphaReturns or "-"
	local openReturn = combinList.openReturn or "-"
	local chargeCost = combinList.chargeCost or "-"
	local estimatedCost = combinList.estimatedCost or "-"

	local OpenlongPrice = GetOrderPrice("M000300",0,0,"最新价","不浮动")
	local OpenshortPrice = GetOrderPrice(future,0,0,"最新价","不浮动")
	local CloselongPrice = OpenlongPrice
	local CloseshortPrice = OpenshortPrice

	local staticInfo = gtArbitrageInfoTable[portID]
	if staticInfo then
		basicEarnings = staticInfo.BasisRevenue
		estimatedEarnings = staticInfo.EstimatedRevenue
		alphaReturns = staticInfo.AlphaRevenue
		openReturn = staticInfo.ExposureRevenue
		chargeCost = staticInfo.ImpactCosts
		estimatedCost = staticInfo.EstimatedCost
		local OpenHS300Price  = staticInfo.OpenHS300Price --建仓沪深300的最新价
		local OpenFuturePrice = staticInfo.OpenFuturePrice --建仓期指的最新价
		local CloseHS300Price  = staticInfo.CloseHS300Price --平仓沪深300的最新价
		local CloseFuturePrice = staticInfo.CloseFuturePrice  --平仓期指的最新价
		if OpenHS300Price ~= "-" then
			OpenlongPrice = OpenHS300Price
		end

		if OpenFuturePrice ~= "-" then
			OpenshortPrice = OpenFuturePrice
		end

		if CloseHS300Price ~= "-" then
			CloselongPrice = CloseHS300Price
		end

		if CloseFuturePrice ~= "-" then
			CloseshortPrice = CloseFuturePrice
		end
	end

	local basis = OpenshortPrice - OpenlongPrice							--价差
	local positionBasis = CloseshortPrice - CloselongPrice				--持仓基差
	combinList.positionBasis = positionBasis
	combinList.basis = basis
	--if portID == gPortID then
	--local log2 = sys_format("OpenlongPrice[%s],OpenshortPrice[%s],CloseshortPrice[%s],CloselongPrice[%s],basis[%s],positionBasis[%s]",OpenlongPrice,OpenshortPrice,CloseshortPrice,CloselongPrice,basis,positionBasis)
	--_WriteErrorLog(log2)
	--end

	spotSpotMarket = sys_format("%.0f",spotSpotMarket)
	futureSpotMarket = sys_format("%.0f",futureSpotMarket)
	open = sys_format("%.0f",open)

	spotValuePosition = sys_format("%.0f",spotValuePosition)
	futureValuePosition = sys_format("%.0f",futureValuePosition)
	openPosition = sys_format("%.0f",openPosition)
	basis = sys_format("%.02f",basis)
	positionBasis = sys_format("%.02f",positionBasis)
	if estimatedEarnings ~= "-" then
		estimatedEarnings = sys_format("%.02f",estimatedEarnings)
	end
	if alphaReturns ~= "-" then
		alphaReturns = sys_format("%.02f",alphaReturns)
	end

	stock = gtInventoryName[stock] or "-"
	local DTSEvent inventory = _CreateEventObject("VInventoryListTable")
	inventory._SetFld("SpotVarieties",spotVarieties)						--现货品种
	inventory._SetFld("ContractNo",stockNum)								--合约分数
	inventory._SetFld("StockStatus",stockStatus)							--股票状态
	inventory._SetFld("FutureStatus",futureStatus)							--期货状态
																			----------建仓情况----------
	inventory._SetFld("Basis",basis)										--基差
	inventory._SetFld("SpotMarket",spotSpotMarket)							--现货市值
	inventory._SetFld("FutureMarket",futureSpotMarket)						--期货市值
	inventory._SetFld("Open",open)											--敞口
																			----------持仓情况----------
	inventory._SetFld("PositionBasis",positionBasis)						--持仓基差
	inventory._SetFld("SpotValuePosition",spotValuePosition)				--现货持仓市值
	inventory._SetFld("FutureValuePosition",futureValuePosition)			--期货持仓市值
	inventory._SetFld("OpenPosition",openPosition)							--持仓敞口
																			----------套利分析----------
	inventory._SetFld("BasicEarnings",basicEarnings)						--基差收益
	inventory._SetFld("EstimatedEarnings",estimatedEarnings)				--预估收益
	inventory._SetFld("AlphaReturns",alphaReturns)							--α收益
	inventory._SetFld("OpenReturn",openReturn)								--敞口收益
	inventory._SetFld("ChargeCost",chargeCost)								--冲击成本
	inventory._SetFld("EstimatedCost",estimatedCost)						--预估费用

	inventory._SetFld("PortID",portID)										--套利组合号
	inventory._SetFld("CombinName",combinName)
	inventory._SetFld("Stock",stock)
	inventory._SetFld("StockNum",stockNum)
	inventory._SetFld("StockBuy",stockBuy)
	inventory._SetFld("StockSell",stockSell)
	inventory._SetFld("Future",future)
	inventory._SetFld("FutureNum",futureNum)
	inventory._SetFld("FutureBuy",futureBuy)
	inventory._SetFld("FutureSell",futureSell)

	_SendToClients(inventory)
end
function calculateInventory(portID)								--计算套利组合内显示字段
	local combinList = gtCombinList[portID]
	if not combinList then
		return "未找到套利组合"
	end
	local inventoryModelID = combinList.Stock
	local spotVarieties = combinList.InventoryNum
	local stockStatus = combinList.StockStatus
	local futureStatus = combinList.FutureStatus
	local combinName = combinList.CombinName
	local stock = combinList.Stock
	local stockNum = combinList.StockNum
	local stockBuy = combinList.StockBuy
	local stockSell = combinList.StockSell
	local future = combinList.Future
	local futureNum = combinList.FutureNum
	local futureBuy = combinList.FutureBuy
	local futureSell = combinList.FutureSell

	local longPrice = GetOrderPrice("M000300",0,0,"最新价","不浮动")
	local shortPrice = GetOrderPrice(future,0,0,"最新价","不浮动")

	local spotSpotMarket = 0										--现货委托市值
	local spotValuePosition = 0										--现货持仓成本
	local futureSpotMarket = shortPrice * 300 * futureNum			--期货委托市值
	local futureValuePosition = 0									--期货持仓成本
	local shortPricePosition = 0									--期货持仓价位
	local futureQty = 0												--期货持仓数量
	for issue,v in pairs(gtCombinList[portID].List) do
		local price = GetOrderPrice(issue,0,0,"最新价","不浮动")
		local qty = v.OrderBuyQty or 0
		spotSpotMarket = spotSpotMarket + price * qty
	end
	local open = longPrice * 300 * stockNum - spotSpotMarket		--敞口值

	if gtArbitragePositionTable[portID] then
		local staticInfo = gtArbitrageInfoTable[portID]
		local stockInit =false
		local futInit =false

		for key,value in pairs(gtArbitragePositionTable[portID]) do
			local issueCode = value.IssueCode
			local market = _PosIssueMarketTable[issueCode]
			local longShort = value.LongShort
			local amount = value.Amount
			local qty = value.Quantity

			if market == "1" or market == "2" then
				spotValuePosition = spotValuePosition + amount
			elseif market == "3" and longShort == "3" then
				futureValuePosition = futureValuePosition + amount
				futureQty = futureQty + qty
			end

			---汇总组合情况显示的数据
			if staticInfo then

				if market == "1" or market == "2" then
					if not stockInit then
						staticInfo.SpotMarketValue = 0
						staticInfo.SpotVarieties = 0
						staticInfo.SpotFloatStatus = 0
						stockInit = true
					end
					local spotValue = 0
					if _PosPriceTable[issueCode] then
						spotValue = _PosPriceTable[issueCode].LastPrice * qty
					end
					staticInfo.SpotMarketValue = staticInfo.SpotMarketValue + spotValue
					staticInfo.SpotVarieties = staticInfo.SpotVarieties + 1
					staticInfo.SpotFloatStatus  = staticInfo.SpotFloatStatus + value.ValuationPL + value.CumulationDividend

				elseif market == "3" then
					if not futInit then
						staticInfo.FutureMarketValue = 0
						staticInfo.FutureFloatStatus  = 0
						futInit = true
					end

					local spotValue = 0
					if _PosPriceTable[issueCode] then
						spotValue = _PosPriceTable[issueCode].LastPrice * qty * 300
					end

					staticInfo.FutureMarketValue = staticInfo.FutureMarketValue + spotValue
					staticInfo.FutureFloatStatus  = staticInfo.FutureFloatStatus + value.ValuationPL
				end
			end

		end
		if futureQty ~= 0 then
			shortPricePosition = futureValuePosition / futureQty / 300
		end
	end

	local openPosition = longPrice * 300 * stockNum - spotValuePosition			--持仓敞口值

	combinList.spotSpotMarket = spotSpotMarket
	combinList.spotValuePosition = spotValuePosition
	combinList.futureSpotMarket = futureSpotMarket
	combinList.futureValuePosition = futureValuePosition
	combinList.open = open
	combinList.openPosition = openPosition
end
function StockOpenPosTable(portID,issueCode)					--现货组合建仓表单个合约刷新
	local combinList = gtCombinList[portID]
	if not combinList then
		return
	end
	if not combinList.List[issueCode] then
		return
	end
	local sampleNum = combinList.List[issueCode].Quantity			--样本数量
	local status = combinList.List[issueCode].Status				--合约状态
	local notBuyQty = combinList.List[issueCode].NotBuyQty		--买盘不足状态
	local notSell = combinList.List[issueCode].NotSell				--不卖出判断
	local userPos = combinList.List[issueCode].UserPos			--使用库存量
	local stockPrice = combinList.List[issueCode].StockSell			--取价方式
	local stockBuytick = combinList.List[issueCode].StockSellTick	--卖盘tick
	local OrderSellQty = sampleNum*combinList.StockNum				--委托卖出数量
	local inventory = combinList.List[issueCode].Inventory			--使用库存数量

	local issueName = _PosIssueNameTable[issueCode]					--合约中文名称
	local lastPrice = GetOrderPrice(issueCode,0,0,"最新价","不浮动")	--最新价
	local adjustedLNC = GetOrderPrice(issueCode,0,0,"AdjustedLNC","不浮动")	--昨收盘
	local rose = 0													--涨跌幅
	if adjustedLNC ~= 0 and  lastPrice ~= 0 then
		rose = (lastPrice - adjustedLNC) / adjustedLNC
	end

	if notSell == "1" then
		OrderSellQty = 0
		inventory = 0
	else
		if userPos == "1" then
			--委买数量 = 取整(样本股*分数) - 库存
			if OrderSellQty >= inventory then
				OrderSellQty = OrderSellQty - inventory
			else
				inventory = OrderSellQty
				OrderSellQty = 0
			end
		else
			inventory = 0
		end
	end
	OrderSellQty = (sys_ceil(OrderSellQty/100)*100)					--向上取100整 委托买入数量
	local sellPrice = GetOrderPrice(issueCode,0,OrderSellQty,stockPrice,stockBuytick)--委托买入价格
	local buyingQuantity = GetOrderQty(issueCode,stockPrice,"Buy")		--买入盘口数量
	local handicap = stateJudge(issueCode)
	if handicap ~= status then
		if handicap == "停牌" then
		gtCombinList[portID].SP = gtCombinList[portID].SP + 1
		elseif handicap == "跌停" then
		gtCombinList[portID].DL = gtCombinList[portID].DL + 1
		elseif handicap == "涨停" then
		gtCombinList[portID].SL = gtCombinList[portID].SL + 1
		end
		if status == "停牌" then
		gtCombinList[portID].SP = gtCombinList[portID].SP - 1
		elseif status == "跌停" then
		gtCombinList[portID].DL = gtCombinList[portID].DL - 1
		elseif status == "涨停" then
		gtCombinList[portID].SL = gtCombinList[portID].SL - 1
		end
	end
	if buyingQuantity < OrderSellQty then
		if notBuyQty == "正常" then
		gtCombinList[portID].NotBuyQty = gtCombinList[portID].NotBuyQty + 1
		end
		combinList.List[issueCode].NotBuyQty = "盘口不足"
	else
		if notBuyQty == "盘口不足" then
			gtCombinList[portID].NotBuyQty = gtCombinList[portID].NotBuyQty - 1
		end
		combinList.List[issueCode].NotBuyQty = "正常"
	end

	local dealQty = 0
	local dealPrice = 0
	local Amount = 0
	local avlQty = 0
	if gtArbitragePositionTable[portID] then
		for key,value in pairs(gtArbitragePositionTable[portID]) do
			local issue = value.IssueCode
			if issue == issueCode then
				dealQty = dealQty + value.Quantity
				Amount = Amount + value.Amount
				avlQty = avlQty + value.AvlQuantity
			end
		end
		if dealQty ~= 0 then
			dealPrice = Amount / dealQty
		end
	end

	gtCombinList[portID].List[issueCode].Status = handicap					--合约行情状态
	gtCombinList[portID].List[issueCode].OrderSellQty = OrderSellQty			--委托卖出数量
	gtCombinList[portID].List[issueCode].OrderSellPrice = sellPrice			--委托卖出价格
	gtCombinList[portID].List[issueCode].ExecQuantity = dealQty				--持仓数量
	gtCombinList[portID].List[issueCode].ExecPrice = dealPrice				--持仓均价
	gtCombinList[portID].List[issueCode].Inventory = inventory 				--使用库存量

	if combinList.List[issueCode].NotBuyQty == "盘口不足" then
		handicap = "不足"
	end
	rose = sys_format("%.02f",rose * 100)
	lastPrice = sys_format("%.02f",lastPrice)
	sellPrice = sys_format("%.02f",sellPrice)
	dealPrice = sys_format("%.02f",dealPrice)

	sampleNum = sys_format("%.0f",sampleNum)
	OrderSellQty = sys_format("%.0f",OrderSellQty)
	dealQty = sys_format("%.0f",dealQty)
	avlQty = sys_format("%.0f",avlQty)
	buyingQuantity = sys_format("%.0f",buyingQuantity)
	inventory = sys_format("%.0f",inventory)

	local DTSEvent StockOpen = _CreateEventObject("VStockOpenPosTable")
	StockOpen._SetFld("IssueCode",issueCode)				--合约代码
	StockOpen._SetFld("IssueName",issueName)				--合约名称
	StockOpen._SetFld("SampleNum",sampleNum)				--样本数量
	StockOpen._SetFld("Rose",rose)							--涨幅
	StockOpen._SetFld("LastPrice",lastPrice)				--最新价
	StockOpen._SetFld("StockPrice",stockPrice)				--取价方式
	StockOpen._SetFld("SellPrice",sellPrice)					--委卖价格
	StockOpen._SetFld("SellQty",OrderSellQty)					--委卖数量
	StockOpen._SetFld("Handicap",handicap)					--盘口
	StockOpen._SetFld("DealQty",dealQty)					--成交数量/持仓数量
	StockOpen._SetFld("DealPrice",dealPrice)				--成交价格
	StockOpen._SetFld("AvlQty",avlQty)				--可用数量

	StockOpen._SetFld("BuyingQuantity",buyingQuantity)	--买盘数量
	StockOpen._SetFld("Inventory",inventory)				--使用库存量
	StockOpen._SetFld("UserPos",userPos)					--使用库存
	StockOpen._SetFld("NotSell",notSell)						--不买入

	_SendToClients(StockOpen)


end
function StockClosePosTable(portID,issueCode)					--现货组合平仓表单个合约刷新
	local combinList = gtCombinList[portID]
	if not combinList then
		return
	end
	if not combinList.List[issueCode] then
		return
	end

	local sampleNum = combinList.List[issueCode].Quantity			--样本数量
	local status = combinList.List[issueCode].Status				--合约状态
	local NotSellQty = combinList.List[issueCode].NotSellQty		--卖盘不足状态
	local issueName = _PosIssueNameTable[issueCode]					--合约中文名称
	local lastPrice = GetOrderPrice(issueCode,0,0,"最新价","不浮动")	--最新价
	local adjustedLNC = GetOrderPrice(issueCode,0,0,"AdjustedLNC","不浮动")	--昨收盘
	local stockPrice = combinList.List[issueCode].StockBuy			--买盘取价方式
	local stockBuytick = combinList.List[issueCode].StockBuyTick	--买盘tick
	local OrderBuyQty = sampleNum*combinList.StockNum				--委托买入数量
	local notBuy = combinList.List[issueCode].NotBuy				--不买入判断
	local savePos = combinList.List[issueCode].SavePos				--使用留存量
	local saveQty = combinList.List[issueCode].SaveQty				--留存数量
	--local log = sys_format("lastPrice[%s],adjustedLNC[%s],notBuy[%s],savePos[%s],saveQty[%s]",lastPrice,adjustedLNC,notBuy,savePos,saveQty)
	--_WriteAplLog(log)
	local rose = 0													--涨跌幅
	if adjustedLNC ~= 0 and  lastPrice ~= 0 then
		rose = (lastPrice - adjustedLNC) / adjustedLNC
	end

	if notBuy == "1" then
		OrderBuyQty = 0
		saveQty = 0
	else
		if savePos == "1" then
			--委卖数量 = 取整(样本股*分数) - 留存
			if  OrderBuyQty >= saveQty then
				OrderBuyQty = OrderBuyQty - saveQty
			else
				saveQty = OrderBuyQty
				OrderBuyQty = 0
			end
		else
			saveQty = 0
		end
	end

	local buyPrice = GetOrderPrice(issueCode,1,OrderBuyQty,stockPrice,stockBuytick)	--委托买入价格
	local sellingQuantity = GetOrderQty(issueCode,stockPrice,"Sell")		--卖出盘口数量

	local handicap = stateJudge(issueCode)
	if handicap == status then
	else
		if handicap == "停牌" then
		gtCombinList[portID].SP = gtCombinList[portID].SP + 1
		elseif handicap == "跌停" then
		gtCombinList[portID].DL = gtCombinList[portID].DL + 1
		elseif handicap == "涨停" then
		gtCombinList[portID].SL = gtCombinList[portID].SL + 1
		end
		if status == "停牌" then
		gtCombinList[portID].SP = gtCombinList[portID].SP - 1
		elseif status == "跌停" then
		gtCombinList[portID].DL = gtCombinList[portID].DL - 1
		elseif status == "涨停" then
		gtCombinList[portID].SL = gtCombinList[portID].SL - 1
		end
	end
	if sellingQuantity < OrderBuyQty then
		if NotSellQty == "正常" then
		gtCombinList[portID].NotSellQty = gtCombinList[portID].NotSellQty + 1
		end
		combinList.List[issueCode].NotSellQty = "盘口不足"
	else
		if NotSellQty == "盘口不足" then
			gtCombinList[portID].NotSellQty = gtCombinList[portID].NotSellQty - 1
		end
		combinList.List[issueCode].NotSellQty = "正常"
	end


	local sellingCost = 0
	local dealQty = 0
	local dealPrice = 0
	local avlQty = 0

	if gtArbitragePositionTable[portID] then
		for key ,value in pairs(gtArbitragePositionTable[portID]) do
			local issue = value.IssueCode
			if issue == issueCode then
				sellingCost = sellingCost + value.Amount
				dealQty = dealQty + value.Quantity
				avlQty = avlQty + value.AvlQty
			end
		end
		if dealQty ~= 0 then
			dealPrice = sellingCost / dealQty
		end
	end
	--if OrderBuyQty > avlQty then		--委托买入数量一定要小于可用数量
	--	OrderBuyQty = avlQty
	--end
	gtCombinList[portID].List[issueCode].Status = handicap					--合约行情状态
	gtCombinList[portID].List[issueCode].OrderBuyQty = OrderBuyQty		--委托买入数量
	gtCombinList[portID].List[issueCode].OrderBuyPrice = buyPrice			--委托买入价格
	gtCombinList[portID].List[issueCode].SaveQty = saveQty 					--留存量

	if combinList.List[issueCode].NotSellQty == "盘口不足" then
		handicap = "不足"
	end
	rose = sys_format("%.02f",rose * 100)
	lastPrice = sys_format("%.02f",lastPrice)
	dealPrice = sys_format("%.02f",dealPrice)
	sellingCost = sys_format("%.02f",sellingCost)

	OrderBuyQty = sys_format("%.0f",OrderBuyQty)
	saveQty = sys_format("%.0f",saveQty)
	sampleNum = sys_format("%.0f",sampleNum)
	dealQty = sys_format("%.0f",dealQty)
	avlQty = sys_format("%.0f",avlQty)
	sellingQuantity = sys_format("%.0f",sellingQuantity)

	local DTSEvent StockClose = _CreateEventObject("VStockClosePosTable")
	StockClose._SetFld("IssueCode",issueCode)				--合约代码
	StockClose._SetFld("IssueName",issueName)				--合约名称
	StockClose._SetFld("SampleNum",sampleNum)				--样本数量
	StockClose._SetFld("Rose",rose)							--涨幅
	StockClose._SetFld("LastPrice",lastPrice)				--最新价
	StockClose._SetFld("StockPrice",stockPrice)				--取价方式
	StockClose._SetFld("SellingCost",sellingCost)				--卖出成本
	StockClose._SetFld("BuyPrice",buyPrice)				--委买价格
	StockClose._SetFld("BuyQty",OrderBuyQty)				--委买数量
	StockClose._SetFld("Handicap",handicap)					--盘口
	StockClose._SetFld("DealQty",dealQty)					--持仓数量
	StockClose._SetFld("DealPrice",dealPrice)				--持仓均价
	StockClose._SetFld("AvlQty",avlQty)						--可用数量
	StockClose._SetFld("SellingQuantity",sellingQuantity)		--卖盘数量
	StockClose._SetFld("SaveQty",saveQty)					--留存量
	StockClose._SetFld("SavePos",savePos)					--留存
	StockClose._SetFld("NotBuy",notBuy)					--不买入

	_SendToClients(StockClose)
end

function StockAllTable(portID,issueCode)						--现货组合建平仓表单个合约刷新
	local combinList = gtCombinList[portID]
	if not combinList then
		return
	end
	if not combinList.List[issueCode] then
		return
	end
	--open
	local sampleNum = combinList.List[issueCode].Quantity			--样本数量
	local status = combinList.List[issueCode].Status				--合约状态
	local notSellQty = combinList.List[issueCode].NotSellQty		--卖盘不足状态
	local notSell = combinList.List[issueCode].NotSell				--不买入判断
	local userPos = combinList.List[issueCode].UserPos			--使用库存量
	local stockBuyPrice = combinList.List[issueCode].StockBuy			--取价方式
	local stockBuytick = combinList.List[issueCode].StockBuyTick	--买盘tick
	local OrderBuyQty = sampleNum*combinList.StockNum				--委托买入数量
	local inventory = combinList.List[issueCode].Inventory			--使用库存数量

	local issueName = _PosIssueNameTable[issueCode]					--合约中文名称
	local lastPrice = GetOrderPrice(issueCode,0,0,"最新价","不浮动")	--最新价
	local adjustedLNC = GetOrderPrice(issueCode,0,0,"AdjustedLNC","不浮动")	--昨收盘

	--close
	local notBuyQty = combinList.List[issueCode].NotBuyQty		--买盘不足状态
	local stockSellPrice = combinList.List[issueCode].StockSell			--卖盘取价方式
	local stockSelltick = combinList.List[issueCode].StockSellTick	--卖盘tick
	local OrderSellQty = sampleNum*combinList.StockNum				--委托卖出数量
	local notBuy = combinList.List[issueCode].NotBuy				--不卖出判断
	local savePos = combinList.List[issueCode].SavePos				--使用留存量
	local saveQty = combinList.List[issueCode].SaveQty				--留存数量


	local rose = 0													--涨跌幅
	if adjustedLNC ~= 0 and  lastPrice ~= 0 then
		rose = (lastPrice - adjustedLNC) / adjustedLNC
	end
	--open
	if notSell == "1" then	--开仓 融券卖出
		OrderSellQty = 0
		inventory = 0
	else
		if userPos == "1" then
			--委买数量 = 取整(样本股*分数) - 库存
			if OrderSellQty >= inventory then
				OrderSellQty = OrderSellQty - inventory
			else
				inventory = OrderSellQty
				OrderSellQty = 0
			end
		else
			inventory = 0
		end
	end
	OrderSellQty = (sys_ceil(OrderSellQty/100)*100)					--向上取100整 委托买入数量
	--close
	if notBuy == "1" then	--平仓 买券还券
		OrderBuyQty = 0
		saveQty = 0
	else
		if savePos == "1" then
			--委卖数量 = 取整(样本股*分数) - 留存
			if  OrderBuyQty >= saveQty then
				OrderBuyQty = OrderBuyQty - saveQty
			else
				saveQty = OrderBuyQty
				OrderBuyQty = 0
			end
		else
			saveQty = 0
		end
	end
	--open
	local buyPrice = GetOrderPrice(issueCode,0,OrderBuyQty,stockBuyPrice,stockBuytick)--委托买入价格
	local sellingQuantity = GetOrderQty(issueCode,stockBuyPrice,"Sell")		--卖出盘口数量
	--close
	local sellPrice = GetOrderPrice(issueCode,1,OrderSellQty,stockSellPrice,stockSelltick)	--委托卖出价格
	local buyingQuantity = GetOrderQty(issueCode,stockSellPrice,"Buy")		--买入盘口数量

	local handicap = stateJudge(issueCode)
	local handicapClose = handicap
	if handicap ~= status then
		if handicap == "停牌" then
		gtCombinList[portID].SP = gtCombinList[portID].SP + 1
		elseif handicap == "跌停" then
		gtCombinList[portID].DL = gtCombinList[portID].DL + 1
		elseif handicap == "涨停" then
		gtCombinList[portID].SL = gtCombinList[portID].SL + 1
		end
		if status == "停牌" then
		gtCombinList[portID].SP = gtCombinList[portID].SP - 1
		elseif status == "跌停" then
		gtCombinList[portID].DL = gtCombinList[portID].DL - 1
		elseif status == "涨停" then
		gtCombinList[portID].SL = gtCombinList[portID].SL - 1
		end
	end
	--open
	if buyingQuantity < OrderSellQty then
		if notBuyQty == "正常" then
			gtCombinList[portID].NotBuyQty = gtCombinList[portID].NotBuyQty + 1
		end
		combinList.List[issueCode].NotBuyQty = "盘口不足"
	else
		if notBuyQty == "盘口不足" then
			gtCombinList[portID].NotBuyQty = gtCombinList[portID].NotBuyQty - 1
		end
		combinList.List[issueCode].NotBuyQty = "正常"
	end
	--close
	if sellingQuantity < OrderBuyQty then
		if notSellQty == "正常" then
			gtCombinList[portID].NotSellQty = gtCombinList[portID].NotSellQty + 1
		end
		combinList.List[issueCode].NotSellQty = "盘口不足"
	else
		if notSellQty == "盘口不足" then
			gtCombinList[portID].NotSellQty = gtCombinList[portID].NotSellQty - 1
		end
		combinList.List[issueCode].NotSellQty = "正常"
	end
	--取持仓数据
	local dealQty = 0
	local dealPrice = 0
	local Amount = 0
	local avlQty = 0
	if gtArbitragePositionTable[portID] then
		for key,value in pairs(gtArbitragePositionTable[portID]) do
			local issue = value.IssueCode
			if issue == issueCode then
				dealQty = dealQty + value.Quantity
				Amount = Amount + value.Amount
				avlQty = avlQty + value.AvlQty
			end
		end
		if dealQty ~= 0 then
			dealPrice = Amount / dealQty
		end
	end

	gtCombinList[portID].List[issueCode].Status = handicap					--合约行情状态
	gtCombinList[portID].List[issueCode].OrderBuyQty = OrderBuyQty			--委托买入数量
	gtCombinList[portID].List[issueCode].OrderBuyPrice = buyPrice			--委托买入价格
	gtCombinList[portID].List[issueCode].ExecQuantity = dealQty				--持仓数量
	gtCombinList[portID].List[issueCode].ExecPrice = dealPrice				--持仓均价
	gtCombinList[portID].List[issueCode].Inventory = inventory 				--使用库存量
	gtCombinList[portID].List[issueCode].OrderSellQty = OrderSellQty		--委托卖出数量
	gtCombinList[portID].List[issueCode].OrderSellPrice = sellPrice			--委托卖出价格
	gtCombinList[portID].List[issueCode].SaveQty = saveQty 					--留存量

	if combinList.List[issueCode].NotBuyQty == "盘口不足" then
		handicap = "不足"
	end

	if combinList.List[issueCode].NotSellQty == "盘口不足" then
		handicapClose = "不足"
	end

	--open
	rose = sys_format("%.02f",rose * 100)
	lastPrice = sys_format("%.02f",lastPrice)
	buyPrice = sys_format("%.02f",buyPrice)
	dealPrice = sys_format("%.02f",dealPrice)

	sampleNum = sys_format("%.0f",sampleNum)
	OrderBuyQty = sys_format("%.0f",OrderBuyQty)
	dealQty = sys_format("%.0f",dealQty)
	sellingQuantity = sys_format("%.0f",sellingQuantity)
	inventory = sys_format("%.0f",inventory)

	--close
	Amount = sys_format("%.02f",Amount)

	OrderSellQty = sys_format("%.0f",OrderSellQty)
	saveQty = sys_format("%.0f",saveQty)

	avlQty = sys_format("%.0f",avlQty)
	buyingQuantity = sys_format("%.0f",buyingQuantity)


	local DTSEvent StockOpen = _CreateEventObject("VStockOpenPosTable")
	StockOpen._SetFld("IssueCode",issueCode)				--合约代码
	StockOpen._SetFld("IssueName",issueName)				--合约名称
	StockOpen._SetFld("SampleNum",sampleNum)				--样本数量
	StockOpen._SetFld("Rose",rose)							--涨幅
	StockOpen._SetFld("LastPrice",lastPrice)				--最新价
	StockOpen._SetFld("StockPrice",stockSellPrice)			--取价方式
	StockOpen._SetFld("SellPrice",sellPrice)				--委卖价格
	StockOpen._SetFld("SellQty",OrderSellQty)				--委卖数量
	StockOpen._SetFld("Handicap",handicap)					--盘口
	StockOpen._SetFld("DealQty",dealQty)					--成交数量
	StockOpen._SetFld("DealPrice",dealPrice)				--成交价格
	StockOpen._SetFld("AvlQty",avlQty)						--可用数量
	StockOpen._SetFld("BuyingQuantity",buyingQuantity)		--买盘数量
	StockOpen._SetFld("Inventory",inventory)				--使用库存量
	StockOpen._SetFld("UserPos",userPos)					--使用库存
	StockOpen._SetFld("NotSell",notSell)						--不买入

	_SendToClients(StockOpen)

	local DTSEvent StockClose = _CreateEventObject("VStockClosePosTable")
	StockClose._SetFld("IssueCode",issueCode)				--合约代码
	StockClose._SetFld("IssueName",issueName)				--合约名称
	StockClose._SetFld("SampleNum",sampleNum)				--样本数量
	StockClose._SetFld("Rose",rose)							--涨幅
	StockClose._SetFld("LastPrice",lastPrice)				--最新价
	StockClose._SetFld("StockPrice",stockBuyPrice)				--取价方式
	StockClose._SetFld("SellingCost",Amount)				--买入成本
	StockClose._SetFld("BuyPrice",buyPrice)					--委买价格
	StockClose._SetFld("BuyQty",OrderBuyQty)					--委买数量
	StockClose._SetFld("Handicap",handicapClose)					--盘口
	StockClose._SetFld("DealQty",dealQty)					--持仓数量
	StockClose._SetFld("DealPrice",dealPrice)				--持仓均价
	StockClose._SetFld("AvlQty",avlQty)						--可用数量
	StockClose._SetFld("SellingQuantity",sellingQuantity)	--卖盘数量
	StockClose._SetFld("SaveQty",saveQty)					--留存量
	StockClose._SetFld("SavePos",savePos)					--留存
	StockClose._SetFld("NotBuy",notBuy)					--不卖出

	_SendToClients(StockClose)
end


function FutureOpenPosTable(portID)								--刷新期货建仓表
	local combinList = gtCombinList[portID]
	if not combinList then
		return
	end
	local issueCode = combinList.Future
	if not gFutureList[issueCode] then
		return
	end
	local lastPrice =  GetOrderPrice(issueCode,0,0,"最新价","不浮动")	--最新价
	local adjustedLNC = GetOrderPrice(issueCode,0,0,"AdjustedLNC","不浮动")	--昨收盘
	local rose = 0													--涨跌幅
	if adjustedLNC ~= 0 and adjustedLNC then
		rose = (lastPrice - adjustedLNC) / adjustedLNC
	end
	local buySell = "买入"
	local openClose = "开仓"
	local futurePrice = gtCombinList[portID].FutureBuy
	local futureTick = gtCombinList[portID].FutureBuyTick
	local entrustQty = gtCombinList[portID].FutureNum
	local entrustPrice = GetOrderPrice(issueCode,1,entrustQty,futurePrice,futureTick)
	local dealQty = 0
	local dealPrice = 0
	local amount = 0
	local OrderBuyQty = 0

	if gtArbitragePositionTable[portID] then
		for key,info in pairs(gtArbitragePositionTable[portID]) do
			local issue = info.IssueCode
			local longshort = info.LongShort
			if issue == issueCode and longshort == "3" then
				amount = amount + info.Amount
				dealQty = dealQty + info.Quantity
			end
		end
		if dealQty ~= 0 then
			dealPrice = amount / dealQty / 300
		end
	end

	rose = sys_format("%.02f",rose * 100)
	lastPrice = sys_format("%.02f",lastPrice)
	dealPrice = sys_format("%.02f",dealPrice)
	entrustPrice = sys_format("%.02f",entrustPrice)
	entrustQty = sys_format("%.0f",entrustQty)
	dealQty = sys_format("%.0f",dealQty)

	local DTSEvent FutureOpen = _CreateEventObject("VFutureOpenPosTable")
	FutureOpen._SetFld("IssueCode",issueCode)
	FutureOpen._SetFld("Rose",rose)
	FutureOpen._SetFld("LastPrice",lastPrice)
	FutureOpen._SetFld("BuySell",buySell)
	FutureOpen._SetFld("OpenClose",openClose)
	FutureOpen._SetFld("FuturePrice",futurePrice)
	FutureOpen._SetFld("EntrustPrice",entrustPrice)
	FutureOpen._SetFld("EntrustQty",entrustQty)
	FutureOpen._SetFld("DealQty",dealQty)
	FutureOpen._SetFld("DealPrice",dealPrice)

	_SendToClients(FutureOpen)
end


function FutureClosePosTable(portID)							--刷新期货平仓表
	local combinList = gtCombinList[portID]
	if not combinList then
		return
	end
	local issueCode = combinList.Future
	if not gFutureList[issueCode] then
		return
	end
	local lastPrice = GetOrderPrice(issueCode,0,0,"最新价","不浮动")	--最新价
	local adjustedLNC = GetOrderPrice(issueCode,0,0,"AdjustedLNC","不浮动")	--昨收盘
	local rose = 0													--涨跌幅
	if adjustedLNC ~= 0 and adjustedLNC then
		rose = (lastPrice - adjustedLNC) / adjustedLNC
	end
	--local status = "-"
	local buySell = "卖出"
	local openClose = "平仓"
	local futurePrice = gtCombinList[portID].FutureSell
	local futureTick = gtCombinList[portID].FutureSellTick
	local entrustQty = gtCombinList[portID].FutureNum
	local entrustPrice = GetOrderPrice(issueCode,0,entrustQty,futurePrice,futureTick)
	local dealQty = 0
	local dealPrice = 0
	local amount = 0


	if gtArbitragePositionTable[portID] then
		for key,info in pairs(gtArbitragePositionTable[portID]) do
			local issue = info.IssueCode
			local longshort = info.LongShort
			if issue == issueCode and longshort == "3" then
				amount = amount + info.Amount
				dealQty = dealQty + info.Quantity
			end
		end
		if dealQty ~= 0 then
			dealPrice = amount / dealQty / 300
		end
	end

	rose = sys_format("%.02f",rose * 100)
	lastPrice = sys_format("%.02f",lastPrice)
	entrustPrice = sys_format("%.02f",entrustPrice)
	dealPrice = sys_format("%.02f",dealPrice)
	entrustQty = sys_format("%.0f",entrustQty)
	dealQty = sys_format("%.0f",dealQty)

	local DTSEvent FutureClose = _CreateEventObject("VFutureClosePosTable")
	FutureClose._SetFld("IssueCode",issueCode)
	FutureClose._SetFld("Rose",rose)
	FutureClose._SetFld("LastPrice",lastPrice)
	FutureClose._SetFld("BuySell",buySell)
	FutureClose._SetFld("OpenClose",openClose)
	FutureClose._SetFld("FuturePrice",futurePrice)
	FutureClose._SetFld("EntrustPrice",entrustPrice)
	FutureClose._SetFld("EntrustQty",entrustQty)
	FutureClose._SetFld("DealQty",dealQty)
	FutureClose._SetFld("DealPrice",dealPrice)

	_SendToClients(FutureClose)
end
function FutureAllTable(portID)									--刷新期货建平仓表
	local combinList = gtCombinList[portID]
	if not combinList then
		return
	end
	local issueCode = combinList.Future
	if not gFutureList[issueCode] then
		return
	end
	local lastPrice =  GetOrderPrice(issueCode,0,0,"最新价","不浮动")	--最新价
	local adjustedLNC = GetOrderPrice(issueCode,0,0,"AdjustedLNC","不浮动")	--昨收盘
	local rose = 0													--涨跌幅
	if adjustedLNC ~= 0 and adjustedLNC then
		rose = (lastPrice - adjustedLNC) / adjustedLNC
	end
	--open
	local buySell = "买入"
	local openClose = "开仓"
	local futurePrice = gtCombinList[portID].FutureBuy
	local futureTick = gtCombinList[portID].FutureBuyTick
	local entrustQty = gtCombinList[portID].FutureNum
	local entrustPrice = GetOrderPrice(issueCode,1,entrustQty,futurePrice,futureTick)
	local dealQty = 0
	local dealPrice = 0
	local amount = 0
	--close
	local buySell2 = "卖出"
	local openClose2 = "平仓"
	local futurePrice2 = gtCombinList[portID].FutureSell
	local futureTick2 = gtCombinList[portID].FutureSellTick
	local entrustPrice2 = GetOrderPrice(issueCode,0,entrustQty,futurePrice2,futureTick2)


	if gtArbitragePositionTable[portID] then
		for key,info in pairs(gtArbitragePositionTable[portID]) do
			local issue = info.IssueCode
			local longshort = info.LongShort
			if issue == issueCode and longshort == "3" then
				amount = amount + info.Amount
				dealQty = dealQty + info.Quantity
			end
		end
		if dealQty ~= 0 then
			dealPrice = amount / dealQty / 300
		end
	end

	rose = sys_format("%.02f",rose * 100)
	lastPrice = sys_format("%.02f",lastPrice)
	dealPrice = sys_format("%.02f",dealPrice)
	entrustPrice = sys_format("%.02f",entrustPrice)
	entrustQty = sys_format("%.0f",entrustQty)
	dealQty = sys_format("%.0f",dealQty)

	entrustPrice2 = sys_format("%.02f",entrustPrice2)

	local DTSEvent FutureOpen = _CreateEventObject("VFutureOpenPosTable")
	FutureOpen._SetFld("IssueCode",issueCode)
	FutureOpen._SetFld("Rose",rose)
	FutureOpen._SetFld("LastPrice",lastPrice)
	FutureOpen._SetFld("BuySell",buySell)
	FutureOpen._SetFld("OpenClose",openClose)
	FutureOpen._SetFld("FuturePrice",futurePrice)
	FutureOpen._SetFld("EntrustPrice",entrustPrice)
	FutureOpen._SetFld("EntrustQty",entrustQty)
	FutureOpen._SetFld("DealQty",dealQty)
	FutureOpen._SetFld("DealPrice",dealPrice)

	_SendToClients(FutureOpen)


	local DTSEvent FutureClose = _CreateEventObject("VFutureClosePosTable")
	FutureClose._SetFld("IssueCode",issueCode)
	FutureClose._SetFld("Rose",rose)
	FutureClose._SetFld("LastPrice",lastPrice)
	FutureClose._SetFld("BuySell",buySell2)
	FutureClose._SetFld("OpenClose",openClose2)
	FutureClose._SetFld("FuturePrice",futurePrice2)
	FutureClose._SetFld("EntrustPrice",entrustPrice2)
	FutureClose._SetFld("EntrustQty",entrustQty)
	FutureClose._SetFld("DealQty",dealQty)
	FutureClose._SetFld("DealPrice",dealPrice)

	_SendToClients(FutureClose)
end

function SendPosTableEvent(portID)								--刷新现货建平仓控件
	--_WriteErrorLog("SendPosTableEvent")
	if gtCombinList[portID] then
		local SP = gtCombinList[portID].SP
		local SL = gtCombinList[portID].SL
		local DL = gtCombinList[portID].DL
		local buyNo = gtCombinList[portID].InventoryNum
		local sellNo = gtCombinList[portID].InventoryNum
		local buyAmount = 0
		local sellAmount = 0
		local dealAmount = 0
		local notSellQty = gtCombinList[portID].NotSellQty
		local notBuyQty = gtCombinList[portID].NotBuyQty

		for issue,value in pairs(gtCombinList[portID].List) do

			local OrderBuyQty = value.OrderBuyQty												--委托买入数量
			if OrderBuyQty == 0 then
				buyNo = buyNo - 1
			end
			local buyPrice = value.OrderBuyPrice
			buyAmount = buyAmount + buyPrice * OrderBuyQty

			local OrderSellQty = value.OrderSellQty												--委托买入数量
			if OrderSellQty == 0 then
				sellNo = sellNo - 1
			end
			local sellPrice = value.OrderSellPrice
			sellAmount = sellAmount + sellPrice * OrderSellQty

		end

		if gtArbitragePositionTable[portID] then
			for key,info in pairs(gtArbitragePositionTable[portID]) do
				local issue = info.IssueCode
				if _PosIssueMarketTable[issue] == "1" or _PosIssueMarketTable[issue] == "2" then
					dealAmount = dealAmount + info.Amount
				end
			end
		end

		local DTSEvent OpenPos = _CreateEventObject("VOpenPosTableEvent")
		OpenPos._SetFld("BuyNo",buyNo)
		OpenPos._SetFld("BuyAmount",buyAmount)
		OpenPos._SetFld("SellNo",sellNo)
		OpenPos._SetFld("SellAmount",sellAmount)
		OpenPos._SetFld("DealAmount",dealAmount)
		OpenPos._SetFld("NotBuyQty",notBuyQty)
		OpenPos._SetFld("NotSellQty",notSellQty)
		OpenPos._SetFld("SP",SP)
		OpenPos._SetFld("SL",SL)
		OpenPos._SetFld("DL",DL)
		_SendToClients(OpenPos)
	end
end
function GetYMD()												--获取日期
	local DTSDate nowDate = _GetNowDate();
	local _String today = nowDate.asString("%Y%m%d");
	return today
end

function creatID()												--创建组合编码信息
	local strDate = GetYMD()
	--local strDate = os.date("%Y%m%d", os.time())
	local portID = ""
	local SubmitNo = 1; --下单序列号，为了保证每个CombinCode的唯一
	local strSubmitNo = sys_format("%03d",SubmitNo); --格式化成3位
	portID = sys_format("v%s%s",strDate,strSubmitNo);
	while findID(portID) do
		SubmitNo = SubmitNo + 1;
		strSubmitNo = sys_format("%03d",SubmitNo);
		portID = sys_format("v%s%s",strDate,strSubmitNo);
	end
	local log = "createportID by the function of creatIDtodisposition:"..portID
	_WriteErrorLog(log);
	return portID;
end
function findID(portID)  										--找到最新组合编号
	for CombinCode, info in pairs(gtCombinList) do
		if portID == CombinCode then
			return true
		end
	end
	if gtArbitragePositionTable[portID] then
		return true
	end
	if gtOrderList[portID] then
		return true
	end
	return false
end


function GetOrderQty(issueCode,mode,BuySell)					--取下单量
	local qty = 0
	local priceInfo = _PosPriceTable[issueCode]
	if priceInfo then
		if mode == "自动盘口" then
			local askQty1 = priceInfo.AskQuantity1 or 0
			local askQty2 = priceInfo.AskQuantity2 or 0
			local askQty3 = priceInfo.AskQuantity3 or 0
			local askQty4 = priceInfo.AskQuantity4 or 0
			local askQty5 = priceInfo.AskQuantity5 or 0
			local askQty6 = priceInfo.AskQuantity6 or 0
			local askQty7 = priceInfo.AskQuantity7 or 0
			local askQty8 = priceInfo.AskQuantity8 or 0
			local askQty9 = priceInfo.AskQuantity9 or 0
			local askQty10 = priceInfo.AskQuantity10 or 0
			local bidQty1 = priceInfo.BidQuantity1 or 0
			local bidQty2 = priceInfo.BidQuantity2 or 0
			local bidQty3 = priceInfo.BidQuantity3 or 0
			local bidQty4 = priceInfo.BidQuantity4 or 0
			local bidQty5 = priceInfo.BidQuantity5 or 0
			local bidQty6 = priceInfo.BidQuantity6 or 0
			local bidQty7 = priceInfo.BidQuantity7 or 0
			local bidQty8 = priceInfo.BidQuantity8 or 0
			local bidQty9 = priceInfo.BidQuantity9 or 0
			local bidQty10 = priceInfo.BidQuantity10 or 0
			if BuySell == "Buy" then
				qty = bidQty1+bidQty2+bidQty3+bidQty4+bidQty5+bidQty6+bidQty7+bidQty8+bidQty9+bidQty10
			else
				qty = askQty1+askQty2+askQty3+askQty4+askQty5+askQty6+askQty7+askQty8+askQty9+askQty10
			end
		elseif mode == "卖10价" then
			qty =  priceInfo.AskQuantity10 or 0
		elseif mode == "卖9价" then
			qty =  priceInfo.AskQuantity9 or 0
		elseif mode == "卖8价" then
			qty =  priceInfo.AskQuantity8 or 0
		elseif mode == "卖7价" then
			qty =  priceInfo.AskQuantity7 or 0
		elseif mode == "卖6价" then
			qty =  priceInfo.AskQuantity6 or 0
		elseif mode == "卖5价" then
			qty =  priceInfo.AskQuantity5 or 0
		elseif mode == "卖4价" then
			qty =  priceInfo.AskQuantity4 or 0
		elseif mode == "卖3价" then
			qty =  priceInfo.AskQuantity3 or 0
		elseif mode == "卖2价" then
			qty =  priceInfo.AskQuantity2 or 0
		elseif mode == "卖1价" then
			qty =  priceInfo.AskQuantity1 or 0
		elseif mode == "最新价" then
			qty =  priceInfo.LastQuantity or 0
		elseif mode == "买1价" then
			qty =  priceInfo.BidQuantity1 or 0
		elseif mode == "买2价" then
			qty =  priceInfo.BidQuantity2 or 0
		elseif mode == "买3价" then
			qty =  priceInfo.BidQuantity3 or 0
		elseif mode == "买4价" then
			qty =  priceInfo.BidQuantity4 or 0
		elseif mode == "买5价" then
			qty =  priceInfo.BidQuantity5 or 0
		elseif mode == "买6价" then
			qty =  priceInfo.BidQuantity6 or 0
		elseif mode == "买7价" then
			qty =  priceInfo.BidQuantity7 or 0
		elseif mode == "买8价" then
			qty =  priceInfo.BidQuantity8 or 0
		elseif mode == "买9价" then
			qty =  priceInfo.BidQuantity9 or 0
		elseif mode == "买10价" then
			qty =  priceInfo.BidQuantity10 or 0
		end
	end
	return qty
end
function stateJudge(issueCode)									--股票状态判断
	if not _PosPriceTable[issueCode] then
		_WriteAplLog(issueCode);
		return "未知"
	else
		local askQty1 = _PosPriceTable[issueCode].AskQuantity1;
		local askQty2 = _PosPriceTable[issueCode].AskQuantity2;
		local askQty3 = _PosPriceTable[issueCode].AskQuantity3;
		local askQty4 = _PosPriceTable[issueCode].AskQuantity4;
		local askQty5 = _PosPriceTable[issueCode].AskQuantity5;
		local bidQty1 = _PosPriceTable[issueCode].BidQuantity1;
		local bidQty2 = _PosPriceTable[issueCode].BidQuantity2;
		local bidQty3 = _PosPriceTable[issueCode].BidQuantity3;
		local bidQty4 = _PosPriceTable[issueCode].BidQuantity4;
		local bidQty5 = _PosPriceTable[issueCode].BidQuantity5;

		if (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
			local logs = sys_format("issueCode:%s SP stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteAplLog(logs);
			return "停牌";	--SusPend 停牌
		elseif (askQty1 > 0 or askQty2 > 0 or askQty3 > 0 or askQty4 > 0 or askQty5 > 0) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
			local logs = sys_format("issueCode:%s DL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteErrorLog(logs);
			return "跌停";	--Decline Limit 跌停
		elseif (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 > 0 or bidQty2 > 0 or bidQty3 > 0 or bidQty4 > 0 or bidQty5 > 0) then
			local logs = sys_format("issueCode:%s SL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",issueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteErrorLog(logs);
			return "涨停";	--Surged Limit 涨停
		else
			return "正常";	--NorMal 正常
		end
	end
end
function GetOrderPrice(issueCode,oc,quantity,price,Tick)		--获取当前合约行情
	--local log = sys_format("GetOrderPrice:issueCode=%s,oc=%s,quantity=%s,price=%s,Tick=%s",issueCode,oc,quantity,price,Tick)
	--_WriteErrorLog(log)
	local OpenPrice = 0
	local Auto = {}
	local priceInfo = _PosPriceTable[issueCode]
	if priceInfo then
		if price == "自动盘口" then
			OpenPrice = getMarketPrice(issueCode,oc,quantity,1)
		elseif price == "卖10价" then
			OpenPrice =  priceInfo.AskPrice10 or 0
		elseif price == "卖9价" then
			OpenPrice =  priceInfo.AskPrice9 or 0
		elseif price == "卖8价" then
			OpenPrice =  priceInfo.AskPrice8 or 0
		elseif price == "卖7价" then
			OpenPrice =  priceInfo.AskPrice7 or 0
		elseif price == "卖6价" then
			OpenPrice =  priceInfo.AskPrice6 or 0
		elseif price == "卖5价" then
			OpenPrice =  priceInfo.AskPrice5 or 0
		elseif price == "卖4价" then
			OpenPrice =  priceInfo.AskPrice4 or 0
		elseif price == "卖3价" then
			OpenPrice =  priceInfo.AskPrice3 or 0
		elseif price == "卖2价" then
			OpenPrice =  priceInfo.AskPrice2 or 0
		elseif price == "卖1价" then
			OpenPrice =  priceInfo.AskPrice1 or 0
		elseif price == "最新价" then
			OpenPrice =  priceInfo.LastPrice or 0
		elseif price == "买1价" then
			OpenPrice =  priceInfo.BidPrice1 or 0
		elseif price == "买2价" then
			OpenPrice =  priceInfo.BidPrice2 or 0
		elseif price == "买3价" then
			OpenPrice =  priceInfo.BidPrice3 or 0
		elseif price == "买4价" then
			OpenPrice =  priceInfo.BidPrice4 or 0
		elseif price == "买5价" then
			OpenPrice =  priceInfo.BidPrice5 or 0
		elseif price == "买6价" then
			OpenPrice =  priceInfo.BidPrice6 or 0
		elseif price == "买7价" then
			OpenPrice =  priceInfo.BidPrice7 or 0
		elseif price == "买8价" then
			OpenPrice =  priceInfo.BidPrice8 or 0
		elseif price == "买9价" then
			OpenPrice =  priceInfo.BidPrice9 or 0
		elseif price == "买10价" then
			OpenPrice =  priceInfo.BidPrice10 or 0
		elseif price == "AdjustedLNC" then
			OpenPrice = priceInfo.AdjustedLNC or 0
		elseif price == "涨停价" then
			OpenPrice = priceInfo.UpLimitPrice or 0
		elseif price == "跌停价" then
			OpenPrice = priceInfo.LowLimitPrice or 0
			--WriteAplLog()
		end
	else
		local issueMarket = _PosIssueMarketTable[issueCode]
		if issueMarket then
			_RegisterPrice(_IssueCode=issueCode,_MarketCode=issueMarket)
		end
		return 0
	end

	local tick = _PosIssuePriceTickTable[issueCode]
	if Tick == "不浮动" then
		OpenPrice = OpenPrice + 0
	elseif Tick == "上浮20单位" then
		OpenPrice = OpenPrice + 20*tick
	elseif Tick == "上浮10单位" then
		OpenPrice = OpenPrice + 10*tick
	elseif Tick == "上浮5单位" then
		OpenPrice = OpenPrice + 5*tick
	elseif Tick == "上浮4单位" then
		OpenPrice = OpenPrice + 4*tick
	elseif Tick == "上浮3单位" then
		OpenPrice = OpenPrice + 3*tick
	elseif Tick == "上浮2单位" then
		OpenPrice = OpenPrice + 2*tick
	elseif Tick == "上浮1单位" then
		OpenPrice = OpenPrice + 1*tick
	elseif Tick == "下浮1单位" then
		OpenPrice = OpenPrice - 1*tick
	elseif Tick == "下浮2单位" then
		OpenPrice = OpenPrice - 2*tick
	elseif Tick == "下浮3单位" then
		OpenPrice = OpenPrice - 3*tick
	elseif Tick == "下浮4单位" then
		OpenPrice = OpenPrice - 4*tick
	elseif Tick == "下浮5单位" then
		OpenPrice = OpenPrice - 5*tick
	elseif Tick == "下浮10单位" then
		OpenPrice = OpenPrice - 10*tick
	elseif Tick == "下浮20单位" then
		OpenPrice = OpenPrice - 20*tick
	else
		--WriteAplLog()
	end

	return OpenPrice
end

function getMarketPrice(IssueCode,OC,Quantity,Confidence)		--返回自动盘口价格和数量
	local marketPrice = 0
 	local priceInfo = _PosPriceTable[IssueCode]
 	if priceInfo then
  		local askPrice1 = priceInfo.AskPrice1 or 0
	  	local askPrice2 = priceInfo.AskPrice2 or 0
	 	local askPrice3 = priceInfo.AskPrice3 or 0
	 	local askPrice4 = priceInfo.AskPrice4 or 0
	 	local askPrice5 = priceInfo.AskPrice5 or 0
		local askPrice6 = priceInfo.AskPrice6 or 0
	  	local askPrice7 = priceInfo.AskPrice7 or 0
	 	local askPrice8 = priceInfo.AskPrice8 or 0
	 	local askPrice9 = priceInfo.AskPrice9 or 0
	 	local askPrice10 = priceInfo.AskPrice10 or 0
	    local bidPrice1 = priceInfo.BidPrice1 or 0
	    local bidPrice2 = priceInfo.BidPrice2 or 0
	    local bidPrice3 = priceInfo.BidPrice3 or 0
	    local bidPrice4 = priceInfo.BidPrice4 or 0
	    local bidPrice5 = priceInfo.BidPrice5 or 0
		local bidPrice6 = priceInfo.BidPrice6 or 0
	    local bidPrice7 = priceInfo.BidPrice7 or 0
	    local bidPrice8 = priceInfo.BidPrice8 or 0
	    local bidPrice9 = priceInfo.BidPrice9 or 0
	    local bidPrice10 = priceInfo.BidPrice10 or 0
	    local askQty1 = priceInfo.AskQuantity1 or 0
	    local askQty2 = priceInfo.AskQuantity2 or 0
	    local askQty3 = priceInfo.AskQuantity3 or 0
	    local askQty4 = priceInfo.AskQuantity4 or 0
	    local askQty5 = priceInfo.AskQuantity5 or 0
		local askQty6 = priceInfo.AskQuantity6 or 0
	    local askQty7 = priceInfo.AskQuantity7 or 0
	    local askQty8 = priceInfo.AskQuantity8 or 0
	    local askQty9 = priceInfo.AskQuantity9 or 0
	    local askQty10 = priceInfo.AskQuantity10 or 0
	    local bidQty1 = priceInfo.BidQuantity1 or 0
	    local bidQty2 = priceInfo.BidQuantity2 or 0
	    local bidQty3 = priceInfo.BidQuantity3 or 0
	    local bidQty4 = priceInfo.BidQuantity4 or 0
        local bidQty5 = priceInfo.BidQuantity5 or 0
		local bidQty6 = priceInfo.BidQuantity6 or 0
	    local bidQty7 = priceInfo.BidQuantity7 or 0
	    local bidQty8 = priceInfo.BidQuantity8 or 0
	    local bidQty9 = priceInfo.BidQuantity9 or 0
        local bidQty10 = priceInfo.BidQuantity10 or 0

	    if OC == 0 then
			Quantity = Quantity.getNumberValue()
	  		local Quantity1 = Quantity - askQty1*Confidence  --除去卖1量以后还需要交易的数量
	   		local Quantity2 = Quantity1 - askQty2*Confidence --除去卖2量以后还需要交易的数量
	  		local Quantity3 = Quantity2 - askQty3*Confidence --除去卖3量以后还需要交易的数量
	  		local Quantity4 = Quantity3 - askQty4*Confidence --除去卖4量以后还需要交易的数量
	 		local Quantity5 = Quantity4 - askQty5*Confidence
			local Quantity6 = Quantity5 - askQty6*Confidence
			local Quantity7 = Quantity6 - askQty7*Confidence
			local Quantity8 = Quantity7 - askQty8*Confidence
			local Quantity9 = Quantity8 - askQty9*Confidence
			local Quantity10 = Quantity9 - askQty10*Confidence
	  	        if Quantity1 <= 0 then   --卖1量足够
	   			    marketPrice = askPrice1
	            elseif Quantity2 <= 0 then  --卖2量足够
	   			    marketPrice = askPrice2
	   			elseif Quantity3 <= 0 then  --卖3量足够
	    			marketPrice = askPrice3
	  		    elseif Quantity4 <= 0 then  --卖4量足够
	   				marketPrice = askPrice4
	            elseif Quantity5 <= 0 then --卖5量
	   			    marketPrice = askPrice5
				elseif Quantity6 <= 0 then
	   			    marketPrice = askPrice6
				elseif Quantity7 <= 0 then
	   			    marketPrice = askPrice7
				elseif Quantity8 <= 0 then
	   			    marketPrice = askPrice8
				elseif Quantity9 <= 0 then
	   			    marketPrice = askPrice9
				else
	   			    marketPrice = askPrice10
	   			end
	    else
	   		local Quantity1 = Quantity - bidQty1*Confidence  --除去买1量以后还需要交易的数量
	   	    local Quantity2 = Quantity1 - bidQty2*Confidence --除去买2量以后还需要交易的数量
	        local Quantity3 = Quantity2 - bidQty3*Confidence --除去买3量以后还需要交易的数量
	        local Quantity4 = Quantity3 - bidQty4*Confidence --除去买4量以后还需要交易的数量
			local Quantity5 = Quantity4 - bidQty5*Confidence
			local Quantity6 = Quantity5 - bidQty6*Confidence
			local Quantity7 = Quantity6 - bidQty7*Confidence
			local Quantity8 = Quantity7 - bidQty8*Confidence
			local Quantity9 = Quantity8 - bidQty9*Confidence
			local Quantity10 = Quantity9 - bidQty10*Confidence
			if Quantity1 <= 0 then   --买1量足够
				marketPrice = bidPrice1
			elseif Quantity2 <= 0 then  --买2量足够
				marketPrice = bidPrice2
			elseif Quantity3 <= 0 then  --买3量足够
				marketPrice = bidPrice3
			elseif Quantity4 <= 0 then  --买4量足够
				marketPrice = bidPrice4
			elseif Quantity5 <= 0 then --买5量以上
				marketPrice = bidPrice5
			elseif Quantity6 <= 0 then
				marketPrice = bidPrice6
			elseif Quantity7 <= 0 then
				marketPrice = bidPrice7
			elseif Quantity8 <= 0 then
				marketPrice = bidPrice8
			elseif Quantity9 <= 0 then
				marketPrice = bidPrice9
			else
				marketPrice = bidPrice10
   	        end
        end
    end

	return marketPrice
end

function RefreshArbitragePosition()								--刷新套利持仓
	gtArbitragePositionTable = {}
	_WriteAplLog("RefreshArbitragePosition")
	local marginAccountCode = nil
	if _PosBAMapAccount[gMarginbaMapID] then
		marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
	end
	local futureAccountCode = nil
	if _PosBAMapAccount[gFuturebaMapID] then
		futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	end
	if marginAccountCode and futureAccountCode then
		if _PosFundStatus[marginAccountCode] and _PosFundStatus[futureAccountCode] then
			local marginInvestorID = _PosFundStatus[marginAccountCode].InvestorID
			local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
			if marginInvestorID and futureInvestorID then
				for key, pos in pairs(_PosPositionTable) do
					local bAMapID = pos.BAMapID
					local accountCode = _PosBAMapAccount[bAMapID]
					if _PosFundStatus[accountCode] and accountCode then
						local investorID = _PosFundStatus[accountCode].InvestorID
						if gtInvestorIDMap[investorID] then
							if gtInvestorIDMap[investorID] == bAMapID then
								RefreshOneArbitragePosition(pos,investorID)
							end
						end
					end
				end
			end
		end
	end
	showArbitragePosition()		--刷新显示当前组合套利持仓
end
function RefreshArbitrageSinglePos(portID)						--刷新当前套利持仓
	gtArbitragePositionTable[portID] = {}
	local marginAccountCode = nil
	if _PosBAMapAccount[gMarginbaMapID] then
		marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
	end
	local futureAccountCode = nil
	if _PosBAMapAccount[gFuturebaMapID] then
		futureAccountCode = _PosBAMapAccount[gFuturebaMapID]
	end
	if marginAccountCode and futureAccountCode then
		if _PosFundStatus[marginAccountCode] and _PosFundStatus[futureAccountCode] then
			local marginInvestorID = _PosFundStatus[marginAccountCode].InvestorID
			local futureInvestorID = _PosFundStatus[futureAccountCode].InvestorID
			if marginInvestorID and futureInvestorID then
				for key, pos in pairs(_PosPositionTable) do
					local baSubID = pos.BASubID
					local combinCode = sys_sub(baSubID,2,-1)
					if combinCode == portID then
						local bAMapID = pos.BAMapID
						local accountCode = _PosBAMapAccount[bAMapID]
						if _PosFundStatus[accountCode] and accountCode then
							local investorID = _PosFundStatus[accountCode].InvestorID
							if gtInvestorIDMap[investorID] then
								if gtInvestorIDMap[investorID] == bAMapID then
									RefreshOneArbitragePosition(pos,investorID)
								end
							end
						end
					end
				end
			end
		end
	end
	showArbitragePosition()		--刷新显示当前组合套利持仓
end
function RefreshOneArbitragePosition(pos,investorID)			--逐个保存套利组合持仓数据
	local issueCode = pos.IssueCode
	local issueName = _PosIssueNameTable[issueCode]
	local quantity = pos.Quantity or 0
	local avlQty = pos.AvlQuantity
	local amount = pos.Amount or 0
	local costPrice = 0
	local MarketCode = _PosIssueMarketTable[issueCode]
	if MarketCode and quantity ~= 0 then
		if MarketCode == "1" or MarketCode == "2" then
			costPrice = amount / quantity
		elseif MarketCode == "3" then
			costPrice = amount / quantity / 300
		end
	end
	local baMapID = pos.BAMapID
	local baSubID = pos.BASubID
	local longShort = sys_sub(baSubID,1,1)
	local combinCode = sys_sub(baSubID,2,-1)
	local longShortStr = ""
	local openClose = ""

	local openExecList = pos.OpenExecList
	for i,order in pairs(openExecList) do
		openClose = order.OpenClose
		break
	end
	if longShort == "1" then
		longShortStr = "卖"
		if openClose == 4 then
			longShortStr = "融券卖出"
		elseif openClose == 5 then
			longShortStr = "卖券还款"
		elseif openClose == 7 then
			longShortStr = "现金还款"
		end
	elseif longShort == "3" then
		longShortStr = "买"
		if openClose == 4 then
			longShortStr = "融资买入"
		elseif openClose == 5 then
			longShortStr = "买券还券"
		elseif openClose == 7 then
			longShortStr = "现金还款"
		elseif openClose == 8 then
			longShortStr = "现金还券"
		end
	end

	local rose = 0
	local lastPrice = 0
	local priceInfo = _PosPriceTable[issueCode]
	if priceInfo and costPrice > 0 then
		lastPrice = priceInfo.LastPrice or 0
		if lastPrice ~= 0 then
			rose = (lastPrice - costPrice) / costPrice
		end
	end
	local valuationPL = pos.ValuationPL or 0
	local key = investorID .. issueCode .. longShort

	gtArbitragePositionTable[combinCode] = gtArbitragePositionTable[combinCode] or {}
	gtArbitragePositionTable[combinCode][key] = gtArbitragePositionTable[combinCode][key] or {}
	gtArbitragePositionTable[combinCode][key].IssueName = issueName
	gtArbitragePositionTable[combinCode][key].IssueCode = issueCode
	gtArbitragePositionTable[combinCode][key].Quantity = quantity
	gtArbitragePositionTable[combinCode][key].AvlQty = avlQty
	gtArbitragePositionTable[combinCode][key].CostPrice = costPrice
	gtArbitragePositionTable[combinCode][key].Rose = rose
	gtArbitragePositionTable[combinCode][key].LastPrice = lastPrice
	gtArbitragePositionTable[combinCode][key].BuySell = longShortStr
	gtArbitragePositionTable[combinCode][key].Amount = amount
	gtArbitragePositionTable[combinCode][key].ValuationPL = valuationPL
	gtArbitragePositionTable[combinCode][key].CombinCode = combinCode
	gtArbitragePositionTable[combinCode][key].BAMapID = baMapID
	--gtArbitragePositionTable[combinCode][key].AverageCost = averageCost
	--gtArbitragePositionTable[combinCode][key].Future = future
	gtArbitragePositionTable[combinCode][key].InvestorID = investorID
	gtArbitragePositionTable[combinCode][key].LongShort = longShort
	---组合显示统计需要的数据
	gtArbitragePositionTable[combinCode][key].CumulationPL = pos.CumulationPL
	gtArbitragePositionTable[combinCode][key].CumulationDividend = pos.CumulationDividend
	--gtArbitragePositionTable[combinCode][key].CumulationFare = pos.CumulationFare
	--gtArbitragePositionTable[combinCode][key].Fare = pos.Fare
	--gtArbitragePositionTable[combinCode][key].RealizedPL = pos.RealizedPL
end

function showArbitragePosition()								--发送当前组合套利持仓到界面
	--_WriteAplLog("showArbitragePosition")

	if gtArbitragePositionTable[gPortID] then
		for key,info in pairs(gtArbitragePositionTable[gPortID]) do

			local issueCode = info.IssueCode or "-"
			local issueName = info.IssueName or "-"
			local quantity = info.Quantity or 0
			local avlQty = info.AvlQty or 0
			local costPrice = info.CostPrice or 0
			local rose = info.Rose or 0
			local lastPrice = info.LastPrice or 0
			local buySell = info.BuySell or "-"
			local combinCode = info.CombinCode or 0
			local baMapID = info.BAMapID or 0
			local valuationPL = info.ValuationPL or 0
			local investorID = info.InvestorID  or "-"
			local longShort = info.LongShort
			local MarketCode = _PosIssueMarketTable[issueCode]

			local statusflag = "1"
			local posAvlQty = 0	--柜台持仓可用
			if quantity == 0 then
				statusflag = "0"
			end
			--增加显示柜台持仓可用
			local tempkey = ""
			local contractType = "" --融资融券标志
			if MarketCode == "1" or MarketCode == "2" then
				if longShort == "1" then
					contractType = "1"	--融券
				elseif longShort == "3" then
					contractType = "0"	--融资
				end
				tempkey = issueCode.."."..contractType
				if gtQryMarginPosition[investorID] then
					if gtQryMarginPosition[investorID][tempkey] then
						local contract_qty = gtQryMarginPosition[investorID][tempkey].contract_qty or 0
						local close_qty = gtQryMarginPosition[investorID][tempkey].close_qty or 0
						local today_close_qty = gtQryMarginPosition[investorID][tempkey].today_close_qty or 0
						posAvlQty = contract_qty - close_qty - today_close_qty
					end
				end
			else
				tempkey = issueCode .. "." .. longShort .. "." .. gHedgeFlag
				if gtPositionTable[investorID] then
					if gtPositionTable[investorID][tempkey] then
						posAvlQty = gtPositionTable[investorID][tempkey].AvQty or 0
					end
				end
			end
			rose = sys_format("%.02f",rose * 100)
			costPrice = sys_format("%.02f",costPrice)
			lastPrice = sys_format("%.02f",lastPrice)
			valuationPL = sys_format("%.02f",valuationPL)

			quantity = sys_format("%.0f",quantity)
			avlQty = sys_format("%.0f",avlQty)
			posAvlQty = sys_format("%.0f",posAvlQty)
			if MarketCode == "1" or MarketCode == "2" then
				local DTSEvent Arbitrage = _CreateEventObject("VArbitragePositionInfo")
				Arbitrage._SetFld("CombinCode",combinCode)
				Arbitrage._SetFld("BAMapID",baMapID)
				Arbitrage._SetFld("IssueCode",issueCode)
				Arbitrage._SetFld("IssueName",issueName)
				Arbitrage._SetFld("ArbitrageQty",quantity)
				Arbitrage._SetFld("AvlQty",avlQty)
				Arbitrage._SetFld("CostPrice",costPrice)
				Arbitrage._SetFld("Rose",rose)
				Arbitrage._SetFld("BuySell",buySell)
				Arbitrage._SetFld("ValuationPL",valuationPL)
				Arbitrage._SetFld("LastPrice",lastPrice)
				Arbitrage._SetFld("InvestorID",investorID)
				Arbitrage._SetFld("PosAvlQty",posAvlQty)
				Arbitrage._SetFld("StatusFlag",statusflag)
				_SendToClients(Arbitrage)
			elseif MarketCode == "3" then
				local DTSEvent Arbitrage = _CreateEventObject("VFutureArbitragePosInfo")
				Arbitrage._SetFld("CombinCode",combinCode)
				Arbitrage._SetFld("BAMapID",baMapID)
				Arbitrage._SetFld("IssueCode",issueCode)
				Arbitrage._SetFld("Position",quantity)
				Arbitrage._SetFld("AvlQty",avlQty)
				Arbitrage._SetFld("AverageCost",costPrice)
				Arbitrage._SetFld("Rose",rose)
				Arbitrage._SetFld("BuySell",buySell)
				Arbitrage._SetFld("ValuationPL",valuationPL)
				Arbitrage._SetFld("LastPrice",lastPrice)
				Arbitrage._SetFld("InvestorID",investorID)
				Arbitrage._SetFld("PosAvlQty",posAvlQty)
				Arbitrage._SetFld("StatusFlag",statusflag)
				_SendToClients(Arbitrage)
			end
		end
	end
end

function SendStockOrder(portID)									--刷新委托表
	if gtOrderList[portID] then
		for StockFuture,tableInfo in pairs(gtOrderList[portID]) do
			if StockFuture == "StockOpen" or StockFuture == "StockClose" then
				for corpCode,info in pairs(tableInfo) do
					SendStockOpenOrderEvent(portID,corpCode,info)
					status = info.Status
					if status == "全部成交" or status =="部成部撤" or status == "部分成交" then
						SendStockOpenExecuteEvent(portID,corpCode,info)
					end
				end
			elseif StockFuture == "FutureOpen" or StockFuture == "FutureClose" then
				for corpCode,info in pairs(tableInfo) do
					SendFutureOpenOrderEvent(portID,corpCode,info)
					status = info.Status
					if status == "全部成交" or status =="部成部撤" or status == "部分成交" then
						SendFutureOpenExecuteEvent(portID,corpCode,info)
					end
				end
			end
		end
	end
end

function SendStockOpenOrderEvent(portID,corpCode,info)			--刷新股票委托表
	local execNo = info.ExecNo or "-"
	local execTime = info.ExecTime or "-"
	local issueCode = info.IssueCode or "-"
	local issueName = info.IssueName or "-"
	local market = info.Market or "-"
	local status = info.Status or "-"
	local buySell = info.BuySell or "-"
	local orderPrice = info.EntrustPrice or "-"
	local orderQuantity = info.EntrustQty or ""
	local executionQuantity = info.DealQty or "-"
	local execPrice = info.ExecPrice or "-"
	local cancelQuantity = info.CancellationQty or "-"
	local orderTime = info.Time or "-"
	local strDate = info.Date or "-"
	local shareholderCode = info.ShareholderCode or "-"
	local orderAcceptNo = info.OrderAcceptNo or "-"
	local statusFlag = info.StatusFlag or "-"
	local workingQuantity = info.WorkingQuantity or "-"
	local investorID = info.InvestorID or "-"
	local flag = info.Flag or "-"
	if flag ~= "初始化内部成交" then
		local DTSEvent ord = _CreateEventObject("VStockOrderEvent")
		ord._SetFld("PortID", portID)								--组合号
		ord._SetFld("CorpCode", corpCode)							--委托号
		ord._SetFld("IssueCode", issueCode)							--合约
		ord._SetFld("IssueName", issueName)							--合约名称
		ord._SetFld("Market", market)								--市场
		ord._SetFld("Other", status)								--委托状态
		ord._SetFld("BuySell", buySell)  							--买卖
		ord._SetFld("EntrustPrice", orderPrice)     				--委托价格
		ord._SetFld("EntrustQty", orderQuantity)					--委托手数
		ord._SetFld("DealQty", executionQuantity)					--成交手数
		ord._SetFld("AveragePrice", execPrice)						--成交均价
		ord._SetFld("CancellationQty", cancelQuantity)				--撤单数量
		ord._SetFld("WorkingQty", workingQuantity)					--挂单数量
		ord._SetFld("Time", orderTime)         						--交易时间
		ord._SetFld("OrderAcceptNo", orderAcceptNo)         		--柜台号
		ord._SetFld("StatusFlag", statusFlag)						--1：不可撤委托/2：可撤委托
		ord._SetFld("InvestorID", investorID)						--资金账号
		ord._SetFld("Flag", flag)									--备注
		_SendToClients(ord);
	end
end
function SendStockOpenExecuteEvent(portID,corpCode,info)		--刷新股票成交表
	local execNo = info.ExecNo or "-"
	local execTime = info.ExecTime or "-"
	local issueCode = info.IssueCode or "-"
	local issueName = info.IssueName or "-"
	local market = info.Market or "-"
	local buySell = info.BuySell or "-"
	local entrustQty = info.EntrustQty or "-"
	local entrustPrice = info.EntrustPrice or "-"
	local dealQty = info.DealQty or "-"
	local execPrice = info.ExecPrice or "-"
	local cancellationQty = info.CancellationQty or "-"
	local status = info.Status or "-"
	local orderAcceptNo = info.OrderAcceptNo or "-"
	local shareholderCode = info.ShareholderCode or "-"
	local workingQuantity = info.WorkingQuantity or "-"
	local investorID = info.InvestorID or "-"
	local flag = info.Flag or "-"
	if flag ~= "初始化内部成交" then
		local DTSEvent exec = _CreateEventObject("VStockExecuteEvent")
		exec._SetFld("CorpCode", corpCode);
		exec._SetFld("PortID", portID);
		exec._SetFld("ExecNo", execNo);
		exec._SetFld("Date", execTime)
		exec._SetFld("IssueCode", issueCode);
		exec._SetFld("IssueName", issueName);
		exec._SetFld("BuySell", buySell)
		exec._SetFld("EntrustQty", entrustQty);
		exec._SetFld("EntrustPrice", entrustPrice);
		exec._SetFld("DealQty", dealQty);
		exec._SetFld("AveragePrice", execPrice);
		exec._SetFld("CancellationQty", cancellationQty);
		exec._SetFld("Explain", status);
		exec._SetFld("WorkingQty", workingQuantity);
		exec._SetFld("OrderAcceptNo", orderAcceptNo)
		exec._SetFld("InvestorID", investorID)
		_SendToClients(exec)
	end
end
function SendFutureOpenOrderEvent(portID,corpCode,info)			--刷新期货委托表
	local issueCode = info.IssueCode or "-"
	local status = info.Status or "-"
	local buySell = info.BuySell or "-"
	local entrustPrice = info.EntrustPrice or "-"
	local entrustQty = info.EntrustQty or ""
	local dealQty = info.DealQty or "-"
	local cancelQuantity = info.CancellationQty or "-"
	local orderTime = info.Time or "-"
	local orderAcceptNo = info.OrderAcceptNo or "-"
	local statusFlag = info.StatusFlag or "-"
	local workingQuantity = info.WorkingQuantity or "-"
	local openClose = info.OpenClose or "-"
	local execPrice = info.ExecPrice or "-"
	local investorID = info.InvestorID or "-"
	local hedgeFlag = info.HedgeFlag or "-"
	if hedgeFlag == "0" then
		hedgeFlag = "投机"
	elseif hedgeFlag == "1" then
		hedgeFlag = "套保"
	elseif hedgeFlag == "2" then
		hedgeFlag = "套利"
	end
	local flag = info.Flag or "-"
	if flag ~= "初始化内部成交" then
		local DTSEvent ord = _CreateEventObject("VFutureOrderEvent")
		ord._SetFld("PortID", portID)
		ord._SetFld("CorpCode", corpCode)
		ord._SetFld("IssueCode", issueCode)
		ord._SetFld("BuySell", buySell)
		ord._SetFld("OpenClose", openClose)
		ord._SetFld("EntrustPrice", entrustPrice)
		ord._SetFld("EntrustQty", entrustQty)
		ord._SetFld("Status", status)
		ord._SetFld("DealPrice", execPrice)
		ord._SetFld("DealQty", dealQty)
		ord._SetFld("CancellationQty", cancelQuantity)
		ord._SetFld("WorkingQty", workingQuantity)
		ord._SetFld("BatchNumber", orderAcceptNo)
		ord._SetFld("Date", orderTime)
		ord._SetFld("StatusFlag", statusFlag)
		ord._SetFld("InvestorID", investorID)
		ord._SetFld("HedgeFlag", hedgeFlag)
		ord._SetFld("Flag", flag)						--备注
		_SendToClients(ord);
	end
end
function SendFutureOpenExecuteEvent(portID,corpCode,info)		--刷新期货成交表
	local execNo = info.ExecNo or "-"
	local execTime = info.ExecTime or "-"
	local issueCode = info.IssueCode or "-"
	local buySell = info.BuySell or "-"
	local dealQty = info.DealQty or "-"
	local cancellationQty = info.CancellationQty or "-"
	local status = info.Status or "-"
	local orderAcceptNo = info.OrderAcceptNo or "-"
	local openClose = info.OpenClose or "-"
	local execPrice = info.ExecPrice
	local investorID = info.InvestorID or "-"
	local hedgeFlag = info.HedgeFlag or "-"
	if hedgeFlag == "0" then
		hedgeFlag = "投机"
	elseif hedgeFlag == "1" then
		hedgeFlag = "套保"
	elseif hedgeFlag == "2" then
		hedgeFlag = "套利"
	end
	local flag = info.Flag or "-"
	if flag ~= "初始化内部成交" then
		local DTSEvent exec = _CreateEventObject("VFutureExecuteEvent")
		exec._SetFld("PortID", portID);
		exec._SetFld("CorpCode", corpCode);
		exec._SetFld("ExecNo", execNo);
		exec._SetFld("Date", execTime)
		exec._SetFld("IssueCode", issueCode);
		exec._SetFld("BuySell", buySell)
		exec._SetFld("OpenClose", openClose)
		exec._SetFld("DealQty", dealQty);
		exec._SetFld("DealPrice", execPrice);
		exec._SetFld("CancellationQty", cancellationQty);
		exec._SetFld("Status", status);
		exec._SetFld("OrderAcceptNo", orderAcceptNo)
		exec._SetFld("InvestorID", investorID)
		exec._SetFld("HedgeFlag", hedgeFlag)
		_SendToClients(exec)
	end
end

function RefreshArbitrageInfo(portID)							--刷新套利组合统计数据(原先统计指标计算函数)
	local info = gtCombinList[portID]
	local staticInfo = CreateArbitrageInfo(portID, false)
	if info and staticInfo then

	    local StockNum = info.StockNum --现货份数
	    local Future = info.Future--期货
		local FutureNum = info.FutureNum--期货份数
        local Status = info.StockStatus
		local futureBuy  = info.FutureBuy							--期货买入取价方式
	    local futureSell = info.FutureSell
		local futureBuyTick  = info.FutureBuyTick						--期货tick
		local futureSellTick  = info.FutureSellTick

		staticInfo.StockNum  = StockNum
		staticInfo.FutureNum = FutureNum
		staticInfo.CombinName = info.CombinName
		--现货
		local BuyAmount = 0							--买入金额
		local SellAmount = 0							--卖出金额
		local SpotBuyChargeCost = 0					--买入冲击成本
		local SpotSellChargeCost = 0					--卖出冲击成本
		local SpotVarieties = info.InventoryNum						--品种数
		local SpotTradeFee = 0						--交易费用

		--
		local LastSellAmount = 0 					--现价建仓市值

		local StockSell = "-"
		local StockSellTick = "-"
		local StockBuy = "-"
		local StockBuyTick = "-"
		local OrderBuyQty = 0
		--期货
		local OpenPrice = "-"						--建仓均价
		local FutureBuyChargeCost = "-"				--建仓冲击成本
		local FutureSellChargeCost = "-"				--建仓冲击成本
		local FutureTradeFee = "-"					--交易费用
		local ContractsNum = "-"					--平仓合约数
		local Price = "-"							--当前价格

		--套利
		local Exposure = "-"						--建仓敞口
		local EstimatedCost = "-"					--预估费用


		local marginAccountCode = _PosBAMapAccount[gMarginbaMapID]
	    local futureAccountCode = _PosBAMapAccount[gFuturebaMapID]

		local order = {}
		order.BS = "3"
		order.OpenClose = 0
		order.CreRed = 0
		order.Price = 0
		order.Quantity = 0
		order.IsInternal = 0

		if info.StockStatus ==  "新建" or  info.FutureStatus ==  "新建" then
		   Status = "新建"
		end
		if info.StockStatus ==  "自动建仓" or  info.FutureStatus ==  "自动建仓" then
		   Status = "自动建仓"
		end

		if (Status == "新建"   or Status == "自动建仓") and  marginAccountCode and futureAccountCode then
			if info.StockStatus ==  "新建" or info.StockStatus ==  "自动建仓" then
				for issue,value in pairs(gtCombinList[portID].List) do
					StockSell = value.StockSell
					StockSellTick = value.StockSellTick
					StockBuy = value.StockBuy
					StockBuyTick = value.StockBuyTick
					OrderSellQty = value.OrderSellQty or 0
					local ExecQuantity = value.ExecQuantity or 0
					local orderPrice = GetOrderPrice(issue,0,OrderSellQty,StockSell,StockSellTick)	--委托卖出价格
					SellAmount = SellAmount + orderPrice * OrderSellQty
					local LastPrice = GetOrderPrice(issue,0,0,"最新价","不浮动")
					LastSellAmount = LastSellAmount + LastPrice * OrderSellQty
					order.Price = orderPrice
					order.Quantity = OrderSellQty
					SpotTradeFee = SpotTradeFee + PosEstimateFare(marginAccountCode, issue, order)
				end
				SpotSellChargeCost = LastSellAmount - SellAmount

				staticInfo.SellAmount = SellAmount
				staticInfo.SpotSellChargeCost = SpotSellChargeCost
				staticInfo.SpotTradeFee = SpotTradeFee
			else
				SpotTradeFee = staticInfo.SpotTradeFee
				SellAmount = staticInfo.SellAmount
			end
			if info.FutureStatus ==  "新建" or info.FutureStatus ==  "自动建仓" then
				--期货
				local futureOrderPrice =  GetOrderPrice(Future,0,FutureNum,futureBuy,futureBuyTick)
				Price = GetOrderPrice(Future,0,0,"最新价","不浮动")
				local size = _PosIssueContractSizeTable[Future]
				OpenPrice = futureOrderPrice
				FutureBuyChargeCost =(futureOrderPrice-Price)*FutureNum*size
				order.BS = "3"
				order.Price = futureOrderPrice
				order.Quantity = FutureNum
				FutureTradeFee = PosEstimateFare(futureAccountCode,Future,order)

				staticInfo.OpenPrice = OpenPrice
				staticInfo.FutureBuyChargeCost = FutureBuyChargeCost
				staticInfo.FutureTradeFee = FutureTradeFee
				staticInfo.ContractsNum = ContractsNum
				staticInfo.Price = Price
			else
				FutureTradeFee = staticInfo.FutureTradeFee
				SellAmount = staticInfo.SellAmount
			end

			--套利分析
			local  lp_300_price = GetOrderPrice("M000300",0,0,"最新价","不浮动")
			if SellAmount and FutureNum and SellAmount ~= "-" and FutureNum ~= "-" then
				Exposure = lp_300_price*300 - SellAmount/FutureNum
			end
			local cost = 0
			if SpotTradeFee ~="-" then
				cost = SpotTradeFee
			end
			if FutureTradeFee ~="-" then
				cost = cost + FutureTradeFee
			end
			if cost ~=0 then
				EstimatedCost = cost
			end

			staticInfo.Exposure = Exposure
			staticInfo.EstimatedCost = EstimatedCost
		end
		HandleArbitrageInfo(portID)
	end
end
function HandleArbitrageInfo(portID)
	local info = gtArbitrageInfoTable[portID]
	if info then
		CalculateStaticInfo(info)
		--需要保存组合套利情况显示数据
		SaveArbitrageInfo(info)
		SendArbitrageInfo(info)
	end
end
function CalculateStaticInfo(staticInfo)						--现货、期货、期现套利统计与分析

	if staticInfo then

		local shortPrice = GetOrderPrice("M000300",0,0,"最新价","不浮动")

		--local log = sys_format("FutureTradeFee:%s, StockNum:%s, OpenHS300Price:%s,FutureNum:%s,BuyAmount:%s,SpotTradeFee:%s,StockStatus:%s,FutureStatus:%s,PortID:%s", staticInfo.FutureTradeFee , staticInfo.SampleNum, staticInfo.OpenHS300Price, staticInfo.FutureNum, staticInfo.BuyAmount,staticInfo.SpotTradeFee,staticInfo.StockStatus,staticInfo.FutureStatus,staticInfo.PortID)
		--_WriteErrorLog(log)

		--计算累计盈亏及其他值
		staticInfo.Price = GetOrderPrice(staticInfo.Future,0,0,"最新价","不浮动")

		local gainLoss = 0
		if staticInfo.SpotFloatStatus ~= "-" then
		    gainLoss = staticInfo.SpotFloatStatus
		end

		if staticInfo.SpotTradeFee ~="-" and staticInfo.StockStatus ~= "新建" then
			staticInfo.SpotGainLoss  = gainLoss + staticInfo.SpotCumulationPL - staticInfo.SpotTradeFee
		end

		gainLoss =0
		if staticInfo.FutureFloatStatus ~= "-" then
		    gainLoss = staticInfo.FutureFloatStatus
			--staticInfo.FutureGainLoss  = gainLoss
		end

		if staticInfo.FutureTradeFee  ~="-" and staticInfo.FutureStatus ~= "新建"  then
			staticInfo.FutureGainLoss  = gainLoss + staticInfo.FutureCumulationPL - staticInfo.FutureTradeFee
		end

		if staticInfo.OpenQtySum > 0 then
			staticInfo.ContractsNum = staticInfo.FutureNum - staticInfo.OpenQtySum + staticInfo.CloseQtySum
		end
		--计算期现套利分析
		if staticInfo.OpenHS300Price ~= "-" and staticInfo.BuyAmount ~="-" then
			staticInfo.Exposure =( staticInfo.OpenHS300Price * 300 * staticInfo.SampleNum - staticInfo.BuyAmount )/staticInfo.FutureNum
		end

		if staticInfo.OpenHS300Price ~="-" and staticInfo.OpenPrice ~= "-" then
			staticInfo.OpenBasis = staticInfo.OpenPrice - staticInfo.OpenHS300Price
		end
		staticInfo.OpenPoint = staticInfo.OpenHS300Price

		if staticInfo.CloseHS300Price ~="-" and staticInfo.ClosePrice ~= "-" then
			staticInfo.CloseBasis = staticInfo.ClosePrice - staticInfo.CloseHS300Price
		end

		staticInfo.ClosePoint = staticInfo.CloseHS300Price

		if staticInfo.CloseBasis ~="-" and staticInfo.OpenBasis ~="-" then
			staticInfo.BasisRevenue = (staticInfo.CloseBasis -  staticInfo.OpenBasis) * 300
		end

		if staticInfo.ClosePoint  =="-" and staticInfo.OpenHS300Price ~="-" and staticInfo.SellAmount ~="-" and staticInfo.SpotMarketValue ~="-" then
		   staticInfo.AlphaRevenue = staticInfo.SpotMarketValue - staticInfo.SellAmount * (1+ (shortPrice-staticInfo.OpenHS300Price) /staticInfo.OpenHS300Price)
		end

		local spotMarketValue = 0
		if staticInfo.SpotMarketValue ~= "-" then
			spotMarketValue = staticInfo.SpotMarketValue
		end

 		if staticInfo.ClosePoint  ~="-" and staticInfo.OpenHS300Price ~="-" and staticInfo.BuyAmount ~="-" and staticInfo.CloseHS300Price ~="-" then
			staticInfo.AlphaRevenue = spotMarketValue + staticInfo.BuyAmount - staticInfo.SellAmount * (1+ (staticInfo.CloseHS300Price-staticInfo.OpenHS300Price) /staticInfo.OpenHS300Price)
		end

		if staticInfo.OpenHS300Price ~="-" and staticInfo.Exposure ~="-" and staticInfo.CloseHS300Price =="-" then
			staticInfo.ExposureRevenue = staticInfo.Exposure * (staticInfo.OpenHS300Price -shortPrice)/staticInfo.OpenHS300Price
		end

		if staticInfo.CloseHS300Price ~="-" and staticInfo.Exposure ~="-" then
			staticInfo.ExposureRevenue = staticInfo.Exposure * (staticInfo.OpenHS300Price -staticInfo.CloseHS300Price)/staticInfo.OpenHS300Price
		end
		local impactCost = 0

		if staticInfo.SpotBuyChargeCost ~= "-" then
			impactCost = impactCost+ staticInfo.SpotBuyChargeCost
		end

		if staticInfo.SpotSellChargeCost ~= "-" then
			impactCost = impactCost + staticInfo.SpotSellChargeCost
		end

		if staticInfo.FutureBuyChargeCost ~= "-"  then
			impactCost = impactCost + staticInfo.FutureBuyChargeCost
		end

		if staticInfo.FutureSellChargeCost ~= "-" then
			impactCost = impactCost+ staticInfo.FutureSellChargeCost
		end
		staticInfo.ImpactCosts = impactCost

		local estimatedCost = 0

		if staticInfo.SpotTradeFee ~= "-" then
			estimatedCost = staticInfo.SpotTradeFee
		end

		if staticInfo.FutureTradeFee ~= "-" then
			estimatedCost = estimatedCost + staticInfo.FutureTradeFee
		end

		staticInfo.EstimatedCost = estimatedCost

		if staticInfo.SpotMarketValue ~= "-" and staticInfo.FutureMarketValue ~="-" then
			staticInfo.PoorMarket = staticInfo.FutureMarketValue - staticInfo.SpotMarketValue
		end

		if staticInfo.BasisRevenue ~= "-" and staticInfo.AlphaRevenue ~="-" and staticInfo.ExposureRevenue ~="-" then
			staticInfo.EstimatedRevenue = staticInfo.BasisRevenue + staticInfo.AlphaRevenue + staticInfo.ExposureRevenue - staticInfo.EstimatedCost
		end

		if staticInfo.EstimatedRevenue ~="-" then
			staticInfo.RateReturn = staticInfo.EstimatedRevenue / (staticInfo.BuyAmount + staticInfo.ContractsNum * staticInfo.OpenPrice * 300)
		end
	end
end

function CreateArbitrageInfo(portID,isCreate)
	local staticInfo = gtArbitrageInfoTable[portID]
	local combInfo = gtCombinList[portID]

    if not staticInfo and combInfo then

	    gtArbitrageInfoTable[portID] = {}
		staticInfo = gtArbitrageInfoTable[portID]
		staticInfo.PortID = portID
		staticInfo.CombinName = combInfo.CombinName
		staticInfo.Status = combInfo.Status
		staticInfo.Stock = combInfo.Stock
		staticInfo.StockStatus  =  combInfo.StockStatus								--状态
		staticInfo.FutureStatus = combInfo.FutureStatus
		staticInfo.SampleNum = combInfo.StockNum
		staticInfo.Future = combInfo.Future
		staticInfo.FutureNum = combInfo.FutureNum

		staticInfo.StartTime = "-"
		staticInfo.EndTime = "-"

		staticInfo.BuyAmount = "-"
		staticInfo.SpotBuyChargeCost = "-"
		staticInfo.SellAmount = "-"
		staticInfo.SpotSellChargeCost = "-"
		staticInfo.SpotMarketValue = "-"
		staticInfo.SpotVarieties = "-"
		staticInfo.SpotTradeFee = "-"
		staticInfo.SpotFloatStatus = "-"
		staticInfo.SpotGainLoss = "-"
		staticInfo.SpotCumulationPL = 0

		staticInfo.OpenPrice = "-"
		staticInfo.OpenQtySum = 0
		staticInfo.FutureBuyChargeCost = "-"
		staticInfo.ClosePrice = "-"
		staticInfo.CloseQtySum = 0
		staticInfo.FutureSellChargeCost = "-"
		staticInfo.FutureMarketValue   = "-"
		staticInfo.FutureTradeFee = "-"
		staticInfo.ContractsNum = "-"
		staticInfo.Price = "-"
		staticInfo.FutureFloatStatus = "-"
		staticInfo.FutureGainLoss = "-"
        staticInfo.FutureCumulationPL = 0

		staticInfo.Exposure = "-"
		staticInfo.OpenBasis = "-"
		staticInfo.OpenPoint = "-"
		staticInfo.CloseBasis = "-"
		staticInfo.ClosePoint = "-"
		staticInfo.BasisRevenue = "-"
		staticInfo.AlphaRevenue = "-"
		staticInfo.ExposureRevenue = "-"
		staticInfo.ImpactCosts = "-"
		staticInfo.EstimatedCost = "-"
		staticInfo.PoorMarket = "-"
		staticInfo.EstimatedRevenue = "-"
		staticInfo.RateReturn = "-"

		staticInfo.OpenHS300Price  ="-" --建仓沪深300的最新价
		staticInfo.OpenFuturePrice ="-" --平仓期指的最新价
		staticInfo.CloseHS300Price  ="-" --平仓沪深300的最新价
		staticInfo.CloseFuturePrice ="-"  --平仓期指的最新价
		staticInfo.SaveFlag =0
	end
	if staticInfo and isCreate then

		if staticInfo.StockStatus == "新建" then
			staticInfo.SellAmount = "-"
			staticInfo.SpotSellChargeCost = "-"
			staticInfo.SpotTradeFee = "-"
		end
		if staticInfo.FutureStatus == "新建" then
			staticInfo.OpenPrice = "-"
			staticInfo.FutureBuyChargeCost = "-"
			staticInfo.FutureTradeFee = "-"
		end
	end
	return staticInfo
end

function SendArbitrageInfo(info)								--发送套利组合统计数据(原先统计指标发送函数)
	if info then
		--基本信息
		local CombinName = info.CombinName						--套利组合名
		local Status = info.Status								--状态
		local Stock = info.Stock								--现货
		local SampleNum = info.SampleNum						--样本数
		local Future = info.Future								--期货
		local FutureNum = info.FutureNum						--期货分数
		local StartTime = info.StartTime						--建仓开始时间
		local EndTime = info.EndTime							--平仓开始时间
		--现货
		local BuyAmount = info.BuyAmount						--买入金额
		local SpotBuyChargeCost = info.SpotBuyChargeCost		--买入冲击成本
		local SellAmount = info.SellAmount						--卖出金额
		local SpotSellChargeCost = info.SpotSellChargeCost		--卖出冲击成本
		local SpotMarketValue = info.SpotMarketValue			--持仓市值
		local SpotVarieties = info.SpotVarieties				--品种数
		local SpotTradeFee = info.SpotTradeFee					--交易费用
		local SpotFloatStatus = info.SpotFloatStatus			--浮动盈亏
		local SpotGainLoss = info.SpotGainLoss					--现货盈亏
		if BuyAmount ~= "-" then
		   BuyAmount = sys_format("%.02f",BuyAmount)
		end
		if SpotBuyChargeCost ~= "-" then
		   SpotBuyChargeCost = sys_format("%.02f",SpotBuyChargeCost)
		end
		if SellAmount ~= "-" then
		   SellAmount = sys_format("%.02f",SellAmount)
		end
		if SpotSellChargeCost ~= "-" then
		   SpotSellChargeCost = sys_format("%.02f",SpotSellChargeCost)
		end
		if SpotMarketValue ~= "-" then
		   SpotMarketValue = sys_format("%.02f",SpotMarketValue)
		end
		if SpotTradeFee ~= "-" then
		   SpotTradeFee = sys_format("%.02f",SpotTradeFee)
		end
		if SpotFloatStatus ~= "-" then
		   SpotFloatStatus = sys_format("%.02f",SpotFloatStatus)
		end
		if SpotGainLoss ~= "-" then
		   SpotGainLoss = sys_format("%.02f",SpotGainLoss)
		end
		--期货
		local OpenPrice = info.OpenPrice						--建仓均价
		local FutureBuyChargeCost = info.FutureBuyChargeCost	--建仓冲击成本
		local ClosePrice = info.ClosePrice						--平仓均价
		local FutureSellChargeCost = info.FutureSellChargeCost	--平仓冲击成本
		local FutureTradeFee = info.FutureTradeFee				--交易费用
		local ContractsNum = info.ContractsNum					--平仓合约数
		local Price = info.Price								--当前价格
		local FutureFloatStatus = info.FutureFloatStatus		--浮动盈亏
		local FutureGainLoss = info.FutureGainLoss				--期货盈亏

		if OpenPrice ~= "-" then
		   OpenPrice = sys_format("%.02f",OpenPrice)
		end
		if FutureBuyChargeCost ~= "-" then
		   FutureBuyChargeCost = sys_format("%.02f",FutureBuyChargeCost)
		end
		if ClosePrice ~= "-" then
		   ClosePrice = sys_format("%.02f",ClosePrice)
		end
		if FutureSellChargeCost ~= "-" then
		   FutureSellChargeCost = sys_format("%.02f",FutureSellChargeCost)
		end
		if FutureTradeFee ~= "-" then
		   FutureTradeFee = sys_format("%.02f",FutureTradeFee)
		end
		if FutureFloatStatus ~= "-" then
		   FutureFloatStatus = sys_format("%.02f",FutureFloatStatus)
		end
		if FutureGainLoss ~= "-" then
		   FutureGainLoss = sys_format("%.02f",FutureGainLoss)
		end
		--套利
		local Exposure = info.Exposure							--建仓敞口
		local OpenBasis = info.OpenBasis						--建仓基差
		local OpenPoint = info.OpenPoint						--建仓点
		local CloseBasis = info.CloseBasis						--平仓基差
		local ClosePoint = info.ClosePoint						--平仓点
		local BasisRevenue = info.BasisRevenue					--基差收益
		local AlphaRevenue = info.AlphaRevenue					--α收益
		local ExposureRevenue = info.ExposureRevenue			--敞口收益
		local ImpactCosts = info.ImpactCosts					--冲击成本
		local EstimatedCost = info.EstimatedCost				--预估费用
		local PoorMarket = info.PoorMarket						--市值差
		local EstimatedRevenue = info.EstimatedRevenue			--预估收益
		local RateReturn = info.RateReturn						--收益率

		if Exposure ~= "-" then
		   Exposure = sys_format("%.02f",Exposure)
		end
		if OpenBasis ~= "-" then
		   OpenBasis = sys_format("%.02f",OpenBasis)
		end
		if OpenPoint ~= "-" then
		   OpenPoint = sys_format("%.02f",OpenPoint)
		end
		if CloseBasis ~= "-" then
		   CloseBasis = sys_format("%.02f",CloseBasis)
		end
		if ClosePoint ~= "-" then
		   ClosePoint = sys_format("%.03f",ClosePoint)
		end
		if BasisRevenue ~= "-" then
		   BasisRevenue = sys_format("%.02f",BasisRevenue)
		end
		if AlphaRevenue ~= "-" then
		   AlphaRevenue = sys_format("%.02f",AlphaRevenue)
		end
		if ExposureRevenue ~= "-" then
		   ExposureRevenue = sys_format("%.02f",ExposureRevenue)
		end
		if ImpactCosts ~= "-" then
		   ImpactCosts = sys_format("%.02f",ImpactCosts)
		end
		if EstimatedCost ~= "-" then
		   EstimatedCost = sys_format("%.02f",EstimatedCost)
		end
		if PoorMarket ~= "-" then
		   PoorMarket = sys_format("%.02f",PoorMarket)
		end
		if EstimatedRevenue ~= "-" then
		   EstimatedRevenue = sys_format("%.02f",EstimatedRevenue)
		end
		if RateReturn ~= "-" then
		   RateReturn = sys_format("%.03f",RateReturn)
		end


		local DTSEvent info = _CreateEventObject("VArbitrageInfo")
		info._SetFld("CombinName", CombinName);
		info._SetFld("Status", Status);
		info._SetFld("Stock", Stock);
		info._SetFld("SampleNum", SampleNum);
		info._SetFld("Future", Future);
		info._SetFld("FutureNum", FutureNum);
		info._SetFld("StartTime", StartTime);
		info._SetFld("EndTime", EndTime);

		info._SetFld("BuyAmount", BuyAmount);
		info._SetFld("SpotBuyChargeCost", SpotBuyChargeCost);
		info._SetFld("SellAmount", SellAmount);
		info._SetFld("SpotSellChargeCost", SpotSellChargeCost);
		info._SetFld("SpotMarketValue", SpotMarketValue);
		info._SetFld("SpotVarieties", SpotVarieties);
		info._SetFld("SpotTradeFee", SpotTradeFee);
		info._SetFld("SpotFloatStatus", SpotFloatStatus);
		info._SetFld("SpotGainLoss", SpotGainLoss);

		info._SetFld("OpenPrice", OpenPrice);
		info._SetFld("FutureBuyChargeCost", FutureBuyChargeCost);
		info._SetFld("ClosePrice", ClosePrice);
		info._SetFld("FutureSellChargeCost", FutureSellChargeCost);
		info._SetFld("FutureTradeFee", FutureTradeFee);
		info._SetFld("ContractsNum", ContractsNum);
		info._SetFld("Price", Price);
		info._SetFld("FutureFloatStatus", FutureFloatStatus);
		info._SetFld("FutureGainLoss", FutureGainLoss);

		info._SetFld("Exposure", Exposure);
		info._SetFld("OpenBasis", OpenBasis);
		info._SetFld("OpenPoint", OpenPoint);
		info._SetFld("CloseBasis", CloseBasis);
		info._SetFld("ClosePoint", ClosePoint);
		info._SetFld("BasisRevenue", BasisRevenue);
		info._SetFld("AlphaRevenue", AlphaRevenue);
		info._SetFld("ExposureRevenue", ExposureRevenue);
		info._SetFld("ImpactCosts", ImpactCosts);
		info._SetFld("EstimatedCost", EstimatedCost);
		info._SetFld("PoorMarket", PoorMarket);
		info._SetFld("EstimatedRevenue", EstimatedRevenue);
		info._SetFld("RateReturn", RateReturn);
		_SendToClients(info)
	end
end

function ClearTable()											--清空表
	--现货建仓表
	local DTSEvent StockOpen = _CreateEventObject("VStockOpenPosTable")
	StockOpen._SetFld("IssueCode","Clear")
	_SendToClients(StockOpen)

	--现货平仓表
	local DTSEvent StockClose = _CreateEventObject("VStockClosePosTable")
	StockClose._SetFld("IssueCode","Clear")
	_SendToClients(StockClose)

	--期货建仓表
	local DTSEvent FutureOpen = _CreateEventObject("VFutureOpenPosTable")
	FutureOpen._SetFld("IssueCode","Clear")
	_SendToClients(FutureOpen)

	--期货平仓表
	local DTSEvent FutureClose = _CreateEventObject("VFutureClosePosTable")
	FutureClose._SetFld("IssueCode","Clear")
	_SendToClients(FutureClose)

	--现货套利持仓
	local DTSEvent Arbitrage = _CreateEventObject("VArbitragePositionInfo")
	Arbitrage._SetFld("IssueCode","Clear")
	_SendToClients(Arbitrage)

	--现货委托表
	local DTSEvent StockOrder = _CreateEventObject("VStockOrderEvent")
	StockOrder._SetFld("IssueCode","Clear")
	_SendToClients(StockOrder)

	--现货成交表
	local DTSEvent StockExecute = _CreateEventObject("VStockExecuteEvent")
	StockExecute._SetFld("IssueCode","Clear")
	_SendToClients(StockExecute)

	--期货委托表
	local DTSEvent FutureOrder = _CreateEventObject("VFutureOrderEvent")
	FutureOrder._SetFld("IssueCode","Clear")
	_SendToClients(FutureOrder)

	--期货成交表
	local DTSEvent FutureExec = _CreateEventObject("VFutureExecuteEvent")
	FutureExec._SetFld("IssueCode","Clear")
	_SendToClients(FutureExec)


	--期货套利表
	local DTSEvent FutureArb = _CreateEventObject("VFutureArbitragePosInfo")
	FutureArb._SetFld("IssueCode","Clear")
	_SendToClients(FutureArb)

end
function getDateTime()
    local DTSDate nowDate = _GetNowDate();
	local today = nowDate.asString("%Y%m%d");
	local DTSTime nowtime = _GetNowTime();
    local smtime = nowtime.asString("%H:%M:%S");
	local dateTime = sys_format("%s-%s",today,smtime)
	return dateTime
end
function sendLog(logMessage)
	sendLog(logMessage,"")
end
function sendLog(logMessage,portID)
	local DTSEvent systemLog=_CreateEventObject("VSystemLog")
	local DTSTime nowtime = _GetNowTime();
    local smtime = nowtime.asString("%H%M%S");
	local tmplogtimeH = sys_sub(smtime,1,2);
	local tmplogtimeM = sys_sub(smtime,3,4);
	local tmplogtimeS = sys_sub(smtime,5,6);
	local tmplogtime = tmplogtimeH..":"..tmplogtimeM..":"..tmplogtimeS
	if gtCombinList[portID] then
		portID = gtCombinList[portID].CombinName
		logMessage = sys_format("组合名称[%s]:%s",portID,logMessage)
	end
	systemLog._SetFld("LogTime",tmplogtime)
	systemLog._SetFld("LogMessage",logMessage)
	--systemLog._SetFld("PortID",portID)
	_SendToClients(systemLog)
end


function getPriceFormat(issueCode)								--得到价格格式字符串
	local priceExponent = _PosIssueExponentTable[issueCode]
	if not priceExponent then
		priceExponent = -3
	end
	local priceExponentabs = sys_abs(priceExponent)
	local formatStr = sys_format("%%.%df", priceExponentabs)
	return formatStr
end

function formatTime(time)										--时间格式化函数：将时间格式化为hh:mm:ss的格式
	local ftTime = time
	local colon = sys_sub(time, 3, 3)
	if colon ~= ":" then
		local hh = sys_sub(time ,1, 2)
		local mm = sys_sub(time ,3, 4)
		local ss = sys_sub(time ,5, 6)
		ftTime = hh .. ":" .. mm .. ":" .. ss
	end
	return ftTime
end
function SaveArbitrageInfo(staticInfo)

   if staticInfo then
     local saveFlag = staticInfo.SaveFlag
	 if saveFlag == 1 then
		local portID = staticInfo.PortID

	    SaveArbitrageInfoEvent._SetFld("PortID",portID)
		gtSaveArbitrageInfo._Clear()
	    local DTSEvent saveEvent  = _CreateEventObject("VSaveArbitrageInfo");
		local buyAmount = staticInfo.BuyAmount  --现货买入金额
		local spotBuyChargeCost = staticInfo.SpotBuyChargeCost --现货买入冲击成本
		local sellAmount = staticInfo.SellAmount --现货卖出金额
		local spotSellChargeCost = staticInfo.SpotSellChargeCost--现货卖出冲击成本
		local spotTradeFee = staticInfo.SpotTradeFee--现货交易费用
		local spotGainLoss = staticInfo.SpotCumulationPL --现货盈亏

		local openPrice = staticInfo.OpenPrice --建仓均价
		local futureBuyChargeCost = staticInfo.FutureBuyChargeCost--冲击成本
		local closePrice = staticInfo.ClosePrice--平仓均价
		local futureSellChargeCost = staticInfo.FutureSellChargeCost--冲击成本
		local futureTradeFee = staticInfo.FutureTradeFee --交易费用
		local futureGainLoss = staticInfo.FutureCumulationPL--期货盈亏


		local open300Price = staticInfo.OpenHS300Price
		local openIFPrice = staticInfo.OpenFuturePrice
		local close300Price = staticInfo.CloseHS300Price
		local cloeIFPrice = staticInfo.CloseFuturePrice
		local closeQty = staticInfo.CloseQtySum
		local openQty = staticInfo.OpenQtySum

		local startTime = staticInfo.StartTime
		local endTime = staticInfo.EndTime

		saveEvent._SetFld("PortID",portID) --组合号
		saveEvent._SetFld("BuyAmount",buyAmount) --现货买入金额
		saveEvent._SetFld("SpotBuyChargeCost",spotBuyChargeCost)--现货买入冲击成本
		saveEvent._SetFld("SellAmount",sellAmount)--现货卖出金额
		saveEvent._SetFld("SpotSellChargeCost",spotSellChargeCost)--现货卖出冲击成本
		saveEvent._SetFld("SpotTradeFee",spotTradeFee)--现货交易费用
		saveEvent._SetFld("SpotGainLoss",spotGainLoss)--现货盈亏
		saveEvent._SetFld("OpenPrice",openPrice)--建仓均价
		saveEvent._SetFld("FutureBuyChargeCost",futureBuyChargeCost)--冲击成本
		saveEvent._SetFld("ClosePrice",closePrice)--平仓均价
		saveEvent._SetFld("FutureSellChargeCost",futureSellChargeCost)--冲击成本
		saveEvent._SetFld("FutureTradeFee",futureTradeFee)--交易费用
		saveEvent._SetFld("FutureGainLoss",futureGainLoss)--期货盈亏

		saveEvent._SetFld("OpenHS300Price",open300Price)
		saveEvent._SetFld("OpenFuturePrice",openIFPrice)
		saveEvent._SetFld("CloseHS300Price",close300Price)
		saveEvent._SetFld("CloseFuturePrice",cloeIFPrice)
		saveEvent._SetFld("CloseQtySum",closeQty)
		saveEvent._SetFld("OpenQtySum",openQty)
		saveEvent._SetFld("StartTime",startTime)
		saveEvent._SetFld("EndTime",endTime)

		gtSaveArbitrageInfo._SaveData("SaveArbitrageInfoData",saveEvent)
		local log = sys_format("Save,PortID:%s, open300Price:%s,openIFPrice:%s, close300Price:%s, cloeIFPrice:%s, futureTradeFee:%s, closeQty:%s,openQty:%s ", portID, open300Price,openIFPrice, close300Price, cloeIFPrice, futureTradeFee,closeQty,openQty)
		_WriteAplLog(log)
		staticInfo.SaveFlag = 0
	 end
   end
end

function RefreshList(portID)
	local stock = gtCombinList[portID].Stock
	local stockNum = gtCombinList[portID].StockNum
	local stockBuy = gtCombinList[portID].StockBuy
	local stockSell = gtCombinList[portID].StockSell
	gtCombinList[portID].SP = 0											--停牌数量
	gtCombinList[portID].DL = 0											--涨停数量
	gtCombinList[portID].SL = 0											--跌停数量
	gtCombinList[portID].NotSellQty = 0									--盘口不足
	gtCombinList[portID].NotBuyQty = 0									--盘口不足

	if gtInventoryList[stock] then
		for issue,value in pairs(gtCombinList[portID].List) do
			if not gtInventoryList[stock][issue] then
				gtCombinList[portID].InventoryNum = gtCombinList[portID].InventoryNum - 1
				gtCombinList[portID].List[issue] = nil
			else
				gtCombinList[portID].List[issue].Status = "正常"
				gtCombinList[portID].List[issue].NotSellQty = "正常"
				gtCombinList[portID].List[issue].NotBuyQty = "正常"
			end
		end

		for issue,value in pairs(gtInventoryList[stock]) do
			if not gtCombinList[portID].List[issue] then
				gtCombinList[portID].InventoryNum = gtCombinList[portID].InventoryNum + 1
				gtCombinList[portID].List[issue] = {}
				gtCombinList[portID].List[issue].Quantity = value.Quantity
				gtCombinList[portID].List[issue].Status = "正常"
				gtCombinList[portID].List[issue].Inventory = 0		--库存量
				gtCombinList[portID].List[issue].SaveQty = 0		--留存量
				gtCombinList[portID].List[issue].OrderBuyPrice = 0		--委托买入价格
				gtCombinList[portID].List[issue].OrderSellPrice = 0		--委托卖出价格
				gtCombinList[portID].List[issue].OrderBuyQty = value.Quantity * stockNum.getNumberValue()	--委托买入数量
				gtCombinList[portID].List[issue].OrderSellQty = value.Quantity * stockNum.getNumberValue()	--委托卖出数量
				gtCombinList[portID].List[issue].NotSellQty = "正常"		--卖盘盘口匹配
				gtCombinList[portID].List[issue].NotBuyQty = "正常"			--买盘盘口匹配
				gtCombinList[portID].List[issue].StockBuyTick = "不浮动" 	--现货tick
				gtCombinList[portID].List[issue].StockSellTick = "不浮动"	--现货tick
				gtCombinList[portID].List[issue].StockBuy = stockBuy		--现货买入取价方式
				gtCombinList[portID].List[issue].StockSell = stockSell		--现货卖出取价方式
				gtCombinList[portID].List[issue].ExecQuantity = 0 			--成交数量
				gtCombinList[portID].List[issue].ExecPrice = 0 				--成交均价
				gtCombinList[portID].List[issue].UserPos = "0" 				--使用库存
				gtCombinList[portID].List[issue].NotSell = "0" 				--不买入
				gtCombinList[portID].List[issue].SavePos = "0" 				--留存
				gtCombinList[portID].List[issue].NotBuy = "0" 				--不卖出
			elseif gtCombinList[portID].List[issue].Quantity ~= value.Quantity then
				gtCombinList[portID].List[issue].Quantity = value.Quantity
				gtCombinList[portID].List[issue].OrderBuyQty = value.Quantity * stockNum.getNumberValue()	--委托买入数量
				gtCombinList[portID].List[issue].OrderSellQty = value.Quantity * stockNum.getNumberValue()	--委托卖出数量
			end
		end
		Refresh(portID)
		SaveCombinData(portID,gtCombinList[portID])						--保存动态套利组合数据
	end
end

function CopyCombin(portID)
	local combinName = gtCombinList[portID].CombinName
	local stock = gtCombinList[portID].Stock
	local stockNum = gtCombinList[portID].StockNum
	local stockBuy = gtCombinList[portID].StockBuy
	local stockSell = gtCombinList[portID].StockSell
	local future = gtCombinList[portID].Future
	local futureNum = gtCombinList[portID].FutureNum
	local futureBuy = gtCombinList[portID].FutureBuy
	local futureSell = gtCombinList[portID].FutureSell
	CreateCombin(combinName,stock,stockNum,stockBuy,stockSell,future,futureNum,futureBuy,futureSell)
end

function CreateCombin(combinName,stock,stockNum,stockBuy,stockSell,future,futureNum,futureBuy,futureSell)
	local portID = creatID()
	_WriteErrorLog(stock)
	for i,k in pairs(gtInventoryName)do
		if stock == k then
			stock = i
		end
	end
	_WriteErrorLog(stock)
	gtCombinList[portID] = gtCombinList[portID] or {}
	gtCombinList[portID].CombinName = combinName						--套利组合名称
	gtCombinList[portID].List = {}										--现货组合详情
	gtCombinList[portID].Stock = stock									--现货组合号
	gtCombinList[portID].StockNum = stockNum.getNumberValue()							--现货交易单位
	gtCombinList[portID].StockBuy = stockBuy							--现货买入取价方式
	gtCombinList[portID].StockSell = stockSell							--现货卖出取价方式

	gtCombinList[portID].Future = future								--期货组合号
	gtCombinList[portID].FutureNum = futureNum.getNumberValue()			--期货交易单位
	gtCombinList[portID].FutureBuy = futureBuy							--期货买入取价方式
	gtCombinList[portID].FutureSell = futureSell						--期货卖出取价方式
	gtCombinList[portID].FutureBuyTick = "不浮动"							--期货tick
	gtCombinList[portID].FutureSellTick = "不浮动"							--期货tick
	gtCombinList[portID].InventoryNum = 0								--品种数量
	gtCombinList[portID].SP = 0											--停牌数量
	gtCombinList[portID].DL = 0											--涨停数量
	gtCombinList[portID].SL = 0											--跌停数量
	gtCombinList[portID].OpenNum = 0                                       -- 实际买入品种数
	gtCombinList[portID].CloseNum = 0                                      -- 实际卖出品种数
	gtCombinList[portID].NotSellQty = 0									--盘口不足
	gtCombinList[portID].NotBuyQty = 0									--盘口不足
	gtCombinList[portID].StockStatus =  "新建" 								--状态
	gtCombinList[portID].FutureStatus = "新建" 								--状态

	local log = sys_format("创建组合[%s]",stock)
	_WriteAplLog(log)
	if gtInventoryList[stock] then
		for issue,value in pairs(gtInventoryList[stock]) do
			gtCombinList[portID].InventoryNum = gtCombinList[portID].InventoryNum + 1
			gtCombinList[portID].List[issue] = {}
			gtCombinList[portID].List[issue].Quantity = value.Quantity
			gtCombinList[portID].List[issue].Status = "正常"
			gtCombinList[portID].List[issue].Inventory = 0		--库存量
			gtCombinList[portID].List[issue].SaveQty = 0		--留存量
			gtCombinList[portID].List[issue].OrderBuyPrice = 0		--委托买入价格
			gtCombinList[portID].List[issue].OrderSellPrice = 0		--委托卖出价格
			gtCombinList[portID].List[issue].OrderBuyQty = value.Quantity * stockNum.getNumberValue()	--委托买入数量
			gtCombinList[portID].List[issue].OrderSellQty = value.Quantity * stockNum.getNumberValue()	--委托卖出数量
			gtCombinList[portID].List[issue].NotSellQty = "正常"		--卖盘盘口匹配
			gtCombinList[portID].List[issue].NotBuyQty = "正常"			--买盘盘口匹配
			gtCombinList[portID].List[issue].StockBuyTick = "不浮动" 	--现货tick
			gtCombinList[portID].List[issue].StockSellTick = "不浮动"	--现货tick
			gtCombinList[portID].List[issue].StockBuy = stockBuy		--现货买入取价方式
			gtCombinList[portID].List[issue].StockSell = stockSell		--现货卖出取价方式
			gtCombinList[portID].List[issue].ExecQuantity = 0 			--成交数量
			gtCombinList[portID].List[issue].ExecPrice = 0 				--成交均价
			gtCombinList[portID].List[issue].UserPos = "0" 				--使用库存
			gtCombinList[portID].List[issue].NotSell = "0" 				--不买入
			gtCombinList[portID].List[issue].SavePos = "0" 				--留存
			gtCombinList[portID].List[issue].NotBuy = "0" 				--不卖出
		end
	else
		local log = sys_format("创建组合组合失败:没有找到组合[%s]",stock)
		sendLog(log,portID)
	end
	InventoryListTable(portID)										--刷新套利组合表信息
	SaveCombinData(portID,gtCombinList[portID])						--保存动态套利组合数据
end
----------
--定时器--
----------

_OnEventTimer(_TimerName="TimeInterval")
	if _DD == 1 then				--刷新单笔委托资金信息
		if _PosPriceTable[_QueryIssue] then
			_DD = 0
			local CombinCode = _QueryTable["CombinCode"]
			local accountCode = _QueryTable["AccountCode"]
			local BAMapID = 	_QueryTable["BAMapID"]
			sendFundReplyClose(BAMapID,accountCode,CombinCode)
		end
	end

	if TT >= _gRefreash then
		TT = 0
		if gPortID ~= "" then
			RefreshArbitrageSinglePos(gPortID)								--刷新当前套利持仓
			calculateInventory(gPortID)	--定时计算套利组合内相关数据（基差重要数据行情实时计算）
			RefreshArbitrageInfo(gPortID) --定时计算与刷新现货、期货和期现套利数据计算
		end
	end
	TT = TT + 1
_End
_OnEventTimer(_TimerName="initTimer")
	RefreshArbitragePosition()
	for portID,info in pairs(gtCombinList) do
		calculateInventory(portID)	--定时计算套利组合内相关数据（基差重要数据行情实时计算）
		if gtArbitrageInfoTable[portID] then
		CalculateStaticInfo(gtArbitrageInfoTable[portID])
		end
		InventoryListTable(portID)
	end
_End
