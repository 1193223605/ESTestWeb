﻿--跨期套利初始版1.01
--Release version: 1.001.20140305
--委托成交回调
_OnEventExecution("OrderExecReply", {} , DTSMessageRecordAccess msg)
	local _String message = msg.getMessageType ()
	local DTSOrderDetailRecordAccess order = msg.getOrderDetailRecord();
	local _String baMapID = order.getBAMapID();
	local investorID = "-"
	local accountCode = _PosBAMapAccount[baMapID] or "-"
	local accountType = ""
	if _PosFundStatus[accountCode] then
		if _PosFundStatus[accountCode] then
			investorID = _PosFundStatus[accountCode].InvestorID
			accountType = _PosFundStatus[accountCode].Type
		end
	end

	--价格格式化
	local issueCode = order.getIssueCode();
	local formatPriceExponent = getPriceFormat(issueCode)
	if accountType == "F" and POS_LOGIN_CHECK_FUT_ISSUE ~= issueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= issueCode then
		local issueCode = order.getIssueCode();					--合约号
		local baSubID = order.getBASubID();						--BASubID
		local subID = sys_sub(baSubID, 2, -1)					--组合号
		local issueName = _PosIssueNameTable[issueCode];		--合约名称
		local buySell = order.getBuySell();						--买卖
		local openClose = order.getReserveInt1();				--开仓、平仓、平今
		local creRed = order.getGeneralInt1()					--0普通委托, 1:申购. 2:赎回, 3:质押, 4:融资回购, 5:融券回购
		local orderQuantity = order.getOriginalQuantity();		--委托数量
		local orderPrice = order.getOrderPrice();				--委托价
		local orderTime = order.getOrderTime();					--委托时间
		local orderAcceptNo = order.getOrderAcceptNo();			--委托号
		local corpCode = order.getCorpCode();					--内部委托号

		local workingQuantity = order.getWorkingQuantity();					--挂盘数量
		local cancelQuantity = order.getCancelQuantity();					--撤单数量
		local unAcceptedQuantity = order.getUnacceptedQuantity();			--未报数量
		local rejectedQuantity = order.getRejectedQuantity();				--拒绝数量
		local executionQuantity = order.getExecutionQuantity();				--成交数量
		local executionValue = order.getExecutionValue();					--成交金额

		local marketCode = order.getMarketCode();				--市场号
		local productCode = order.getProductCode();				--产品代码
		local marginFlag = order.getOrderMarginFlag();			--0:证券交易 2：开仓 4：平仓
		local generalString1 = order.getGeneralString1();		--客户号和交易密码
		local reserveString2 = order.getReserveString2()		--上海股东代码|深证股东代码
		local PCID = order.getPositionCheckID()					--持仓检查号
		local batchID = order.getTargetPrice()					--匹配号
		--投机套保标识
		local orderHedgeFlag = order.getExternalSystemID()
		if _PosDBHedgeFlagTable[orderHedgeFlag] then
			orderHedgeFlag = _PosDBHedgeFlagTable[orderHedgeFlag]
		end
		if subID == "" then
			subID = "-"
		end
		if subID == "-" or sys_sub(subID, 1, 2) == "KQ" then
			local logg = sys_format("batchID = [%s]",batchID)
			--_WriteErrorLog(logg)
			---XH---
			if gtKQOrderList[batchID] then
				_WriteErrorLog("回调gtKQOrderList[batchID]存在")
				local log = sys_format("cancelQuantity = %s,executionQuantity = %s,orderQuantity =%s",cancelQuantity,executionQuantity,orderQuantity)
				_WriteErrorLog(log)
				if executionQuantity == orderQuantity then
					_WriteErrorLog("单边全部成交")
					if gtKQOrderList[batchID].tOtherSide then
						OpenOrderSide(batchID)
					end
				end
			end

			--下单拒绝时交易号为""，输出为"-"
			if orderAcceptNo == "" then
				orderAcceptNo = "-"
			end

			------
			--[[设置成交额
			if executionValue ~= "" then
				executionValue = sys_format(formatPriceExponent, executionValue);
			end]]

			--设置委托价格
			if orderPrice ~= "" then
				orderPrice = sys_format(formatPriceExponent, orderPrice);
			end

			--设置委托时间
			if orderTime~="" then
				local tmpordtimeH = sys_sub(orderTime,1,2);
				local tmpordtimeM = sys_sub(orderTime,3,4);
				local tmpordtimeS = sys_sub(orderTime,5,6);
				local tmpordtimeHM = sys_sub(orderTime,7,9);
				orderTime = tmpordtimeH..":"..tmpordtimeM..":"..tmpordtimeS
			else
				local nowTime = GetHMS()
				orderTime = formatTime(nowTime)--内部成交的委托时间为空,取当前时间
			end

			--市价类型
			local orderType = order.getOrderPriceCondition()

			--设置委托状态
			local status = "-"
			local statusFlag = "-";
			if orderQuantity == executionQuantity then
				status = "全部成交"
				statusFlag = "1"
			elseif executionQuantity >0 and orderQuantity > executionQuantity then
				if executionQuantity + cancelQuantity == orderQuantity then
					status = "部成部撤"
					statusFlag = "1"
				else
					status = "部分成交"
					statusFlag = "2"
				end
			elseif workingQuantity > 0 then
				status = "挂单"
				statusFlag = "2"
			elseif cancelQuantity > 0 then
				status = "撤单"
				statusFlag = "1"
			elseif unAcceptedQuantity == orderQuantity then
				status = "未报"
				statusFlag = "2"
			elseif rejectedQuantity > 0 then
				status = "拒绝"
				statusFlag = "1"
			end

			local log = sys_format("OnExecOrder, msg=[%s], corpCode=[%s], orderAcceptNo=[%s], orderTime=[%s], PCID=[%s], batchID=[%s], issue=[%s], baSubID=[%s], bs=[%s], oc=[%s], orderPrice=[%s],orderQty=[%s], execQty=[%s], workingQty=[%s], cancelQty=[%s], unAcceptedQty=[%s], rejectedQty=[%s], status=[%s], statusFlag=[%s]",
											message, corpCode, orderAcceptNo, orderTime, PCID, batchID, issueCode, baSubID,  buySell, openClose, orderPrice, orderQuantity,executionQuantity, workingQuantity, cancelQuantity, unAcceptedQuantity, rejectedQuantity, status, statusFlag)
			_WriteErrorLog(log)

			-----------发送委托表，并保存在gtOrderList中-----------
			if not gtOrderList[subID] then
				gtOrderList[subID] = {}
				gtOrderList[subID].FutureOpen = {}
				gtOrderList[subID].FutureClose = {}
			end
			local templist = {}
			templist.PortID = subID
			templist.CorpCode = corpCode
			templist.IssueCode = issueCode
			templist.BuySell = buySell
			templist.OpenClose = openClose
			templist.EntrustPrice = orderPrice
			templist.EntrustQty = orderQuantity
			templist.OrderAcceptNo = orderAcceptNo
			templist.Status = status
			local dealPrice = 0
			if executionQuantity and executionQuantity ~= 0 then
				dealPrice = executionValue / executionQuantity / 300
				if dealPrice ~= "" then
					dealPrice = sys_format(formatPriceExponent, dealPrice);
				end
			end
			log = sys_format("executionQuantity[%s],executionValue[%s],dealPrice[%s]",executionQuantity,executionValue,dealPrice)
			_WriteErrorLog(log)
			templist.DealPrice = dealPrice
			templist.DealQty = executionQuantity
			templist.WorkingQuantity = workingQuantity
			templist.CancellationQty = cancelQuantity
			templist.Date = orderTime
			templist.InvestorID = investorID
			templist.StatusFlag = statusFlag
			templist.HedgeFlag = orderHedgeFlag
			if msg.getMessageType () == "L04" and status == "拒绝" then
			templist.Flag = reserveString2
			elseif msg.getMessageType () == "L18" then
				local tempbamap = sys_sub(baMapID,-3,-1)
				if tempbamap == "999" then
				templist.Flag = "初始化内部成交"
				else
				templist.Flag = "内部成交"
				end
			end

			SendFutureOpenOrderEvent(subID,corpCode,templist)
			if buySell == "3" then
				gtOrderList[subID].FutureOpen[corpCode] = templist
			elseif buySell == "1" then
				gtOrderList[subID].FutureClose[corpCode] = templist
			end
			---------------------------------------------------------

			--成交回调，并发送成交
			if msg.getMessageType () == "L07" or msg.getMessageType () == "L18"  then
				local execPrice = msg.getExecutionPrice()				--成交价格
				local execQuantity = msg.getExecutionQuantity()		--成交数量
				local execTime = msg.getExecutionTime()				--成交时间
				local execNo = msg.getExecutionNo()						--成交号

				if execPrice ~= "" then
					execPrice = sys_format(formatPriceExponent, execPrice);
				end
				if execNo == "" then	--内部成交的成交号为空
					execNo = "-"
				end
				if execTime ~= "" then
					execTime = formatTime(execTime)
				end

				local execLog = sys_format("OnExecOrder, execPrice:%s, execQuantity:%s, execTime:%s, execNo:%s",execPrice, execQuantity, execTime, execNo)
				_WriteErrorLog(execLog)

				-----------发送成交表，并保存在gtOrderList中-----------
				templist.ExecNo = execNo
				templist.ExecTime = execTime
				templist.ExecQuantity = execQuantity
				templist.ExecPrice = execPrice

				SendFutureOpenExecuteEvent(subID,corpCode,templist)
				if buySell == "3" then
					gtOrderList[subID].FutureOpen[corpCode] = templist
				elseif buySell == "1" then
					gtOrderList[subID].FutureClose[corpCode] = templist
				end

				---------------------------------------------------------
				--实时同步柜台持仓逻辑
				if msg.getMessageType () == "L07" and marketCode == "3" then
					if gtPositionTable[investorID] then

						local tempsubid = buySell
						local tempqty = execQuantity.getNumberValue()
						local tempAvlQty = tempqty
						if buySell == "3" and (openClose == 1 or openClose == 2) then
							tempsubid = "1"
							tempqty = -tempqty
							tempAvlQty = tempqty
						elseif buySell == "1" and (openClose == 1 or openClose == 2) then
							tempsubid = "3"
							tempqty = -tempqty
							tempAvlQty = tempqty
						end
						local tempkey = issueCode .. "." .. tempsubid .. "." .. orderHedgeFlag

						if gtPositionTable[investorID][tempkey] then
							local PosQuantity = gtPositionTable[investorID][tempkey].Quantity
							local PosAvQty = gtPositionTable[investorID][tempkey].AvQty
							if PosQuantity and PosQuantity ~= "" then
								PosQuantity = PosQuantity.getNumberValue()
								gtPositionTable[investorID][tempkey].Quantity = PosQuantity + tempqty
							end
							if PosAvQty and PosAvQty ~= "" then
								PosAvQty = PosAvQty.getNumberValue()
								gtPositionTable[investorID][tempkey].AvQty = PosAvQty + tempAvlQty
							end
						else
							gtPositionTable[investorID][tempkey] = {}
							local poslist = gtPositionTable[investorID][tempkey]
							poslist.BuySell = buySell
							poslist.InvestorID = investorID
							poslist.IssueName = issueName
							poslist.IssueCode = issueCode
							poslist.MarketType = marketCode
							poslist.Quantity = tempqty
							poslist.ReportQty = 0
							poslist.RedeemQty = 0
							poslist.AvQty = tempAvlQty
							poslist.AvSellQty = 0
							poslist.AvePrice = execPrice
							poslist.Margin = 0
							poslist.PL = 0
							poslist.hedgeType = orderHedgeFlag
							poslist.CostValue = execPrice * tempqty
						end
						sendQuerysinglePos(gtPositionTable[investorID][tempkey],"future")
					end
				end

			end


			--如果发生拒绝,发送拒绝消息,提示用户
			if msg.getMessageType() == "L04" or msg.getMessageType() == "L06" then
				local errorInfo = ""
				local errorType =  msg.getErrorType();
				if errorType == "1" or errorType == "2" then
					errorInfo = order.getReserveString2()
					if msg.getMessageType() == "L04" then
						errorInfo = sys_format("下单拒绝:%s", errorInfo)
					else
						errorInfo = sys_format("撤单拒绝:%s", errorInfo)
					end
				end
				if errorInfo ~= "" then
					local log = sys_format("Rejected Order, CorpCode:%s, errorInfo:%s", corpCode, errorInfo)
					_WriteErrorLog(log)
					if _PosStatus == POS_STATUS_NORMAL then
						sendSysLog(errorInfo)
					end
				end
			end



		end
	end
_End



function OpenOrderSide(batchID)
	_WriteErrorLog("OpenOrderSide")
	local submit = {}
	submit = gtKQOrderList[batchID].tOtherSide
	bs = submit.BuySell
	if bs == "3" then
		price = GetOrderPrice(submit.IssueCode,0,submit.Quantity,submit.Price,submit.Tick)
	elseif bs == "1" then
		price = GetOrderPrice(submit.IssueCode,1,submit.Quantity,submit.Price,submit.Tick)
	end

	local ret = PosSubmitSingleOrder(submit.BAMapID, submit.BASubID, submit.IssueCode, bs, 0, price, submit.Quantity, 0, "")
	if ret.Result then
		local log = sys_format("开仓方式[%s],合约[%s],价格[%s],数量[%s],追单时间[%s],追单次数[%s],追单取价[%s],追单价格幅度[%s]",
			submit.States,submit.IssueCode,price,submit.Quantity,submit.RunS,submit.RunNum,submit.RunP,submit.RunT)
		sendSysLog(log)

		if submit.RunS <= 0 then
		else
			local pcid = ret.PositionCheckID;
			local priceType = GetToPrice(submit.Iss,submit.RunP)
			local tick = GetToTick(submit.runT)
			PosSetAutoAmend(pcid, submit.RunS, submit.RunNum, priceType, POS_ADJ_BY_TICK, tick)
		end
	end

	gtKQOrderList[batchID].tOtherSide = nil
	ClearAutoList(submit)
	Notice(submit.States)
	_WriteErrorLog("OpenOrderSide EDN")
end
