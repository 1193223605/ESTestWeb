﻿--跨期套利初始版1.01
--Release version: 1.001.20140305
-------------------------XH--------------------------
--发送IF信息
_DefineEventObject CreateIFTableEvent _AS _Output
	_DefFld("IF1", _String, 6)
	_DefFld("IF2", _String, 6)
	_DefFld("IF3", _String, 6)
	_DefFld("IF4", _String, 6)
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);

_End

--发送正反向开仓基差
_DefineEventObject BuySellBasisEvent _AS _Output
	_DefFld("Basis1", _String, 6)
	_DefFld("Basis2", _String, 6)

_End

--手动开仓
_DefineEventObject HandOrderEvent _AS _Input
	_DefFld("States", _String, 20) -- 手动开仓 正向还是反向
	_DefFld("Issue1", _String, 20)
	_DefFld("Issue2", _String, 20)
	_DefFld("Qty1", _String, 20)
	_DefFld("Qty2", _String, 20)
	_DefFld("Price1", _String, 20)
	_DefFld("Tick1", _String, 20)
	_DefFld("Price2", _String, 20)
	_DefFld("Tick2", _String, 20)

	_DefFld("OrderWay", _String, 20) -- 下单方式 -- 近期优先/远期优先
	_DefFld("Order123", _String, 20) -- 下单顺序
	_DefFld("RunP1", _String, 20)
	_DefFld("RunT1", _String, 20)
	_DefFld("RunS1", _String, 20)
	_DefFld("RunP2", _String, 20)
	_DefFld("RunT2", _String, 20)
	_DefFld("RunS2", _String, 20)
	_DefFld("RunNum", _String, 20)

_End

--自动开仓

_DefineEventObject AutoOrderEvent _AS _Input
	_DefFld("Set1", _String, 20) -- 正向开关
	_DefFld("Set2", _String, 20) -- 反向开关
	_DefFld("States", _String, 20) -- 手动开仓 正向还是反向
	_DefFld("Issue1", _String, 20)
	_DefFld("Issue2", _String, 20)
	_DefFld("Qty1", _String, 20)
	_DefFld("Qty2", _String, 20)
	_DefFld("Price1", _String, 20)
	_DefFld("Tick1", _String, 20)
	_DefFld("Price2", _String, 20)
	_DefFld("Tick2", _String, 20)
	_DefFld("Basis1", _String, 20)
	_DefFld("Basis2", _String, 20)

	_DefFld("OrderWay", _String, 20) -- 下单方式 -- 近期优先/远期优先
	_DefFld("Order123", _String, 20) -- 下单顺序
	_DefFld("RunP1", _String, 20)
	_DefFld("RunT1", _String, 20)
	_DefFld("RunS1", _String, 20)
	_DefFld("RunP2", _String, 20)
	_DefFld("RunT2", _String, 20)
	_DefFld("RunS2", _String, 20)
	_DefFld("RunNum", _String, 20)

_End

--改变取价方式刷新基差
_DefineEventObject Notice _AS _Output
	_DefFld("States", _String, 20) -- 开仓还是开反仓

_End

--改变取价方式刷新基差
_DefineEventObject GetPriceForBasisEvent _AS _Input
	_DefFld("No", _String, 20) -- 手动开仓 正向还是反向
	_DefFld("Price1", _String, 20)
	_DefFld("Tick1", _String, 20)
	_DefFld("Price2", _String, 20)
	_DefFld("Tick2", _String, 20)
	_DefFld("Price3", _String, 20)
	_DefFld("Tick3", _String, 20)
	_DefFld("Price4", _String, 20)
	_DefFld("Tick4", _String, 20)

_End

-----------------------------------------------------
--发送账户信息
_DefineEventObject CreateFutureIDEvent _AS _Output
	_DefFld("BAMapID", _String, 200)			--账户列表
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--确认账户按钮的事件
_DefineEventObject SetBAMapID _AS _Input
	_DefFld("Flag", _String, 20)
	_DefFld("FutureInvestorID", _String, 20)
_End

_DefineEventObject selSp _AS _Input -- 接收选中跨期的期货Issue及取价方式
	_DefFld("Issue1",_String,20)
	_DefFld("Issue2",_String,20)
	_DefFld("Price1",_String,20)
	_DefFld("Tick1",_String,20)
	_DefFld("Price2",_String,20)
	_DefFld("Tick2",_String,20)
	_DefFld("Price3",_String,20)
	_DefFld("Tick3",_String,20)
	_DefFld("Price4",_String,20)
	_DefFld("Tick4",_String,20)

_End
--刷新柜台资金事件
_DefineEventObject RefreshFund _AS _Input
_End

--套利平仓
_DefineEventObject CombinControl1 _AS _Input
	_DefFld("CombinCode",_String,100)
	_DefFld("Issue1",_String,100)
	_DefFld("Issue2",_String,100)
	_DefFld("Qty1",_String,100)
	_DefFld("Qty2",_String,100)
	_DefFld("Price1",_String,100)
	_DefFld("Price2",_String,100)
	_DefFld("Tick1",_String,100)
	_DefFld("Tick2",_String,100)

_End
--止盈止损存数据
_DefineEventObject CombinControl2 _AS _Input
	_DefFld("CombinCode",_String,100)
	_DefFld("Issue1",_String,100)
	_DefFld("Issue2",_String,100)
	_DefFld("Qty1",_String,100)
	_DefFld("Qty2",_String,100)
	_DefFld("Price1",_String,100)
	_DefFld("Price2",_String,100)
	_DefFld("Price3",_String,100)
	_DefFld("Price4",_String,100)
	_DefFld("Tick1",_String,100)
	_DefFld("Tick2",_String,100)
	_DefFld("Tick3",_String,100)
	_DefFld("Tick4",_String,100)
	_DefFld("ZhiYing",_String,100)
	_DefFld("ZhiSun",_String,100)
	_DefFld("OK",_String,100)
	_DefFld("UpDian",_String,100)
	_DefFld("DownDian",_String,100)

_End

--提醒清先设置止盈止损参数
_DefineEventObject SetMessageNow  _AS _Input
	_DefFld("No",_String,100)

_End

--发送止盈止损触发成功消息
_DefineEventObject UpDownNotice  _AS _Input
	_DefFld("No",_String,100)

_End

--发送止盈止损下单提示
_DefineEventObject YesMessage  _AS _Input
	_DefFld("CombinCode",_String,100)

_End

--接受止盈止损确认
_DefineEventObject BackMessage  _AS _Input
	_DefFld("CombinCode",_String,100)
	_DefFld("Yes",_String,100)

_End

--止盈止损开关
_DefineEventObject StopProfit  _AS _Input
	_DefFld("CombinCode",_String,100)
	_DefFld("Kaiguan",_String,100)

_End

--删除套利
_DefineEventObject CombinControl3 _AS _Input
	_DefFld("CombinCode",_String,100)
_End

--清空套利
_DefineEventObject CombinControl4 _AS _Input
_End

--刷新实时价差图
_DefineEventObject tickerEvt _AS _Output
	_DefFld("pairCode",_String,20)
	_DefFld("lnSpread",_String,20)
	_DefFld("_TimeKey",_String,20)
	_DefKeyField("pairCode")
	_SetDataType(_EventOtherType)
	_SetBufferedFlag(1)
_End

_DefineEventObject flPriceEvt _AS _Output
	_DefFld("IssueCode", _String, 20)
	_DefFld("lastPrice", _String, 20)
	_DefFld("spread", _String, 20)
	_DefFld("price0", _String, 20)
	_DefFld("price1", _String, 20)
	_DefFld("price2", _String, 20)
	_DefFld("price3", _String, 20)

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType);
_End

_DefineEventObject flPriceEvt2 _AS _Output
	_DefFld("IssueCode", _String, 20)
	_DefFld("lastPrice", _String, 20)
	_DefFld("BestBid1", _String, 20)	--昨结算价
	_DefFld("BestBid2", _String, 20)	--持仓量
	_DefFld("Volume", _String, 20)		--成交量
	_DefFld("BestAsk", _String, 20)		--增仓
	_DefFld("Rose", _String, 20)		--涨幅

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType);
_End

_DefineEventObject SystemLog _AS _Output
	_DefFld("LogTime", _String, 12)
	_DefFld("LogMsg", _Meta, 4)
	_DefFld("LogNo", _Number, 4)
	_DefKeyField("LogNo")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType)
_End



_DefineEventObject FundStatus _AS _Output
	_DefFld("BZFund",_String ,20);		--保证金
	_DefFld("DTFund",_String ,20);		--动态权益
	_DefFld("KYFund",_String,20);		--可用资金
	_DefFld("DJFund",_String,20);		--冻结资金
	_DefFld("AccountID",_String,20);		--子账户

	_DefKeyField("AccountID");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

_DefineEventObject selCode _AS _Input
	_DefFld("is",_String,20)
	_DefFld("sel",_String,20)
_End

_DefineEventObject klineEvent _AS _Output
    _DefFld("pairCode",_String,20)
	_DefFld("lnSpread",_String,20)
	_DefFld("_TimeKey",_String,20)

    _DefKeyField("pairCode");
    _SetBufferedFlag(2);
    _SetDataType(_EventMinuteType);
    _SetDataInterval(1);
_End;
--根据CorpCode撤单
_DefineEventObject CancelSingleOrder _AS _Input
	_DefFld("CorpCode", _String, 20);	--内部委托号
_End
--改价重下
_DefineEventObject AmendSingleOrder _AS _Input
	_DefFld("CorpCode", _String, 20);	--内部委托号
	_DefFld("IssueCode", _String, 20);	--IssueCode
	_DefFld("BuySell", _String, 5);	--方向
	_DefFld("OrderPrice", _String, 20);	--改价
_End
--平仓查询资金状况显示
_DefineEventObject QueryCloseFund _AS _Input
	_DefFld("BAMapID",_String,32)		--BAMapID
    _DefFld("IssueCode", _String, 12)
	_DefFld("CombinCode", _String, 100)
_End
--单笔委托资金显示
_DefineEventObject FundReply _AS _Output
    _DefFld("IssueCode", _String, 20)
    _DefFld("AvlibFund", _String, 20)
    _DefFld("AvlibOpenatQty", _String, 20)
    _DefFld("AvlibBuyCloseQty", _String, 20)
    _DefFld("AvlibSellCloseQty", _String, 20)

    _DefKeyField("IssueCode")
    _SetBufferedFlag(2) -- use map mode
_End
--单笔委托
_DefineEventObject FireEvent _AS _Input
	_DefFld("CombinCode",_String,100)
	_DefFld("BAMapID",_String,32)		--BAMapID,平仓应用
    _DefFld("IssueCode", _String, 20)
    _DefFld("BuySell", _String, 1)
    _DefFld("OpenClose", _String, 1)
	_DefFld("Price", _String, 13)
    _DefFld("Quantity", _Int, 8)
_End
--Define basePrice Object
_DefineEventObject BasePriceEvent _AS _Output
	_DefFld("IssueCode",_String ,20);				--合约
	_DefFld("IssueShortName",_String ,30);		--合约名称
	_DefFld("LastPrice",_String,15);       			--最新
	_DefFld("LastVolume",_String,15);      	    	--现量
	_DefFld("BidPrice_1",_String,15);      			--买价
	_DefFld("BidQty_1",_String,15);        	    	--买量
	_DefFld("AskPrice_1",_String,15);  				--卖价
	_DefFld("AskQty_1",_String,15);        			--卖量
	_DefFld("BidPrice_2",_String,15);      			--买价
	_DefFld("BidQty_2",_String,15);        	    	--买量
	_DefFld("AskPrice_2",_String,15);  				--卖价
	_DefFld("AskQty_2",_String,15);        			--卖量
	_DefFld("BidPrice_3",_String,15);      			--买价
	_DefFld("BidQty_3",_String,15);        	    	--买量
	_DefFld("AskPrice_3",_String,15);  				--卖价
	_DefFld("AskQty_3",_String,15);        			--卖量
	_DefFld("BidPrice_4",_String,15);      			--买价
	_DefFld("BidQty_4",_String,15);        	    	--买量
	_DefFld("AskPrice_4",_String,15);  				--卖价
	_DefFld("AskQty_4",_String,15);        			--卖量
	_DefFld("BidPrice_5",_String,15);      			--买价
	_DefFld("BidQty_5",_String,15);        	    	--买量
	_DefFld("AskPrice_5",_String,15);  				--卖价
	_DefFld("AskQty_5",_String,15);        			--卖量
	_DefFld("UpperLimitPrice",_String,20);			--涨停价
	_DefFld("LowerLimitPrice",_String,20);			--跌停价
	_DefFld("TotalAskQty",_String,20);			--总卖量
	_DefFld("TotalBidQty",_String,20);			--总买量

	_DefKeyField("IssueCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;
_DefineEventObject InputExecution _AS _Input	--内部成交新下单接口修改
	_DefFld("IssueCode", _String, 20);
	_DefFld("BuySell", _String, 4);
	_DefFld("OpenClose", _String, 8);
	_DefFld("Price", _Number, 8);
	_DefFld("Quantity",_Int ,4);
	_DefFld("ExecDate", _String, 20);
	_DefFld("PortID", _String, 48)	;	--组合编号
_End


_DefineEventObject SetRateEvent _AS _Input
_End

_DefineEventObject SetRateInEvent _AS _Input
	_DefFld("HedgeFlag", _String, 12)--交易编码

_End
_DefineEventObject SetRateEventData _AS _Output
	_DefFld("BuyRatio", _String, 12)--中金所买入佣金费率
	_DefFld("SellRatio", _String, 12)--中金所卖出佣金费率
	_DefFld("BuyTCloseRatio", _String, 12)--中金所买入平今仓
	_DefFld("SellTCloseRatio", _String, 12)--中金所卖出平今仓
	_DefFld("BuyHCloseRatio", _String, 12)--中金所买入平历史仓
	_DefFld("SellHCloseRatio", _String, 12)--中金所买入平历史仓
	_DefFld("BalanceRatio", _String, 12)--中金所保证金比例
	_DefFld("FundYearRate", _String, 12)--中金所资金年利率
	_DefFld("HedgeFlag", _String, 12)--交易编码

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
---------------------------期货相关表Begin---------------------------
--期货建仓表
_DefineEventObject FutureOpenPosTable _AS _Output
	_DefFld("IssueCode", _String, 15)
	_DefFld("Rose", _String, 10)
	_DefFld("LastPrice", _String, 15)
	_DefFld("BuySell", _String, 8)
	_DefFld("OpenClose", _String, 8)
	_DefFld("FuturePrice", _String, 15)
	_DefFld("EntrustPrice", _String, 15)
	_DefFld("EntrustQty", _String, 10)
	_DefFld("DealQty", _String, 10)
	_DefFld("DealPrice", _String, 15)

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--期货平仓表
_DefineEventObject FutureClosePosTable _AS _Output
	_DefFld("IssueCode", _String, 15)
	_DefFld("Rose", _String, 10)
	_DefFld("LastPrice", _String, 15)
	_DefFld("BuySell", _String, 8)
	_DefFld("OpenClose", _String, 8)
	_DefFld("FuturePrice", _String, 15)
	_DefFld("EntrustPrice", _String, 15)
	_DefFld("EntrustQty", _String, 10)
	_DefFld("DealQty", _String, 10)
	_DefFld("DealPrice", _String, 15)

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

_DefineEventObject CombinList _AS _Output
	_DefFld("CombinCode", _String, 100)				--组合号
	_DefFld("InvestorID", _String, 30)				--资金账号
	_DefFld("Issue1", _String, 15)					--多头合约
	_DefFld("Issue2", _String, 15)					--空头合约
	_DefFld("Status", _String, 20)					--交易状态
	_DefFld("AvlQty", _String, 10)					--建仓份数
	_DefFld("BuyQty", _String, 10)					--多头数量
	_DefFld("SellQty", _String, 10)					--空头数量
	_DefFld("InPrice", _String, 10)					--入市价差
	_DefFld("OutPrice", _String, 10)				--平仓价差
	_DefFld("ValuationPL", _String, 15)				--浮动盈亏
	_DefFld("Fare", _String, 10)					--手续费
	_DefFld("clear", _String, 1)					--showFlag
	_DefFld("StopFlag", _String, 20)				--止盈止损开关

	_DefKeyField("CombinCode")
	_SetBufferedFlag(2)
_End

_DefineEventObject SaveCombinDataEvent _AS _Output
	_DefFld("CombinCode", _String, 100)				--组合号
	_DefFld("InvestorID", _String, 30)				--资金账号
	_DefFld("Issue1", _String, 15)					--多头合约
	_DefFld("Issue2", _String, 15)					--空头合约
	_DefFld("Status", _String, 20)					--交易状态
	_DefFld("AvlQty", _String, 10)					--建仓份数
	_DefFld("BuyQty", _String, 10)					--多头数量
	_DefFld("SellQty", _String, 10)					--空头数量
	_DefFld("InPrice", _String, 10)					--入市价差
	_DefFld("OutPrice", _String, 10)				--平仓价差
	_DefFld("buyOutAmount", _String, 10)
	_DefFld("buyOutQty", _String, 10)
	_DefFld("sellOutAmount", _String, 10)
	_DefFld("sellOutQty", _String, 10)
	_DefFld("ValuationPL", _String, 15)				--浮动盈亏
	_DefFld("Fare", _String, 10)					--手续费

	_DefKeyField("CombinCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End
--委托表
_DefineEventObject FutureOrderEvent _AS _Output
	_DefFld("PortID", _String, 25)					--组合号
	_DefFld("CorpCode", _String, 25)				--委托号
	_DefFld("IssueCode", _String, 15)				--合约
	_DefFld("BuySell", _String, 8)					--买卖
	_DefFld("OpenClose", _String, 8)				--开平
	_DefFld("EntrustPrice", _String, 15)     		--委托价格
	_DefFld("EntrustQty", _String, 10)				--委托手数
	_DefFld("Status", _String, 20)					--委托状态
	_DefFld("DealPrice",_String,10)					--成交价
	_DefFld("DealQty",_String,10)					--成交手数
	_DefFld("WorkingQty", _String, 10)				--挂单数量
	_DefFld("CancellationQty", _String, 10)			--撤单数量
	_DefFld("BatchNumber", _String, 12)				--批号
	_DefFld("Date", _String, 40)         			--交易时间
	_DefFld("InvestorID", _String, 30)
	_DefFld("HedgeFlag", _String, 30)
	_DefFld("Flag", _String, 500)

	_DefFld("StatusFlag", _String, 1)				--1:可撤委托

	_DefKeyField("CorpCode")
	_SetBufferedFlag(2)
_End

--成交表
_DefineEventObject FutureExecuteEvent _AS _Output
	_DefFld("PortID", _String, 25)					--组合号
	_DefFld("CorpCode", _String, 25)
	_DefFld("ExecNo", _String, 25)
	_DefFld("Date", _String, 40)
	_DefFld("IssueCode", _String, 15)
	_DefFld("BuySell", _String, 10)
	_DefFld("OpenClose", _String, 10)
	_DefFld("DealQty", _String, 25)
	_DefFld("DealPrice", _String, 20)
	_DefFld("CancellationQty", _String, 25)
	_DefFld("OrderAcceptNo", _String, 25)
	_DefFld("Status", _String, 20)
	_DefFld("InvestorID", _String, 30)
	_DefFld("HedgeFlag", _String, 30)

	_DefKeyField("CorpCode")
	_DefKeyField("ExecNo")
	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End



--套利持仓表
_DefineEventObject FutureArbitragePosInfo _AS _Output
	_DefFld("CombinCode",_String ,100);			--组合编码
	_DefFld("BAMapID", _String, 20);			--BAmapID
	_DefFld("IssueCode",_String, 20);			--代码
	_DefFld("Position", _String, 25)
	_DefFld("AvlQty", _String, 25)
	_DefFld("AverageCost", _String, 25)
	_DefFld("Rose", _String, 25)
	_DefFld("BuySell", _String, 25)
	_DefFld("ValuationPL", _String, 25)
	_DefFld("LastPrice", _String, 25)
	_DefFld("InvestorID", _String, 30)

	_DefFld("UniqueKeyCode", _String, 100);		--标记Key
	_DefFld("MainRowFlag", _String, 1);			--传1表示是折叠列表中的主行，2表示副行
	_DefFld("clear", _String, 1);				--showFlag

	_DefKeyField("UniqueKeyCode")
	_SetBufferedFlag(2)
	_SetDataType(_EventOtherType);
_End

--持仓信息表
_DefineEventObject CombineInfoPosition _AS _Output
	_DefFld("IsChecked", _String, 1)				--勾选
	_DefFld("IssueCode", _String, 15)				--合约
	_DefFld("HaveQty", _String, 10)					--拥股数量
	_DefFld("AvlQty", _String, 10)					--可用数量
	_DefFld("CanFundNo", _String, 15)				--可申赎数
	_DefFld("CostPrice", _String, 15)				--成本价
	_DefFld("LastPrice", _String, 15)				--现价
	_DefFld("MarketValue", _String, 15)				--市值
	_DefFld("FloatStatus", _String, 15)				--浮动盈亏
	_DefFld("ProfitAndLoss", _String, 15)			--盈亏比
	_DefFld("Market", _String, 10)					--市场
	_DefFld("ShareholderNo", _String, 15)			--股东代码
	_DefFld("TodayBuyQty", _String, 10)				--当日买入数量
	_DefFld("TodaySellQty", _String, 10)			--当日卖出数量

	_DefKeyField("IssueCode")
	_SetBufferedFlag(2)
_End

--发送柜台持仓信息显示
_DefineEventObject FutCombinPos _AS _Output
	_DefFld("InvestorID", _String, 30)
	_DefFld("BuySell", _String, 30)
	_DefFld("IssueName", _String, 30)
	_DefFld("IssueCode", _String, 20)
	_DefFld("MarketType", _String, 20)
	_DefFld("Quantity", _String, 30)
	_DefFld("AvQty", _String, 30)
	_DefFld("AvSellQty", _String, 30)
	_DefFld("AvePrice", _String, 30)
	_DefFld("Margin", _String, 30)
	_DefFld("PL", _String, 30)
	_DefFld("HedgeType", _String, 10)
	_DefFld("CostValue", _String, 30)

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--勾选持仓
_DefineEventObject InputPositionCheck _AS _Input
	_DefFld("IssueCode", _String, 8)
	_DefFld("IsChecked", _String, 1);
_End

_DefineEventObject k1dEvent _AS _Output
	_DefFld("Date",_String ,8);	--日期
	_DefFld("Time",_String ,6);	--时间
	_DefFld("DateTime",_String ,14); --内部时间Key
	_DefFld("OpenPrice",_String,8); --开盘价
	_DefFld("HighPrice",_String,8); --最高价
	_DefFld("LowPrice",_String,8); --最低价
	_DefFld("ClosePrice",_String,8); --收盘价
	_DefFld("Volume",_String,15); --成交量
	_DefFld("OpenInterest",_String,15); --持仓量
	_DefFld("ClearingPrice",_String,8); --结算价
	_DefFld("IssueCode",_String ,9); --代码
	_DefFld("MarketCode",_String,1); --市场
	_DefFld("Amount",_String,15); --成交额
	_DefFld("Zero",_String,4); --0 内部画图参考用
	_DefFld("BidPrice",_String,8);  --卖价
	_DefFld("AskPrice",_String,8);  --买价

	_DefKeyField("IssueCode");
	_DefKeyField("MarketCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventDayType);
_End
_DefineEventObject k1mEvent _AS _Output
	_DefFld("Date",_String ,8);
	_DefFld("Time",_String ,6);
	_DefFld("DateTime",_String ,14);
	_DefFld("OpenPrice",_String,8);
	_DefFld("HighPrice",_String,8);
	_DefFld("LowPrice",_String,8);
	_DefFld("ClosePrice",_String,8);
	_DefFld("Volume",_String,15);
	_DefFld("OpenInterest",_String,15);
	_DefFld("ClearingPrice",_String,8);
	_DefFld("IssueCode",_String ,9);
	_DefFld("MarketCode",_String,1);
	_DefFld("Amount",_String,15);
	_DefFld("Zero",_Int,4);
	_DefFld("BidPrice",_String,8);  --ZZ
	_DefFld("AskPrice",_String,8);  --ZZ
	_DefFld("Seq", _Int, 4)

	_DefKeyField("Date");
	_DefKeyField("IssueCode");
	_DefKeyField("MarketCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventMinuteType);
	_SetDataInterval(1);
_End;

--快捷锁仓
_DefineEventObject LockOrder _AS _Input
	_DefFld("IssueCode", _String, 20);
	_DefFld("Side", _String, 20);
	_DefFld("Quantity", _Int, 8);	--持仓量

_End


--快速平仓
_DefineEventObject QuickSell _AS _Input
	_DefFld("IssueCode", _String, 20);
	_DefFld("Side", _String, 20);
	_DefFld("Quantity", _Int, 8);	--持仓量

_End

--反手委托事情定义
_DefineEventObject RrightBackHand _AS _Input
	_DefFld("Way",_String,20)
	_DefFld("IssueCode", _String, 20);
	_DefFld("Side", _String, 20);
	_DefFld("Quantity", _Int, 8);	--持仓量
	_DefFld("MoveQuantity",_Int,8)	--移动数量
	_DefFld("Price1",_String,20)
	_DefFld("Price2",_String,20)

_End
