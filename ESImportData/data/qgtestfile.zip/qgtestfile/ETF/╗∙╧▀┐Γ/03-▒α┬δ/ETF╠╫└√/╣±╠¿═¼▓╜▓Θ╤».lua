﻿--@@Version:1.00.100.20131129@@
--初始化
function initialMarketQry()
	gtMarketPosition = {}
	gtInvestorFundStatus = {}
	gtInvestorPositionInfo = {}
	gtInitStartOrderTable = {}
    gMQTradeIssueCode = ""      --摩旗下单模块查询合约

	if not gtInvestorFundStatus[spBAMapID] then
		gtInvestorFundStatus[spBAMapID] = {}
	end
	gtInvestorFundStatus[spBAMapID].AvlFund = 0
	gtInvestorFundStatus[spBAMapID].TotalFund = 0
	gtInvestorFundStatus[spBAMapID].ForzenAmount = 0
	gtInvestorFundStatus[spBAMapID].PostBalance = 0
    gETFPositionSyncFlag = false
	if spInvestorMode == 1 then
		_StartTimer(_TimerName = "RefreshAccountFundTimer",_Interval = 5000)
	end
end


--【刷新帐户】的按钮事件

_DefineEventObject RefreshAccountFromMarketEvent _AS _Input
	_DefFld("RefreshFlag",_String,20)
_End

--【刷新帐户】回调，调用RefreshAccountFromMarket函数
_OnEventDefined(RefreshAccountFromMarketEvent evt)
	local refreshFlag = evt._GetFld("RefreshFlag")
	sendLog("刷新持仓")
	if spInvestorMode == 1 then
		RefreshAccountFromMarket()
	else
		ShowQryPosition()
		ShowQryAvlFund()
	end
_End

--进行帐户资金和持仓全局变量刷新
function RefreshAccountFromMarket()
	local BAMapID = spBAMapID
	local accountCode = _PosBAMapAccount[BAMapID]
	local ClientID = _PosFundStatus[accountCode].ClientID
	local InvestorID = _PosClient[ClientID].InvestorID

	L2CQueryMarket(InvestorID, ClientID, BAMapID, "", "Fund")
	gtMarketPosition[InvestorID] = {}
	gContinueQryMarketFlag = false
	L2CQueryMarket(InvestorID, ClientID, BAMapID, "", "Position")
end



--查询资金和柜台的统一接口
function L2CQueryMarket(InvestorID, ClientID, BAMapID, IssueCode, BusinessType)
    if spInvestorMode == 1 then
        if BusinessType == "Fund" then
            L2CQueryMarketFund()
        elseif BusinessType == "Position" then
            L2CQueryMarketPosition(IssueCode)
        end
    else
        if BusinessType == "Fund" then
            L2CQueryPosLibFund(InvestorID, ClientID, BAMapID)
        elseif BusinessType == "Position" then
            L2CQueryPosLibPosition(InvestorID, ClientID,BAMapID,IssueCode)
        end
    end
end

--将持仓库的_PosFundStatus变量值，赋值给gtInvestorFundStatus
function L2CQueryPosLibFund(InvestorID, ClientID, BAMapID)
	local accountCode = _PosBAMapAccount[BAMapID]
	local fundStatus = _PosFundStatus[accountCode]
	if not gtInvestorFundStatus then
		gtInvestorFundStatus = {}
	end
	gtInvestorFundStatus[InvestorID].AvlFund = fundStatus.AvlFund
end


--将持仓库的_PosPositionTable变量对应字段值，赋值给gtInvestorPositionInfo
function L2CQueryPosLibPosition(InvestorID, ClientID,BAMapID,IssueCode)
	if not gtInvestorPositionInfo[IssueCode] then
		gtInvestorPositionInfo[IssueCode] = {}
	end
	for posKey,position in pairs(_PosPositionTable)do
		if position.BAMapID == BAMapID and position.IssueCode == IssueCode then
			gtInvestorPositionInfo[IssueCode].Quantity = position.Quantity
			gtInvestorPositionInfo[IssueCode].AvlQuantity = position.AvlQuantity
			gtInvestorPositionInfo[IssueCode].AvlCreRedQuantity = position.AvlCreRedQuantity
			gtInvestorPositionInfo[IssueCode].WorkingQtyOfOpen = position.WorkingQtyOfOpen
			gtInvestorPositionInfo[IssueCode].WorkingQtyOfClose = position.WorkingQtyOfClose
			gtInvestorPositionInfo[IssueCode].ValuationPL = position.ValuationPL
		end
	end
end


--调用_QryMarket函数，第一个参数为："Fund_SQZH"，设置资金查询请求字段信息，并发送查询请求。
function L2CQueryMarketFund()
	local BusinessType = "Fund"

	local BAMapID = spBAMapID
	local accountCode = _PosBAMapAccount[BAMapID]
	local clientID = _PosFundStatus[accountCode].ClientID
	local investorID = _PosClient[clientID].InvestorID
	local passWord = _GetInvestorPWD(BAMapID)

	local log = sys_format("当前证券账号: ClientID=%s, InvestorID=%s 的资金信息处于请求状态",clientID, investorID)
	--_WriteDebugLog(log)

	--local SUBJECT = "TEST"
	local DTSSubmitEvent qryFundEvent;
	--消息头
	qryFundEvent.setField("MessageType","Q13") 		--客户资金查询
	qryFundEvent.setField("InvestorID",investorID) --资金帐号
	qryFundEvent.setField("Password",passWord)       --密码
	qryFundEvent.setField("WorkstationNo","660")   	--默认本机
	--New Add
	qryFundEvent.setField("ClientID",clientID)   	--加入总账户信息

	--消息体
	local DTSSubmitEvent queryList
	local DTSSubmitEvent query1
	query1.setField("function_id","KHZJLS")     --功能号KHZJLS
	queryList.append(query1)
	qryFundEvent.spliceArray("MessageDetail", queryList)
	_QryMarket("Fund_JZZQ",qryFundEvent)


	--local ret = QueryMarket(InvestorID,ClientID,BAMapID, "", BusinessType)
end

--调用_QryMarket函数，第一个参数为："Pos_SQZH"，设置资金查询请求字段信息，并发送查询请求。
function L2CQueryMarketPosition(IssueCode)
	--local BusinessType = "Position"
	local BAMapID = spBAMapID
	local accountCode = _PosBAMapAccount[BAMapID]
	local ClientID = _PosFundStatus[accountCode].ClientID
	local InvestorID = _PosClient[ClientID].InvestorID

	--local ret = QueryMarket(InvestorID,ClientID,BAMapID, "", BusinessType)
	local type = _PosClient[ClientID].Type
	local passWord = _GetInvestorPWD(BAMapID)


	local DTSSubmitEvent qryPosEvent;
	qryPosEvent.setField("MessageType","Q14") 		--客户持仓查询
	qryPosEvent.setField("InvestorID",InvestorID) --资金帐号
	qryPosEvent.setField("Password",passWord)       --密码
	qryPosEvent.setField("WorkstationNo","660")   	--默认本机
	--New Add
	qryPosEvent.setField("ClientID",ClientID)   	--加入总账户信息

	--消息体
	local DTSSubmitEvent queryList
	local DTSSubmitEvent query1
	query1.setField("function_id","KHCCLS")     --功能号

	--local SUBJECT = "TEST"
	--Set IssueCode 单个合约查询，issueCode为空时查所有持仓
	query1.setField("issue_code",IssueCode)     --功能号
	queryList.append(query1)
	qryPosEvent.spliceArray("MessageDetail", queryList)
	_QryMarket("Pos_JZZQ",qryPosEvent)
end


--资金查询回调返回，将返回信息设置fundList后，调用L2cOnQueryMarketFund(fundList)函数
_OnQryMarketResult("Fund_JZZQ",DTSSubmitEvent rplEvt)
	local encode = rplEvt.encode()
	local startLog = sys_format("******柜台资金查询 Fund_JZZQ Start :encode = [%s]*******",encode)
	_WriteAplLog(startLog)

	local clientMessageID = rplEvt.getField("ClientMessageID")
	--_WriteDebugLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	--_WriteDebugLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	--_WriteDebugLog(clientID)

	if investorID and investorID ~= "" then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
		--rplEvt.getFirstField(fieldname, topField)
		while not rplEvt.eof() do
			if topField.isArray() then --MessageDetail
				--for index = 0, topField.size(), 1 do
				local index = 0
				local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
				--_WriteDebugLog(log)

				local DTSSubmitEvent rplMsg = topField.getSubMessage(index)

				local error_no= rplMsg.getField("error_no")
				local error_msg = rplMsg.getField("error_msg")
				log = sys_format("Qry Fund_JZZQ :error_no=%d,error_msg=%s",error_no,error_msg)
				--_WriteDebugLog(log)

				local flag = 0
				if not error_msg then
					flag  = 1
				elseif error_msg == "" then
					flag  = 1
				end

				if flag == 1 then
					local available_balance = rplMsg.getField("available_balance");     --可用资金
					local post_balance      = rplMsg.getField("post_balance");          --帐户余额
					local frozen_amount     = rplMsg.getField("frozen_amount");         --冻结金额
					local fetch_balance     = rplMsg.getField("fetch_balance");         --可取资金
					local total_balance     = rplMsg.getField("total_balance");         --总资产

					local fundList = {}
					fundList.clientMessageID    = clientMessageID
					fundList.clientID           = clientID
					fundList.investorID         = investorID
					fundList.post_balance       = FormatNumberValue(post_balance)
					fundList.frozen_amount      = FormatNumberValue(frozen_amount)
					fundList.available_balance  = FormatNumberValue(available_balance)
					fundList.fetch_balance      = FormatNumberValue(fetch_balance)
					fundList.total_balance      = FormatNumberValue(total_balance)

					--L2cOnQueryMarket("Fund",fund)

					L2COnQueryMarketFund(fundList)
					log = sys_format("当前证券账号: ClientID=%s, InvestorID=%s 的资金信息处于已回复状态",clientID, investorID)
					--_WriteDebugLog(log)
				else
					log = sys_format("Qry Fund_JZZQ Failed :error_no=%d,error_msg=%s",error_no,error_msg)
					--_WriteDebugLog(log)
				end
				--end
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				--_WriteDebugLog(logstr)
			end

			--if not rplEvt.getNextField(fieldname, topField) then
				break
			--end
		end
	else
		--_WriteDebugLog("Fund_SQZH:未获取到投资者账户")
	end
	_WriteAplLog("******柜台资金查询Pos_JZZQ End********")
_End

--持仓查询回调返回，将返回信息设置positionList后，调用L2cOnQueryMarketPosition(positionList)函数
_OnQryMarketResult("Pos_JZZQ",DTSSubmitEvent rplEvt)
	local encode = rplEvt.encode()
	local startLog = sys_format("******柜台持仓查询Pos_JZZQ Start :encode = [%s]*******",encode)
	_WriteAplLog(startLog)
    local clientMessageID = rplEvt.getField("ClientMessageID")
	--_WriteDebugLog(clientMessageID)
	local investorID = rplEvt.getField("InvestorID")
	--_WriteDebugLog(investorID)
	local clientID = rplEvt.getField("ClientID")
	--_WriteDebugLog(clientID)

	local onQryFlag = true
	if investorID and investorID ~= "" then
		local fieldname = "MessageDetail"
		local DTSSubmitEvent topField = rplEvt.getSubMessage(fieldname)
		--rplEvt.getFirstField(fieldname, topField)
		while not rplEvt.eof() do
			if topField.isArray() then --MessageDetail
			    local InvestorID = ""
				for index = 0, topField.size()-1, 1 do
					local log = sys_format("index=%s, clientMessageID=%s",index, clientMessageID)
					--_WriteAplLog(log)
					--_WriteDebugLog(log)

					local DTSSubmitEvent rplMsg = topField.getSubMessage(index)

					local error_no= rplMsg.getField("error_no")
					local error_msg = rplMsg.getField("error_msg")
					log = sys_format("Qry Pos_JZZQ :error_no=%d,error_msg=%s",error_no,error_msg)
					--_WriteAplLog(log)
					--_WriteDebugLog(log)

					local flag = 0
					if not error_msg then
						flag  = 1
					elseif error_msg == "" then
						flag  = 1
					end
					if flag == 1 then
					    local issueCode = rplMsg.getField("issue_code")
					    if issueCode ~= false and issueCode ~= "" and issueCode ~= " " and issueCode ~= nil then
					        local issue_code	      = rplMsg.getField("issue_code")          --证券代码
                            --local issue_name = _PosIssueNameTable[issue_code]
							local issue_name	      = rplMsg.getField("issue_name")          --证券名称

                            local exchange_type	      = rplMsg.getField("exchange_type")       --交易所
                            local position_qty	      = rplMsg.getField("position_qty")        --今持仓量
							position_qty = FormatNumberValue(position_qty)

							local available_qty	      = rplMsg.getField("available_qty")       --可用数量
                            available_qty = FormatNumberValue(available_qty)

							local enable_redeem_qty	  = rplMsg.getField("enable_redeem_qty")   --可赎回数量
                            enable_redeem_qty = FormatNumberValue(enable_redeem_qty)

							local enable_report_qty	  = rplMsg.getField("enable_report_qty")   --可申购数量
                            enable_report_qty = FormatNumberValue(enable_report_qty)

							local enable_sell_qty	  = rplMsg.getField("enable_sell_qty")     --可卖出数量
                            enable_sell_qty = FormatNumberValue(enable_sell_qty)

							local pos_average_price	  = rplMsg.getField("pos_average_price")   --持仓均价
                            pos_average_price = FormatNumberValue(pos_average_price)

							local assign_cost_price	  = rplMsg.getField("assign_cost_price")   --摊薄成本价
                            assign_cost_price = FormatNumberValue(assign_cost_price)

							local margin	          = rplMsg.getField("margin")              --保证金
                            margin = FormatNumberValue(margin)

							local profit_total	      = rplMsg.getField("profit_total")        --累计盈亏
                            profit_total = FormatNumberValue(profit_total)

							local profit_float	      = rplMsg.getField("profit_float")        --浮动盈亏
                            profit_float = FormatNumberValue(profit_float)

							local entrust_bs	      = rplMsg.getField("entrust_bs")          --买卖方向
                            local insure_flag	      = rplMsg.getField("insure_flag")         --投机套保标志

							local position_cost       = rplMsg.getField("position_cost")       --持仓成本
                            position_cost = FormatNumberValue(position_cost)

							local position_str	      = rplMsg.getField("position_str")        --定位串

                            local position = {}
                            position.clientMessageID    = clientMessageID
                            position.investorID         = investorID
                            position.clientID           = clientID
                            position.issue_code	        = issue_code
                            position.issue_name	        = issue_name
                            position.exchange_type	    = exchange_type
                            position.position_qty	    = position_qty
                            position.available_qty	    = available_qty
                            position.enable_redeem_qty	= enable_redeem_qty
                            position.enable_report_qty	= enable_report_qty
                            position.enable_sell_qty	= enable_sell_qty
                            position.pos_average_price	= pos_average_price
                            position.assign_cost_price	= assign_cost_price
                            position.margin	            = margin
                            position.profit_total	    = profit_total
                            position.profit_float	    = profit_float
                            position.entrust_bs	        = entrust_bs
                            position.insure_flag	    = insure_flag
                            position.position_cost      = position_cost
                            position.position_str	    = position_str

							local pLog = sys_format("Get Qry Issue = %s,investorID = %s,clientID = %s,position_qty = %s,available_qty = %s,enable_redeem_qty = %s,enable_report_qty = %s",issue_code,investorID,clientID,position_qty,available_qty,enable_redeem_qty,enable_report_qty)
							_WriteAplLog(pLog)

							--柜台查询持仓赋值给gtMarketPosition

							if not 	gtMarketPosition then
								gtMarketPosition  = {}
							end
							InvestorID = investorID
							if not gtMarketPosition[InvestorID] then
								gtMarketPosition[InvestorID] = {}
							end
							if not gtMarketPosition[InvestorID][issue_code] then
								gtMarketPosition[InvestorID][issue_code] = {}
								gtMarketPosition[InvestorID][issue_code].issue_code = issue_code
							end

							gtMarketPosition[InvestorID][issue_code].Quantity = position_qty --总持仓
							gtMarketPosition[InvestorID][issue_code].ValuationPL = profit_float --收益
							gtMarketPosition[InvestorID][issue_code].AvlQuantity = 	available_qty--可用数量
                            gtMarketPosition[InvestorID][issue_code].AvlCreRedQuantity = enable_redeem_qty--可赎回数量
							--可申赎数量
							if enable_report_qty.getNumberValue() > 0 then
								gtMarketPosition[InvestorID][issue_code].AvlCreRedQuantity = enable_report_qty--可申购数量
							end
							L2COnQueryMarketPosition(position)
                            --sys_insert(positionList, position)
					    end
					else
						log = sys_format("Qry Pos_JZZQ :error_no=%d,error_msg=%s",error_no,error_msg)
						--_WriteDebugLog(log)
					end
				end

				if topField.size() == spRequestNum then
					if not gContinueQryMarketFlag then
						 _StartTimer(_TimerName="ContinueQryMarketPos",_Interval=1000, _MaxNumber=1)
						 gContinueQryMarketFlag = true
					end
				else
					if gContinueQryMarketFlag then
						_StopTimer(_TimerName="ContinueQryMarketPos")
					end
					gContinueQryMarketFlag = false
                    if topField.size() == 1 and gETFPositionSyncFlag then
                        --ETF赎回,查询单个ETF的持仓时,不需要删除其他股票的持仓数据.
                        gETFPositionSyncFlag = false
                    else
                        RemoveInvalidPosition()
                    end
				end
			else
				local logstr = sys_format("%s[%d]:%s",fieldname,topField.type(),topField.asCommon().toString())
				--_WriteDebugLog(logstr)
			end

			--if not rplEvt.getNextField(fieldname, topField) then
				break
			--end
		end
		local log = sys_format("当前期货账号: ClientID=%s, InvestorID=%s 的柜台持仓信息处于已回复状态", clientID, investorID)
		--_WriteDebugLog(log)
	else
		--_WriteDebugLog("Pos_SQZH:未获取到柜台投资者持仓")
	end
	_WriteAplLog("******柜台持仓查询Pos_JZZQ End******")
_End

--返回格式化后数据
function FormatNumberValue(number)
	local returnValue = 0
	if number ~= "" and number ~= nil and number ~= false then
		returnValue = number
	end
	return returnValue
end

--将返回的fundList，设置到gtInvestorFundStatus
function L2COnQueryMarketFund(fundList)
	local avlFund = fundList.available_balance --可用资金
	local postBalance = fundList.post_balance --帐户余额
	local forzenAmount = fundList.frozen_amount	--冻结金额
    local fetchBalance = fundList.fetch_balance--可取资金
	local totalBalance = fundList.total_balance--总资产


	local baMapID = spBAMapID
	if not gtInvestorFundStatus[baMapID] then
		gtInvestorFundStatus[baMapID] = {}
	end
	gtInvestorFundStatus[baMapID].AvlFund = avlFund
	gtInvestorFundStatus[baMapID].TotalFund = totalBalance
	gtInvestorFundStatus[baMapID].ForzenAmount = forzenAmount
	gtInvestorFundStatus[baMapID].PostBalance = postBalance
	ShowQryAvlFund()

end

function _ETFCalcAvlQty(pos)
--	pos.AvlTodayQuantity = sys_max(pos.TodayCreQuantity - pos.TodayCloseQuantity - pos.WorkingQtyOfClose, 0)
	pos.AvlTodayQuantity = pos.TodayCreQuantity - pos.TodayCloseQuantity - pos.WorkingQtyOfClose
--	pos.AvlTodayCreRedQuantity = sys_max(pos.TodayOpenQuantity - pos.TodayRedQuantity, 0)
	pos.AvlTodayCreRedQuantity = pos.TodayOpenQuantity - pos.TodayRedQuantity
	pos.AvlQuantity = pos.AvlPrevQuantity + pos.AvlTodayQuantity + pos.DeltaMarketWorkingQtyOfClose
	pos.AvlCreRedQuantity = pos.AvlPrevAvlCreRedQuantity + pos.AvlTodayCreRedQuantity + pos.DeltaMarketWorkingQtyOfRed

    local log = sys_format("_ETFCalcAvlQty IssueCode:%s,AvlTodayQuantity:%d,AvlTodayCreRedQuantity%d,AvlQuantity:%d,AvlCreRedQuantity:%d",pos.IssueCode,pos.AvlTodayQuantity,pos.AvlTodayCreRedQuantity,pos.AvlQuantity,pos.AvlCreRedQuantity)
    _WriteAplLog(log)
    --------------------------
    InvestorIssuePositionChange(pos.IssueCode)

end

--持仓变化，更新持仓信息
function InvestorIssuePositionChange(IssueCode)
    if gETFName ~= "" then
		if _ETFName2IssueTable[gETFName] == IssueCode then
			sendEtfInfoToClient(gETFName,gTradeUnitQty);
        else
			if _ETFComponentTable[gETFName] then
				if _ETFComponentTable[gETFName][IssueCode] then
					RefreshSingleIssueTradeInfo(IssueCode)
				end
			end
        end
    end
    --下单模块更新
    MarketsendFundReply(IssueCode)
    --持仓表更新
    ShowSingleQryPosition(IssueCode)
end


--将返回的positionList，设置到gtInvestorPositionInfo
--调用SyncIssueMarketPosition(positionList)，设置和gtInvestorPositionInfo持仓数据
--刷新画面ETF的持仓信息
--重新计算生成最新的gtETFComponentTradeInfo变量，刷新画面ETF成分股相关信息。
function L2COnQueryMarketPosition(positionList)
	--local InvestorID = positionList.investorID
	local baMapID = spBAMapID
	local accountCode = _PosBAMapAccount[baMapID]
	local clientID = _PosFundStatus[accountCode].ClientID
	local investorID = _PosClient[clientID].InvestorID


	if positionList then
		SyncIssueMarketPosition(positionList)
	end
end

--将柜台返回的合约持仓，更新至gtInvestorPositionInfo。
function SyncIssueMarketPosition(positionList)
	local issueCode = positionList.issue_code
	local DeltaMarketWorkingQtyOfClose =0
	local DeltaMarketWorkingQtyOfRed = 0
	local AvlPrevQuantity = 0
	local AvlPrevAvlCreRedQuantity = 0
	local WorkingQtyOfClose = 0
	local avlCreRedQuantity = positionList.enable_redeem_qty    --可赎回数量

	if positionList.enable_report_qty.getNumberValue() > 0 then
		avlCreRedQuantity = positionList.enable_report_qty--可申购数量
	end

	if gtInvestorPositionInfo[issueCode] ~= nil then
		DeltaMarketWorkingQtyOfClose = positionList.available_qty - gtInvestorPositionInfo[issueCode].AvlQuantity + gtInvestorPositionInfo[issueCode].WorkingQtyOfClose
		DeltaMarketWorkingQtyOfRed = avlCreRedQuantity - gtInvestorPositionInfo[issueCode].AvlCreRedQuantity

		AvlPrevQuantity = gtInvestorPositionInfo[issueCode].AvlQuantity
		AvlPrevAvlCreRedQuantity = gtInvestorPositionInfo[issueCode].AvlCreRedQuantity
		WorkingQtyOfClose = gtInvestorPositionInfo[issueCode].WorkingQtyOfClose
    else
        AvlPrevQuantity = positionList.available_qty
        AvlPrevAvlCreRedQuantity = avlCreRedQuantity
	end

	AddInitInvestorPositionInfo(issueCode)
	gtInvestorPositionInfo[issueCode].IssueName = positionList.issue_name
	gtInvestorPositionInfo[issueCode].DeltaMarketWorkingQtyOfClose = DeltaMarketWorkingQtyOfClose
	gtInvestorPositionInfo[issueCode].DeltaMarketWorkingQtyOfRed = DeltaMarketWorkingQtyOfRed
	gtInvestorPositionInfo[issueCode].WorkingQtyOfClose = WorkingQtyOfClose
	gtInvestorPositionInfo[issueCode].AvlPrevQuantity = AvlPrevQuantity
	gtInvestorPositionInfo[issueCode].AvlPrevAvlCreRedQuantity = AvlPrevAvlCreRedQuantity
	_ETFCalcAvlQty(gtInvestorPositionInfo[issueCode])
end


--成份股持仓初始化gtInvestorPositionInfo[issueCode]
function AddInitInvestorPositionInfo(issueCode)
	gtInvestorPositionInfo[issueCode] = gtInvestorPositionInfo[issueCode] or {}
    gtInvestorPositionInfo[issueCode].IssueCode = issueCode
	gtInvestorPositionInfo[issueCode].Quantity = 0
	gtInvestorPositionInfo[issueCode].AvlTodayQuantity = 0
	gtInvestorPositionInfo[issueCode].TodayCreQuantity = 0
	gtInvestorPositionInfo[issueCode].TodayCloseQuantity = 0
	gtInvestorPositionInfo[issueCode].WorkingQtyOfClose = 0
	gtInvestorPositionInfo[issueCode].AvlTodayCreRedQuantity = 0
	gtInvestorPositionInfo[issueCode].TodayOpenQuantity = 0
	gtInvestorPositionInfo[issueCode].TodayRedQuantity = 0
	gtInvestorPositionInfo[issueCode].AvlQuantity = 0
	gtInvestorPositionInfo[issueCode].AvlPrevQuantity = 0
	gtInvestorPositionInfo[issueCode].DeltaMarketWorkingQtyOfClose = 0
	gtInvestorPositionInfo[issueCode].AvlCreRedQuantity = 0
	gtInvestorPositionInfo[issueCode].AvlPrevAvlCreRedQuantity = 0
	gtInvestorPositionInfo[issueCode].DeltaMarketWorkingQtyOfRed = 0
end

--遍历gtInvestorPositionInfo,如果在gtMarketPosition内没有记录，则删除对应的gtInvestorPositionInfo无效持仓信息。
function RemoveInvalidPosition()
	local baMapID = spBAMapID
	local accountCode = _PosBAMapAccount[baMapID]
	local clientID = _PosFundStatus[accountCode].ClientID
	local investorID = _PosClient[clientID].InvestorID
    if gtMarketPosition[investorID] == nil then
		gtInvestorPositionInfo = {}
    else
        for issueCode,value in pairs(gtInvestorPositionInfo) do
            if gtMarketPosition[investorID][issueCode] == nil then
                local log = sys_format("Remove Data ,issueCode = %s",issueCode)
                _WriteAplLog(log)
                gtInvestorPositionInfo[issueCode] = nil
                InvestorIssuePositionChange(issueCode)
            end
        end
    end
end

_OnEventTimer(_TimerName = "ContinueQryMarketPos")
	local BAMapID = spBAMapID
	local accountCode = _PosBAMapAccount[BAMapID]
	local ClientID = _PosFundStatus[accountCode].ClientID
	local InvestorID = _PosClient[ClientID].InvestorID
	L2CQueryMarket(InvestorID, ClientID, BAMapID, "", "Position")
_End

--每5秒触发一次定时器,定时查询帐户资金和更新虚拟头寸预估利润
_OnEventTimer(_TimerName = "RefreshAccountFundTimer")
    RefreshAccountFund()
    RefreshVirtualTaskProfit()
_End

--查询帐户资金
function RefreshAccountFund()
	local BAMapID = spBAMapID
	local accountCode = _PosBAMapAccount[BAMapID]
	local ClientID = _PosFundStatus[accountCode].ClientID
	local InvestorID = _PosClient[ClientID].InvestorID
	if gOrderExecFlag then
		L2CQueryMarket(InvestorID, ClientID, BAMapID,"", "Fund")
		gOrderExecFlag = false
	end
end


function OnExec(exec,pos)
	if _PosStatus == POS_STATUS_INIT then
		return
	end
	local IssueCode = exec.IssueCode
	local BAMapID = spBAMapID
	local accountCode = _PosBAMapAccount[BAMapID]
	local ClientID = _PosFundStatus[accountCode].ClientID
	local InvestorID = _PosClient[ClientID].InvestorID
    local CorpCode = exec.CorpCode

	if not gtInvestorPositionInfo[IssueCode] then
		AddInitInvestorPositionInfo(IssueCode)
	end

	local baSubID = pos.BASubID
	local posBS = sys_sub(baSubID, 1, 1)
	local position = gtInvestorPositionInfo[IssueCode]
    local log = sys_format("----_ETFCalcAvlQty position.TodayOpenQuantity:%d,%d,%d,%d",position.TodayOpenQuantity,position.TodayCreQuantity,position.TodayCloseQuantity,position.TodayRedQuantity)
       _WriteAplLog(log)

	if exec.BS == posBS then --开仓
		if exec.CreRed == 0 then
			position.TodayOpenQuantity = position.TodayOpenQuantity + exec.Quantity
		elseif exec.CreRed == 1 or exec.CreRed == 2 then
			position.TodayCreQuantity = position.TodayCreQuantity + exec.Quantity
		end
	else --平仓
		if exec.CreRed == 0 then
            if gtInitStartOrderTable[IssueCode] == nil or gtInitStartOrderTable[IssueCode][CorpCode] == nil then
                position.TodayCloseQuantity = position.TodayCloseQuantity + exec.Quantity
            end

		elseif exec.CreRed == 1 or exec.CreRed == 2 then
			position.TodayRedQuantity = position.TodayRedQuantity + exec.Quantity
		end
	end
	if exec.CreRed == 2 and _ETFIssue2NameTable[IssueCode] then    --ETF赎回，ETF可用数查询
        gETFPositionSyncFlag = true
		L2CQueryMarket(InvestorID, ClientID,BAMapID,IssueCode,"Position")
	else
        log = sys_format("----_ETFCalcAvlQty position.TodayOpenQuantity:%d,%d,%d,%d",position.TodayOpenQuantity,position.TodayCreQuantity,position.TodayCloseQuantity,position.TodayRedQuantity)
        _WriteAplLog(log)

		_ETFCalcAvlQty(position)
	end
end

--买委托；撤的成交；卖的成交；申购赎回
_OnEventExecution("GetWorkingQty", {} , DTSMessageRecordAccess msg)
	local MessageType = msg.getMessageType()
	local ErrorType = msg.getErrorType()

	local DTSOrderDetailRecordAccess shmOrder = msg.getOrderDetailRecord();
	local issueCode = shmOrder.getIssueCode()

	local baSubID = shmOrder.getBASubID()
	--local StatusName =

	local BuySell = shmOrder.getBuySell()
	local baMapID = shmOrder.getBAMapID();
	local Quantity = shmOrder.getOriginalQuantity();
	local ExecutionQuantity = shmOrder.getExecutionQuantity();
	local ExecutionValue = shmOrder.getExecutionValue();
	local WorkingQuantity = shmOrder.getWorkingQuantity();
	local OrderAcceptNo = shmOrder.getOrderAcceptNo();
	local OrderTime = shmOrder.getOrderTime();
	local CancelQuantity = shmOrder.getCancelQuantity();
	local UnAcceptedQuantity = shmOrder.getUnacceptedQuantity();
	local RejectedQuantity = shmOrder.getRejectedQuantity();
	local CorpCode = shmOrder.getCorpCode();
	local BatchID = shmOrder.getTargetPrice()
	local BS = shmOrder.getBuySell()
    local posBS = sys_sub(baSubID, 1, 1)

	local order = {}
	order.CreRed = shmOrder.getGeneralInt1()
    if (POS_LOGIN_CHECK_FUT_ISSUE ~= issueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= issueCode) then
		if spBAMapID == baMapID then
	    if _PosStatus == POS_STATUS_INIT then
	        local StatusName = getOrderStatusName(Quantity, ExecutionQuantity, WorkingQuantity, CancelQuantity, RejectedQuantity, UnAcceptedQuantity)

	        --记录策略启动时挂单状态的单子
	        if StatusName == "挂单" then
	            if BuySell == "1" then
	                gtInitStartOrderTable[issueCode] = gtInitStartOrderTable[issueCode] or {}
	                gtInitStartOrderTable[issueCode][CorpCode] = true
	            end
	        else
	            if gtInitStartOrderTable[issueCode] then
					if gtInitStartOrderTable[issueCode][CorpCode] then
						gtInitStartOrderTable[issueCode][CorpCode] = nil
					end
	            end
            end
		else
			gOrderExecFlag = true
			--if order.CreRed == 0  then --平仓
			if order.CreRed == 0 and BS ~= posBS then --平仓

				if gtInvestorPositionInfo[issueCode] == nil then
					AddInitInvestorPositionInfo(issueCode)
				end
				position = gtInvestorPositionInfo[issueCode]

					if gtInitStartOrderTable[issueCode] == nil or gtInitStartOrderTable[issueCode][CorpCode] == nil then

						if ErrorType == "0" and MessageType == "L04" then
							position.WorkingQtyOfClose = position.WorkingQtyOfClose + Quantity
						else
							local DeltaWorking = 0
							if MessageType == "L07" then
								DeltaWorking = - msg.getExecutionQuantity()
							elseif MessageType == "L08" then
								DeltaWorking = - msg.getCancelAmendQuantity()
							end
							position.WorkingQtyOfClose = position.WorkingQtyOfClose + DeltaWorking
						end
						local log = sys_format("----_ETFCalcAvlQty position.WorkingQtyOfClose:%d",position.WorkingQtyOfClose)
						_WriteAplLog(log)
					else
						if MessageType == "L08" then
							position.AvlPrevQuantity = position.AvlPrevQuantity + msg.getCancelAmendQuantity()
						end
					end
					_ETFCalcAvlQty(position)
				end
			end
		end
	end
_End

