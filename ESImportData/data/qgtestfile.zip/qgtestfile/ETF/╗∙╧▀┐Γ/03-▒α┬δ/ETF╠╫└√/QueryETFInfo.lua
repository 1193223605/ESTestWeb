﻿--修改记录
--@@Version:1.03.300.20130704@@
--配合Position版本2.2支持跨市跨境ETF修改升级

--提供回调函数，供ETF或者外部策略调用
--[[
	function OnQueryETFListTable(etfListTable) end
	function OnQueryETFComponentTable(etfComponentTable) end
]]
---------------------------------------------------事件定义----------------------------------------

--ETF清单DD
_DefineEventObject ETFListTable _AS _Output
	_DefFld("ETFID",_String ,20);					--从申赎清单文件中取得的ETF标识
	_DefFld("IssueCode",_String ,20); 				--ETF合约代码
	_DefFld("CreateIssueCode",_String ,20); 		--申赎代码
	_DefFld("CashIssueCode",_String,20);			--申赎资金代码
	_DefFld("FundName",_String,30);					--基金名称
	_DefFld("FundManagementCompany",_String,30);	--基金公司
	_DefFld("UnderlyingIndex",_String,20);			--对应指数
	_DefFld("CreationRedemptionUnit",_Int,10);		--最小申赎单位
	_DefFld("EstimateCashComponent",_Number,15);	--预估现金替代金额
	_DefFld("MaxCashRatio",_Number,15);				--最大现金替代比例
	_DefFld("Publish",_String ,1);					--是否公布IOPV,(1:允许 0:禁止)
	_DefFld("Creation",_String,1);					--是否开放申购,(1:允许 0:禁止)
	_DefFld("Redemption",_String,1);				--是否可赎回,(1:允许 0:禁止)
	_DefFld("RecordNum",_Int,10);					--成份股个数
	_DefFld("TradingDay",_String,8);  				--当前交易日期
	_DefFld("CashComponent",_Number,15); 			--前日现金差额
	_DefFld("PreTradingDay",_String,8);  			--上一交易日日期
	_DefFld("NAVperCU",_Number,15);					--前日每申赎单位净值
	_DefFld("NAV",_Number,15);  					--前日每份净值
	_DefFld("DividendPerCU",_Number,15);  			--最小申购赎回单位现金红利
	
	_DefFld("CashCreationPremiumRatio",_String,20);		--未使用
	_DefFld("CashCreationSettlementRatio",_String,20);	--未使用
	_DefFld("CashCreationLimitPerUser",_Int,10);		--未使用
	_DefFld("CashCreationLimitPerPD",_String,8);  		--未使用
	_DefFld("CashCreationLimitTotal",_String,8);  		--未使用
	_DefFld("CreateTime",_String,15);					--创建时间
	
	_DefFld("Type",_String,1);  				--ETF类型(1.单市场ETF 2.跨市场ETF 3.跨境ETF)
	_DefFld("CreationLimit",_Number,15);  		--当天累计可申购的基金份额上限，为 0 表示没有限制
	_DefFld("RedemptionLimit",_Number,15);  	--当天累 计可赎回的基金份额上限，为 0 表示没有限制

	_DefKeyField("ETFID");
	_DefKeyField("TradingDay");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

--ETF成分股清单DD
_DefineEventObject ETFComponentTable _AS _Output
	_DefFld("ETFID",_String ,20);			--ETFID
	_DefFld("TradingDay",_String ,8);		--时间
	_DefFld("IssueCode",_String ,20); 		--股票代码
	_DefFld("IssueName",_String ,20); 		--股票名称
	_DefFld("Quantity",_Number,15); 		--成分股数量
	_DefFld("CanCashRepl",_String,1); 		--现金替代标志0:禁止替代,1:允许替代,2:必须替代
	_DefFld("CashBuffer",_Number,15); 		--现金替代溢价比例
	_DefFld("CashAmount",_Number,15); 		--现金替代金额
	_DefFld("CreateTime",_String,15);		--创建时间
	_DefFld("RedemptionAmount",_Number,15); --赎回 替代金额
	_DefFld("OrderMarket",_String,20); 		--挂牌市场

	_DefKeyField("ETFID");
	_DefKeyField("IssueCode");
	_DefKeyField("TradingDay");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

---------------------------------------------------策略调用函数----------------------------------------

--初始化方法，require该函数的策略先要初始化
--参数pid：生成的ETF DD清单策略的模型号
--参数sid：生成的ETF DD清单策略的策略号
--对于仅做单市场的ETF策略，都传入""即可
function ETFQueryStart(pid,sid)
	DTSDate currentDate = _GetNowDate();	--取当前日期
	_String strCurrentDate = currentDate.asString("%Y%m%d");	--时间格式化

	DTSEvent etfEvent = _CreateEventObject("ETFListTable")
	DTSDynamicData etfListStore = _CreateDynamicData("ETFListEvent",fileType=_DataOtherType,ETFListTable etfEvent,portfolioID=pid,strategyID=sid)
	
	DTSEvent etfCompEvent = _CreateEventObject("ETFComponentTable")
	DTSDynamicData etfCompStore = _CreateDynamicData("ETFComponentEvent",fileType=_DataOtherType,ETFComponentTable etfCompEvent,portfolioID=pid,strategyID=sid)

	--初始化走的方法
	_ETFIssue2NameTable = {} --ETF合约对应的名称关系 key:IssueCode value:ETFName
	_ETFID2NameTable = {} --ETFID对应的名称关系 key:ETFID value:ETFName
	_ETFName2IssueTable = {} --ETF名称对应的ETFIssueCode关系 key:FundName value:ETFIssueCode
	_ETFID2ETFIssueTable = {} --ETFID对应的ETFIssueCode关系 key:ETFID value:ETFIssueCode
	_ETFInfoTable = {} --ETF信息表 key:FundName value:etfInfTable
	_ETFComponentTable = {} --成分股信息表 key:FundName value:componentInfTable
	
	--查询所有ETF清单及成分股清单
	_QueryETFAll(pid,sid)
end

--供策略调用读取ETF清单（策略不用关心读取的数据来源）
function QueryETFList(cond,pid,sid)
	_QueryETFListInTable(cond) --来自数据库
	_QueryETFListInDD(cond,pid,sid) --来自DD
end

--供策略调用读取ETF清单（策略不用关心读取的数据来源）
function QueryETFComponent(cond,pid,sid)
	_QueryETFComponentInTable(cond) --来自数据库
	_QueryETFComponentInDD(cond,pid,sid) --来自DD
end

---------------------------------------------------内部使用函数----------------------------------------

--读数据库ETF清单
function _QueryETFListInTable(cond)
	_WriteAplLog("QueryETFInfo:_QueryETFListInTable query condition:")
	_WriteAplLog(cond)
	local strcond = cond.toString()
	local cond = "TradingDay = \'"..strCurrentDate.."\' AND FundName = \'"..strcond.."\'";
	_WriteAplLog(cond)
	_GetCommonData(dataName = "ETFListTable", condition = cond,tablename = "DTSETFList");
end

--读数据库ETF成分股清单
function _QueryETFComponentInTable(cond)
	_WriteAplLog("QueryETFInfo:_QueryETFComponentInTable query condition:")
	_WriteAplLog(cond)
	local strcond = cond.toString()
	local cond = "ETFID = \'"..strcond.."\' AND TradingDay = \'"..strCurrentDate.."\'";
	_WriteAplLog(cond)
	_GetCommonData(dataName = "ETFComponentTable", condition = cond,tablename = "DTSETFComponent");
end

--读ETF清单DD
function _QueryETFListInDD(cond,pid,sid)
	_WriteAplLog("QueryETFInfo: _QueryETFListInDD query condition:")
	_WriteAplLog(cond)
	local strcond = cond.toString()
	local cond = "TradingDay#"..strCurrentDate..";FundName#"..strcond
	_WriteAplLog(cond)
	if etfListStore ~= NULL then
		etfListStore._GetDynamicData("ETFListDD",condition = cond)
	else
		_WriteAplLog("QueryETFInfo:_PosLoadETFInfo no ETFListDD")
	end
end

--读ETF成分股清单DD
function _QueryETFComponentInDD(cond,pid,sid)
	_WriteAplLog("QueryETFInfo:_QueryETFComponentInDD query condition:")
	_WriteAplLog(cond)
	local strcond = cond.toString()
	local cond = "ETFID#"..strcond..";TradingDay#"..strCurrentDate
	_WriteAplLog(cond)
	if etfListStore ~= NULL then
		etfCompStore._GetDynamicData("ETFComponentDD",condition = cond)
	else
		_WriteAplLog("QueryETFInfo:_QueryETFComponentInDD no ETFComponentDD")
	end
end

--查询ETF所有清单，为了保存_ETFIssue2NameTable,_ETFID2NameTable,_ETFName2IssueTable全局表
function _QueryETFAll(pid,sid)
	_GetCommonData(dataName = "ETFListTableAll", condition = "",tablename = "DTSETFList");
	local cond = "TradingDay#"..strCurrentDate
	_WriteAplLog(cond)
	if etfListStore ~= NULL then
		etfListStore._GetDynamicData("ETFListDDAll",condition = cond)
	else
		_WriteAplLog("QueryETFInfo:_PosLoadETFInfo no ETFListDDAll")
	end
end

---------------------------------------------------回调函数----------------------------------------
_OnCommonData(dataName = "ETFListTableAll", DTSDTSETFList del)
	local ETFID = del.getETFID()
	local ETFIssueCode = del.getIssueCode()
	local FundName = del.getFundName()
	_ETFIssue2NameTable[ETFIssueCode] = FundName
	_ETFID2NameTable[ETFID] = FundName
	_ETFName2IssueTable[FundName] = ETFIssueCode
	_ETFID2ETFIssueTable[ETFID] = ETFIssueCode
_End

_OnDynamicData("ETFListDDAll",ETFListTable ETFList)
	local ETFID = ETFList._GetFld("ETFID")
	local ETFIssueCode = ETFList._GetFld("IssueCode")
	if not _ETFIssue2NameTable[ETFIssueCode] then
		local FundName = ETFList._GetFld("FundName")
		_ETFIssue2NameTable[ETFIssueCode] = FundName
		_ETFID2NameTable[ETFID] = FundName
		_ETFName2IssueTable[FundName] = ETFIssueCode
		_ETFID2ETFIssueTable[ETFID] = ETFIssueCode
	end
_End

_OnCommonData(dataName = "ETFListTable", DTSDTSETFList del)
	local etfID = del.getETFID();	--ETFID
	local issueCode = del.getIssueCode();	--IssueCode of ETF
	local createIssueCode = del.getCreateIssueCode()
	local cashIssueCode = del.getCashIssueCode()
	local fundName = del.getFundName();	--ETFName
	local fundManagementCompany = del.getFundManagementCompany()
	local underlyingIndex = del.getUnderlyingIndex()
	local creationRedemptionUnit = del.getCreationRedemptionUnit();	--最小申赎单位
	local estimatecashcomponent = del.getEstimatecashcomponent();	--预估现金部分
	if estimatecashcomponent == "" or estimatecashcomponent == nil then
		estimatecashcomponent = 0;
	end
	local maxCashRatio =del.getMaxCashRatio();	--最大现金替代比例
	local publish = del.getPublish()
	local creation = del.getCreation()
	local redemption = del.getRedemption()
	local recordNum = del.getRecordNum();	--成份股个数

	local tradingDay = del.getTradingDay();	--交易日（一般是今日）
	local preTradingDay = del.getPreTradingDay()
	local cashComponent = del.getCashComponent();	--前日现金差额
	if cashComponent == "" or cashComponent == nil then
		cashComponent = 0;
	end
	local navPerCU = del.getNAVperCU()
	local nav = del.getNAV()
	local dividendPerCU = del.getDividendPerCU()
	local cashCreationPremiumRatio = del.getCashCreationPremiumRatio()
	local cashCreationSettlementRatio = del.getCashCreationSettlementRatio()
	local cashCreationLimitPerUser = del.getCashCreationLimitPerUser()
	local cashCreationLimitPerPD = del.getCashCreationLimitPerPD()
	local cashCreationLimitTotal = del.getCashCreationLimitTotal()

	local type;
	if issueCode == "510300" or issueCode == "159919" then
		type = 2
	elseif issueCode == "510900" or issueCode == "159920" then
		type = 3
	else
		type = 1
	end

	local tETFInfo = {};
	tETFInfo.ETFID = etfID
	tETFInfo.IssueCode = issueCode
	tETFInfo.CreateIssueCode = createIssueCode
	tETFInfo.CashIssueCode = cashIssueCode
	tETFInfo.FundName = fundName
	tETFInfo.FundManagementCompany = fundManagementCompany
	tETFInfo.UnderlyingIndex = underlyingIndex
	tETFInfo.CreationRedemptionUnit = creationRedemptionUnit
	tETFInfo.EstimateCashComponent = estimatecashcomponent
	tETFInfo.MaxCashRatio = maxCashRatio
	tETFInfo.Publish = publish
	tETFInfo.Creation = creation
	tETFInfo.Redemption = redemption
	tETFInfo.RecordNum = recordNum
	tETFInfo.TradingDay = tradingDay
	tETFInfo.PreTradingDay = preTradingDay
	tETFInfo.CashComponent = cashComponent
	tETFInfo.NAVPerCU = navPerCU
	tETFInfo.NAV = nav
	tETFInfo.DividendPerCU = dividendPerCU
	tETFInfo.CashCreationPremiumRatio = cashCreationPremiumRatio
	tETFInfo.CashCreationSettlementRatio = cashCreationSettlementRatio
	tETFInfo.CashCreationLimitPerUser = cashCreationLimitPerUser
	tETFInfo.CashCreationLimitPerPD = cashCreationLimitPerPD
	tETFInfo.CashCreationLimitTotal = cashCreationLimitTotal
	tETFInfo.Type = type
	_ETFInfoTable[fundName] = tETFInfo
	
	local etfListLog = sys_format("QueryETFInfo:ETFListTable ETFID[%s] Issue[%s] FundName[%s] Type[%s] Estimatecashcomponent[%s] maxCashRatio[%s] RecordNum[%s]",
		etfID,issueCode,fundName,type,estimatecashcomponent,maxCashRatio,recordNum)
	_WriteAplLog(etfListLog)
	
	OnQueryETFListTable(tETFInfo)
_End

_OnCommonData(dataName = "ETFComponentTable", DTSDTSETFComponent dec)
	local etfID = dec.getETFID();	--ID
	local etfName = _ETFID2NameTable[etfID];
	local ETFIssueCode = _ETFID2ETFIssueTable[etfID]
	if not _ETFInfoTable[etfName] then
		local log = sys_format("QueryETFInfo:%s 数据库清单不完整", etfID)
		_WriteErrorLog(log)
		_WriteAplLog(log)
	else
		local TradingDay = dec.getTradingDay();
		local IssueCode = dec.getIssueCode();
		local Quantity = dec.getQuantity();
		local CanCashRepl = dec.getCanCashRepl();
		local CashBuffer = dec.getCashBuffer();
		local CashAmount = dec.getCashAmount();

		local tETFComp = {}
		tETFComp.ETFID = etfID
		tETFComp.TradingDay = TradingDay
		tETFComp.IssueCode = IssueCode
		tETFComp.Quantity = Quantity
		tETFComp.CanCashRepl = CanCashRepl
		tETFComp.CashBuffer = CashBuffer
		tETFComp.CashAmount = CashAmount

		if not _ETFComponentTable[etfName] then
			_ETFComponentTable[etfName] = {}
		end
		_ETFComponentTable[etfName][IssueCode] = tETFComp
		
		OnQueryETFComponentTable(tETFComp)
		--local log = sys_format("QueryETFInfo:etfIssueCode=%s,IssueCode=%s,CanCashRepl=%s", ETFIssueCode,IssueCode,CanCashRepl)
		--_WriteAplLog(log)
	end
_End


_OnDynamicData(dataName="ETFListDD",ETFListEvent etfEvent)
	local ETFID = etfEvent._GetFld("ETFID")
	local ETFName = _ETFID2NameTable[ETFID];
	local IssueCode = etfEvent._GetFld("IssueCode")
	
	--跨境跨市场新增字段
	local TotalRecordNum = etfEvent._GetFld("TotalRecordNum") 	--表示一个篮子中的所有成份股数目
	local Type = etfEvent._GetFld("Type") 						--ETF 类型，1：本市场 ETF， 2：跨市场ETF, 3:跨境ETF
	local CreationLimit = etfEvent._GetFld("CreationLimit") 	--当天累计可申购的基金份额上限，为 0 表示没有限制
	local RedemptionLimit = etfEvent._GetFld("RedemptionLimit") --当天累 计可赎回的基金份额上限，为 0 表示没有限制
	
	if not _ETFInfoTable[ETFName] then --数据库记录已经读取，防止重复记录再次读取
		_WriteAplLog("QueryETFInfo:ETFListDD")
		local CreateIssueCode = etfEvent._GetFld("CreateIssueCode")
		local CashIssueCode = etfEvent._GetFld("CashIssueCode")
		local FundName = etfEvent._GetFld("FundName")
		local FundManagementCompany = etfEvent._GetFld("FundManagementCompany")
		local UnderlyingIndex = etfEvent._GetFld("UnderlyingIndex")
		local CreationRedemptionUnit = etfEvent._GetFld("CreationRedemptionUnit")
		local EstimateCashComponent = etfEvent._GetFld("EstimateCashComponent")
		local MaxCashRatio = etfEvent._GetFld("MaxCashRatio")
		local Publish = etfEvent._GetFld("Publish")
		local Creation = etfEvent._GetFld("Creation")
		local Redemption = etfEvent._GetFld("Redemption")
		local RecordNum = etfEvent._GetFld("RecordNum")
		local TradingDay = etfEvent._GetFld("TradingDay")
		local PreTradingDay = etfEvent._GetFld("PreTradingDay")
		local CashComponent = etfEvent._GetFld("CashComponent")
		local NAVPerCU = etfEvent._GetFld("NAVperCU")
		local NAV = etfEvent._GetFld("NAV")
		local DividendPerCU = etfEvent._GetFld("DividendPerCU")
		local CashCreationPremiumRatio = etfEvent._GetFld("CashCreationPremiumRatio")
		local CashCreationSettlementRatio = etfEvent._GetFld("CashCreationSettlementRatio")
		local CashCreationLimitPerUser = etfEvent._GetFld("CashCreationLimitPerUser")
		local CashCreationLimitPerPD = etfEvent._GetFld("CashCreationLimitPerPD")
		local CashCreationLimitTotal = etfEvent._GetFld("CashCreationLimitTotal")
		--_ETFID2ETFIssueTable[ETFID] = IssueCode
		if EstimateCashComponent == "" or EstimateCashComponent == nil then
			EstimateCashComponent = 0
		end
		if CashComponent == "" or CashComponent == nil then
			CashComponent = 0
		end

		local tETFInfo = {};
		tETFInfo.ETFID = ETFID
		tETFInfo.IssueCode = IssueCode
		tETFInfo.CreateIssueCode = CreateIssueCode
		tETFInfo.CashIssueCode = CashIssueCode
		tETFInfo.FundName = FundName
		tETFInfo.FundManagementCompany = FundManagementCompany or "";
		tETFInfo.UnderlyingIndex = UnderlyingIndex or "";
		tETFInfo.CreationRedemptionUnit = CreationRedemptionUnit
		tETFInfo.EstimateCashComponent = EstimateCashComponent
		tETFInfo.MaxCashRatio = MaxCashRatio
		tETFInfo.Publish = Publish
		tETFInfo.Creation = Creation
		tETFInfo.Redemption = Redemption
		tETFInfo.RecordNum = RecordNum
		tETFInfo.TradingDay = TradingDay
		tETFInfo.PreTradingDay = PreTradingDay
		tETFInfo.CashComponent = CashComponent
		tETFInfo.NAVPerCU = NAVPerCU
		tETFInfo.NAV = NAV
		tETFInfo.DividendPerCU = DividendPerCU
		tETFInfo.CashCreationPremiumRatio = CashCreationPremiumRatio or 0;
		tETFInfo.CashCreationSettlementRatio = CashCreationSettlementRatio or 0;
		tETFInfo.CashCreationLimitPerUser = CashCreationLimitPerUser or 0;
		tETFInfo.CashCreationLimitPerPD = CashCreationLimitPerPD or 0;
		tETFInfo.CashCreationLimitTotal = CashCreationLimitTotal or 0;
		tETFInfo.TotalRecordNum = TotalRecordNum
		tETFInfo.Type = Type
		tETFInfo.CreationLimit = CreationLimit
		tETFInfo.RedemptionLimit = RedemptionLimit

		_ETFInfoTable[FundName] = tETFInfo

		local etfListLog = sys_format("QueryETFInfo:ETFListDD ETFID[%s] Issue[%s] Type[%s] CashIssueCode[%s] Redemption[%s] RecordNum[%s] CashComponent[%s]CreationRedemptionUnit[%s]EstimateCashComponent[%s] _ETFID2ETFIssueTable[%s]=%s",
			tETFInfo.ETFID,tETFInfo.IssueCode,Type,tETFInfo.CashIssueCode,tETFInfo.Redemption,tETFInfo.RecordNum,tETFInfo.CashComponent,CreationRedemptionUnit,EstimateCashComponent,ETFID,IssueCode)
		_WriteAplLog(etfListLog)
		OnQueryETFListTable(tETFInfo)
	else
		--只需修正数据库缺少的DD特有的字段即可
		_ETFInfoTable[ETFName].Type = Type
		_ETFInfoTable[ETFName].TotalRecordNum = TotalRecordNum
		_ETFInfoTable[ETFName].CreationLimit = CreationLimit
		_ETFInfoTable[ETFName].RedemptionLimit = RedemptionLimit
		local etfListLog = sys_format("QueryETFInfo:ETFListDD2 ETFID[%s] Issue[%s] Type[%s] TotalRecordNum[%s] CreationLimit[%s] RedemptionLimit[%s]",ETFID,IssueCode,Type,TotalRecordNum,CreationLimit,RedemptionLimit)
		_WriteAplLog(etfListLog)
	end
_End

_OnDynamicData(dataName="ETFComponentDD",ETFComponentEvent etfCompEvent)
	local ETFID = etfCompEvent._GetFld("ETFID")
	local ETFName = _ETFID2NameTable[ETFID];
	local ETFIssueCode = _ETFID2ETFIssueTable[ETFID]
	if not _ETFInfoTable[ETFName] then
		local log = sys_format("QueryETFInfo:%s DD清单不完整", ETFID)
		_WriteErrorLog(log)
		_WriteAplLog(log)
	else
		local TradingDay = etfCompEvent._GetFld("TradingDay")
		local IssueCode = etfCompEvent._GetFld("IssueCode")
		local Quantity = etfCompEvent._GetFld("Quantity")
		local CanCashRepl = etfCompEvent._GetFld("CanCashRepl")
		local CashBuffer = etfCompEvent._GetFld("CashBuffer")
		local CashAmount = etfCompEvent._GetFld("CashAmount")
		--深圳跨境新增字段
		local CreAmount = etfCompEvent._GetFld("CreAmount")	--申购替代金额
		local RedAmount = etfCompEvent._GetFld("RedAmount")	--赎回替代金额
		local OrderMarket = etfCompEvent._GetFld("OrderMarket")	--挂牌市场

		local tETFComp = {}
		tETFComp.ETFID = ETFID
		tETFComp.TradingDay = TradingDay
		tETFComp.IssueCode = IssueCode
		tETFComp.Quantity = Quantity
		tETFComp.CanCashRepl = CanCashRepl
		tETFComp.CashBuffer = CashBuffer
		tETFComp.CashAmount = CashAmount
		tETFComp.CreAmount = CreAmount
		tETFComp.RedAmount = RedAmount
		tETFComp.OrderMarket = OrderMarket or "";

		if not _ETFComponentTable[ETFName] then
			_ETFComponentTable[ETFName] = {}
		end
		
		if not _ETFComponentTable[ETFName][IssueCode] then --数据库记录已经读取，防止重复记录再次读取
			_ETFComponentTable[ETFName][IssueCode] = tETFComp
			--Test
			local log = sys_format("QueryETFInfo:ETFComponentDD ETFIssueCode=%s,IssueCode=%s,CanCashRepl=%s", ETFIssueCode,IssueCode,CanCashRepl)
			_WriteAplLog(log)
			OnQueryETFComponentTable(tETFComp)
		end
	end
_End
