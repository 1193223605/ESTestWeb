﻿--@@Version:1.00.100.20131227@@
--@@Version:1.00.100.20131129@@
function MarketBasketCheckFund(Basket)
	--_WriteAplLog("BasketCheckFund");
	local checkRet = true

	local checkFlag = false
	local totalFare = 0
	for key,value in pairs(Basket) do
		local IssueCode = value.IssueCode
		--local BuySell = bv.BuySell
		local OpenClose = value.OpenClose
		local Quantity = value.Quantity
		local Price = value.Price
		local contractSize = _PosIssueContractSizeTable[IssueCode];
		local vLog = sys_format("MarketBasketCheckFund,IssueCode = %s,OpenClose = %s,Quantity = %s,Price = %s",
		IssueCode,OpenClose,Quantity,Price)
		_WriteAplLog(vLog)
		if OpenClose == "0" then
			checkFlag = true
		else
			break
		end
		totalFare = totalFare + (Quantity * Price * contractSize).getNumberValue()
	end
	local avlFund = gtInvestorFundStatus[spBAMapID].AvlFund
	local fundLog = sys_format("MarketBasketCheckFund:totalFare = %s,avlFund = %s",totalFare,avlFund)
	_WriteAplLog(fundLog)
	--sendLog(fundLog)
	if totalFare.getNumberValue() >  avlFund.getNumberValue() and avlFund.getNumberValue()>0 and checkFlag == true then
		local logStr = sys_format("篮子买入可用资金不足!需要资金 [%s],可用资金[%s]",totalFare,avlFund)
		sendLog(logStr);
		--_WriteAplLog(logStr);
		checkRet = false
	elseif avlFund.getNumberValue()<= 0 then
		local logStr = sys_format("篮子买入可用资金不足!可用资金[%s]",avlFund)
		sendLog(logStr);
		--_WriteAplLog(logStr);
		checkRet = false
	else
		checkRet = true
	end
	local cLog = sys_format("MarketBasketCheckFund : checkRet = %s",checkRet)
	_WriteAplLog(cLog)
	return checkRet
end


--买入成份股回调
_OnEventDefined(BuyComponent evt,sessionID)
	_WriteAplLog("ETF:BuyComponent")
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		if spInvestorMode == 1 then
			MarketBuyComponent()
		else
			PosBuyComponent(sessionID)
		end
	end
_End

--卖出成份股回调
_OnEventDefined(SellComponent evt,sessionID)
	_WriteAplLog("ETF:BuyComponent")
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		if spInvestorMode == 1 then
			MarketSellComponent()
		else
			PosSellComponent(sessionID)
		end
	end
_End
--申购ETF回调
_OnEventDefined(CreateETF evt,sessionID)
	_WriteAplLog("ETF:CreateETF")
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		if spInvestorMode == 1 then
			MarketCreETF()
		else
			PosCreETF(sessionID)
		end
	end
_End


--赎回ETF回调
_OnEventDefined(Redemption evt,sessionID)
	_WriteAplLog("ETF:Redemption")
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		if spInvestorMode == 1 then
			MarketRedeemETF()
		else
			PosRedeemETF(sessionID)
		end
	end
_End
--BuyETF Button买入ETF
_OnEventDefined(BuyETF evt,sessionID)
	_WriteAplLog("买ETF回调")
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		if spInvestorMode == 1 then
			MarketBuyETF()
		else
			PosBuyETF(sessionID)
		end
	end
_End


--SellETF Button卖出ETF
_OnEventDefined(SellETF evt,sessionID)
	_WriteAplLog("卖ETF回调")
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		if spInvestorMode == 1 then
			MarketSellETF()
		else
			PosSellETF(sessionID)
		end
	end
_End
------------------------------------------------------------------------------------------
--------------------买卖盘选择------------------------------------------------------------
------------------------------------------------------------------------------------------
--选择买盘输入
_DefineEventObject SelectBidQuoteInput _AS _Input
	_DefFld("SelectBidQuote",_String,20);
_End

--选择买盘回调
_OnEventDefined(SelectBidQuoteInput selBidQutEvent,sessionID)
	gBidQuote = selBidQutEvent._GetFld("SelectBidQuote");
	local logs = sys_format("SelectBidQuoteInput-gBidQuote:%s",gBidQuote)
	_WriteAplLog(logs);
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],选择买盘 操作参数[买盘=%s]",
		loginSequence,loginID,loginRoute,gBidQuote)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)
	showBidQuote();

	--成分股列表更新
	for issueCode,infoTable in pairs(gtETFComponentTradeInfo) do
		SelectSingleIssueBidQuoteEvent(issueCode,gBidQuote)
	end

	saveETFDynamicData();	--存入DynamicData
_End

--选择卖盘输入
_DefineEventObject SelectAskQuoteInput _AS _Input
	_DefFld("SelectAskQuote", _String, 20);
_End

--选择卖盘回调
_OnEventDefined(SelectAskQuoteInput selAskQutEvent,sessionID)
	gAskQuote = selAskQutEvent._GetFld("SelectAskQuote");
	local logs = sys_format("SelectAskQuoteInput-gAskQuote:%s",gAskQuote)
	_WriteAplLog(logs);
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],选择卖盘 操作参数[买盘=%s]",
		loginSequence,loginID,loginRoute,gAskQuote)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)
	showAskQuote();

	--成分股列表更新
	for issueCode,infoTable in pairs(gtETFComponentTradeInfo) do
		SelectSingleIssueAskQuoteEvent(issueCode,gAskQuote)
	end

	saveETFDynamicData();	--存入DynamicData
_End


--显示买盘
function showBidQuote()
	local logs = sys_format("showBidQuote-gBidQuote:%s",gBidQuote)
	--_WriteAplLog(logs)
	local DTSEvent bidQuoteEvent = _CreateEventObject("SelectBidQuoteOutput");
	bidQuoteEvent._SetFld("SelectBidQuote",gBidQuote);
	bidQuoteEvent._SetFld("KeyForBuffer",1);
	_SendToClients(bidQuoteEvent);
end

--显示卖盘
function showAskQuote()

	local logs = sys_format("showAskQuote-gAskQuote:%s",gAskQuote)
	_WriteAplLog(logs)
	local DTSEvent askQuoteEvent = _CreateEventObject("SelectAskQuoteOutput");
	askQuoteEvent._SetFld("SelectAskQuote",gAskQuote);
	askQuoteEvent._SetFld("KeyForBuffer",1);
	_SendToClients(askQuoteEvent);
end



--选择买盘输出
_DefineEventObject SelectBidQuoteOutput _AS _Output
	_DefFld("SelectBidQuote",_String,20);
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--选择卖盘输出
_DefineEventObject SelectAskQuoteOutput _AS _Output
	_DefFld("SelectAskQuote", _String, 20);
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

-------------------------------------------------------------------------------------------
-----------------保留成分股/ETF------------------------------------------------------------
--保留ETF
_DefineEventObject SaveETFShareEvent _AS _Input
	_DefFld("SaveNum",_String,3)
_End

_OnEventDefined(SaveETFShareEvent evt)
	local saveNum = evt._GetFld("SaveNum")
	local log = sys_format("SaveETFShareEvent : saveNum = %s",saveNum)
	_WriteAplLog(log)
    if saveNum.getNumberValue() >= 0 then
        if spInvestorMode == 1 then
            SellExtraETF(saveNum)
        end
	else
		local log = sys_format("清除多余ETF份额:SaveNum 错误! SaveNum = %s",saveNum)
		_WriteAplLog(log)
	end

_End

--保留成分股
_DefineEventObject SaveComponentShareEvent _AS _Input
	_DefFld("SaveNum",_String,3)
_End

_OnEventDefined(SaveComponentShareEvent evt)
	local saveNum = evt._GetFld("SaveNum")
	local log = sys_format("SaveComponentShareEvent : saveNum = %s",saveNum)
	_WriteAplLog(log)
	if saveNum.getNumberValue() >= 0 then
		if spInvestorMode == 1 then
			SellExtraComponent(saveNum)
		end
	else
		local log = sys_format("清除多余成分股份额:SaveNum 错误! SaveNum = %s",saveNum)
		_WriteAplLog(log)
	end
_End

--出售多余成分股
function SellExtraComponent(RemindNumber)
	local logs = sys_format("ETF:SellExtraComponent RemindNumber[%s]",RemindNumber)
	_WriteAplLog(logs)

	local issueNum = 1;
	local buyCompEndFlag = false;
	local buyCompStartFlag = true;
	local cmplCompStart = true;
	local cmplCompEnd = false;
	local keyPosList = "";

	--按降序排列权重
	local Basket = {}
	local OrderSeq = 0
	local BuySell = "1"
	local buysell = "S";
	--local quote = gAskQuote;
	local tick = gSellTick;
	local chkQty = false;
	local BatchID = 0

	local ETFIssueCode = _ETFName2IssueTable[gETFName]
	local ETFMarketCode = _PosIssueMarketTable[ETFIssueCode]

	gSellETFCompCount = gSellETFCompCount + 1
	BatchID = gSellETFCompCount
	if spInvestorMode ~= 1 then
		chkQty = true;
	end

	for issueCode,value in pairs(gtETFComponentTradeInfo) do
		--_WriteAplLog(logs);
		local issueInfo = _ETFComponentTable[gETFName][issueCode];
		local tradeAmount = issueInfo.TradeAmount;	--交易数量
		local tradeQty = 0;
		local orderFlag = true

		local remindQty = RemindNumber * tradeAmount
		local quantityTemp = 0
		--if spInvestorMode == 1 then
		if gtInvestorPositionInfo[issueCode]~= nil then
			if gtInvestorPositionInfo[issueCode].AvlQuantity ~= nil then
				quantityTemp = gtInvestorPositionInfo[issueCode].AvlQuantity;	--持仓数量
			end
		end

		if (quantityTemp - remindQty) > 0 then
			tradeQty = quantityTemp - remindQty	--卖出成份股时的实际卖出数量
		end
		local askQuote = gtETFComponentTradeInfo[issueCode].SelectAskQuote
		local tick = gSellTick;
		local orderPrice = gtETFComponentTradeInfo[issueCode].AskPrice
		local orderLog = sys_format("IssueCode = %s,askQuote = %s,tick = %s,buysell = %s,orderPrice = %s",issueCode,askQuote,tick,buysell,orderPrice)
		_WriteAplLog(orderLog)

		--下单
		local issueCodePirceStatus = getIssueCodePriceStatus(issueCode)
		if tradeQty > 0 and  issueCodePirceStatus ~= "SP" then
			local OrderInfo = {}
			OrderInfo.IssueCode = issueCode
			OrderInfo.Quantity = tradeQty
			OrderInfo.Price = orderPrice
			OrderInfo.BuySell = BuySell
			OrderInfo.OpenClose = "1"
			OrderInfo.PriceCondition = ""
			OrderInfo.IsRedemption = false
			OrderInfo.BatchID = BatchID
			sys_insert(Basket,OrderInfo)
		end
	end
	local BasketSize = sys_getSize(Basket)
	if BasketSize > 0 then
		MarketSubmitBasketOrder(Basket)
		logs = sys_format("清楚多余成分股%s的成份股下单完成",gETFName);
		sendLog(logs)
		_WriteAplLog(logs);
	else
		sendLog("无多余可卖成分股!不下单！")
	end
end


--卖出多余ETF
function SellExtraETF(RemindNumber)
	local unit = _ETFInfoTable[gETFName].Unit
	local tradeQty = 0;
	local quantityTemp = 0
	if _ETFInfoTable[gETFName] then
		local etfIssue = _ETFName2IssueTable[gETFName];
		if spInvestorMode == 1 then
			if gtInvestorPositionInfo[etfIssue]~= nil then
				if gtInvestorPositionInfo[etfIssue].AvlQuantity ~= nil then
					quantityTemp = gtInvestorPositionInfo[etfIssue].AvlQuantity;	--持仓数量
				end
			end
		else
			local keyPosList = spBAMapID..".3."..etfIssue
			if _PosPositionTable[keyPosList] ~= nil then
				if _PosPositionTable[keyPosList].Quantity ~= nil then
					quantityTemp = _PosPositionTable[keyPosList].Quantity;	--持仓数量
				end
			end
		end
		local remindQty = unit * RemindNumber
		local remindLog = sys_format("RemindNumber = %s,remindQty = %s,quantityTemp = %s",RemindNumber,remindQty,quantityTemp)
		_WriteAplLog(remindLog)
		tradeQty = sys_max(0,(quantityTemp - remindQty))
		local buySell = "1"
		local quote = gAskQuote
		local tick = gSellTick
		local openClose = "1"
		local isRedemption = false
		local orderPrice = getOrderPrice(etfIssue,quote,tick,buySell,tradeQty)
		if tradeQty > 0 then
			if tradeQty > _MaxOrderSumitQty  then
				MarketSplitQuantity(etfIssue,tradeQty,orderPrice,buySell)
			else
				MarketSubmitSingleBasket(etfIssue,buySell,tradeQty,orderPrice,openClose,isRedemption,"")
			end
			local successlog = sys_format("清除多余ETF份额完成!")
			_WriteAplLog(successlog)
			sendLog(successlog)
		else
			local log = sys_format("无可卖多余ETF！")
			sendLog(log)
		end
	end
end

-------------------------------------------------------------------------------------
----------------------下单封装-------------------------------------------------------
function MarketSubmitBasketOrder(orderTable)
	local accountCode = _PosBAMapAccount[spBAMapID]
	local fundStatus = _PosFundStatus[accountCode]
	local submitFlag = 0; --如果大于0才下单

	local password = _GetInvestorPWD(spBAMapID)
	local _String gs = fundStatus.InvestorID.."\t"..fundStatus.Password
	--如果获取的密码为空,则用数据库密码，否则用LoginSS密码
	if password ~= "" then
		gs = fundStatus.InvestorID.."\t"..password
	end
	_WriteAplLog("*******MarketSubmitBasketOrder批量下单******")

	--新下单接口方式,优化下单性能
	--DTSSubmitEvent
	local DTSSubmitEvent submitEvent

	submitEvent.setField("MessageType","L01")
	local workstationNo = _GetWorkstationNo()
	submitEvent.setField("WorkstationNo",workstationNo) --默认本机
	submitEvent.setField("ModelID","1000")   				--可不填
	submitEvent.setField("WaveID","1111")    			--可不填
	local dealerID = _GetDealerID()
	local _String strDealerID = dealerID
	submitEvent.setField("DealerID", strDealerID)  		--默认登录用户

	--List
	local DTSSubmitEvent orderList;

	for bk,bv in pairs(orderTable) do
		local IssueCode = bv.IssueCode
		local BuySell = bv.BuySell
		local OpenClose = bv.OpenClose
		local Quantity = bv.Quantity
		local Price = bv.Price
		local IsRedemption = bv.IsRedemption
		local BatchID = bv.BatchID
		--local BASubID = bv.BASubID
		local openClose1 = OpenClose;
		local priorMarket = _PosIssueMarketTable[IssueCode];
		if priorMarket == "1" or priorMarket == "2" then
			if BuySell == "3" then
				openClose1 = "0";
			end
			if BuySell == "1" then
				openClose1 = "1";
			end
		end

		local BASubID = "";
		if openClose1 == "0" then
			BASubID = BuySell;
		else
			if BuySell == "1" then
				BASubID = "3";
			else
				BASubID = "1";
			end
		end


		submitFlag = submitFlag + 1;
		local temlog = sys_format("Add order Issue %s Quantity %s Price %s to Basket",IssueCode,Quantity,Price);

		--Order
		local DTSSubmitEvent order1
		local _String strbAMapID = spBAMapID;
		local _String strIssueCode = IssueCode;
		local _String strMarketCode = _PosIssueMarketTable[IssueCode];
		local _String strProductCode = _PosIssueProductCodeTable[IssueCode];
		--local _String strBuySell = BuySell;

		local _String MACAddress = gMacIpHdIDTable.MacAddress
		local _String HDID = gMacIpHdIDTable.HdID
		local _String IPAddress = gMacIpHdIDTable.LocalIP
		order1.setField("HDID",HDID)
		order1.setField("MacAddress",MACAddress)
		order1.setField("IPAddress",IPAddress)

		order1.setField("BAMapID",strbAMapID)
		order1.setField("IssueCode",strIssueCode)
		order1.setField("MarketCode",strMarketCode)
		order1.setField("ProductCode",strProductCode)

		local tmpCreRed = 0
		if IsRedemption then
			if BuySell == "3" then
				order1.setField("GeneralInt1",1)
				tmpCreRed = 1
			else
				order1.setField("GeneralInt1",2)
				tmpCreRed = 2
			end
		end

		--针对于新下单接口，重新设置buysell标志
		local tmpBuySell = _PosNewSubmitBSConventer(BuySell,openClose1,tmpCreRed)
		local _String strBuySell = tmpBuySell
		order1.setField("BuySell",strBuySell)

		if priorMarket == "1" or priorMarket == "2" then
			order1.setField("MarginFlag","0")
		else
			if openClose1 == "0" then
				order1.setField("MarginFlag","2")
			else
				order1.setField("MarginFlag","4")
			end
		end
		if BatchID and BatchID ~= "" then
			local _String strBatchID = BatchID
			order1.setField("TargetPrice",strBatchID)
		end

		local _String strBASubID;

		strBASubID = BASubID
		order1.setField("BASubID",strBASubID)
		local _Int intqty = Quantity;
		order1.setField("Quantity",intqty)
		local  _String strPrice = Price;
		order1.setField("Price",strPrice)
		order1.setField("DealerID",strDealerID)
		local _String strSenderID = gUserID;
		order1.setField("SenderID",strSenderID)
		local _String strOwnerID = gUserID;
		order1.setField("OwnerID",strOwnerID)
		--gs = gs.."\t1024";	--特殊的委托方式
		order1.setField("GeneralString1",gs)
		--local _String resStr2 = _StockAccountSH .. "|" .. _StockAccountSZ;
		local accountCode = _PosBAMapAccount[spBAMapID]
		local _String resStr2 = _PosFundStatus[accountCode].StockAccountSH .. "|" .. _PosFundStatus[accountCode].StockAccountSZ;
		order1.setField("ReserveString2",resStr2)

		--增加股东代码字段StockholderCode
		local _String strStockholderCode = ""
		if strMarketCode == "1" then
			strStockholderCode = _PosFundStatus[accountCode].StockAccountSH
		elseif strMarketCode == "2" then
			strStockholderCode = _PosFundStatus[accountCode].StockAccountSZ
		end
		order1.setField("StockholderCode",strStockholderCode)


		local _Int intoc = openClose1;
		order1.setField("Direction",intoc)

		--New Add
		local _String strInvestorID = fundStatus.InvestorID
		order1.setField("InvestorID",strInvestorID)
		local _String strPassword = fundStatus.Password
		local loginssPassword = _GetInvestorPWD(strbAMapID)
		if loginssPassword ~= "" then
			strPassword = loginssPassword
		end
		order1.setField("Password",strPassword)

		--test log
		local submitLog = sys_format("MarketSubmitBasketOrder SubmitOrder: IssueCode[%s] Quantity[%s] Price[%s] BAMapID[%s] ReserveInt1[%s] BuySell[%s] BASubID[%s] BatchID[%s] InvestorID[%s] Password[%s] StockholderCode[%s]",
			strIssueCode,intqty,Price,strbAMapID,intoc,BuySell,strBASubID,BatchID,strInvestorID,strPassword,strStockholderCode)
		_WriteAplLog(submitLog)

		submitEvent.spliceField("OrderList",order1)
	end

    local ret = true
	if submitFlag > 0 then
		_WriteAplLog("MarketSubmitBasketOrder下单完成！")
		_SendOrders(submitEvent);
	else
		_WriteAplLog("MarketSubmitBasketOrder批量单为空单，不下单！")
        ret = false
	end
    return ret
end

--柜台下单封装部分
--柜台成分股开仓
function MarketBuyComponent()
	local logs = sys_format("ETF:MarketBuyComponent")
	_WriteAplLog(logs)
	gBuyETFCompCount = gBuyETFCompCount + 1
	BatchID = gBuyETFCompCount
	--按降序排列权重
	local Basket = {}
	local BuySell = "3"
	local ETFIssueCode = _ETFName2IssueTable[gETFName]
	local ETFMarketCode = _PosIssueMarketTable[ETFIssueCode]

	for issueCode,value in pairs(gtETFComponentTradeInfo) do
		local tradeQty = value.BuyQuantity
		local orderPrice = value.BidPrice
		local orderLog = sys_format("IssueCode = %s,orderPrice = %s,tradeQty = %s",issueCode,orderPrice,tradeQty)
		_WriteAplLog(orderLog)

		--下单
		local issueCodePirceStatus = getIssueCodePriceStatus(issueCode)
		if tradeQty > 0 and  issueCodePirceStatus ~= "SP" then
			local OrderInfo = {}
			OrderInfo.IssueCode = issueCode
			OrderInfo.Quantity = tradeQty
			OrderInfo.Price = orderPrice
			OrderInfo.BuySell = BuySell
			OrderInfo.OpenClose = "0"
			OrderInfo.PriceCondition = ""
			OrderInfo.IsRedemption = false
			OrderInfo.BatchID = BatchID
			sys_insert(Basket,OrderInfo)
		end
	end
    if MarketBasketCheckFund(Basket) then
        local ret = MarketSubmitBasketOrder(Basket)
        if ret then
            AddBuyETFCompExecInfo(BatchID, ETFIssueCode,gTradeUnitQty)
            --CreateYJVirtualTaskInfo(BatchID,ETFIssueCode,gTradeUnitQty)
        end
    else
        sendLog("成分股下单:资金不足！")
    end
end

function MarketSubmitSingleBasket(IssueCode,BuySell,Quantity,Price,OpenClose,IsRedemption,BatchID)
	local log = sys_format("MarketSubmitSingleBasket : IssueCode = [%s],BuySell = [%s] ,Quantity = [%s],Price = [%s],OpenClose = [%s],IsRedemption = [%s],BatchID= [%s]",
	IssueCode,BuySell,Quantity,Price,OpenClose,IsRedemption,BatchID)
	_WriteAplLog(log)
	local Basket = {}
	local issueCodePirceStatus = getIssueCodePriceStatus(IssueCode)
	if Quantity > 0 and  issueCodePirceStatus ~= "SP" then
		local OrderInfo = {}
		OrderInfo.IssueCode = IssueCode
		OrderInfo.Quantity = Quantity
		OrderInfo.Price = Price
		OrderInfo.BuySell = BuySell
		OrderInfo.OpenClose = OpenClose
		OrderInfo.PriceCondition = ""
		OrderInfo.IsRedemption = IsRedemption
		OrderInfo.BatchID = BatchID
		sys_insert(Basket,OrderInfo)
	end
	 MarketSubmitBasketOrder(Basket)
end


--柜台成分股平仓
function MarketSellComponent()
	local log = sys_format("ETF:MarketSellComponent")
	_WriteAplLog(log)
	--按降序排列权重
	local Basket = {}
	local BuySell = "1"
	gSellETFCompCount = gSellETFCompCount + 1
	BatchID = gSellETFCompCount
	for issueCode,value in pairs(gtETFComponentTradeInfo) do
		local tradeQty = gtETFComponentTradeInfo[issueCode].SellQuantity
		local quantityTemp = 0

		if gtInvestorPositionInfo[issueCode]~= nil then
			if gtInvestorPositionInfo[issueCode].AvlQuantity ~= nil then
				quantityTemp = gtInvestorPositionInfo[issueCode].AvlQuantity;	--持仓数量
			end
		end
		if quantityTemp < tradeQty then
			tradeQty = quantityTemp
		end
		local orderPrice = gtETFComponentTradeInfo[issueCode].AskPrice
		local orderLog = sys_format("IssueCode = %s,orderPrice = %s,tradeQty = %s,",issueCode,orderPrice,tradeQty)
		_WriteAplLog(orderLog)
		local issueCodePirceStatus = getIssueCodePriceStatus(issueCode)
		--下单
		if tradeQty > 0 and  issueCodePirceStatus ~= "SP" then
			local OrderInfo = {}
			OrderInfo.IssueCode = issueCode
			OrderInfo.Quantity = tradeQty
			OrderInfo.Price = orderPrice
			OrderInfo.OpenClose = "1"
			OrderInfo.BuySell = BuySell
			OrderInfo.PriceCondition = ""
			OrderInfo.IsRedemption = false
			OrderInfo.BatchID = BatchID
			sys_insert(Basket,OrderInfo)
		end
	end
    local BasketSize = sys_getSize(Basket)
    if BasketSize > 0 then
        local ret = MarketSubmitBasketOrder(Basket)
        if ret then
            logs = sys_format("出售[%s]成分股下单完成",gETFName);
            sendLog(logs)
            local ETFIssueCode = _ETFName2IssueTable[gETFName]
            AddSellETFCompExecInfo(BatchID, ETFIssueCode,gTradeUnitQty)
            AddSellETFCompToVirtualTask(BatchID,gTradeUnitQty)
        end
    else
        logs = sys_format("[%s]成分股下单失败,无有效单可下!",gETFName);
        sendLog(logs)
    end
end

--ETF申购
function MarketCreETF()
	local log = sys_format("ETF:MarketSellComponent")
	_WriteAplLog(log)
	--按降序排列权重
	local Basket = {}
	local BuySell = "3"
	if _ETFInfoTable[gETFName] then
		local etfIssue = _ETFName2IssueTable[gETFName];

		tradeQty = _ETFInfoTable[gETFName].Unit * gTradeUnitQty;

		local quote = gBidQuote
		local tick = gBuyTick
		local openClose = "0"
		local isRedemption = true
		local orderPrice = getOrderPrice(etfIssue,quote,tick,BuySell,tradeQty)
		local orderLog = sys_format("etfIssue = %s,orderPrice = %s,tradeQty = %s",etfIssue,orderPrice,tradeQty)
		_WriteAplLog(orderLog)
		--下单
		MarketSubmitSingleBasket(etfIssue,BuySell,tradeQty,orderPrice,openClose,isRedemption,"")
		logs = sys_format("申购ETF:[%s]完成",gETFName);
		sendLog(logs)
	else
		sendLog("ETF信息错误！")
	end
end

--赎回成分股
function MarketRedeemETF()
	local log = sys_format("ETF:MarketRedeemETF")
	_WriteAplLog(log)
	--按降序排列权重
	local Basket = {}
	local BuySell = "1"
	local quote = gAskQuote
	local tick = gSellTick
	local openClose = "1"
	local isRedemption = true
	if _ETFInfoTable[gETFName] then
		local etfIssue = _ETFName2IssueTable[gETFName];

		local tradeQty = _ETFInfoTable[gETFName].Unit * gTradeUnitQty;

		local orderPrice = getOrderPrice(etfIssue,quote,tick,BuySell,tradeQty)
		local orderLog = sys_format("etfIssue = %s,orderPrice = %s,tradeQty = %s",etfIssue,orderPrice,tradeQty)
		_WriteAplLog(orderLog)
		--下单
		MarketSubmitSingleBasket(etfIssue,BuySell,tradeQty,orderPrice,openClose,isRedemption,"")
		logs = sys_format("赎回成分股:[%s]完成",gETFName);
		sendLog(logs)
	else
		sendLog("ETF信息错误！")
	end
end

--买入ETF
function MarketBuyETF()
		local log = sys_format("ETF:MarketBuyETF")
	_WriteAplLog(log)

	local Basket = {}
	local buySell = "3"
	local isRedemption = false
	local quote = ""
	local tick = ""
	local openClose = ""
	if buySell == "3" then
		tick = gBuyTick
		quote = gBidQuote
		openClose = "0"
	else
		tick = gSellTick
		quote = gAskQuote
		openClose = "1"
	end
	if _ETFInfoTable[gETFName] then
		local etfIssue = _ETFName2IssueTable[gETFName];

		local tradeQty = _ETFInfoTable[gETFName].Unit * gTradeUnitQty;
		--使用ETF可赎回余额
		if gUseETFAvlRed == "True" then
			local tempQty = tradeQty - gETFAvlRedNum
			if tempQty < 0 then
				sendLog("使用可赎回余额大于ETF买入量！停止交易！")
				return
			else
				tradeQty = tempQty
			end
		end

		local orderPrice = getOrderPrice(etfIssue,quote,tick,buySell,tradeQty)
		--下单
		if tradeQty > _MaxOrderSumitQty then
			MarketSplitQuantity(etfIssue,tradeQty,orderPrice,buySell)
		else
			MarketSubmitSingleBasket(etfIssue,buySell,tradeQty,orderPrice,openClose,isRedemption,"")
		end
		logs = sys_format("买入ETF:[%s]完成",gETFName);
		sendLog(logs)
	else
		sendLog("ETF信息错误！")
	end
end

--卖出ETF
function MarketSellETF()
	local log = sys_format("ETF:MarketSellETF")
	_WriteAplLog(log)
	local buySell = "1"
	local quote = gAskQuote
	local tick = gSellTick
	local openClose = "1"
	local isRedemption = false
	if _ETFInfoTable[gETFName] then
		local etfIssue = _ETFName2IssueTable[gETFName];
		local tradeQty = _ETFInfoTable[gETFName].Unit * gTradeUnitQty;
		local orderPrice = getOrderPrice(etfIssue,quote,tick,buySell,tradeQty)
		if tradeQty > _MaxOrderSumitQty then
			MarketSplitQuantity(etfIssue,tradeQty,orderPrice,buySell)
		else
			MarketSubmitSingleBasket(etfIssue,buySell,tradeQty,orderPrice,openClose,isRedemption,"")
		end
		logs = sys_format("卖出ETF:[%s]完成",gETFName);
		sendLog(logs)
	else
		sendLog("ETF信息错误！")
	end
end

---Position下单封装部分
--Position下单成分股开仓
function PosBuyComponent(sessionID)

end
--Position下单成分股开仓
function PosSellComponent(sessionID)

end

--Position下单成分股开仓
function PosCreETF(sessionID)

end
--Position下单成分股开仓
function PosRedeemETF(sessionID)

end
--Position下单成分股开仓
function PosBuyETF(sessionID)

end
--Position下单成分股开仓
function PosSellETF(sessionID)

end
----------------------------------------------------------------------------------
-----------------------------设定使用余额-------------------------------------------
--使用股票可申购余额
_DefineEventObject SetUseStockAvlCreRed _AS _Input
	_DefFld("Flag",_String,20)
_End

_OnEventDefined(SetUseStockAvlCreRed evt)
	local flag = evt._GetFld("Flag")
	local log = sys_format("使用ETF可赎回余额:SetUseETFAvlRed ,Flag = %s",flag)
	--_WriteAplLog(log)
	if gUseStockAvlCreRed == flag then
		local flog = sys_format("SetUseStockAvlCreRed:Change Will Not happen Flag = [%s]",flag)
		_WriteAplLog(flog)
	else
		if flag == "True" then
			for IssueCode,value in pairs(gtETFComponentTradeInfo) do
				CashRepl_SingleIssueUseBalance(IssueCode,"√")
			end
		else
			for IssueCode,value in pairs(gtETFComponentTradeInfo) do
				CashRepl_SingleIssueUseBalance(IssueCode,"")
			end
		end

		gUseStockAvlCreRed = flag
	end
_End


--使用ETF可赎回余额
_DefineEventObject SetUseETFAvlRed _AS _Input
	_DefFld("Flag",_String,20)
_End

_OnEventDefined(SetUseETFAvlRed evt)
	local flag = evt._GetFld("Flag")
	local log = sys_format("使用ETF可赎回余额:SetUseETFAvlRed ,Flag = %s",flag)
	--_WriteAplLog(log)
	if gUseETFAvlRed == flag then

	else
		gUseETFAvlRed = flag
	end
_End

--设置可赎回数量
_DefineEventObject InputETFAvlRedNum _AS _Input
	_DefFld("Number",_String,20)
_End

_OnEventDefined(InputETFAvlRedNum evt)
	local num = evt._GetFld("Number")
	local log = sys_format("InputETFAvlRedNum number = %s",num)
	--_WriteAplLog(log)
	if num == "" then
		gETFAvlRedNum = 0
	else
		gETFAvlRedNum = num.getNumberValue()
	end
_End
--重置使用余额
_DefineEventObject ResetUseAvl _AS _Output
	_DefFld("Flag",_String,20)
_End
function resetUseAvl()
	local DTSEvent evt = _CreateEventObject("ResetUseAvl")
	--_WriteAplLog("resetUseAvl()")
	gUseStockAvlCreRed = "False" --使用股票可申购余额
	gUseETFAvlRed = "False" --使用ETF可申购余额
	evt._SetFld("Flag","True")
	_SendToClients(evt)
end

function MarketSplitQuantity(issueCode,quantity,orderPrice,buySell)
	if quantity > _MaxOrderSumitQty then
		--local etfIssue = _ETFName2IssueTable[gETFName];
		local logs = "";
		local _Int submitTimes = quantity / _MaxOrderSumitQty;
		local remain = quantity % _MaxOrderSumitQty;
		local _Int submitTimeforLog = submitTimes;
		logs = sys_format("MarketSplitQuantity Times:%s,remain:%s",submitTimes,remain);
		if remain > 0 then
			submitTimeforLog = submitTimeforLog + 1;
		end
		logs = sys_format("下单数量过大,将分%s次下单!",submitTimeforLog);
		sendLog(logs);

		local isRedemption = false
		--submit order for times

		local quote = ""
		local tick = ""
		local openClose = ""
		if buySell == "3" then
			bs = "买入";
			openClose = "0"
		else
			bs = "卖出";
			openClose = "1"
		end

--		local orderPrice = getOrderPrice(issueCode,quote,tick,buySell,quantity)
		for i = 1,submitTimes,1 do
			logs = sys_format("%s%s股%s下单",bs,_MaxOrderSumitQty,issueCode);
			sendLog(logs);
			MarketSubmitSingleBasket(issueCode,buySell,_MaxOrderSumitQty,orderPrice,openClose,isRedemption,"")
		end

		if remain > 0 then
			logs = sys_format("%s%s股%s下单",bs,remain,issueCode);
			sendLog(logs);
			MarketSubmitSingleBasket(issueCode,buySell,remain,orderPrice,openClose,isRedemption,"")
		end
		return true;
	else
		return false;
	end
end


--查询可开可平回调
_OnEventDefined(QueryFund qfEvent)
	local queryIssue = qfEvent._GetFld("IssueCode")
	_PosRegisterPrice(queryIssue)
    --柜台查询模式
    if spInvestorMode == 1 then
        gMQTradeIssueCode = queryIssue
        MarketsendFundReply(queryIssue)
    end
_End


 --柜台查询模式的下单模块资金可卖数设置
function MarketsendFundReply(issueCode)
    if  gMQTradeIssueCode ~= issueCode then
        return false
    end

	if _PosStatus ~= POS_STATUS_NORMAL then
		return false --未初始化
	end
	local priceInfo = _PosPriceTable[issueCode]
	if not priceInfo then
		return false
	end

    if gtInvestorFundStatus[spBAMapID]  == nil then
        return
    end

    local AvlQty = 0
    local avlFund = gtInvestorFundStatus[spBAMapID].AvlFund
    if gtInvestorPositionInfo[issueCode] then
        AvlQty = gtInvestorPositionInfo[issueCode].AvlQuantity
    end

	local avlOpenQty = "0"
    local accountCode = _PosBAMapAccount[spBAMapID]
	local contractSize = _PosIssueContractSizeTable[issueCode]
	local bail = _PosGetBail(accountCode, issueCode)
	if priceInfo.LastPrice == nil then
		priceInfo.LastPrice = 0
	end
	if priceInfo.LastPrice ~= 0 then
        local estimateQty = sys_format("%.0f", avlFund / priceInfo.LastPrice / contractSize / bail)
        --估计手续费
        local order = {}
        order.IsInternal = 0
        order.Quantity = estimateQty
        order.Price = priceInfo.LastPrice
        order.OpenClose = 0
        order.CreRed = 0
        order.BS = "3"
        local estimateFare = PosEstimateFare(accountCode, issueCode, order)

		avlOpenQty = sys_format("%.0f", (avlFund - estimateFare) / priceInfo.LastPrice / contractSize / bail)
	end

	local avlBuyCloseQty = sys_format("%.0f", AvlQty)
	local avlSellCloseQty = 0
	local strAvlFund = sys_format("%.2f", avlFund)
--	local log = sys_format("MarketsendFundReply issueCode:%s, avlBuyCloseQty:%s,avlSellCloseQty:%s",issueCode, avlBuyCloseQty,avlSellCloseQty)
--	_WriteAplLog(log)
	DTSEvent fReply = _CreateEventObject("FundReply")
	fReply._SetFld("IssueCode",issueCode)
	fReply._SetFld("AvlibFund",strAvlFund)
	fReply._SetFld("AvlibOpenatQty",avlOpenQty)
	fReply._SetFld("AvlibBuyCloseQty",avlBuyCloseQty)
	fReply._SetFld("AvlibSellCloseQty",avlSellCloseQty);
	_SendToClients(fReply);
end
