﻿--@@Version:1.00.100.20131227@@
--@@Version:1.00.100.20131129@@

gtYJVirtualTaskInfo = {}
gtBuyETFCompToVirtualTask = {}
gtBuyETFCompExecInfo = {}
gtZJVirtualTaskInfo = {}
gtSellETFCompExecInfo = {}
gtSellETFCompToVirtualTask = {}

_DefineEventObject VirtualTaskInfo _AS _Output
	_DefFld("No",_Int,4) --序号
	_DefFld("StartTime",_String,8) --开始时间
	_DefFld("EndTime",_String,8) --结束时间
	_DefFld("ETFName",_String,30) --ETF
	_DefFld("Type",_String,8) --类型
	_DefFld("BuyAmount",_Number,4) --买入成本
	_DefFld("SellIncome",_Number,4) --卖出收入
	_DefFld("Fare",_Number,4) --费用
	_DefFld("ETFDisc",_Number,4) --ETF折算
	_DefFld("EstimateProfit",_Number,4) --预估利润
	_DefFld("Status",_String,12) --状态

	_DefKeyField("ETFName");
	_DefKeyField("No");
	_DefKeyField("Type");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End



----------------------------函数定义开始-----------------------------------
--创建溢价虚拟头寸信息
function CreateYJVirtualTaskInfo(BatchID, ETFIssueCode,BuyETFCompBasketQty)
	local log = sys_format("In CreateYJVirtualTaskInfo,BatchID:%s,ETFIssueCode:%s,BuyETFCompBasketQty:%s",BatchID, ETFIssueCode,BuyETFCompBasketQty)
	_WriteAplLog(log)
	for i=1, BuyETFCompBasketQty do
		gtYJVirtualTaskInfo[ETFIssueCode] = gtYJVirtualTaskInfo[ETFIssueCode] or {}
		local taskInfo = {}
		local DTSTime nowTime = _GetNowTime()
		taskInfo.StartTime = nowTime.asString("%H:%M:%S")
		taskInfo.EndTime = "--:--:--"
		taskInfo.BuyETFCompBatchID = BatchID
		local FundName = _ETFIssue2NameTable[ETFIssueCode]
		local accountCode = _PosBAMapAccount[spBAMapID]
		local fare = _PosGetFare(accountCode, ETFIssueCode)
		taskInfo.CreETFFare = 0
		taskInfo.EstimateRestCreETFFare = _ETFInfoTable[FundName].Unit * fare.CreFare
		taskInfo.CreETFQty = 0
		taskInfo.SellETFQty = 0
		taskInfo.SellETFAmount = 0
		taskInfo.SellETFFare = 0
		taskInfo.ETFDisc = 0
		taskInfo.EstimateProfit = 0
		taskInfo.Status = "未申购"

		sys_insert(gtYJVirtualTaskInfo[ETFIssueCode], taskInfo)
		local size = sys_getSize(gtYJVirtualTaskInfo[ETFIssueCode])
		gtBuyETFCompToVirtualTask[BatchID] = gtBuyETFCompToVirtualTask[BatchID] or {}
		sys_insert(gtBuyETFCompToVirtualTask[BatchID], size)

		local log = sys_format("size:%s",size)
		_WriteAplLog(log)

	end
end

--添加买入成份股的篮子信息
function AddBuyETFCompExecInfo(BatchID, ETFIssueCode,BuyETFCompBasketQty)
	local log = sys_format("In AddBuyETFCompExecInfo,BatchID:%s,ETFIssueCode:%s,BuyETFCompBasketQty:%s",BatchID, ETFIssueCode,BuyETFCompBasketQty)
	_WriteAplLog(log)
	gtBuyETFCompExecInfo[BatchID] = gtBuyETFCompExecInfo[BatchID]  or {}
	gtBuyETFCompExecInfo[BatchID].ETFIssueCode = ETFIssueCode
	gtBuyETFCompExecInfo[BatchID].BuyETFCompBasketQty = BuyETFCompBasketQty
	gtBuyETFCompExecInfo[BatchID].BuyETFCompAmount = 0
	gtBuyETFCompExecInfo[BatchID].BuyETFCompFare = 0
	--计算预估金额和费用
	local AmountAndFare = CalcCompTradeEstimateAmountAndFare(ETFIssueCode,BatchID,"3")
	gtBuyETFCompExecInfo[BatchID].EstimateAmount = AmountAndFare.EstimateAmount
	gtBuyETFCompExecInfo[BatchID].EstimateFare = AmountAndFare.EstimateFare
	gtBuyETFCompExecInfo[BatchID].YJTBAmount = AmountAndFare.YJTBAmount
	gtBuyETFCompExecInfo[BatchID].YJOtherAmount = AmountAndFare.YJOtherAmount
	gtBuyETFCompExecInfo[BatchID].YJCashAmount = AmountAndFare.YJCashAmount
	gtBuyETFCompExecInfo[BatchID].MustAmount = AmountAndFare.MustAmount


end

--计算买入成交的成分股
function CalExecutionCost(BatchID, IssueCode, CorpCode, ExecValue, expense, ExecutionQuantity, ExecutionPrice, Price)
	local log = sys_format("In CalExecutionCost,BatchID:%s, IssueCode:%s, CorpCode:%s, ExecValue:%s, expense:%s, ExecutionQuantity:%s, ExecutionPrice:%s, Price:%s",BatchID, IssueCode, CorpCode, ExecValue, expense, ExecutionQuantity, ExecutionPrice, Price)
	_WriteAplLog(log)
	gtBuyETFCompExecInfo[BatchID].BuyETFCompAmount =  gtBuyETFCompExecInfo[BatchID].BuyETFCompAmount + ExecValue
	gtBuyETFCompExecInfo[BatchID].BuyETFCompFare = gtBuyETFCompExecInfo[BatchID].BuyETFCompFare + expense
end


--计算ETF卖出评估费用
function CalSellETFEstimateFare(ETFIssueCode,Quantity)
	local EstimateFare = 0
	local order = {}
	local PriceInfo = _PosPriceTable[ETFIssueCode]
	if PriceInfo then
		if PriceInfo.LastPrice then
			order.Price = PriceInfo.LastPrice
		else
			return EstimateFare
		end
	end
	order.Quantity = Quantity
	order.OpenClose = 1
	order.BS = "1"
	order.CreRed = 0
	local accountCode = _PosBAMapAccount[spBAMapID]
	EstimateFare = PosEstimateFare(accountCode,ETFIssueCode,order)
	return EstimateFare
end


--卖出ETF的溢价套利虚拟头寸处理
function SellETFVirtualTaskInfoDeal(exec)
	local remainQty = exec.ExecutionQuantity
	local ExecPrice = exec.ExecutionPrice
	local ETFIssueCode = exec.IssueCode
	local FundName = _ETFIssue2NameTable[ETFIssueCode]
	local Unit = _ETFInfoTable[FundName].Unit
	for TaskID, v in pairs(gtYJVirtualTaskInfo[ETFIssueCode]) do
		if v.Status == "已申购" then
			local matchQty = 0
			if Unit - v.SellETFQty - remainQty> 0 then
				matchQty = remainQty
				remainQty = 0
			else
				matchQty = Unit - v.SellETFQty
				remainQty = remainQty - matchQty
				v.Status = "完成"
			end
			--添加matchQty数量至虚拟头寸内
			AddYJSellETFVirtualTaskInfo(ETFIssueCode, TaskID, matchQty, ExecPrice, v.Status)
			RefreshVirtualTaskInfo(ETFIssueCode,TaskID,v.Status,"溢价")
		end
		if remainQty == 0 then
			break
		--多卖的部分,不计入虚拟头寸
		end
	end
end

--添加溢价套利的卖出ETF记录
function AddYJSellETFVirtualTaskInfo(ETFIssueCode, TaskID, ExecQty, ExecPrice, Status)
    if gtYJVirtualTaskInfo[ETFIssueCode] == nil or gtYJVirtualTaskInfo[ETFIssueCode][TaskID] == nil then
        return
    end
    local ExecTable = {}
    ExecTable.SellExecQty = ExecQty
    ExecTable.SellExecPrice = ExecPrice
    gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFInfo = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFInfo or {}
    sys_insert(gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFInfo, ExecTable)
    gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFQty = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFQty + ExecQty
    gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFAmount = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFAmount + ExecQty * ExecPrice

	local accountCode = _PosBAMapAccount[spBAMapID]
	local order = {}
	order.ExecValue = ExecQty*ExecPrice
	order.ExecQty = ExecQty
	order.OpenClose = 1
	order.CreRed = 0
	order.BS = "1"
    gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFFare = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFFare + PosFare(accountCode, ETFIssueCode, order)
    gtYJVirtualTaskInfo[ETFIssueCode][TaskID].Status = Status
end


--[[
--股票行情来了,更新对应的虚拟头寸信息
function IssuePriceUpdateVirtualTaskInfo(IssueCode)
	--如果是ETF行情，更新ETF折算和预估利润
	if _ETFIssue2NameTable[IssueCode] then
		for ETFIssueCode , TaskInfo in pairs(gtYJVirtualTaskInfo) do
			for TaskID,YJVirtualTaskInfo in pairs(TaskInfo) do
				if YJVirtualTaskInfo.Status ~= "完成" then
					local BatchID = YJVirtualTaskInfo.BuyETFCompBatchID
					CalcYJEstimateProfit(ETFIssueCode,TaskID)
					RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"", "溢价")
				end
			end
		end
		for ETFIssueCode , TaskInfo in pairs(gtZJVirtualTaskInfo) do
			for TaskID,ZJVirtualTaskInfo in pairs(TaskInfo) do
				if ZJVirtualTaskInfo.Status ~= "完成" then
					CalcZJEstimateProfit(ETFIssueCode,TaskID)
					RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"", "折价")
				end
			end
		end
	end

	--成分股行情
	if gtETFComponentTradeInfo[IssueCode] then
		--溢价买入成分股已下单，不更新;折价如果还没有卖出成分股下单，则更新成分股卖出预估收入
		for ETFIssueCode, TaskInfo in pairs(gtZJVirtualTaskInfo) do
			if TaskInfo.SellETFCompBatchID ~= "" then		--还未挂单卖出成分股
				for TaskID,ZJVirtualTaskInfo in pairs(TaskInfo) do
					CalcZJEstimateProfit(ETFIssueCode,TaskID)
					RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"", "折价")
				end
			end
		end
	end
end
]]


--创建折价虚拟头寸信息
function CreateZJVirtualTaskInfo(ETFIssueCode,BuyETFQty,ExecPrice)
	local remainQty = BuyETFQty
	local taskList = {}
	local size = 0
	gtZJVirtualTaskInfo[ETFIssueCode] = gtZJVirtualTaskInfo[ETFIssueCode] or {}
	for ETFIssueCode,TaskInfo in pairs(gtZJVirtualTaskInfo) do
		size = size + sys_getSize(TaskInfo)
	end
	while remainQty > 0 do
		local matchQty = 0
		local FundName = _ETFIssue2NameTable[ETFIssueCode]
		local accountCode = _PosBAMapAccount[spBAMapID]
		local Unit = _ETFInfoTable[FundName].Unit
		if Unit - remainQty> 0 then
			matchQty = remainQty
			remainQty = 0
		else
			matchQty = Unit
			remainQty = remainQty - matchQty
		end
		size = size + 1
		local TaskID = size
		local taskInfo = {}
		local DTSTime nowTime = _GetNowTime()
		taskInfo.StartTime = nowTime.asString("%H:%M:%S")
		taskInfo.EndTime = "--:--:--"
		local ExecTable = {}
		ExecTable.BuyExecQty = matchQty
		ExecTable.BuyExecPrice = ExecPrice
		taskInfo.BuyETFInfo = {}
		sys_insert(taskInfo.BuyETFInfo, ExecTable)


		local order = {}
		order.ExecValue = matchQty*ExecPrice
		order.ExecQty = matchQty
		order.OpenClose = 0
		order.CreRed = 0
		order.BS = "3"

		local fare = _PosGetFare(accountCode, ETFIssueCode)
		taskInfo.EstimateRestRedETFFare = Unit * fare.RedFare
		taskInfo.RedETFFare = 0
		taskInfo.RedETFQty = 0
		taskInfo.BuyETFQty = matchQty
		taskInfo.BuyETFAmount = matchQty * ExecPrice
		taskInfo.BuyETFFare = PosFare(accountCode, ETFIssueCode, order)
		taskInfo.SellETFCompBatchID = ""
		taskInfo.Status = "未赎回"

		gtZJVirtualTaskInfo[ETFIssueCode][TaskID]=taskInfo
		sys_insert(taskList, TaskID)

		local ret = CalcZJETFDisc(ETFIssueCode,TaskID)
		local EstimateAmount = ret.EstimateAmount
		local ZJTBAmount = ret.ZJTBAmount
		gtZJVirtualTaskInfo[ETFIssueCode][TaskID].ETFDisc = ret.ETFDisc
		gtZJVirtualTaskInfo[ETFIssueCode][TaskID].EstimateProfit = CalcZJEstimateProfit(ETFIssueCode,TaskID,EstimateAmount,ZJTBAmount)
	end
	return taskList
end


--计算买入ETF评估费用
function CalBuyETFEstimateFare(ETFIssueCode,Quantity)
	local EstimateFare = 0
	local order = {}
	local PriceInfo = _PosPriceTable[ETFIssueCode]
	if PriceInfo then
		if PriceInfo.LastPrice then
			order.Price = PriceInfo.LastPrice
		else
			return EstimateFare
		end
	end
	order.Quantity = Quantity
	order.OpenClose = 0
	order.BS = "3"
	order.CreRed = 0
	local accountCode = _PosBAMapAccount[spBAMapID]
	EstimateFare = PosEstimateFare(accountCode,ETFIssueCode,order)
	return EstimateFare
end


--添加折价套利的买入ETF记录
function AddZJBuyETFVirtualTaskInfo(ETFIssueCode, TaskID, ExecQty, ExecPrice)
	if gtZJVirtualTaskInfo[ETFIssueCode] == nil or gtZJVirtualTaskInfo[ETFIssueCode][TaskID] == nil then
		return
	end
	local ExecTable = {}
	ExecTable.BuyExecQty = ExecQty
	ExecTable.BuyExecPrice = ExecPrice
	gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFInfo = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFInfo or {}
	sys_insert(gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFInfo, ExecTable)
	gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFQty = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFQty + ExecQty
	gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFAmount = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFAmount + ExecQty * ExecPrice

	local accountCode = _PosBAMapAccount[spBAMapID]
	local order = {}
	order.ExecValue = ExecQty*ExecPrice
	order.ExecQty = ExecQty
	order.OpenClose = 0
	order.CreRed = 0
	order.BS = "3"
	gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFFare = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFFare + PosFare(accountCode, ETFIssueCode, order)
	gtZJVirtualTaskInfo[ETFIssueCode][TaskID].Status = "未赎回"
end


--买入ETF的折价套利虚拟头寸处理
function BuyETFVirtualTaskInfoDeal(exec)
	local remainQty = exec.ExecutionQuantity
	local ExecPrice = exec.ExecutionPrice
	local ETFIssueCode = exec.IssueCode
	local FundName = _ETFIssue2NameTable[ETFIssueCode]
	local Unit = _ETFInfoTable[FundName].Unit
	gtZJVirtualTaskInfo[ETFIssueCode] = gtZJVirtualTaskInfo[ETFIssueCode] or {}
	for TaskID, v in pairs(gtZJVirtualTaskInfo[ETFIssueCode]) do
		local status = v.Status
		_WriteAplLog(status)
		if v.Status == "未赎回" then
			local matchQty = 0
			local log = sys_format("before,remainQty:%s,matchQty:%s",remainQty,matchQty)
			_WriteAplLog(log)
			if Unit - v.BuyETFQty - remainQty > 0 then
				_WriteAplLog("not enough")
				matchQty = remainQty
				remainQty = 0
			else
				_WriteAplLog("enough")
				matchQty = Unit - v.BuyETFQty
				remainQty = remainQty - matchQty
			end
			log = sys_format("after,remainQty:%s,matchQty:%s",remainQty,matchQty)
			_WriteAplLog(log)
			--添加matchQty数量至虚拟头寸内
			if matchQty > 0 then
				AddZJBuyETFVirtualTaskInfo(ETFIssueCode, TaskID, matchQty, ExecPrice)
				RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"","折价")
			end
		end
		if remainQty == 0 then
			break
		end
	end
	 --创建新的TaskID虚拟头寸
	if remainQty > 0 then
		local log = sys_format("BuyETFVirtualTaskInfoDeal,ETFIssueCode:%s,remainQty:%s,ExecPrice:%s,Unit:%s",ETFIssueCode,remainQty,ExecPrice,Unit)
		_WriteAplLog(log)
		local taskLIst = CreateZJVirtualTaskInfo(ETFIssueCode,remainQty, ExecPrice)
		for i, TaskID in pairs (taskLIst) do
			RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"","折价")
		end
	end
end



--添加卖出成份股的篮子信息
function AddSellETFCompExecInfo(BatchID, ETFIssueCode,SellETFCompBasketQty)
	gtSellETFCompExecInfo[BatchID] = gtSellETFCompExecInfo[BatchID] or {}
	gtSellETFCompExecInfo[BatchID].ETFIssueCode = ETFIssueCode
	gtSellETFCompExecInfo[BatchID].SellETFCompBasketQty = SellETFCompBasketQty
	gtSellETFCompExecInfo[BatchID].SellETFCompAmount = 0
	gtSellETFCompExecInfo[BatchID].SellETFCompFare = 0
	--计算预估金额和费用
	local AmountAndFare = CalcCompTradeEstimateAmountAndFare(ETFIssueCode,BatchID,"1")
	gtSellETFCompExecInfo[BatchID].EstimateAmount = AmountAndFare.EstimateAmount
	gtSellETFCompExecInfo[BatchID].EstimateFare = AmountAndFare.EstimateFare
	gtSellETFCompExecInfo[BatchID].ZJTBAmount = AmountAndFare.ZJTBAmount
	gtSellETFCompExecInfo[BatchID].MustAmount = AmountAndFare.MustAmount
	gtSellETFCompExecInfo[BatchID].ZJCashAmount = AmountAndFare.ZJCashAmount
end


--计算卖出成交的成分股
function CalSellExecutionCost(BatchID,IssueCode, CorpCode, ExecValue, expense,ExecutionQuantity, ExecutionPrice, Price)
	if gtSellETFCompExecInfo[BatchID] then
		gtSellETFCompExecInfo[BatchID].SellETFCompAmount = gtSellETFCompExecInfo[BatchID].SellETFCompAmount + ExecValue
		gtSellETFCompExecInfo[BatchID].SellETFCompFare = gtSellETFCompExecInfo[BatchID].SellETFCompFare + expense
	end
end


--计算买入成份股和卖出成份股的预估金额和费用,供计算套利的预估利润和折价净值用。
function CalcCompTradeEstimateAmountAndFare(ETFIssueCode,BatchID,BuySell)
	local strBatchID = BatchID.toString()
	local ret = {}
	local accountCode = _PosBAMapAccount[spBAMapID]
	local EstimateAmount = 0
	local EstimateFare = 0
	local MustAmount = 0
	local YJOtherAmount = 0
	local YJTBAmount = 0
	local ZJTBAmount = 0
	local YJCashAmount = 0
	local ZJCashAmount = 0
	local ETFName = _ETFIssue2NameTable[ETFIssueCode]
	if BuySell == "3" then
		local BuyETFCompBasketQty = gtBuyETFCompExecInfo[BatchID].BuyETFCompBasketQty
		EstimateAmount =  _ETFInfoTable[ETFName].EstimateCash*BuyETFCompBasketQty - EstimateAmount
		if gBuyETFCompOrder[strBatchID] then
			EstimateAmount = EstimateAmount + gtBuyETFCompExecInfo[BatchID].BuyETFCompAmount
			EstimateFare = EstimateFare + gtBuyETFCompExecInfo[BatchID].BuyETFCompFare
			--遍历成分股清单，计算预估成本和现金替代
			for IssueCode,CompInfo in pairs(_ETFComponentTable[ETFName]) do
				local LastPrice = 0
				local AdjustedLNC = 0
				local priceInfo = _PosPriceTable[IssueCode]
				if priceInfo then
					if priceInfo.LastPrice then
						LastPrice = priceInfo.LastPrice
					end
					if priceInfo.AdjustedLNC then
						AdjustedLNC = priceInfo.AdjustedLNC
					end
				end
				local Buffer = CompInfo.CashBuffer/100
				local formatCashRepl = FormatCashRepl(ETFName,IssueCode)
				if formatCashRepl == "0 - 禁止" or formatCashRepl == "1 - 允许" then
					if gBuyETFCompOrder[strBatchID][IssueCode] then
						local ExecQty = 0
						local Quantity = 0
						local CancelQty = 0
						local WorkingQty = 0
						local RejQty = 0
						local UnAccQty = 0
						for CorpCode,OrderInfo in pairs(gBuyETFCompOrder[strBatchID][IssueCode]) do
							Quantity = Quantity + OrderInfo.Quantity
							ExecQty = ExecQty + OrderInfo.ExecQty
							CancelQty = CancelQty + OrderInfo.CancelQty
							WorkingQty = WorkingQty + OrderInfo.WorkingQty
							RejQty = RejQty + OrderInfo.RejQty
							UnAccQty  = UnAccQty + OrderInfo.UnAccQty
						end
						if formatCashRepl == "0 - 禁止" then
							EstimateAmount = EstimateAmount + (CompInfo.Quantity * BuyETFCompBasketQty - ExecQty) * LastPrice
							local order = {}
							order.IssueCode = IssueCode
							order.BS = BuySell
							order.Quantity = CompInfo.Quantity * BuyETFCompBasketQty - ExecQty
							order.Price = LastPrice
							order.CreRed = 0
							order.OpenClose = 0
							EstimateFare = EstimateFare + PosEstimateFare(accountCode, IssueCode, order)
						elseif formatCashRepl == "1 - 允许" then
							EstimateAmount = EstimateAmount + WorkingQty * LastPrice + (CompInfo.Quantity * BuyETFCompBasketQty - WorkingQty - ExecQty) * AdjustedLNC
							YJCashAmount = YJCashAmount + (CompInfo.Quantity * BuyETFCompBasketQty - WorkingQty - ExecQty) * AdjustedLNC
							YJOtherAmount = YJOtherAmount + (CompInfo.Quantity * BuyETFCompBasketQty - WorkingQty - ExecQty) * AdjustedLNC * Buffer
							local order = {}
							order.IssueCode = IssueCode
							order.BS = BuySell
							order.Quantity = WorkingQty
							order.Price = LastPrice
							order.CreRed = 0
							order.OpenClose = 0
							EstimateFare = EstimateFare + PosEstimateFare(accountCode, IssueCode, order)
						end
					else
						if formatCashRepl == "0 - 禁止" then
							EstimateAmount = EstimateAmount +CompInfo.Quantity * BuyETFCompBasketQty * LastPrice
							local order = {}
							order.IssueCode = IssueCode
							order.BS = BuySell
							order.Quantity = CompInfo.Quantity * BuyETFCompBasketQty
							order.Price = LastPrice
							order.CreRed = 0
							order.OpenClose = 0
							EstimateFare = EstimateFare + PosEstimateFare(accountCode, IssueCode, order)
						elseif formatCashRepl == "1 - 允许" then
							EstimateAmount = EstimateAmount + CompInfo.Quantity * BuyETFCompBasketQty * AdjustedLNC
							YJCashAmount = YJCashAmount + CompInfo.Quantity * BuyETFCompBasketQty * AdjustedLNC
							YJOtherAmount = YJOtherAmount + CompInfo.Quantity * BuyETFCompBasketQty * AdjustedLNC * Buffer
							local order = {}
							order.IssueCode = IssueCode
							order.BS = BuySell
							order.Quantity = CompInfo.Quantity * BuyETFCompBasketQty
							order.Price = LastPrice
							order.CreRed = 0
							order.OpenClose = 0
							EstimateFare = EstimateFare + PosEstimateFare(accountCode, IssueCode, order)
						end
					end
				elseif formatCashRepl == "2 - 必须" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * BuyETFCompBasketQty
					MustAmount = MustAmount + CompInfo.CashAmount * BuyETFCompBasketQty
				elseif formatCashRepl == "3 - 退补" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * BuyETFCompBasketQty
					YJTBAmount = YJTBAmount + CompInfo.CashAmount * BuyETFCompBasketQty * Buffer
				elseif formatCashRepl == "4 - 必须" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * BuyETFCompBasketQty
					MustAmount = MustAmount + CompInfo.CashAmount * BuyETFCompBasketQty
				end
				local log = sys_format("CalcCompTradeEstimateAmountAndFare,YJOtherAmount1:%s",YJOtherAmount)
			--	_WriteAplLog(log)
			end
		else
			--委托表还没有初始化
			--遍历成分股清单，计算预估成本和现金替代
			for IssueCode,CompInfo in pairs(_ETFComponentTable[ETFName]) do
				local LastPrice = 0
				local AdjustedLNC = 0
				local priceInfo = _PosPriceTable[IssueCode]
				if priceInfo then
					if priceInfo.LastPrice then
						LastPrice = priceInfo.LastPrice
					end
					if priceInfo.AdjustedLNC then
						AdjustedLNC = priceInfo.AdjustedLNC
					end
				end
				local Buffer = CompInfo.CashBuffer/100
				local formatCashRepl = FormatCashRepl(ETFName,IssueCode)
				if formatCashRepl == "0 - 禁止" then
					EstimateAmount = EstimateAmount + CompInfo.Quantity * BuyETFCompBasketQty * LastPrice
				elseif formatCashRepl == "1 - 允许" then
					EstimateAmount = EstimateAmount + CompInfo.Quantity * BuyETFCompBasketQty * AdjustedLNC
					YJCashAmount = YJCashAmount + CompInfo.Quantity * BuyETFCompBasketQty * AdjustedLNC
					YJOtherAmount = YJOtherAmount + CompInfo.Quantity * BuyETFCompBasketQty * AdjustedLNC * Buffer
				elseif formatCashRepl == "2 - 必须" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * BuyETFCompBasketQty
					MustAmount = MustAmount + CompInfo.CashAmount * BuyETFCompBasketQty
				elseif formatCashRepl == "3 - 退补" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount  * BuyETFCompBasketQty
					YJTBAmount = YJTBAmount + CompInfo.CashAmount * BuyETFCompBasketQty * Buffer
				elseif formatCashRepl == "4 - 必须" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * BuyETFCompBasketQty
					MustAmount = MustAmount + CompInfo.CashAmount * BuyETFCompBasketQty
				end
				local log = sys_format("CalcCompTradeEstimateAmountAndFare,YJOtherAmount2:%s",YJOtherAmount)
			--	_WriteAplLog(log)
			end

		end
		ret.EstimateAmount = EstimateAmount
		ret.MustAmount = MustAmount
		ret.YJTBAmount = YJTBAmount
		ret.YJCashAmount = YJCashAmount
		ret.YJOtherAmount = YJOtherAmount
		ret.EstimateFare = EstimateFare
	elseif BuySell == "1" then
		--遍历成分股清单，计算预估收入和现金替代
		local SellETFCompBasketQty = 1
		if gtSellETFCompExecInfo[BatchID] then
			SellETFCompBasketQty = gtSellETFCompExecInfo[BatchID].SellETFCompBasketQty
		end
		EstimateAmount = EstimateAmount + _ETFInfoTable[ETFName].EstimateCash*SellETFCompBasketQty
		if gSellETFCompOrder[strBatchID] and gtSellETFCompExecInfo[BatchID] then
			EstimateAmount = EstimateAmount + gtSellETFCompExecInfo[BatchID].SellETFCompAmount
			EstimateFare = EstimateFare + gtSellETFCompExecInfo[BatchID].SellETFCompFare
			for IssueCode,CompInfo in pairs(_ETFComponentTable[ETFName]) do
				local LastPrice = 0
				local AdjustedLNC = 0
				local priceInfo = _PosPriceTable[IssueCode]
				if priceInfo then
					if priceInfo.LastPrice then
						LastPrice = priceInfo.LastPrice
					end
					if priceInfo.AdjustedLNC then
						AdjustedLNC = priceInfo.AdjustedLNC
					end
				end
				local Buffer = CompInfo.CashBuffer/100
				local formatCashRepl = FormatCashRepl(ETFName,IssueCode)
				if formatCashRepl == "0 - 禁止" or formatCashRepl == "1 - 允许" then
					if gSellETFCompOrder[strBatchID][IssueCode] then
						local formatCashRepl = FormatCashRepl(ETFName,IssueCode)
						local ExecQty = 0
						local Quantity = 0
						local CancelQty = 0
						local WorkingQty = 0
						local RejQty = 0
						local UnAccQty = 0
						for CorpCode,OrderInfo in pairs(gSellETFCompOrder[strBatchID][IssueCode]) do
							Quantity = Quantity + OrderInfo.Quantity
							ExecQty = ExecQty + OrderInfo.ExecQty
							CancelQty = CancelQty + OrderInfo.CancelQty
							WorkingQty = WorkingQty + OrderInfo.WorkingQty
							RejQty = RejQty + OrderInfo.RejQty
							UnAccQty  = UnAccQty + OrderInfo.UnAccQty
						end
						EstimateAmount = EstimateAmount + (CompInfo.Quantity * SellETFCompBasketQty - ExecQty) * LastPrice
						local order = {}
						order.IssueCode = IssueCode
						order.BS = BuySell
						order.Quantity = CompInfo.Quantity * SellETFCompBasketQty - ExecQty
						order.Price = LastPrice
						order.CreRed = 0
						order.OpenClose = 1
						EstimateFare = EstimateFare + PosEstimateFare(accountCode, IssueCode, order)
					else
						EstimateAmount = EstimateAmount + CompInfo.Quantity * SellETFCompBasketQty * AdjustedLNC
						ZJCashAmount = ZJCashAmount + CompInfo.Quantity * SellETFCompBasketQty * AdjustedLNC
					end
				elseif formatCashRepl == "2 - 必须" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * SellETFCompBasketQty
					MustAmount = MustAmount + CompInfo.CashAmount * SellETFCompBasketQty
				elseif formatCashRepl == "3 - 退补" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount  * SellETFCompBasketQty
					ZJTBAmount = ZJTBAmount + CompInfo.CashAmount * SellETFCompBasketQty * Buffer
				elseif formatCashRepl == "4 - 必须" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * SellETFCompBasketQty
					MustAmount = MustAmount + CompInfo.CashAmount * SellETFCompBasketQty
				end
			end

		else
			--委托表还没有初始化
			for IssueCode,CompInfo in pairs(_ETFComponentTable[ETFName]) do
				local LastPrice = 0
				local AdjustedLNC = 0
				local priceInfo = _PosPriceTable[IssueCode]
				if priceInfo then
					if priceInfo.LastPrice then
						LastPrice = priceInfo.LastPrice
					end
					if priceInfo.AdjustedLNC then
						AdjustedLNC = priceInfo.AdjustedLNC
					end
				end
				local Buffer = CompInfo.CashBuffer/100
				local formatCashRepl = FormatCashRepl(ETFName,IssueCode)
				if formatCashRepl == "0 - 禁止" or formatCashRepl == "1 - 允许" then
					if LastPrice ~= 0 then
						EstimateAmount = EstimateAmount + CompInfo.Quantity * SellETFCompBasketQty * LastPrice
						local order = {}
						order.IssueCode = IssueCode
						order.BS = BuySell
						order.Quantity = CompInfo.Quantity * SellETFCompBasketQty
						order.Price = LastPrice
						order.CreRed = 0
						order.OpenClose = 1
						EstimateFare = EstimateFare + PosEstimateFare(accountCode, IssueCode, order)
					else
						EstimateAmount = EstimateAmount + CompInfo.Quantity * SellETFCompBasketQty * AdjustedLNC
						ZJCashAmount = ZJCashAmount + CompInfo.Quantity * SellETFCompBasketQty * AdjustedLNC
					end
				elseif formatCashRepl == "2 - 必须" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * SellETFCompBasketQty
					MustAmount = MustAmount + CompInfo.CashAmount * SellETFCompBasketQty
				elseif formatCashRepl == "3 - 退补" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * SellETFCompBasketQty
					ZJTBAmount = ZJTBAmount + CompInfo.CashAmount * SellETFCompBasketQty * Buffer
				elseif formatCashRepl == "4 - 必须" then
					EstimateAmount = EstimateAmount + CompInfo.CashAmount * SellETFCompBasketQty
					MustAmount = MustAmount + CompInfo.CashAmount * SellETFCompBasketQty
				end
			end
		end
		ret.EstimateAmount = EstimateAmount
		ret.MustAmount = MustAmount
		ret.ZJTBAmount = ZJTBAmount
		ret.EstimateFare = EstimateFare
		ret.ZJCashAmount = ZJCashAmount
	end
	return ret
end

--输出虚拟头寸信息
function ShowVirtualTaskInfo(ETFIssueCode,TaskID,Flag)
	local DTSEvent VirtualTaskInfoEvent = _CreateEventObject("VirtualTaskInfo")
	if Flag == "溢价" then
		local ETFName = _ETFIssue2NameTable[ETFIssueCode]
		local StartTime = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].StartTime
		local EndTime = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].EndTime
		local BuyETFCompBatchID = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFCompBatchID
		local BuyETFCompBasketQty = gtBuyETFCompExecInfo[BuyETFCompBatchID].BuyETFCompBasketQty
		local BuyETFCompAmount = (gtBuyETFCompExecInfo[BuyETFCompBatchID].BuyETFCompAmount + gtBuyETFCompExecInfo[BuyETFCompBatchID].MustAmount+gtBuyETFCompExecInfo[BuyETFCompBatchID].YJCashAmount)/BuyETFCompBasketQty + _ETFInfoTable[ETFName].EstimateCash 	--每个篮子买入成本
		if SubtractTBYJCashBufferFlag then
			BuyETFCompAmount = BuyETFCompAmount + gtBuyETFCompExecInfo[BuyETFCompBatchID].YJTBAmount/BuyETFCompBasketQty
		end

		if SubtractOtherCashBufferFlag then
			BuyETFCompAmount = BuyETFCompAmount + gtBuyETFCompExecInfo[BuyETFCompBatchID].YJOtherAmount/BuyETFCompBasketQty
		end
		local SellETFAmount = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFAmount		--卖出收入
		--费用 = 买入成分股费用 + 申购费用 + 卖出ETF费用
		BuyETFCompAmount = sys_format("%.02f",BuyETFCompAmount)
		SellETFAmount = sys_format("%.02f",SellETFAmount)
		local Fare = gtBuyETFCompExecInfo[BuyETFCompBatchID].BuyETFCompFare/BuyETFCompBasketQty + gtYJVirtualTaskInfo[ETFIssueCode][TaskID].CreETFFare + gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFFare
		Fare = sys_format("%.02f",Fare)
		local ETFDisc =  sys_format("%.03f",gtYJVirtualTaskInfo[ETFIssueCode][TaskID].ETFDisc)
		local EstimateProfit =  sys_format("%.02f",gtYJVirtualTaskInfo[ETFIssueCode][TaskID].EstimateProfit)
		local Status =  gtYJVirtualTaskInfo[ETFIssueCode][TaskID].Status

		VirtualTaskInfoEvent._SetFld("No",TaskID)
		VirtualTaskInfoEvent._SetFld("StartTime",StartTime)
		VirtualTaskInfoEvent._SetFld("EndTime",EndTime)
		VirtualTaskInfoEvent._SetFld("ETFName",ETFIssueCode)
		VirtualTaskInfoEvent._SetFld("Type","溢价")
		VirtualTaskInfoEvent._SetFld("BuyAmount",BuyETFCompAmount)
		VirtualTaskInfoEvent._SetFld("SellIncome",SellETFAmount)
		VirtualTaskInfoEvent._SetFld("Fare",Fare)
		VirtualTaskInfoEvent._SetFld("ETFDisc",ETFDisc)
		VirtualTaskInfoEvent._SetFld("EstimateProfit",EstimateProfit)
		VirtualTaskInfoEvent._SetFld("Status",Status)
		local log = sys_format("ShowVirtualTaskInfo,TaskID:%s,StartTime:%s,EndTime:%s,ETFIssueCode:%s,flag:%s,BuyETFAmount:%s,SellETFCompAmount:%s,Fare:%s,ETFDisc:%s,EstimateProfit:%s,Status:%s",TaskID,StartTime,EndTime,ETFIssueCode,Flag,BuyETFCompAmount,SellETFAmount,Fare,ETFDisc,EstimateProfit,Status)
		_WriteAplLog(log)
	elseif Flag == "折价" then
		local ETFName = _ETFIssue2NameTable[ETFIssueCode]
		local StartTime = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].StartTime
		local EndTime = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].EndTime
		local SellETFCompBatchID = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFCompBatchID
		local BuyETFAmount = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFAmount			--买入成本
		local SellETFCompAmount = 0
		local SellETFCompFare = 0
		if SellETFCompBatchID ~= "" and SellETFCompBatchID  ~= nil  then
			local SellETFCompBasketQty = gtSellETFCompExecInfo[SellETFCompBatchID].SellETFCompBasketQty
			SellETFCompAmount = (gtSellETFCompExecInfo[SellETFCompBatchID].SellETFCompAmount+gtSellETFCompExecInfo[SellETFCompBatchID].MustAmount+gtSellETFCompExecInfo[SellETFCompBatchID].ZJCashAmount)/SellETFCompBasketQty - _ETFInfoTable[ETFName].EstimateCash	--卖出收入
			SellETFCompFare = gtSellETFCompExecInfo[SellETFCompBatchID].SellETFCompFare/SellETFCompBasketQty
			if SubtractTBZjCashBufferFlag == false then
				SellETFCompAmount = SellETFCompAmount + gtSellETFCompExecInfo[SellETFCompBatchID].ZJTBAmount/SellETFCompBasketQty
			end
		end
		BuyETFAmount = sys_format("%.02f",BuyETFAmount)
		SellETFCompAmount = sys_format("%.02f",SellETFCompAmount)
		--费用 = 买入ETF费用 + 赎回成分股费用 + 卖出成分股费用
		local Fare = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFFare + gtZJVirtualTaskInfo[ETFIssueCode][TaskID].RedETFFare + SellETFCompFare
		Fare = sys_format("%.02f",Fare)
		local ETFDisc =  sys_format("%.03f",gtZJVirtualTaskInfo[ETFIssueCode][TaskID].ETFDisc)
		local EstimateProfit =  sys_format("%.02f",gtZJVirtualTaskInfo[ETFIssueCode][TaskID].EstimateProfit)
		local Status =  gtZJVirtualTaskInfo[ETFIssueCode][TaskID].Status

		VirtualTaskInfoEvent._SetFld("No",TaskID)
		VirtualTaskInfoEvent._SetFld("StartTime",StartTime)
		VirtualTaskInfoEvent._SetFld("EndTime",EndTime)
		VirtualTaskInfoEvent._SetFld("ETFName",ETFIssueCode)
		VirtualTaskInfoEvent._SetFld("Type","折价")
		VirtualTaskInfoEvent._SetFld("BuyAmount",BuyETFAmount)
		VirtualTaskInfoEvent._SetFld("SellIncome",SellETFCompAmount)
		VirtualTaskInfoEvent._SetFld("Fare",Fare)
		VirtualTaskInfoEvent._SetFld("ETFDisc",ETFDisc)
		VirtualTaskInfoEvent._SetFld("EstimateProfit",EstimateProfit)
		VirtualTaskInfoEvent._SetFld("Status",Status)
		local log = sys_format("ShowVirtualTaskInfo,TaskID:%s,StartTime:%s,EndTime:%s,ETFIssueCode:%s,flag:%s,BuyETFAmount:%s,SellETFCompAmount:%s,Fare:%s,ETFDisc:%s,EstimateProfit:%s,Status:%s",TaskID,StartTime,EndTime,ETFIssueCode,Flag,BuyETFAmount,SellETFCompAmount,Fare,ETFDisc,EstimateProfit,Status)
		_WriteAplLog(log)
	end


	_SendToClients(VirtualTaskInfoEvent)
end

--刷新虚拟头寸的任务信息,并更新至画面
function RefreshVirtualTaskInfo(ETFIssueCode,TaskID,Status, Flag)
	local log = sys_format("In RefreshVirtualTaskInfo,ETFIssueCode:%s,TaskID:%s,Status:%s, Flag:%s",ETFIssueCode,TaskID,Status, Flag)
	_WriteAplLog(log)
	if Flag == "溢价" then
		local BatchID = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFCompBatchID
		gtYJVirtualTaskInfo[ETFIssueCode][TaskID].ETFDisc = CalcYJETFDisc(ETFIssueCode,TaskID)
		gtYJVirtualTaskInfo[ETFIssueCode][TaskID].EstimateProfit = CalcYJEstimateProfit(ETFIssueCode,TaskID)
		if Status ~= "" then
			gtYJVirtualTaskInfo[ETFIssueCode][TaskID].Status = Status
		end
		if Status == "完成" then
			if gtYJVirtualTaskInfo[ETFIssueCode][TaskID].EndTime == "--:--:--" then
				local DTSTime nowTime = _GetNowTime()
				gtYJVirtualTaskInfo[ETFIssueCode][TaskID].EndTime = nowTime.asString("%H:%M:%S")
			end
		end
	elseif Flag == "折价" then
		local ret = CalcZJETFDisc(ETFIssueCode,TaskID)
		gtZJVirtualTaskInfo[ETFIssueCode][TaskID].ETFDisc = ret.ETFDisc
		local EstimateAmount = ret.EstimateAmount
		local ZJTBAmount = ret.ZJTBAmount
		gtZJVirtualTaskInfo[ETFIssueCode][TaskID].EstimateProfit = CalcZJEstimateProfit(ETFIssueCode,TaskID,EstimateAmount,ZJTBAmount)
		if Status ~= "" then
			gtZJVirtualTaskInfo[ETFIssueCode][TaskID].Status = Status
		end
		if Status == "完成" then
			if gtZJVirtualTaskInfo[ETFIssueCode][TaskID].EndTime == "--:--:--" then
				local DTSTime nowTime = _GetNowTime()
				gtZJVirtualTaskInfo[ETFIssueCode][TaskID].EndTime = nowTime.asString("%H:%M:%S")
			end
		end
	end
	ShowVirtualTaskInfo(ETFIssueCode,TaskID,Flag)
end



--根据成交回报,更新虚拟头寸的相关信息。
function OnExecVirtualTaskInfoUpdate(exec)
	local IssueCode = exec.IssueCode
	local ExecutionQuantity	= exec.ExecutionQuantity
	local ExecutionPrice = exec.ExecutionPrice
	local Price = exec.Price
	local BuySell = exec.BuySell
	local expense = exec.expense
	local CorpCode = exec.CorpCode
	local ExecValue = exec.ExecValue
	local BatchID = exec.BatchID
	if BatchID ~= "" and BatchID ~= nil then
		BatchID = BatchID.getNumberValue()
	end
	local log = sys_format("OnExecVirtualTaskInfoUpdate,IssueCode:%s,ExecutionQuantity:%s,ExecutionPrice:%s,Price:%s,BuySell:%s,expense:%s,CorpCode:%s,ExecValue:%s,BatchID:%s",IssueCode,ExecutionQuantity,ExecutionPrice,Price,BuySell,expense,CorpCode,ExecValue,BatchID)
	_WriteAplLog(log)
	if _ETFIssue2NameTable[IssueCode] then
		local FundName = _ETFIssue2NameTable[IssueCode]
		local Unit = _ETFInfoTable[FundName].Unit
		if exec.CreRed == 0 then
			if BuySell == "3" then
				BuyETFVirtualTaskInfoDeal(exec)
			elseif BuySell == "1" then
				SellETFVirtualTaskInfoDeal(exec)
			end
		elseif exec.CreRed == 1 then
			local lExecQty =  ExecutionQuantity
			for TaskID,TaskInfo in pairs(gtYJVirtualTaskInfo[IssueCode]) do
				if gtYJVirtualTaskInfo[IssueCode][TaskID].CreETFFare == 0 then
					gtYJVirtualTaskInfo[IssueCode][TaskID].CreETFFare = expense * Unit / ExecutionQuantity
					gtYJVirtualTaskInfo[IssueCode][TaskID].EstimateRestCreETFFare = 0
				end
				--local CreETFQty = TaskInfo.CreETFQty or 0	--已申购数量
				if TaskInfo.Status == "未申购" then
					--ExecutionQuantity = ExecutionQuantity + CreETFQty - Unit
					lExecQty = lExecQty - Unit
					if lExecQty >= 0 then
						gtYJVirtualTaskInfo[IssueCode][TaskID].CreETFQty = Unit
						RefreshVirtualTaskInfo(IssueCode,TaskID,"已申购","溢价")

					else
						--gtYJVirtualTaskInfo[IssueCode][TaskID].CreETFQty = ExecutionQuantity + Unit

						break
					end
				end
			end

		elseif exec.CreRed == 2 then
			local lExecQty =  ExecutionQuantity
			for TaskID,TaskInfo in pairs(gtZJVirtualTaskInfo[IssueCode]) do
				if gtZJVirtualTaskInfo[IssueCode][TaskID].RedETFFare == 0 then
					gtZJVirtualTaskInfo[IssueCode][TaskID].RedETFFare = expense * Unit / ExecutionQuantity
					gtZJVirtualTaskInfo[IssueCode][TaskID].EstimateRestRedETFFare = 0
				end
				--local RedETFQty = TaskInfo.RedETFQty or 0	--已赎回数量
				if TaskInfo.Status == "未赎回" then
					--ExecutionQuantity = ExecutionQuantity + RedETFQty - Unit
					lExecQty = lExecQty - Unit
					if lExecQty >= 0 then
						gtZJVirtualTaskInfo[IssueCode][TaskID].RedETFQty = Unit
						RefreshVirtualTaskInfo(IssueCode,TaskID,"已赎回","折价")
					else
						--gtZJVirtualTaskInfo[IssueCode][TaskID].RedETFQty = ExecutionQuantity + Unit
						break
					end
				end
			end
		end
	else
		if BatchID ~= "" and BatchID ~= nil then
			if exec.CreRed == 0 and BatchID > 0  then
				if BuySell == "3" then
					if not gtBuyETFCompToVirtualTask[BatchID] then
						local ETFIssueCode = gtBuyETFCompExecInfo[BatchID].ETFIssueCode
						local BuyETFCompBasketQty = gtBuyETFCompExecInfo[BatchID].BuyETFCompBasketQty
						CreateYJVirtualTaskInfo(BatchID, ETFIssueCode,BuyETFCompBasketQty)
					end
					CalExecutionCost(BatchID, IssueCode, CorpCode, ExecValue, expense, ExecutionQuantity, ExecutionPrice, Price)

					local TaskIDInfo = gtBuyETFCompToVirtualTask[BatchID]
					local ETFIssueCode = _ETFName2IssueTable[gETFName]
					for key, TaskID in pairs(TaskIDInfo) do
						RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"","溢价")
					end

				elseif BuySell == "1" then
					local LastPrice = _PosPriceTable[IssueCode].LastPrice
					CalSellExecutionCost(BatchID,IssueCode, CorpCode, ExecValue, expense,ExecutionQuantity, ExecutionPrice, LastPrice)
					CheckZJSellETFCompStatus(BatchID)
				end
			end
		end
	end
end

--将BatchID赋值到折价虚拟任务头寸信息
function AddSellETFCompToVirtualTask(BatchID,SellETFCompBasketQty)
	local ETFIssueCode = _ETFName2IssueTable[gETFName]
	local size = 0
	gtSellETFCompToVirtualTask[BatchID] = gtSellETFCompToVirtualTask[BatchID] or {}
	for BatchID,TaskInfo in pairs(gtSellETFCompToVirtualTask) do
		size = size + sys_getSize(TaskInfo)
	end
	for i=1,SellETFCompBasketQty do
		local TaskID = size+i
		if gtZJVirtualTaskInfo[ETFIssueCode][TaskID].Status == "已赎回" then
			sys_insert(gtSellETFCompToVirtualTask[BatchID],TaskID)
			gtZJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFCompBatchID = BatchID
		else
			--还未赎回,这次卖出的成分股不计入虚拟头寸
			gtSellETFCompExecInfo[BatchID] = {}
			break
		end
	end
end


--判断是否BatchID的所有卖委托都已经完成,是返回"完成",否则返回""
function CheckZJSellETFCompStatus(BatchID)
	local _String strBatchID = BatchID
	local ETFIssueCode = _ETFName2IssueTable[gETFName]
	local TaskIDInfo = gtSellETFCompToVirtualTask[BatchID]

	local Status = "完成"

	for IssueCode , CompInfo in pairs(_ETFComponentTable[gETFName]) do
		if gSellETFCompOrder[strBatchID][IssueCode] ~= nil then
			local ExecQty = 0
			local Quantity = 0
			local CancelQty = 0
			local WorkingQty = 0
			local RejQty = 0
			local UnAccQty = 0
			for CorpCode,OrderInfo in pairs( gSellETFCompOrder[strBatchID][IssueCode]) do
				Quantity = Quantity + OrderInfo.Quantity
				ExecQty = ExecQty + OrderInfo.ExecQty
				CancelQty = CancelQty + OrderInfo.CancelQty
				WorkingQty = WorkingQty + OrderInfo.WorkingQty
				RejQty = RejQty + OrderInfo.RejQty
				UnAccQty  = UnAccQty + OrderInfo.UnAccQty
			end
			--判断单子状态
			local StatusName = getOrderStatusName(Quantity, ExecQty, WorkingQty, CancelQty, RejQty, UnAccQty)
			local log = sys_format("StatusName:%s,IssueCode:%s,Quantity:%s,ExecQty:%s,WorkingQty:%s,CancelQty:%s, RejQty:%s, UnAccQty:%s",StatusName,IssueCode,Quantity, ExecQty, WorkingQty, CancelQty, RejQty, UnAccQty)
			_WriteAplLog(log)
			if StatusName == "挂单" or StatusName == "部分成交" then
				Status = ""
				break
			end
		end
	end

	for key,TaskID in pairs(TaskIDInfo) do
		RefreshVirtualTaskInfo(ETFIssueCode,TaskID,Status,"折价")
	end
end

--ETF设置发生改变时调用
function RefreshVirtualTaskEstimateProfit(SubtractTBYJCashBufferFlagChanged,SubtractOtherCashBufferFlagChanged,SubtractTBZjCashBufferFlagChanged)
	local log = sys_format("RefreshVirtualTaskEstimateProfit,%s,%s,%s",SubtractTBYJCashBufferFlagChanged,SubtractOtherCashBufferFlagChanged,SubtractTBZjCashBufferFlagChanged)
	--_WriteAplLog(log)
	local ETFIssueCode = _ETFName2IssueTable[gETFName]
	--【列表的溢价预期利润需减去退补溢价比例部分】选中标志或【列表的溢价预期利润需减去其他溢价比例部分】选中标志 发生改变
	if SubtractTBYJCashBufferFlagChanged or SubtractOtherCashBufferFlagChanged then
		for ETFIssueCode,TaskInfo in pairs(gtYJVirtualTaskInfo) do
			for TaskID,Task in pairs(TaskInfo) do
				RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"","溢价")
			end
		end
	end

	--【列表的折价预期利润需减去退补折算比例部分】选中标志 发生改变
	if SubtractTBZjCashBufferFlagChanged then
		for ETFIssueCode,TaskInfo in pairs(gtZJVirtualTaskInfo) do
			for TaskID,Task in pairs(TaskInfo) do
				RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"","折价")
			end
		end
	end
end

--刷新虚拟头寸的预估利润
function RefreshVirtualTaskProfit()
	for ETFIssueCode,YJTaskInfo in pairs(gtYJVirtualTaskInfo) do
		for TaskID,YJTask in pairs(YJTaskInfo) do
			RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"","溢价")
		end
	end

	for ETFIssueCode,ZJTaskInfo in pairs(gtZJVirtualTaskInfo) do
		for TaskID,ZJTask in pairs(ZJTaskInfo) do
			RefreshVirtualTaskInfo(ETFIssueCode,TaskID,"","折价")
		end
	end
end

--计算溢价ETF折算
function CalcYJETFDisc(ETFIssueCode,TaskID)
	local BatchID = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFCompBatchID
	local FundName = _ETFIssue2NameTable[ETFIssueCode]
	local Unit = _ETFInfoTable[FundName].Unit
	local BuyETFCompBasketQty = gtBuyETFCompExecInfo[BatchID].BuyETFCompBasketQty
	local AmountAndFare = 0
	local Status = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].Status
	local CreETFFare = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].CreETFFare
	local accountCode = _PosBAMapAccount[spBAMapID]
	if gtYJVirtualTaskInfo[ETFIssueCode][TaskID].CreETFFare == 0 then
		local fare = _PosGetFare(accountCode, ETFIssueCode)
		CreETFFare = Unit * fare.CreFare
	end
	local SellETFFare = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFFare
	local RestSellETFQty = Unit - gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFQty	 --未卖出的ETF数量
	local EstimateSellETFFare = SellETFFare + CalSellETFEstimateFare(ETFIssueCode,RestSellETFQty)
	if Status == "完成" or Status == "已申购" then
		AmountAndFare = gtBuyETFCompExecInfo[BatchID].EstimateAmount/BuyETFCompBasketQty + gtBuyETFCompExecInfo[BatchID].EstimateFare/BuyETFCompBasketQty + CreETFFare + EstimateSellETFFare
	elseif  Status == "未申购" then
		local ret = CalcCompTradeEstimateAmountAndFare(ETFIssueCode,BatchID,"3")
		gtBuyETFCompExecInfo[BatchID].EstimateAmount = ret.EstimateAmount
		gtBuyETFCompExecInfo[BatchID].EstimateFare = ret.EstimateFare
		gtBuyETFCompExecInfo[BatchID].YJTBAmount = ret.YJTBAmount
		gtBuyETFCompExecInfo[BatchID].YJOtherAmount = ret.YJOtherAmount
		gtBuyETFCompExecInfo[BatchID].YJCashAmount = ret.YJCashAmount
		AmountAndFare = ret.EstimateAmount/BuyETFCompBasketQty + ret.EstimateFare/BuyETFCompBasketQty + CreETFFare + EstimateSellETFFare
	end

	if SubtractTBYJCashBufferFlag then
		AmountAndFare = AmountAndFare + gtBuyETFCompExecInfo[BatchID].YJTBAmount/BuyETFCompBasketQty
	end

	if SubtractOtherCashBufferFlag then
		AmountAndFare = AmountAndFare + gtBuyETFCompExecInfo[BatchID].YJOtherAmount/BuyETFCompBasketQty
	end

	ret = AmountAndFare/Unit
	local log = sys_format("In CalcYJETFDisc,Status:%s,ETFIssueCode:%s,BatchID:%s,TaskID:%s,ret:%s,AmountAndFare:%s,EstimateAmount:%s,EstimateFare:%s,CreETFFare:%s,YJTBAmount:%s,YJOtherAmount:%s,EstimateSellETFFare:%s,BuyETFCompBasketQty:%s",Status,ETFIssueCode,BatchID,TaskID,ret,AmountAndFare,gtBuyETFCompExecInfo[BatchID].EstimateAmount,gtBuyETFCompExecInfo[BatchID].EstimateFare,CreETFFare,gtBuyETFCompExecInfo[BatchID].YJTBAmount,gtBuyETFCompExecInfo[BatchID].YJOtherAmount,EstimateSellETFFare,BuyETFCompBasketQty)
	_WriteAplLog(log)
	return ret
end

--计算溢价预估利润
function CalcYJEstimateProfit(ETFIssueCode,TaskID)
	local FundName = _ETFIssue2NameTable[ETFIssueCode]
	local Unit = _ETFInfoTable[FundName].Unit
	local SellETFAmount = gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFAmount
	local RestSellETFQty = Unit - gtYJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFQty	 --未卖出的ETF数量
	local PriceInfo = _PosPriceTable[ETFIssueCode]
	local LastPrice = 0
	if PriceInfo then
		if PriceInfo.LastPrice then
			LastPrice = PriceInfo.LastPrice
		end
	end
	RestSellETFAmount = RestSellETFQty * LastPrice
	ret = SellETFAmount + RestSellETFAmount - gtYJVirtualTaskInfo[ETFIssueCode][TaskID].ETFDisc*Unit

	local log = sys_format("CalcYJEstimateProfit,SellETFAmount:%s,RestSellETFAmount:%s,ret:%s",SellETFAmount,RestSellETFAmount,ret)
	_WriteAplLog(log)
	return ret
end


--计算折价ETF折算
function CalcZJETFDisc(ETFIssueCode,TaskID)
	local FundName = _ETFIssue2NameTable[ETFIssueCode]
	local BatchID = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFCompBatchID
	local SellETFCompBasketQty = 1
	if gtSellETFCompExecInfo[BatchID] then
		SellETFCompBasketQty = gtSellETFCompExecInfo[BatchID].SellETFCompBasketQty
	end
	local AmountAndFare = 0
	local RedETFFare = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].RedETFFare

	--计算买入ETF的成本和费用
	local LastPrice = 0
	local PriceInfo = _PosPriceTable[ETFIssueCode]
	if PriceInfo then
		if PriceInfo.LastPrice then
			LastPrice = PriceInfo.LastPrice
		end
	end
	local Unit = _ETFInfoTable[FundName].Unit
	local BuyETFQty = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFQty
	local RestQuantity = Unit - BuyETFQty
	EstimateBuyETFAmount = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFAmount + RestQuantity*LastPrice
	local order = {}
	order.Price = LastPrice
	order.Quantity = RestQuantity
	order.OpenClose = 0
	order.BS = "3"
	order.CreRed = 0
	local accountCode = _PosBAMapAccount[spBAMapID]
	EstimateBuyETFFare =  gtZJVirtualTaskInfo[ETFIssueCode][TaskID].BuyETFFare + PosEstimateFare(accountCode,ETFIssueCode,order)

	--计算赎回费用
	if RedETFFare == 0 then
		local fare = _PosGetFare(accountCode, ETFIssueCode)
		RedETFFare = Unit * fare.RedFare
	end

	--计算预估卖出ETF的费用
	local ret = CalcCompTradeEstimateAmountAndFare(ETFIssueCode,BatchID,"1")
	if gtSellETFCompExecInfo[BatchID] then
		gtSellETFCompExecInfo[BatchID].EstimateAmount = ret.EstimateAmount
		gtSellETFCompExecInfo[BatchID].EstimateFare = ret.EstimateFare
		gtSellETFCompExecInfo[BatchID].ZJTBAmount = ret.ZJTBAmount
		gtSellETFCompExecInfo[BatchID].MustAmount = ret.MustAmount
		gtSellETFCompExecInfo[BatchID].ZJCashAmount = ret.ZJCashAmount
	end
	AmountAndFare = EstimateBuyETFAmount + EstimateBuyETFFare + RedETFFare + ret.EstimateFare/SellETFCompBasketQty
	ret.ETFDisc = AmountAndFare/Unit

	local log = sys_format("In CalcZJETFDisc,ETFIssueCode:%s,BatchID:%s,TaskID:%s,ret:%s,AmountAndFare:%s,EstimateBuyETFAmount:%s,EstimateBuyETFFare:%s,RedETFFare:%s,EstimateSellCompFare:%s,SellETFCompBasketQty:%s ",ETFIssueCode,BatchID,TaskID,ret.ETFDisc,AmountAndFare,EstimateBuyETFAmount,EstimateBuyETFFare,RedETFFare,ret.EstimateFare,SellETFCompBasketQty )
	_WriteAplLog(log)
	return ret
end

--计算折价预估利润
function CalcZJEstimateProfit(ETFIssueCode,TaskID,EstimateAmount,ZJTBAmount)
	local SellETFCompBatchID = gtZJVirtualTaskInfo[ETFIssueCode][TaskID].SellETFCompBatchID
	local SellETFCompBasketQty = 1
	if gtSellETFCompExecInfo[SellETFCompBatchID] then
		SellETFCompBasketQty = gtSellETFCompExecInfo[SellETFCompBatchID].SellETFCompBasketQty
	end

	EstimateAmount = EstimateAmount/SellETFCompBasketQty
	ZJTBAmount = ZJTBAmount/SellETFCompBasketQty
	if SubtractTBZjCashBufferFlag == false then
		EstimateAmount = EstimateAmount + ZJTBAmount
	end

	local FundName = _ETFIssue2NameTable[ETFIssueCode]
	local Unit = _ETFInfoTable[FundName].Unit
	ret = EstimateAmount - gtZJVirtualTaskInfo[ETFIssueCode][TaskID].ETFDisc * Unit
	local log = sys_format("In CalcZJEstimateProfit,ETFIssueCode:%s,TaskID:%s,ret:%s,SellETFCompBatchID:%s,SellETFCompBasketQty:%s,EstimateAmount:%s,ZJTBAmount:%s",ETFIssueCode,TaskID,ret,SellETFCompBatchID,SellETFCompBasketQty,EstimateAmount,ZJTBAmount)
	_WriteAplLog(log)
	return ret
end
