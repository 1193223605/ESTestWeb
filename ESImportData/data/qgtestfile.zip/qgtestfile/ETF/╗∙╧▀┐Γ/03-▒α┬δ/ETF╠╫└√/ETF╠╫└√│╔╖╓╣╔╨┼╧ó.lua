﻿--@@Version:1.00.100.20131129@@
---------------------------------------全局变量初始化开始-----------------------------------------------
gtETFComponentTradeInfo = {}

---------------------------------------全局变量初始化结束-----------------------------------------------


---------------------------------------成分股信息事件定义开始-------------------------------------------
--现金替代显示
_DefineEventObject CashRepl _AS _Output
	_DefFld("IssueCode",_String,20)  --股票代码
	_DefFld("IssueName",_String,20)  --股票名称
	_DefFld("Quantity",_Int,4)  --权重数量
	_DefFld("CashRepl",_String,20)  --替代标志
	_DefFld("QuantityValue",_Int,4)  --权重市值
	_DefFld("SelectBidQuote",_String,20)  --买入盘口  下拉框
	_DefFld("BidPrice",_String,12)  --买入价格
	_DefFld("BidQuantity",_String,12)  --买盘数量
	_DefFld("UseBalanceFlag",_String,4)  --使用余额
	_DefFld("AvailCreRed",_Int,4)  --可申购余额
	_DefFld("UseCashAmountFlag",_String,4)  --现金替代
	_DefFld("CashAmount",_String,15)  --替代金额
	_DefFld("BuyQuantity",_Int,4)  --委托买入
	_DefFld("SelectAskQuote",_String,20)  --卖出盘口  下拉框
	_DefFld("AskPrice",_String,12)  --卖出价格
	_DefFld("AskQuantity",_String,12)  --盘口数量
	_DefFld("Available",_Int,4)  --可卖出数量
	_DefFld("RetainStockFlag",_String,4)  --保留股份
	_DefFld("SellQuantity",_Int,4)  --委托卖出
	_DefFld("SectorName",_String,80)  --行业名称
	_DefFld("ShowFlag",_String,1)  --显示与否

	_DefKeyField("IssueCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--是否使用余额
_DefineEventObject CashRepl_UseBalanceEvent _AS _Input
	_DefFld("IssueCode",_String,20)  --股票代码
	_DefFld("UseBalanceFlag",_String,4)  --使用余额标志
_End

--是否使用现金替代
_DefineEventObject CashRepl_UseCashAmountEvent _AS _Input
	_DefFld("IssueCode",_String,20)  --股票代码
	_DefFld("UseCashAmountFlag",_String,4)  --使用现金替代标志
_End

--是否保留股份
_DefineEventObject CashRepl_RetainStockEvent _AS _Input
	_DefFld("IssueCode",_String,20)  --股票代码
	_DefFld("RetainStockFlag",_String,4)  --保留股份标志
_End

--选择买入盘口
_DefineEventObject CashRepl_SelectBidQuoteEvent _AS _Input
	_DefFld("IssueCode",_String,20)  --股票代码
	_DefFld("SelectBidQuote",_String,20)  --买入盘口
_End

--选择卖出盘口
_DefineEventObject CashRepl_SelectAskQuoteEvent _AS _Input
	_DefFld("IssueCode",_String,20)  --股票代码
	_DefFld("SelectAskQuote",_String,20)  --卖出盘口
_End


---------------------------------------成分股信息事件定义结束-------------------------------------------


---------------------------------------回调函数定义开始-------------------------------------------------
--成分股清单信息【使用余额】字段双击事件
_OnEventDefined(CashRepl_UseBalanceEvent CashRepl_UseBalanceEvt)
	_WriteAplLog("In CashRepl_UseBalanceEvent")
	local IssueCode = CashRepl_UseBalanceEvt._GetFld("IssueCode")	--股票代码
	local UseBalanceFlag = CashRepl_UseBalanceEvt._GetFld("UseBalanceFlag")	 --使用余额标志
	CashRepl_SingleIssueUseBalance(IssueCode,UseBalanceFlag)
_End

--成分股清单信息【现金替代】字段双击事件
_OnEventDefined(CashRepl_UseCashAmountEvent	CashRepl_UseCashAmountEvt)
	_WriteAplLog("In CashRepl_UseCashAmountEvent")
	local IssueCode = CashRepl_UseCashAmountEvt._GetFld("IssueCode")	--股票代码
	local UseCashAmountFlag = CashRepl_UseCashAmountEvt._GetFld("UseCashAmountFlag")	--使用现金替代标志
	gtETFComponentTradeInfo[IssueCode].UseCashAmountFlag = UseCashAmountFlag
	gtETFComponentTradeInfo[IssueCode].CashAmount = CalcCashAmount(IssueCode)
	gtETFComponentTradeInfo[IssueCode].BuyQuantity = CalcBuyQuantity(IssueCode)
	sendCashRepltoClient(gETFName,IssueCode)
_End

--成分股清单信息【保留股份】字段双击事件
_OnEventDefined(CashRepl_RetainStockEvent CashRepl_RetainStockEvt)
	_WriteAplLog("In CashRepl_RetainStockEvent")
	local IssueCode = CashRepl_RetainStockEvt._GetFld("IssueCode")	--股票代码
	local RetainStockFlag = CashRepl_RetainStockEvt._GetFld("RetainStockFlag")	--保留股份标志
	gtETFComponentTradeInfo[IssueCode].RetainStockFlag = RetainStockFlag
	gtETFComponentTradeInfo[IssueCode].SellQuantity = CalcSellQuantity(IssueCode)
	sendCashRepltoClient(gETFName,IssueCode)
_End

--成分股清单信息【买入盘口】字段选择事件
_OnEventDefined(CashRepl_SelectBidQuoteEvent CashRepl_SelectBidQuoteEvt)
	_WriteAplLog("In CashRepl_SelectBidQuoteEvent")
	local IssueCode = CashRepl_SelectBidQuoteEvt._GetFld("IssueCode")	--股票代码
	local SelectBidQuote = CashRepl_SelectBidQuoteEvt._GetFld("SelectBidQuote")	--买入盘口
	SelectSingleIssueBidQuoteEvent(IssueCode,SelectBidQuote)
_End

--成分股清单信息【卖出盘口】字段选择事件
_OnEventDefined(CashRepl_SelectAskQuoteEvent CashRepl_SelectAskQuoteEvt)
	_WriteAplLog("In CashRepl_SelectAskQuoteEvent")
	local IssueCode = CashRepl_SelectAskQuoteEvt._GetFld("IssueCode")	--股票代码
	local SelectAskQuote = CashRepl_SelectAskQuoteEvt._GetFld("SelectAskQuote")	--卖出盘口
	SelectSingleIssueAskQuoteEvent(IssueCode,SelectAskQuote)
_End

---------------------------------------回调函数定义结束-------------------------------------------------



---------------------------------------自定义函数定义开始-----------------------------------------------
--初始化成份股交易参数信息表
function InitETFComponentTradeInfo()
	gtETFComponentTradeInfo = {}
	local ComponentTable = _ETFComponentTable[gETFName]
	for IssueCode,Component in pairs(ComponentTable) do
		if not gtETFComponentTradeInfo[IssueCode] then
			gtETFComponentTradeInfo[IssueCode] = {}
		end
		if not gInitialFlagTable[IssueCode] then
			gInitialFlagTable[IssueCode] = false
		end
		gtETFComponentTradeInfo[IssueCode].SelectBidQuote = gBidQuote
		gtETFComponentTradeInfo[IssueCode].SelectAskQuote = gAskQuote
		gtETFComponentTradeInfo[IssueCode].UseBalanceFlag = ""
		gtETFComponentTradeInfo[IssueCode].UseCashAmountFlag = ""
		gtETFComponentTradeInfo[IssueCode].RetainStockFlag = ""

		gtETFComponentTradeInfo[IssueCode].SellQuantity = CalcSellQuantity(IssueCode)
		gtETFComponentTradeInfo[IssueCode].BuyQuantity = CalcBuyQuantity(IssueCode)
		gtETFComponentTradeInfo[IssueCode].CashAmount = CalcCashAmount(IssueCode)
		local BidPriceQty = getQuotePriceAndQty(IssueCode,"自动盘口",0)
		gtETFComponentTradeInfo[IssueCode].BidPrice = BidPriceQty.Price
		gtETFComponentTradeInfo[IssueCode].BidQuantity = BidPriceQty.Quantity
		local AskPriceQty = getQuotePriceAndQty(IssueCode,"自动盘口",1)
		gtETFComponentTradeInfo[IssueCode].AskPrice = AskPriceQty.Price
		gtETFComponentTradeInfo[IssueCode].AskQuantity = AskPriceQty.Quantity
		sendCashRepltoClient(gETFName,IssueCode)
	end
end

--刷新所有成份股信息
function RefreshAllCashRepltoClient()
	for IssueCode,value in pairs(gtETFComponentTradeInfo)do
		RefreshSingleIssueTradeInfo(IssueCode)
	end
end

--刷新成份股单个合约持仓买卖价格和挂单数量
function RefreshSingleIssueTradeInfo(IssueCode)
    if gtETFComponentTradeInfo[IssueCode] then
		gtETFComponentTradeInfo[IssueCode].SellQuantity = CalcSellQuantity(IssueCode)
		gtETFComponentTradeInfo[IssueCode].BuyQuantity = CalcBuyQuantity(IssueCode)
		gtETFComponentTradeInfo[IssueCode].CashAmount = CalcCashAmount(IssueCode)

        local bidQuote = gtETFComponentTradeInfo[IssueCode].SelectBidQuote
		local BidPriceQty = getQuotePriceAndQty(IssueCode,bidQuote,0)
		gtETFComponentTradeInfo[IssueCode].BidPrice = BidPriceQty.Price
		gtETFComponentTradeInfo[IssueCode].BidQuantity = BidPriceQty.Quantity

        local askQuote = gtETFComponentTradeInfo[IssueCode].SelectAskQuote
		local AskPriceQty = getQuotePriceAndQty(IssueCode,askQuote,1)
		gtETFComponentTradeInfo[IssueCode].AskPrice = AskPriceQty.Price
		gtETFComponentTradeInfo[IssueCode].AskQuantity = AskPriceQty.Quantity
        sendCashRepltoClient(gETFName,IssueCode)
    end
end

--成份股信息显示
function sendCashRepltoClient(ETFName,IssueCode)
	local IssueName = _PosIssueNameTable[IssueCode]
	if not _ETFComponentTable[ETFName] then
		return
	end
	if not  _ETFComponentTable[ETFName][IssueCode] then
		return
	end

	local ETFComponentInfo = _ETFComponentTable[ETFName][IssueCode]
	local Quantity = ETFComponentInfo.Quantity
	local CashRepl = FormatCashRepl(ETFName,IssueCode)

	local priceInfo = _PosPriceTable[IssueCode]
	local lastprice = 0
    local AdjustedLNC = 0
	if priceInfo then
		if priceInfo.LastPrice then
			lastprice = priceInfo.LastPrice
		end
        if priceInfo.AdjustedLNC then
            AdjustedLNC = priceInfo.AdjustedLNC
        end
	end
	local QuantityValue = Quantity * lastprice
	local issueCodePirceStatus = getIssueCodePriceStatus(IssueCode)

	if issueCodePirceStatus == "SP" then
		QuantityValue = Quantity * AdjustedLNC
	end

	local SelectBidQuote = gtETFComponentTradeInfo[IssueCode].SelectBidQuote
	local BidPrice = gtETFComponentTradeInfo[IssueCode].BidPrice
	if not BidPrice then
		BidPrice = 0.00
	end
	local BidQuantity = gtETFComponentTradeInfo[IssueCode].BidQuantity
	BidQuantity = sys_format("%d",BidQuantity)
	if BidQuantity == 0 then
		BidQuantity = "-"
	end
	local UseBalanceFlag = gtETFComponentTradeInfo[IssueCode].UseBalanceFlag
	local AvailCreRed = 0
	local Available = 0
	if gtInvestorPositionInfo[IssueCode] then
		AvailCreRed = gtInvestorPositionInfo[IssueCode].AvlCreRedQuantity
		Available = gtInvestorPositionInfo[IssueCode].AvlQuantity
	end
	local UseCashAmountFlag = gtETFComponentTradeInfo[IssueCode].UseCashAmountFlag
	local CashAmount = gtETFComponentTradeInfo[IssueCode].CashAmount
	local BuyQuantity = gtETFComponentTradeInfo[IssueCode].BuyQuantity
	local SelectAskQuote = gtETFComponentTradeInfo[IssueCode].SelectAskQuote
	local AskPrice = gtETFComponentTradeInfo[IssueCode].AskPrice
	if not AskPrice then
		AskPrice = 0.00
	end
	local AskQuantity = gtETFComponentTradeInfo[IssueCode].AskQuantity
	AskQuantity = sys_format("%d",AskQuantity)
	if AskQuantity == 0 then
		AskQuantity = "-"
	end

	local RetainStockFlag = gtETFComponentTradeInfo[IssueCode].RetainStockFlag
	local SellQuantity = gtETFComponentTradeInfo[IssueCode].SellQuantity

	local DTSEvent cashReplEvent = _CreateEventObject("CashRepl")
	cashReplEvent._SetFld("IssueCode",IssueCode)
	cashReplEvent._SetFld("IssueName",IssueName)
	cashReplEvent._SetFld("Quantity",Quantity)
	cashReplEvent._SetFld("CashRepl",CashRepl)
	cashReplEvent._SetFld("QuantityValue",QuantityValue)
	cashReplEvent._SetFld("SelectBidQuote",SelectBidQuote)
	cashReplEvent._SetFld("BidPrice",BidPrice)
	cashReplEvent._SetFld("BidQuantity",BidQuantity)
	cashReplEvent._SetFld("UseBalanceFlag",UseBalanceFlag)
	cashReplEvent._SetFld("AvailCreRed",AvailCreRed)
	cashReplEvent._SetFld("UseCashAmountFlag",UseCashAmountFlag)
	cashReplEvent._SetFld("CashAmount",CashAmount)
	cashReplEvent._SetFld("BuyQuantity",BuyQuantity)
	cashReplEvent._SetFld("SelectAskQuote",SelectAskQuote)
	cashReplEvent._SetFld("AskPrice",AskPrice)
	cashReplEvent._SetFld("AskQuantity",AskQuantity)
	cashReplEvent._SetFld("Available",Available)
	cashReplEvent._SetFld("RetainStockFlag",RetainStockFlag)
	cashReplEvent._SetFld("SellQuantity",SellQuantity)
	if ETFName == gETFName then
		showFlag = "1";
	else
		showFlag = "0";
	end
	cashReplEvent._SetFld("ShowFlag", showFlag);

	local SectorName = getIssueSectorName(IssueCode)
	cashReplEvent._SetFld("SectorName",SectorName)

	local log = sys_format("In sendCashRepltoClient,  IssueCode:%s,IssueName:%s,Quantity:%s,CashRepl:%s,QuantityValue:%s,SelectBidQuote:%s,BidPrice:%s,BidQuantity:%s,UseBalanceFlag:%s,AvailCreRed:%s,UseCashAmountFlag:%s,CashAmount:%s,BuyQuantity:%s,SelectAskQuote:%s,AskPrice:%s,AskQuantity:%s,Available:%s,RetainStockFlag:%s,SellQuantity:%s,ShowFlag:%s",IssueCode,IssueName,Quantity,CashRepl,QuantityValue,SelectBidQuote,BidPrice,BidQuantity,UseBalanceFlag,AvailCreRed,UseCashAmountFlag,CashAmount,BuyQuantity,SelectAskQuote,AskPrice,AskQuantity,Available,RetainStockFlag,SellQuantity,showFlag)

	--_WriteAplLog(log)

	_SendToClients(cashReplEvent)
end

--格式化输出替代现金字段
function FormatCashRepl(ETFName,IssueCode)
	local ETFComponentInfo = _ETFComponentTable[ETFName][IssueCode]
	local CanCashRepl = ETFComponentInfo.CanCashRepl
	local formatCashRepl = ""
	local log = sys_format("FormatCashRepl: ETFName = %s,IssueCode = %s,CanCashRepl = %s",ETFName,IssueCode,CanCashRepl)
	--_WriteAplLog(log)
	if CanCashRepl == "0" or CanCashRepl == 0 then
		formatCashRepl = "0 - 禁止"
	elseif CanCashRepl == "1" or CanCashRepl == 1 then
		formatCashRepl = "1 - 允许"
	elseif CanCashRepl == "2" or CanCashRepl == 2 then
		formatCashRepl = "2 - 必须"
	elseif CanCashRepl == "3" or CanCashRepl == 3 then
		formatCashRepl = "3 - 退补"
	elseif CanCashRepl == "4" or CanCashRepl == 4 then
		formatCashRepl = "4 - 必须"
	end
	return formatCashRepl
end

function getIssueSectorName(IssueCode)
	local SectorName = ""
	if _IssueSectorTable[IssueCode] == 1 then
		SectorName = "农、林、牧、渔业"
	elseif _IssueSectorTable[IssueCode] == 2 then
		SectorName  =  "采掘业"
	elseif _IssueSectorTable[IssueCode] == 3 then
		SectorName  =  "制造业"
	elseif _IssueSectorTable[IssueCode] == 4 then
		SectorName  =  "电力、煤气及水的生产和供应业"
	elseif _IssueSectorTable[IssueCode] == 5 then
		SectorName  =  "建筑业"
	elseif _IssueSectorTable[IssueCode] == 6 then
		SectorName  =  "交通运输、仓储业"
	elseif _IssueSectorTable[IssueCode] == 7 then
		SectorName  =  "信息技术业"
	elseif _IssueSectorTable[IssueCode] == 8 then
		SectorName  =  "批发和零售贸易"
	elseif _IssueSectorTable[IssueCode] == 9 then
		SectorName  =  "金融、保险业"
	elseif _IssueSectorTable[IssueCode] == 10 then
		SectorName  =  "房地产业"
	elseif _IssueSectorTable[IssueCode] == 11 then
		SectorName  =  "社会服务业"
	elseif _IssueSectorTable[IssueCode] == 12 then
		SectorName  =  "传播与文化产业"
	elseif _IssueSectorTable[IssueCode] == 13 then
		SectorName  =  "综合类"
	end
	return SectorName
end


--将买卖盘转化为价格
function getQuotePriceAndQty(IssueCode,quote,BuySellFlag)
	local Price = 0
	local Quantity = 0
	local priceInfo =  _PosPriceTable[IssueCode]
	local issueStatus = getIssueCodePriceStatus(IssueCode)
	if issueStatus == "SP" then
		Price = priceInfo.AdjustedLNC
		Quantity = 0
	else
		if priceInfo then
			if quote == "涨停" then
				Quantity = 0
			elseif quote == "卖1" then
				Quantity = priceInfo.AskQuantity1
			elseif quote == "卖2" then
				Quantity = priceInfo.AskQuantity2
			elseif quote == "卖3" then
				Quantity = priceInfo.AskQuantity3
			elseif quote == "卖4" then
				Quantity = priceInfo.AskQuantity4
			elseif quote == "卖5" then
				Quantity = priceInfo.AskQuantity5
			elseif quote == "最新" then
				Quantity = 0
			elseif quote == "买1" then
				Quantity = priceInfo.BidQuantity1
			elseif quote == "买2" then
				Quantity = priceInfo.BidQuantity2
			elseif quote == "买3" then
				Quantity = priceInfo.BidQuantity3
			elseif quote == "买4" then
				Quantity = priceInfo.BidQuantity4
			elseif quote == "买5" then
				Quantity = priceInfo.BidQuantity5
			elseif quote == "跌停" then
				Quantity = 0
			elseif quote =="自动盘口" then
				local quantity = 0
				if BuySellFlag == 0 then
					quantity = gtETFComponentTradeInfo[IssueCode].BuyQuantity
				else
					quantity = gtETFComponentTradeInfo[IssueCode].SellQuantity
				end
				local confidence = GetConfidenceByIssueCode(IssueCode)
				--_WriteAplLog(gConfidence)
				local ret = getMarketPrice(IssueCode,BuySellFlag,quantity,confidence)
				return ret
			end
			if quote ~= "自动盘口" then
				if BuySellFlag == 0 then --买
					Price = getOrderPrice(IssueCode,quote,gBuyTick,"3")
				else
					Price = getOrderPrice(IssueCode,quote,gSellTick,"1")
				end
			end

		else
			local log = sys_format("getQuotePriceAndQty,IssueCode:%s,行情未初始化",IssueCode)
			_WriteAplLog(log)
		end
	end

    local ret = {}
	ret.Price = Price
	ret.Quantity = Quantity
	return ret
end


--单个成分股合约【使用余额】字段双击事件处理逻辑
function CashRepl_SingleIssueUseBalance(IssueCode,UseBalanceFlag)
	gtETFComponentTradeInfo[IssueCode].UseBalanceFlag = UseBalanceFlag
	gtETFComponentTradeInfo[IssueCode].CashAmount = CalcCashAmount(IssueCode)
	gtETFComponentTradeInfo[IssueCode].BuyQuantity = CalcBuyQuantity(IssueCode)
	sendCashRepltoClient(gETFName,IssueCode)
end


--计算现金替代金额
function CalcCashAmount(IssueCode)
	local issueCodePirceStatus = getIssueCodePriceStatus(IssueCode)
	local simpleLog = sys_format("CalcSellQuantity:IssueCode = [%s],PriceStatus = [%s]",IssueCode,issueCodePirceStatus)
	--_WriteAplLog(simpleLog)
	local CashRepl = _ETFComponentTable[gETFName][IssueCode].CashRepl
	local UseCashAmountFlag = gtETFComponentTradeInfo[IssueCode].UseCashAmountFlag
	local UseBalanceFlag = gtETFComponentTradeInfo[IssueCode].UseBalanceFlag
	local priceInfo = _PosPriceTable[IssueCode]
	local AdjustedLNC = 0
	local ret = 0
	if priceInfo then
        if priceInfo.AdjustedLNC then
            AdjustedLNC = priceInfo.AdjustedLNC
        end
	end

	local AvlCreRedQuantity = 0
	if gtInvestorPositionInfo[IssueCode] then
		AvlCreRedQuantity = gtInvestorPositionInfo[IssueCode].AvlCreRedQuantity
	end


	if CashRepl == "必须" or CashRepl == "深市必须" then	--必须替代，深市必须
		ret = _ETFComponentTable[gETFName][IssueCode].CashAmount * gTradeUnitQty
	elseif  CashRepl == "禁止" then  --禁止替代
		ret = 0
	elseif CashRepl == "深市退补" then  --深市退补
		ret = gTradeUnitQty * _ETFComponentTable[gETFName][IssueCode].CashAmount * (1+_ETFComponentTable[gETFName][IssueCode].CashBuffer/100)
	elseif CashRepl == "允许" then -- 允许替代
		if issueCodePirceStatus == "SP" then
	  	  ret = gTradeUnitQty * _ETFComponentTable[gETFName][IssueCode].Quantity * AdjustedLNC * (1+_ETFComponentTable[gETFName][IssueCode].CashBuffer/100)
		else
	  	    if UseCashAmountFlag == "√" then
                if UseBalanceFlag == "√" then
                    ret = sys_max(gTradeUnitQty * _ETFComponentTable[gETFName][IssueCode].Quantity - AvlCreRedQuantity, 0) * AdjustedLNC * (1+_ETFComponentTable[gETFName][IssueCode].CashBuffer/100)
	        	else
                    ret = gTradeUnitQty * _ETFComponentTable[gETFName][IssueCode].Quantity * AdjustedLNC * (1+_ETFComponentTable[gETFName][IssueCode].CashBuffer/100)
	        	end
            else
                ret = 0
            end
		end
	end
	return ret
end


--计算委托卖出数量
function CalcSellQuantity(IssueCode)
	local issueCodePirceStatus = getIssueCodePriceStatus(IssueCode)
	local simpleLog = sys_format("CalcSellQuantity:IssueCode = [%s],PriceStatus = [%s]",IssueCode,issueCodePirceStatus)
	_WriteAplLog(simpleLog)
	local CashRepl = _ETFComponentTable[gETFName][IssueCode].CashRepl
	local RetainStockFlag = gtETFComponentTradeInfo[IssueCode].RetainStockFlag
	local Quantity = _ETFComponentTable[gETFName][IssueCode].Quantity
	local ret = 0
	if issueCodePirceStatus == "SP" then
		ret = 0
	else
		if CashRepl == "必须" or CashRepl == "深市必须" or CashRepl == "深市退补" or RetainStockFlag == "√" then
			ret = 0
		else
			local AvlQuantity = 0
			if gtInvestorPositionInfo[IssueCode] then
				AvlQuantity = gtInvestorPositionInfo[IssueCode].AvlQuantity
			end
			ret = sys_min(gTradeUnitQty * _ETFComponentTable[gETFName][IssueCode].Quantity, AvlQuantity)
		end
	end
	local log = sys_format("CalcSellQuantity , IssueCode:%s,Quantity:%s,CashRepl:%s,RetainStockFlag:%s,ret:%s",IssueCode,Quantity,CashRepl,RetainStockFlag,ret)
	_WriteAplLog(log)
	return ret
end


--计算委托买入数量
function CalcBuyQuantity(IssueCode)
	local issueCodePirceStatus = getIssueCodePriceStatus(IssueCode)
	local simpleLog = sys_format("CalcBuyQuantity:IssueCode = [%s],PriceStatus = [%s]",IssueCode,issueCodePirceStatus)
	--_WriteAplLog(simpleLog)
	local CashRepl = _ETFComponentTable[gETFName][IssueCode].CashRepl
	local UseCashAmountFlag = gtETFComponentTradeInfo[IssueCode].UseCashAmountFlag
	local UseBalanceFlag = gtETFComponentTradeInfo[IssueCode].UseBalanceFlag
	local  Quantity = _ETFComponentTable[gETFName][IssueCode].Quantity
	local ret = 0
	if issueCodePirceStatus == "SP" then
		ret = 0
	else
		if CashRepl == "必须" or CashRepl == "深市必须" or CashRepl == "深市退补" then  --必须替代，深市退补，深市必须
			ret = 0
		elseif UseCashAmountFlag == "√" and CashRepl == "允许" then  --允许替代且用现金替代
			ret = 0
		else
			if UseBalanceFlag == "√" then --使用余额
	                local AvlCreRedQuantity = 0
	                if gtInvestorPositionInfo[IssueCode] then
	                    AvlCreRedQuantity = gtInvestorPositionInfo[IssueCode].AvlCreRedQuantity
	                end
				ret = sys_ceil(sys_max(gTradeUnitQty * _ETFComponentTable[gETFName][IssueCode].Quantity - AvlCreRedQuantity, 0)/100) * 100
			else
				ret = gTradeUnitQty * _ETFComponentTable[gETFName][IssueCode].Quantity
			end
		end
	end
	local log = sys_format("CalcBuyQuantity , IssueCode:%s,Quantity:%s,CashRepl:%s,UseCashAmountFlag:%s,UseBalanceFlag:%s,ret:%s",IssueCode,Quantity,CashRepl,UseCashAmountFlag,UseBalanceFlag,ret)
	--_WriteAplLog(log)
	return ret
end


--单个合约【买入盘口】字段选择事件
function SelectSingleIssueBidQuoteEvent(IssueCode,quote)
	gtETFComponentTradeInfo[IssueCode].SelectBidQuote = quote
	local ltPriceAndQty = getQuotePriceAndQty(IssueCode,quote,0)
	gtETFComponentTradeInfo[IssueCode].BidPrice = ltPriceAndQty.Price
	gtETFComponentTradeInfo[IssueCode].BidQuantity = ltPriceAndQty.Quantity
	sendCashRepltoClient(gETFName,IssueCode)
end


--单个合约【卖出盘口】字段选择事件
function SelectSingleIssueAskQuoteEvent(IssueCode,quote)
	gtETFComponentTradeInfo[IssueCode].SelectAskQuote = quote
	local ltPriceAndQty = getQuotePriceAndQty(IssueCode,quote,1)
	gtETFComponentTradeInfo[IssueCode].AskPrice = ltPriceAndQty.Price
	gtETFComponentTradeInfo[IssueCode].AskQuantity = ltPriceAndQty.Quantity
	sendCashRepltoClient(gETFName,IssueCode)
end

--返回自动盘口价格和数量
function getMarketPrice(IssueCode,OC,Quantity,Confidence)
	local marketPrice = 0
	local quantity = 0
	local priceInfo = _PosPriceTable[IssueCode]
	if priceInfo then
		local askPrice1 = priceInfo.AskPrice1 or 0
		local askPrice2 = priceInfo.AskPrice2 or 0
		local askPrice3 = priceInfo.AskPrice3 or 0
		local askPrice4 = priceInfo.AskPrice4 or 0
		local askPrice5 = priceInfo.AskPrice5 or 0
		local bidPrice1 = priceInfo.BidPrice1 or 0
		local bidPrice2 = priceInfo.BidPrice2 or 0
		local bidPrice3 = priceInfo.BidPrice3 or 0
		local bidPrice4 = priceInfo.BidPrice4 or 0
		local bidPrice5 = priceInfo.BidPrice5 or 0
		local askQty1 = priceInfo.AskQuantity1 or 0
		local askQty2 = priceInfo.AskQuantity2 or 0
		local askQty3 = priceInfo.AskQuantity3 or 0
		local askQty4 = priceInfo.AskQuantity4 or 0
		local askQty5 = priceInfo.AskQuantity5 or 0
		local bidQty1 = priceInfo.BidQuantity1 or 0
		local bidQty2 = priceInfo.BidQuantity2 or 0
		local bidQty3 = priceInfo.BidQuantity3 or 0
		local bidQty4 = priceInfo.BidQuantity4 or 0
		local bidQty5 = priceInfo.BidQuantity5 or 0
        local lastPrice = priceInfo.LastPrice or 0

		if OC == 0 then
			local Quantity1 = Quantity - askQty1*Confidence		--除去卖1量以后还需要交易的数量
			local Quantity2 = Quantity1 - askQty2*Confidence	--除去卖2量以后还需要交易的数量
			local Quantity3 = Quantity2 - askQty3*Confidence	--除去卖3量以后还需要交易的数量
			local Quantity4 = Quantity3 - askQty4*Confidence	--除去卖4量以后还需要交易的数量
			--local Quantity5 = Quantity4 - askQty5*Confidence
			if askPrice5 > 0 and Quantity4 > 0 then			--卖1量足够
				marketPrice = askPrice5
				quantity = askQty5
			elseif askPrice4 > 0 and Quantity3 >  0 then		--卖2量足够
				marketPrice = askPrice4
				quantity = askQty4
			elseif askPrice3 > 0 and Quantity2 >  0 then		--卖3量足够
				marketPrice = askPrice3
				quantity = askQty3
			elseif askPrice2 > 0 and Quantity1 > 0 then		--卖4量足够
				marketPrice = askPrice2
				quantity = askQty2
			elseif  askPrice1 > 0 and askQty1 > 0 then	--卖5量以上
				marketPrice = askPrice1
				quantity = askQty1
			else
                marketPrice = lastPrice
			end
		else
			local Quantity1 = Quantity - bidQty1*Confidence		--除去买1量以后还需要交易的数量
			local Quantity2 = Quantity1 - bidQty2*Confidence	--除去买2量以后还需要交易的数量
			local Quantity3 = Quantity2 - bidQty3*Confidence	--除去买3量以后还需要交易的数量
			local Quantity4 = Quantity3 - bidQty4*Confidence	--除去买4量以后还需要交易的数量
			--local Quantity5 = Quantity4 - bidQty5*Confidence
			if bidPrice5 > 0 and Quantity4 > 0 then			--买1量足够
				marketPrice = bidPrice5
				quantity = bidQty5
			elseif bidPrice4 > 0 and Quantity3 >  0 then		--买2量足够
				marketPrice = bidPrice4
				quantity = bidQty4
			elseif bidPrice3 > 0 and  Quantity2 > 0 then		--买3量足够
				marketPrice = bidPrice3
				quantity = bidQty3
			elseif bidPrice2 > 0 and  Quantity1 > 0 then		--买4量足够
				marketPrice = bidPrice2
				quantity = bidQty2
			elseif bidPrice1 > 0 and  bidQty1 > 0 then
				marketPrice = bidPrice1
				quantity = bidQty1
			else
                marketPrice = lastPrice
				--local log = sys_format("五档盘口数量不足:IssueCode:%s,BS:%s,Quantity:%s,Confidence:%s"IssueCode,BS,Quantity,Confidence)
			end
		end
--		local logs = sys_format("askPrice1:%s,askPrice2:%s,askPrice3:%s,askPrice4:%s,askPrice5:%s,bidPrice1:%s,bidPrice2:%s,bidPrice3:%s,bidPrice4:%s,bidPrice5:%s,askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s,marketPrice:%s",askPrice1,askPrice2,askPrice3,askPrice4,askPrice5,bidPrice1,bidPrice2,bidPrice3,bidPrice4,bidPrice5,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5,marketPrice)
		--_WriteAplLog(logs)
	end
	local ret = {}
	ret.Price = marketPrice
	ret.Quantity = quantity
	return ret
end

---------------------------------------自定义函数定义结束-----------------------------------------------
-----------------------------------------------------------------------------------------------
----------------ETF设置------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
--ETF设置
_DefineEventObject SetETF _AS _Input
	_DefFld("ETFConfidence",_String,20)--ETF置信度
	_DefFld("StockConfidence",_String,20)--股票置信度

	_DefFld("PremiumCondition1",_String,20)--列表的溢价预期利润需减去退补溢价比例部分
	_DefFld("PremiumCondition2",_String,20)--列表的溢价预期利润需减去其他溢价比例部分
	_DefFld("DisCountCondition",_String,20)--列表的折价预期利润需减去退补折算比例部分
_End
--ETF数据设置
_OnEventDefined(SetETF evt)
	local etfConfidence = evt._GetFld("ETFConfidence")
	local stockConfidence = evt._GetFld("StockConfidence")

	local premiumCondition1 = evt._GetFld("PremiumCondition1")
	local premiumCondition2 = evt._GetFld("PremiumCondition2")
	local disCountCondition = evt._GetFld("DisCountCondition")
	local log = sys_format("ETF设置:etfConfidence = %s,stockConfidence = %s,premiumCondition1 = %s, premiumCondition2 = %s,disCountCondition = %s",
	etfConfidence,stockConfidence,premiumCondition1,premiumCondition2,disCountCondition)
	_WriteCatchAplLog(log)
	_WriteAplLog(log)
		--股票置信度
	StockOrderRatio = stockConfidence.getNumberValue()/100
	--ETF置信度
	ETFOrderRatio = etfConfidence.getNumberValue()/100

	local hisSubtractTBYJCashBufferFlag = SubtractTBYJCashBufferFlag
	local hisSubtractOtherCashBufferFlag = SubtractOtherCashBufferFlag
	local hisSubtractTBZjCashBufferFlag = SubtractTBZjCashBufferFlag
	--【列表的溢价预期利润需减去退补溢价比例部分】选中标志
	if premiumCondition1 == "1" then
		SubtractTBYJCashBufferFlag = true
   	else
		SubtractTBYJCashBufferFlag = false
	end
	--【列表的溢价预期利润需减去其他溢价比例部分】选中标志
	if premiumCondition2 == "1" then
		SubtractOtherCashBufferFlag = true
	else
		SubtractOtherCashBufferFlag = false
	end
	--【列表的折价预期利润需减去退补折算比例部分】选中标志
	if disCountCondition == "1" then
		SubtractTBZjCashBufferFlag  = true
   	else
		SubtractTBZjCashBufferFlag  = false
	end
	RefreshAllCashRepltoClient()


	if hisSubtractTBYJCashBufferFlag ~= SubtractTBYJCashBufferFlag then
		SubtractTBYJCashBufferFlagChanged = true
	else
		SubtractTBYJCashBufferFlagChanged = false
	end

	if hisSubtractOtherCashBufferFlag ~= SubtractOtherCashBufferFlag then
		SubtractOtherCashBufferFlagChanged = true
	else
		SubtractOtherCashBufferFlagChanged = false
	end
	if hisSubtractTBZjCashBufferFlag ~= SubtractTBZjCashBufferFlag then
		SubtractTBZjCashBufferFlagChanged = true
	else
		SubtractTBZjCashBufferFlagChanged = false
	end
	RefreshVirtualTaskEstimateProfit(SubtractTBYJCashBufferFlagChanged,SubtractOtherCashBufferFlagChanged,SubtractTBZjCashBufferFlagChanged)
_End
---根据合约返回置信度
function GetConfidenceByIssueCode(IssueCode)
	if _ETFIssue2NameTable[IssueCode] then
		return ETFOrderRatio
	else
		return StockOrderRatio
	end
end
--策略设置获取数据
_DefineEventObject InitialSetETF _AS _Input
	_DefFld("Flag",_String,10)
_End

_OnEventDefined(InitialSetETF evt)
	local flag = evt._GetFld("Flag")
	_WriteAplLog("InitialSetETF")
	outPutConfidence()
_End

--策略设置获取数据
_DefineEventObject OutputETFSet _AS _Output

	_DefFld("ETFConfidence",_String,20)--ETF置信度
	_DefFld("StockConfidence",_String,20)--股票置信度

	_DefFld("PremiumCondition1",_String,20)--列表的溢价预期利润需减去退补溢价比例部分
	_DefFld("PremiumCondition2",_String,20)--列表的溢价预期利润需减去其他溢价比例部分
	_DefFld("DisCountCondition",_String,20)--列表的折价预期利润需减去退补折算比例部分
	---_DefFld("Flag",_String,10)
_End


function outPutConfidence()
	local DTSEvent evt = _CreateEventObject("OutputETFSet")
	--股票置信度
	local stockConfidence = 0
	if StockOrderRatio == -1 then
		stockConfidence = 100
	else
		stockConfidence = StockOrderRatio * 100
	end

	--ETF置信度
	local etfConfidence = 0
	if ETFOrderRatio == -1 then
		etfConfidence = 100
	else
		etfConfidence = ETFOrderRatio * 100
	end

	--列表的溢价预期利润需减去退补溢价比例部分
	local premiumCondition1 = "1"
	if SubtractTBYJCashBufferFlag == true then
		premiumCondition1 = "1"
	else
		premiumCondition1 = "0"
	end
	--列表的溢价预期利润需减去其他溢价比例部分
	local premiumCondition2 = "1"
	if SubtractOtherCashBufferFlag == true then
		premiumCondition2 = "1"
	else
		premiumCondition2 = "0"
	end

	--列表的折价预期利润需减去退补折算比例部分
	local disCountCondition = "1"
	if SubtractTBZjCashBufferFlag == true then
		disCountCondition = "1"
	else
		disCountCondition = "0"
	end

	evt._SetFld("ETFConfidence",etfConfidence)
	evt._SetFld("StockConfidence",stockConfidence)

	evt._SetFld("PremiumCondition1",premiumCondition1)
	evt._SetFld("PremiumCondition2",premiumCondition2)
	evt._SetFld("DisCountCondition",disCountCondition)

	local log = sys_format("outPutConfidence:stockConfidence = %s,etfConfidence = %s,premiumCondition1 = %s,premiumCondition2 = %s,disCountCondition = %s",
	stockConfidence,etfConfidence,premiumCondition1,premiumCondition2,disCountCondition)
	_WriteAplLog(log)
	_SendToClients(evt)
end
