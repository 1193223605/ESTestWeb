﻿
_WriteAplLog("ETF Trade Version:1.00.100.20131227")
sendLog("初始化中，请稍候")
--======================================================
--启动参数设置
--======================================================
_DefineStrategyParameters
	_String spBAMapID = ""		    	_Comment "证券子账户"
	_Number spRequestNum = 300  _Comment "柜台查询返回条数上限"
	--_String spLoadETFDDPID = "" 	_Comment "读取ETF清单DD模型号"
	--_String spLoadETFDDSID = ""		_Comment "读取ETF清单DD策略号"
_End

spInvestorMode = 1  --"资金账户查询模式,1为柜台查询,0为position查询"
--======================================================
--全局变量定义部分开始
--======================================================
--全局变量定义
gAutoCancelTime = 0
gBuyETFCompCount = 0			--买入成份股次数
gSellETFCompCount = 0			--卖出成份股次数
gETFName = "";	--SS中唯一的ETF
gTradeUnitQty = 1;	--篮子数
gBuyTick = 0;
gSellTick = 0;
gAmendTick = 0;	--改价价格调整
gBidQuote = "自动盘口";	--买盘
gAskQuote = "自动盘口";	--卖盘
gAmendPrice = "最新";	--改价价格
gDDFlag = 0;
gUserID=_GetDealerID();	--current user
gTradePermissionFlag = true;	--the permission of trade, controlled by Manager
gFareCalcCheck = "1"  --在计算成交成分股的综合成本时,是否计算手续费,默认计算,值为"1"时计算,其他不计算.
gCost = 0
gTradeMode = ""; --自动交易逻辑
gCheckFundFlag = false;

_CashReplacePty = 0
_IsCheckQuantity = true;
_String AccountType = "1";
gInitialFlagTable = {}

--股票置信度
StockOrderRatio = 1
--ETF置信度
ETFOrderRatio = 1
SubtractTBYJCashBufferFlag = true
SubtractOtherCashBufferFlag = true
SubtractTBZjCashBufferFlag = true
gUseStockAvlCreRed = "False" --使用股票可申购余额
gUseETFAvlRed = "False" --使用ETF可申购余额
gETFAvlRedNum = 0


--全局表定义
_IssueWeightTable = {}
_BuyStockValue = {}
_CancelOrderTable = {}
gCurrentOrderTable = {}		--当前委托key:CorpCode
gMacIpHdIDTable = {}   --网络信息
gtExpenseTable = {}    --保存费用
gAutoCancelTable = {} --自动追价
gBuyETFCompOrder = {}			--买入成份股计算综合成本 key:Num,IssueCode,CorpCode
gBuyETFCorpToBatchID = {}		--买入成份股的CorpCode和BatchID的对应

gSellETFCompOrder = {}			--卖出成份股计算综合成本 key:Num,IssueCode,CorpCode
gSellETFCorpToBatchID = {}		--卖出成份股的CorpCode和BatchID的对应

_ETFArbInfo = {};	--to store the information of Auto-Trade, like OverOrUnder and AutoOrDelay
gtQuote = {};	--以issue为key，储存买卖盘的价格和数量
gtSellExecutionCost = {};  --存放每个批号下的成本，key为批号
gtExecutionCost = {};  --存放每个批号下的成本，key为批号
_AmendOrderTable={} --改价重下
--gUserList={};
_CanBeCancelOrderTable = {} --可撤委托table
gtStopLossTable = {}
gtStopList = {}
gtWeight = {};	--set ETFName as key to map the weight(Only the number)
gtWeightOfIssue = {};	--set ETFName and weight as co-key to map issue
gtETFWeightSize = {};	--set ETFName as key to map its count of weight
gtIsWeightCalc = {};	--set ETFName as key to map if this ETF's weight has been calculated
gtIssueWeight = {};	--set ETF and issue as co-key to map weight

_IssueSectorTable = {} --读取股票行业
_SectorIssueTable = {}
--读取ETF成份股
--_ETFComponentTable = {};	--用来存放ETF相关信息,以ETFName和issueCode为双key
gETFCompCountTable = {};	--用来存放ETF相关信息,以ETFName为key
gtStockStatusTable = {}
--_ETFInfoTable = {};	--set ETFname as key to map all its infomation
_IssueETFTable = {};	--set issuecode and ETFname as co-key
--_ETFNameTable = {}	--以ETF的IssueCode为key,映射Name，用QueryETFList函数中的_ETFIssue2NameTable全局表替换
--gtETFIDtoName = {}	--以ID为KEY存放ETFName,用QueryETFList函数中的_ETFID2NameTable全局表替换
--_ETFName2IssueTable = {};	--以ETF的Name为key,映射IssueCode 用QueryETFList函数中的_ETFName2IssueTable全局表替换

--常量定义
_MaxOrderSumitQty = 1000000; --define 单笔最大买卖数量
DTSDate nowDate = _GetNowDate();	--取当前时间
_String strDate = nowDate.asString("%Y%m%d");	--时间格式化

--初始化调用

initialMarketQry()	--持仓同步初始化

--时时更新并储存的DynamicData
DTSEvent _AddETFIssueEvent = _CreateEventObject("ETFDynamicData");
DTSDynamicData ETFDDStore = _CreateDynamicData(TSInstanceName="ETFDynamicData", fileType=_DataOtherType, ETFDynamicData _AddETFIssueEvent);
ETFDDStore._GetDynamicData(dataName="ETFDynamicData", condition="");
_OnDynamicData(_dataName="ETFDynamicData", ETFDynamicData evt)
	gETFName = evt._GetFld("ETFName");
	gTradeUnitQty = evt._GetFld("TradeUnitQty");
	gBidQuote = evt._GetFld("BidQuote");
	gAskQuote = evt._GetFld("AskQuote");
	gBuyTick = evt._GetFld("BuyTick");
	gSellTick = evt._GetFld("SellTick");
	gAmendTick = evt._GetFld("AmendTick");	--改价tick
	gAmendPrice = evt._GetFld("AmendPrice");	--改价价格
	gAutoCancelTime = evt._GetFld("AutoCancelTime");
	local logs = sys_format("ETFDynamicData,gETFName:%s,gTradeUnitQty:%s,gBidQuote:%s,gAskQuote:%s,gBuyTick:%s,gSellTick:%s,gAmendTick:%s,gAmendPrice:%s,gAutoCancelTime:%s",gETFName,gTradeUnitQty,gBidQuote,gAskQuote,gBuyTick,gSellTick,gAmendTick,gAmendPrice,gAutoCancelTime)
	_WriteAplLog(logs);

	--刷新界面数据
	showBidQuote();	--显示买盘
	showAskQuote();	--显示卖盘
	showTradeUnitQty();	--显示蓝子数
	showBuyTick();	--显示买价tick
	showSellTick();	--显示卖家tick
	showAmendTick();	--显示改价tick
	showAmendPrice();	--显示改价价格
	showAutoCancelTime();
	gDDFlag = 1;
	sendCashReplacePty()
_End


if gDDFlag == 0 then
	showBidQuote();	--显示买盘
	showAskQuote();	--显示卖盘
	showTradeUnitQty();	--显示蓝子数
	showAmendPrice();	--显示改价价格
end
---------------------------------------------------
--全局变量定义部分结束
---------------------------------------------------
require("Position")
require("QueryETFInfo")
require("ETFComponentInfo")	--成分股信息显示
require("QureyShift")--资金持仓
require("ETFOrder")--下单修改
require("VirtualTask")--虚拟持仓
--======================================================
--Position初始化部分开始
--======================================================
PosInitialize();
--注释ETF清单来自于数据库，换成采用DD模式
_PosNeedAdjPrice = false


--暂且清单数据都来自于数据库
--POS_LOADETFDD_PID = spLoadETFDDPID
--POS_LOADETFDD_SID = spLoadETFDDSID
POS_LOADETFDD_PID = ""
POS_LOADETFDD_SID = ""

PosAddBAMapID(spBAMapID);
PosStart();

gAccountCode = _PosBAMapAccount[spBAMapID]
_RegAccount(gAccountCode,"2")

_RegistPricePrefix("1","2");	--level 2
_RegistPricePrefix("2","2");

ETFQueryStart(POS_LOADETFDD_PID,POS_LOADETFDD_SID)
if gETFName ~= nil and gETFName ~= "" then
	--读ETF清单DD
	local initlog = sys_format("ETF:Initilize gETFName[%s]POS_LOADETFDD_PID[%s]POS_LOADETFDD_SID[%s]",gETFName,POS_LOADETFDD_PID,POS_LOADETFDD_SID)
	_WriteAplLog(initlog)
	QueryETFList(gETFName,POS_LOADETFDD_PID,POS_LOADETFDD_SID)
end

---------------------------------------------------
--Position初始化部分结束
---------------------------------------------------
--======================================================
--Position回调函数开始
--======================================================
function OnBackTestDayEnd() end


function OnExecution(position, exec)
	OnExec(exec,position)
end

function OnOrder(position, order)end


function OnPositionError(errorInfo)end

function OnPrice(issueCode, priceInfo)
	if gInitialFlagTable then
		if gtETFComponentTradeInfo[issueCode] then
			if gInitialFlagTable[issueCode] == false then
				local issueCodePirceStatus = getIssueCodePriceStatus(issueCode)
				if issueCodePirceStatus == "SP" then
					gtETFComponentTradeInfo[issueCode].SellQuantity = CalcSellQuantity(issueCode)
					gtETFComponentTradeInfo[issueCode].BuyQuantity = CalcBuyQuantity(issueCode)
					gtETFComponentTradeInfo[issueCode].CashAmount = CalcCashAmount(issueCode)
					sendCashRepltoClient(gETFName,issueCode)
				end
				gInitialFlagTable[issueCode] = true
			end
		end
	end
end

function OnPositionChanged(pos, reason)
end

function OnPositionInitialized()
	--资金持仓刷新

	LoadETFComponent()

	if gETFName ~= "" then
		sendEtfInfoToClient(gETFName,gTradeUnitQty)
	end

	if spInvestorMode == 1 then
		RefreshAccountFromMarket()
	else
		ShowQryAvlFund()
		ShowQryPosition()
	end
	sendLog("初始化完成")
	gInitialFlag = true
end

ShowETFList();
--------------------------------------------------------
--Position回调函数结束
--------------------------------------------------------

--======================================================
--输出事件部分开始
--======================================================
_DefineEventObject AutoCancelTimeOutput _AS _Output
	_DefFld("AutoCancelTime", _Int, 4);
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--ETF信息
_DefineEventObject ETFBaseInfo _AS _Output
	_DefFld("ETFName",_String, 40);
	_DefFld("ETFIssueCode",_String, 20);
	_DefFld("Date",_String, 8);
	_DefFld("CashAmount",_String, 15);		--必须现金替代部分
	_DefFld("EstimateCash", _String, 15);	--预估现金部分
	_DefFld("PreCash", _String, 15);	--前日现金差额
	_DefFld("IssueCount", _Int, 4);	--成份股个数
	_DefFld("Unit", _Int, 4);	--最小申赎单位
	_DefFld("MaxCashRatio", _String, 15);	--最大现金替代比例
	_DefFld("TradeUnitQty", _Int, 4);		--篮子数
	_DefFld("TradeAmount", _Int, 4);	--交易数量
	_DefFld("LastPrice", _Number, 8);	--现价
	_DefFld("Quantity", _Int, 4);	--总持仓
	_DefFld("AvailableQty", _Int, 4);	--可卖
	_DefFld("AvailableCreRedempQty", _Int, 4);	--可申赎
	_DefFld("Status",_String,40);	--状态
	_DefFld("MarketValue",_Number, 8);	--市值
	_DefFld("NetValue",_Number, 8);	--净值
	_DefFld("Flag", _String, 1);	--恒等于"1"，用于新数据来后覆盖

	_SetBufferedFlag(2);
	_DefKeyField("Flag");
	_SetDataType(_EventOtherType);
_End

--存储ETF相关数据
_DefineEventObject ETFDynamicData _AS _Output
	_DefFld("Key",_String,1);	--用于保证储存ETF信息的唯一性,恒等于"1"
	_DefFld("ETFName",_String, 40);
	_DefFld("BidQuote",_String, 16);	--买盘
	_DefFld("AskQuote",_String, 16);	--卖盘
	_DefFld("TradeUnitQty",_Int, 4);	--篮子数
	_DefFld("BuyTick",_Int, 4);
	_DefFld("SellTick",_Int, 4);
	_DefFld("AmendTick",_Int, 4);
	_DefFld("AmendPrice",_String, 8);	--改价价格（买一）
	_DefFld("AutoCancelTime",_Int,4);

	_DefKeyField("Key");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--篮子数显示
_DefineEventObject TradeUnitQtyOutput _AS _Output
	_DefFld("TradeUnitQty", _Int, 4);
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--	行业比例
_DefineEventObject SectorPty _AS _Output
	_DefFld("SectorCode",_Int, 8);
	_DefFld("SectorName",_String, 80);
	_DefFld("Pty",_String, 8);
	_DefFld("IsReplace",_String, 20);
	_DefFld("IsReplaceNo",_String, 1);
	_DefFld("ShowFlag",_String, 1);	--显示与否,1显示,0隐藏

	_DefKeyField("SectorCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End


--显示下拉ETF清单列表yi.xiong_9.8
_DefineEventObject ShowETFIssueList _AS _Output
	_DefFld("ETFIssueList",_Meta ,4);		--ETF下拉列表

	_SetBufferedFlag(2);
_End

--价格调整显示
_DefineEventObject BuyTickOutput _AS _Output
	_DefFld("BuyTick", _Int, 4);
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--价格调整显示
_DefineEventObject SellTickOutput _AS _Output
	_DefFld("SellTick", _Int, 4);
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--止损下单确认对话框out事件
_DefineEventObject StopLossConfirm _AS _Output
	_DefFld("text",_String,60)
	_DefFld("No",_String,30)
	_SetBufferedFlag(2)
_End

--改价价格调整显示
_DefineEventObject AmendTickOutput _AS _Output
	_DefFld("AmendTick", _Int, 4);
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--成交一览
_DefineEventObject ExecutEvent _AS _Output
	_DefFld("IssueCode",_String ,12);
	_DefFld("IssueName",_String ,60);
	_DefFld("BuySell",_String ,8);
	--_DefFld("OpenClose",_String ,15);
	_DefFld("Quantity",_Int ,15);
	_DefFld("ExecutionPrice",_String,15);
	_DefFld("ExecutionTime",_String,20);
	_DefFld("ExecutionNo",_String,8);
	_DefFld("Expense",_String,12);

	_SetBufferedFlag(1);
	_SetDataType(_EventOtherType);
_End;

--委托一览
_DefineEventObject OrderEvent _AS _Output
	_DefFld("IsChecked", _String, 1);			--勾选项
	_DefFld("IssueCode",_String ,12);
	_DefFld("IssueName",_String ,60);
	_DefFld("BuySell",_String ,8);
	--_DefFld("OpenClose",_String ,8);
	_DefFld("Quantity",_Int ,15);
	_DefFld("Price",_String ,15);
	_DefFld("ExecutionQuantity",_Int ,15);
	_DefFld("ExecutionValue",_String,15);	--成交金额
	_DefFld("WorkingQuantity",_Int ,15);
	_DefFld("Status",_String ,12);
	_DefFld("OrderAcceptNo",_String,10);
	_DefFld("OrderTime",_String,20);
	_DefFld("CorpCode",_String,20);
	_DefFld("Expense",_String,12);
	_DefFld("StatusFlag",_String,1);	--for xml use

	_DefKeyField("CorpCode");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

--重下价格输出
_DefineEventObject AmendOrderPriceOutput _AS _Output
	_DefFld("AmenderPrice", _String, 8);	--改价价格
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End


--可开可平,下单对话框调用
_DefineEventObject FundReply _AS _Output
	_DefFld("IssueCode", _String, 12);
	_DefFld("AvlibFund", _String, 20);
	_DefFld("AvlibOpenatQty", _Number, 20);
	_DefFld("AvlibBuyCloseQty", _Number, 20);
	_DefFld("AvlibSellCloseQty", _Number, 20);

	_DefKeyField("IssueCode");
	_SetBufferedFlag(0);
_End

--可用资金
_DefineEventObject FundStatusEvent _AS _Output
	_DefFld("FundItem",_String ,20);	--资金项目
	_DefFld("Value",_String,20);	--值

	_DefKeyField("FundItem");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

_DefineEventObject AvlibFundStatusEvent _AS _Output
	--_DefFld("FundItem",_String ,20);	--资金项目
	--_DefFld("Value",_String,20);	--值
	_DefFld("AvailableFund",_String ,20);	--可用资金
	_DefFld("Key",_Int,1);	--关键字，总是1

	_DefKeyField("Key");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End;

--持仓（带可申赎数量）
_DefineEventObject Position _AS _Output
    _DefFld("IssueCode", _String, 12)
    _DefFld("IssueName", _String, 60)
    _DefFld("BASubID", _String, 48)
    _DefFld("Quantity", _Int, 4)  --数量
    _DefFld("AvailableQty",_Int,4)-- 可用数量
    _DefFld("_workingQuantity", _Int, 15)     --未成交数量
    _DefFld("AvailableCreRedempQty",_Int,4)
    _DefFld("PL", _String, 15)         --浮动盈亏
    _DefFld("BS", _String, 1);      --多空, english

    _DefKeyField("BASubID")
    _DefKeyField("IssueCode")

    _SetBufferedFlag(2) -- use map mode
	_SetDataType(_EventOtherType);
_End

--系统日志
_DefineEventObject SystemLog _AS _Output
	_DefFld("LogTime", _String, 12);
	_DefFld("LogMessage", _Meta, 4);
	_SetBufferedFlag(1);
_End;

--Show the PL today
_DefineEventObject CurrentPL _AS _Output
	_DefFld("CurrentPL", _String, 10);
	_DefFld("Key",_Int,1);	--关键字，总是1

	_DefKeyField("Key");
	_SetBufferedFlag(2);
_End;

--Show premium amount of cash in lieu
_DefineEventObject PremCashAmount _AS _Output
	_DefFld("PremCashAmount", _String, 10);
	_DefFld("Key",_Int,1);	--关键字，总是1

	_DefKeyField("Key");
	_SetBufferedFlag(2);
_End;

--当前状态按钮上的显示
_DefineEventObject TradeModeButton _AS _Output
	_DefFld("Caption",_String, 40);	--显示文字
	_DefFld("KeyForBuffer",_Int,4);	--为buffer2显示效果而设置的key，值=1

	_DefKeyField("KeyForBuffer");
	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--价格输出事件yi.xiong_9.8
_DefineEventObject ShowComplePrice _AS _Output
	_DefFld("Price", _Meta, 4);		--组合编码
	_DefKeyField("Price");
	_SetBufferedFlag(2);
_End

_DefineEventObject CashReplacePty _AS _Output
	_DefFld("CashReplacePty", _String, 20);

	_SetBufferedFlag(1);
	_SetDataType(_EventOtherType);
_End


_DefineEventObject SectorReplaceOutput _AS _Output
	_DefFld("SectorCode", _String, 20);

	_SetBufferedFlag(1);
	_SetDataType(_EventOtherType);
_End

--显示ETF综合成本
_DefineEventObject ETFCompCost _AS _Output
	_DefFld("ETFCompCost", _String, 14);				--成本

	_SetBufferedFlag(1);
   	_SetDataType(_EventOtherType);
_End

--止损设置对话框中成本out事件
_DefineEventObject sendCost _AS _Output
	_DefFld("Cost",_String,6)
	_SetBufferedFlag(2)
	_SetDataType(_EventDayType)
_End
--------------------------------------------------------
--输出事件部分结束
--------------------------------------------------------


--======================================================
--输入及回调事件开始
--======================================================
--买入成份股（按现金替代设置），所用数据均来源于全局变量
_DefineEventObject BuyComponent _AS _Input
_End

--卖出成份股（按申赎清单）
_DefineEventObject SellComponent _AS _Input
	_DefFld("SellUnit",_Int, 4);	--卖出单位	Guorui.jia
_End


--申购，所用数据均来源于全局变量
_DefineEventObject CreateETF _AS _Input
_End


--赎回，所用数据均来源于全局变量
_DefineEventObject Redemption _AS _Input
_End

--选择ETF
_DefineEventObject SelectETF _AS _Input
	_DefFld("ETFIssueCode",_String,20);
_End

--选择ETF回调
_OnEventDefined(SelectETF selectETFEvent,sessionID)
	_WriteAplLog("ETF:SelectETF")
	local etfIssueCode = selectETFEvent._GetFld("ETFIssueCode");
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],选择ETF 操作参数[ETF代码=%s]",
		loginSequence,loginID,loginRoute,etfIssueCode)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)

	local etfName = _ETFIssue2NameTable[etfIssueCode] or "";
	_WriteAplLog(etfName)
	local ID = 0;
	local logs = "";
	local selectCompCond = "";
	local errorMSg = ""
	if _ETFInfoTable[etfName] then
		local tETFInfo = _ETFInfoTable[etfName];
		if tETFInfo.Exist then	--ETF清单已存在
			_WriteAplLog("ETF清单已存在")
			if tETFInfo.Complete then	--ETF清单已存在且成份股完整
				_WriteAplLog("清单已存在且成份股完整");
				selectETFIssue(etfName);
			else	--有ETF清单但成份股不完整,重新导入成份股
				_WriteAplLog("有清单但成份股不完整");
				ID = tETFInfo.ID.toString();
				local selectCompCond = "ETFID#"..ID..";TradingDay#"..strDate
				--etfComponentStore._GetDynamicData("ETFComponentDD",condition = selectCompCond)
				QueryETFComponent(ID,POS_LOADETFDD_PID,POS_LOADETFDD_SID)
				local log = sys_format("RecordNum:%s,IssueCount:%s",_ETFInfoTable[etfName].IssueCount,gETFCompCountTable[etfName].IssueCount)
				_WriteAplLog(log);

				if _ETFInfoTable[etfName].IssueCount ~= gETFCompCountTable[etfName].IssueCount then
					logs = sys_format("etfIssueCode:%s,etfName:%s,RecordNum:%s,IssueCount:%s",etfIssueCode,etfName,_ETFInfoTable[etfName].IssueCount,gETFCompCountTable[etfName].IssueCount)
					_WriteAplLog(logs);
					logs = sys_format("%s的成份股未导入完全",etfName);
					sendLog(logs);
					errorMSg = logs
					sendLog("请稍候再按选择ETF按钮刷新")
					_ETFComponentTable[etfName] = nil;	--清空不完全的表
				else
					_ETFInfoTable[etfName].Complete = true;
					selectETFIssue(etfName);

				end
			end
		end
	else	--ETF清单不存在,重新导入清单
		_WriteAplLog("ETF:SelectETF ETF清单不存在,重新导入清单")
		--local selectETFListCond = "IssueCode#"..etfIssueCode..";TradingDay#"..strDate
		--etfListStore._GetDynamicData("ETFListDD",condition = selectETFListCond)
		local FundName = _ETFIssue2NameTable[etfIssueCode]
		_WriteAplLog(FundName)
		QueryETFList(FundName,POS_LOADETFDD_PID,POS_LOADETFDD_SID)
		etfName = _ETFIssue2NameTable[etfIssueCode] or "";
		if _ETFInfoTable[etfName] then
			ID = _ETFInfoTable[etfName].ID.toString();
			local selectCompCond = "ETFID#"..ID..";TradingDay#"..strDate
			--etfComponentStore._GetDynamicData("ETFComponentDD",condition = selectCompCond)
			QueryETFComponent(ID,POS_LOADETFDD_PID,POS_LOADETFDD_SID)
			if _ETFInfoTable[etfName].IssueCount ~= gETFCompCountTable[etfName].IssueCount then
				_ETFComponentTable[etfName] = nil;	--清空不完全的表
				logs = sys_format("%s的成份股未导入完全.清单数量[%s],当前数量[%s]",etfName,_ETFInfoTable[etfName].IssueCount,gETFCompCountTable[etfName].IssueCount)
				sendLog(logs);
				errorMSg = logs
				sendLog("请稍候再按选择ETF按钮刷新");
				_WriteAplLog(logs)
			else
				_ETFInfoTable[etfName].Complete = true;
				selectETFIssue(etfName);

			end
		else
			logs = sys_format("当日%s申赎清单还未添加",etfIssueCode);
			sendLog(logs);
			errorMSg = logs
			sendLog("请稍候再按选择ETF按钮刷新");
			_WriteAplLog(logs)
		end
	end
	_ETFInfoTable[""] = nil;
	if errorMSg ~= "" then
		local catchLog01 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],选择ETF失败 错误信息[%s]",
		loginSequence,loginID,loginRoute,errorMSg)
		_WriteCatchErrorLog(catchLog01)
    end
_End

_DefineEventObject SetAutoCancelTime _AS _Input
	_DefFld("AutoCancelTime",_Int,4);
_End

_OnEventDefined(SetAutoCancelTime setAutoCancelTimeEvent,sessionID)
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)

	gAutoCancelTime = setAutoCancelTimeEvent._GetFld("AutoCancelTime");

	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],设置自动追价时间:%s",
		loginSequence,loginID,loginRoute,gAutoCancelTime)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)

	if gAutoCancelTime < 5 and gAutoCancelTime >0 then
--		gAutoCancelTime = 0
		local sendlog = "追价间隔最小为5秒"
		sendLog(sendlog)
	end

	local logs = sys_format("gAutoCancelTime[%s]",gAutoCancelTime)
	_WriteAplLog(logs)
--	sendLog(logs)
	saveETFDynamicData();
	showAutoCancelTime();
_End



--设置交易单位（篮子数）
_DefineEventObject SetETFTradeUnitQty _AS _Input
	_DefFld("TradeUnitQty", _Int, 4);
_End

--设置篮子数回调
_OnEventDefined(SetETFTradeUnitQty evt,sessionID)
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)

	local oldUnitQty = gTradeUnitQty;
	gTradeUnitQty = evt._GetFld("TradeUnitQty");
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],设置篮子数 操作参数[数量=%s],之前数量：%s",
		loginSequence,loginID,loginRoute,gTradeUnitQty,oldUnitQty)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)
	local logs = sys_format("SetETFTradeUnitQty-Old:%s,New:%s",oldUnitQty,gTradeUnitQty);
	_WriteAplLog(logs);
	if gTradeUnitQty <= 0 then
		logs = "篮子数必须大于0";
		sendLog(logs);
		gTradeUnitQty = 1;
	end
	showTradeUnitQty();
	if gETFName == "" then
		logs = "请先选择一个ETF";
		sendLog(logs);
	elseif not _ETFInfoTable[gETFName] then
		logs = gETFName .. "还未添加";
		sendLog(logs);
	else
		logs = sys_format("将篮子数设置成%s",gTradeUnitQty);
		sendLog(logs);
		saveETFDynamicData();	--修改篮子数后，写入DynamicData

		sendEtfInfoToClient(gETFName,gTradeUnitQty);
		updateComponentInfoTradeQty(oldUnitQty);
		 RefreshAllCashRepltoClient()

	end
_End


--设置买盘Tick
_DefineEventObject SetBuyTick _AS _Input
	_DefFld("BuyTick",_Int,4);
_End

--设置买盘tick回调
_OnEventDefined(SetBuyTick setBuyTickEvent,sessionID)
	gBuyTick = setBuyTickEvent._GetFld("BuyTick");
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],设置买盘tick 操作参数[Tick=%s]",
		loginSequence,loginID,loginRoute,gBuyTick)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)
	local logs = sys_format("SetBuyTick-gBuyTick:%s",gBuyTick)
	_WriteAplLog(logs)
	saveETFDynamicData()
	showBuyTick()
_End

--设置买盘Tick
_DefineEventObject SetSellTick _AS _Input
	_DefFld("SellTick",_Int,4);
_End

--设置卖盘tick回调
_OnEventDefined(SetSellTick setSellTickEvent,sessionID)
	gSellTick = setSellTickEvent._GetFld("SellTick");
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],设置卖盘tick 操作参数[Tick=%s]",
		loginSequence,loginID,loginRoute,gSellTick)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)
	local logs = sys_format("setSellTickEvent-gSellTick:%s",gSellTick)
	_WriteAplLog(logs)
	saveETFDynamicData();	--存入DynamicData
	showSellTick();
_End

--设置买盘Tick
_DefineEventObject SetAmendTick _AS _Input
	_DefFld("AmendTick",_Int,4);
_End

--设置改价tick回调
_OnEventDefined(SetAmendTick setAmendTickEvent,sessionID)
	gAmendTick = setAmendTickEvent._GetFld("AmendTick");
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],设置撤单重下tick 操作参数[Tick=%s]",
		loginSequence,loginID,loginRoute,gAmendTick)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)
	local logs = sys_format("setAmendTickEvent-gAmendTick:%s",gAmendTick)
	_WriteAplLog(logs)
	saveETFDynamicData();	--存入DynamicData
	showAmendTick();
_End

--设置现金替代
--双击ETF成份股信息，设置交易数量(单位)
_DefineEventObject SetTradeAmount _AS _Input	--Guorui.jia Add
	_DefFld("IssueCode", _String, 20);	--股票代码
	_DefFld("TradeAmounts", _Number, 10);	--交易数量
_End

--成份股一览中的设置交易单位
_OnEventDefined(SetTradeAmount evt,sessionID)
	--_WriteAplLog("SetTradeAmount");
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)

	local issueCode = evt._GetFld("IssueCode");
	--local isCashRepl = evt._GetFld("IsCashRepl")
	local tradeAmount = evt._GetFld("TradeAmounts");	--Guorui.jia
	local temLog = sys_format("tradeAmount,issueCode:%s,tradeAmount:%s",issueCode,tradeAmount);
	_WriteAplLog(temLog);
	local etfInfo = _ETFInfoTable[gETFName];
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],设置交易单位,操作参数[证券代码=%s,交易单位=%s]",
		loginSequence,loginID,loginRoute,issueCode,tradeAmount)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)
	if etfInfo then
		local issueInfo = _ETFComponentTable[gETFName][issueCode];
		if issueInfo then
			--数量合法性判断
			local tradeQtyMax = gTradeUnitQty * issueInfo.Quantity;
			local remianQty = tradeAmount % 100;
			if tradeAmount < 0 then
				local log = sys_format("设置数量无效，必须大于0");
				sendLog(log);
			elseif(remianQty ~= 0)then
				sendLog("数量应该为100的整数倍");
			else
				local tempTradeAmount = sys_format("%d",tradeAmount)
				_WriteAplLog(tempTradeAmount)
				if sys_len(tempTradeAmount) > 10 then
					sendLog("设置的交易数量过大！");
				else
					if not (tradeAmount > 0 and issueInfo.CashRepl == "必须") and not (tradeAmount < tradeQtyMax and issueInfo.CashRepl == "禁止") then
						--update UI
						_ETFComponentTable[gETFName][issueCode].TradeAmount = tradeAmount;
						sendCashRepltoClient(gETFName,issueCode);
					end
				end
			end
		end
	end
_End

--下单
_DefineEventObject FireEvent _AS _Input
	_DefFld("IssueCode", _String, 12);
	_DefFld("BuySell", _String, 1);
	_DefFld("Price", _String, 13);
	_DefFld("Quantity", _Int, 8);
_End


--下单回调
_OnEventDefined(FireEvent fire,sessionID)
	_WriteAplLog("下单回调")
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		local _String loginID = _GetLoginID(sessionID)
		local _String loginSequence = _GetLoginSequence(sessionID)
		local _String loginRoute = _GetLoginRoute(sessionID)
		local accountCode = _PosBAMapAccount[spBAMapID]
		local clientID = _PosFundStatus[accountCode].ClientID
		--对改操作的网络地址进行分析
		gMacIpHdIDTable = anilyzeIPANDMacAddress(loginRoute)

		gTradePermissionFlag = true;
		if gTradePermissionFlag then
            local issueCode = fire._GetFld("IssueCode");
            local bs = fire._GetFld("BuySell");
            local oc = "";
            local qtyChk = false;
            if bs == "3" then
                oc = "0";
            else
                if spInvestorMode ~= 1 then
                    oc = "1";
                    qtyChk = true;
                end
            end
            local price = fire._GetFld("Price");
            local quantity = fire._GetFld("Quantity");
            local logs = sys_format("issue:%s,quantity:%d",issueCode,quantity);
            _WriteAplLog(logs)

            local password = _GetInvestorPWD(spBAMapID)

            local investorID = _PosClient[clientID].InvestorID
            local pwd = _PosClient[clientID].Password
            local checkLog = sys_format("investorID = %s,pwd = %s,password = %s",investorID,pwd,password)
            --_WriteAplLog(checkLog)


            --if _PosClient[clientID].InvestorID and _PosClient[clientID].Password and _PosClient[clientID].InvestorID ~= "" and _PosClient[clientID].Password ~= "" then
            if _PosClient[clientID].InvestorID and password and _PosClient[clientID].InvestorID ~= "" and password ~= "" then
                local slog = sys_format("Pass null check")
                --_WriteAplLog(slog)
                local _String gs1 = _PosClient[clientID].InvestorID.."\t".._PosClient[clientID].Password;
                _SubmitOrderFlag = true;
                --by Richard,091203,start--------------------
                --check the quantity,if quantity more than MAX_ORDER_SUBMIT_QUANTITY(should be 1,000,000),then the quantity will be splited
                local buySell = bs
                local quote = ""
                local tick = ""
                local openClose = ""
                if buySell == "3" then
                    tick = gBuyTick
                    quote = gBidQuote
                    openClose = "0"
                else
                    tick = gSellTick
                    quote = gAskQuote
                    openClose = "1"
                end
                if quantity > _MaxOrderSumitQty	then
                    MarketSplitQuantity(issueCode,quantity,price,bs)
                else
                    MarketSubmitSingleBasket(issueCode,bs,quantity,price,openClose,false,"")
                end
		local buysellname = "买入"
		if bs == "1" then
			buysellname = "卖出"
		end
		log = sys_format("%s合约:[%s],数量:[%s],价格:[%s],下单完成",buysellname,issueCode,quantity,price);
		sendLog(log)
			end
		else
			sendLog("您没有交易权限!");
		end
	end
_End

--改价重下
_DefineEventObject AmendOrder _AS _Input
_End

_OnEventDefined(AmendOrder aoEvent,sessionID)
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		--local _String loginID = _GetLoginID(sessionID)
		--local _String loginSequence = _GetLoginSequence(sessionID)
		local _String loginRoute = _GetLoginRoute(sessionID)
		--对改操作的网络地址进行分析
		gMacIpHdIDTable = anilyzeIPANDMacAddress(loginRoute)

		gTradePermissionFlag = true;
		if gTradePermissionFlag then
			local SelCount = 0
			for kCorpCode,v in pairs (gCurrentOrderTable) do
				if v.IsChecked == "1" then
					local IssueCode = v.IssueCode
					local logs = sys_format("AmendOrder- CorpCode:%s,IssueCode:%s",kCorpCode,IssueCode);
					--_WriteAplLog(logs);
					_AmendOrderTable[kCorpCode] = 1;
					cancelSingleOrder(kCorpCode);
					gAutoCancelTable[kCorpCode] = nil;
					SelCount = SelCount + 1

					--计算综合成本判断用
					if gBuyETFCorpToBatchID[kCorpCode] ~= nil then
						local BatchID = gBuyETFCorpToBatchID[kCorpCode]
						gBuyETFCompOrder[BatchID][IssueCode][kCorpCode].AmendFlag = true
					end
				end
			end
			if SelCount == 0 then
				sendLog("撤单重下前，先选择要撤单重下的挂单。")
			end
		else
			sendLog("您没有交易权限!");
		end
	end
_End

--重下价格输入
_DefineEventObject AmendOrderPriceInput _AS _Input
	_DefFld("AmenderPrice", _String, 8);	--改价价格
_End

--设置改价价格回调
_OnEventDefined(AmendOrderPriceInput amendOrderPriceEvent,sessionID)
	gAmendPrice = amendOrderPriceEvent._GetFld("AmenderPrice");
	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],设置撤单重下价格 操作参数[价格=%s]",
		loginSequence,loginID,loginRoute,gAmendPrice)
	_WriteCatchAplLog(catchLog00)
	_WriteAplLog(catchLog00)
	local logs = sys_format("AmendOrderPriceInput-AmenderPrice:%s",gAmendPrice)
	_WriteAplLog(logs)
	saveETFDynamicData();	--存入DynamicData
	showAmendPrice();
_End

--根据CorpCode撤单
_DefineEventObject CancelOrder _AS _Input
_End

_OnEventDefined(CancelOrder coEvent,sessionID)
	if _PosStatus ~= POS_STATUS_NORMAL then
		sendLog("初始化中，请稍候")
	else
		--local _String loginID = _GetLoginID(sessionID)
		--local _String loginSequence = _GetLoginSequence(sessionID)
		local _String loginRoute = _GetLoginRoute(sessionID)
		--对改操作的网络地址进行分析
		gMacIpHdIDTable = anilyzeIPANDMacAddress(loginRoute)

		gTradePermissionFlag = true;
		if gTradePermissionFlag then
			local SelCount = 0
			for kCorpCode,v in pairs (gCurrentOrderTable) do
				if v.IsChecked == "1" then
					local logs = sys_format("CancelOrder- CorpCode:%s,IssueCode:%s",kCorpCode,v.IssueCode);
					--_WriteAplLog(logs);
					cancelSingleOrder(kCorpCode);
					SelCount =  SelCount + 1
				end
			end
			if SelCount == 0 then
				sendLog("撤单前，先选择要撤的挂单。")
			end

		else
			sendLog("您没有交易权限!");
		end
	end
_End

--查询可开可平,下单对话框调用
_DefineEventObject QueryFund _AS _Input
	_DefFld("IssueCode", _String, 12);
	_DefFld("BASubID", _String, 48);
	_SetBufferedFlag(1);
_End


_DefineEventObject BuyETF _AS _Input
_End;
_DefineEventObject SellETF _AS _Input
_End;

--选中当前委托中的记录
_DefineEventObject OrderChecked _AS _Input
	_DefFld("IsChecked", _String, 1);	--撤销或者选中(0:撤销,1:选中)
	_DefFld("CorpCode", _String, 20);
_End

--选中当前委托中的记录回调
_OnEventDefined(OrderChecked event,sessionID)
	local IsChecked = event._GetFld("IsChecked");
	local CorpCode = event._GetFld("CorpCode");
	local IssueCode = ""

	if gCurrentOrderTable[CorpCode] ~= nil then
		gCurrentOrderTable[CorpCode].IsChecked = IsChecked
		IssueCode = gCurrentOrderTable[CorpCode].IssueCode
	end

	local log = sys_format("OrderChecked CorpCode:%s,IssueCode:%s,IsChecked:%s",CorpCode,IssueCode,IsChecked)
	_WriteAplLog(log)
_End

--当前委托全部选中或清除
_DefineEventObject SelectOrClearAllChecked _AS _Input
	_DefFld("IsChecked", _String, 1);	--撤销或者选中(0:撤销,1:选中)
_End

--当前委托全部选中或清除
_OnEventDefined(SelectOrClearAllChecked event,sessionID)
	local IsChecked = event._GetFld("IsChecked");
	local log = sys_format("SelectOrClearAllChecked IsChecked:%s", IsChecked)
	_WriteAplLog(log)

	for kCorpCode,v in pairs (gCurrentOrderTable) do
		gCurrentOrderTable[kCorpCode].IsChecked = IsChecked
	end
_End

-------------右键下单-------------
_DefineEventObject OrderPost _AS _Input
	_DefFld("IssueCode",_String,300)
	_DefFld("AskQuote",_String,8)
	_DefFld("SellTick",_Int,4)
_End



--计算成交成份股综合成本 by jun 20120316
_DefineEventObject FareSet _AS _Input
	_DefFld("FareCalcCheck", _String, 1);		--手续费选项
_End

--成交成份股综合成本
_OnEventDefined(FareSet fareSet,sessionID)
	local FareCalcCheck = fareSet._GetFld("FareCalcCheck")
	gFareCalcCheck = FareCalcCheck;
_End

--确认In事件
_DefineEventObject Notice _AS _Input
	_DefFld("text",_String,60)
	_DefFld("No",_String,30)
_End

_OnEventDefined(Notice evtNotice)
	local number = evtNotice._GetFld("No")--其实是type：ETF or 成份股
	local log;
	log = sys_format("_OnEventDefined:Notice,确认事件，No：%s",number)
	--_WriteAplLog(log)
	if gtStopList[number] then
		gtStopList[number].isConfirm = 1
	else
		log = sys_format("出错,%s条件单不存在",number)
		--_WriteAplLog(log)
	end
_End

--输入替代行业
_DefineEventObject SectorReplace _AS _Input
	_DefFld("SectorCode", _Int, 20);
	_DefFld("IsReplace", _String, 1);
_End

_OnEventDefined(SectorReplace srEvent,sessionID)
	--_WriteAplLog("modify ctr")
	local IsReplace = srEvent._GetFld("IsReplace")
	local SectorCode = srEvent._GetFld("SectorCode")

	local _String loginID = _GetLoginID(sessionID)
	local _String loginSequence = _GetLoginSequence(sessionID)
	local _String loginRoute = _GetLoginRoute(sessionID)
	local catchLog00 = sys_format("LoginSequence[%s],UserID=[%s],LoginRoute=[%s],设置现金替代 操作参数[是否替代=%s][行业代码=%s]",
		loginSequence,loginID,loginRoute,IsReplace,SectorCode)
	if IsReplace =="1" then
		if not _RSectorCode then
			_RSectorCode = {}
		end

		if not _RSectorCode[SectorCode] then
			_RSectorCode[SectorCode] = 1
			local log = sys_format("RSectorCode:%s",SectorCode)
			if _ETFSectorPtyTable[gETFName] then
				if _ETFSectorPtyTable[gETFName][SectorCode] then
					local sectorName = _ETFSectorPtyTable[gETFName][SectorCode]["SectorName"]
					local logs = sys_format("%s设为现金替代",sectorName);
					sendLog(logs);
					for IssueCode,value in pairs(gtETFComponentTradeInfo)do
						if _IssueSectorTable[IssueCode] == SectorCode then
							gtETFComponentTradeInfo[IssueCode].UseCashAmountFlag = "√"
							gtETFComponentTradeInfo[IssueCode].CashAmount = CalcCashAmount(IssueCode)
							gtETFComponentTradeInfo[IssueCode].BuyQuantity = CalcBuyQuantity(IssueCode)
							sendCashRepltoClient(gETFName,IssueCode)
						end
					end
				end
			end
			updateSectorInfo(gETFName,SectorCode,"是","1")
			updateTradeQty1()
		end
	else
		if _RSectorCode then
			if _RSectorCode[SectorCode]== 1 then
				_RSectorCode[SectorCode] = nil
				if _ETFSectorPtyTable[gETFName] then
					if _ETFSectorPtyTable[gETFName][SectorCode] then
						local sectorName = _ETFSectorPtyTable[gETFName][SectorCode]["SectorName"]
						local logs = sys_format("%s取消现金替代",sectorName);
						sendLog(logs);
						for IssueCode,value in pairs(gtETFComponentTradeInfo)do
							if _IssueSectorTable[IssueCode] == SectorCode then
								gtETFComponentTradeInfo[IssueCode].UseCashAmountFlag = ""
								gtETFComponentTradeInfo[IssueCode].CashAmount = CalcCashAmount(IssueCode)
								gtETFComponentTradeInfo[IssueCode].BuyQuantity = CalcBuyQuantity(IssueCode)
								sendCashRepltoClient(gETFName,IssueCode)
							end
						end
					end
				end
				updateSectorInfo(gETFName,SectorCode,"否","0")
				updateTradeQty1()

			end
		end
	end
_End

--------------------------------------------------------
--输入及回调事件结束
--------------------------------------------------------

--======================================================
--数据库读取部分开始
--======================================================

_GetCommonData(dataName = "SectorIssue", condition = "",  tablename = "SectorIssue")
_OnCommonData(dataName = "SectorIssue", DTSSectorIssue si)
	local SectorCategoryID = si.getSectorCategoryID();
	if SectorCategoryID == 1 then
		--_WriteAplLog("wwssyylog1")
		local SectorCode = si.getSectorCode();
		local IssueCode = si.getIssueCode();
		if not _SectorIssueTable[SectorCode] then
			_SectorIssueTable[SectorCode] = {}
		end
		if not _SectorIssueTable[SectorCode][IssueCode] then
			_SectorIssueTable[SectorCode][IssueCode] = 1
		end

		_IssueSectorTable[IssueCode] = SectorCode
	end
_End

--------------------------------------------------------
--数据库读取部分结束
--------------------------------------------------------


--======================================================
--定时器回调部分开始
--======================================================
--自动追加 by wsy
_StartTimer(_TimerName="AutoCancelTimer",_Interval=1000)
_OnEventTimer(_TimerName="AutoCancelTimer")
	if gAutoCancelTime >= 5 then
		local DTSTime nowtime = _GetNowTime();
		local smtime = nowtime.asString("%H%M%S");
		local forNowTime = timetrans(smtime)

		local _String MACAddress = gMacIpHdIDTable.MacAddress
		local _String HDID = gMacIpHdIDTable.HdID
		local _String IPAddress = gMacIpHdIDTable.LocalIP

		for k,v in pairs(gAutoCancelTable) do
			if (forNowTime - v.OrderTime) >= gAutoCancelTime and v.AutoAmendFlag == false then
				local _String CorpCode = k;

				--使用新接口模式撤单
				--DTSSubmitEvent
				local DTSSubmitEvent submitEvent
				submitEvent.setField("MessageType","L03")
				local workstationNo = _GetWorkstationNo()
				submitEvent.setField("WorkstationNo",workstationNo) --默认本机

				--Order
				local DTSSubmitEvent order1
				order1.setField("CorpCode",CorpCode)
				order1.setField("HDID",HDID)
				order1.setField("MacAddress",MACAddress)
				order1.setField("IPAddress",IPAddress)

				submitEvent.spliceField("OrderList",order1)
				_SendOrders(submitEvent)

				--输出信息,By wsy
				local logBuySell = ""
				local logOpenClose = ""
				if v.BuySell == "3" then
					logBuySell = "买"
				else
					logBuySell = "卖"
				end

				if v.OpenClose == 0 then
					logOpenClose = "开仓"
				elseif v.OpenClose == 1 then
					logOpenClose = "平仓"
				else
					logOpenClose = "平今"
				end
				local sendlog = sys_format("[%s]发生自动撤单: [%s] [%s股] [%s]",v.IssueCode,logBuySell,v.workingQuantity,k)
				sendLog(sendlog)
				_WriteCatchAplLog(sendlog)
				_WriteAplLog(sendlog)
				--输出信息END
--				gAutoCancelTable[k] = nil
                gAutoCancelTable[k].AutoAmendFlag = true--自动撤单只执行一次
			end
		end
	end
_End
--------------------------------------------------------
--定时器回调部分结束
--------------------------------------------------------


--======================================================
--自定义函数部分开始
--======================================================
--分析网络信息函数
function anilyzeIPANDMacAddress(text)
	local _Int len = sys_len(text);
	local table = {};
	local i = 0;
	local j = 0;
	local _Int n;
	for n = 1,len,1 do
		local ch1 = sys_sub(text,n,n);
		if ch1 == "=" then
			i = n + 1;
			for n = i,len,1 do
				local ch2 = sys_sub(text,n,n);
				if ch2 == ";" then
					j = n - 1;
					local  subText = sys_sub(text,i,j);
					sys_insert(table,subText);
					--_WriteAplLog(subText);
					break;
				elseif len == n then
					j = n;
					local  subText = sys_sub(text,i,j);
					sys_insert(table,subText);
					--_WriteAplLog(subText);
				end
			end
		end
	end

	local rTable = {};
	local _Int num = 0;
	for key,value in pairs(table) do
		num = num +1;
		if num == 1 then
			rTable.MacAddress = value;
		elseif num == 2 then
			rTable.LocalIP = value;
		elseif num == 3 then
			rTable.Route = value;
		elseif num == 4 then
			rTable.HdID = value;
		end
	end

	local log = sys_format("anilyzeIPANDMacAddress %s,%s,%s,",rTable.MacAddress,rTable.LocalIP,rTable.HdID )
	--_WriteAplLog(log)
	return rTable;
end

function showAutoCancelTime()
	local logs = sys_format("showAutoCancelTime-gAutoCancelTime:%s",gAutoCancelTime)
	--_WriteAplLog(logs)
	local DTSEvent autoCancelTimeEvent = _CreateEventObject("AutoCancelTimeOutput");
	autoCancelTimeEvent._SetFld("AutoCancelTime",gAutoCancelTime);
	autoCancelTimeEvent._SetFld("KeyForBuffer",1);
	_SendToClients(autoCancelTimeEvent);
end

function timetrans(time1)
    local hh1 = sys_sub(time1,1,2)
    local mm1 = sys_sub(time1,3,4)
    local ss1 = sys_sub(time1,5,6)
    local result = hh1*3600+mm1*60+ss1
    return result
end

--发送系统日志
function sendLog(logMessage)
	local DTSEvent systemLog =_CreateEventObject("SystemLog");
	local DTSTime nowtime = _GetNowTime();
	local smtime = nowtime.asString("%H%M%S");
	--HH:MM:SS格式化
	local tmplogtimeH = sys_sub(smtime,1,2);
	local tmplogtimeM = sys_sub(smtime,3,4);
	local tmplogtimeS = sys_sub(smtime,5,6);
	local tmplogtime = tmplogtimeH..":"..tmplogtimeM..":"..tmplogtimeS;
	systemLog._SetFld("LogTime",tmplogtime);
	systemLog._SetFld("LogMessage",logMessage);
	_SendToClients(systemLog);
end

--QueryETFComponent回调函数
function OnQueryETFComponentTable(etfComponentTable)
	local ETFID = etfComponentTable.ETFID	--ID
	local TradingDay = etfComponentTable.TradingDay
	local IssueCode = etfComponentTable.IssueCode
	local Quantity = etfComponentTable.Quantity
	local CanCashRepl = etfComponentTable.CanCashRepl
	local CashBuffer = etfComponentTable.CashBuffer
	local CashAmount = etfComponentTable.CashAmount
	local etfName = _ETFID2NameTable[ETFID];
	--local testLog = sys_format("DTSETFComponent:ETFID[%s],etfName[%s]",ETFID,etfName)
	--_WriteAplLog(testLog)
	local issueName = _PosIssueNameTable[IssueCode];
	local tETFComp = {};
	tETFComp.ETFName = etfName;	--ETFName
	if not gETFCompCountTable[etfName] then
		gETFCompCountTable[etfName] = {};
		gETFCompCountTable[etfName].IssueCount = 0;
		gETFCompCountTable[etfName].IssueCode = IssueCode;
	end
	--if IssueCode ~= "159900" then	--过滤159920中的虚拟成分股159900
	gETFCompCountTable[etfName].IssueCount = gETFCompCountTable[etfName].IssueCount + 1;
	--end
	local testLogs = sys_format("读取成分股回调:ETFID[%s],etfName[%s],IssueCode[%s],IssueCount[%s],TradingDay[%s]",
								ETFID,etfName,IssueCode,gETFCompCountTable[etfName].IssueCount,TradingDay)
	--_WriteAplLog(testLogs)
	tETFComp.ID = gETFCompCountTable[etfName].IssueCount.toString();
	tETFComp.IssueCode = IssueCode;
	tETFComp.IssueName = issueName;
	tETFComp.Quantity = Quantity;
	local CashRepl = "";
	if CanCashRepl == "0" then
		CashRepl = "禁止";
	--上海跨市对深市成分股均现金替代，跨境成分股都为现金替代
	--elseif CanCashRepl == "1" or CanCashRepl == "3" or CanCashRepl == "5" then
	elseif CanCashRepl == "1" then
		CashRepl = "允许";
	elseif CanCashRepl == "2" then
		CashRepl = "必须";
	elseif CanCashRepl == "3" then
		CashRepl = "深市退补";
	elseif CanCashRepl == "4" then
		CashRepl = "深市必须";
	end

	tETFComp.CashRepl = CashRepl;
	tETFComp.CashBuffer = CashBuffer;
	tETFComp.CashAmount = CashAmount;
	tETFComp.CanCashRepl = CanCashRepl;
	tETFComp.BidQuantity = 0;
	tETFComp.AskQuantity = 0;
	tETFComp.Available = 0;
	tETFComp.AvailCreRed = 0;
	tETFComp.Value = 0;
	local isCashRepl = "";
	local tradeAmount = 0;
	if not _ETFComponentTable[etfName] then
		_ETFComponentTable[etfName] = {};
	end
	_ETFComponentTable[etfName][IssueCode] = tETFComp;
	if tETFComp.CashRepl ~= "必须" and tETFComp.CashRepl ~= "深市必须" and tETFComp.CashRepl ~= "深市退补" then
		isCashRepl = "不替代"
		tradeAmount = gTradeUnitQty * Quantity;
		_ETFComponentTable[etfName][IssueCode].TradeAmount = tradeAmount;
	else
		isCashRepl = "替代";
		_ETFComponentTable[etfName][IssueCode].TradeAmount = 0;
	end
	if not _IssueETFTable[IssueCode] then
		_IssueETFTable[IssueCode] = {};
		local marketCode = _PosIssueMarketTable[IssueCode];
		_RegisterPrice(_IssueCode = IssueCode, _MarketCode = marketCode);
	end
	_IssueETFTable[IssueCode][etfName] = 1;
	--local logs = sys_format("Component-TradingDay:%s,IssueCode:%s,Quantity:%s,CanCashRepl:%s,CashBuffer:%s,CashAmount:%s,IssueCount:%s",TradingDay,IssueCode,Quantity,CanCashRepl,CashBuffer,CashAmount,gETFCompCountTable[etfName].IssueCount);
	--_WriteAplLog(logs);
	--[[
	if etfName == gETFName then
		sendCashRepltoClient(etfName,IssueCode);
	end
	]]

	local tETFInfo = _ETFInfoTable[etfName];
	if tETFInfo then
		--calculate cash replace
		--从清单中取得任意一个不为0的现金替代溢价比例
		if CashBuffer > 0 and tETFInfo.CashBuffer == 0 then
			tETFInfo.CashBuffer = CashBuffer;
		end
		--从清单中分别计算每个ETF所有必须现金替代的股票的替代金额的和
		if CashRepl == "必须" and CashAmount then
			tETFInfo.CashAmount = tETFInfo.CashAmount + CashAmount;
		elseif CashRepl == "深市必须" and CashAmount then
			tETFInfo.CashAmount = tETFInfo.CashAmount + CashAmount;
		elseif CashRepl == "深市退补" and CashAmount then
			tETFInfo.CashAmount = tETFInfo.CashAmount + CashAmount *(1+CashBuffer/100);
		end
		local tPriceInfo = _PosPriceTable[IssueCode];
		--if the price of this issue has come
		if tPriceInfo then
			--_WriteAplLog("the price has been registed");
			if not gtStockStatusTable[IssueCode] then
				 gtStockStatusTable[IssueCode] = {};
			end
			local aq1 = tPriceInfo.AskQuantity1;
			local aq2 = tPriceInfo.AskQuantity2;
			local aq3 = tPriceInfo.AskQuantity3;
			local aq4 = tPriceInfo.AskQuantity4;
			local aq5 = tPriceInfo.AskQuantity5;
			local bq1 = tPriceInfo.BidQuantity1;
			local bq2 = tPriceInfo.BidQuantity2;
			local bq3 = tPriceInfo.BidQuantity3;
			local bq4 = tPriceInfo.BidQuantity4;
			local bq5 = tPriceInfo.BidQuantity5;
			local status = stateJudge(aq1,aq2,aq3,aq4,aq5,bq1,bq2,bq3,bq4,bq5);
			gtStockStatusTable[IssueCode].Status = status;
			if status == "0" then
				tETFInfo.StockStop = tETFInfo.StockStop + 1;
			elseif status == "1" then
				tETFInfo.StockDrop = tETFInfo.StockDrop + 1;
			elseif status == "2" then
				tETFInfo.StockRise = tETFInfo.StockRise + 1;
			end
			local lastPrice = tPriceInfo.LastPrice;
			if lastPrice == "" or lastPrice == nil then
				lastPrice = 1
			end
			local weight = Quantity * lastPrice;
			if not tETFInfo.PriceSet[IssueCode] then
				tETFInfo.PriceSet[IssueCode] = 1;
				tETFInfo.PriceCount = tETFInfo.PriceCount + 1;
			end
			local newValue = weight;
			-- "必须","深市必须"
            if CanCashRepl == "2" or CanCashRepl == "4" then
				newValue = tETFComp.CashAmount;
			elseif status == "0" then
				local adjustedLNC = _PosPriceTable[IssueCode].AdjustedLNC or 0
				newValue = adjustedLNC * Quantity
			end
			tETFInfo.NetValue = tETFInfo.NetValue + newValue - tETFComp.Value;

			tETFComp.Value = newValue;
			calcWeight(etfName,IssueCode,weight);
			sendEtfInfoToClient(etfName,tETFInfo.TradeUnitQty);
		end
		_ETFInfoTable[etfName] = tETFInfo;
	end
end


function clearCashRepl(etfName)
	local DTSEvent cashReplEvent = _CreateEventObject("CashRepl");
	cashReplEvent._SetFld("IssueCode", "000000");
	cashReplEvent._SetFld("ShowFlag", "2");		--清空界面成分股清单表
	_SendToClients(cashReplEvent);
	gtETFComponentTradeInfo = {}				--清空成分股交易信息
end

--计算卖出成交的成分股  by yongqun.huang 20120327
function CalSellExecutionCost(BatchID,IssueCode, CorpCode, ExecValue, expense,gFareCalcCheck)
	--批号检查
	if BatchID == nil or BatchID == 0 then
		--_WriteAplLog("计算卖出成交的成分股的成本: BatchID == nil result")
		return false;
	end
	--不是保存在批号的单子，不计算返回
	local OrderNumKey = sys_format("%d", BatchID)
	if gSellETFCompOrder[OrderNumKey] == nil then
		--_WriteAplLog("计算卖出成交的成分股的成本:gSellETFCompOrder[BuyETFCompNum] == nil result")
		return false;
	end
	--不是保存在批号下合约的单子，不计算返回
	if gSellETFCompOrder[OrderNumKey][IssueCode] == nil then
		--_WriteAplLog("计算卖出卖出成交的成分股的成本:gSellETFCompOrder[OrderNumKey][IssueCode] == nil result")
		return false;
	end
	--不是保存在批号下的合约，且合该合下的委托的单子，不计算返回
	if gSellETFCompOrder[OrderNumKey][IssueCode][CorpCode] == nil then
		--_WriteAplLog("计算卖出成交的成分股的成本:gSellETFCompOrder[OrderNumKey][IssueCode][CorpCode] == nil result")
		return false;
	end

	--初始化gtSellExecutionCost存放每个批号下的成本的表格
	if not gtSellExecutionCost then
		gtSellExecutionCost = {};
	end
	if not gtSellExecutionCost[OrderNumKey] then
		gtSellExecutionCost[OrderNumKey] = 0;
		local tmplog = sys_format("初始化卖出计算成交的成分股的成本：gtSellExecutionCost[%s] = %s",OrderNumKey,gtSellExecutionCost[OrderNumKey]);
		--_WriteAplLog(tmplog);
	end

	--上面的各种检查通过，对该成交的成本进行累加
	if gFareCalcCheck == "1" then  --加上费用
		gtSellExecutionCost[OrderNumKey] = gtSellExecutionCost[OrderNumKey] + ExecValue + expense;
	else	--不加上费用
		gtSellExecutionCost[OrderNumKey] = gtSellExecutionCost[OrderNumKey] + ExecValue;
	end
	local tmplog = sys_format("计算卖出成交的成分股的成本：IssueCode = %s,gtSellExecutionCost[%s] = %.2f,ExecValue = %.2f,expense = %.2f,CorpCode = %s",
					IssueCode,OrderNumKey,gtSellExecutionCost[OrderNumKey],ExecValue,expense,CorpCode);
	--_WriteAplLog(tmplog);
	return true;
end

--计算买入成交的成分股  by jun 20120316
function CalExecutionCost(BatchID,IssueCode, CorpCode, ExecValue, expense,gFareCalcCheck)
	--批号检查
	if BatchID == nil or BatchID == 0 then
		--_WriteAplLog("计算买入成交的成分股的成本: BatchID == nil result")
		return false;
	end
	--不是保存在批号的单子，不计算返回
	local OrderNumKey = sys_format("%d", BatchID)
	if gBuyETFCompOrder[OrderNumKey] == nil then
		--_WriteAplLog("计算买入成交的成分股的成本:gBuyETFCompOrder[BuyETFCompNum] == nil result")
		return false;
	end
	--不是保存在批号下合约的单子，不计算返回
	if gBuyETFCompOrder[OrderNumKey][IssueCode] == nil then
		--_WriteAplLog("计算买入成交的成分股的成本:gBuyETFCompOrder[OrderNumKey][IssueCode] == nil result")
		return false;
	end
	--不是保存在批号下的合约，且合该合下的委托的单子，不计算返回
	if gBuyETFCompOrder[OrderNumKey][IssueCode][CorpCode] == nil then
		--_WriteAplLog("计算买入成交的成分股的成本:gBuyETFCompOrder[OrderNumKey][IssueCode][CorpCode] == nil result")
		return false;
	end

	--初始化gtExecutionCost存放每个批号下的成本的表格
	if not gtExecutionCost then
		gtExecutionCost = {};
	end
	if not gtExecutionCost[OrderNumKey] then
		gtExecutionCost[OrderNumKey] = 0;
		local tmplog = sys_format("初始化计算买入成交的成分股的成本：gtExecutionCost[%s] = %s",OrderNumKey,gtExecutionCost[OrderNumKey]);
		--_WriteAplLog(tmplog);
	end

	--上面的各种检查通过，对该成交的成本进行累加
	if gFareCalcCheck == "1" then  --加上费用
		gtExecutionCost[OrderNumKey] = gtExecutionCost[OrderNumKey] + ExecValue + expense;
	else	--不加上费用
		gtExecutionCost[OrderNumKey] = gtExecutionCost[OrderNumKey] + ExecValue;
	end
	local tmplog = sys_format("计算买入成交的成分股的成本：IssueCode = %s,gtExecutionCost[%s] = %.2f,ExecValue = %.2f,expense = %.2f,CorpCode = %s",
					IssueCode,OrderNumKey,gtExecutionCost[OrderNumKey],ExecValue,expense,CorpCode);
	--_WriteAplLog(tmplog);
	return true;
end

function getIssueCodePriceStatus(IssueCode)
	local priceInfo = _PosPriceTable[IssueCode]
	if priceInfo then
		local askQty1 = priceInfo.AskQuantity1
		local askQty2 = priceInfo.AskQuantity2
		local askQty3 = priceInfo.AskQuantity3
		local askQty4 = priceInfo.AskQuantity4
		local askQty5 = priceInfo.AskQuantity5
		local bidQty1 = priceInfo.BidQuantity1
		local bidQty2 = priceInfo.BidQuantity2
		local bidQty3 = priceInfo.BidQuantity3
		local bidQty4 = priceInfo.BidQuantity4
		local bidQty5 = priceInfo.BidQuantity5

		if (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
			gLogs = sys_format("issueCode:%s SP stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",IssueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteAplLog(gLogs);
			return "SP"; --SusPend 停牌
		elseif (askQty1 > 0 or askQty2 > 0 or askQty3 > 0 or askQty4 > 0 or askQty5 > 0) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
			gLogs = sys_format("issueCode:%s DL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",IssueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteAplLog(gLogs);
			return "DL"; --Decline Limit 跌停
		elseif (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 > 0 or bidQty2 > 0 or bidQty3 > 0 or bidQty4 > 0 or bidQty5 > 0) then
			gLogs = sys_format("issueCode:%s SL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",IssueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteAplLog(gLogs);
			return "SL"; --Surged Limit 涨停
		else
			return "NM"; --NorMal 正常
		end
	else
		return "NM"; --NorMal 正常
	end
end

function updateCanBeCancelTable(order)
	local IssueCode = order.IssueCode;
	local BuySell = order.BuySell;
	local Quantity = order.Quantity
	local Price = order.Price
	local ExecutionQuantity = order.ExecutionQuantity
	local ExecutionValue = order.ExecutionValue
	local WorkingQuantity = order.WorkingQuantity
	local OrderAcceptNo = order.OrderAcceptNo
	local OrderTime = order.OrderTime
	local CancelQuantity = order.CancelQuantity
	local UnAcceptedQuantity = order.UnacceptedQuantity
	local RejectedQuantity = order.RejectedQuantity
	local CorpCode = order.CorpCode
	local orderIsFinished = false
	if Quantity == ExecutionQuantity then
		orderIsFinished = true
	elseif ExecutionQuantity >0 and Quantity > ExecutionQuantity then
		if ExecutionQuantity + CancelQuantity == Quantity then
			orderIsFinished = true
		else

		end
	elseif WorkingQuantity > 0 then

	elseif CancelQuantity > 0 then
		orderIsFinished = true
	elseif UnAcceptedQuantity == Quantity then

	elseif RejectedQuantity > 0 then
		orderIsFinished = true
	end
	if(orderIsFinished)then
		if _CanBeCancelOrderTable[CorpCode]then
			_CanBeCancelOrderTable[CorpCode] = nil;
		end
		return
	end

	if(WorkingQuantity> 0)then
		local tCancelOrder = {};
		tCancelOrder.IssueCode = IssueCode;
		tCancelOrder.BuySell = BuySell;
		tCancelOrder.Quantity = Quantity;
		tCancelOrder.Price = Price;
		tCancelOrder.ExecutionQuantity = ExecutionQuantity;
		tCancelOrder.WorkingQuantity = WorkingQuantity;
		tCancelOrder.CancelQuantity = CancelQuantity;
		tCancelOrder.RejectedQuantity = RejectedQuantity;
		tCancelOrder.UnAcceptedQuantity = UnAcceptedQuantity;
		_CanBeCancelOrderTable[CorpCode] = tCancelOrder;
	else
		if(_CanBeCancelOrderTable[CorpCode])then
			_CanBeCancelOrderTable[CorpCode] = nil;
		end
	end
end

function getOrderStatusFlag(StatusName)
	local StatusFlag = "2"
	if StatusName == "全部成交" or StatusName == "部成部撤" or StatusName == "撤单" or StatusName == "拒绝" then
		StatusFlag = "1"
	end
	return StatusFlag
end

--取得挂单状态的意义
function getOrderStatusName(Quantity, ExecutionQuantity, WorkingQuantity, CancelQuantity, RejectedQuantity, UnAcceptedQuantity)
	local log = sys_format("getStatusName() Quantity:%s, ExecutionQuantity:%s, WorkingQuantity:%s, CancelQuantity:%s, RejectedQuantity:%s, UnAcceptedQuantity:%s",
				Quantity, ExecutionQuantity, WorkingQuantity, CancelQuantity, RejectedQuantity, UnAcceptedQuantity)
--	_WriteAplLog(log)

	local StatusName = ""
	if Quantity == ExecutionQuantity then
		StatusName = "全部成交"
	elseif ExecutionQuantity >0 and Quantity > ExecutionQuantity then
		if ExecutionQuantity + CancelQuantity == Quantity then
			StatusName = "部成部撤";
		else
			StatusName = "部分成交";
		end
	elseif WorkingQuantity > 0 then
		StatusName = "挂单";
	elseif CancelQuantity > 0 then
		StatusName ="撤单";
	elseif UnAcceptedQuantity == Quantity then
		StatusName = "未报";
	elseif RejectedQuantity > 0 then
		StatusName = "拒绝";
	end
	log = sys_format("getStatusName() StatusName:%s", StatusName)
--	_WriteAplLog(log)
	return StatusName
end
function getProductKey(productCode, underlyingAssetCode, marketCode)
	return productCode .. "." .. underlyingAssetCode .. "." .. marketCode;
end


function showPremCashAmount(temPremCashAmount)
	local DTSEvent premCashAmountEvent = _CreateEventObject("PremCashAmount");
	local premCashAmount = temPremCashAmount;
	premCashAmountEvent._SetFld("PremCashAmount",premCashAmount);
	premCashAmountEvent._SetFld("KeyForBuffer",1);
	_SendToClients(premCashAmountEvent);
end

function cancelSingleOrder(CorpCode)
	_CancelOrderTable[CorpCode] = 1
	gAutoCancelTable[CorpCode] = nil
	gCurrentOrderTable[CorpCode].IsChecked = "0"

	--使用新接口模式撤单
	--DTSSubmitEvent
	local DTSSubmitEvent submitEvent
	submitEvent.setField("MessageType","L03")
	local workstationNo = _GetWorkstationNo()
	submitEvent.setField("WorkstationNo",workstationNo) --默认本机

	--Order
	local DTSSubmitEvent order1
	local _String CorpCodeS = CorpCode;
	local _String MACAddress = gMacIpHdIDTable.MacAddress
	local _String HDID = gMacIpHdIDTable.HdID
	local _String IPAddress = gMacIpHdIDTable.LocalIP

	order1.setField("CorpCode",CorpCodeS)
	order1.setField("HDID",HDID)
	order1.setField("MacAddress",MACAddress)
	order1.setField("IPAddress",IPAddress)

	submitEvent.spliceField("OrderList",order1)
	_SendOrders(submitEvent)
end


--存储需要计算综合成本的买入成份股记录
function SaveBuyETFCompOrderInfo(IssueCode,CorpCode,Price,Quantity,WorkingQty,ExecQty,RejQty,CancelQty,UnAccQty,ExecValue,Fare,Num)
	local log = sys_format("SaveBuyETFCompOrderInfo IssueCode:%s,CorpCode:%s,Price:%s,Quantity:%s,WorkingQty:%s,ExecQty:%s,RejQty:%s,CancelQty:%s,UnAccQty:%s,ExecValue:%s,Fare:%.2f,Num:%s",
		IssueCode,CorpCode,Price,Quantity,WorkingQty,ExecQty,RejQty,CancelQty,UnAccQty,ExecValue,Fare,Num)
	--_WriteAplLog(log)

	--如果不是买入ETF成份操作
	if Num == 0  or Num == nil then
		return
	end

	if gBuyETFCorpToBatchID[CorpCode] == nil then
		gBuyETFCorpToBatchID[CorpCode] = Num
	end

	if gBuyETFCompOrder[Num] == nil then
		gBuyETFCompOrder[Num] = {}
	end
	if gBuyETFCompOrder[Num][IssueCode] == nil then
		gBuyETFCompOrder[Num][IssueCode] = {}
	end
	if gBuyETFCompOrder[Num][IssueCode][CorpCode] == nil then
		gBuyETFCompOrder[Num][IssueCode][CorpCode] = {}
		gBuyETFCompOrder[Num][IssueCode][CorpCode].IssueCode = IssueCode
		gBuyETFCompOrder[Num][IssueCode][CorpCode].CorpCode = CorpCode
		gBuyETFCompOrder[Num][IssueCode][CorpCode].AmendFlag = false
	end

	gBuyETFCompOrder[Num][IssueCode][CorpCode].Price = Price
	gBuyETFCompOrder[Num][IssueCode][CorpCode].Quantity = Quantity
	gBuyETFCompOrder[Num][IssueCode][CorpCode].WorkingQty = WorkingQty
	gBuyETFCompOrder[Num][IssueCode][CorpCode].ExecQty = ExecQty
	gBuyETFCompOrder[Num][IssueCode][CorpCode].RejQty = RejQty
	gBuyETFCompOrder[Num][IssueCode][CorpCode].CancelQty = CancelQty
	gBuyETFCompOrder[Num][IssueCode][CorpCode].UnAccQty = UnAccQty
	gBuyETFCompOrder[Num][IssueCode][CorpCode].ExecValue = ExecValue
	gBuyETFCompOrder[Num][IssueCode][CorpCode].Fare = Fare
end


--存储需要计算综合成本的卖出成份股记录
function SaveSellETFCompOrderInfo(IssueCode,CorpCode,Price,Quantity,WorkingQty,ExecQty,RejQty,CancelQty,UnAccQty,ExecValue,Fare,Num)
	local log = sys_format("SaveSellETFCompOrderInfo IssueCode:%s,CorpCode:%s,Price:%s,Quantity:%s,WorkingQty:%s,ExecQty:%s,RejQty:%s,CancelQty:%s,UnAccQty:%s,ExecValue:%s,Fare:%.2f,Num:%s",
		IssueCode,CorpCode,Price,Quantity,WorkingQty,ExecQty,RejQty,CancelQty,UnAccQty,ExecValue,Fare,Num)
	--_WriteAplLog(log)

	--如果不是买入ETF成份操作
	if Num == 0  or Num == nil then
		return
	end

	if gSellETFCorpToBatchID[CorpCode] == nil then
		gSellETFCorpToBatchID[CorpCode] = Num
	end

	if gSellETFCompOrder[Num] == nil then
		gSellETFCompOrder[Num] = {}
	end
	if gSellETFCompOrder[Num][IssueCode] == nil then
		gSellETFCompOrder[Num][IssueCode] = {}
	end
	if gSellETFCompOrder[Num][IssueCode][CorpCode] == nil then
		gSellETFCompOrder[Num][IssueCode][CorpCode] = {}
		gSellETFCompOrder[Num][IssueCode][CorpCode].IssueCode = IssueCode
		gSellETFCompOrder[Num][IssueCode][CorpCode].CorpCode = CorpCode
		gSellETFCompOrder[Num][IssueCode][CorpCode].AmendFlag = false
	end

	gSellETFCompOrder[Num][IssueCode][CorpCode].Price = Price
	gSellETFCompOrder[Num][IssueCode][CorpCode].Quantity = Quantity
	gSellETFCompOrder[Num][IssueCode][CorpCode].WorkingQty = WorkingQty
	gSellETFCompOrder[Num][IssueCode][CorpCode].ExecQty = ExecQty
	gSellETFCompOrder[Num][IssueCode][CorpCode].RejQty = RejQty
	gSellETFCompOrder[Num][IssueCode][CorpCode].CancelQty = CancelQty
	gSellETFCompOrder[Num][IssueCode][CorpCode].UnAccQty = UnAccQty
	gSellETFCompOrder[Num][IssueCode][CorpCode].ExecValue = ExecValue
	gSellETFCompOrder[Num][IssueCode][CorpCode].Fare = Fare
end

--ETF下拉框列表数据添加
function ShowETFList()
	--_WriteAplLog("ShowETFList");
	local DTSEvent Show = _CreateEventObject("ShowETFIssueList");
	local nameList = "";
	for IssueCode,FundName in pairs (_ETFIssue2NameTable)do
		nameList = nameList..";"..IssueCode;
	end
	--_WriteAplLog(nameList);
	Show._SetFld("ETFIssueList",nameList);
	_SendToClients(Show);
end

--重新设定篮子数后调用此函数刷新数据
function updateTradeQty(CashReplacePty)
	for etfName,value in pairs(_ETFName2IssueTable) do
		local logs = sys_format("update etfName:%s  tradeUnit:%d",etfName,gTradeUnitQty);
		--_WriteAplLog(logs);
		if _ETFComponentTable[etfName] then
			for issueCode,v in pairs(_ETFComponentTable[etfName]) do
				--local oldTradeAmount = v.TradeAmount;
				local SectorCode = _IssueSectorTable[issueCode]
				if _RSectorCode and  SectorCode then

					local logs1 = sys_format("update SectorCode1:%s",SectorCode);
					--_WriteAplLog(logs1);
					if _RSectorCode[SectorCode] == 1 and v.CashRepl~="禁止" then
						v.TradeAmount = 0;

					--if _SectorIssueTable[_RSectorCode][issueCode] == 1 then
						--v.TradeAmount = 0;
					else
						if v.CashRepl=="必须" then
							v.TradeAmount = 0
						else
							local tradeAmount1 = _ETFComponentTable[etfName][issueCode].Quantity * gTradeUnitQty * CashReplacePty;	--根据新的篮子数计算新的成交量
							tradeAmount1 = tradeAmount1 / 100;
							tradeAmount1  = sys_floor(tradeAmount1 )*100;
							local tradeAmount2 = _ETFComponentTable[etfName][issueCode].Quantity * gTradeUnitQty
							local tradeAmount = sys_min(tradeAmount1 ,tradeAmount2)
							v.TradeAmount = tradeAmount;
							local log2 = sys_format("update2 issueCode:%s,tradeAmount1:%s,tradeAmount2:%s,tradeAmount:%s",issueCode,tradeAmount1,tradeAmount2,tradeAmount)
						        --_WriteAplLog(log2)
						end

					end
				else
					if v.CashRepl=="必须" then
						v.TradeAmount = 0
					else
						local tradeAmount1 = _ETFComponentTable[etfName][issueCode].Quantity * gTradeUnitQty * CashReplacePty;	--根据新的篮子数计算新的成交量
						tradeAmount1 = tradeAmount1 / 100;
						tradeAmount1  = sys_floor(tradeAmount1 )*100;
						local tradeAmount2 = _ETFComponentTable[etfName][issueCode].Quantity * gTradeUnitQty
						local tradeAmount = sys_min(tradeAmount1 ,tradeAmount2)
						v.TradeAmount = tradeAmount;
						local log2 = sys_format("update3 issueCode:%s,tradeAmount1:%s,tradeAmount2:%s,tradeAmount:%s",issueCode,tradeAmount1,tradeAmount2,tradeAmount)
						--_WriteAplLog(log2)
					end



				end
				local logs = sys_format("update etfName:%s issue %s ",etfName,issueCode);
				if etfName == gETFName then
					sendCashRepltoClient(etfName,issueCode);
				end
			end
		end
	end
end

function sendSectorReplace()
	local log1 = sys_format("SectorReplace:%s",_RSectorCode)
	--_WriteAplLog(log1)
	local DTSEvent SectorReplaceEvent = _CreateEventObject("SectorReplaceOutput");
	SectorReplaceEvent._SetFld("SectorReplace",_RSectorCode);
	_SendToClients(SectorReplaceEvent);
end

--设置行业现金替代后调用此函数刷新数据
function updateTradeQty1()
	for etfName,value in pairs(_ETFName2IssueTable) do
		local logs = sys_format("update etfName:%s  tradeUnit:%d",etfName,gTradeUnitQty);
		--_WriteAplLog(logs);
		if _ETFComponentTable[etfName] then
			for issueCode,v in pairs(_ETFComponentTable[etfName]) do
				local SectorCode = _IssueSectorTable[issueCode]
				if SectorCode then
					if _RSectorCode[SectorCode] == 1 and v.CashRepl~="禁止" then
						v.TradeAmount = 0;
					else
						if v.CashRepl=="必须" then
							v.TradeAmount = 0
						else
							local tradeAmount1
							if _ETFComponentTable[etfName] then
								if _ETFComponentTable[etfName][issueCode] and _ETFInfoTable[gETFName] then
									tradeAmount1 = _ETFComponentTable[etfName][issueCode].Quantity * gTradeUnitQty * (1-_CashReplacePty)*_ETFInfoTable[gETFName].MarketValue/_BuyStockValue[gETFName];	--根据新的篮子数计算新的成交量
									tradeAmount1 = tradeAmount1 / 100;
									tradeAmount1  = sys_floor(tradeAmount1 )*100;
									local tradeAmount2 = _ETFComponentTable[etfName][issueCode].Quantity * gTradeUnitQty
									local tradeAmount = sys_min(tradeAmount1 ,tradeAmount2)
									v.TradeAmount = tradeAmount;
									local log2 = sys_format("tradeAmount1:%s,tradeAmount2:%s,tradeAmount:%s",tradeAmount1,tradeAmount2,tradeAmount)
									_WriteAplLog(log2)
								end
							end
						end
					end
				else
					if v.CashRepl=="必须" then
						v.TradeAmount = 0
					else
						local tradeAmount1
						if _ETFComponentTable[etfName] then
							if _ETFComponentTable[etfName][issueCode] and _ETFInfoTable[gETFName] then
								local tradeAmount1 = _ETFComponentTable[etfName][issueCode].Quantity * gTradeUnitQty * (1-_CashReplacePty)*_ETFInfoTable[gETFName].MarketValue/_BuyStockValue[gETFName];	--根据新的篮子数计算新的成交量
								tradeAmount1 = tradeAmount1 / 100;
								tradeAmount1  = sys_floor(tradeAmount1 )*100;
								local tradeAmount2 = _ETFComponentTable[etfName][issueCode].Quantity * gTradeUnitQty
								local tradeAmount = sys_min(tradeAmount1 ,tradeAmount2)
								v.TradeAmount = tradeAmount;
								local log2 = sys_format("tradeAmount1:%s,tradeAmount2:%s,tradeAmount:%s",tradeAmount1,tradeAmount2,tradeAmount)
								_WriteAplLog(log2)
							end
						end
					end
				end
				local logs = sys_format("update etfName:%s issue %s ",etfName,issueCode);
				if etfName == gETFName then
					sendCashRepltoClient(etfName,issueCode);
				end
			end
		end
	end
end

function calcSectorPty(etfName)
	local log = sys_format("calcSectorPty,ETFName: %s",etfName)
	_WriteAplLog(log)
	if not _ETFSectorPtyTable then
		_ETFSectorPtyTable = {}
	end
	if not _ETFSectorPtyTable[etfName] then
		_ETFSectorPtyTable[etfName] = {}
	end

	clearSectorPty()
	local i = 0
	gSectorPtyTable = {}
	if _ETFComponentTable[etfName] then
		for issueCode,v in pairs(_ETFComponentTable[etfName]) do
			local a = issueCode
			local weight = 0
			if gtIssueWeight[etfName] then
				if gtIssueWeight[etfName][issueCode] then
					weight = gtIssueWeight[etfName][issueCode]
				end
			end
			if _IssueSectorTable[issueCode] then
				local sectorCode = _IssueSectorTable[issueCode]

				if not gSectorPtyTable[sectorCode] then
					gSectorPtyTable[sectorCode] = weight
				else
					gSectorPtyTable[sectorCode] = gSectorPtyTable[sectorCode] + weight
				end
				--end
			end
			i = i + weight
		end
	end

	for sectorCode,pty in pairs(gSectorPtyTable) do
		if not _ETFSectorPtyTable[etfName][sectorCode] then
			_ETFSectorPtyTable[etfName][sectorCode] = {}
		end

		local DTSEvent SectorPtyEvent = _CreateEventObject("SectorPty");
		SectorPtyEvent._SetFld("SectorCode",sectorCode);

		if sectorCode == 1 then
			SectorPtyEvent._SetFld("SectorName", "农、林、牧、渔业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "农、林、牧、渔业"
		elseif sectorCode == 2 then
			SectorPtyEvent._SetFld("SectorName", "采掘业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "采掘业"
		elseif sectorCode == 3 then
			SectorPtyEvent._SetFld("SectorName", "制造业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "制造业"
		elseif sectorCode == 4 then
			SectorPtyEvent._SetFld("SectorName", "电力、煤气及水的生产和供应业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "电力、煤气及水的生产和供应业"
		elseif sectorCode == 5 then
			SectorPtyEvent._SetFld("SectorName", "建筑业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "建筑业"
		elseif sectorCode == 6 then
			SectorPtyEvent._SetFld("SectorName", "交通运输、仓储业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "交通运输、仓储业"
		elseif sectorCode == 7 then
			SectorPtyEvent._SetFld("SectorName", "信息技术业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "信息技术业"
		elseif sectorCode == 8 then
			SectorPtyEvent._SetFld("SectorName", "批发和零售贸易");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "批发和零售贸易"
		elseif sectorCode == 9 then
			SectorPtyEvent._SetFld("SectorName", "金融、保险业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "金融、保险业"
		elseif sectorCode == 10 then
			SectorPtyEvent._SetFld("SectorName", "房地产业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "房地产业"
		elseif sectorCode == 11 then
			SectorPtyEvent._SetFld("SectorName", "社会服务业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "社会服务业"
		elseif sectorCode == 12 then
			SectorPtyEvent._SetFld("SectorName", "传播与文化产业");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "传播与文化产业"
		elseif sectorCode == 13 then
			SectorPtyEvent._SetFld("SectorName", "综合类");
			_ETFSectorPtyTable[etfName][sectorCode]["SectorName"] = "综合类"
		end

		local sectorPty = pty/i*100
		local sectorPtyString = sectorPty.toString()
		sectorPtyString = sys_sub(sectorPtyString,1,5)
		sectorPtyString=sectorPtyString.."%"

		SectorPtyEvent._SetFld("Pty",sectorPtyString);
		_ETFSectorPtyTable[etfName][sectorCode]["Pty"] = sectorPtyString
		if _RSectorCode then
			if _RSectorCode[sectorCode]== 1 then
				SectorPtyEvent._SetFld("IsReplace","是");
				SectorPtyEvent._SetFld("IsReplaceNo","1");
			else
				SectorPtyEvent._SetFld("IsReplace","否");
				SectorPtyEvent._SetFld("IsReplaceNo","0");
			end
		else
			SectorPtyEvent._SetFld("IsReplace","否");
			SectorPtyEvent._SetFld("IsReplaceNo","0");
		end

		local etfIssue = _ETFName2IssueTable[etfName]
		local type
		if _PosETFInfoTable[etfIssue] then
			type = _PosETFInfoTable[etfIssue].Type
		end

		if type == POS_ETF_MULTIAREA then   --跨境ETF不显示行业比例
			SectorPtyEvent._SetFld("ShowFlag", "0");

		else
			SectorPtyEvent._SetFld("ShowFlag", "1");

		end
		_SendToClients(SectorPtyEvent);
	end
end

function clearSectorPty()
	if gSectorPtyTable then
		for sectorCode,pty in pairs(gSectorPtyTable) do
			local DTSEvent SectorPtyEvent = _CreateEventObject("SectorPty");
			SectorPtyEvent._SetFld("ShowFlag", "0");
			_SendToClients(SectorPtyEvent);
		end
	end
end

function updateSectorInfo(etfName,sectorCode,IsReplace,IsReplaceNo)
	local DTSEvent SectorPtyEvent = _CreateEventObject("SectorPty");
	--local sectorCode = _ETFSectorPtyTable[etfName][sectorCode]["SectorCode"]
	SectorPtyEvent._SetFld("SectorCode",sectorCode);
	local sectorName = _ETFSectorPtyTable[etfName][sectorCode]["SectorName"]
	SectorPtyEvent._SetFld("SectorName", sectorName);
	local sectorPty = _ETFSectorPtyTable[etfName][sectorCode]["Pty"]
	SectorPtyEvent._SetFld("Pty",sectorPty);
	SectorPtyEvent._SetFld("IsReplace",IsReplace);
	SectorPtyEvent._SetFld("IsReplaceNo",IsReplaceNo);
	local etfIssue = _ETFName2IssueTable[etfName]
	local type
	if _PosETFInfoTable[etfIssue] then
		type = _PosETFInfoTable[etfIssue].Type
	end
	local log = sys_format("ETF类型为：%s",type)

	if type == POS_ETF_MULTIAREA then   --跨境ETF不显示行业比例
		SectorPtyEvent._SetFld("ShowFlag", "0");
	else
		SectorPtyEvent._SetFld("ShowFlag", "1");
	end
	_SendToClients(SectorPtyEvent);
end

function sendCashReplacePty()
	local log1 = sys_format("_CashReplacePty:%s",_CashReplacePty)
	--_WriteAplLog(log1)
	local DTSEvent CashReplacePtyEvent = _CreateEventObject("CashReplacePty");
	CashReplacePtyEvent._SetFld("CashReplacePty",_CashReplacePty);
	local log = sys_format("_CashReplacePty:%s",_CashReplacePty)
	--_WriteAplLog(log)
	--_WriteAplLog("send ctr")
	_SendToClients(CashReplacePtyEvent);
end

function calcWeight(etfName,issueCode,weight)
	--_WriteAplLog("calcWeight");
	if not gtIssueWeight[etfName] then
		gtIssueWeight[etfName] = {};
		gtIsWeightCalc[etfName] = false;
	end
	--each issue in one ETF can only calculate weight once
	if not gtIssueWeight[etfName][issueCode] then
		gtIssueWeight[etfName][issueCode] = weight;
	end
	--when all the componets' price has come, and the weight of this ETF has not calculated, then it will be calculated.
	if _ETFInfoTable[etfName].PriceCount == _ETFInfoTable[etfName].IssueCount and not gtIsWeightCalc[etfName] then
		local tWeight = {};
		local tWeightOfIssue = {};
		for issueCode,weight in pairs(gtIssueWeight[etfName]) do
			if not tWeightOfIssue[weight] then
				tWeightOfIssue[weight] = {};
				sys_insert(tWeight,weight);
			end
			sys_insert(tWeightOfIssue[weight],issueCode);
		end
		--按照升序排序tWeight,然后再按照降序读取，使得权重由大到小读取出来
		sys_sort(tWeight,"asc");
		gtETFWeightSize[etfName] = sys_getSize(tWeight);
		gtWeight[etfName] = tWeight;
		gtWeightOfIssue[etfName] = tWeightOfIssue;
		gtIsWeightCalc[etfName] = true;
	end
end

--状态判断函数
function stateJudge(aq1,aq2,aq3,aq4,aq5,bq1,bq2,bq3,bq4,bq5)
	--local logs = sys_format("stateJudge-aq1:%s,aq2:%s,aq3:%s,aq4:%s,aq5:%s,bq1:%s,bq2:%s,bq3:%s,bq4:%s,bq5:%s",aq1,aq2,aq3,aq4,aq5,bq1,bq2,bq3,bq4,bq5)
	--_WriteAplLog(logs);
	if (aq1==0 or aq1==nil) and (aq2==0 or aq2==nil) and (aq3==0 or aq3==nil) and (aq4==0 or aq4==nil) and (aq5==0 or aq5==nil) and (bq1==0 or bq1==nil) and (bq2==0 or bq2==nil) and (bq3==0 or bq3==nil) and (bq4==0 or bq4==nil) and (bq5==0 or bq5==nil) then
		return "0";	--未开盘
	elseif (aq1>0 or aq2>0 or aq3>0 or aq4>0 or aq5>0) and (bq1==0 or bq1==nil) and (bq2==0 or bq2==nil) and (bq3==0 or bq3==nil) and (bq4==0 or bq4==nil) and (bq5==0 or bq5==nil) then
		return "1";	--跌停
	elseif (aq1==0 or aq1==nil) and (aq2==0 or aq2==nil) and (aq3==0 or aq3==nil) and (aq4==0 or aq4==nil) and (aq5==0 or aq5==nil) and (bq1>0 or bq2>0 or bq3>0 or bq4>0 or bq5>0) then
		return "2";	--涨停
	else--if (aq1>0 and aq2>0 and aq3>0 and aq4>0 and aq5>0) and (bq1>0 and bq2>0 and bq3>0 and bq4>0 and bq5>0) then
		return "3";	--正常
	end
end

--显示篮子数
function showTradeUnitQty()
	local logs = sys_format("showTradeUnitQty-gTradeUnitQty:%s",gTradeUnitQty)
	_WriteAplLog(logs)
	local DTSEvent trdUnitQtyEvent = _CreateEventObject("TradeUnitQtyOutput");
	trdUnitQtyEvent._SetFld("TradeUnitQty",gTradeUnitQty);
	trdUnitQtyEvent._SetFld("KeyForBuffer",1);
	_SendToClients(trdUnitQtyEvent);
end



--显示买盘tick
function showBuyTick()
	local DTSEvent buyTickEvent = _CreateEventObject("BuyTickOutput");
	buyTickEvent._SetFld("BuyTick",gBuyTick);
	buyTickEvent._SetFld("KeyForBuffer",1);
	local logs = sys_format("showBuyTick-gBuyTick:%s",gBuyTick)
	_WriteAplLog(logs)
	_SendToClients(buyTickEvent);
end



--显示买盘tick
function showSellTick()
	local logs = sys_format("showSellTick-gSellTick:%s",gSellTick)
	_WriteAplLog(logs)
	local DTSEvent sellTickEvent = _CreateEventObject("SellTickOutput");
	sellTickEvent._SetFld("SellTick",gSellTick);
	sellTickEvent._SetFld("KeyForBuffer",1);
	_SendToClients(sellTickEvent);
end



--显示改价tick
function showAmendTick()
	local logs = sys_format("showAmendTick-gAmendTick:%s",gAmendTick)
	_WriteAplLog(logs)
	local DTSEvent amendTickEvent = _CreateEventObject("AmendTickOutput");
	amendTickEvent._SetFld("AmendTick",gAmendTick);
	amendTickEvent._SetFld("KeyForBuffer",1);
	_SendToClients(amendTickEvent);
end



--显示改价价格
function showAmendPrice()
	local DTSEvent amendOrderPriceEvent = _CreateEventObject("AmendOrderPriceOutput");
	amendOrderPriceEvent._SetFld("AmenderPrice",gAmendPrice);
	amendOrderPriceEvent._SetFld("KeyForBuffer",1);
	_SendToClients(amendOrderPriceEvent);
end

--更新ETF状态
function updateETFStatus(issueCode)
	--sunzhijian 2011-11-10
	local tIssuePriceInfo = _PosPriceTable[issueCode];
	local aq1 = tIssuePriceInfo.AskQuantity1;
	local aq2 = tIssuePriceInfo.AskQuantity2;
	local aq3 = tIssuePriceInfo.AskQuantity3;
	local aq4 = tIssuePriceInfo.AskQuantity4;
	local aq5 = tIssuePriceInfo.AskQuantity5;
	local bq1 = tIssuePriceInfo.BidQuantity1;
	local bq2 = tIssuePriceInfo.BidQuantity2;
	local bq3 = tIssuePriceInfo.BidQuantity3;
	local bq4 = tIssuePriceInfo.BidQuantity4;
	local bq5 = tIssuePriceInfo.BidQuantity5;
	local lp = tIssuePriceInfo.LastPrice or 0;

	--如果是ETF行情
	if _ETFIssue2NameTable[issueCode] then
		local etfName = _ETFIssue2NameTable[issueCode];
		if _ETFInfoTable[etfName] then
			_ETFInfoTable[etfName].hasETFPrice = true;
			--计算市值
			_ETFInfoTable[etfName].MarketValue = _ETFInfoTable[etfName].Unit * lp;
			--更新图,表
			if not (_ETFInfoTable[etfName].hasETFPrice and _ETFInfoTable[etfName].PriceCount == _ETFInfoTable[etfName].IssueCount) then
				--_WriteAplLog("Not all price has come.");
			end
			--ETF行情状态的判断
			_ETFInfoTable[etfName].ETFStatus = stateJudge(aq1,aq2,aq3,aq4,aq5,bq1,bq2,bq3,bq4,bq5);
		end
	--如果是成份股行情
	else
		if _IssueETFTable[issueCode] then
			--成份股行情状态的判断
			if not gtStockStatusTable[issueCode] then
				 gtStockStatusTable[issueCode] = {};
				 gtStockStatusTable[issueCode].Status = "3";
			end
			local oldStatus = gtStockStatusTable[issueCode].Status;
			local newStatus = stateJudge(aq1,aq2,aq3,aq4,aq5,bq1,bq2,bq3,bq4,bq5);
			if newStatus == "0" then
				lp = _PosPriceTable[issueCode].AdjustedLNC or 0
			end
			if oldStatus == "0" and newStatus == "1" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockStop = _ETFInfoTable[etfName].StockStop - 1;
					_ETFInfoTable[etfName].StockDrop = _ETFInfoTable[etfName].StockDrop + 1;
					gtStockStatusTable[issueCode].Status = "1";
				end
			elseif oldStatus == "0" and newStatus == "2" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockStop = _ETFInfoTable[etfName].StockStop - 1;
					_ETFInfoTable[etfName].StockRise = _ETFInfoTable[etfName].StockRise + 1;
					gtStockStatusTable[issueCode].Status = "2";
				end
			elseif oldStatus == "0" and newStatus == "3" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do

					_ETFInfoTable[etfName].StockStop = _ETFInfoTable[etfName].StockStop - 1;
					gtStockStatusTable[issueCode].Status = "3";

				end
			elseif oldStatus == "1" and newStatus == "0" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockDrop = _ETFInfoTable[etfName].StockDrop - 1;
					_ETFInfoTable[etfName].StockStop = _ETFInfoTable[etfName].StockStop + 1;
					gtStockStatusTable[issueCode].Status = "0";
					--_WriteAplLog("StockStop : ");
				--	_WriteAplLog(issueCode);
				end
			elseif oldStatus == "1" and newStatus == "2" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockDrop = _ETFInfoTable[etfName].StockDrop - 1;
					_ETFInfoTable[etfName].StockRise = _ETFInfoTable[etfName].StockRise + 1;
					gtStockStatusTable[issueCode].Status = "2";
				end
			elseif oldStatus == "1" and newStatus == "3" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockDrop = _ETFInfoTable[etfName].StockDrop - 1;
					gtStockStatusTable[issueCode].Status = "3";
				--	_WriteAplLog("StockDrop1 -1: ");
				--	_WriteAplLog(issueCode);
				end
			elseif oldStatus == "2" and newStatus == "0" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockRise = _ETFInfoTable[etfName].StockRise - 1;
					_ETFInfoTable[etfName].StockStop = _ETFInfoTable[etfName].StockStop + 1;
					gtStockStatusTable[issueCode].Status = "0";
					--_WriteAplLog("StockStop2 : ");
					--_WriteAplLog(issueCode);
				end
			elseif oldStatus == "2" and newStatus == "1" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockRise = _ETFInfoTable[etfName].StockRise - 1;
					_ETFInfoTable[etfName].StockDrop = _ETFInfoTable[etfName].StockDrop + 1;
					gtStockStatusTable[issueCode].Status = "1";
				end
			elseif oldStatus == "2" and newStatus == "3" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockRise = _ETFInfoTable[etfName].StockRise - 1;
					gtStockStatusTable[issueCode].Status = "3";
				end
			elseif oldStatus == "3" and newStatus == "0" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockStop = _ETFInfoTable[etfName].StockStop + 1;
					gtStockStatusTable[issueCode].Status = "0";
					--_WriteAplLog("StockStop3 : ");
					--_WriteAplLog(issueCode);
				end
			elseif oldStatus == "3" and newStatus == "1" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockDrop = _ETFInfoTable[etfName].StockDrop + 1;
					gtStockStatusTable[issueCode].Status = "1";
					--_WriteAplLog("StockDrop3: ");
					--_WriteAplLog(issueCode);
				end
			elseif oldStatus == "3" and newStatus == "2" then
				for etfName, v in pairs(_IssueETFTable[issueCode]) do
					_ETFInfoTable[etfName].StockRise = _ETFInfoTable[etfName].StockRise + 1;
					gtStockStatusTable[issueCode].Status = "2";
				end
			end
			for etfName, v in pairs(_IssueETFTable[issueCode]) do
				if not _IssueWeightTable[etfName] then
					_IssueWeightTable[etfName] = {}
				end

				if not _ETFInfoTable[etfName].PriceSet[issueCode] then
					_ETFInfoTable[etfName].PriceSet[issueCode] = 1;
					_ETFInfoTable[etfName].PriceCount = _ETFInfoTable[etfName].PriceCount + 1;
				end
				if _ETFComponentTable[etfName] then
					if _ETFComponentTable[etfName][issueCode] then
						local componentInfo = _ETFComponentTable[etfName][issueCode];

						--计算净值
						local newValue = 0;
						--local testlog = sys_format("更新ETF状态:lastprice=%s,清单数量=%s",lp,componentInfo.Quantity)
						--_WriteAplLog(testlog)
						if lp then
							local weight = lp * componentInfo.Quantity;	--权重 = 最新价 * 清单数量
							_IssueWeightTable[etfName][issueCode] = weight
                            if componentInfo.CashRepl == "必须" or componentInfo.CashRepl == "深市必须" then
								newValue = componentInfo.CashAmount;
							else
								newValue = weight;
							end
							_ETFInfoTable[etfName].NetValue = _ETFInfoTable[etfName].NetValue + newValue - componentInfo.Value;

							componentInfo.Value = newValue;
							--统计权重
							calcWeight(etfName,issueCode,weight);
						else
							_WriteAplLog("当前最新价lp为空")
						end
					end
				end
				--更ETF基本信息
				if not (_ETFInfoTable[etfName].hasETFPrice and _ETFInfoTable[etfName].PriceCount == _ETFInfoTable[etfName].IssueCount) then
					local log = sys_format("Not all price has come. %s/%s", _ETFInfoTable[etfName].PriceCount, _ETFInfoTable[etfName].IssueCount)
					--_WriteAplLog(log);
				else
					if not _BuyStockValue[etfName] then
						_BuyStockValue[etfName] = 0
						if _ETFComponentTable[gETFName] then
							for k,v in pairs(_ETFComponentTable[gETFName]) do
								if _IssueWeightTable[gETFName][k] then
									if gtStockStatusTable[k].Status == "0" or gtStockStatusTable[k].Status == "2" or _ETFComponentTable[gETFName][k] == "禁止" then
										if _IssueWeightTable[gETFName][k] then
											_BuyStockValue[etfName] = _BuyStockValue[etfName] + _IssueWeightTable[gETFName][k]
										end
									end
								end
							end
						end
						if _ETFInfoTable[gETFName] then
							_BuyStockValue[etfName] = _ETFInfoTable[gETFName].MarketValue - _BuyStockValue[etfName]
						end
						local log2 = sys_format("_BuyStockValue:%s,etfName:%s",_BuyStockValue[etfName],etfName)
						--_WriteAplLog(log2);
					 	if _BuyStockValue[gETFName] then --and _BuyStockValue[gETFName]> 0 then
							if _ETFInfoTable[gETFName] then
								if _BuyStockValue[gETFName]> 0 then
									local CashReplacePty = (1-_CashReplacePty)*_ETFInfoTable[gETFName].MarketValue/_BuyStockValue[gETFName]
									updateTradeQty(CashReplacePty)
								else
									updateTradeQty(1);
								end
							end
						else
							updateTradeQty(1);
						end
						calcSectorPty(etfName)
					end

					if etfName == gETFName then
						if _ETFComponentTable[gETFName][issueCode] then
							sendEtfInfoToClient(gETFName,gTradeUnitQty);
						end
					end
				end
			end
		end
	end
end


function getPriceCondition()
	local priceCondition = getETFPriceCondition();
	return priceCondition;
end

function getETFPriceCondition()
	local priceCondition = "";
	local EtfIssue = _ETFName2IssueTable[gETFName];
	local marketCode = _PosIssueMarketTable[EtfIssue]
	if marketCode == "1" then
		priceCondition = "H";
	else
		priceCondition = "X";
	end
	return priceCondition;
end


--更新ETF基本信息
function sendEtfInfoToClient(etfName,qty)
	--_WriteAplLog("sendEtfInfoToClient")
	if not _ETFInfoTable[etfName] then
		return;
	end
	local DTSEvent baseInfoEvt = _CreateEventObject("ETFBaseInfo");
	baseInfoEvt._SetFld("ETFName", etfName);
	local EtfIssue = _ETFName2IssueTable[etfName];
	baseInfoEvt._SetFld("ETFIssueCode", EtfIssue);
	local tETFInfo = _ETFInfoTable[etfName]
	field = tETFInfo.Date;
	baseInfoEvt._SetFld("Date", field);
	local CashAmount = tETFInfo.CashAmount

	--修正现金替代科学技术法显示
	local tmpCashAmount = sys_format("%.02f",CashAmount)
	baseInfoEvt._SetFld("CashAmount",tmpCashAmount);
	--baseInfoEvt._SetFld("CashAmount",gCashAmount);
	field = tETFInfo.EstimateCash;
	baseInfoEvt._SetFld("EstimateCash",field );
	field = tETFInfo.PreCash;
	baseInfoEvt._SetFld("PreCash", field);
	field = tETFInfo.IssueCount;
	baseInfoEvt._SetFld("IssueCount",field );
	field = tETFInfo.Unit;
	local unit = field.getNumberValue();
	baseInfoEvt._SetFld("Unit",field );
	field = tETFInfo.MaxCashRatio;
	baseInfoEvt._SetFld("MaxCashRatio",field);
	local unitQty = qty;
	baseInfoEvt._SetFld("TradeUnitQty",unitQty );
	baseInfoEvt._SetFld("Flag","1" );
	local tradeAmount = unitQty * unit;	--交易数量=篮子数*最小交易单位
	field = tradeAmount;
	baseInfoEvt._SetFld("TradeAmount",field );
	local lastPrice = 0;
	if _PosPriceTable[EtfIssue] then
		lastPrice = _PosPriceTable[EtfIssue].LastPrice;	--ETF最新价 sunzhijian 2011-11-10
	end
	field = sys_format("%.3f",lastPrice);
	baseInfoEvt._SetFld("LastPrice",field);
	local keyPosList = spBAMapID..".3."..EtfIssue;
	local quantity = 0;
	local availableQty = 0;
	local availableCreRedempQty = 0;
	--sunzhijian 2011-11-09
	if gtInvestorPositionInfo[EtfIssue] then
		quantity = gtInvestorPositionInfo[EtfIssue].Quantity;
		availableQty = gtInvestorPositionInfo[EtfIssue].AvlQuantity;
		availableCreRedempQty = gtInvestorPositionInfo[EtfIssue].AvlCreRedQuantity;--可申赎数量
	end
	field = availableQty;
	baseInfoEvt._SetFld("AvailableQty",field );
	field = availableCreRedempQty;
	baseInfoEvt._SetFld("AvailableCreRedempQty",field );
	field = "";
	local stockStop = tETFInfo.StockStop;
	local stockDrop = tETFInfo.StockDrop;
	local stockRise = tETFInfo.StockRise;
	local eTFStatus=tETFInfo.ETFStatus;
	if stockStop > 0 then
		local stop = stockStop.toString();
		field = "未开盘："..stop.." ";
	end
	if stockDrop > 0 then
		local drop = stockDrop.toString();
		field = field.."跌停："..drop.." ";
	end
	if stockRise > 0 then
		local rise = stockRise.toString();
		field = field.."涨停："..rise.." ";
	end
	if eTFStatus == "0" then
		field = field.."ETF:未开盘";
	end
	if eTFStatus == "1" then
		field = field.."ETF:跌停";
	end
	if eTFStatus == "2" then
		field = field.."ETF:涨停";
	end
	baseInfoEvt._SetFld("Status", field);
	local netValue = tETFInfo.NetValue
		if netValue ~= nil and netValue ~= "" and unit ~= nil and unit ~= 0 then
		netValue = netValue.getNumberValue()
		field = netValue / unit;
		field = sys_format("%.3f", field)
		baseInfoEvt._SetFld("NetValue", field);
	end
	--field = tETFInfo.MarketValue;
	field = sys_format("%.3f",lastPrice);
	baseInfoEvt._SetFld("MarketValue", field);
	local log = sys_format("send ETFBaseInfo(%s),TradeUnitQty(%d),LastPrice(%s)",etfName,qty,lastPrice);
	--debugLog(log)
	--_WriteAplLog(log);
	_SendToClients(baseInfoEvt);
end

--选择ETF处理逻辑
function selectETFIssue(etfName)
	if etfName == gETFName then
		local log = etfName .. "已经是当前ETF";
		sendLog(log);
		return;
	end
	--clear last ETF information
	clearCashRepl(gETFName);
	gETFName = etfName;
	local logs = sys_format("选择%s",gETFName)
	sendLog(logs);

	gBidQuote = "自动盘口"
	gAskQuote = "自动盘口"
	showBidQuote();
	showAskQuote();

	InitETFComponentTradeInfo()
	resetUseAvl()
	saveETFDynamicData();	--存入DyanamicData
	sendEtfInfoToClient(etfName,gTradeUnitQty);

	calcSectorPty(etfName)
	if (_ETFInfoTable[etfName].hasETFPrice and _ETFInfoTable[etfName].PriceCount == _ETFInfoTable[etfName].IssueCount) then
		--_WriteAplLog("enter")
		if not _BuyStockValue[etfName] then
			_BuyStockValue[etfName] = 0
			if _ETFComponentTable[gETFName] then
				for k,v in pairs(_ETFComponentTable[gETFName]) do
					if gtStockStatusTable[k].Status == "0" or gtStockStatusTable[k].Status == "2" or _ETFComponentTable[gETFName][k] == "禁止" then
						if _IssueWeightTable then
							if _IssueWeightTable[gETFName] then
								if _IssueWeightTable[gETFName][k] then
									_BuyStockValue[etfName] = _BuyStockValue[etfName] + _IssueWeightTable[gETFName][k]
								end
							end
						end
					end
				end
			end
			if _ETFInfoTable[gETFName] then
				_BuyStockValue[etfName] = _ETFInfoTable[gETFName].MarketValue - _BuyStockValue[etfName]
			end
			local log2 = sys_format("_BuyStockValue:%s,etfName:%s",_BuyStockValue[etfName],etfName)
			--_WriteAplLog(log2);
			--calcSectorPty(etfName)
		end
	end
	if _ETFInfoTable[gETFName] then
		if _CashReplacePty > _ETFInfoTable[gETFName].MaxCashRatio then
			_CashReplacePty = _ETFInfoTable[gETFName].MaxCashRatio
			sendCashReplacePty()
			logs = sys_format("自动修改%s的最大现金替代比例%s",gETFName,_ETFInfoTable[gETFName].MaxCashRatio);
			sendLog(logs);
			if _BuyStockValue[gETFName] then --and _BuyStockValue[gETFName]> 0 then
				if _BuyStockValue[gETFName]> 0 then
					local CashReplacePty = (1-_CashReplacePty)*_ETFInfoTable[gETFName].MarketValue/_BuyStockValue[gETFName]
					updateTradeQty(CashReplacePty)
				else
					updateTradeQty(1);
				end
				--calcSectorPty(etfName)
			else
				updateTradeQty(1);
				--calcSectorPty(etfName)
			end
		else
			if _BuyStockValue[gETFName] then --and _BuyStockValue[gETFName]> 0 then
				if _BuyStockValue[gETFName]> 0 then
					local CashReplacePty = (1-_CashReplacePty)*_ETFInfoTable[gETFName].MarketValue/_BuyStockValue[gETFName]
					updateTradeQty(CashReplacePty)
					--calcSectorPty(etfName)
				else
					updateTradeQty(1);
				end
			else
				updateTradeQty(1);
				--calcSectorPty(etfName)
			end
		end
		--calcSectorPty(etfName)
	end
end

--将信息存入DynamicData
function saveETFDynamicData()
	--_WriteAplLog("saveETFDynamicData");
	ETFDDStore._Clear();	--清理掉DynamicData里的数据
	for etfNameV,v in pairs(_ETFInfoTable) do
		if( etfNameV == gETFName)then	--只保存当前ETF
			local DTSEvent ETFDDEvent = _CreateEventObject("ETFDynamicData");
			ETFDDEvent._SetFld("ETFName", gETFName);
			ETFDDEvent._SetFld("TradeUnitQty",gTradeUnitQty);
			ETFDDEvent._SetFld("BidQuote",gBidQuote);
			ETFDDEvent._SetFld("AskQuote",gAskQuote);
			ETFDDEvent._SetFld("BuyTick",gBuyTick);
			ETFDDEvent._SetFld("SellTick",gSellTick);
			ETFDDEvent._SetFld("AmendTick",gAmendTick);
			ETFDDEvent._SetFld("AmendPrice",gAmendPrice);
			ETFDDEvent._SetFld("AutoCancelTime",gAutoCancelTime);
			ETFDDEvent._SetFld("Key","1");
			local logs = sys_format("saveETFDynamicData,gETFName:%s,gTradeUnitQty:%s,gBidQuote:%s,gAskQuote:%s,gBuyTick:%s,gSellTick:%s,gAmendTick:%s,gAmendPrice:%s",gETFName,gTradeUnitQty,gBidQuote,gAskQuote,gBuyTick,gSellTick,gAmendTick,gAmendPrice);
			--_WriteAplLog(logs);
			ETFDDStore._SaveData("ETFDynamicData", ETFDDEvent);	--将最新数据存入DynamicData
            break
		end
	end
end



--重新设定篮子数后调用此函数刷新数据
function updateComponentInfoTradeQty(oldTradeUnit)
	for etfName,value in pairs(_ETFName2IssueTable) do
		local logs = sys_format("update etfName:%s  tradeUnit:%d",etfName,gTradeUnitQty);
		--_WriteAplLog(logs);
		if _ETFComponentTable[etfName] then
			for issueCode,v in pairs(_ETFComponentTable[etfName]) do
				local oldTradeAmount = v.TradeAmount;
				local tradeAmount = oldTradeAmount * gTradeUnitQty/ oldTradeUnit ;	--根据新的篮子数计算新的成交量
				local remainQty = tradeAmount % 100;
				local _Int cl = tradeAmount /100;
				if(remainQty > 0 )then
					tradeAmount = cl * 100;
					local log = sys_format("set tradeQty %d,cl:%d ",tradeAmount,cl);
					--_WriteAplLog(logs);
				end
				v.TradeAmount = tradeAmount;
				local logs = sys_format("update etfName:%s issue %s tradeAmount:%d",etfName,issueCode,tradeAmount);
				if etfName == gETFName then
					sendCashRepltoClient(etfName,issueCode);
				end
			end
		end
	end
end



--当某档价格不理想时，取下一档行情
function getNextPriceType(priceType)
	local newPriceType = "";
	if(priceType == "买5")then
		newPriceType = "买4";
	elseif(priceType == "买4")then
		newPriceType = "买3";
	elseif(priceType == "买3")then
		newPriceType = "买2";
	elseif(priceType == "买2")then
		newPriceType = "买1";
	elseif(priceType == "买1" or priceType == "卖1")then
		newPriceType = "最新";
	elseif(priceType == "卖5")then
		newPriceType = "卖4";
	elseif(priceType == "卖5")then
		newPriceType = "卖4";
	elseif(priceType == "卖4")then
		newPriceType = "卖3";
	elseif(priceType == "卖3")then
		newPriceType = "卖2";
	elseif(priceType == "卖2")then
		newPriceType = "卖1";
	end
	return newPriceType;
end

function getOrderPrice(issue,priceType,tick,buySell,orderQty)
	local price = 0
	local confidence = GetConfidenceByIssueCode(issue)
	if (priceType == "自动盘口") then
		if buySell == "3" then
			local PriceAndQty = getMarketPrice(issue,0,orderQty,confidence)
			price = PriceAndQty.Price
		else
			local PriceAndQty = getMarketPrice(issue,1,orderQty,confidence)
			price = PriceAndQty.Price
		end
	else
		price = getOrderPrice(issue,priceType,tick,buySell)
	end
	return price
end

--获取价格
function getOrderPrice(issue,priceType,tick,buySell)
	local returnPrice = -1.00;
	local newPriceType = priceType;
	while (returnPrice <= 0.0) do
		returnPrice = getOrderSmartPrice(issue,newPriceType,tick,buySell);
		if(returnPrice == -1.00)then
			break;
		elseif(returnPrice == -9.00)then
			newPriceType = getNextPriceType(newPriceType);
			if(newPriceType == "")	then
				returnPrice = -1.00;
				break;
			end
			returnPrice = getOrderSmartPrice(issue,newPriceType,tick,buySell);
		end
	end
	return returnPrice;
end


--将价格类型转化成价格数字
function getOrderSmartPrice(issue,priceType,tick,buySell)
	if not _PosPriceTable[issue] then
		return -1.00;
	end
	local OrderPrice = 0.00;
	local tIssuePriceInfo = _PosPriceTable[issue];
	--停牌股票判断
	if(tIssuePriceInfo.BidQuantity1 == 0 and tIssuePriceInfo.BidQuantity2 == 0 and tIssuePriceInfo.BidQuantity3 == 0 and tIssuePriceInfo.BidQuantity4 == 0 and tIssuePriceInfo.BidQuantity5 == 0
		and tIssuePriceInfo.AskQuantity1 == 0 and tIssuePriceInfo.AskQuantity2 == 0 and tIssuePriceInfo.AskQuantity3 == 0 and tIssuePriceInfo.AskQuantity4 == 0 and tIssuePriceInfo.AskQuantity5 == 0)then
		--return tIssuePriceInfo.LastPrice;	--模拟用
		return -1;	--生产用 --sunzhijian 2011-11-09
	end
	--sunzhijian 2011-11-10
	if(priceType == "买1")then
		OrderPrice = tIssuePriceInfo.BidPrice1;
	elseif(priceType =="买2")then
		OrderPrice = tIssuePriceInfo.BidPrice2;
	elseif(priceType =="买3")then
		OrderPrice = tIssuePriceInfo.BidPrice3;
	elseif(priceType =="买4")then
		OrderPrice =  tIssuePriceInfo.BidPrice4;
	elseif(priceType =="买5")then
		OrderPrice = tIssuePriceInfo.BidPrice5;
	elseif(priceType =="最新")then
		OrderPrice = tIssuePriceInfo.LastPrice;
	elseif(priceType =="卖1")then
		OrderPrice = tIssuePriceInfo.AskPrice1;
	elseif(priceType =="卖2")then
		OrderPrice = tIssuePriceInfo.AskPrice2;
	elseif(priceType =="卖3")then
		OrderPrice = tIssuePriceInfo.AskPrice3;
	elseif(priceType =="卖4")then
		OrderPrice = tIssuePriceInfo.AskPrice4;
	elseif(priceType =="卖5")then
		OrderPrice = tIssuePriceInfo.AskPrice5;
	elseif(priceType =="涨停")then
		OrderPrice = tIssuePriceInfo.UpLimitPrice;
	elseif(priceType =="跌停")then
		OrderPrice = tIssuePriceInfo.LowLimitPrice;
	elseif(priceType =="市价")then--市价转限价限价如何定？
		return  -2.00;
	end
	-- add tick
	if(OrderPrice ~= nil and OrderPrice ~= 0)then
		local productCode = _PosIssueProductCodeTable[issue]
		local marketCode = _PosIssueMarketTable[issue]
		local underlyingIssueCode = _PosIssueUnderlyingTable[issue]
		local key = productCode.."-"..marketCode.."-"..underlyingIssueCode
		local priceTick = _PosIssuePriceTickTable[issue];
		OrderPrice = OrderPrice + priceTick * tick.getNumberValue();
	else
		return -9.00;
	end
	return OrderPrice;	--卖1;卖2;卖3;卖4;卖5;最新;买1;买2;买3;买4;买5;买1;涨停;跌停
end


function priceToNumber(s)
	if not s then
		return nil;
	end
	if s == "" then
		return nil;
	end
	return s.getNumberValue();
end
function quantityToNumber(s)
	if not s then
		return 0;
	end
	if s == "" then
		return 0;
	end
	return s.getNumberValue();
end

--QueryETFList回调函数
function OnQueryETFListTable(etfListTable)
	local ETFID = etfListTable.ETFID
	local IssueCode = etfListTable.IssueCode
	local FundName = etfListTable.FundName
	--_ETFID2NameTable[ETFID] = FundName;
	--_ETFIssue2NameTable[IssueCode] = FundName;
	--_ETFName2IssueTable[FundName] = IssueCode;
	local CreationRedemptionUnit = etfListTable.CreationRedemptionUnit --最小申赎单位
	local Estimatecashcomponent = etfListTable.EstimateCashComponent--预估现金部分
	if Estimatecashcomponent == "" or Estimatecashcomponent == nil then
		Estimatecashcomponent = 0;
	end
	local MaxCashRatio = etfListTable.MaxCashRatio;		--最大现金替代比例
	local RecordNum = etfListTable.RecordNum;			--成份股个数
	local TradingDay = etfListTable.TradingDay;			--交易日（一般是今日）
	local CashComponent = etfListTable.CashComponent;		--前日现金差额

	if CashComponent == "" or CashComponent == nil then
		CashComponent = 0;
	end

	local tETFInfo = {};
	tETFInfo.ID = ETFID;
	tETFInfo.ETFName = FundName;					--ETFName
	tETFInfo.Date = TradingDay;						--交易日（一般是今日）
	tETFInfo.EstimateCash = Estimatecashcomponent;	--预估现金部分
	tETFInfo.PreCash = CashComponent;				--前日现金差额
	tETFInfo.MaxCashRatio = MaxCashRatio;			--最大现金替代比例
	tETFInfo.IssueCount = RecordNum;				--成份股个数
	tETFInfo.Unit = CreationRedemptionUnit;			--最小申赎单位
	tETFInfo.PriceSet = {};
	tETFInfo.PriceCount = 0;
	tETFInfo.hasETFPrice = false;
	tETFInfo.NetValue = Estimatecashcomponent;	--净值
	tETFInfo.StockStop = 0;	--停牌数量
	tETFInfo.StockDrop = 0;	--跌停数量
	tETFInfo.StockRise = 0;	--涨停数量
	tETFInfo.ETFStatus = "3";	--状态
	tETFInfo.MarketValue = 0;	--市值
	tETFInfo.CashAmount = 0;	--现金替代之和
	tETFInfo.CashBuffer = 0;
	local tPriceInfo = _PosPriceTable[IssueCode];
	if tPriceInfo then
		local lastPrice = tPriceInfo.LastPrice;
		local aq1 = tPriceInfo.AskQuantity1;
		local aq2 = tPriceInfo.AskQuantity2;
		local aq3 = tPriceInfo.AskQuantity3;
		local aq4 = tPriceInfo.AskQuantity4;
		local aq5 = tPriceInfo.AskQuantity5;
		local bq1 = tPriceInfo.BidQuantity1;
		local bq2 = tPriceInfo.BidQuantity2;
		local bq3 = tPriceInfo.BidQuantity3;
		local bq4 = tPriceInfo.BidQuantity4;
		local bq5 = tPriceInfo.BidQuantity5;
		if lastPrice == "" or lastPrice == nil then
			lastPrice = 1
		end
		tETFInfo.MarketValue = tETFInfo.Unit * lastPrice;
		tETFInfo.ETFStatus = stateJudge(aq1,aq2,aq3,aq4,aq5,bq1,bq2,bq3,bq4,bq5);
		tETFInfo.hasETFPrice = true;
	end
	tETFInfo.Exist = true;	--若为true则当日ETF清单已经添加
	tETFInfo.Complete = false;	--若成份股信息完整，则稍后会变成true
	tETFInfo.TradeUnitQty = gTradeUnitQty;
	_ETFInfoTable[FundName] = tETFInfo;
	local marketCode = _PosIssueMarketTable[IssueCode];
	_RegisterPrice(_IssueCode = IssueCode, _MarketCode = marketCode);
	local logs = sys_format("OnQueryETFListTable:%s,FundName:%s,CreationRedemptionUnit:%s,Estimatecashcomponent:%s,MaxCashRatio:%s,RecordNum:%s,TradingDay:%s,CashComponent:%s",IssueCode,FundName,CreationRedemptionUnit,Estimatecashcomponent,MaxCashRatio,RecordNum,TradingDay,CashComponent)
	_WriteAplLog(logs);
	if FundName == gETFName then
		sendEtfInfoToClient(FundName,tETFInfo.TradeUnitQty);
	end
end

function LoadETFComponent()
	for k,v in pairs(_ETFID2NameTable) do
		if v == gETFName then	--已经存在ETF清单，才去获取成份股
			--读ETF成分股清单DD
			QueryETFComponent(k,POS_LOADETFDD_PID,POS_LOADETFDD_SID)

			if _ETFInfoTable[v].IssueCount ~= gETFCompCountTable[v].IssueCount then
				if v == gETFName then
                    local ETFID = _ETFInfoTable[v].ETFID
					local logs = sys_format("%s[%s]的成份股未导入完全，请稍候再按选择ETF按钮刷新",ETFID,v);
					sendLog(logs);
				end
				_ETFComponentTable[v] = nil;	--清空不完全的表
			else
				_ETFInfoTable[v].Complete = true;
				InitETFComponentTradeInfo()
			end
		end
	end
end
--------------------------------------------------------
--自定义函数部分结束
--------------------------------------------------------

--======================================================
--读取SHM委托成交开始
--======================================================
--成交一览
--修正一次委托两次成交问题,position库会去注册
--_RegisterExecution(gUserList);

_OnEventExecution("ETFExecution", {} , DTSMessageRecordAccess msg1)
	local DTSOrderDetailRecordAccess order = msg1.getOrderDetailRecord();
	local baMapID = order.getBAMapID();
	local IssueCode = order.getIssueCode();
	local CorpCode = order.getCorpCode();
	if (POS_LOGIN_CHECK_FUT_ISSUE ~= IssueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= IssueCode) then
		--自动追加 By wsy
		if msg1.getMessageType () == "L04" and not gAutoCancelTable[CorpCode] then
			local workingQuantity = order.getWorkingQuantity();
			if spBAMapID == baMapID and workingQuantity > 0 then --有可能响应有延迟或拒绝，所以确保挂盘后才开始自动撤单
				local OrderTime = order.getOrderTime();
				local forOrderTime = timetrans(OrderTime)
				gAutoCancelTable[CorpCode] = {}
				local BuySell = order.getBuySell();
				local OpenClose = order.getReserveInt1();
				gAutoCancelTable[CorpCode].OrderTime = forOrderTime
				gAutoCancelTable[CorpCode].IssueCode = IssueCode
				gAutoCancelTable[CorpCode].BuySell = BuySell
				gAutoCancelTable[CorpCode].OpenClose = OpenClose
				gAutoCancelTable[CorpCode].workingQuantity = workingQuantity
                gAutoCancelTable[CorpCode].AutoAmendFlag = false
			end
		end

		if spBAMapID == baMapID then
			local msgType = msg1.getMessageType();
			local logs = "";
			if(msgType == "L07" or msgType == "L18" or msgType == "L04" )then

				local BuySell = order.getBuySell();
				local Quantity = order.getOriginalQuantity();
				local Price = order.getOrderPrice();
				local ExecutionQuantity = msg1.getExecutionQuantity();
				local ExecutionValue = order.getExecutionValue();
				local WorkingQuantity = order.getWorkingQuantity();
				local OrderAcceptNo = order.getOrderAcceptNo();
				local CancelQuantity = order.getCancelQuantity();
				local UnAcceptedQuantity = order.getUnacceptedQuantity();
				local RejectedQuantity = order.getRejectedQuantity();
				local CorpCode = order.getCorpCode();

				local productCode = _PosIssueProductCodeTable[IssueCode];
				local priceExponent = _PosIssueExponentTable[IssueCode];
				local priceExponentabs = sys_abs(priceExponent);
				local orderInfo = {};
				orderInfo.IssueCode = IssueCode;
				orderInfo.Quantity = Quantity;
				orderInfo.WorkingQuantity = WorkingQuantity;
				orderInfo.CorpCode = CorpCode;
				orderInfo.CancelQuantity = CancelQuantity;
				orderInfo.UnAcceptedQuantity = UnAcceptedQuantity;
				orderInfo.RejectedQuantity = RejectedQuantity;
				orderInfo.ExecutionQuantity = ExecutionQuantity;
				local formatPriceExponent = sys_format("%%.%df", priceExponentabs);
				if WorkingQuantity == 0 then
					gAutoCancelTable[CorpCode] = nil--自动撤单 By zhuwei
				end
			end
		end
	end
_End

--this OnEventExecution only used for AmendOrder
_OnEventExecution("eventExecName2", {} , DTSMessageRecordAccess msg2)
	local DTSOrderDetailRecordAccess order = msg2.getOrderDetailRecord();
	local corp = order.getCorpCode();
	local issueCode = order.getIssueCode();
	local baMapID = order.getBAMapID();
	if (POS_LOGIN_CHECK_FUT_ISSUE ~= issueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= issueCode) then
		if spBAMapID == baMapID then
			if msg2.getMessageType () == "L08" then
				if getIssueCodePriceStatus(issueCode) == "SP" then
						local temlog = sys_format("%s今日停牌",issueCode);
						sendLog(temlog);
				elseif _AmendOrderTable[corp] then
					_AmendOrderTable[corp] = nil;
					local _String IssueCode = order.getIssueCode();
					local _String marketCode = order.getMarketCode();
					local _Int Quantity = order.getCancelQuantity();
					local _String BuySell = order.getBuySell();
					local buySell = "";
					if BuySell == "3" then	--转换买卖
						buySell = "B";
						local logs = "";
						local oldQuantity = Quantity;
						local newQuantity = sys_ceil(Quantity / 100.0) * 100;
						Quantity = newQuantity.toInt();
						logs = sys_format("%s撤单数量为%s，按%s重新下单",IssueCode,oldQuantity,Quantity);
						sendLog(logs);
						logs = sys_format("AmendOrder Quantity,old Quantity =%s,new Quantity=%s",oldQuantity,Quantity);
						--_WriteAplLog(logs);
					elseif BuySell == "1" then
						buySell = "S";
					else
						local temLog = sys_format("委托%s的买卖有误！",corp)
						sendLog(temLog);
					end
					local _String price = getOrderPrice(IssueCode,gAmendPrice,gAmendTick,BuySell, Quantity);	--获取改价价格
					local _String BaMapID = order.getBAMapID();
					local _String BaSubID = order.getBASubID();
					local _String ProductCode = order.getProductCode();
					local _String DealerID = order.getSenderID();
					local _String SenderID = order.getSenderID();
					local _String OwnerID = order.getOwnerID();
					local _String MarginFlag = order.getOrderMarginFlag();
					local _String GeneralString1 = order.getGeneralString1();
					local _String extDetailID_1 = order.getExtDetailID_1()
					local _Int reserveint1 = order.getReserveInt1();
					local OpenClose = order.getReserveInt1();
					local _Int genInt1 = order.getGeneralInt1();
					local _String resStr2 = order.getReserveString2();
					local _String BatchID = order.getTargetPrice()
					if(price == "MaketPrice")then -- later
					end

					local accountCode = _PosBAMapAccount[baMapID]
					local fundStatus = _PosFundStatus[accountCode]
					if fundStatus then
						--新下单接口方式,优化下单性能
						--DTSSubmitEvent

						--test log
						local submitLog = sys_format("撤单重下SubmitOrder: IssueCode[%s] Quantity[%s] Price[%s] BAMapID[%s] ReserveInt1[%s] BuySell[%s] BASubID[%s] ",
							IssueCode,Quantity,price,BaMapID,reserveint1,BuySell,BaSubID)
						_WriteAplLog(submitLog)
						--orderList.append(order1)
						--submitEvent.spliceArray("OrderList", orderList)
						MarketSubmitSingleBasket(IssueCode,BuySell,Quantity,price,OpenClose,false,BatchID)

						local logs = sys_format("%s撤单重下",IssueCode);
						sendLog(logs);
					else
						local tipLog = sys_format("POS:改价重下：无子账户[%s]对应的investorID",baMapID)
						_WriteAplLog(tipLog)
					end

				elseif 	_CancelOrderTable[corp] then
					_CancelOrderTable[corp] = nil
				elseif gAutoCancelTable[corp] then
--					if _HaveSubmitOrderFlag and gAutoCancelTime >= 5 then
                    if gAutoCancelTable[corp].AutoAmendFlag then
                        gAutoCancelTable[corp] = nil
						local DTSOrderDetailRecordAccess order = msg2.getOrderDetailRecord();
						local _String IssueCode = order.getIssueCode();
						local _String marketCode = order.getMarketCode();
						local _Int    Quantity = order.getCancelQuantity();
						local _String BuySell = order.getBuySell();
						local _String BaMapID = order.getBAMapID();
						local _String BaSubID = order.getBASubID();
						local _String ProductCode = order.getProductCode();
						local _String DealerID = order.getSenderID();
						local _String SenderID = order.getSenderID();
						local _String OwnerID = order.getOwnerID();
						local _String MarginFlag = order.getOrderMarginFlag();
						local _String GeneralString1 = order.getGeneralString1();
						local _Int reserveint1 = order.getReserveInt1();
						local OpenClose = order.getReserveInt1();
						local _String BatchID = order.getTargetPrice()

						local Basket = {}

						if BuySell == "3" then
							local Price = getOrderPrice(IssueCode,gBidQuote,gBuyTick,BuySell, Quantity);
							local sendlog = sys_format("[%s]自动追价价格: [%s] [%s]tick [%s]元",IssueCode,gBidQuote,gBuyTick,Price)
							sendLog(sendlog)
							_WriteCatchAplLog(sendlog)
							_WriteAplLog(sendlog)
							Quantity = sys_ceil(Quantity / 100.0) * 100;
							MarketSubmitSingleBasket(IssueCode,BuySell,Quantity,Price,OpenClose,false,BatchID)

						else
							local Price = getOrderPrice(IssueCode,gAskQuote,gSellTick, BuySell, Quantity);
							local sendlog = sys_format("[%s]自动追价价格: [%s] [%s]tick [%s]元",IssueCode,gAskQuote,gSellTick,Price)
							sendLog(sendlog)
							_WriteCatchAplLog(sendlog)
							_WriteAplLog(sendlog)
							MarketSubmitSingleBasket(IssueCode,BuySell,Quantity,Price,OpenClose,false,BatchID)

						end
					end
				end
			end
		end
	end
_End

_OnEventExecution("eventExecName", {} , DTSMessageRecordAccess msg)
	local DTSEvent exec = _CreateEventObject("ExecutEvent");
	local DTSOrderDetailRecordAccess order = msg.getOrderDetailRecord();
	local baMapID = order.getBAMapID();
	local IssueCode = order.getIssueCode();
	local msgType = msg.getMessageType();
	if (POS_LOGIN_CHECK_FUT_ISSUE ~= IssueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= IssueCode) then
		if spBAMapID == baMapID  then
			if msg.getMessageType () == "L07" or msg.getMessageType () == "L18"  then

				local IssueName = _PosIssueNameTable[IssueCode];
				local BuySell = order.getBuySell();
				local reserveint1 = order.getReserveInt1();
				local Quantity = msg.getExecutionQuantity();
				local orderQuantity = order.getExecutionQuantity();
				local ExecutionPrice = msg.getExecutionPrice();
				local ExecutionTime = msg.getExecutionTime();
				local ExecutionNo = msg.getExecutionNo();
				local gnInt1 =  order.getGeneralInt1();
				exec._SetFld("IssueCode",IssueCode);
				exec._SetFld("IssueName",IssueName);
				local BuySellFld = "未知";
				if BuySell == "3" then
					if(gnInt1 == 1)then
						BuySellFld = "申购";
					elseif(gnInt1 == 2)then
						BuySellFld = "赎回";
					else
						BuySellFld = "买";
					end
				else
					if(gnInt1 == 1)then
						BuySellFld = "申购";
					elseif(gnInt1 == 2)then
						BuySellFld = "赎回";
					else
						BuySellFld = "卖";
					end
				end
				local msgType = msg.getMessageType();

				exec._SetFld("Quantity",Quantity);
				exec._SetFld("ExecutionPrice",ExecutionPrice);
				exec._SetFld("ExecutionTime",ExecutionTime);
				exec._SetFld("ExecutionNo",ExecutionNo);

				local ordFare = {}
				ordFare.BS = order.getBuySell()
				ordFare.OpenClose = order.getReserveInt1()
				ordFare.CreRed = order.getGeneralInt1()
				ordFare.Price = order.getOrderPrice()
				ordFare.Quantity = order.getOriginalQuantity()
				ordFare.ExecQty = msg.getExecutionQuantity();
				ordFare.ExecValue = msg.getExecutionQuantity() * msg.getExecutionPrice()
				if msgType == "L18" and ordFare.CreRed == 0 then
					ordFare.IsInternal = 1
					if order.getReserveInt1()==0 then
						BuySellFld = "移入"
					else
						BuySellFld = "移出"
					end
				else
					ordFare.IsInternal = 0
				end
				exec._SetFld("BuySell",BuySellFld);

				--手续费
				local expense = PosFare(gAccountCode, IssueCode, ordFare)
				expense = sys_format("%.02f", expense)

				exec._SetFld("Expense",expense);
				local tFundStatus = _PosFundStatus[gAccountCode];

				if msg.getMessageType () == "L07" and (gnInt1 == 1 or gnInt1 == 2) then
					local resevStr = msg.getReserveString1();
					local temlog = sys_format("gnInt1:%s,ReserveString:%s",gnInt1,resevStr);
					--_WriteAplLog(temlog);
					local cashAmount = 0;	--现金替代
					if resevStr ~= "" and resevStr ~= nil then
						cashAmount = resevStr.getNumberValue();
					end
					local etfName = _ETFIssue2NameTable[IssueCode];
					--_WriteAplLog(etfName)
					local unit = 0;	--最小申述单位
					local estimateCash = 0;	--预估现金
					local theCash = 0;
					if etfName then
						if  _ETFInfoTable[etfName] then
							local tETFInfo = _ETFInfoTable[etfName]
							unit = tETFInfo.Unit;
							estimateCash = tETFInfo.EstimateCash;
							theCash = Quantity / unit * estimateCash;
							temlog = sys_format("theCash:%s",theCash);

							if gnInt1 == 1 then
								--Total-CreRedFund subtract This-CreRedFund
								--申购时，成交数量/申赎单位*每申赎单位的预估现金（从DTSETFListTable中读入的,可能为负数），从资金中减去
								--从申购的L07（注意，赎回不需要）中，取得替代金额后，减去该ETF所有必须现金替代的股票的替代金额的和
								--溢价金额=3的计算结果/(1+2的数字)*2的数字，取2位小数
								local totalCashAmount = tETFInfo.CashAmount;
								local cashBuffer = tETFInfo.CashBuffer
								premCashAmonut = (cashAmount - totalCashAmount) / (1 + cashBuffer) * cashBuffer;
								premCashAmonut = sys_format("%.2f",premCashAmonut);
								temlog = sys_format("PremCashAmount:%s,totalCashAmount:%s,CashBuffer:%s",premCashAmonut,totalCashAmount,cashBuffer)
							--Redemption
							elseif gnInt1 == 2 then
								--Total-CreRedFund add This-CreRedFund
								--赎回时，成交数量/申赎单位*每申赎单位的预估现金（从DTSETFListTable中读入的,可能为负数），加入到资金中
							end
						end
					end
				end
				_SendToClients(exec)
			end
			if msg.getMessageType () == "L04"  then
				local errorType =  msg.getErrorType();
				--local accceptCode = msg.getAccceptCode();
				local returnCode = msg.getReturnCode();
				if errorType ~="0" then
					_WriteLogToClient("下单被市场拒绝");
					--_WriteLogToClient("AccceptCode:%s",accceptCode);
					_WriteLogToClient("ReturnCode:%s",returnCode);
					_WriteAplLog("下单被市场拒绝")
				end
			end
		end
	end
_End

_OnEventExecution("eventExecName1", {} , DTSMessageRecordAccess msg1)
	local DTSEvent ord = _CreateEventObject("OrderEvent")
	local DTSOrderDetailRecordAccess order = msg1.getOrderDetailRecord();
	local baMapID = order.getBAMapID();
	local msgType = msg1.getMessageType()
	local IssueCode = order.getIssueCode();
	if (POS_LOGIN_CHECK_FUT_ISSUE ~= IssueCode and POS_LOGIN_CHECK_STOCK_ISSUE ~= IssueCode) then
		if spBAMapID == baMapID then
			local IssueName = _PosIssueNameTable[IssueCode];
			local BuySell = order.getBuySell();
			--local OpenClose = order.getReserveInt1();
			local Quantity = order.getOriginalQuantity();
			local Price = order.getOrderPrice();
			local ExecutionQuantity = order.getExecutionQuantity();
			local ExecutionValue = order.getExecutionValue();
			local WorkingQuantity = order.getWorkingQuantity();
			local OrderAcceptNo = order.getOrderAcceptNo();
			local OrderTime = order.getOrderTime();
			local CancelQuantity = order.getCancelQuantity();
			local UnAcceptedQuantity = order.getUnacceptedQuantity();
			local RejectedQuantity = order.getRejectedQuantity();
			local CorpCode = order.getCorpCode();
			local BatchID = order.getTargetPrice()
			local ExecValue = order.getExecutionValue()
			local MarketCode = order.getMarketCode()

			local testSHMMLog = sys_format("eventExecName1: issue[%s] CorpCode[%s] BatchID[%s]",order.getIssueCode(),order.getCorpCode(),order.getTargetPrice())
			_WriteAplLog(testSHMMLog)
			if BuySell == "3" then
				if BatchID and BatchID ~= "" then
					if BatchID.toInt() > gBuyETFCompCount then
						gBuyETFCompCount = BatchID.toInt()
					end
				end
			elseif BuySell == "1" then
				if BatchID and BatchID ~= "" then
					if BatchID.toInt() > gSellETFCompCount then
						gSellETFCompCount = BatchID.toInt()
					end
				end
			end

			local gnInt1 =  order.getGeneralInt1();
			ord._SetFld("IssueCode",IssueCode);
			ord._SetFld("IssueName",IssueName);
			if BuySell == "3" then
				if(gnInt1 == 1)then
					ord._SetFld("BuySell","申购");
				elseif(gnInt1 == 2)then
					ord._SetFld("BuySell","赎回");
				else
					ord._SetFld("BuySell","买");
				end
			else
				if(gnInt1 == 1)then
					ord._SetFld("BuySell","申购");
				elseif(gnInt1 == 2)then
					ord._SetFld("BuySell","赎回");
				else
					ord._SetFld("BuySell","卖");
				end
			end

			local priceExponent = _PosIssueExponentTable[IssueCode];
			local priceExponentabs = sys_abs(priceExponent);
			local formatPriceExponent = sys_format("%%.%df", priceExponentabs);

			if ExecutionValue ~="" then
				local ftExValue = sys_format(formatPriceExponent,ExecutionValue);
				ord._SetFld("ExecutionValue",ftExValue);
			else
				ord._SetFld("ExecutionValue",ExecutionValue);
			end
			ord._SetFld("Quantity",Quantity);
			ord._SetFld("Price",Price);
			ord._SetFld("ExecutionQuantity",ExecutionQuantity)
			ord._SetFld("WorkingQuantity",WorkingQuantity);
			ord._SetFld("CorpCode",CorpCode);
			local orderInfo = {}
			orderInfo.IssueCode = order.getIssueCode();
			orderInfo.IssueName = _PosIssueNameTable[IssueCode];
			orderInfo.BuySell = order.getBuySell();
			--orderInfo.OpenClose = order.getReserveInt1();
			orderInfo.Quantity = order.getOriginalQuantity();
			orderInfo.Price = order.getOrderPrice();
			orderInfo.ExecutionQuantity = order.getExecutionQuantity();
			orderInfo.ExecutionValue = order.getExecutionValue();
			orderInfo.WorkingQuantity = order.getWorkingQuantity();
			orderInfo.OrderAcceptNo = order.getOrderAcceptNo();
			orderInfo.OrderTime = order.getOrderTime();
			orderInfo.CancelQuantity = order.getCancelQuantity();
			orderInfo.UnAcceptedQuantity = order.getUnacceptedQuantity();
			orderInfo.RejectedQuantity = order.getRejectedQuantity();
			orderInfo.CorpCode = order.getCorpCode();
			updateCanBeCancelTable(orderInfo)

			if gCurrentOrderTable[CorpCode] == nil then
				gCurrentOrderTable[CorpCode] = {}
				gCurrentOrderTable[CorpCode].IssueCode = IssueCode
				gCurrentOrderTable[CorpCode].IsChecked = "0"
			end

			local StatusName = getOrderStatusName(Quantity, ExecutionQuantity, WorkingQuantity, CancelQuantity, RejectedQuantity, UnAcceptedQuantity)
			local StatusFlag = getOrderStatusFlag(StatusName)
			--深圳跨市ETF和跨境ETF申赎单只要下单到柜台,没有被拒绝和返回错误,L04回来就把单子状态改为“全部成交”
			if StatusName == "挂单" then
				local etfType
				if _PosETFInfoTable[IssueCode] then
					etfType = _PosETFInfoTable[IssueCode].Type
				end
				if (MarketCode == "2" and etfType == POS_ETF_MULTIMARKET) or etfType == POS_ETF_MULTIAREA then
					if gnInt1 == 1 or gnInt1 == 2 then --修正只有申赎的时候深圳跨市及跨境ETF正常挂单后委托状态为全部成交
						StatusName = "全部成交"
					end
				end
			end
			local IsChecked = gCurrentOrderTable[CorpCode].IsChecked
			ord._SetFld("Status", StatusName)
			ord._SetFld("StatusFlag", StatusFlag)
			ord._SetFld("IsChecked", IsChecked)
			if StatusFlag == "1" then
				gCurrentOrderTable[CorpCode] = nil
				if StatusName == "拒绝" and msgType == "L04" then
					local reason = order.getReserveString2()
					local temLog = sys_format("%s下单被拒绝，原因:%s",IssueCode,reason)
					sendLog(temLog)
				end
			end

			if OrderTime~="" then
				local tmpordtimeH = sys_sub(OrderTime,1,2);
				local tmpordtimeM = sys_sub(OrderTime,3,4);
				local tmpordtimeS = sys_sub(OrderTime,5,6);
				local tmpordtimeHM =sys_sub(OrderTime,7,9);
				local tmpodrtime = tmpordtimeH..":"..tmpordtimeM..":"..tmpordtimeS.."."..tmpordtimeHM
				ord._SetFld("OrderTime",tmpodrtime);
			else
				ord._SetFld("OrderTime",OrderTime);
			end
			ord._SetFld("OrderAcceptNo",OrderAcceptNo)

			local ordFare = {}
			ordFare.BS = order.getBuySell()
			ordFare.OpenClose = order.getReserveInt1()
			ordFare.CreRed = order.getGeneralInt1()
			ordFare.Price = order.getOrderPrice()
			ordFare.Quantity = order.getOriginalQuantity()
			ordFare.ExecQty = order.getExecutionQuantity()
			ordFare.ExecValue = order.getExecutionValue()
			if msgType == "L18" and ordFare.CreRed == 0 then
				ordFare.IsInternal = 1
				local log = sys_format("order.getReserveInt1()=%s,msg1.getGeneralString2()=%s",order.getReserveInt1(),msg1.getGeneralString2())
				--_WriteAplLog(log)
				if order.getReserveInt1()==0 then
					ord._SetFld("BuySell","移入");
				else
					ord._SetFld("BuySell","移出");
				end
			else
				ordFare.IsInternal = 0
			end

			--手续费
			local expense = PosFare(gAccountCode, IssueCode, ordFare)
			--存储需要计算综合成本的买入成份股记录
			if BuySell == "3" then
				SaveBuyETFCompOrderInfo(IssueCode, CorpCode, Price, Quantity, WorkingQuantity, ExecutionQuantity, RejectedQuantity, CancelQuantity, UnAcceptedQuantity, ExecValue, expense, BatchID)
			else
				SaveSellETFCompOrderInfo(IssueCode, CorpCode, Price, Quantity, WorkingQuantity, ExecutionQuantity, RejectedQuantity, CancelQuantity, UnAcceptedQuantity, ExecValue, expense, BatchID)
			end

			local sEexpense = sys_format("%.02f", expense)
			ord._SetFld("Expense",sEexpense);
			_SendToClients(ord);

			--计算成交成分股的综合成本  by jun 20120316
			if msgType == "L07" then
				if not gtExpenseTable[CorpCode] then
					gtExpenseTable[CorpCode] = expense
				else
					local lastExpense = gtExpenseTable[CorpCode]
					expense = expense - lastExpense
				end
				local tmpBatchID;
				if BatchID and BatchID ~= "" then
					tmpBatchID = BatchID.toInt();
				end
				local execPrice = msg1.getExecutionPrice()
				local execQty = msg1.getExecutionQuantity()
				ExecValue = execPrice * execQty
				local logs = sys_format("计算ExecValue BatchID=%s,IssueCode=%s,ExecutionPrice=%s,ExecutionQuantity=%s,ExecValue=%s",tmpBatchID,IssueCode,execPrice,execQty,ExecValue)
				--_WriteAplLog(logs)
				if _PosStatus == POS_STATUS_NORMAL  then
					local exec = {}
					exec.IssueCode = IssueCode
					exec.ExecutionQuantity = execQty
					exec.ExecutionPrice = execPrice
					exec.Price = Price
					exec.BuySell = BuySell
					exec.expense = expense
					exec.CorpCode = CorpCode
					exec.ExecValue = ExecValue
					exec.BatchID = BatchID
					exec.CreRed = order.getGeneralInt1()
					OnExecVirtualTaskInfoUpdate(exec)
				end
			end

		end
    end
_End
--------------------------------------------------------
--读取SHM委托成交结束
--------------------------------------------------------


--======================================================
--行情回调部分结束
--======================================================
_OnEventPrice(_PriceName="ETFTrade", {} , DTSPrice price);
	local issueCode = price.getIssueCode();
	local seqNo = price.getSeqNo();
	local tIssuePriceInfo = {};
	--获取10档行情
	tIssuePriceInfo.IssueCode = issueCode;
	tIssuePriceInfo.LastPrice = priceToNumber(price.getEstLastPrice());
	tIssuePriceInfo.AskPrice1 = priceToNumber(price.getAskPrice_1());
	tIssuePriceInfo.AskQuantity1 = quantityToNumber(price.getAskQty_1());
	tIssuePriceInfo.AskPrice2 = priceToNumber(price.getAskPrice_2());
	tIssuePriceInfo.AskQuantity2 = quantityToNumber(price.getAskQty_2());
	tIssuePriceInfo.AskPrice3 = priceToNumber(price.getAskPrice_3());
	tIssuePriceInfo.AskQuantity3 = quantityToNumber(price.getAskQty_3());
	tIssuePriceInfo.AskPrice4 = priceToNumber(price.getAskPrice_4());
	tIssuePriceInfo.AskQuantity4 = quantityToNumber(price.getAskQty_4());
	tIssuePriceInfo.AskPrice5 = priceToNumber(price.getAskPrice_5());
	tIssuePriceInfo.AskQuantity5 = quantityToNumber(price.getAskQty_5());
	tIssuePriceInfo.BidPrice1 = priceToNumber(price.getBidPrice_1());
	tIssuePriceInfo.BidQuantity1 = quantityToNumber(price.getBidQty_1());
	tIssuePriceInfo.BidPrice2 = priceToNumber(price.getBidPrice_2());
	tIssuePriceInfo.BidQuantity2 = quantityToNumber(price.getBidQty_2());
	tIssuePriceInfo.BidPrice3 = priceToNumber(price.getBidPrice_3());
	tIssuePriceInfo.BidQuantity3 = quantityToNumber(price.getBidQty_3());
	tIssuePriceInfo.BidPrice4 = priceToNumber(price.getBidPrice_4());
	tIssuePriceInfo.BidQuantity4 = quantityToNumber(price.getBidQty_4());
	tIssuePriceInfo.BidPrice5 = priceToNumber(price.getBidPrice_5());
	tIssuePriceInfo.BidQuantity5 = quantityToNumber(price.getBidQty_5());
	tIssuePriceInfo.Volume = quantityToNumber(price.getVolume());
	tIssuePriceInfo.AdjustedLNC = priceToNumber(price.getAdjustedLNC());
	tIssuePriceInfo.PriceExponent = 0-_PosIssueExponentTable[issueCode];
	tIssuePriceInfo.UpLimitPrice = priceToNumber(price.getUpperLimitPrice());
	tIssuePriceInfo.LowLimitPrice = priceToNumber(price.getLowerLimitPrice());
	tIssuePriceInfo.VWAPEVEPrice = priceToNumber(price.getVWAPEVEPrice());--IOPV
	_PosPriceTable[issueCode] = tIssuePriceInfo;

	--刷新可买可卖
    MarketsendFundReply(issueCode)

	--if _ETFComponentTable[gETFName][issueCode] then
		updateETFStatus(issueCode);
	--end
	if gtETFComponentTradeInfo[issueCode] then
		sendEtfInfoToClient(gETFName,gTradeUnitQty);	--ETFBaseInfo事件刷新

        local bidQuote = gtETFComponentTradeInfo[issueCode].SelectBidQuote
		local BidPriceQty = getQuotePriceAndQty(issueCode,bidQuote,0)

        local askQuote = gtETFComponentTradeInfo[issueCode].SelectAskQuote
		local AskPriceQty = getQuotePriceAndQty(issueCode,askQuote,1)

		gtETFComponentTradeInfo[issueCode].BidPrice = BidPriceQty.Price
		gtETFComponentTradeInfo[issueCode].BidQuantity = BidPriceQty.Quantity
		gtETFComponentTradeInfo[issueCode].AskPrice = AskPriceQty.Price
		gtETFComponentTradeInfo[issueCode].AskQuantity = AskPriceQty.Quantity
		sendCashRepltoClient(gETFName,issueCode)
	end

--	IssuePriceUpdateVirtualTaskInfo(issueCode)
_End

--------------------------------------------------------
--行情回调部分结束
--------------------------------------------------------
--------------------------------------------------------------------------
-----------------------更改后的资金持仓显示-------------------------------
--------------------------------------------------------------------------
function ShowQryAvlFund()

	local DTSEvent fundStatus=_CreateEventObject("AvlibFundStatusEvent");
	local availableFund = 0;
	if _PosFundStatus[gAccountCode] ~= nil then
		availableFund = sys_format("%.2f",gtInvestorFundStatus[spBAMapID].AvlFund);
	end
	fundStatus._SetFld("AvailableFund",availableFund);
	fundStatus._SetFld("Key",1);
	local logs = sys_format("ShowQryAvlFund-AvailableFund:%s",availableFund);
	--_WriteAplLog(logs);
	_SendToClients(fundStatus);

    if gMQTradeIssueCode ~= "" then
        MarketsendFundReply(gMQTradeIssueCode)
    end
end


function ShowQryPosition()
	for issueCode, pos in pairs(gtInvestorPositionInfo) do
        InvestorIssuePositionChange(issueCode)
	end
end

--持仓表更新
function ShowSingleQryPosition(issueCode)
	local log = sys_format("ShowSingleQryPosition issueCode = %s ",issueCode)
	--_WriteAplLog(log)

    local Quantity = 0
    local AvlQuantity = 0
    local AvlCreRedQuantity = 0
	local issueName = _PosIssueNameTable[issueCode]
	local displayBS = "买"
	local workingQuantity = 0
	local ValuationPL = 0
	local posBS = "3"

	local pos = gtInvestorPositionInfo[issueCode]
	if pos then
        Quantity = pos.Quantity
        AvlQuantity = pos.AvlQuantity
        AvlCreRedQuantity = pos.AvlCreRedQuantity
	end

	local DTSEvent posEvent = _CreateEventObject("Position")
	posEvent._SetFld("IssueCode",issueCode)
	posEvent._SetFld("IssueName",issueName)
	posEvent._SetFld("BASubID",displayBS)
	posEvent._SetFld("Quantity",Quantity)
	posEvent._SetFld("AvailableQty",AvlQuantity)
	posEvent._SetFld("_workingQuantity",workingQuantity) --未成交数量
	posEvent._SetFld("AvailableCreRedempQty",AvlCreRedQuantity)
	posEvent._SetFld("PL",ValuationPL)
	posEvent._SetFld("BS",posBS)
	_SendToClients(posEvent)

end
---------------------------------------------------------------------------------------------------------------------------------------------
---右键下单
_OnEventDefined(OrderPost st)
	local issueCode = st._GetFld("IssueCode")
	local askQuote = st._GetFld("AskQuote")
	local sellTick = st._GetFld("SellTick")
	local logs = sys_format("OrderPost IssueCode=%s,AskQuote=%s,SellTick=%s",issueCode,askQuote,sellTick)
	_WriteAplLog(logs)

	local _String str1 = issueCode.toString()
	local str = str1.."\r\n"
	local len = sys_len(str)
	local issueCodeTable = {}
	local a = 1
	for i=1,len do
		local chr = sys_sub(str,i,i+1)
		if chr == "\r\n" then
			local issue = sys_sub(str,i-6,i-1)
			issueCodeTable[a] = issue
			a = a + 1
		end
	end

	local Basket = {}
	local OrderSeq = 0
	for a,issuecode in pairs(issueCodeTable) do
		local quantity=0
		if spInvestorMode == 1 then
			if gtInvestorPositionInfo[issuecode] ~= nil then
				if gtInvestorPositionInfo[issuecode].AvlQuantity ~= nil then
					quantity = gtInvestorPositionInfo[issuecode].AvlQuantity
				end
			end
		end
		if quantity > 0 then
			local buysell =  "1"
			local quote = askQuote
			local tick = sellTick
			local orderPrice = getOrderPrice(issuecode,quote,tick,buysell,quantity)
			local priceCondition = ""
			local issueCodePirceStatus = getIssueCodePriceStatus(issueCode)
			if issueCodePirceStatus ~= "SP" then
				local OrderInfo = {}
				OrderInfo.IssueCode = issuecode
				OrderInfo.Quantity = quantity
				OrderInfo.Price = orderPrice
				OrderInfo.BuySell = buysell
				OrderInfo.OpenClose = "1"
				OrderInfo.PriceCondition = priceCondition
				OrderInfo.IsRedemption = false
				if quantity > _MaxOrderSumitQty then--拆单
					MarketSplitQuantity(issuecode,quantity,orderPrice,buysell)
				else
					sys_insert(Basket,OrderInfo)
				end
			end
		end
	end
	sendLog("批量下单执行...")
	MarketSubmitBasketOrder(Basket)
_End
