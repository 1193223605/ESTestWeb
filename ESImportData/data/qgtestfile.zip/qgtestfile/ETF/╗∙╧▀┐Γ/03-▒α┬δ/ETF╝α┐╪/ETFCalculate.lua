﻿--@@Version:1.00.100.20131212@@
--算法代码
Initialization()

function Initialization()
	_WriteAplLog("NewManualTrade Initialization")
	_WriteAplLog("系统初始化开始...")
	--*******初始化Position全局变量*******
	PosInitialize()
	PosAddBAMapID(spStockBAMapID)
	_PosRecoverFund()
	initialSelectTable()
	Init()
end


--全局变量初始化
function Init()
	--全局变量和表初始化
	gTradeUnitQty = 1
	gPriceInFlag = false
	gtMarketValueTable = {}			--盘口市值表
	--gtPremETFMarketValueTable = {}		--ETF溢价盘口市值		key:ETFIssueCode,value:ETF溢价盘口市值
	--gtDiscETFMarketValueTable = {}		--ETF折价盘口市值		key:ETFIssueCode,value:ETF折价盘口市值
	--gtPremComponentMarketValueTable = {} 	--成分股溢价盘口市值    key:ETFIssueCode,value:成分股溢价盘口市值
	--gtDiscComponentMarketValueTable = {}	--成分股折价盘口市值	key:ETFIssueCode,value:成分股折价盘口市值
	gtETFFareTable = {}			--ETF套利费用表			key:etfname,value:BuyCompFare,CreFare,SellETFFare,BuyETFFare,RedFare,SellCompFare
	gtLastPriceQuote = {}		--上一次的盘口价格  key:etfname,key2:issuecode,value:溢价price,折价price
	--盘口价种类：LastPrice,AskPrice1,AskPrice2,AskPrice3,AskPrice4,AskPrice5,BidPrice1,BidPrice2,BidPrice3,BidPrice4,BidPrice5,UpLimitPrice,LowLimitPrice

    --ETF溢价盘口价格  默认自动盘口
	gETFPremiumPriceType = "AutoPrice"
	--ETF折价盘口价格  默认自动盘口
	gETFDiscountPriceType = "AutoPrice"
	--股票溢价盘口价格  默认自动盘口
	gComponentPremiumPriceType = "AutoPrice"
	--股票折价盘口价格  默认自动盘口
	gComponentDiscountPriceType = "AutoPrice"

	gaccountCode = _PosBAMapAccount[spStockBAMapID]
	local log = sys_format("gaccountCode:%s",gaccountCode)
	_WriteAplLog(log)
	--股票置信度
	gStockConfidence = 1
	--ETF置信度
	gETFConfidence = 1
	--全局表定义
    gtIssueFareTable = {}       --合约买卖保存的费用
	--读取ETF成份股
	gETFCompCountTable = {};	--用来存放ETF相关信息,以ETFName为key
	gtStockStatusTable = {}
	_IssueETFTable = {};	--set issuecode and ETFname as co-key
	_CompIssuePriceCount = {};	--key:etfname value:已有的行情数量

	--常量定义
	DTSDate nowDate = _GetNowDate();	--取当前时间
	_String strDate = nowDate.asString("%Y%m%d");	--时间格式化

	--暂且清单数据都来自于数据库
	POS_LOADETFDD_PID = ""
	POS_LOADETFDD_SID = ""

	ETFQueryStart(POS_LOADETFDD_PID,POS_LOADETFDD_SID)
	for ETFID,ETFName in pairs(_ETFID2NameTable) do
		--读ETF清单和ETF成分股清单
		local initlog = sys_format("ETF:Initilize ETFName[%s]POS_LOADETFDD_PID[%s]POS_LOADETFDD_SID[%s]",ETFName,POS_LOADETFDD_PID,POS_LOADETFDD_SID)
		_WriteAplLog(initlog)
		QueryETFList(ETFName,POS_LOADETFDD_PID,POS_LOADETFDD_SID)
		QueryETFComponent(ETFID,POS_LOADETFDD_PID,POS_LOADETFDD_SID)
	end

	--_WriteAplLog(gETFList)
	--发送所有ETF清单到界面
	outputETFList()

	--读DD,读取上次设置的盘口价格名称
	local DTSEvent marketPriceType = _CreateEventObject("MarketPriceTypeEvent")
	DTSDynamicData marketPriceTypeStore = _CreateDynamicData(TSInstanceName = "MarketPriceTypeDD", fileType = _DataOtherType,MarketPriceTypeEvent marketPriceType)
	marketPriceTypeStore._GetDynamicData("GetMarketPriceType",condition="")
	outPutMarketPriceTypeEvent()

    --导入历史监控ETF
    LoadSaveETF()

    --全部初始化以后调用
	_StartTimer(_TimerName="RefreshETFInfo",_Interval= 3000)
end


--QueryETFList回调函数
function OnQueryETFListTable(etfListTable)
	local IssueCode = etfListTable.IssueCode;
	local etfName = etfListTable.FundName;
    gtMarketValueTable[etfName] = {}
    gtMarketValueTable[etfName].MustCashComponent = etfListTable.EstimateCashComponent

    ResetCalInfo(etfName)
end

--重置计算信息
function ResetCalInfo(etfName)
    --净值计算
    gtMarketValueTable[etfName] = gtMarketValueTable[etfName] or {}
    gtMarketValueTable[etfName].PremComponentMarketValue = 0            --溢价盘口净值
    gtMarketValueTable[etfName].DiscComponentMarketValue = 0             --折价盘口净值
    gtMarketValueTable[etfName].ComponentMarketValue = 0                  --成交价净值
    gtMarketValueTable[etfName].PremETFMarketValue = 0                      --溢价盘口ETF市值
    gtMarketValueTable[etfName].DiscETFMarketValue = 0                       --折价盘口ETF市值

    --费用计算
    gtETFFareTable[etfName] = {}
    gtETFFareTable[etfName].BuyCompFare = 0
    gtETFFareTable[etfName].SellCompFare = 0
    gtETFFareTable[etfName].BuyETFFare = 0
    gtETFFareTable[etfName].SellETFFare = 0
    gtETFFareTable[etfName].RedFare = 0
    gtETFFareTable[etfName].CreFare = 0

    gtIssueFareTable = {}

    _CompIssuePriceCount[etfName] = {}
	_CompIssuePriceCount[etfName].PriceCount = 0
	gtLastPriceQuote[etfName] = nil

end

--QueryETFComponent回调函数
function OnQueryETFComponentTable(etfComponentTable)
	local ETFID = etfComponentTable.ETFID
	local etfName = _ETFID2NameTable[ETFID];
	local CanCashRepl = etfComponentTable.CanCashRepl

	if CanCashRepl == "2" or CanCashRepl == "4" then
		gtMarketValueTable[etfName].MustCashComponent = gtMarketValueTable[etfName].MustCashComponent + etfComponentTable.CashAmount
	end

end


--计算成分股折价溢价市值以及买卖成分股的费用
function CalcComponentMarketValueAndFare(etfName,issueCode)
	local log = sys_format("In GetComponentMarketValue,etfName:%s,issueCode:%s",etfName,issueCode)
--	_WriteAplLog(log)
	if not _ETFComponentTable[etfName] then
		_WriteAplLog("ETF成分股清单未导入，请稍后启动策略")
		return
	end
	--在原先基础上加算
	local CanCashRepl = _ETFComponentTable[etfName][issueCode].CanCashRepl
	if CanCashRepl == "0" or CanCashRepl== "1" or CanCashRepl== "3" then
		--计算净值变化
		local OldComponentPremiumPrice = 0 	--上次计算时候用的溢价盘口价
		local OldComponentDiscountPrice = 0	--上次计算时候用的折价盘口价
		local OldComponentPrice = 0 --上次计算时用的最新价
		if gtLastPriceQuote[etfName] then
			if gtLastPriceQuote[etfName][issueCode] then
				OldComponentPremiumPrice = gtLastPriceQuote[etfName][issueCode].ComponentPremiumPrice
				OldComponentDiscountPrice = gtLastPriceQuote[etfName][issueCode].ComponentDiscountPrice
				OldComponentPrice = gtLastPriceQuote[etfName][issueCode].ComponentPrice
			else
				gtLastPriceQuote[etfName][issueCode] = {}
			end
		else
			gtLastPriceQuote[etfName] = {}
			gtLastPriceQuote[etfName][issueCode] = {}
		end
		local ComponentPremiumPrice = 0
		local ComponentDiscountPrice = 0
		local ComponentPrice = 0
		local adjustedLNC = 0	 		 	--股票除权除息昨收价
		local lastPrice = 0
		local priceInfo = _PosPriceTable[issueCode]
		if priceInfo then
			adjustedLNC = priceInfo.AdjustedLNC or 0
			lastPrice = priceInfo.LastPrice or 0
		end
		local Quantity =  _ETFComponentTable[etfName][issueCode].Quantity


		local issueStatus = getIssueCodePriceStatus(issueCode)
		if issueStatus == "SP" then
			ComponentPremiumPrice = adjustedLNC
			ComponentDiscountPrice = adjustedLNC
			ComponentPrice = adjustedLNC
		else
			ComponentPremiumPrice = getOrderPrice(issueCode,gComponentPremiumPriceType,0,"3",Quantity)
			ComponentDiscountPrice = getOrderPrice(issueCode,gComponentDiscountPriceType,0,"1",Quantity)
			ComponentPrice = lastPrice
		end
		gtLastPriceQuote[etfName][issueCode].ComponentPremiumPrice = ComponentPremiumPrice
		gtLastPriceQuote[etfName][issueCode].ComponentDiscountPrice = ComponentDiscountPrice
		gtLastPriceQuote[etfName][issueCode].ComponentPrice = ComponentPrice

		gtMarketValueTable[etfName].PremComponentMarketValue = gtMarketValueTable[etfName].PremComponentMarketValue + (ComponentPremiumPrice - OldComponentPremiumPrice)*Quantity
		gtMarketValueTable[etfName].DiscComponentMarketValue = gtMarketValueTable[etfName].DiscComponentMarketValue + (ComponentDiscountPrice - OldComponentDiscountPrice)*Quantity
		gtMarketValueTable[etfName].ComponentMarketValue = gtMarketValueTable[etfName].ComponentMarketValue + (ComponentPrice - OldComponentPrice)*Quantity


		if issueStatus ~= "SP" then
			--未停牌股票计算费用变化
			local premorder = {}
			local discorder = {}
			local etfIssueCode = _ETFName2IssueTable[etfName]
			--溢价买成分股
			premorder.Quantity = Quantity
			premorder.Price = ComponentPremiumPrice
			premorder.BS = "3"
			premorder.OpenClose = 0
			premorder.CreRed = 0
			local BuyFare = MyPosEstimateFare(gaccountCode, issueCode, premorder)

			--折价卖成分股
			discorder.Quantity = Quantity
			discorder.Price = ComponentDiscountPrice
			discorder.BS = "1"
			discorder.OpenClose = 1
			discorder.CreRed = 0
			local SellFare = MyPosEstimateFare(gaccountCode, issueCode, discorder)

            if gtIssueFareTable[issueCode] == nil then
                gtIssueFareTable[issueCode] = {}
            end
            if gtIssueFareTable[issueCode][etfName] == nil then
                gtIssueFareTable[issueCode][etfName] = {}
                gtIssueFareTable[issueCode][etfName].BuyFare = 0
                gtIssueFareTable[issueCode][etfName].SellFare = 0
            end
			local oldBuyFare = gtIssueFareTable[issueCode][etfName].BuyFare
			local oldSellFare = gtIssueFareTable[issueCode][etfName].SellFare
            gtIssueFareTable[issueCode][etfName].BuyFare = BuyFare
            gtIssueFareTable[issueCode][etfName].SellFare = SellFare

			gtETFFareTable[etfName].BuyCompFare = gtETFFareTable[etfName].BuyCompFare + BuyFare -oldBuyFare
			gtETFFareTable[etfName].SellCompFare = gtETFFareTable[etfName].SellCompFare + SellFare - oldSellFare
		end
	end
end


--计算ETF折价溢价市值以及买卖ETF的费用
function CalcETFMarketValueAndFare(etfName)
	local log = sys_format("In CalcETFMarketValue,etfName:%s",etfName)
	if not _ETFInfoTable[etfName] then
		_WriteAplLog("ETF清单未导入，请稍后启动策略")
		return
	end
	--_WriteAplLog(log)
	local premETFMarketValue = 0			--ETF溢价市值
	local discETFMarketValue = 0			--ETF折价市值
	local Unit = _ETFInfoTable[etfName].CreationRedemptionUnit	--申赎单位
	local etfIssueCode = _ETFName2IssueTable[etfName]
	local ETFPriceInfo = _PosPriceTable[etfIssueCode]
	local etfPremiumPrice = 0                      --ETF溢价盘口价
	local etfDiscountPrice = 0                     --ETF折价盘口价
	local AdjustedLNC = 0
	if ETFPriceInfo then
		AdjustedLNC = ETFPriceInfo.AdjustedLNC or 0
	end

	local ETFissueStatus = getIssueCodePriceStatus(etfIssueCode)
	if ETFissueStatus == "SP" then
		etfPremiumPrice = AdjustedLNC
		etfDiscountPrice = AdjustedLNC
	else
		etfPremiumPrice =  getOrderPrice(etfIssueCode,gETFPremiumPriceType,0,"1",Unit)
		etfDiscountPrice = getOrderPrice(etfIssueCode,gETFDiscountPriceType,0,"3",Unit)
	end
	etfPremiumAmount = etfPremiumPrice*Unit
	etfDiscountAmount = etfDiscountPrice*Unit
	log = sys_format("etfPremiumAmount:%f,etfDiscountAmount:%f",etfPremiumAmount,etfDiscountAmount)
	--_WriteAplLog(log)

	gtMarketValueTable[etfName].PremETFMarketValue = etfPremiumAmount
	gtMarketValueTable[etfName].DiscETFMarketValue = etfDiscountAmount

	if ETFissueStatus ~= "SP" then
		--未停牌ETF计算费用
		local premorder = {}
		local discorder = {}

		--溢价卖ETF
		premorder.Quantity = Unit
		premorder.Price = etfPremiumPrice
		premorder.BS = "1"
		premorder.OpenClose = 1
		premorder.CreRed = 0
		local SellETFFare = MyPosEstimateFare(gaccountCode, etfIssueCode, premorder)
		gtETFFareTable[etfName].SellETFFare = SellETFFare

		--折价买ETF
		discorder.Quantity = Unit
		discorder.Price = etfDiscountPrice
		discorder.BS = "3"
		discorder.OpenClose = 0
		discorder.CreRed = 0
		local BuyETFFare = MyPosEstimateFare(gaccountCode, etfIssueCode, discorder)
		gtETFFareTable[etfName].BuyETFFare = BuyETFFare

		if not gtETFFareTable[etfName].CreFare then
			--申购
			local fare = _PosGetFare(gaccountCode, etfIssueCode)
			gtETFFareTable[etfName].CreFare = Unit * fare.CreFare
		end

		if not gtETFFareTable[etfName].RedFare then
			--赎回
			local fare = _PosGetFare(gaccountCode, etfIssueCode)
			gtETFFareTable[etfName].RedFare = Unit * fare.RedFare
		end
	end
end


--Position行情回调
function OnPrice(issueCode, priceInfo)
	if _IssueETFTable[issueCode] == nil and _ETFIssue2NameTable[issueCode] == nil then
		return
	end

	gPriceInFlag = true
	if _ETFIssue2NameTable[issueCode] then
		--如果ETF
		if gSelectETFListTable[issueCode] then
			local etfName = _ETFIssue2NameTable[issueCode]
			CalcETFMarketValueAndFare(etfName)
		end
	else
		--来的是成分股行情
		for ETFIssueCode,v in pairs(gSelectETFListTable) do
			local ETFName = _ETFIssue2NameTable[ETFIssueCode]
			if _IssueETFTable[issueCode][ETFName] == 1 then
				if not _CompIssuePriceCount[ETFName] then
					_CompIssuePriceCount[ETFName] = {}
					_CompIssuePriceCount[ETFName].PriceCount = 0
				end
				CalcComponentMarketValueAndFare(ETFName,issueCode)
				if _CompIssuePriceCount[ETFName][issueCode] == nil then
					_CompIssuePriceCount[ETFName].PriceCount = _CompIssuePriceCount[ETFName].PriceCount + 1
					_CompIssuePriceCount[ETFName][issueCode] = 1
				end
			end
		end
	end
end


--读DD回调,读取上次设置的盘口价格名称
_OnDynamicData("GetMarketPriceType", MarketPriceTypeEvent  marketPriceTypeEvt)
	local etfPremiumPriceType = marketPriceTypeEvt._GetFld("ETFPremiumPriceType")
	local etfDiscountPriceType = marketPriceTypeEvt._GetFld("ETFDiscountPriceType")
	local componentPremiumPriceType = marketPriceTypeEvt._GetFld("ComponentPremiumPriceType")
	local componentDiscountPriceType = marketPriceTypeEvt._GetFld("ComponentDiscountPriceType")
	gETFPremiumPriceType = etfPremiumPriceType
	gETFDiscountPriceType = etfDiscountPriceType
	gComponentPremiumPriceType = componentPremiumPriceType
	gComponentDiscountPriceType = componentDiscountPriceType

	local log = sys_format("IN GetMarketPriceType, ETF溢价盘口价格类型:%s,ETF折价盘口价格类型:%s,成分股溢价盘口价格类型:%s,成分股折价盘口价格类型:%s",etfPremiumPriceType,etfDiscountPriceType,componentPremiumPriceType,componentDiscountPriceType)
	_WriteAplLog(log)
_End


--置信度设置
_OnEventDefined(SetConfidence setConfidenceevt)
	local stockConfidence = setConfidenceevt._GetFld("StockConfidence")
	local etfConfidence = setConfidenceevt._GetFld("ETFConfidence")
	gStockConfidence = stockConfidence.getNumberValue()
	gETFConfidence = etfConfidence.getNumberValue()
_End


--保存设置的盘口类型
_OnEventDefined(SetMarketPriceTypeEvent marketPriceTypeEvt)
	local etfPremiumPriceType = marketPriceTypeEvt._GetFld("ETFPremiumPriceType")
	local etfDiscountPriceType = marketPriceTypeEvt._GetFld("ETFDiscountPriceType")
	local componentPremiumPriceType = marketPriceTypeEvt._GetFld("ComponentPremiumPriceType")
	local componentDiscountPriceType = marketPriceTypeEvt._GetFld("ComponentDiscountPriceType")

	local log = sys_format("IN SetMarketPriceTypeEvent, ETF溢价盘口价格类型:%s,ETF折价盘口价格类型:%s,成分股溢价盘口价格类型:%s,成分股折价盘口价格类型:%s",etfPremiumPriceType,etfDiscountPriceType,componentPremiumPriceType,componentDiscountPriceType)
	_WriteAplLog(log)
	_WriteCatchAplLog(log)

	gETFPremiumPriceType = etfPremiumPriceType
	gETFDiscountPriceType = etfDiscountPriceType
	gComponentPremiumPriceType = componentPremiumPriceType
	gComponentDiscountPriceType = componentDiscountPriceType

	marketPriceTypeStore._Clear()
	marketPriceTypeStore._SaveData("MarketPriceTypeDD",marketPriceTypeEvt)
_End


--定时计算ETF折价溢价市值，股票折价溢价市值
_OnEventTimer(_TimerName="RefreshETFInfo")
	if gPriceInFlag then
		RefreshAllETFMarketInfo()
        gPriceInFlag = false
	end

_End


--刷新所有ETF盘口信息
function RefreshAllETFMarketInfo()
	local log = sys_format("In RefreshAllETFMarketInfo")
	--_WriteAplLog(log)
	for issueCode,value in pairs(gSelectETFListTable)  do
		if (value == 1) then
			local issueName = _ETFIssue2NameTable[issueCode]
			RefreshSingleETFMarketInfo(issueName)
		end
	end
end


--重新计算ETF和成份股信息并输出
function ReCalAndFreshAllInfo()
	for etfIssueCode,value in pairs(gSelectETFListTable)do
		local etfName = _ETFIssue2NameTable[etfIssueCode]
        ResetCalInfo(etfName)
		ResetETFMarketInfo(etfName)
	end
    ResetCompMarketInfo()
    RefreshAllETFMarketInfo()
end

function ResetETFMarketInfo(etfName)
	--重新计算ETF市值
	local issueCode = _ETFName2IssueTable[etfName]
	local priceInfo = _PosPriceTable[issueCode]
	if priceInfo then
		OnPrice(issueCode, priceInfo)
	end
	RefreshSingleETFMarketInfo(etfName)
end

function ResetCompMarketInfo()
	--重新计算成分股净值,对每个ETF成分股调用OnPrice
	for issueCode,v in pairs(_IssueETFTable) do
		local priceInfo = _PosPriceTable[issueCode]
		if priceInfo then
			OnPrice(issueCode, priceInfo)
		end
	end

end



--刷新一个ETF盘口信息
function RefreshSingleETFMarketInfo(etfName)
	local etfIssueCode = _ETFName2IssueTable[etfName]
	--添加过滤条件
	if gSelectETFListTable[etfIssueCode] then
		if gSelectETFListTable[etfIssueCode] == 1 and _PosPriceTable[etfIssueCode] then
			if _CompIssuePriceCount[etfName] then
				if _CompIssuePriceCount[etfName].PriceCount == _ETFInfoTable[etfName].RecordNum then
					SendETFInfo(etfIssueCode)
				end
			end
		end
	end
end

--发送盘口信息到XML
function SendETFInfo(etfIssueCode)
	local etfname = _ETFIssue2NameTable[etfIssueCode]						--ETF名称
	local etfMarketInfo = gtMarketValueTable[etfname]
	local etfPremMarketValue = 0
	local componentPremMarketValue = 0
	local etfDiscMarketValue = 0
	local componentDiscMarketValue = 0
	local componentMarketValue = 0
	local premFare = 0
	local discFare = 0
	local etfPremPrice = 0
	local componentPremPrice = 0
	local etfDiscPrice = 0
	local componentDiscPrice = 0
	local premiumProfit = 0
	local discountProfit = 0
	local unit = 0

	if etfMarketInfo then
		etfPremMarketValue = etfMarketInfo.PremETFMarketValue	--ETF溢价市值
		componentPremMarketValue = etfMarketInfo.PremComponentMarketValue + etfMarketInfo.MustCashComponent	--成分股溢价市值
		etfDiscMarketValue = etfMarketInfo.DiscETFMarketValue	--ETF折价市值
		componentDiscMarketValue = etfMarketInfo.DiscComponentMarketValue + etfMarketInfo.MustCashComponent	--成分股折价市值
		componentMarketValue = etfMarketInfo.ComponentMarketValue + etfMarketInfo.MustCashComponent
		premFare = gtETFFareTable[etfname].BuyCompFare + gtETFFareTable[etfname].CreFare + gtETFFareTable[etfname].SellETFFare--溢价费用
		discFare = gtETFFareTable[etfname].BuyETFFare + gtETFFareTable[etfname].RedFare + gtETFFareTable[etfname].SellCompFare--折价费用
		local etfInfo = _ETFInfoTable[etfname]
		unit = etfInfo.CreationRedemptionUnit
		if unit then
			etfPremPrice = etfPremMarketValue/unit						--ETF溢价盘口
			componentPremPrice = componentPremMarketValue/unit			--成分股溢价盘口
			etfDiscPrice = etfDiscMarketValue/unit						--ETF折价盘口
			componentDiscPrice = componentDiscMarketValue/unit			--成分股折价盘口
		end
		premiumProfit = etfPremMarketValue - componentPremMarketValue - premFare	--预期溢价利润
		discountProfit = componentDiscMarketValue - discFare - etfDiscMarketValue	--预期折价利润
	end

 --保存至表
	local DTSDate nowDate = _GetNowDate()
	local strDate = nowDate.asString("%Y%m%d")
	local DTSTime nowTime = _GetNowTime()
	local strTime = nowTime.asString("%H%M%S")
	local dateTime = strDate..strTime

	--本、率
	--本 = 交易费用/（基金份额所对应的成分股净值*ETF最小申赎单位）*100
	local premiumTradeCostPerShare =  premFare/(componentPremMarketValue) * 10000
	local disCountTradeCostPerShare = discFare/(componentDiscMarketValue) * 10000
	local blog = sys_format("premiumTradeCostPerShare = %s,premFare = %s,componentPremMarketValue = %s",
	premiumTradeCostPerShare,premFare,componentPremMarketValue)
--	_WriteCatchAplLog(blog)
	--率 = [（市-净）/ 净*100 或（净-市）/ 市*100]
	local premiumRate = (etfPremMarketValue - componentPremMarketValue)/componentPremMarketValue * 10000
	local disCountRate = (componentDiscMarketValue - etfDiscMarketValue)/etfDiscMarketValue * 10000
	--基点信息：率 - 本
	local premiumBasePointInfo = premiumRate - premiumTradeCostPerShare
	local disCountBasePointInfo = disCountRate - disCountTradeCostPerShare
--[[
	--IOPV:成分股净值/份额
	local premiumIOPV = componentPremMarketValue/unit               --盘口溢价净值
	local disCountIOPV = componentDiscMarketValue/unit                --盘口折价净值
	local iopv = componentMarketValue/unit                                  --实际净值
]]
	saveIssueMinuteDataToTable(etfIssueCode,etfname,dateTime,componentMarketValue,componentPremMarketValue,etfPremMarketValue,premiumTradeCostPerShare,premiumRate,premiumBasePointInfo,componentDiscMarketValue,etfDiscMarketValue,disCountTradeCostPerShare,disCountRate,disCountBasePointInfo)

	if (etfIssueCode == gSelectIssueCode) then
		sendLine(etfIssueCode,dateTime)
	end
-----------------------------------------------------------------
--输出格式化
	etfPremMarketValue = formatPara(etfPremMarketValue, 2)
	componentPremMarketValue = formatPara(componentPremMarketValue, 2)

	etfDiscMarketValue = formatPara(etfDiscMarketValue,2)
	componentDiscMarketValue = formatPara(componentDiscMarketValue, 2)
	premFare = formatPara(premFare, 2)
	discFare = formatPara(discFare,2)
	etfPremPrice = formatPara(etfPremPrice)
	componentPremPrice = formatPara(componentPremPrice)
	etfDiscPrice = formatPara(etfDiscPrice)
	componentDiscPrice = formatPara(componentDiscPrice, 2)
	premiumProfit = formatPara(premiumProfit, 2)
	componentDiscPrice = formatPara(componentDiscPrice)
	discountProfit = formatPara(discountProfit, 2)

--	local log = sys_format("ETFInfo ETF名称:%s,ETF溢价市:%s,成分股溢价市:%s,溢价费用:%s,ETF溢价盘口:%s,成分股溢价盘口:%s,预期溢价利润:%s,ETF折价市值:%s,成分股折价市值:%s,折价费用:%s,ETF折价盘口:%s,成分股折价盘口:%s,预期折价利润:%s",etfname,etfPremMarketValue,componentPremMarketValue,premFare,etfPremPrice,componentPremPrice,premiumProfit,etfDiscMarketValue,componentDiscMarketValue,discFare,etfDiscPrice,componentDiscPrice,discountProfit)
--	_WriteAplLog(log)
	local DTSEvent ETFInfoevt = _CreateEventObject("ETFArbiSpaceEvent")
	ETFInfoevt._SetFld("IssueCode",etfIssueCode)
	ETFInfoevt._SetFld("ETFName",etfname)
	ETFInfoevt._SetFld("ETFPremMarketValue",etfPremMarketValue)
	ETFInfoevt._SetFld("ComponentPremMarketValue",componentPremMarketValue)
	ETFInfoevt._SetFld("PremFare",premFare)
	ETFInfoevt._SetFld("ETFPremPrice",etfPremPrice)
	ETFInfoevt._SetFld("ComponentPremPrice",componentPremPrice)
	ETFInfoevt._SetFld("PremiumProfit",premiumProfit)
	ETFInfoevt._SetFld("ComponentDiscMarketValue",componentDiscMarketValue)
	ETFInfoevt._SetFld("ETFDiscMarketValue",etfDiscMarketValue)
	ETFInfoevt._SetFld("DiscFare",discFare)
	ETFInfoevt._SetFld("ETFDiscPrice",etfDiscPrice)
	ETFInfoevt._SetFld("ComponentDiscPrice",componentDiscPrice)
	ETFInfoevt._SetFld("DiscountProfit",discountProfit)
	if gSelectETFListTable[etfIssueCode] then
		if gSelectETFListTable[etfIssueCode] == 1 then
			ETFInfoevt._SetFld("DeleteFlag","0")
		elseif gSelectETFListTable[etfIssueCode] == 0 then
			ETFInfoevt._SetFld("DeleteFlag","1")
		end
		_SendToClients(ETFInfoevt)
	end
end
--格式化变量
--格式化变量
function formatPara(Para,Type)
	if(Para == 0) then
		Para = "-"
	else
        if Type == 2 then
            Para = sys_format("%.2f",Para)
        else
            Para = sys_format("%.3f",Para)
        end
	end
	return Para
end

function formatPara(Para)
    return formatPara(Para, 3)
end
--获取成分股股票状态
function getIssueCodePriceStatus(IssueCode)
	local priceInfo = _PosPriceTable[IssueCode]
	if priceInfo then
		local askQty1 = priceInfo.AskQuantity1
		local askQty2 = priceInfo.AskQuantity2
		local askQty3 = priceInfo.AskQuantity3
		local askQty4 = priceInfo.AskQuantity4
		local askQty5 = priceInfo.AskQuantity5
		local bidQty1 = priceInfo.BidQuantity1
		local bidQty2 = priceInfo.BidQuantity2
		local bidQty3 = priceInfo.BidQuantity3
		local bidQty4 = priceInfo.BidQuantity4
		local bidQty5 = priceInfo.BidQuantity5

		if (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
			gLogs = sys_format("issueCode:%s SP stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",IssueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteAplLog(gLogs);
			return "SP"; --SusPend 停牌
		elseif (askQty1 > 0 or askQty2 > 0 or askQty3 > 0 or askQty4 > 0 or askQty5 > 0) and (bidQty1 == 0 or bidQty1 == nil) and (bidQty2 == 0 or bidQty2 == nil) and (bidQty3 == 0 or bidQty3 == nil) and (bidQty4 == 0 or bidQty4 == nil) and (bidQty5 == 0 or bidQty5 == nil) then
			gLogs = sys_format("issueCode:%s DL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",IssueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteAplLog(gLogs);
			return "DL"; --Decline Limit 跌停
		elseif (askQty1 == 0 or askQty1 == nil) and (askQty2 == 0 or askQty2 == nil) and (askQty3 == 0 or askQty3 == nil) and (askQty4 == 0 or askQty4 == nil) and (askQty5 == 0 or askQty5 == nil) and (bidQty1 > 0 or bidQty2 > 0 or bidQty3 > 0 or bidQty4 > 0 or bidQty5 > 0) then
			gLogs = sys_format("issueCode:%s SL stateJudge-askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s",IssueCode,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5)
			--_WriteAplLog(gLogs);
			return "SL"; --Surged Limit 涨停
		else--if (askQty1>0 and askQty2>0 and askQty3>0 and askQty4>0 and askQty5>0) and (bidQty1>0 and bidQty2>0 and bidQty3>0 and bidQty4>0 and bidQty5>0) then
			return "NM"; --NorMal 正常
		end
	else
		return "NM"; --NorMal 正常
	end
end


--当某档价格不理想时，取下一档行情
function getNextPriceType(priceType)
	local newPriceType = "";
	if(priceType == "BidPrice5")then
		newPriceType = "BidPrice4";
	elseif(priceType == "BidPrice4")then
		newPriceType = "BidPrice3";
	elseif(priceType == "BidPrice3")then
		newPriceType = "BidPrice2";
	elseif(priceType == "BidPrice2")then
		newPriceType = "BidPrice1";
	elseif(priceType == "BidPrice1" or priceType == "AskPrice1")then
		newPriceType = "LastPrice";
	elseif(priceType == "AskPrice5")then
		newPriceType = "AskPrice4";
	elseif(priceType == "AskPrice5")then
		newPriceType = "AskPrice4";
	elseif(priceType == "AskPrice4")then
		newPriceType = "AskPrice3";
	elseif(priceType == "AskPrice3")then
		newPriceType = "AskPrice2";
	elseif(priceType == "AskPrice2")then
		newPriceType = "AskPrice1";
	end
	return newPriceType;
end


function getOrderPrice(issue,priceType,tick,buySell,orderQty)
	local price = 0
	if (priceType == "AutoPrice") then
        if _ETFIssue2NameTable[issue] then
            price =  getMarketPrice(issue,buySell,orderQty,gETFConfidence)
        else
            price =  getMarketPrice(issue,buySell,orderQty,gStockConfidence)
        end
	else
		price = getOrderPrice(issue,priceType,tick,buySell)
	end
	return price
end


--获取价格
function getOrderPrice(issue,priceType,tick,buySell)
	local returnPrice = -1.00;
	local newPriceType = priceType;
	while (returnPrice <= 0.0) do
		returnPrice = getOrderSmartPrice(issue,newPriceType,tick,buySell);
		if(returnPrice == -1.00)then
			local log = sys_format("returnPrice == -1.00, returnPrice == %s",returnPrice)
			_WriteAplLog(log)
			break;
		elseif(returnPrice == -9.00)then
			newPriceType = getNextPriceType(newPriceType);
			if(newPriceType == "")	then
				local log = sys_format("returnPrice == -9.00, returnPrice == %s",returnPrice)
				_WriteAplLog(log)
				returnPrice = -1.00;
				break;
			end
			returnPrice = getOrderSmartPrice(issue,newPriceType,tick,buySell);
		end
	end
	return returnPrice;
end


--将价格类型转化成价格数字
function getOrderSmartPrice(issue,priceType,tick,buySell)
	if not _PosPriceTable[issue] then
		local log =sys_format("issue:%s not registed",issue)
		_WriteAplLog(log)
		return -1.00;
	end
	local OrderPrice = 0.00;
	local tIssuePriceInfo = _PosPriceTable[issue];
	--停牌股票判断
	if(tIssuePriceInfo.BidQuantity1 == 0 and tIssuePriceInfo.BidQuantity2 == 0 and tIssuePriceInfo.BidQuantity3 == 0 and tIssuePriceInfo.BidQuantity4 == 0 and tIssuePriceInfo.BidQuantity5 == 0
		and tIssuePriceInfo.AskQuantity1 == 0 and tIssuePriceInfo.AskQuantity2 == 0 and tIssuePriceInfo.AskQuantity3 == 0 and tIssuePriceInfo.AskQuantity4 == 0 and tIssuePriceInfo.AskQuantity5 == 0)then
		--return tIssuePriceInfo.LastPrice;	--模拟用
		return -1;	--生产用 --sunzhijian 2011-11-09
	end
	--sunzhijian 2011-11-10
	if(priceType == "BidPrice1")then
		OrderPrice = tIssuePriceInfo.BidPrice1;
	elseif(priceType =="BidPrice2")then
		OrderPrice = tIssuePriceInfo.BidPrice2;
	elseif(priceType =="BidPrice3")then
		OrderPrice = tIssuePriceInfo.BidPrice3;
	elseif(priceType =="BidPrice4")then
		OrderPrice = tIssuePriceInfo.BidPrice4;
	elseif(priceType =="BidPrice5")then
		OrderPrice = tIssuePriceInfo.BidPrice5;
	elseif(priceType =="LastPrice")then
		OrderPrice = tIssuePriceInfo.LastPrice;
	elseif(priceType =="AskPrice1")then
		OrderPrice = tIssuePriceInfo.AskPrice1;
	elseif(priceType =="AskPrice2")then
		OrderPrice = tIssuePriceInfo.AskPrice2;
	elseif(priceType =="AskPrice3")then
		OrderPrice = tIssuePriceInfo.AskPrice3;
	elseif(priceType =="AskPrice4")then
		OrderPrice = tIssuePriceInfo.AskPrice4;
	elseif(priceType =="AskPrice5")then
		OrderPrice = tIssuePriceInfo.AskPrice5;
	elseif(priceType =="涨停")then
		OrderPrice = tIssuePriceInfo.UpLimitPrice;
	elseif(priceType =="跌停")then
		OrderPrice = tIssuePriceInfo.LowLimitPrice;
	elseif(priceType =="市价")then--市价转限价限价如何定？
		return  -2.00;
	else
		--local price = getQuotePriceAndQty(issue,priceType,0)
		--return price
	end
	-- add tick
	if(OrderPrice ~= nil and OrderPrice ~= 0)then
		local productCode = _PosIssueProductCodeTable[issue]
		local marketCode = _PosIssueMarketTable[issue]
		local underlyingIssueCode = _PosIssueUnderlyingTable[issue]
		local key = productCode.."-"..marketCode.."-"..underlyingIssueCode
		local priceTick = _PosIssuePriceTickTable[issue];
		OrderPrice = OrderPrice + priceTick * tick.getNumberValue();
	else
		return -9.00;
	end
	return OrderPrice;	--卖1;卖2;卖3;卖4;卖5;最新;买1;买2;买3;买4;买5;买1;涨停;跌停
end


--获取股票盘口价格
--参数：合约代码，买卖，数量，置信度，盘口价格类型
function getMarketPrice(IssueCode,buySell,Quantity,Confidence)
	local marketPrice = 0
	--local quantity = 0
	local priceInfo = _PosPriceTable[IssueCode]
	if priceInfo then
		local askPrice1 = priceInfo.AskPrice1 or 0
		local askPrice2 = priceInfo.AskPrice2 or 0
		local askPrice3 = priceInfo.AskPrice3 or 0
		local askPrice4 = priceInfo.AskPrice4 or 0
		local askPrice5 = priceInfo.AskPrice5 or 0
		local bidPrice1 = priceInfo.BidPrice1 or 0
		local bidPrice2 = priceInfo.BidPrice2 or 0
		local bidPrice3 = priceInfo.BidPrice3 or 0
		local bidPrice4 = priceInfo.BidPrice4 or 0
		local bidPrice5 = priceInfo.BidPrice5 or 0
		local askQty1 = priceInfo.AskQuantity1 or 0
		local askQty2 = priceInfo.AskQuantity2 or 0
		local askQty3 = priceInfo.AskQuantity3 or 0
		local askQty4 = priceInfo.AskQuantity4 or 0
		local askQty5 = priceInfo.AskQuantity5 or 0
		local bidQty1 = priceInfo.BidQuantity1 or 0
		local bidQty2 = priceInfo.BidQuantity2 or 0
		local bidQty3 = priceInfo.BidQuantity3 or 0
		local bidQty4 = priceInfo.BidQuantity4 or 0
		local bidQty5 = priceInfo.BidQuantity5 or 0
        local lastPrice = priceInfo.LastPrice or 0
		if buySell == "3" then
			local Quantity1 = Quantity - askQty1*Confidence		--除去卖1量以后还需要交易的数量
			local Quantity2 = Quantity1 - askQty2*Confidence	--除去卖2量以后还需要交易的数量
			local Quantity3 = Quantity2 - askQty3*Confidence	--除去卖3量以后还需要交易的数量
			local Quantity4 = Quantity3 - askQty4*Confidence	--除去卖4量以后还需要交易的数量
			--local Quantity5 = Quantity4 - askQty5*Confidence
			if askPrice5 > 0 and Quantity4 > 0 then			--卖1量足够
				marketPrice = askPrice5
				--quantity = askQty5
			elseif askPrice4 > 0 and Quantity3 >  0 then		--卖2量足够
				marketPrice = askPrice4
				--quantity = askQty4
			elseif askPrice3 > 0 and Quantity2 >  0 then		--卖3量足够
				marketPrice = askPrice3
				--quantity = askQty3
			elseif askPrice2 > 0 and Quantity1 > 0 then		--卖4量足够
				marketPrice = askPrice2
				--quantity = askQty2
			elseif  askPrice1 > 0 and askQty1 > 0 then	--卖5量以上
				marketPrice = askPrice1
				--quantity = askQty1
			else
				--marketPrice = lastPrice
			end
		else
			local Quantity1 = Quantity - bidQty1*Confidence		--除去买1量以后还需要交易的数量
			local Quantity2 = Quantity1 - bidQty2*Confidence	--除去买2量以后还需要交易的数量
			local Quantity3 = Quantity2 - bidQty3*Confidence	--除去买3量以后还需要交易的数量
			local Quantity4 = Quantity3 - bidQty4*Confidence	--除去买4量以后还需要交易的数量
			--local Quantity5 = Quantity4 - bidQty5*Confidence
			if bidPrice5 > 0 and Quantity4 > 0 then			--买1量足够
				marketPrice = bidPrice5
				--quantity = bidQty5
			elseif bidPrice4 > 0 and Quantity3 >  0 then		--买2量足够
				marketPrice = bidPrice4
				--quantity = bidQty4
			elseif bidPrice3 > 0 and  Quantity2 > 0 then		--买3量足够
				marketPrice = bidPrice3
				--quantity = bidQty3
			elseif bidPrice2 > 0 and  Quantity1 > 0 then		--买4量足够
				marketPrice = bidPrice2
				--quantity = bidQty2
			elseif bidPrice1 > 0 and  bidQty1 > 0 then
				marketPrice = bidPrice1
				--quantity = bidQty1
			else
				marketPrice = lastPrice
				--local log = sys_format("五档盘口数量不足:IssueCode:%s,BS:%s,Quantity:%s,Confidence:%s"IssueCode,BS,Quantity,Confidence)
			end
		end
--		local logs = sys_format("askPrice1:%s,askPrice2:%s,askPrice3:%s,askPrice4:%s,askPrice5:%s,bidPrice1:%s,bidPrice2:%s,bidPrice3:%s,bidPrice4:%s,bidPrice5:%s,askQty1:%s,askQty2:%s,askQty3:%s,askQty4:%s,askQty5:%s,bidQty1:%s,bidQty2:%s,bidQty3:%s,bidQty4:%s,bidQty5:%s,marketPrice:%s",askPrice1,askPrice2,askPrice3,askPrice4,askPrice5,bidPrice1,bidPrice2,bidPrice3,bidPrice4,bidPrice5,askQty1,askQty2,askQty3,askQty4,askQty5,bidQty1,bidQty2,bidQty3,bidQty4,bidQty5,marketPrice)
		--_WriteAplLog(logs)
	end
	return marketPrice
end

-----------------------------------------------------------------------------------------------------
------------------------------------------------MarketPriceTypeEvent输出-----------------------------
-----------------------------------------------------------------------------------------------------
function outPutMarketPriceTypeEvent()
	local DTSEvent evt = _CreateEventObject("MarketPriceTypeEvent")
	evt._SetFld("ETFPremiumPriceType",gETFPremiumPriceType)
	evt._SetFld("ETFDiscountPriceType",gETFDiscountPriceType)
	evt._SetFld("ComponentPremiumPriceType",gComponentPremiumPriceType)
	evt._SetFld("ComponentDiscountPriceType",gComponentDiscountPriceType)
	local log = sys_format("gETFPremiumPriceType = %s,gETFDiscountPriceType = %s, gComponentPremiumPriceType = %s,gComponentDiscountPriceType = %s",
	gETFPremiumPriceType,gETFDiscountPriceType,gComponentPremiumPriceType,gComponentDiscountPriceType)
	_WriteCatchAplLog(log)

	_SendToClients(evt)

end

------------------------------------------------------------------------------------------------------
------------------------------------------------Position函数定义--------------------------------------
------------------------------------------------------------------------------------------------------
function OnPositionInitialized()
end
function OnBackTestDayEnd()
end

function OnExecution(position, exec)
end

function OnOrder(position, order)
end

function OnPositionChanged(pos, reason)
end

function OnPositionError(log)
end

--估计交易费用accountCode为所属的帐户，issueCode为证券/期货合约代码，order为委托对象
function MyPosEstimateFare(accountCode, issueCode, order)
	if order.IsInternal == 1 then
		return 0
	end
	--现金还款\现券还券\担保品提交\担保品返回不计费用
	if order.OpenClose == 7 or  order.OpenClose == 8 or order.OpenClose == 9 then
		return 0
	end
	local productCode = _PosIssueProductCodeTable[issueCode]
	local fare = _PosGetFare(accountCode, issueCode)
	local contractSize = _PosIssueContractSizeTable[issueCode]
	local totalFare = 0
	local execValue = order.Quantity * contractSize * order.Price
	local execQty = order.Quantity
	if execQty == 0 then
		return 0
	end
	--期货交易费用计算
	if productCode == "21" or productCode == "31" or productCode == "37" then
		if order.OpenClose == 0 or order.OpenClose == 1 then --开仓，平仓
			totalFare = execValue * fare.OpenDropRatio + execQty * fare.OpenDropBalance
		else --平今
			totalFare = execValue * fare.DropCuFareRatio + execQty * fare.DropCuFareBalance
		end
	elseif productCode == "26" or productCode == "36" then
		local nearIssue = _PosIssueNearMonthTable[issueCode]
		local otherIssue = _PosIssueOtherMonthTable[issueCode]
		local nearFare = _PosGetFare(accountCode, nearIssue)
		local otherFare = _PosGetFare(accountCode, otherIssue)
		local nearContractSize = _PosIssueContractSizeTable[nearIssue]
		local otherContractSize = _PosIssueContractSizeTable[otherIssue]
		local nearUpperLimit = _PosGetUpperLimit(nearIssue)
		local otherUpperLimit = _PosGetUpperLimit(otherIssue)

		local nearExecValue = order.Quantity * nearContractSize * nearUpperLimit
		local otherExecValue = order.Quantity * otherContractSize * otherUpperLimit
		if order.OpenClose == 0 or order.OpenClose == 1 then --开仓，平仓
			totalFare = nearExecValue * nearFare.OpenDropRatio + execQty * nearFare.OpenDropBalance
			totalFare = totalFare + otherExecValue * otherFare.OpenDropRatio + execQty * otherFare.OpenDropBalance
		else --平今
			totalFare = nearExecValue * nearFare.DropCuFareRatio + execQty * nearFare.DropCuFareBalance
			totalFare = totalFare + otherExecValue * otherFare.DropCuFareRatio + execQty * otherFare.DropCuFareBalance
		end
	else--证券交易费用计算
		if order.CreRed == 0 then --普通证券买卖
			--过户费
			local faceValue = _PosIssueFaceValueTable[issueCode] or 0
			local transferExpense=sys_max(sys_ceil(execQty/100)*100*faceValue*fare.TransferExpense, fare.LowestTransferExpense);

			--印花税
			local sellStampTax=0;
			local buyStampTax=0;
			if order.BS=="1"  and productCode=="10" then
				sellStampTax=execValue * fare.SellStampTax;		--印花税
			elseif order.BS=="3" and productCode=="10"  then
				buyStampTax=execValue * fare.BuyStampTax;
			end

			local fareLog = ""
			--佣金(区分日内佣金和结算佣金)
			local tmpCommission = fare.Commission
			local tmpLowestCommission = fare.LowestCommission
			if PosTradingTransferFlag == 0 then --日内佣金
				if fare.TraCommission then
					tmpCommission = fare.TraCommission
					--fareLog = sys_format("POS:MyPosEstimateFare 日内佣金率设置[%s]",tmpCommission)
					--_WriteAplLog(fareLog)
				end

				if fare.TraLowestCommission then
					tmpLowestCommission = fare.TraLowestCommission
					--fareLog = sys_format("POS:MyPosEstimateFare 日内最低佣金额设置[%s]",tmpLowestCommission)
					--_WriteAplLog(fareLog)
				end
			end

			local commission = sys_max(execValue * tmpCommission, tmpLowestCommission);
			commission = sys_floor(commission * 100 + 0.5) / 100;


			totalFare = transferExpense + sellStampTax + buyStampTax + commission;		--交易费用

			--fareLog = sys_format("POS:MyPosEstimateFare 交易费用[%.2f] 过户费[%s],买印花税[%s],卖印花税[%s],佣金[%.2f],成交额[%.2f],佣金率[%.6f],最低佣金额[%.2f]",
				--totalFare,transferExpense,buyStampTax,sellStampTax,commission,execValue,tmpCommission,tmpLowestCommission)
			--_WriteAplLog(fareLog)
		else --ETF申购赎回
			if ( order.CreRed == 1 and order.BS == "3" ) then --申购的ETF成交
				totalFare = execQty * fare.CreFare
			elseif (order.CreRed == 2 and order.BS == "1") then--赎回的ETF成交
				totalFare = execQty * fare.RedFare
			else --成分股成交
				local faceValue = _PosIssueFaceValueTable[issueCode] or 0
				totalFare = execQty * faceValue * fare.CreRedTransferExpense
			end
		end
	end
	totalFare = sys_floor(totalFare * 100 + 0.5)/100
	return totalFare
end
