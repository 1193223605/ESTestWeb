﻿_WriteAplLog("ETF Monitor Version:1.00.100.20131212")

_DefineStrategyParameters
	_String spStockBAMapID = ""			_Comment "国内股票账号"
_End

require("Position")
require("sendLine")
require("ETFCalculate")
require("QueryETFInfo")
----------------------------------------------------------------------------------------
--选择需要输出图形的ETF事件
_DefineEventObject SelectETF _AS _Input
	_DefFld("IssueCode",_String,30)--ETF名称
_End

--存储IssueCode
_DefineEventObject SaveETF _AS _Output
	_DefFld("IssueCode",_String,30)--ETF名称
_End

--------------------------------------------------------------------------------------
----------------------------溢价部分--------------------------------------------------
--------------------------------------------------------------------------------------
--输出溢价走势图/瞬时套利空间图
_DefineEventObject PremiumArbitrageLine  _AS _Output
	_DefFld("IssueCode",_String,30)--ETF合约号
	_DefFld("IssueName",_String,30)--ETF名称
	_DefFld("StockPremiumNetValue",_String,20)      --净值(成分股溢价盘口市值)
	_DefFld("PremiumMarketValue",_String,20)         --ETF溢价市值
	_DefFld("PremiumIOPV",_String,20)                   --IOPV


----------------5档行情--------------------
	_DefFld("AskPrice_5",_String,20)--卖5价
	_DefFld("AskPrice_4",_String,20)--卖4价
	_DefFld("AskPrice_3",_String,20)--卖3价
	_DefFld("AskPrice_2",_String,20)--卖2价
	_DefFld("AskPrice_1",_String,20)--卖1价

	_DefFld("Price",_String,20)--现价

	_DefFld("BidPrice_1",_String,20)--买1价
	_DefFld("BidPrice_2",_String,20)--买2价
	_DefFld("BidPrice_3",_String,20)--买3价
	_DefFld("BidPrice_4",_String,20)--买4价
	_DefFld("BidPrice_5",_String,20)--买5价
----------------------------------------------------------------
--本：交易费用/基金份额所对应的成分股净值*10000
--率：溢价率
	_DefFld("PremiumTradeCostPerShare",_String,20)--每份额交易成本:交易费用/（基金份额所对应的成分股净值*10000）
	_DefFld("PremiumRate",_String,20)--溢价率
--	_DefFld("PremiumExpectProfit",_String,20)--溢价预期利润
--	_DefFld("PremiumExpectCost",_String,20)--溢价预期成本
	_DefFld("PremiumBasePointInfo",_String,20)--基点信息：率 - 本

	_DefFld("DateTime",_String,30)--时间
	_DefKeyField("IssueCode");
	_SetBufferedFlag(0);
	_SetDataType(_EventMinuteType);
	_SetDataInterval(1);
_End


--------------------------------------------------------------------------------------
----------------------------折价部分--------------------------------------------------
--------------------------------------------------------------------------------------
--输出折价走势图/瞬时套利空间图
_DefineEventObject DisCountArbitrageLine  _AS _Output
	_DefFld("IssueCode",_String,30)--ETF合约号
	_DefFld("IssueName",_String,30)--ETF名称
	_DefFld("StockDiscountNetValue",_String,20)--净值(成份股折价盘口市值)
	_DefFld("DiscountMarketValue",_String,20)--ETF折价市值
	_DefFld("DisCountIOPV",_String,20)--IOPV

----------------5档行情--------------------
	_DefFld("AskPrice_5",_String,20)--卖5价
	_DefFld("AskPrice_4",_String,20)--卖4价
	_DefFld("AskPrice_3",_String,20)--卖3价
	_DefFld("AskPrice_2",_String,20)--卖2价
	_DefFld("AskPrice_1",_String,20)--卖1价

	_DefFld("Price",_String,20)--现价

	_DefFld("BidPrice_1",_String,20)--买1价
	_DefFld("BidPrice_2",_String,20)--买2价
	_DefFld("BidPrice_3",_String,20)--买3价
	_DefFld("BidPrice_4",_String,20)--买4价
	_DefFld("BidPrice_5",_String,20)--买5价

--本：交易费用/基金份额所对应的成分股净值*10000
--率：折价率
	_DefFld("DisCountTradeCostPerShare",_String,20)--每份额交易成本:交易费用/基金份额所对应的成分股净值*10000
	_DefFld("DisCountRate",_String,20)--折价率
--	_DefFld("DisCountExpectProfit",_String,20)--折价预期利润
--	_DefFld("DisCountExpectCost",_String,20)--折价预期成本
	_DefFld("DisCountBasePointInfo",_String,20)--基点信息：率 - 本


	_DefFld("DateTime",_String,30)--时间

	_DefKeyField("IssueCode");
	_SetBufferedFlag(0);
	_SetDataType(_EventMinuteType);
	_SetDataInterval(1);

_End
--------------------------------------------------------------------------------------------
-----------------------------------------ETF设置--------------------------------------------
--------------------------------------------------------------------------------------------
_DefineEventObject SetETF _AS _Input
	_DefFld("ETFConfidence",_String,20)--ETF置信度
	_DefFld("StockConfidence",_String,20)--股票置信度
	_DefFld("ArbitrageSuccessRatio",_String,20)--套利成功率

	_DefFld("PremiumCondition1",_String,20)--列表的溢价预期利润需减去退补溢价比例部分
	_DefFld("PremiumCondition2",_String,20)--列表的溢价预期利润需减去其他溢价比例部分
	_DefFld("DisCountCondition",_String,20)--列表的折价预期利润需减去退补折算比例部分
_End
-------------------------------------------------------------------------------------------
-------------------------------------------ETF盘口价格选择----------------------------
--------------------------------------------------------------------------------------------
--溢价价格(股票)
_DefineEventObject PremiumStockPriceSelect _AS _Input
	_DefFld("PremiumStockPriceType",_String,20)
_End

--溢价价格(ETF)
_DefineEventObject PremiumETFPriceSelect _AS _Input
	_DefFld("PremiumETFPriceType",_String,20)
_End

--折价价格(股票)
_DefineEventObject DisCountStockPriceSelect _AS _Input
	_DefFld("DisCountStockPriceType",_String,20)
_End

--折价价格(ETF)
_DefineEventObject DisCountETFPriceSelect _AS _Input
	_DefFld("DisCountETFPriceType",_String,20)
_End
------------------------------------------------------------------------
-----------------------------ETF监控增加、删除事件----------------------
------------------------------------------------------------------------
--置信度请求事件
_DefineEventObject ConfidenceRequest _AS _Input
	_DefFld("Flag",_String,20)
_End

_DefineEventObject OutputConfidence _AS _Output
	_DefFld("StockConfidence",_String,20)
	_DefFld("ETFConfidence",_String,20)
	_SetBufferedFlag(2);
_End


--所有ETF输出输出事件
_DefineEventObject OutputAllETFList _AS _Output
	_DefFld("AllETFList",_Meta,1)

	_SetBufferedFlag(2);
_End


--增加监控事件
_DefineEventObject AddNewETF _AS _Input
	_DefFld("IssueCode",_String,20)
_End


--删除监控事件
_DefineEventObject DeleteETF _AS _Input
	_DefFld("ETFName",_String,50)
_End
------------------------------------------------------------------------------------------------
----------------------------------------------计算相关------------------------------------------
------------------------------------------------------------------------------------------------
--置信度设置
_DefineEventObject SetConfidence _AS _Input
	_DefFld("StockConfidence",_String,6)	--股票置信度
	_DefFld("ETFConfidence",_String,6)		--ETF置信度
_End

--设置盘口价格类型
_DefineEventObject SetMarketPriceTypeEvent _AS _Input
	_DefFld("ETFPremiumPriceType",_String,9)
	_DefFld("ETFDiscountPriceType",_String,9)
	_DefFld("ComponentPremiumPriceType",_String,9)
	_DefFld("ComponentDiscountPriceType",_String,9)
_End


--盘口价格类型事件
_DefineEventObject MarketPriceTypeEvent _AS _Output
	_DefFld("ETFPremiumPriceType",_String,9)
	_DefFld("ETFDiscountPriceType",_String,9)
	_DefFld("ComponentPremiumPriceType",_String,9)
	_DefFld("ComponentDiscountPriceType",_String,9)

	_SetBufferedFlag(2);
	_SetDataType(_EventOtherType);
_End

--套利空间事件
_DefineEventObject ETFArbiSpaceEvent _AS _Output
	_DefFld("IssueCode",_String,20) --ETF合约号
	_DefFld("ETFName",_String,20)					--ETF名称

	_DefFld("ETFPremMarketValue",_String,20)			--ETF溢价市值
	_DefFld("ComponentPremMarketValue",_String,20)	--成分股溢价市值
	_DefFld("PremFare",_String,9)					--溢价费用
	_DefFld("ETFPremPrice",_String,9)				--ETF溢价盘口
	_DefFld("ComponentPremPrice",_String,9)			--成分股溢价盘口
	_DefFld("PremiumProfit",_String,9)				--预期溢价利润

	_DefFld("ETFDiscMarketValue",_String,20)			--ETF折价市值
	_DefFld("ComponentDiscMarketValue",_String,20)	--成分股折价市值
	_DefFld("DiscFare",_String,9)					--折价费用
	_DefFld("ETFDiscPrice",_String,9)				--ETF折价盘口
	_DefFld("ComponentDiscPrice",_String,9)			--成分股折价盘口
	_DefFld("DiscountProfit",_String,9)				--预期折价利润

	_DefFld("DeleteFlag",_String,2)				--DeleteFlag
	_SetBufferedFlag(2);
    _DefKeyField("IssueCode");
	_SetDataType(_EventOtherType);
_End

