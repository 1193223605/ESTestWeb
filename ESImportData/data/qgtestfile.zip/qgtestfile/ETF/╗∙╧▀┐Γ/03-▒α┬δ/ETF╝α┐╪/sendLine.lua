﻿--@@Version:1.00.100.20131212@@
--------------------------------------------------------------------------
-------------------------初始化相关---------------------------------------
--------------------------------------------------------------------------
function initialSelectTable()
	IssuePriceTable = {}
	ETFListTable = {}
	gSelectIssueCode = nil
	gETFList = ""

	gSelectETFListTable = {}

end

function LoadSaveETF()
	--初始化存储的ETF列表
	local DTSEvent saveETF = _CreateEventObject("SaveETF")
	DTSDynamicData savedETFStore = _CreateDynamicData(TSInstanceName = "SaveETFData", fileType = _DataOtherType,SaveETF saveETF)
	savedETFStore._GetDynamicData("GetSavedETF",condition="")
end

_OnDynamicData("GetSavedETF",SaveETF evt)
	local issueCode = evt._GetFld("IssueCode")
	local etfname = _ETFIssue2NameTable[issueCode]

	local DTSEvent ETFInfoevt = _CreateEventObject("ETFArbiSpaceEvent")
	ETFInfoevt._SetFld("IssueCode",issueCode)
	ETFInfoevt._SetFld("ETFName",etfname)
	ETFInfoevt._SetFld("ETFPremMarketValue","-")
	ETFInfoevt._SetFld("ComponentPremMarketValue","-")
	ETFInfoevt._SetFld("PremFare","-")
	ETFInfoevt._SetFld("ETFPremPrice","-")
	ETFInfoevt._SetFld("ComponentPremPrice","-")
	ETFInfoevt._SetFld("PremiumProfit","-")
	ETFInfoevt._SetFld("ComponentDiscMarketValue","-")
	ETFInfoevt._SetFld("ETFDiscMarketValue","-")
	ETFInfoevt._SetFld("DiscFare","-")
	ETFInfoevt._SetFld("ETFDiscPrice","-")
	ETFInfoevt._SetFld("ComponentDiscPrice","-")
	ETFInfoevt._SetFld("DiscountProfit","-")
	ETFInfoevt._SetFld("DeleteFlag","0")
	_SendToClients(ETFInfoevt)

	if not gSelectETFListTable[issueCode] then
		gSelectETFListTable[issueCode] = 1
		_PosRegisterPrice(issueCode)

		local etfName = _ETFIssue2NameTable[issueCode]
		if _ETFComponentTable[etfName] then
			for stockIssueCode,value in pairs(_ETFComponentTable[etfName]) do
				_PosRegisterPrice(stockIssueCode)
				if not _IssueETFTable[stockIssueCode] then
					_IssueETFTable[stockIssueCode] = {}
				end
				_IssueETFTable[stockIssueCode][etfName] = 1
			end
		end
	end
_End
----------------------------------------------------------------------------
----------------------------------数据发送-----------------------------------
-----------------------------------------------------------------------------
--发送某个ETF的数据
function sendETFLine(issueCode)
    if IssuePriceTable[issueCode] == nil then
        return
    end

	for time,value in pairs(IssuePriceTable[issueCode])do
        sendLine(issueCode,time)
      end

end

--发送分时图上某点的数据
function sendLine(issueCode,dateTime)
--	local log = sys_format("SendLine issueCode:%s,dateTime = %s",issueCode,dateTime)
--	_WriteAplLog(log)
	sendPremiumArbitrageLine(issueCode,dateTime)
	sendDiscountArbitrageLine(issueCode,dateTime)
end

---溢价输出事件
--function sendPremiumArbitrageLine(issueCode,issueName,dateTime,iopv,premiumIOPV,stockPremiumNetValue,premiumMarketValue,askPrice_5,askPrice_4,askPrice_3,askPrice_2,askPrice_1,price,bidPrice_1,bidPrice_2,bidPrice_3,bidPrice_4,bidPrice_5,premiumTradeCostPerShare,premiumRate,premiumExpectProfit,premiumExpectCost,premiumBasePointInfo)
function sendPremiumArbitrageLine(issueCode,dateTime)
	local DTSEvent evt = _CreateEventObject("PremiumArbitrageLine")
	local timeKey = formatTimeKey(dateTime)
	evt._SetTimeKey(timeKey)

    local value = IssuePriceTable[issueCode][dateTime]
    local issueName = value.IssueName
    local askPrice_5 = value.AskPrice_5
    local askPrice_4 = value.AskPrice_4
    local askPrice_3 = value.AskPrice_3
    local askPrice_2 = value.AskPrice_2
    local askPrice_1 = value.AskPrice_1
    local price = value.Price
    local bidPrice_1 = value.BidPrice_1
    local bidPrice_2 = value.BidPrice_2
    local bidPrice_3 = value.BidPrice_3
    local bidPrice_4 = value.BidPrice_4
    local bidPrice_5 = value.BidPrice_5
    ---------------------------------------------------------------
    local premiumIOPV = value.IOPV
    local premiumTradeCostPerShare = value.PremiumTradeCosePerShare
    local premiumRate = value.PremiumRate
    local premiumBasePointInfo = value.PremiumBasePointInfo
    local stockPremiumNetValue = value.StockPremiumNetValue
    local premiumMarketValue = value.PremiumMarketValue
	evt._SetFld("IssueCode",issueCode)--ETF合约号
	evt._SetFld("IssueName",issueName)--ETF名称

	stockPremiumNetValue = formatPara(stockPremiumNetValue)
	evt._SetFld("StockPremiumNetValue",stockPremiumNetValue)--净值(成分股溢价盘口市值)

	premiumMarketValue = formatPara(premiumMarketValue)
	evt._SetFld("PremiumMarketValue",premiumMarketValue)--ETF溢价市值

	premiumIOPV = formatPara(premiumIOPV)
	evt._SetFld("PremiumIOPV",premiumIOPV)--IOPV

----------------5档行情--------------------
	askPrice_5 = formatPara(askPrice_5)
	evt._SetFld("AskPrice_5",askPrice_5)--卖5价

	askPrice_4 = formatPara(askPrice_4)
	evt._SetFld("AskPrice_4",askPrice_4)--卖4价

	askPrice_3 = formatPara(askPrice_3)
	evt._SetFld("AskPrice_3",askPrice_3)--卖3价

	askPrice_2 = formatPara(askPrice_2)
	evt._SetFld("AskPrice_2",askPrice_2)--卖2价

	askPrice_1 = formatPara(askPrice_1)
	evt._SetFld("AskPrice_1",askPrice_1)--卖1价

	price = formatPara(price)
	evt._SetFld("Price",price)--现价

	bidPrice_1 = formatPara(bidPrice_1)
	evt._SetFld("BidPrice_1",bidPrice_1)--买1价

	bidPrice_2 = formatPara(bidPrice_2)
	evt._SetFld("BidPrice_2",bidPrice_2)--买2价

	bidPrice_3 = formatPara(bidPrice_3)
	evt._SetFld("BidPrice_3",bidPrice_3)--买3价

	bidPrice_4 = formatPara(bidPrice_4)
	evt._SetFld("BidPrice_4",bidPrice_4)--买4价

	bidPrice_5 = formatPara(bidPrice_5)
	evt._SetFld("BidPrice_5",bidPrice_5)--买5价

----------------------------------------------------------------
--本：交易费用/基金份额所对应的成分股净值*10000
--率：溢价率
	premiumTradeCostPerShare = formatPara(premiumTradeCostPerShare)
	evt._SetFld("PremiumTradeCostPerShare",premiumTradeCostPerShare)--每份额交易成本:交易费用/（基金份额所对应的成分股净值*10000）

	premiumRate = formatPara(premiumRate)
	evt._SetFld("PremiumRate",premiumRate)--溢价率

	premiumBasePointInfo = formatPara(premiumBasePointInfo)
	evt._SetFld("PremiumBasePointInfo",premiumBasePointInfo)--基点信息：率 - 本


--时间日期相关
	evt._SetFld("DateTime",dateTime)
	_SendToClients(evt)
end


--折价输出事件
--function sendDiscountArbitrageLine(issueCode,issueName,dateTime,iopv,disCountIOPV,stockDiscountNetValue,disCountMarketValue,askPrice_5,askPrice_4,askPrice_3,askPrice_2,askPrice_1,price,bidPrice_1,bidPrice_2,bidPrice_3,bidPrice_4,bidPrice_5,disCountTradeCostPerShare,disCountRate,disCountExpectProfit,disCountExpectCost,disCountBasePointInfo)
function sendDiscountArbitrageLine(issueCode,dateTime)
	local DTSEvent evt = _CreateEventObject("DisCountArbitrageLine")
	local timeKey = formatTimeKey(dateTime)
	evt._SetTimeKey(timeKey)

    local value = IssuePriceTable[issueCode][dateTime]
    local issueName = value.IssueName
    local askPrice_5 = value.AskPrice_5
    local askPrice_4 = value.AskPrice_4
    local askPrice_3 = value.AskPrice_3
    local askPrice_2 = value.AskPrice_2
    local askPrice_1 = value.AskPrice_1
    local price = value.Price
    local bidPrice_1 = value.BidPrice_1
    local bidPrice_2 = value.BidPrice_2
    local bidPrice_3 = value.BidPrice_3
    local bidPrice_4 = value.BidPrice_4
    local bidPrice_5 = value.BidPrice_5
    local disCountIOPV = value.IOPV
    local disCountTradeCostPerShare = value.DisCountTradeCosePerShare
    local disCountRate = value.DisCountRate
    local disCountBasePointInfo = value.DisCountBasePointInfo
    local stockDisCountNetValue = value.StockDisCountNetValue
    local disCountMarketValue = value.DisCountMarketValue

	evt._SetFld("IssueCode",issueCode)--ETF合约号
	evt._SetFld("IssueName",issueName)--ETF名称

	stockDisCountNetValue = formatPara(stockDisCountNetValue)
	evt._SetFld("StockDiscountNetValue",stockDisCountNetValue)--净值(成份股折价盘口市值)

	disCountMarketValue = formatPara(disCountMarketValue)
	evt._SetFld("DiscountMarketValue",disCountMarketValue)--ETF折价市值

	disCountIOPV = formatPara(disCountIOPV)
	evt._SetFld("DisCountIOPV",disCountIOPV)--IOPV
----------------5档行情--------------------
	askPrice_5 = formatPara(askPrice_5)
	evt._SetFld("AskPrice_5",askPrice_5)--卖5价

	askPrice_4 = formatPara(askPrice_4)
	evt._SetFld("AskPrice_4",askPrice_4)--卖4价

	askPrice_3 = formatPara(askPrice_3)
	evt._SetFld("AskPrice_3",askPrice_3)--卖3价

	askPrice_2 = formatPara(askPrice_2)
	evt._SetFld("AskPrice_2",askPrice_2)--卖2价

	askPrice_1 = formatPara(askPrice_1)
	evt._SetFld("AskPrice_1",askPrice_1)--卖1价

	price = formatPara(price)
	evt._SetFld("Price",price)--现价

	bidPrice_1 = formatPara(bidPrice_1)
	evt._SetFld("BidPrice_1",bidPrice_1)--买1价

	bidPrice_2 = formatPara(bidPrice_2)
	evt._SetFld("BidPrice_2",bidPrice_2)--买2价

	bidPrice_3 = formatPara(bidPrice_3)
	evt._SetFld("BidPrice_3",bidPrice_3)--买3价

	bidPrice_4 = formatPara(bidPrice_4)
	evt._SetFld("BidPrice_4",bidPrice_4)--买4价

	bidPrice_5 = formatPara(bidPrice_5)
	evt._SetFld("BidPrice_5",bidPrice_5)--买5价


--本：交易费用/基金份额所对应的成分股净值*10000
--率：折价率
	disCountTradeCostPerShare = formatPara(disCountTradeCostPerShare)
	evt._SetFld("DisCountTradeCostPerShare",disCountTradeCostPerShare)--每份额交易成本:交易费用/（基金份额所对应的成分股净值*10000）

	disCountRate = formatPara(disCountRate)
	evt._SetFld("DisCountRate",disCountRate)--折价率

	disCountBasePointInfo = formatPara(disCountBasePointInfo)
	evt._SetFld("DisCountBasePointInfo",disCountBasePointInfo)--基点信息：率 - 本

--时间日期相关
	evt._SetFld("DateTime",dateTime)


	_SendToClients(evt)
end


----------------------------------------
---------数据保存-----------------------
----------------------------------------
--存入表格函数
--function saveIssueMinuteDataToTable(issueCode,issueName,dateTime,iopv,premiumIOPV,stockPremiumNetValue,premiumMarketValue,premiumTradeCostPerShare,premiumRate,premiumExpectProfit,premiumExpectCost,premiumBasePointInfo,disCountIOPV,stockDisCountNetValue,disCountMarketValue,disCountTradeCostPerShare,disCountRate,disCountExpectProfit,disCountExpectCost,disCountBasePointInfo)
function saveIssueMinuteDataToTable(issueCode,issueName,dateTime,iopvValue,stockPremiumNetValue,premiumMarketValue,premiumTradeCostPerShare,premiumRate,premiumBasePointInfo,stockDisCountNetValue,disCountMarketValue,disCountTradeCostPerShare,disCountRate,disCountBasePointInfo)

	--local chagneFlag = false
	--dateTime = formatTimeKey(dateTime)
	local log = sys_format("save : stockPremiumNetValue = %s",stockPremiumNetValue)
	--_WriteAplLog(log)
	if not IssuePriceTable then
		--changeFlag = true
		IssuePriceTable = {}
	end
	if not IssuePriceTable[issueCode] then
		--changeFlag = true
		IssuePriceTable[issueCode] = {}
	end
	if not IssuePriceTable[issueCode][dateTime] then
		--changeFlag = true
		IssuePriceTable[issueCode][dateTime] = {}
	end
    --价格新增部分
	local priceInfo = _PosPriceTable[issueCode]
	local askPrice_1 = 0
	local askPrice_2 = 0
	local askPrice_3 = 0
	local askPrice_4 = 0
	local askPrice_5 = 0

	local lastPrice = 0

	local bidPrice_1 = 0
	local bidPrice_2 = 0
	local bidPrice_3 = 0
	local bidPrice_4 = 0
	local bidPrice_5 = 0

	if priceInfo then
		askPrice_1 = priceInfo.AskPrice1 or 0
		askPrice_2 = priceInfo.AskPrice2 or 0
		askPrice_3 = priceInfo.AskPrice3 or 0
		askPrice_4 = priceInfo.AskPrice4 or 0
		askPrice_5 = priceInfo.AskPrice5 or 0
		lastPrice = priceInfo.LastPrice or 0
		bidPrice_1 = priceInfo.BidPrice1 or 0
		bidPrice_2 = priceInfo.BidPrice2 or 0
		bidPrice_3 = priceInfo.BidPrice3 or 0
		bidPrice_4 = priceInfo.BidPrice4 or 0
		bidPrice_5 = priceInfo.BidPrice5 or 0
	end

	IssuePriceTable[issueCode][dateTime].IssueName = issueName
	IssuePriceTable[issueCode][dateTime].IOPV = iopvValue
	IssuePriceTable[issueCode][dateTime].AskPrice_5 = askPrice_5
	IssuePriceTable[issueCode][dateTime].AskPrice_4 = askPrice_4
	IssuePriceTable[issueCode][dateTime].AskPrice_3 = askPrice_3
	IssuePriceTable[issueCode][dateTime].AskPrice_2 = askPrice_2
	IssuePriceTable[issueCode][dateTime].AskPrice_1 = askPrice_1
	IssuePriceTable[issueCode][dateTime].Price = lastPrice
	IssuePriceTable[issueCode][dateTime].BidPrice_1 = bidPrice_1
	IssuePriceTable[issueCode][dateTime].BidPrice_2 = bidPrice_2
	IssuePriceTable[issueCode][dateTime].BidPrice_3 = bidPrice_3
	IssuePriceTable[issueCode][dateTime].BidPrice_4 = bidPrice_4
	IssuePriceTable[issueCode][dateTime].BidPrice_5 = bidPrice_5

	IssuePriceTable[issueCode][dateTime].StockPremiumNetValue = stockPremiumNetValue
	IssuePriceTable[issueCode][dateTime].PremiumMarketValue = premiumMarketValue
	IssuePriceTable[issueCode][dateTime].PremiumTradeCosePerShare = premiumTradeCostPerShare
	IssuePriceTable[issueCode][dateTime].PremiumRate = premiumRate
--	IssuePriceTable[issueCode][dateTime].PremiumExpectProfit = premiumExpectProfit
--	IssuePriceTable[issueCode][dateTime].PremiumExpectCost = premiumExpectCost
	IssuePriceTable[issueCode][dateTime].PremiumBasePointInfo = premiumBasePointInfo

	IssuePriceTable[issueCode][dateTime].StockDisCountNetValue = stockDisCountNetValue
	IssuePriceTable[issueCode][dateTime].DisCountMarketValue = disCountMarketValue
	IssuePriceTable[issueCode][dateTime].DisCountTradeCosePerShare = disCountTradeCostPerShare
	IssuePriceTable[issueCode][dateTime].DisCountRate = disCountRate
--	IssuePriceTable[issueCode][dateTime].DisCountExpectProfit = disCountExpectProfit
--	IssuePriceTable[issueCode][dateTime].DiscountExpectCost = disCountExpectCost
	IssuePriceTable[issueCode][dateTime].DisCountBasePointInfo = disCountBasePointInfo
end

-----------------------------------------------------
-----选择输出----------------------------------------
------------------------------------------------------
_OnEventDefined(SelectETF evt)
	local issueCode = evt._GetFld("IssueCode")
	local log = sys_format("SelectETF Event: IssueCode = %s",issueCode)
	_WriteAplLog(log)
	if gSelectIssueCode ~= issueCode then
		gSelectIssueCode = issueCode
        sendETFLine(issueCode)
	end
_End

---------------------------------------------------------
------------------时间处理-------------------------------
---------------------------------------------------------
function formatTimeKey(DateTime)
	local formatDateTime = ""
	dateTime = DateTime.toString()
	local len = sys_len(dateTime)
	for i = 1, len,1 do
		local chr = sys_sub(dateTime,i,i)
		if(chr >="0" and chr <= "9")then
			formatDateTime = formatDateTime ..chr;
		end
	end
	formatDateTime = sys_sub(formatDateTime,1,12)
	formatDateTime = formatDateTime .. "00000"
	return formatDateTime
end

--------------------------------------------------------------
----------------------------ETF设置---------------------------
--------------------------------------------------------------
--ETF数据设置
_OnEventDefined(SetETF evt)
	local etfConfidence = evt._GetFld("ETFConfidence")
	local stockConfidence = evt._GetFld("StockConfidence")
	local arbitrageSuccessRatio = evt._GetFld("ArbitrageSuccessRatio")
	local premiumCondition1 = evt._GetFld("PremiumCondition1")
	local premiumCondition2 = evt._GetFld("PremiumCondition2")
	local disCountCondition = evt._GetFld("DisCountCondition")
	local log = sys_format("ETF设置:etfConfidence = %s,stockConfidence = %s,arbitrageSuccessRatio = %s,premiumCondition1 = %s, premiumCondition2 = %s,disCountCondition = %s",
	etfConfidence,stockConfidence,arbitrageSuccessRatio,premiumCondition1,premiumCondition2,disCountCondition)
	_WriteCatchAplLog(log)

	--股票置信度
	gStockConfidence = stockConfidence.getNumberValue()/100
	--ETF置信度
	gETFConfidence = etfConfidence.getNumberValue()/100

    ReCalAndFreshAllInfo()

_End


--ETF盘口价格选择
--溢价价格(股票)
_OnEventDefined(PremiumStockPriceSelect evt)
	local premiumStockPriceType = evt._GetFld("PremiumStockPriceType")
	local log = sys_format("溢价盘口价格(股票): %s",premiumStockPriceType)
	_WriteCatchAplLog(log)
	_WriteAplLog(log)
	if(gComponentPremiumPriceType ~= premiumStockPriceType) then

		gComponentPremiumPriceType = premiumStockPriceType
		for issueCode,value in pairs(IssuePriceTable) do
			IssuePriceTable[issueCode] = {}
		end

		SaveMarketPriceTypeDD()
        ReCalAndFreshAllInfo()
	end
_End

--溢价价格(ETF)
_OnEventDefined(PremiumETFPriceSelect evt)
	local premiumETFPriceType = evt._GetFld("PremiumETFPriceType")
	local log = sys_format("溢价盘口价格(ETF): %s",premiumETFPriceType)
	_WriteCatchAplLog(log)
	_WriteAplLog(log)
	if(gETFPremiumPriceType ~= premiumETFPriceType) then

		gETFPremiumPriceType = premiumETFPriceType
		for issueCode,value in pairs(IssuePriceTable) do
			IssuePriceTable[issueCode] = {}
		end

		SaveMarketPriceTypeDD()
        ReCalAndFreshAllInfo()
	end
_End

--折价价格(股票)
_OnEventDefined(DisCountStockPriceSelect evt)
	local disCountStockPriceType = evt._GetFld("DisCountStockPriceType")
	local log = sys_format("折价盘口价格(股票): %s",disCountStockPriceType)
	_WriteCatchAplLog(log)
	_WriteAplLog(log)
	if(gComponentDiscountPriceType ~= disCountStockPriceType) then

		gComponentDiscountPriceType = disCountStockPriceType
		for issueCode,value in pairs(IssuePriceTable) do
			IssuePriceTable[issueCode] = {}
		end
		SaveMarketPriceTypeDD()
        ReCalAndFreshAllInfo()
	end
_End

--折价价格(ETF)
_OnEventDefined(DisCountETFPriceSelect evt)
	local disCountETFPriceType = evt._GetFld("DisCountETFPriceType")
	local log = sys_format("折价盘口价格(ETF): %s",disCountETFPriceType)
	_WriteCatchAplLog(log)
	_WriteAplLog(log)
	if(gETFDiscountPriceType ~= disCountETFPriceType) then

		gETFDiscountPriceType = disCountETFPriceType
		for issueCode,value in pairs(IssuePriceTable) do
			IssuePriceTable[issueCode] = {}
		end

		SaveMarketPriceTypeDD()
        ReCalAndFreshAllInfo()
	end
_End

function SaveMarketPriceTypeDD()
    local DTSEvent marketPriceTypeEvt = _CreateEventObject("MarketPriceTypeEvent")
    marketPriceTypeEvt._SetFld("ETFPremiumPriceType",gETFPremiumPriceType)
    marketPriceTypeEvt._SetFld("ETFDiscountPriceType",gETFDiscountPriceType)
    marketPriceTypeEvt._SetFld("ComponentPremiumPriceType",gComponentPremiumPriceType)
    marketPriceTypeEvt._SetFld("ComponentDiscountPriceType",gComponentDiscountPriceType)

    marketPriceTypeStore._Clear()
    marketPriceTypeStore._SaveData("MarketPriceTypeDD",marketPriceTypeEvt)
end
-----------------------------------------------------------------------------------
------------------------------------ETF的增删事件---------------------------------
----------------------------------------------------------------------------------
----列表请求输出
_OnEventDefined(ConfidenceRequest evt)
	local flag = evt._GetFld("Flag")
	_WriteCatchAplLog(flag)

	if(flag == "True") then
		outputConfidence()
	end
_End

function outputConfidence()
	StockConfidence = gStockConfidence * 100
	ETFConfidence = gETFConfidence * 100
	local DTSEvent evt = _CreateEventObject("OutputConfidence")
	evt._SetFld("StockConfidence",StockConfidence)
	evt._SetFld("ETFConfidence",ETFConfidence)
	_SendToClients(evt)
end

function outputETFList()

	--_WriteCatchAplLog(gETFList)
	local nameList = "";
	for IssueCode,FundName in pairs (_ETFIssue2NameTable)do
		nameList = nameList..";"..IssueCode;
	end
	local DTSEvent evt = _CreateEventObject("OutputAllETFList")
	evt._SetFld("AllETFList",nameList)

	_SendToClients(evt)
end

--添加ETF监控
_OnEventDefined(AddNewETF evt)
	local issueCode = evt._GetFld("IssueCode")
	local etfName = _ETFIssue2NameTable[issueCode]

	if not gSelectETFListTable[issueCode] then
		local DTSEvent ETFInfoevt = _CreateEventObject("ETFArbiSpaceEvent")
		ETFInfoevt._SetFld("IssueCode",issueCode)
		ETFInfoevt._SetFld("ETFName",etfName)
		ETFInfoevt._SetFld("ETFPremMarketValue","-")
		ETFInfoevt._SetFld("ComponentPremMarketValue","-")
		ETFInfoevt._SetFld("PremFare","-")
		ETFInfoevt._SetFld("ETFPremPrice","-")
		ETFInfoevt._SetFld("ComponentPremPrice","-")
		ETFInfoevt._SetFld("PremiumProfit","-")
		ETFInfoevt._SetFld("ComponentDiscMarketValue","-")
		ETFInfoevt._SetFld("ETFDiscMarketValue","-")
		ETFInfoevt._SetFld("DiscFare","-")
		ETFInfoevt._SetFld("ETFDiscPrice","-")
		ETFInfoevt._SetFld("ComponentDiscPrice","-")
		ETFInfoevt._SetFld("DiscountProfit","-")
		ETFInfoevt._SetFld("DeleteFlag","0")
		_SendToClients(ETFInfoevt)
		gSelectETFListTable[issueCode] = 1
		saveETFList()
		local log = sys_format("Add New ETF: issueCode = %s successed",issueCode)
		_WriteCatchAplLog(log)
		--注册ETF信息
        _PosRegisterPrice(issueCode)

		if _ETFComponentTable[etfName] then
			for stockIssueCode,value in pairs(_ETFComponentTable[etfName]) do
				if not _IssueETFTable[stockIssueCode] then
					_IssueETFTable[stockIssueCode] = {}
				end
				_IssueETFTable[stockIssueCode][etfName] = 1
				local priceInfo = _PosPriceTable[stockIssueCode]
				if priceInfo then
					OnPrice(stockIssueCode, priceInfo)
				else
                    _PosRegisterPrice(stockIssueCode)
				end
			end
		end
	else
		local log = sys_format("Add New ETF: issueCode = %s failed, Issue existed",issueCode)
		_WriteCatchAplLog(log)
	end
_End

--删除ETF监控
_OnEventDefined(DeleteETF evt)
	local issueCode = evt._GetFld("ETFName")
	if(not gSelectETFListTable[issueCode]) then
			local log = sys_format("Delete ETF: issueCode = %s failed, Issue not existed,table is nil",issueCode)

		_WriteCatchAplLog(log)
	else
		if (gSelectETFListTable[issueCode] == 1) then
			gSelectETFListTable[issueCode] = 0
			SendETFInfo(issueCode)
			gSelectETFListTable[issueCode] = nil
			IssuePriceTable[issueCode] = nil
			local log = sys_format("Delete ETF: issueCode = %s successed",issueCode)
			_WriteCatchAplLog(log)
			local marketCode = _PosIssueMarketTable[issueCode]
			--_StopPrice(issueCode,marketCode)
			saveETFList()
		else
			local log = sys_format("Delete ETF: issueCode = %s failed, Issue not existed",issueCode)

			_WriteCatchAplLog(log)
		end
	end
_End

--保存现有ETF列表
function saveETFList()
	savedETFStore._Clear()
	for issueCode,value in pairs(gSelectETFListTable)do
		if value then
			if value == 1 then
				local DTSEvent evt = _CreateEventObject("SaveETF")
				evt._SetFld("IssueCode",issueCode)
				savedETFStore._SaveData("SaveETF",evt)
			end
		end
	end
end









